/* OPTIMIZE_C -- minima.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_ini[6];
static bint_t b_a_rti[12];
static int b_a_rai[12];
static int b_a_rmi[12];
static int b_a_rci[12];
static int b_a_rki[12];
static int b_a_ryi[12];
static int b_a_dli[6];
static int b_a_hbi[6];
static bint_t b_a_mxi[256];
static bint_t b_a_myi[256];
static int b_a_cti[16];
static int b_a_oti[8];
static int b_a_sli[64];
static int b_a_tci[5];
static int b_a_tli[61];
static int b_a_rgi[40];
static bint_t b_v_pxi;
static bint_t b_v_pyi;
static int b_v_dxi;
static int b_v_dyi;
static int b_v_axi;
static int b_v_pki;
static int b_v_mii;
static bint_t b_v_moi;
static bint_t b_v_dai;
static bint_t b_v_dpi;
static int b_v_pgi;
static int b_v_mpi;
static bint_t b_v_qai;
static bint_t b_v_qbi;
static int b_v_gri;
static bint_t b_v_oji;
static int b_v_hui;
static int b_v_hpi;
static int b_v_sci;
static int b_v_dmi;
static bstr_t b_v_cms;
static bint_t b_v_ii;
static bint_t b_v_sxi;
static bint_t b_v_syi;
static bint_t b_v_vxi;
static bint_t b_v_vyi;
static int b_v_lxi;
static int b_v_lyi;
static int b_v_msi;
static int b_v_ki;
static bint_t b_v_nxi;
static bint_t b_v_nyi;
static int b_v_oxi;
static int b_v_oyi;
static bint_t b_v_wxi;
static bint_t b_v_wyi;
static int b_v_tti;
static bint_t b_v_qxi;
static bint_t b_v_qyi;
static bint_t b_v_ri;
static bint_t b_v_sai;
static bint_t b_v_ixi;
static bint_t b_v_iyi;
static int b_v_ci;
static bint_t b_v_hti;
static bint_t b_v_qci;
static bint_t b_v_rbi;
static bint_t b_v_ssi;
static bint_t b_v_ddi;
static bint_t b_v_ji;
static int b_v_sri;
static bint_t b_v_fxi;
static bint_t b_v_fyi;
static int b_v_hmi;
static bint_t b_v_jxi;
static bint_t b_v_jyi;
static bint_t b_v_txi;
static int b_v_tyi;
static bstr_t b_v_ts;
static int b_v_cli;
static int b_v_tli;
static int b_v_tci;
static bstr_t b_v_tns;
static bstr_t b_v_ks;
static int b_v_ai;
static int b_v_rpi;
static bstr_t b_v_mks;
static bstr_t b_v_kas;
static bint_t b_v_mdi;
static bstr_t b_v_ns;
static bstr_t b_v_mas;
static bint_t b_v_lii;
static int b_v_qzi;
static int b_v_gmi;
static bstr_t b_v_trs;
static int b_v_oki;
static bstr_t b_v_sts;
static int b_v_vi;
static bint_t b_v_ogi;
static int b_v_d2i;
static bint_t b_v_d1i;
static bint_t b_v_d0i;
static int b_v_c2i;
static bint_t b_v_c1i;
static bint_t b_v_c0i;
static int b_v_u0i;
static int b_v_u1i;
static int b_v_u2i;
static int b_v_u3i;
static int b_v_u4i;
static int b_v_u5i;
static int b_v_gdi;
static int b_v_rri;
static int b_v_M0;
static bint_t b_v_M1;
static int b_v_M2;
static int b_v_M3;
static bint_t b_v_M4;
static int b_v_M5;
static int b_v_M6;
static bint_t b_v_M7;
static int b_v_M8;
static bint_t b_v_M9;
static int b_v_M10;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[3];
static int b_rtfor_sp=0;
static bint_t b_fl_23;
static bint_t b_fl_25;
static bint_t b_fl_26;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,4,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,5,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,5,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,4,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,5,0,0},{1,0,5,0,0},{1,0,7,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,5,0,0},{1,0,5,0,0},{1,0,7,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,2,0,0},{1,0,3,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,6,0,0},{1,0,6,0,0},{1,0,7,0,0},{1,0,8,0,0},{1,0,8,0,0},{1,0,9,0,0},{1,0,9,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,9,0,0},{1,0,9,0,0},{1,0,8,0,0},{1,0,8,0,0},{1,0,7,0,0},{1,0,6,0,0},{1,0,6,0,0},{1,0,5,0,0},{1,0,4,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,-2,0,0},{1,0,-3,0,0},{1,0,-4,0,0},{1,0,-5,0,0},{1,0,-6,0,0},{1,0,-6,0,0},{1,0,-7,0,0},{1,0,-8,0,0},{1,0,-8,0,0},{1,0,-9,0,0},{1,0,-9,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-9,0,0},{1,0,-9,0,0},{1,0,-8,0,0},{1,0,-8,0,0},{1,0,-7,0,0},{1,0,-6,0,0},{1,0,-6,0,0},{1,0,-5,0,0},{1,0,-4,0,0},{1,0,-3,0,0},{1,0,-2,0,0},{1,0,-1,0,0},{1,0,0,0,0},{1,0,3,0,0},{1,0,14,0,0},{1,0,36,0,0},{1,0,80,0,0},{1,0,160,0,0},{1,0,0,0,0},{1,0,3,0,0},{1,0,7,0,0},{1,0,12,0,0},{1,0,18,0,0},{1,0,28,0,0}};
int b_data_len = 142;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 13 */
b_L13: ;
		/* line 14 */
b_L14: ;
		/* line 15 */
b_L15: ;
		/* line 20 */
b_L20: ;
		b_putc(147);
		b_nl();
		/* line 25 */
b_L25: ;
		/* line 26 */
b_L26: ;
		/* line 30 */
b_L30: ;
		b_v_pxi=(0);
		b_v_pyi=(0);
		b_v_dxi=(0);
		b_v_dyi=(-1);
		b_v_axi=(0);
		b_v_pki=(0);
		b_v_mii=(0);
		b_v_moi=(0);
		b_v_dai=(0);
		b_v_dpi=(0);
		b_v_pgi=(30);
		b_v_mpi=(0);
		b_v_qai=(-10000);
		b_v_qbi=(-10000);
		b_v_gri=(46);
		b_v_oji=(-10000);
		b_v_hui=(100);
		b_v_hpi=(100);
		b_v_sci=(0);
		b_v_dmi=(0);
		/* line 31 */
b_L31: ;
		b_v_cms=b_keep(b_lit("READY",5));
		/* line 32 */
b_L32: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f0_e;
b_f0_t: ;
		b_a_mxi[B_INT(b_v_ii)]=(-10000);
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f0_t;
b_f0_e: ;
		/* line 33 */
b_L33: ;
		b_v_sxi=(20);
		b_v_syi=(12);
		b_v_vxi=(-20);
		b_v_vyi=(-12);
		b_v_lxi=(-10000);
		b_v_lyi=(-10000);
		/* line 37 */
b_L37: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L7000;
b_ret0: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L7100;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L7200;
b_ret2: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L7300;
b_ret3: ;
		/* line 38 */
b_L38: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L8300;
b_ret4: ;
		/* line 40 */
b_L40: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1000;
b_ret5: ;
		b_v_msi=(9);
		b_gosubStack[b_gosubSP++]=6; goto b_L6000;
b_ret6: ;
		b_poke((650),(128));
		b_poke((652),(8));
		b_poke((53281.0),(6));
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 61 */
b_L61: ;
		if(-((b_v_ki) != ((64)))){
			b_v_dmi=(0);
		}
		/* line 62 */
b_L62: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=7; goto b_L8400;
b_ret7: ;
		}
		/* line 63 */
b_L63: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 65 */
b_L65: ;
		if(-((b_v_ki) == ((64)))){ goto b_L60; }
		/* line 70 */
b_L70: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 72 */
b_L72: ;
		if(-((b_v_ki) == ((33)))){
			b_gosubStack[b_gosubSP++]=8; goto b_L3000;
b_ret8: ;
			goto b_L60;
		}
		/* line 74 */
b_L74: ;
		if(-((b_v_ki) == ((20)))){
			b_gosubStack[b_gosubSP++]=9; goto b_L4000;
b_ret9: ;
			goto b_L60;
		}
		/* line 76 */
b_L76: ;
		if(-((b_v_ki) == ((14)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L2500;
b_ret10: ;
			goto b_L60;
		}
		/* line 78 */
b_L78: ;
		b_v_nxi=b_v_pxi;
		b_v_nyi=b_v_pyi;
		/* line 79 */
b_L79: ;
		b_v_oxi=b_v_dxi;
		b_v_oyi=b_v_dyi;
		/* line 80 */
b_L80: ;
		if(-((b_v_ki) == ((9)))){
			b_v_nyi=((b_v_pyi)-((1)));
			b_v_dxi=(0);
			b_v_dyi=(-1);
			b_v_pgi=(30);
		}
		/* line 82 */
b_L82: ;
		if(-((b_v_ki) == ((10)))){
			b_v_nxi=((b_v_pxi)-((1)));
			b_v_dxi=(-1);
			b_v_dyi=(0);
			b_v_pgi=(60);
		}
		/* line 84 */
b_L84: ;
		if(-((b_v_ki) == ((18)))){
			b_v_nxi=((b_v_pxi)+((1)));
			b_v_dxi=(1);
			b_v_dyi=(0);
			b_v_pgi=(62);
		}
		/* line 86 */
b_L86: ;
		if(-((b_v_ki) == ((13)))){
			b_v_nyi=((b_v_pyi)+((1)));
			b_v_dxi=(0);
			b_v_dyi=(1);
			b_v_pgi=(22);
		}
		/* line 87 */
b_L87: ;
		if((B_INT(-((b_v_dxi) != (b_v_oxi))) | B_INT(-((b_v_dyi) != (b_v_oyi))))){
			if(-((b_v_mpi) > ((0)))){
				b_v_mpi=(0);
				b_v_qai=(-10000);
				b_v_qbi=(-10000);
			}
		}
		/* line 88 */
b_L88: ;
		b_v_wxi=b_v_nxi;
		b_v_wyi=b_v_nyi;
		b_gosubStack[b_gosubSP++]=11; goto b_L2000;
b_ret11: ;
		/* line 90 */
b_L90: ;
		if(-((b_v_tti) >= ((1)))){
			b_gosubStack[b_gosubSP++]=12; goto b_L900;
b_ret12: ;
			goto b_L60;
		}
		/* line 95 */
b_L95: ;
		b_v_pxi=b_v_nxi;
		b_v_pyi=b_v_nyi;
		b_v_lxi=(-10000);
		b_v_lyi=(-10000);
		b_v_qxi=((b_v_sxi)+(b_v_dxi));
		b_v_qyi=((b_v_syi)+(b_v_dyi));
		/* line 96 */
b_L96: ;
		if(-((b_v_qxi) < ((3)))){
			b_gosubStack[b_gosubSP++]=13; goto b_L1260;
b_ret13: ;
		}
		/* line 97 */
b_L97: ;
		if(-((b_v_qxi) > ((36)))){
			b_gosubStack[b_gosubSP++]=14; goto b_L1240;
b_ret14: ;
		}
		/* line 98 */
b_L98: ;
		if(-((b_v_qyi) < ((3)))){
			b_gosubStack[b_gosubSP++]=15; goto b_L1200;
b_ret15: ;
		}
		/* line 99 */
b_L99: ;
		if(-((b_v_qyi) > ((20)))){
			b_gosubStack[b_gosubSP++]=16; goto b_L1220;
b_ret16: ;
		}
		/* line 100 */
b_L100: ;
		if(-((b_v_qxi) >= ((3)))){
			if(-((b_v_qxi) <= ((36)))){
				if(-((b_v_qyi) >= ((3)))){
					if(-((b_v_qyi) <= ((20)))){
						b_gosubStack[b_gosubSP++]=17; goto b_L1300;
b_ret17: ;
					}
				}
			}
		}
		/* line 101 */
b_L101: ;
		b_v_msi=(0);
		b_gosubStack[b_gosubSP++]=18; goto b_L6000;
b_ret18: ;
		/* line 102 */
b_L102: ;
		b_v_sci=((b_v_sci)+((1)));
		if(-((b_v_sci) >= ((25)))){
			b_v_sci=(0);
			b_v_hui=((b_v_hui)-((1)));
			if(-((b_v_hui) < ((0)))){
				b_v_hui=(0);
			}
		}
		/* line 103 */
b_L103: ;
		if(-((b_v_hui) <= ((0)))){
			b_v_hpi=((b_v_hpi)-((1)));
			if(-((b_v_hpi) < ((0)))){
				b_v_hpi=(0);
			}
		}
		/* line 104 */
b_L104: ;
		if(-((b_v_hpi) <= ((0)))){
			b_gosubStack[b_gosubSP++]=19; goto b_L9000;
b_ret19: ;
			goto b_L60;
		}
		/* line 105 */
b_L105: ;
		goto b_L60;
		/* line 900 */
b_L900: ;
		/* line 902 */
b_L902: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L2500;
b_ret20: ;
		goto b_return;
		/* line 1000 */
b_L1000: ;
		/* line 1008 */
b_L1008: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f1_e;
b_f1_t: ;
		/* line 1010 */
b_L1010: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_ixi=b_v_vxi;
		b_v_iyi=b_v_wyi;
		/* line 1012 */
b_L1012: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f2_e;
		b_v_M0=((b_v_iyi)*((4)));
		b_v_M1=b_a_sli[B_INT((B_INT(b_v_M0) & B_INT((63))))];
b_f2_t: ;
		/* line 1014 */
b_L1014: ;
		b_v_hti=((((((b_a_sli[B_INT((B_INT(((b_v_ixi)*((3)))) & B_INT((63))))])+(b_v_M1)))+(b_a_sli[B_INT((B_INT(((((b_v_ixi)+(b_v_iyi)))*((2)))) & B_INT((63))))])))+((30)));
		/* line 1016 */
b_L1016: ;
		b_v_qci=b_a_tli[B_INT(b_v_hti)];
		/* line 1017 */
b_L1017: ;
		if(-((b_v_qci) == ((36)))){
			if(-(((B_INT(b_v_ixi) & B_INT((7)))) == ((B_INT(b_v_iyi) & B_INT((7)))))){
				b_v_qci=(61);
			}
		}
		/* line 1020 */
b_L1020: ;
		b_poke(b_v_sai,b_v_qci);
		b_v_sai=((b_v_sai)+((1)));
		b_v_ixi=((b_v_ixi)+((1)));
		/* line 1022 */
b_L1022: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f2_t;
b_f2_e: ;
		/* line 1026 */
b_L1026: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f1_t;
b_f1_e: ;
		/* line 1080 */
b_L1080: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L1700;
b_ret21: ;
		/* line 1110 */
b_L1110: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1202 */
b_L1202: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_gri);
		b_v_vyi=((b_v_vyi)-((1)));
		b_v_rbi=(1904);
		/* line 1203 */
b_L1203: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f3_e;
b_f3_t: ;
		/* line 1204 */
b_L1204: ;
		b_v_ssi=b_v_rbi;
		b_v_ddi=((b_v_rbi)+((40)));
		/* line 1206 */
b_L1206: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f4_e;
b_f4_t: ;
		b_poke(b_v_ddi,B_INT(b_peek((unsigned int)(b_v_ssi))));
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f4_t;
b_f4_e: ;
		/* line 1207 */
b_L1207: ;
		b_v_rbi=((b_v_rbi)-((40)));
		/* line 1208 */
b_L1208: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f3_t;
b_f3_e: ;
		/* line 1210 */
b_L1210: ;
		b_v_ri=(0);
		b_gosubStack[b_gosubSP++]=22; goto b_L1600;
b_ret22: ;
		/* line 1214 */
b_L1214: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1216 */
b_L1216: ;
		goto b_return;
		/* line 1220 */
b_L1220: ;
		/* line 1222 */
b_L1222: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_gri);
		b_v_vyi=((b_v_vyi)+((1)));
		b_v_rbi=(1064);
		/* line 1223 */
b_L1223: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f5_e;
b_f5_t: ;
		/* line 1224 */
b_L1224: ;
		b_v_ssi=b_v_rbi;
		b_v_ddi=((b_v_rbi)-((40)));
		/* line 1226 */
b_L1226: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f6_e;
b_f6_t: ;
		b_poke(b_v_ddi,B_INT(b_peek((unsigned int)(b_v_ssi))));
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f6_t;
b_f6_e: ;
		/* line 1227 */
b_L1227: ;
		b_v_rbi=((b_v_rbi)+((40)));
		/* line 1228 */
b_L1228: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f5_t;
b_f5_e: ;
		/* line 1230 */
b_L1230: ;
		b_v_ri=(23);
		b_gosubStack[b_gosubSP++]=23; goto b_L1600;
b_ret23: ;
		/* line 1234 */
b_L1234: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1236 */
b_L1236: ;
		goto b_return;
		/* line 1240 */
b_L1240: ;
		/* line 1242 */
b_L1242: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_gri);
		b_v_vxi=((b_v_vxi)+((1)));
		b_v_rbi=(1024);
		/* line 1243 */
b_L1243: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f7_e;
b_f7_t: ;
		/* line 1244 */
b_L1244: ;
		b_v_ssi=((b_v_rbi)+((1)));
		b_v_ddi=b_v_rbi;
		/* line 1246 */
b_L1246: ;
		b_v_ci=(0);
		if(b_v_ci > 38) goto b_f8_e;
b_f8_t: ;
		b_poke(b_v_ddi,B_INT(b_peek((unsigned int)(b_v_ssi))));
		b_v_ci += 1;
		if(b_v_ci <= 38) goto b_f8_t;
b_f8_e: ;
		/* line 1247 */
b_L1247: ;
		b_v_rbi=((b_v_rbi)+((40)));
		/* line 1248 */
b_L1248: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f7_t;
b_f7_e: ;
		/* line 1250 */
b_L1250: ;
		b_v_ci=(39);
		b_gosubStack[b_gosubSP++]=24; goto b_L1500;
b_ret24: ;
		/* line 1254 */
b_L1254: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1256 */
b_L1256: ;
		goto b_return;
		/* line 1260 */
b_L1260: ;
		/* line 1262 */
b_L1262: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_gri);
		b_v_vxi=((b_v_vxi)-((1)));
		b_v_rbi=(1024);
		/* line 1263 */
b_L1263: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f9_e;
b_f9_t: ;
		/* line 1264 */
b_L1264: ;
		b_v_ssi=((b_v_rbi)+((38)));
		b_v_ddi=((b_v_rbi)+((39)));
		/* line 1266 */
b_L1266: ;
		b_v_ci=(38);
		if(b_v_ci < 0) goto b_f10_e;
b_f10_t: ;
		b_poke(b_v_ddi,B_INT(b_peek((unsigned int)(b_v_ssi))));
		b_v_ci += -1;
		if(b_v_ci >= 0) goto b_f10_t;
b_f10_e: ;
		/* line 1267 */
b_L1267: ;
		b_v_rbi=((b_v_rbi)+((40)));
		/* line 1268 */
b_L1268: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f9_t;
b_f9_e: ;
		/* line 1270 */
b_L1270: ;
		b_v_ci=(0);
		b_gosubStack[b_gosubSP++]=25; goto b_L1500;
b_ret25: ;
		/* line 1274 */
b_L1274: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1276 */
b_L1276: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1302 */
b_L1302: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_gri);
		/* line 1304 */
b_L1304: ;
		b_v_sxi=b_v_qxi;
		b_v_syi=b_v_qyi;
		/* line 1306 */
b_L1306: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1308 */
b_L1308: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1502 */
b_L1502: ;
		b_v_wxi=((b_v_vxi)+(b_v_ci));
		b_v_sai=(((1024))+(b_v_ci));
		b_v_ixi=b_v_wxi;
		b_v_iyi=b_v_vyi;
		/* line 1503 */
b_L1503: ;
		if(-((b_v_moi) == ((0)))){ goto b_L1514; }
		/* line 1504 */
b_L1504: ;
		b_v_ji=(0);
		if(b_v_ji > 23) goto b_f11_e;
b_f11_t: ;
		b_a_rgi[B_INT(b_v_ji)]=(0);
		b_v_ji += 1;
		if(b_v_ji <= 23) goto b_f11_t;
b_f11_e: ;
		/* line 1505 */
b_L1505: ;
		b_v_ji=(0);
		if(b_v_ji > 255) goto b_f12_e;
		b_v_M2=((b_v_vyi)+((23)));
b_f12_t: ;
		if(-((b_a_mxi[B_INT(b_v_ji)]) == ((-10000)))){ goto b_L1513; }
		/* line 1506 */
b_L1506: ;
		if(-((b_a_mxi[B_INT(b_v_ji)]) == (b_v_ixi))){
			if(-((b_a_myi[B_INT(b_v_ji)]) >= (b_v_vyi))){
				if(-((b_a_myi[B_INT(b_v_ji)]) <= (b_v_M2))){
					b_a_rgi[B_INT(((b_a_myi[B_INT(b_v_ji)])-(b_v_vyi)))]=(1);
				}
			}
		}
		/* line 1513 */
b_L1513: ;
		b_v_ji += 1;
		if(b_v_ji <= 255) goto b_f12_t;
b_f12_e: ;
		/* line 1514 */
b_L1514: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f13_e;
		b_v_M3=((b_v_ixi)*((3)));
		b_v_M4=b_a_sli[B_INT((B_INT(b_v_M3) & B_INT((63))))];
b_f13_t: ;
		/* line 1516 */
b_L1516: ;
		b_v_hti=((((((b_v_M4)+(b_a_sli[B_INT((B_INT(((b_v_iyi)*((4)))) & B_INT((63))))])))+(b_a_sli[B_INT((B_INT(((((b_v_ixi)+(b_v_iyi)))*((2)))) & B_INT((63))))])))+((30)));
		/* line 1517 */
b_L1517: ;
		b_v_qci=b_a_tli[B_INT(b_v_hti)];
		if(-((b_v_qci) == ((36)))){
			if(-(((B_INT(b_v_ixi) & B_INT((7)))) == ((B_INT(b_v_iyi) & B_INT((7)))))){
				b_v_qci=(61);
			}
		}
		/* line 1518 */
b_L1518: ;
		if(-((b_a_rgi[B_INT(b_v_ri)]) == ((1)))){
			b_v_qci=b_v_gri;
		}
		/* line 1519 */
b_L1519: ;
		b_poke(b_v_sai,b_v_qci);
		b_v_sai=((b_v_sai)+((40)));
		b_v_iyi=((b_v_iyi)+((1)));
		/* line 1521 */
b_L1521: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f13_t;
b_f13_e: ;
		/* line 1522 */
b_L1522: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1602 */
b_L1602: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_iyi=b_v_wyi;
		b_v_ixi=b_v_vxi;
		/* line 1603 */
b_L1603: ;
		if(-((b_v_moi) == ((0)))){ goto b_L1614; }
		/* line 1604 */
b_L1604: ;
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f14_e;
b_f14_t: ;
		b_a_rgi[B_INT(b_v_ji)]=(0);
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f14_t;
b_f14_e: ;
		/* line 1605 */
b_L1605: ;
		b_v_ji=(0);
		if(b_v_ji > 255) goto b_f15_e;
		b_v_M5=((b_v_vxi)+((39)));
b_f15_t: ;
		if(-((b_a_mxi[B_INT(b_v_ji)]) == ((-10000)))){ goto b_L1613; }
		/* line 1606 */
b_L1606: ;
		if(-((b_a_myi[B_INT(b_v_ji)]) == (b_v_iyi))){
			if(-((b_a_mxi[B_INT(b_v_ji)]) >= (b_v_vxi))){
				if(-((b_a_mxi[B_INT(b_v_ji)]) <= (b_v_M5))){
					b_a_rgi[B_INT(((b_a_mxi[B_INT(b_v_ji)])-(b_v_vxi)))]=(1);
				}
			}
		}
		/* line 1613 */
b_L1613: ;
		b_v_ji += 1;
		if(b_v_ji <= 255) goto b_f15_t;
b_f15_e: ;
		/* line 1614 */
b_L1614: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f16_e;
		b_v_M6=((b_v_iyi)*((4)));
		b_v_M7=b_a_sli[B_INT((B_INT(b_v_M6) & B_INT((63))))];
b_f16_t: ;
		/* line 1616 */
b_L1616: ;
		b_v_hti=((((((b_a_sli[B_INT((B_INT(((b_v_ixi)*((3)))) & B_INT((63))))])+(b_v_M7)))+(b_a_sli[B_INT((B_INT(((((b_v_ixi)+(b_v_iyi)))*((2)))) & B_INT((63))))])))+((30)));
		/* line 1617 */
b_L1617: ;
		b_v_qci=b_a_tli[B_INT(b_v_hti)];
		if(-((b_v_qci) == ((36)))){
			if(-(((B_INT(b_v_ixi) & B_INT((7)))) == ((B_INT(b_v_iyi) & B_INT((7)))))){
				b_v_qci=(61);
			}
		}
		/* line 1618 */
b_L1618: ;
		if(-((b_a_rgi[B_INT(b_v_ci)]) == ((1)))){
			b_v_qci=b_v_gri;
		}
		/* line 1619 */
b_L1619: ;
		b_poke(b_v_sai,b_v_qci);
		b_v_sai=((b_v_sai)+((1)));
		b_v_ixi=((b_v_ixi)+((1)));
		/* line 1621 */
b_L1621: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f16_t;
b_f16_e: ;
		/* line 1622 */
b_L1622: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1702 */
b_L1702: ;
		if(-((b_v_moi) == ((0)))){ goto b_L1715; }
		/* line 1703 */
b_L1703: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f17_e;
b_f17_t: ;
		/* line 1704 */
b_L1704: ;
		if(-((b_a_mxi[B_INT(b_v_ii)]) == ((-10000)))){ goto b_L1712; }
		/* line 1706 */
b_L1706: ;
		b_v_sci=((b_a_mxi[B_INT(b_v_ii)])-(b_v_vxi));
		b_v_sri=((b_a_myi[B_INT(b_v_ii)])-(b_v_vyi));
		/* line 1707 */
b_L1707: ;
		if(-((b_v_sci) < ((0)))){ goto b_L1712; }
		/* line 1708 */
b_L1708: ;
		if(-((b_v_sci) > ((39)))){ goto b_L1712; }
		/* line 1709 */
b_L1709: ;
		if(-((b_v_sri) < ((0)))){ goto b_L1712; }
		/* line 1710 */
b_L1710: ;
		if(-((b_v_sri) > ((23)))){ goto b_L1712; }
		/* line 1711 */
b_L1711: ;
		b_poke((((((1024))+(((b_v_sri)*((40))))))+(b_v_sci)),b_v_gri);
		/* line 1712 */
b_L1712: ;
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f17_t;
b_f17_e: ;
		/* line 1715 */
b_L1715: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
		/* line 1718 */
b_L1718: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		b_v_ixi=b_v_wxi;
		b_v_iyi=b_v_wyi;
		b_gosubStack[b_gosubSP++]=26; goto b_L8000;
b_ret26: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L7800;
b_ret27: ;
		/* line 2008 */
b_L2008: ;
		if(-((b_v_tti) == ((4)))){
			b_gosubStack[b_gosubSP++]=28; goto b_L2100;
b_ret28: ;
		}
		/* line 2010 */
b_L2010: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L2200;
b_ret29: ;
		/* line 2015 */
b_L2015: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2105 */
b_L2105: ;
		if(-((b_v_tti) != ((4)))){
			goto b_return;
		}
		/* line 2110 */
b_L2110: ;
		if(-(((B_INT(b_v_ixi) & B_INT((7)))) == ((B_INT(b_v_iyi) & B_INT((7)))))){
			b_v_tti=(5);
		}
		/* line 2115 */
b_L2115: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2205 */
b_L2205: ;
		if(-((b_v_tti) == ((0)))){
			goto b_return;
		}
		/* line 2206 */
b_L2206: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f18_e;
b_f18_t: ;
		/* line 2208 */
b_L2208: ;
		if(-((b_a_mxi[B_INT(b_v_ii)]) == ((-10000)))){ goto b_L2215; }
		/* line 2210 */
b_L2210: ;
		if(-((b_a_mxi[B_INT(b_v_ii)]) == (b_v_wxi))){
			if(-((b_a_myi[B_INT(b_v_ii)]) == (b_v_wyi))){
				b_v_tti=(0);
			}
		}
		/* line 2215 */
b_L2215: ;
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f18_t;
b_f18_e: ;
		/* line 2220 */
b_L2220: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2505 */
b_L2505: ;
		b_v_fxi=((b_v_pxi)+(b_v_dxi));
		b_v_fyi=((b_v_pyi)+(b_v_dyi));
		/* line 2510 */
b_L2510: ;
		b_v_wxi=b_v_fxi;
		b_v_wyi=b_v_fyi;
		b_gosubStack[b_gosubSP++]=30; goto b_L2000;
b_ret30: ;
		/* line 2515 */
b_L2515: ;
		if(-((b_v_tti) == ((0)))){
			b_v_msi=(8);
			b_gosubStack[b_gosubSP++]=31; goto b_L6000;
b_ret31: ;
			goto b_return;
		}
		/* line 2518 */
b_L2518: ;
		if(-((b_v_tti) == ((2)))){
			if(-((b_v_pki) < ((1)))){
				b_v_msi=(5);
				b_gosubStack[b_gosubSP++]=32; goto b_L6000;
b_ret32: ;
				goto b_return;
			}
		}
		/* line 2519 */
b_L2519: ;
		if(-((b_v_tti) == ((3)))){
			if(-((b_v_pki) < ((2)))){
				b_v_msi=(6);
				b_gosubStack[b_gosubSP++]=33; goto b_L6000;
b_ret33: ;
				goto b_return;
			}
		}
		/* line 2520 */
b_L2520: ;
		if(-((b_v_tti) == ((4)))){
			if(-((b_v_pki) < ((3)))){
				b_v_msi=(7);
				b_gosubStack[b_gosubSP++]=34; goto b_L6000;
b_ret34: ;
				goto b_return;
			}
		}
		/* line 2521 */
b_L2521: ;
		if(-((b_v_tti) == ((5)))){
			if(-((b_v_pki) < ((4)))){
				b_v_msi=(19);
				b_gosubStack[b_gosubSP++]=35; goto b_L6000;
b_ret35: ;
				goto b_return;
			}
		}
		/* line 2523 */
b_L2523: ;
		b_v_hmi=b_a_hbi[B_INT(b_v_tti)];
		if(-((b_v_tti) == ((1)))){
			if(-((b_v_axi) == ((0)))){
				b_v_hmi=(6);
			}
		}
		/* line 2524 */
b_L2524: ;
		if(-((b_v_fxi) == (b_v_qai))){
			if(-((b_v_fyi) == (b_v_qbi))){
				b_v_mpi=((b_v_mpi)+((1)));
				goto b_L2526;
			}
		}
		/* line 2525 */
b_L2525: ;
		b_v_qai=b_v_fxi;
		b_v_qbi=b_v_fyi;
		b_v_mpi=(1);
		/* line 2526 */
b_L2526: ;
		if(-((b_v_mpi) >= (b_v_hmi))){ goto b_L2530; }
		/* line 2527 */
b_L2527: ;
		if(-((b_v_mpi) == ((1)))){
			b_gosubStack[b_gosubSP++]=36; goto b_L5686;
b_ret36: ;
		}
		/* line 2528 */
b_L2528: ;
		b_gosubStack[b_gosubSP++]=37; goto b_L6300;
b_ret37: ;
		goto b_return;
		/* line 2530 */
b_L2530: ;
		/* line 2532 */
b_L2532: ;
		if(-((b_v_tti) == ((1)))){
			b_a_ini[B_INT((0))]=((((b_a_ini[B_INT((0))])+((1))))+(b_v_axi));
			b_v_msi=(1);
			b_gosubStack[b_gosubSP++]=38; goto b_L2600;
b_ret38: ;
			goto b_L2570;
		}
		/* line 2534 */
b_L2534: ;
		if(-((b_v_tti) == ((2)))){
			b_a_ini[B_INT((1))]=((b_a_ini[B_INT((1))])+((1)));
			b_v_msi=(2);
			b_gosubStack[b_gosubSP++]=39; goto b_L2650;
b_ret39: ;
			goto b_L2570;
		}
		/* line 2536 */
b_L2536: ;
		if(-((b_v_tti) == ((3)))){
			b_a_ini[B_INT((2))]=((b_a_ini[B_INT((2))])+((1)));
			b_v_msi=(3);
			b_gosubStack[b_gosubSP++]=40; goto b_L2650;
b_ret40: ;
			goto b_L2570;
		}
		/* line 2538 */
b_L2538: ;
		if(-((b_v_tti) == ((4)))){
			b_a_ini[B_INT((3))]=((b_a_ini[B_INT((3))])+((1)));
			b_v_msi=(4);
			b_gosubStack[b_gosubSP++]=41; goto b_L2650;
b_ret41: ;
			goto b_L2570;
		}
		/* line 2540 */
b_L2540: ;
		if(-((b_v_tti) == ((5)))){
			b_a_ini[B_INT((5))]=((b_a_ini[B_INT((5))])+((1)));
			b_v_msi=(18);
			b_gosubStack[b_gosubSP++]=42; goto b_L2650;
b_ret42: ;
			goto b_L2570;
		}
		/* line 2542 */
b_L2542: ;
		b_gosubStack[b_gosubSP++]=43; goto b_L6000;
b_ret43: ;
		goto b_return;
		/* line 2570 */
b_L2570: ;
		b_a_mxi[B_INT(b_v_mii)]=b_v_fxi;
		b_a_myi[B_INT(b_v_mii)]=b_v_fyi;
		b_v_mii=(B_INT(((b_v_mii)+((1)))) & B_INT((255)));
		b_v_moi=(1);
		b_v_mpi=(0);
		b_v_qai=(-10000);
		b_v_qbi=(-10000);
		b_v_oji=(-10000);
		/* line 2571 */
b_L2571: ;
		b_v_hui=((b_v_hui)+((5)));
		if(-((b_v_hui) > ((100)))){
			b_v_hui=(100);
		}
		/* line 2572 */
b_L2572: ;
		b_v_jxi=((b_v_sxi)+(b_v_dxi));
		b_v_jyi=((b_v_syi)+(b_v_dyi));
		/* line 2574 */
b_L2574: ;
		if(-((b_v_jxi) >= ((0)))){
			if(-((b_v_jxi) <= ((39)))){
				if(-((b_v_jyi) >= ((0)))){
					if(-((b_v_jyi) <= ((23)))){
						b_poke((((((1024))+(((b_v_jyi)*((40))))))+(b_v_jxi)),b_v_gri);
						b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pgi);
						b_gosubStack[b_gosubSP++]=44; goto b_L6000;
b_ret44: ;
						goto b_return;
					}
				}
			}
		}
		/* line 2580 */
b_L2580: ;
		b_gosubStack[b_gosubSP++]=45; goto b_L6000;
b_ret45: ;
		goto b_return;
		/* line 2600 */
b_L2600: ;
		/* line 2605 */
b_L2605: ;
		if(-((b_v_axi) == ((0)))){
			goto b_return;
		}
		/* line 2610 */
b_L2610: ;
		b_v_dai=((b_v_dai)-((1)));
		if(-((b_v_dai) > ((0)))){
			goto b_return;
		}
		/* line 2615 */
b_L2615: ;
		b_v_axi=(0);
		b_v_dai=(0);
		b_v_msi=(17);
		goto b_return;
		/* line 2650 */
b_L2650: ;
		/* line 2655 */
b_L2655: ;
		if(-((b_v_pki) == ((0)))){
			goto b_return;
		}
		/* line 2660 */
b_L2660: ;
		b_v_dpi=((b_v_dpi)-((1)));
		if(-((b_v_dpi) > ((0)))){
			goto b_return;
		}
		/* line 2665 */
b_L2665: ;
		b_v_pki=(0);
		b_v_dpi=(0);
		b_v_msi=(16);
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3005 */
b_L3005: ;
		b_putc(147);
		b_nl();
		b_poke((53281.0),(0));
		/* line 3010 */
b_L3010: ;
		b_v_txi=(11);
		b_v_tyi=(0);
		b_v_ts=b_keep(b_lit("*** INVENTORY ***",17));
		b_v_cli=(7);
		b_gosubStack[b_gosubSP++]=46; goto b_L5050;
b_ret46: ;
		/* line 3015 */
b_L3015: ;
		b_v_txi=(1);
		b_v_tyi=(2);
		b_v_ts=b_keep(b_lit("RESOURCES",9));
		b_v_cli=(3);
		b_gosubStack[b_gosubSP++]=47; goto b_L5050;
b_ret47: ;
		/* line 3018 */
b_L3018: ;
		b_v_txi=(20);
		b_v_tyi=(2);
		b_v_ts=b_keep(b_lit("TOOLS",5));
		b_v_cli=(3);
		b_gosubStack[b_gosubSP++]=48; goto b_L5050;
b_ret48: ;
		/* line 3020 */
b_L3020: ;
		b_v_txi=(1);
		b_v_tyi=(3);
		b_v_ts=b_keep(b_lit("WOOD    X",9));
		b_v_cli=(9);
		b_gosubStack[b_gosubSP++]=49; goto b_L5050;
b_ret49: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((0))])));
		b_gosubStack[b_gosubSP++]=50; goto b_L5050;
b_ret50: ;
		/* line 3025 */
b_L3025: ;
		b_v_txi=(1);
		b_v_tyi=(4);
		b_v_ts=b_keep(b_lit("STONE   X",9));
		b_v_cli=(12);
		b_gosubStack[b_gosubSP++]=51; goto b_L5050;
b_ret51: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((1))])));
		b_gosubStack[b_gosubSP++]=52; goto b_L5050;
b_ret52: ;
		/* line 3030 */
b_L3030: ;
		b_v_txi=(1);
		b_v_tyi=(5);
		b_v_ts=b_keep(b_lit("IRON    X",9));
		b_v_cli=(14);
		b_gosubStack[b_gosubSP++]=53; goto b_L5050;
b_ret53: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((2))])));
		b_gosubStack[b_gosubSP++]=54; goto b_L5050;
b_ret54: ;
		/* line 3035 */
b_L3035: ;
		b_v_txi=(1);
		b_v_tyi=(6);
		b_v_ts=b_keep(b_lit("GOLD    X",9));
		b_v_cli=(7);
		b_gosubStack[b_gosubSP++]=55; goto b_L5050;
b_ret55: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((3))])));
		b_gosubStack[b_gosubSP++]=56; goto b_L5050;
b_ret56: ;
		/* line 3037 */
b_L3037: ;
		b_v_txi=(1);
		b_v_tyi=(7);
		b_v_ts=b_keep(b_lit("DIAMOND X",9));
		b_v_cli=(1);
		b_gosubStack[b_gosubSP++]=57; goto b_L5050;
b_ret57: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((5))])));
		b_gosubStack[b_gosubSP++]=58; goto b_L5050;
b_ret58: ;
		/* line 3040 */
b_L3040: ;
		b_v_txi=(1);
		b_v_tyi=(8);
		b_v_ts=b_keep(b_lit("STICK   X",9));
		b_v_cli=(15);
		b_gosubStack[b_gosubSP++]=59; goto b_L5050;
b_ret59: ;
		b_v_txi=((b_v_txi)+((9)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((4))])));
		b_gosubStack[b_gosubSP++]=60; goto b_L5050;
b_ret60: ;
		/* line 3050 */
b_L3050: ;
		b_v_tli=b_v_axi;
		b_gosubStack[b_gosubSP++]=61; goto b_L5600;
b_ret61: ;
		b_gosubStack[b_gosubSP++]=62; goto b_L5670;
b_ret62: ;
		b_v_txi=(20);
		b_v_tyi=(3);
		b_v_ts=b_keep(b_lit("AXE    :",8));
		b_v_cli=b_v_tci;
		b_gosubStack[b_gosubSP++]=63; goto b_L5050;
b_ret63: ;
		b_v_txi=((b_v_txi)+((8)));
		b_v_ts=b_keep(b_v_tns);
		b_gosubStack[b_gosubSP++]=64; goto b_L5050;
b_ret64: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_tns))));
		b_v_ts=b_keep(b_strs((breal_t)(b_v_dai)));
		b_gosubStack[b_gosubSP++]=65; goto b_L5050;
b_ret65: ;
		/* line 3055 */
b_L3055: ;
		b_v_tli=b_v_pki;
		b_gosubStack[b_gosubSP++]=66; goto b_L5600;
b_ret66: ;
		b_gosubStack[b_gosubSP++]=67; goto b_L5670;
b_ret67: ;
		b_v_txi=(20);
		b_v_tyi=(4);
		b_v_ts=b_keep(b_lit("PICKAXE:",8));
		b_v_cli=b_v_tci;
		b_gosubStack[b_gosubSP++]=68; goto b_L5050;
b_ret68: ;
		b_v_txi=((b_v_txi)+((8)));
		b_v_ts=b_keep(b_v_tns);
		b_gosubStack[b_gosubSP++]=69; goto b_L5050;
b_ret69: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_tns))));
		b_v_ts=b_keep(b_strs((breal_t)(b_v_dpi)));
		b_gosubStack[b_gosubSP++]=70; goto b_L5050;
b_ret70: ;
		/* line 3065 */
b_L3065: ;
		b_v_txi=(1);
		b_v_tyi=(22);
		b_v_ts=b_keep(b_lit("C=CRAFT   I/Q=CLOSE",19));
		b_v_cli=(3);
		b_gosubStack[b_gosubSP++]=71; goto b_L5050;
b_ret71: ;
		/* line 3070 */
b_L3070: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		/* line 3075 */
b_L3075: ;
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L3070; }
		/* line 3080 */
b_L3080: ;
		if(-(b_strcmp(b_v_ks,b_lit("C",1)) == 0)){
			b_gosubStack[b_gosubSP++]=72; goto b_L4000;
b_ret72: ;
			goto b_return;
		}
		/* line 3085 */
b_L3085: ;
		if(-(b_strcmp(b_v_ks,b_lit("I",1)) == 0)){ goto b_L3100; }
		/* line 3090 */
b_L3090: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){ goto b_L3100; }
		/* line 3095 */
b_L3095: ;
		goto b_L3070;
		/* line 3100 */
b_L3100: ;
		b_poke((53281.0),(6));
		b_gosubStack[b_gosubSP++]=73; goto b_L5060;
b_ret73: ;
		b_gosubStack[b_gosubSP++]=74; goto b_L1000;
b_ret74: ;
		b_v_msi=(9);
		b_gosubStack[b_gosubSP++]=75; goto b_L6000;
b_ret75: ;
		goto b_return;
		/* line 4000 */
b_L4000: ;
		/* line 4005 */
b_L4005: ;
		b_putc(147);
		b_nl();
		b_gosubStack[b_gosubSP++]=76; goto b_L5060;
b_ret76: ;
		b_poke((53281.0),(0));
		/* line 4008 */
b_L4008: ;
		b_v_cms=b_keep(b_lit("READY",5));
		b_gosubStack[b_gosubSP++]=77; goto b_L4100;
b_ret77: ;
		b_gosubStack[b_gosubSP++]=78; goto b_L4600;
b_ret78: ;
		/* line 4010 */
b_L4010: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		/* line 4015 */
b_L4015: ;
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L4010; }
		/* line 4020 */
b_L4020: ;
		if(-(b_strcmp(b_v_ks,b_lit("C",1)) == 0)){ goto b_L4500; }
		/* line 4025 */
b_L4025: ;
		if(-(b_strcmp(b_v_ks,b_lit("I",1)) == 0)){ goto b_L4500; }
		/* line 4030 */
b_L4030: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){ goto b_L4500; }
		/* line 4035 */
b_L4035: ;
		b_v_ai=b_asc(b_v_ks);
		if(-((b_v_ai) >= ((49)))){
			if(-((b_v_ai) <= ((57)))){
				b_v_rpi=((b_v_ai)-((48)));
				b_gosubStack[b_gosubSP++]=79; goto b_L5200;
b_ret79: ;
				goto b_L4055;
			}
		}
		/* line 4040 */
b_L4040: ;
		if(-(b_strcmp(b_v_ks,b_lit("0",1)) == 0)){
			b_v_rpi=(10);
			b_gosubStack[b_gosubSP++]=80; goto b_L5200;
b_ret80: ;
			goto b_L4055;
		}
		/* line 4045 */
b_L4045: ;
		if(-(b_strcmp(b_v_ks,b_lit("D",1)) == 0)){
			b_v_rpi=(11);
			b_gosubStack[b_gosubSP++]=81; goto b_L5200;
b_ret81: ;
			goto b_L4055;
		}
		/* line 4050 */
b_L4050: ;
		goto b_L4010;
		/* line 4055 */
b_L4055: ;
		if(-(b_strcmp(b_v_mks,b_lit("*",1)) == 0)){
			b_gosubStack[b_gosubSP++]=82; goto b_L4600;
b_ret82: ;
			goto b_L4010;
		}
		/* line 4056 */
b_L4056: ;
		b_gosubStack[b_gosubSP++]=83; goto b_L4800;
b_ret83: ;
		goto b_L4010;
		/* line 4100 */
b_L4100: ;
		/* line 4110 */
b_L4110: ;
		b_v_txi=(11);
		b_v_tyi=(0);
		b_v_ts=b_keep(b_lit("*** CRAFTING ***",16));
		b_v_cli=(7);
		b_gosubStack[b_gosubSP++]=84; goto b_L5050;
b_ret84: ;
		/* line 4120 */
b_L4120: ;
		b_v_txi=(0);
		b_v_tyi=(3);
		b_v_ts=b_keep(b_lit("K ITEM          COST     OK",27));
		b_v_cli=(3);
		b_gosubStack[b_gosubSP++]=85; goto b_L5050;
b_ret85: ;
		/* line 4130 */
b_L4130: ;
		b_v_txi=(0);
		b_v_tyi=(23);
		b_v_ts=b_keep(b_lit("1-9,0,D CRAFT  C/I/Q DONE",25));
		b_v_cli=(3);
		b_gosubStack[b_gosubSP++]=86; goto b_L5050;
b_ret86: ;
		/* line 4140 */
b_L4140: ;
		b_v_ri=(1);
		if(b_v_ri > 11) goto b_f19_e;
b_f19_t: ;
		/* line 4145 */
b_L4145: ;
		b_v_kas=b_keep(b_strs((breal_t)(b_v_ri)));
		if(-((b_v_ri) == ((10)))){
			b_v_kas=b_keep(b_lit("0",1));
		}
		/* line 4146 */
b_L4146: ;
		if(-((b_v_ri) == ((11)))){
			b_v_kas=b_keep(b_lit("D",1));
		}
		/* line 4150 */
b_L4150: ;
		b_v_rpi=b_v_ri;
		b_gosubStack[b_gosubSP++]=87; goto b_L5500;
b_ret87: ;
		b_v_mdi=b_a_rmi[B_INT(b_v_rpi)];
		b_gosubStack[b_gosubSP++]=88; goto b_L5700;
b_ret88: ;
		/* line 4155 */
b_L4155: ;
		b_v_txi=(0);
		b_v_tyi=(((3))+(b_v_ri));
		b_v_ts=b_keep(b_v_kas);
		b_v_cli=(12);
		b_gosubStack[b_gosubSP++]=89; goto b_L5050;
b_ret89: ;
		/* line 4160 */
b_L4160: ;
		b_v_txi=(2);
		b_v_ts=b_keep(b_v_ns);
		b_gosubStack[b_gosubSP++]=90; goto b_L5050;
b_ret90: ;
		/* line 4170 */
b_L4170: ;
		b_v_txi=(16);
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((0)))){
			b_v_ts=b_keep(b_strs((breal_t)(b_a_rci[B_INT(b_v_rpi)])));
			b_gosubStack[b_gosubSP++]=91; goto b_L5000;
b_ret91: ;
			b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
			b_v_ts=b_keep(b_v_mas);
			b_gosubStack[b_gosubSP++]=92; goto b_L5000;
b_ret92: ;
			b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_mas))));
			b_v_ts=b_keep(b_lit("->",2));
			b_gosubStack[b_gosubSP++]=93; goto b_L5000;
b_ret93: ;
			b_v_txi=((b_v_txi)+((2)));
			b_v_ts=b_keep(b_strs((breal_t)(b_a_ryi[B_INT(b_v_rpi)])));
			b_gosubStack[b_gosubSP++]=94; goto b_L5000;
b_ret94: ;
			b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
			b_v_ts=b_keep(b_lit("S",1));
			b_gosubStack[b_gosubSP++]=95; goto b_L5000;
b_ret95: ;
			goto b_L4190;
		}
		/* line 4185 */
b_L4185: ;
		b_v_ts=b_keep(b_strs((breal_t)(b_a_rci[B_INT(b_v_rpi)])));
		b_gosubStack[b_gosubSP++]=96; goto b_L5000;
b_ret96: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_v_mas);
		b_gosubStack[b_gosubSP++]=97; goto b_L5000;
b_ret97: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_mas))));
		b_v_ts=b_keep(b_lit("+",1));
		b_gosubStack[b_gosubSP++]=98; goto b_L5000;
b_ret98: ;
		b_v_txi=((b_v_txi)+((1)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_rki[B_INT(b_v_rpi)])));
		b_gosubStack[b_gosubSP++]=99; goto b_L5000;
b_ret99: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit("S",1));
		b_gosubStack[b_gosubSP++]=100; goto b_L5000;
b_ret100: ;
		/* line 4190 */
b_L4190: ;
		b_v_ri += 1;
		if(b_v_ri <= 11) goto b_f19_t;
b_f19_e: ;
		/* line 4195 */
b_L4195: ;
		goto b_return;
		/* line 4500 */
b_L4500: ;
		b_poke((53281.0),(6));
		b_gosubStack[b_gosubSP++]=101; goto b_L5060;
b_ret101: ;
		b_gosubStack[b_gosubSP++]=102; goto b_L1000;
b_ret102: ;
		b_v_msi=(9);
		b_gosubStack[b_gosubSP++]=103; goto b_L6000;
b_ret103: ;
		goto b_return;
		/* line 4600 */
b_L4600: ;
		/* line 4610 */
b_L4610: ;
		b_gosubStack[b_gosubSP++]=104; goto b_L4700;
b_ret104: ;
		/* line 4620 */
b_L4620: ;
		b_v_ri=(1);
		if(b_v_ri > 11) goto b_f20_e;
b_f20_t: ;
		/* line 4630 */
b_L4630: ;
		b_v_rpi=b_v_ri;
		b_gosubStack[b_gosubSP++]=105; goto b_L5800;
b_ret105: ;
		/* line 4635 */
b_L4635: ;
		b_v_cli=(12);
		if(-(b_strcmp(b_v_mks,b_lit("*",1)) == 0)){
			b_v_cli=(5);
		}
		/* line 4640 */
b_L4640: ;
		b_v_ji=(0);
		if(b_v_ji > 25) goto b_f21_e;
		b_v_M8=(((((3))+(b_v_ri)))*((40)));
		b_t_13=(((((55296.0))+(b_v_M8)))+(b_v_ji));
b_f21_t: ;
		b_poke(b_t_13,b_v_cli);
		b_t_13 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 25) goto b_f21_t;
b_f21_e: ;
		/* line 4645 */
b_L4645: ;
		b_v_txi=(25);
		b_v_tyi=(((3))+(b_v_ri));
		b_v_ts=b_keep(b_v_mks);
		b_gosubStack[b_gosubSP++]=106; goto b_L5000;
b_ret106: ;
		/* line 4650 */
b_L4650: ;
		b_v_ri += 1;
		if(b_v_ri <= 11) goto b_f20_t;
b_f20_e: ;
		/* line 4655 */
b_L4655: ;
		b_gosubStack[b_gosubSP++]=107; goto b_L4800;
b_ret107: ;
		/* line 4660 */
b_L4660: ;
		goto b_return;
		/* line 4700 */
b_L4700: ;
		/* line 4710 */
b_L4710: ;
		b_v_sai=(1104);
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f22_e;
		b_t_14=((b_v_sai)+(b_v_ji));
b_f22_t: ;
		b_poke(b_t_14,(32));
		b_t_14 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f22_t;
b_f22_e: ;
		/* line 4720 */
b_L4720: ;
		b_v_txi=(0);
		b_v_tyi=(2);
		b_v_ts=b_keep(b_lit("W",1));
		b_gosubStack[b_gosubSP++]=108; goto b_L5000;
b_ret108: ;
		b_v_txi=((b_v_txi)+((1)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((0))])));
		b_gosubStack[b_gosubSP++]=109; goto b_L5000;
b_ret109: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit(" S",2));
		b_gosubStack[b_gosubSP++]=110; goto b_L5000;
b_ret110: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((1))])));
		b_gosubStack[b_gosubSP++]=111; goto b_L5000;
b_ret111: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit(" I",2));
		b_gosubStack[b_gosubSP++]=112; goto b_L5000;
b_ret112: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((2))])));
		b_gosubStack[b_gosubSP++]=113; goto b_L5000;
b_ret113: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit(" G",2));
		b_gosubStack[b_gosubSP++]=114; goto b_L5000;
b_ret114: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((3))])));
		b_gosubStack[b_gosubSP++]=115; goto b_L5000;
b_ret115: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit(" D",2));
		b_gosubStack[b_gosubSP++]=116; goto b_L5000;
b_ret116: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((5))])));
		b_gosubStack[b_gosubSP++]=117; goto b_L5000;
b_ret117: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		b_v_ts=b_keep(b_lit(" ST",3));
		b_gosubStack[b_gosubSP++]=118; goto b_L5000;
b_ret118: ;
		b_v_txi=((b_v_txi)+((3)));
		b_v_ts=b_keep(b_strs((breal_t)(b_a_ini[B_INT((4))])));
		b_gosubStack[b_gosubSP++]=119; goto b_L5000;
b_ret119: ;
		/* line 4725 */
b_L4725: ;
		b_v_lii=b_v_txi;
		b_v_ji=(0);
		b_fl_23=((b_v_lii)-((1)));
		if(b_v_ji > b_fl_23) goto b_f23_e;
		b_t_15=(((((55296.0))+((80))))+(b_v_ji));
b_f23_t: ;
		b_poke(b_t_15,(1));
		b_t_15 += 1;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_23)) goto b_f23_t;
b_f23_e: ;
		/* line 4730 */
b_L4730: ;
		goto b_return;
		/* line 4800 */
b_L4800: ;
		/* line 4810 */
b_L4810: ;
		b_v_sai=(1704);
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f24_e;
		b_t_16=((b_v_sai)+(b_v_ji));
b_f24_t: ;
		b_poke(b_t_16,(32));
		b_t_16 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f24_t;
b_f24_e: ;
		/* line 4820 */
b_L4820: ;
		b_v_txi=(0);
		b_v_tyi=(17);
		b_v_ts=b_keep(b_v_cms);
		b_v_cli=(7);
		b_gosubStack[b_gosubSP++]=120; goto b_L5050;
b_ret120: ;
		/* line 4830 */
b_L4830: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5005 */
b_L5005: ;
		if(-(b_strcmp(b_v_ts,b_lit("",0)) == 0)){ goto b_L5030; }
		/* line 5006 */
b_L5006: ;
		b_v_ii=(1);
		b_fl_25=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_25) goto b_f25_e;
		b_v_M9=(((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi));
		b_t_17=((((b_v_M9)+(b_v_ii)))-((1)));
b_f25_t: ;
		/* line 5010 */
b_L5010: ;
		b_v_qzi=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 5015 */
b_L5015: ;
		if(-((b_v_qzi) >= ((64)))){
			if(-((b_v_qzi) <= ((95)))){
				b_v_qzi=((b_v_qzi)-((64)));
			}
		}
		/* line 5020 */
b_L5020: ;
		b_poke(b_t_17,b_v_qzi);
		/* line 5025 */
b_L5025: ;
		b_t_17 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_25)) goto b_f25_t;
b_f25_e: ;
		/* line 5030 */
b_L5030: ;
		goto b_return;
		/* line 5050 */
b_L5050: ;
		/* line 5055 */
b_L5055: ;
		b_gosubStack[b_gosubSP++]=121; goto b_L5000;
b_ret121: ;
		/* line 5056 */
b_L5056: ;
		b_v_lii=B_INT(b_len(b_v_ts));
		if(-((b_v_lii) == ((0)))){ goto b_L5058; }
		/* line 5057 */
b_L5057: ;
		b_v_ji=(0);
		b_fl_26=((b_v_lii)-((1)));
		if(b_v_ji > b_fl_26) goto b_f26_e;
		b_v_M10=((b_v_tyi)*((40)));
		b_t_18=(((((((55296.0))+(b_v_M10)))+(b_v_txi)))+(b_v_ji));
b_f26_t: ;
		b_poke(b_t_18,b_v_cli);
		b_t_18 += 1;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_26)) goto b_f26_t;
b_f26_e: ;
		/* line 5058 */
b_L5058: ;
		goto b_return;
		/* line 5060 */
b_L5060: ;
		/* line 5065 */
b_L5065: ;
		b_v_ii=(0);
		if(b_v_ii > 999) goto b_f27_e;
b_f27_t: ;
		b_poke((((55296.0))+(b_v_ii)),(14));
		b_v_ii += 1;
		if(b_v_ii <= 999) goto b_f27_t;
b_f27_e: ;
		/* line 5068 */
b_L5068: ;
		goto b_return;
		/* line 5200 */
b_L5200: ;
		/* line 5205 */
b_L5205: ;
		b_gosubStack[b_gosubSP++]=122; goto b_L5800;
b_ret122: ;
		/* line 5210 */
b_L5210: ;
		if(-(b_strcmp(b_v_mks,b_lit("*",1)) == 0)){ goto b_L5250; }
		/* line 5215 */
b_L5215: ;
		b_v_cms=b_keep(b_lit("NEED MATERIALS",14));
		goto b_return;
		/* line 5250 */
b_L5250: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((0)))){
			b_a_ini[B_INT((0))]=((b_a_ini[B_INT((0))])-(b_a_rci[B_INT(b_v_rpi)]));
			b_a_ini[B_INT((4))]=((b_a_ini[B_INT((4))])+(b_a_ryi[B_INT(b_v_rpi)]));
			b_v_cms=b_keep(b_lit("+STICK",6));
			goto b_return;
		}
		/* line 5255 */
b_L5255: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((1)))){
			b_v_gmi=b_a_rmi[B_INT(b_v_rpi)];
			b_a_ini[B_INT(b_v_gmi)]=((b_a_ini[B_INT(b_v_gmi)])-(b_a_rci[B_INT(b_v_rpi)]));
			b_a_ini[B_INT((4))]=((b_a_ini[B_INT((4))])-(b_a_rki[B_INT(b_v_rpi)]));
			b_v_axi=b_a_rai[B_INT(b_v_rpi)];
			b_v_dai=b_a_dli[B_INT(b_a_rai[B_INT(b_v_rpi)])];
			b_v_cms=b_keep(b_lit("+AXE",4));
			goto b_return;
		}
		/* line 5260 */
b_L5260: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((2)))){
			b_v_gmi=b_a_rmi[B_INT(b_v_rpi)];
			b_a_ini[B_INT(b_v_gmi)]=((b_a_ini[B_INT(b_v_gmi)])-(b_a_rci[B_INT(b_v_rpi)]));
			b_a_ini[B_INT((4))]=((b_a_ini[B_INT((4))])-(b_a_rki[B_INT(b_v_rpi)]));
			b_v_pki=b_a_rai[B_INT(b_v_rpi)];
			b_v_dpi=b_a_dli[B_INT(b_a_rai[B_INT(b_v_rpi)])];
			b_v_cms=b_keep(b_lit("+PICK",5));
			goto b_return;
		}
		/* line 5265 */
b_L5265: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5505 */
b_L5505: ;
		switch(b_v_rpi){
			case 1: goto b_L5510; break;
			case 2: goto b_L5520; break;
			case 3: goto b_L5530; break;
			case 4: goto b_L5540; break;
			case 5: goto b_L5550; break;
			case 6: goto b_L5560; break;
			case 7: goto b_L5570; break;
			case 8: goto b_L5580; break;
			case 9: goto b_L5590; break;
			case 10: goto b_L5595; break;
			case 11: goto b_L5597; break;
			default: break;}
		/* line 5510 */
b_L5510: ;
		b_v_ns=b_keep(b_lit("STICK",5));
		goto b_return;
		/* line 5520 */
b_L5520: ;
		b_v_ns=b_keep(b_lit("WOOD AXE",8));
		goto b_return;
		/* line 5530 */
b_L5530: ;
		b_v_ns=b_keep(b_lit("WOOD PICK",9));
		goto b_return;
		/* line 5540 */
b_L5540: ;
		b_v_ns=b_keep(b_lit("STONE AXE",9));
		goto b_return;
		/* line 5550 */
b_L5550: ;
		b_v_ns=b_keep(b_lit("STONE PICK",10));
		goto b_return;
		/* line 5560 */
b_L5560: ;
		b_v_ns=b_keep(b_lit("IRON AXE",8));
		goto b_return;
		/* line 5570 */
b_L5570: ;
		b_v_ns=b_keep(b_lit("IRON PICK",9));
		goto b_return;
		/* line 5580 */
b_L5580: ;
		b_v_ns=b_keep(b_lit("GOLD AXE",8));
		goto b_return;
		/* line 5590 */
b_L5590: ;
		b_v_ns=b_keep(b_lit("GOLD PICK",9));
		goto b_return;
		/* line 5595 */
b_L5595: ;
		b_v_ns=b_keep(b_lit("DIAMOND AXE",11));
		goto b_return;
		/* line 5597 */
b_L5597: ;
		b_v_ns=b_keep(b_lit("DIAMOND PICK",12));
		goto b_return;
		/* line 5600 */
b_L5600: ;
		/* line 5605 */
b_L5605: ;
		switch(((b_v_tli)+((1)))){
			case 1: goto b_L5615; break;
			case 2: goto b_L5625; break;
			case 3: goto b_L5635; break;
			case 4: goto b_L5645; break;
			case 5: goto b_L5655; break;
			case 6: goto b_L5665; break;
			default: break;}
		/* line 5615 */
b_L5615: ;
		b_v_tns=b_keep(b_lit("NONE",4));
		goto b_return;
		/* line 5625 */
b_L5625: ;
		b_v_tns=b_keep(b_lit("WOOD",4));
		goto b_return;
		/* line 5635 */
b_L5635: ;
		b_v_tns=b_keep(b_lit("STONE",5));
		goto b_return;
		/* line 5645 */
b_L5645: ;
		b_v_tns=b_keep(b_lit("IRON",4));
		goto b_return;
		/* line 5655 */
b_L5655: ;
		b_v_tns=b_keep(b_lit("GOLD",4));
		goto b_return;
		/* line 5665 */
b_L5665: ;
		b_v_tns=b_keep(b_lit("DIAMOND",7));
		goto b_return;
		/* line 5670 */
b_L5670: ;
		/* line 5675 */
b_L5675: ;
		switch(((b_v_tli)+((1)))){
			case 1: goto b_L5680; break;
			case 2: goto b_L5681; break;
			case 3: goto b_L5682; break;
			case 4: goto b_L5683; break;
			case 5: goto b_L5684; break;
			case 6: goto b_L5685; break;
			default: break;}
		/* line 5680 */
b_L5680: ;
		b_v_tci=(11);
		goto b_return;
		/* line 5681 */
b_L5681: ;
		b_v_tci=(9);
		goto b_return;
		/* line 5682 */
b_L5682: ;
		b_v_tci=(12);
		goto b_return;
		/* line 5683 */
b_L5683: ;
		b_v_tci=(14);
		goto b_return;
		/* line 5684 */
b_L5684: ;
		b_v_tci=(7);
		goto b_return;
		/* line 5685 */
b_L5685: ;
		b_v_tci=(1);
		goto b_return;
		/* line 5686 */
b_L5686: ;
		/* line 5687 */
b_L5687: ;
		switch(((b_v_tti)+((1)))){
			case 1: goto b_L5688; break;
			case 2: goto b_L5689; break;
			case 3: goto b_L5691; break;
			case 4: goto b_L5692; break;
			case 5: goto b_L5693; break;
			case 6: goto b_L5694; break;
			default: break;}
		/* line 5688 */
b_L5688: ;
		b_v_trs=b_keep(b_lit("GRASS",5));
		goto b_return;
		/* line 5689 */
b_L5689: ;
		b_v_trs=b_keep(b_lit("FOREST",6));
		goto b_return;
		/* line 5691 */
b_L5691: ;
		b_v_trs=b_keep(b_lit("STONE",5));
		goto b_return;
		/* line 5692 */
b_L5692: ;
		b_v_trs=b_keep(b_lit("IRON",4));
		goto b_return;
		/* line 5693 */
b_L5693: ;
		b_v_trs=b_keep(b_lit("GOLD",4));
		goto b_return;
		/* line 5694 */
b_L5694: ;
		b_v_trs=b_keep(b_lit("DIAMOND",7));
		goto b_return;
		/* line 5700 */
b_L5700: ;
		/* line 5705 */
b_L5705: ;
		switch(((b_v_mdi)+((1)))){
			case 1: goto b_L5715; break;
			case 2: goto b_L5725; break;
			case 3: goto b_L5735; break;
			case 4: goto b_L5745; break;
			case 5: goto b_L5745; break;
			case 6: goto b_L5765; break;
			default: break;}
		/* line 5715 */
b_L5715: ;
		b_v_mas=b_keep(b_lit("W",1));
		goto b_return;
		/* line 5725 */
b_L5725: ;
		b_v_mas=b_keep(b_lit("S",1));
		goto b_return;
		/* line 5735 */
b_L5735: ;
		b_v_mas=b_keep(b_lit("I",1));
		goto b_return;
		/* line 5745 */
b_L5745: ;
		b_v_mas=b_keep(b_lit("G",1));
		goto b_return;
		/* line 5765 */
b_L5765: ;
		b_v_mas=b_keep(b_lit("D",1));
		goto b_return;
		/* line 5800 */
b_L5800: ;
		/* line 5805 */
b_L5805: ;
		b_v_mks=b_keep(b_lit("-",1));
		b_v_oki=(0);
		/* line 5810 */
b_L5810: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((0)))){
			b_v_oki=(1);
		}
		/* line 5815 */
b_L5815: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((1)))){
			if(-((b_a_rai[B_INT(b_v_rpi)]) > (b_v_axi))){
				b_v_oki=(1);
			}
		}
		/* line 5820 */
b_L5820: ;
		if(-((b_a_rti[B_INT(b_v_rpi)]) == ((2)))){
			if(-((b_a_rai[B_INT(b_v_rpi)]) > (b_v_pki))){
				b_v_oki=(1);
			}
		}
		/* line 5825 */
b_L5825: ;
		if(-((b_v_oki) == ((0)))){
			goto b_return;
		}
		/* line 5830 */
b_L5830: ;
		b_v_gmi=b_a_rmi[B_INT(b_v_rpi)];
		if(-((b_a_ini[B_INT(b_v_gmi)]) < (b_a_rci[B_INT(b_v_rpi)]))){
			goto b_return;
		}
		/* line 5835 */
b_L5835: ;
		if(-((b_a_ini[B_INT((4))]) < (b_a_rki[B_INT(b_v_rpi)]))){
			goto b_return;
		}
		/* line 5840 */
b_L5840: ;
		b_v_mks=b_keep(b_lit("*",1));
		/* line 5845 */
b_L5845: ;
		goto b_return;
		/* line 6000 */
b_L6000: ;
		/* line 6005 */
b_L6005: ;
		b_v_sts=b_keep(b_lit("",0));
		/* line 6010 */
b_L6010: ;
		if(-((b_v_msi) == ((0)))){ goto b_L6200; }
		/* line 6015 */
b_L6015: ;
		switch(b_v_msi){
			case 1: goto b_L6020; break;
			case 2: goto b_L6030; break;
			case 3: goto b_L6040; break;
			case 4: goto b_L6050; break;
			case 5: goto b_L6060; break;
			case 6: goto b_L6070; break;
			case 7: goto b_L6080; break;
			case 8: goto b_L6090; break;
			case 9: goto b_L6100; break;
			case 10: goto b_L6110; break;
			case 11: goto b_L6120; break;
			case 12: goto b_L6130; break;
			case 13: goto b_L6140; break;
			case 14: goto b_L6150; break;
			case 15: goto b_L6160; break;
			case 16: goto b_L6165; break;
			case 17: goto b_L6170; break;
			case 18: goto b_L6175; break;
			case 19: goto b_L6180; break;
			default: break;}
		/* line 6020 */
b_L6020: ;
		b_v_sts=b_keep(b_lit("+WOOD",5));
		goto b_L6200;
		/* line 6030 */
b_L6030: ;
		b_v_sts=b_keep(b_lit("+STONE",6));
		goto b_L6200;
		/* line 6040 */
b_L6040: ;
		b_v_sts=b_keep(b_lit("+IRON",5));
		goto b_L6200;
		/* line 6050 */
b_L6050: ;
		b_v_sts=b_keep(b_lit("+GOLD",5));
		goto b_L6200;
		/* line 6060 */
b_L6060: ;
		b_v_sts=b_keep(b_lit("NEED PICKAXE",12));
		goto b_L6200;
		/* line 6070 */
b_L6070: ;
		b_v_sts=b_keep(b_lit("NEED STONE PICK",15));
		goto b_L6200;
		/* line 6080 */
b_L6080: ;
		b_v_sts=b_keep(b_lit("NEED IRON PICK",14));
		goto b_L6200;
		/* line 6090 */
b_L6090: ;
		b_v_sts=b_keep(b_lit("NOTHING HERE",12));
		goto b_L6200;
		/* line 6100 */
b_L6100: ;
		b_v_sts=b_keep(b_lit("WASD MOVE  BUMP/HARVEST  I INV  C CRAFT",39));
		goto b_L6200;
		/* line 6110 */
b_L6110: ;
		b_v_sts=b_keep(b_lit("BLOCKED - HARVEST WITH E",24));
		goto b_L6200;
		/* line 6120 */
b_L6120: ;
		b_v_sts=b_keep(b_lit("FOREST",6));
		goto b_L6200;
		/* line 6130 */
b_L6130: ;
		b_v_sts=b_keep(b_lit("STONE",5));
		goto b_L6200;
		/* line 6140 */
b_L6140: ;
		b_v_sts=b_keep(b_lit("IRON",4));
		goto b_L6200;
		/* line 6150 */
b_L6150: ;
		b_v_sts=b_keep(b_lit("GOLD",4));
		goto b_L6200;
		/* line 6160 */
b_L6160: ;
		b_v_sts=b_keep(b_lit("DIAMOND",7));
		goto b_L6200;
		/* line 6165 */
b_L6165: ;
		b_v_sts=b_keep(b_lit("PICK BROKE",10));
		goto b_L6200;
		/* line 6170 */
b_L6170: ;
		b_v_sts=b_keep(b_lit("AXE BROKE",9));
		goto b_L6200;
		/* line 6175 */
b_L6175: ;
		b_v_sts=b_keep(b_lit("+DIAMOND",8));
		goto b_L6200;
		/* line 6180 */
b_L6180: ;
		b_v_sts=b_keep(b_lit("NEED GOLD PICK",14));
		/* line 6200 */
b_L6200: ;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f28_e;
b_f28_t: ;
		b_poke((((1984))+(b_v_ii)),(32));
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f28_t;
b_f28_e: ;
		/* line 6202 */
b_L6202: ;
		b_v_txi=(0);
		b_v_tyi=(24);
		b_v_ts=b_keep(b_lit("HU",2));
		b_gosubStack[b_gosubSP++]=123; goto b_L5000;
b_ret123: ;
		b_v_vi=b_v_hui;
		b_v_txi=(2);
		b_gosubStack[b_gosubSP++]=124; goto b_L6500;
b_ret124: ;
		/* line 6203 */
b_L6203: ;
		b_v_txi=(5);
		b_v_ts=b_keep(b_lit(" HP",3));
		b_gosubStack[b_gosubSP++]=125; goto b_L5000;
b_ret125: ;
		b_v_vi=b_v_hpi;
		b_v_txi=(8);
		b_gosubStack[b_gosubSP++]=126; goto b_L6500;
b_ret126: ;
		/* line 6204 */
b_L6204: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_txi=(11);
			b_v_ts=b_keep(b_lit(" DEMO",5));
			b_gosubStack[b_gosubSP++]=127; goto b_L5000;
b_ret127: ;
		}
		/* line 6209 */
b_L6209: ;
		goto b_return;
		/* line 6300 */
b_L6300: ;
		/* line 6305 */
b_L6305: ;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f29_e;
b_f29_t: ;
		b_poke((((1984))+(b_v_ii)),(32));
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f29_t;
b_f29_e: ;
		/* line 6310 */
b_L6310: ;
		b_v_txi=(0);
		b_v_tyi=(24);
		b_v_ts=b_keep(b_v_trs);
		b_gosubStack[b_gosubSP++]=128; goto b_L5000;
b_ret128: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_trs))));
		/* line 6320 */
b_L6320: ;
		b_v_ts=b_keep(b_strs((breal_t)(b_v_mpi)));
		b_gosubStack[b_gosubSP++]=129; goto b_L5000;
b_ret129: ;
		b_v_txi=((b_v_txi)+(B_INT(b_len(b_v_ts))));
		/* line 6330 */
b_L6330: ;
		b_v_ts=b_keep(b_lit("/",1));
		b_gosubStack[b_gosubSP++]=130; goto b_L5000;
b_ret130: ;
		b_v_txi=((b_v_txi)+((1)));
		/* line 6340 */
b_L6340: ;
		b_v_ts=b_keep(b_strs((breal_t)(b_v_hmi)));
		b_gosubStack[b_gosubSP++]=131; goto b_L5000;
b_ret131: ;
		/* line 6342 */
b_L6342: ;
		b_v_txi=(20);
		b_v_ts=b_keep(b_lit("HU",2));
		b_gosubStack[b_gosubSP++]=132; goto b_L5000;
b_ret132: ;
		b_v_vi=b_v_hui;
		b_v_txi=(22);
		b_gosubStack[b_gosubSP++]=133; goto b_L6500;
b_ret133: ;
		/* line 6343 */
b_L6343: ;
		b_v_txi=(25);
		b_v_ts=b_keep(b_lit(" HP",3));
		b_gosubStack[b_gosubSP++]=134; goto b_L5000;
b_ret134: ;
		b_v_vi=b_v_hpi;
		b_v_txi=(28);
		b_gosubStack[b_gosubSP++]=135; goto b_L6500;
b_ret135: ;
		/* line 6370 */
b_L6370: ;
		goto b_return;
		/* line 6400 */
b_L6400: ;
		/* line 6410 */
b_L6410: ;
		if(-((b_v_oji) < ((0)))){
			goto b_return;
		}
		/* line 6420 */
b_L6420: ;
		b_poke((((((1024))+(((b_v_oji)*((40))))))+(b_v_oji)),b_v_ogi);
		/* line 6430 */
b_L6430: ;
		b_v_oji=(-10000);
		/* line 6440 */
b_L6440: ;
		goto b_return;
		/* line 6500 */
b_L6500: ;
		/* line 6505 */
b_L6505: ;
		b_v_d2i=b_int(((breal_t)(b_v_vi)/(breal_t)((100))));
		b_v_ri=((b_v_vi)-(((b_v_d2i)*((100)))));
		b_v_d1i=b_int(((breal_t)(b_v_ri)/(breal_t)((10))));
		b_v_d0i=((b_v_ri)-(((b_v_d1i)*((10)))));
		/* line 6506 */
b_L6506: ;
		b_v_c2i=(((48))+(b_v_d2i));
		b_v_c1i=(((48))+(b_v_d1i));
		b_v_c0i=(((48))+(b_v_d0i));
		if(-((b_v_d2i) == ((0)))){
			b_v_c2i=(32);
			if(-((b_v_d1i) == ((0)))){
				b_v_c1i=(32);
			}
		}
		/* line 6508 */
b_L6508: ;
		b_poke((((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi)),b_v_c2i);
		b_poke((((((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi)))+((1))),b_v_c1i);
		b_poke((((((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi)))+((2))),b_v_c0i);
		/* line 6509 */
b_L6509: ;
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7005 */
b_L7005: ;
		b_v_ii=(1);
		if(b_v_ii > 11) goto b_f30_e;
b_f30_t: ;
		/* line 7010 */
b_L7010: ;
		b_v_u0i=b_read_int();
		b_v_u1i=b_read_int();
		b_v_u2i=b_read_int();
		b_v_u3i=b_read_int();
		b_v_u4i=b_read_int();
		b_v_u5i=b_read_int();
		/* line 7015 */
b_L7015: ;
		b_a_rti[B_INT(b_v_ii)]=b_v_u0i;
		b_a_rai[B_INT(b_v_ii)]=b_v_u1i;
		b_a_rmi[B_INT(b_v_ii)]=b_v_u2i;
		b_a_rci[B_INT(b_v_ii)]=b_v_u3i;
		b_a_rki[B_INT(b_v_ii)]=b_v_u4i;
		b_a_ryi[B_INT(b_v_ii)]=b_v_u5i;
		/* line 7020 */
b_L7020: ;
		b_v_ii += 1;
		if(b_v_ii <= 11) goto b_f30_t;
b_f30_e: ;
		/* line 7025 */
b_L7025: ;
		goto b_return;
		/* line 7030 */
b_L7030: ;
		/* line 7035 */
b_L7035: ;
		/* line 7040 */
b_L7040: ;
		/* line 7045 */
b_L7045: ;
		/* line 7050 */
b_L7050: ;
		/* line 7055 */
b_L7055: ;
		/* line 7060 */
b_L7060: ;
		/* line 7065 */
b_L7065: ;
		/* line 7070 */
b_L7070: ;
		/* line 7075 */
b_L7075: ;
		/* line 7080 */
b_L7080: ;
		/* line 7100 */
b_L7100: ;
		/* line 7105 */
b_L7105: ;
		b_a_cti[B_INT((0))]=(32);
		b_a_cti[B_INT((1))]=(32);
		b_a_cti[B_INT((2))]=(32);
		b_a_cti[B_INT((3))]=(32);
		b_a_cti[B_INT((4))]=(32);
		b_a_cti[B_INT((5))]=(32);
		/* line 7106 */
b_L7106: ;
		b_a_cti[B_INT((6))]=(42);
		b_a_cti[B_INT((7))]=(42);
		b_a_cti[B_INT((8))]=(42);
		b_a_cti[B_INT((9))]=(42);
		/* line 7107 */
b_L7107: ;
		b_a_cti[B_INT((10))]=(129);
		b_a_cti[B_INT((11))]=(129);
		b_a_cti[B_INT((12))]=(129);
		/* line 7108 */
b_L7108: ;
		b_a_cti[B_INT((13))]=(32);
		b_a_cti[B_INT((14))]=(32);
		b_a_cti[B_INT((15))]=(32);
		/* line 7110 */
b_L7110: ;
		b_a_oti[B_INT((0))]=(36);
		b_a_oti[B_INT((1))]=(43);
		b_a_oti[B_INT((2))]=(43);
		b_a_oti[B_INT((3))]=(35);
		b_a_oti[B_INT((4))]=(35);
		b_a_oti[B_INT((5))]=(35);
		b_a_oti[B_INT((6))]=(35);
		b_a_oti[B_INT((7))]=(35);
		/* line 7112 */
b_L7112: ;
		b_a_tci[B_INT((0))]=(32);
		b_a_tci[B_INT((1))]=(42);
		b_a_tci[B_INT((2))]=(35);
		b_a_tci[B_INT((3))]=(43);
		b_a_tci[B_INT((4))]=(36);
		/* line 7113 */
b_L7113: ;
		b_v_ii=(0);
		if(b_v_ii > 37) goto b_f31_e;
b_f31_t: ;
		b_a_tli[B_INT(b_v_ii)]=(46);
		b_v_ii += 1;
		if(b_v_ii <= 37) goto b_f31_t;
b_f31_e: ;
		/* line 7114 */
b_L7114: ;
		b_v_ii=(38);
		if(b_v_ii > 43) goto b_f32_e;
b_f32_t: ;
		b_a_tli[B_INT(b_v_ii)]=(42);
		b_v_ii += 1;
		if(b_v_ii <= 43) goto b_f32_t;
b_f32_e: ;
		/* line 7115 */
b_L7115: ;
		b_v_ii=(44);
		if(b_v_ii > 49) goto b_f33_e;
b_f33_t: ;
		b_a_tli[B_INT(b_v_ii)]=(35);
		b_v_ii += 1;
		if(b_v_ii <= 49) goto b_f33_t;
b_f33_e: ;
		/* line 7116 */
b_L7116: ;
		b_v_ii=(50);
		if(b_v_ii > 55) goto b_f34_e;
b_f34_t: ;
		b_a_tli[B_INT(b_v_ii)]=(43);
		b_v_ii += 1;
		if(b_v_ii <= 55) goto b_f34_t;
b_f34_e: ;
		/* line 7117 */
b_L7117: ;
		b_v_ii=(56);
		if(b_v_ii > 60) goto b_f35_e;
b_f35_t: ;
		b_a_tli[B_INT(b_v_ii)]=(36);
		b_v_ii += 1;
		if(b_v_ii <= 60) goto b_f35_t;
b_f35_e: ;
		/* line 7118 */
b_L7118: ;
		goto b_return;
		/* line 7200 */
b_L7200: ;
		/* line 7205 */
b_L7205: ;
		b_v_ii=(0);
		if(b_v_ii > 63) goto b_f36_e;
b_f36_t: ;
		b_v_u0i=b_read_int();
		b_a_sli[B_INT(b_v_ii)]=b_v_u0i;
		b_v_ii += 1;
		if(b_v_ii <= 63) goto b_f36_t;
b_f36_e: ;
		/* line 7210 */
b_L7210: ;
		goto b_return;
		/* line 7220 */
b_L7220: ;
		/* line 7225 */
b_L7225: ;
		/* line 7230 */
b_L7230: ;
		/* line 7235 */
b_L7235: ;
		/* line 7300 */
b_L7300: ;
		/* line 7305 */
b_L7305: ;
		b_v_ii=(0);
		if(b_v_ii > 5) goto b_f37_e;
b_f37_t: ;
		b_v_u0i=b_read_int();
		b_a_dli[B_INT(b_v_ii)]=b_v_u0i;
		b_v_ii += 1;
		if(b_v_ii <= 5) goto b_f37_t;
b_f37_e: ;
		/* line 7310 */
b_L7310: ;
		b_v_ii=(0);
		if(b_v_ii > 5) goto b_f38_e;
b_f38_t: ;
		b_v_u0i=b_read_int();
		b_a_hbi[B_INT(b_v_ii)]=b_v_u0i;
		b_v_ii += 1;
		if(b_v_ii <= 5) goto b_f38_t;
b_f38_e: ;
		/* line 7315 */
b_L7315: ;
		goto b_return;
		/* line 7320 */
b_L7320: ;
		/* line 7325 */
b_L7325: ;
		/* line 7800 */
b_L7800: ;
		/* line 7805 */
b_L7805: ;
		b_v_tti=(0);
		if(-((b_v_hti) < ((38)))){
			goto b_return;
		}
		/* line 7810 */
b_L7810: ;
		b_v_tti=(1);
		if(-((b_v_hti) < ((44)))){
			goto b_return;
		}
		/* line 7815 */
b_L7815: ;
		b_v_tti=(2);
		if(-((b_v_hti) < ((50)))){
			goto b_return;
		}
		/* line 7820 */
b_L7820: ;
		b_v_tti=(3);
		if(-((b_v_hti) < ((56)))){
			goto b_return;
		}
		/* line 7825 */
b_L7825: ;
		b_v_tti=(4);
		goto b_return;
		/* line 8000 */
b_L8000: ;
		/* line 8005 */
b_L8005: ;
		b_v_hti=((((((b_a_sli[B_INT((B_INT(((b_v_ixi)*((3)))) & B_INT((63))))])+(b_a_sli[B_INT((B_INT(((b_v_iyi)*((4)))) & B_INT((63))))])))+(b_a_sli[B_INT((B_INT(((((b_v_ixi)+(b_v_iyi)))*((2)))) & B_INT((63))))])))+((30)));
		/* line 8010 */
b_L8010: ;
		goto b_return;
		/* line 8300 */
b_L8300: ;
		/* line 8305 */
b_L8305: ;
		b_putc(147);
		b_nl();
		/* line 8310 */
b_L8310: ;
		b_v_txi=(16);
		b_v_tyi=(0);
		b_v_ts=b_keep(b_lit("MINIMA",6));
		b_gosubStack[b_gosubSP++]=136; goto b_L5000;
b_ret136: ;
		/* line 8315 */
b_L8315: ;
		b_v_txi=(8);
		b_v_tyi=(2);
		b_v_ts=b_keep(b_lit("W/A/S/D MOVE  E HARVEST",23));
		b_gosubStack[b_gosubSP++]=137; goto b_L5000;
b_ret137: ;
		/* line 8320 */
b_L8320: ;
		b_v_txi=(8);
		b_v_tyi=(3);
		b_v_ts=b_keep(b_lit("I INVENTORY  C CRAFT",20));
		b_gosubStack[b_gosubSP++]=138; goto b_L5000;
b_ret138: ;
		/* line 8325 */
b_L8325: ;
		b_v_txi=(6);
		b_v_tyi=(4);
		b_v_ts=b_keep(b_lit("EAT BY HARVESTING  STAY FED",27));
		b_gosubStack[b_gosubSP++]=139; goto b_L5000;
b_ret139: ;
		/* line 8330 */
b_L8330: ;
		b_v_txi=(8);
		b_v_tyi=(5);
		b_v_ts=b_keep(b_lit("SPACE TO PLAY  D=DEMO",21));
		b_gosubStack[b_gosubSP++]=140; goto b_L5000;
b_ret140: ;
		/* line 8335 */
b_L8335: ;
		b_v_gdi=(1);
		if(b_v_gdi > 200) goto b_f39_e;
		{ b_rtfor_t _f; _f.top_id=39; _f.pI=&b_v_gdi; _f.vtype=1; _f.lim.i=200; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f39_t: ;
		/* line 8337 */
b_L8337: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 8340 */
b_L8340: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 8345 */
b_L8345: ;
		if(-((b_v_ki) == ((18)))){
			b_v_dmi=(1);
			goto b_L8390;
		}
		/* line 8350 */
b_L8350: ;
		if(-((b_v_ki) != ((64)))){
			b_v_dmi=(0);
			goto b_L8390;
		}
		/* line 8355 */
b_L8355: ;
		b_v_gdi += 1;
		if(b_v_gdi <= 200) goto b_f39_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f39_e: ;
		/* line 8360 */
b_L8360: ;
		b_v_dmi=(1);
		/* line 8390 */
b_L8390: ;
		b_putc(147);
		b_nl();
		/* line 8395 */
b_L8395: ;
		goto b_return;
		/* line 8400 */
b_L8400: ;
		/* line 8405 */
b_L8405: ;
		b_v_ki=(64);
		/* line 8408 */
b_L8408: ;
		if(-((b_v_hui) < ((50)))){
			b_v_ki=(14);
			goto b_return;
		}
		/* line 8410 */
b_L8410: ;
		if(-((b_rnd(B_INT((1)))) < ((0.30000000004656613)))){
			b_v_ki=(14);
			goto b_return;
		}
		/* line 8415 */
b_L8415: ;
		b_v_rri=b_int(((b_rnd(B_INT((1))))*((4))));
		/* line 8420 */
b_L8420: ;
		if(-((b_v_rri) == ((0)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 8425 */
b_L8425: ;
		if(-((b_v_rri) == ((1)))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 8430 */
b_L8430: ;
		if(-((b_v_rri) == ((2)))){
			b_v_ki=(13);
			goto b_return;
		}
		/* line 8435 */
b_L8435: ;
		b_v_ki=(18);
		goto b_return;
		/* line 9000 */
b_L9000: ;
		/* line 9005 */
b_L9005: ;
		b_putc(147);
		b_nl();
		/* line 9006 */
b_L9006: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=141; goto b_L9100;
b_ret141: ;
			goto b_return;
		}
		/* line 9010 */
b_L9010: ;
		b_v_txi=(12);
		b_v_tyi=(10);
		b_v_ts=b_keep(b_lit("*** GAME OVER ***",17));
		b_gosubStack[b_gosubSP++]=142; goto b_L5000;
b_ret142: ;
		/* line 9015 */
b_L9015: ;
		b_v_txi=(12);
		b_v_tyi=(12);
		b_v_ts=b_keep(b_lit("R=RESTART  Q=QUIT",17));
		b_gosubStack[b_gosubSP++]=143; goto b_L5000;
b_ret143: ;
		/* line 9020 */
b_L9020: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L9020; }
		/* line 9025 */
b_L9025: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			b_gosubStack[b_gosubSP++]=144; goto b_L9100;
b_ret144: ;
			goto b_return;
		}
		/* line 9030 */
b_L9030: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 9035 */
b_L9035: ;
		goto b_L9020;
		/* line 9100 */
b_L9100: ;
		/* line 9102 */
b_L9102: ;
		b_v_ii=(0);
		if(b_v_ii > 5) goto b_f40_e;
b_f40_t: ;
		b_a_ini[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 5) goto b_f40_t;
b_f40_e: ;
		/* line 9104 */
b_L9104: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f41_e;
b_f41_t: ;
		b_a_mxi[B_INT(b_v_ii)]=(-10000);
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f41_t;
b_f41_e: ;
		/* line 9106 */
b_L9106: ;
		b_v_pxi=(0);
		b_v_pyi=(0);
		b_v_dxi=(0);
		b_v_dyi=(-1);
		b_v_axi=(0);
		b_v_pki=(0);
		b_v_mii=(0);
		b_v_moi=(0);
		b_v_dai=(0);
		b_v_dpi=(0);
		b_v_pgi=(30);
		b_v_mpi=(0);
		b_v_qai=(-10000);
		b_v_qbi=(-10000);
		b_v_oji=(-10000);
		b_v_hui=(100);
		b_v_hpi=(100);
		b_v_sci=(0);
		/* line 9108 */
b_L9108: ;
		b_v_sxi=(20);
		b_v_syi=(12);
		b_v_vxi=(-20);
		b_v_vyi=(-12);
		b_v_lxi=(-10000);
		b_v_lyi=(-10000);
		/* line 9110 */
b_L9110: ;
		b_gosubStack[b_gosubSP++]=145; goto b_L1000;
b_ret145: ;
		b_v_msi=(9);
		b_gosubStack[b_gosubSP++]=146; goto b_L6000;
b_ret146: ;
		/* line 9114 */
b_L9114: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			case 54: goto b_ret54;
			case 55: goto b_ret55;
			case 56: goto b_ret56;
			case 57: goto b_ret57;
			case 58: goto b_ret58;
			case 59: goto b_ret59;
			case 60: goto b_ret60;
			case 61: goto b_ret61;
			case 62: goto b_ret62;
			case 63: goto b_ret63;
			case 64: goto b_ret64;
			case 65: goto b_ret65;
			case 66: goto b_ret66;
			case 67: goto b_ret67;
			case 68: goto b_ret68;
			case 69: goto b_ret69;
			case 70: goto b_ret70;
			case 71: goto b_ret71;
			case 72: goto b_ret72;
			case 73: goto b_ret73;
			case 74: goto b_ret74;
			case 75: goto b_ret75;
			case 76: goto b_ret76;
			case 77: goto b_ret77;
			case 78: goto b_ret78;
			case 79: goto b_ret79;
			case 80: goto b_ret80;
			case 81: goto b_ret81;
			case 82: goto b_ret82;
			case 83: goto b_ret83;
			case 84: goto b_ret84;
			case 85: goto b_ret85;
			case 86: goto b_ret86;
			case 87: goto b_ret87;
			case 88: goto b_ret88;
			case 89: goto b_ret89;
			case 90: goto b_ret90;
			case 91: goto b_ret91;
			case 92: goto b_ret92;
			case 93: goto b_ret93;
			case 94: goto b_ret94;
			case 95: goto b_ret95;
			case 96: goto b_ret96;
			case 97: goto b_ret97;
			case 98: goto b_ret98;
			case 99: goto b_ret99;
			case 100: goto b_ret100;
			case 101: goto b_ret101;
			case 102: goto b_ret102;
			case 103: goto b_ret103;
			case 104: goto b_ret104;
			case 105: goto b_ret105;
			case 106: goto b_ret106;
			case 107: goto b_ret107;
			case 108: goto b_ret108;
			case 109: goto b_ret109;
			case 110: goto b_ret110;
			case 111: goto b_ret111;
			case 112: goto b_ret112;
			case 113: goto b_ret113;
			case 114: goto b_ret114;
			case 115: goto b_ret115;
			case 116: goto b_ret116;
			case 117: goto b_ret117;
			case 118: goto b_ret118;
			case 119: goto b_ret119;
			case 120: goto b_ret120;
			case 121: goto b_ret121;
			case 122: goto b_ret122;
			case 123: goto b_ret123;
			case 124: goto b_ret124;
			case 125: goto b_ret125;
			case 126: goto b_ret126;
			case 127: goto b_ret127;
			case 128: goto b_ret128;
			case 129: goto b_ret129;
			case 130: goto b_ret130;
			case 131: goto b_ret131;
			case 132: goto b_ret132;
			case 133: goto b_ret133;
			case 134: goto b_ret134;
			case 135: goto b_ret135;
			case 136: goto b_ret136;
			case 137: goto b_ret137;
			case 138: goto b_ret138;
			case 139: goto b_ret139;
			case 140: goto b_ret140;
			case 141: goto b_ret141;
			case 142: goto b_ret142;
			case 143: goto b_ret143;
			case 144: goto b_ret144;
			case 145: goto b_ret145;
			case 146: goto b_ret146;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
