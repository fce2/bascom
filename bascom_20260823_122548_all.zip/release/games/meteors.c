/* OPTIMIZE_C -- meteors.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static bint_t b_a_wri[8];
static int b_a_wci[8];
static int b_a_wwi[8];
static int b_a_whi[8];
static int b_a_swi[7];
static int b_a_shi[7];
static int b_a_gti[30];
static int b_a_sbi[7];
static int b_a_gbi[8];
static int b_v_ni;
static int b_v_xi;
static breal_t b_v_sf;
static int b_v_lvi;
static int b_v_dli;
static breal_t b_v_scf;
static int b_v_hti;
static int b_v_pwi;
static breal_t b_v_spf;
static breal_t b_v_mrf;
static breal_t b_v_gcf;
static int b_v_hci;
static bint_t b_v_dmi;
static int b_v_pdi;
static int b_v_gfi;
static bint_t b_v_ci;
static int b_v_gwi;
static bint_t b_v_ryi;
static bstr_t b_v_as;
static int b_v_d0i;
static breal_t b_v_tf;
static bint_t b_v_d1i;
static bint_t b_v_d2i;
static breal_t b_v_d3f;
static breal_t b_v_d4f;
static breal_t b_v_t1f;
static breal_t b_v_t2f;
static int b_v_rri;
static int b_v_ii;
static bint_t b_v_ki;
static int b_v_sfi;
static int b_v_pi;
static int b_v_cxi;
static int b_v_edi;
static int b_v_eti;
static int b_v_bri;
static int b_v_chi;
static int b_v_jti;
static int b_v_jli;
static int b_v_jri;
static int b_v_ji;
static bint_t b_v_kri;
static breal_t b_v_mcf;
static int b_v_zi;
static breal_t b_v_pcf;
static breal_t b_v_drf;
static int b_v_dni;
static breal_t b_v_mtf;
static breal_t b_v_mdf;
static int b_v_ri;
static int b_v_bai;
static int b_v_M0;
static int b_v_M1;
static bint_t b_v_M2;
static int b_v_M3;
static bint_t b_v_M4;
static int b_v_M5;
static bint_t b_v_M6;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_fl_6;
static int b_fl_8;
static int b_fl_9;
static int b_fl_10;
static bint_t b_fl_12;
static int b_fl_14;
static int b_fl_18;
static bint_t b_fl_20;
static bint_t b_fl_21;
static bint_t b_fl_23;
static bint_t b_fl_28;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		b_putc(147);
		b_nl();
		/* line 30 */
b_L30: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f0_e;
b_f0_t: ;
		b_a_wri[B_INT(b_v_ni)]=(-1);
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f0_t;
b_f0_e: ;
		/* line 40 */
b_L40: ;
		b_v_xi=(20);
		b_v_sf=(0);
		b_v_lvi=(3);
		b_v_dli=(200);
		b_v_scf=(0);
		b_v_hti=(0);
		b_v_pwi=(1);
		b_v_spf=(0.34999999997671694);
		b_v_mrf=(0);
		b_v_gcf=(99);
		b_v_hci=(20);
		b_v_dmi=(1);
		b_v_pdi=(0);
		b_v_gfi=(0);
		/* line 50 */
b_L50: ;
		b_putc(19);
		b_nl();
		/* line 60 */
b_L60: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 70 */
b_L70: ;
		b_v_ci=(0);
		if(b_v_ci > 27) goto b_f1_e;
b_f1_t: ;
		b_poke((((55296.0))+(b_v_ci)),(1));
		b_v_ci += 1;
		if(b_v_ci <= 27) goto b_f1_t;
b_f1_e: ;
		b_v_ci=(6);
		if(b_v_ci > 10) goto b_f2_e;
b_f2_t: ;
		b_poke((((55296.0))+(b_v_ci)),(7));
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f2_t;
b_f2_e: ;
		b_poke((((55296.0))+((18))),(7));
		b_poke((((55296.0))+((26))),(7));
		b_poke((((55296.0))+((27))),(7));
		/* line 80 */
b_L80: ;
		b_poke((1024),(19));
		b_poke((1025),(3));
		b_poke((1026),(15));
		b_poke((1027),(18));
		b_poke((1028),(5));
		b_poke((1029),(32));
		/* line 90 */
b_L90: ;
		b_poke((1036),(12));
		b_poke((1037),(9));
		b_poke((1038),(22));
		b_poke((1039),(5));
		b_poke((1040),(19));
		b_poke((1041),(32));
		/* line 100 */
b_L100: ;
		b_poke((1043),(32));
		b_poke((1044),(14));
		b_poke((1045),(5));
		b_poke((1046),(24));
		b_poke((1047),(20));
		b_poke((1048),(32));
		/* line 110 */
b_L110: ;
		b_poke((650),(128));
		b_gosubStack[b_gosubSP++]=0; goto b_L2500;
b_ret0: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L1000;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L1100;
b_ret2: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1200;
b_ret3: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1600;
b_ret4: ;
		/* line 120 */
b_L120: ;
		b_v_gcf=((b_v_gcf)-((1)));
		b_v_gwi=(0);
		/* line 130 */
b_L130: ;
		if(-((b_v_gcf) <= ((0)))){
			b_v_gcf=(99);
			b_v_pwi=((b_v_pwi)+((1)));
			if(-((b_v_pwi) > ((6)))){
				b_v_pwi=(6);
				b_v_gwi=(1);
			}
		}
		/* line 140 */
b_L140: ;
		if(-((b_v_xi) > ((((40))-(b_v_pwi))))){
			b_v_xi=(((40))-(b_v_pwi));
		}
		/* line 150 */
b_L150: ;
		if(-((b_v_gwi) > ((0)))){
			b_gosubStack[b_gosubSP++]=5; goto b_L1500;
b_ret5: ;
			b_gosubStack[b_gosubSP++]=6; goto b_L1600;
b_ret6: ;
			b_v_gfi=(4);
		}
		/* line 160 */
b_L160: ;
		b_v_mrf=((b_v_mrf)+((1)));
		if(-((b_v_mrf) >= ((1200)))){
			b_v_mrf=(0);
			b_v_spf=((b_v_spf)+((0.050000000002910383)));
			if(-((b_v_spf) > ((0.85000000009313226)))){
				b_v_spf=(0.85000000009313226);
			}
		}
		/* line 170 */
b_L170: ;
		b_gosubStack[b_gosubSP++]=7; goto b_L1400;
b_ret7: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L1300;
b_ret8: ;
		/* line 180 */
b_L180: ;
		b_v_hti=(0);
		/* line 190 */
b_L190: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f3_e;
b_f3_t: ;
		/* line 200 */
b_L200: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) < ((0)))){ goto b_L270; }
		/* line 210 */
b_L210: ;
		b_a_wri[B_INT(b_v_ni)]=((b_a_wri[B_INT(b_v_ni)])+((1)));
		/* line 220 */
b_L220: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) < ((24)))){
			b_v_ryi=b_a_wri[B_INT(b_v_ni)];
			b_gosubStack[b_gosubSP++]=9; goto b_L2100;
b_ret9: ;
		}
		/* line 230 */
b_L230: ;
		b_v_ryi=((b_a_wri[B_INT(b_v_ni)])-(b_a_whi[B_INT(b_v_ni)]));
		if(-((b_v_ryi) >= ((1)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L2000;
b_ret10: ;
		}
		/* line 240 */
b_L240: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) < ((24)))){ goto b_L270; }
		/* line 250 */
b_L250: ;
		if(-((b_a_wci[B_INT(b_v_ni)]) < (((b_v_xi)+(b_v_pwi))))){
			if(-((((b_a_wci[B_INT(b_v_ni)])+(b_a_wwi[B_INT(b_v_ni)]))) > (b_v_xi))){
				b_v_hti=(1);
				b_v_hci=b_a_wci[B_INT(b_v_ni)];
			}
		}
		/* line 260 */
b_L260: ;
		b_v_ryi=((((b_a_wri[B_INT(b_v_ni)])-(b_a_whi[B_INT(b_v_ni)])))+((1)));
		if(b_v_ryi > 23) goto b_f4_e;
b_f4_t: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L2000;
b_ret11: ;
		b_v_ryi += 1;
		if(b_v_ryi <= 23) goto b_f4_t;
b_f4_e: ;
		b_a_wri[B_INT(b_v_ni)]=(-1);
		/* line 270 */
b_L270: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f3_t;
b_f3_e: ;
		/* line 280 */
b_L280: ;
		if(-((b_v_hti) > ((0)))){ goto b_L330; }
		/* line 290 */
b_L290: ;
		if(-((b_rnd(B_INT((1)))) < (b_v_spf))){
			b_gosubStack[b_gosubSP++]=12; goto b_L2200;
b_ret12: ;
		}
		/* line 300 */
b_L300: ;
		b_v_sf=((b_v_sf)+((1)));
		b_v_scf=((b_v_scf)+((1)));
		/* line 310 */
b_L310: ;
		if(-((b_v_scf) >= ((100)))){
			b_v_scf=(0);
			if(-((b_v_dli) > ((100)))){
				b_v_dli=((b_v_dli)-((150)));
			}
		}
		/* line 320 */
b_L320: ;
		goto b_L380;
		/* line 330 */
b_L330: ;
		b_v_lvi=((b_v_lvi)-((1)));
		b_gosubStack[b_gosubSP++]=13; goto b_L1100;
b_ret13: ;
		/* line 340 */
b_L340: ;
		if(-((b_v_lvi) <= ((0)))){ goto b_L430; }
		/* line 350 */
b_L350: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f5_e;
b_f5_t: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) >= ((0)))){
			b_v_ryi=((((b_a_wri[B_INT(b_v_ni)])-(b_a_whi[B_INT(b_v_ni)])))+((1)));
			b_fl_6=b_a_wri[B_INT(b_v_ni)];
			if(b_v_ryi > b_fl_6) goto b_f6_e;
b_f6_t: ;
			b_gosubStack[b_gosubSP++]=14; goto b_L2000;
b_ret14: ;
			b_v_ryi += 1;
			if(b_v_ryi <= (b_fl_6)) goto b_f6_t;
b_f6_e: ;
		}
		/* line 360 */
b_L360: ;
		b_a_wri[B_INT(b_v_ni)]=(-1);
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f5_t;
b_f5_e: ;
		/* line 370 */
b_L370: ;
		b_gosubStack[b_gosubSP++]=15; goto b_L1900;
b_ret15: ;
		/* line 380 */
b_L380: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L1000;
b_ret16: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L1200;
b_ret17: ;
		/* line 390 */
b_L390: ;
		if(-((b_v_gfi) > ((0)))){
			b_v_gfi=((b_v_gfi)-((1)));
			b_poke((53280.0),(7));
			goto b_L410;
		}
		/* line 400 */
b_L400: ;
		b_poke((53280.0),(0));
		/* line 410 */
b_L410: ;
		goto b_L120;
		/* line 420 */
b_L420: ;
		goto b_L120;
		/* line 430 */
b_L430: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=18; goto b_L1900;
b_ret18: ;
			b_poke((53280.0),(0));
			b_gosubStack[b_gosubSP++]=19; goto b_L2400;
b_ret19: ;
			goto b_L120;
		}
		/* line 440 */
b_L440: ;
		b_poke((53280.0),(2));
		b_putc(147);
		b_nl();
		/* line 450 */
b_L450: ;
		b_nl();
		b_nl();
		{ bstr_t _t=b_lit("    *** GAME OVER ***",21); b_str(_t.p,_t.len); }
		b_nl();
		b_nl();
		/* line 460 */
b_L460: ;
		{ bstr_t _t=b_lit("    SCORE:",10); b_str(_t.p,_t.len); }
		b_putint((bint_t)(b_v_sf));
		b_nl();
		b_nl();
		{ bstr_t _t=b_lit("    R=RESTART  Q=QUIT",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 470 */
b_L470: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_as,b_lit("R",1)) == 0)){
			b_poke((53280.0),(0));
			b_gosubStack[b_gosubSP++]=20; goto b_L2400;
b_ret20: ;
			goto b_L120;
		}
		/* line 480 */
b_L480: ;
		if(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 490 */
b_L490: ;
		goto b_L470;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_d0i=b_int((b_v_sf/(breal_t)((10000))));
		b_v_tf=((b_v_sf)-(((b_v_d0i)*((10000)))));
		/* line 1002 */
b_L1002: ;
		b_v_d1i=b_int((b_v_tf/(breal_t)((1000))));
		b_v_tf=((b_v_tf)-(((b_v_d1i)*((1000)))));
		/* line 1003 */
b_L1003: ;
		b_v_d2i=b_int((b_v_tf/(breal_t)((100))));
		b_v_tf=((b_v_tf)-(((b_v_d2i)*((100)))));
		/* line 1004 */
b_L1004: ;
		b_v_d3f=b_int((b_v_tf/(breal_t)((10))));
		b_v_d4f=((b_v_tf)-(((b_v_d3f)*((10)))));
		/* line 1005 */
b_L1005: ;
		b_poke((1030),(((48))+(b_v_d0i)));
		b_poke((1031),(((48))+(b_v_d1i)));
		b_poke((1032),(((48))+(b_v_d2i)));
		b_poke((1033),(((48))+(b_v_d3f)));
		b_poke((1034),(((48))+(b_v_d4f)));
		/* line 1006 */
b_L1006: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
			goto b_L1008;
		}
		/* line 1007 */
b_L1007: ;
		b_poke((1060),(32));
		b_poke((1061),(32));
		b_poke((1062),(32));
		b_poke((1063),(32));
		b_poke((55332.0),(0));
		b_poke((55333.0),(0));
		b_poke((55334.0),(0));
		b_poke((55335.0),(0));
		/* line 1008 */
b_L1008: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_poke((1042),(((48))+(b_v_lvi)));
		/* line 1102 */
b_L1102: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_t1f=b_int((b_v_gcf/(breal_t)((10))));
		b_v_t2f=((b_v_gcf)-(((b_v_t1f)*((10)))));
		/* line 1202 */
b_L1202: ;
		b_poke((1049),(32));
		b_poke((1050),(((48))+(b_v_t1f)));
		b_poke((1051),(((48))+(b_v_t2f)));
		/* line 1203 */
b_L1203: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_v_rri=b_v_dli;
		/* line 1302 */
b_L1302: ;
		if(-((b_v_rri) < ((100)))){ goto b_L1305; }
		/* line 1303 */
b_L1303: ;
		b_v_ii=(1);
		if(b_v_ii > 100) goto b_f7_e;
b_f7_t: ;
		b_v_ii += 1;
		if(b_v_ii <= 100) goto b_f7_t;
b_f7_e: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L1200;
b_ret21: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L1400;
b_ret22: ;
		/* line 1304 */
b_L1304: ;
		b_v_rri=((b_v_rri)-((100)));
		goto b_L1302;
		/* line 1305 */
b_L1305: ;
		b_v_ii=(1);
		b_fl_8=b_v_rri;
		if(b_v_ii > b_fl_8) goto b_f8_e;
b_f8_t: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L1200;
b_ret23: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L1400;
b_ret24: ;
		/* line 1306 */
b_L1306: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 1402 */
b_L1402: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 1403 */
b_L1403: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 1404 */
b_L1404: ;
		if(-((b_v_ki) == ((7)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 1405 */
b_L1405: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) != ((64)))){
				b_v_dmi=(0);
				b_gosubStack[b_gosubSP++]=25; goto b_L2400;
b_ret25: ;
				goto b_L120;
			}
		}
		/* line 1406 */
b_L1406: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=26; goto b_L2300;
b_ret26: ;
		}
		/* line 1407 */
b_L1407: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((10)))){
				b_gosubStack[b_gosubSP++]=27; goto b_L1700;
b_ret27: ;
			}
		}
		/* line 1408 */
b_L1408: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((18)))){
				b_gosubStack[b_gosubSP++]=28; goto b_L1800;
b_ret28: ;
			}
		}
		/* line 1409 */
b_L1409: ;
		if(-((b_v_dmi) == ((1)))){
			goto b_return;
		}
		/* line 1410 */
b_L1410: ;
		if(-((b_v_ki) == ((10)))){
			b_gosubStack[b_gosubSP++]=29; goto b_L1700;
b_ret29: ;
		}
		/* line 1411 */
b_L1411: ;
		if(-((b_v_ki) == ((18)))){
			b_gosubStack[b_gosubSP++]=30; goto b_L1800;
b_ret30: ;
		}
		/* line 1412 */
b_L1412: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_pi=(0);
		b_fl_9=((b_v_pwi)-((1)));
		if(b_v_pi > b_fl_9) goto b_f9_e;
		b_v_M0=(((1984))+(b_v_xi));
		b_t_1=((b_v_M0)+(b_v_pi));
b_f9_t: ;
		b_poke(b_t_1,(32));
		b_t_1 += 1;
		b_v_pi += 1;
		if(b_v_pi <= (b_fl_9)) goto b_f9_t;
b_f9_e: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		b_v_pi=(0);
		b_fl_10=((b_v_pwi)-((1)));
		if(b_v_pi > b_fl_10) goto b_f10_e;
		b_v_M1=(((1984))+(b_v_xi));
		b_t_2=((b_v_M1)+(b_v_pi));
		b_t_3=(((((((55296.0))+((960))))+(b_v_xi)))+(b_v_pi));
b_f10_t: ;
		b_poke(b_t_2,(81));
		b_poke(b_t_3,(5));
		b_t_2 += 1;
		b_t_3 += 1;
		b_v_pi += 1;
		if(b_v_pi <= (b_fl_10)) goto b_f10_t;
b_f10_e: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		if(-((b_v_xi) > ((0)))){
			b_gosubStack[b_gosubSP++]=31; goto b_L1500;
b_ret31: ;
			b_v_xi=((b_v_xi)-((1)));
			b_gosubStack[b_gosubSP++]=32; goto b_L1600;
b_ret32: ;
		}
		/* line 1702 */
b_L1702: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		if(-((b_v_xi) < ((((40))-(b_v_pwi))))){
			b_gosubStack[b_gosubSP++]=33; goto b_L1500;
b_ret33: ;
			b_v_xi=((b_v_xi)+((1)));
			b_gosubStack[b_gosubSP++]=34; goto b_L1600;
b_ret34: ;
		}
		/* line 1802 */
b_L1802: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_cxi=b_v_hci;
		if(-((b_v_cxi) < ((0)))){
			b_v_cxi=(0);
		}
		/* line 1902 */
b_L1902: ;
		if(-((b_v_cxi) > ((39)))){
			b_v_cxi=(39);
		}
		/* line 1903 */
b_L1903: ;
		b_v_edi=(4000);
		b_v_eti=(6000);
		if(-((b_v_dmi) == ((1)))){
			b_v_edi=(200);
			b_v_eti=(300);
		}
		/* line 1904 */
b_L1904: ;
		b_v_bri=(1);
		if(b_v_bri > 6) goto b_f11_e;
b_f11_t: ;
		/* line 1905 */
b_L1905: ;
		b_v_chi=(42);
		if(-((b_v_bri) >= ((4)))){
			b_v_chi=(46);
		}
		/* line 1906 */
b_L1906: ;
		b_v_jti=(((24))-(b_v_bri));
		if(-((b_v_jti) < ((1)))){
			b_v_jti=(1);
		}
		/* line 1907 */
b_L1907: ;
		b_v_jli=((b_v_cxi)-(b_v_bri));
		if(-((b_v_jli) < ((0)))){
			b_v_jli=(0);
		}
		/* line 1908 */
b_L1908: ;
		b_v_jri=((b_v_cxi)+(b_v_bri));
		if(-((b_v_jri) > ((39)))){
			b_v_jri=(39);
		}
		/* line 1909 */
b_L1909: ;
		b_v_ci=b_v_jli;
		b_fl_12=b_v_jri;
		if(b_v_ci > b_fl_12) goto b_f12_e;
		b_t_4=(((1984))+(b_v_ci));
		b_t_5=(((((55296.0))+((960))))+(b_v_ci));
b_f12_t: ;
		b_poke(b_t_4,b_v_chi);
		b_poke(b_t_5,(2));
		b_t_4 += 1;
		b_t_5 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_12)) goto b_f12_t;
b_f12_e: ;
		/* line 1910 */
b_L1910: ;
		b_v_ki=b_v_jti;
		if(b_v_ki > 24) goto b_f13_e;
		b_t_6=(((((1024))+(((b_v_ki)*((40))))))+(b_v_cxi));
		b_t_7=(((((55296.0))+(((b_v_ki)*((40))))))+(b_v_cxi));
b_f13_t: ;
		b_poke(b_t_6,b_v_chi);
		b_poke(b_t_7,(2));
		b_t_6 += 40;
		b_t_7 += 40;
		b_v_ki += 1;
		if(b_v_ki <= 24) goto b_f13_t;
b_f13_e: ;
		/* line 1911 */
b_L1911: ;
		b_v_ii=(1);
		b_fl_14=b_v_edi;
		if(b_v_ii > b_fl_14) goto b_f14_e;
b_f14_t: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_14)) goto b_f14_t;
b_f14_e: ;
		/* line 1912 */
b_L1912: ;
		b_v_bri += 1;
		if(b_v_bri <= 6) goto b_f11_t;
b_f11_e: ;
		/* line 1913 */
b_L1913: ;
		b_v_ki=(1);
		if(b_v_ki > 23) goto b_f15_e;
		b_t_8=(((((1024))+(((b_v_ki)*((40))))))+(b_v_cxi));
b_f15_t: ;
		b_poke(b_t_8,(32));
		b_t_8 += 40;
		b_v_ki += 1;
		if(b_v_ki <= 23) goto b_f15_t;
b_f15_e: ;
		/* line 1914 */
b_L1914: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f16_e;
b_f16_t: ;
		b_poke((((1984))+(b_v_ci)),(32));
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f16_t;
b_f16_e: ;
		/* line 1915 */
b_L1915: ;
		b_gosubStack[b_gosubSP++]=35; goto b_L1600;
b_ret35: ;
		/* line 1916 */
b_L1916: ;
		b_v_ji=(1);
		if(b_v_ji > 15) goto b_f17_e;
b_f17_t: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		b_v_ji += 1;
		if(b_v_ji <= 15) goto b_f17_t;
b_f17_e: ;
		/* line 1917 */
b_L1917: ;
		b_v_ii=(1);
		b_fl_18=b_v_eti;
		if(b_v_ii > b_fl_18) goto b_f18_e;
b_f18_t: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_18)) goto b_f18_t;
b_f18_e: ;
		/* line 1918 */
b_L1918: ;
		b_v_ji=(1);
		if(b_v_ji > 15) goto b_f19_e;
b_f19_t: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		b_v_ji += 1;
		if(b_v_ji <= 15) goto b_f19_t;
b_f19_e: ;
		/* line 1919 */
b_L1919: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		if(-((b_v_ryi) < ((1)))){
			goto b_return;
		}
		/* line 2002 */
b_L2002: ;
		if(-((b_v_ryi) > ((23)))){
			goto b_return;
		}
		/* line 2003 */
b_L2003: ;
		b_v_ci=(0);
		b_fl_20=((b_a_wwi[B_INT(b_v_ni)])-((1)));
		if(b_v_ci > b_fl_20) goto b_f20_e;
		b_v_M2=(((1024))+(((b_v_ryi)*((40)))));
		b_v_M3=b_a_wci[B_INT(b_v_ni)];
		b_t_9=((((b_v_M2)+(b_v_M3)))+(b_v_ci));
b_f20_t: ;
		b_poke(b_t_9,(32));
		b_t_9 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_20)) goto b_f20_t;
b_f20_e: ;
		/* line 2004 */
b_L2004: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		if(-((b_v_ryi) < ((1)))){
			goto b_return;
		}
		/* line 2102 */
b_L2102: ;
		if(-((b_v_ryi) > ((23)))){
			goto b_return;
		}
		/* line 2103 */
b_L2103: ;
		b_v_ki=((((((b_v_ryi)-(b_a_wri[B_INT(b_v_ni)])))+(b_a_whi[B_INT(b_v_ni)])))-((1)));
		b_v_kri=((b_a_gbi[B_INT(b_v_ni)])+(((b_v_ki)*(b_a_wwi[B_INT(b_v_ni)]))));
		/* line 2104 */
b_L2104: ;
		b_v_ci=(0);
		b_fl_21=((b_a_wwi[B_INT(b_v_ni)])-((1)));
		if(b_v_ci > b_fl_21) goto b_f21_e;
		b_v_M4=(((1024))+(((b_v_ryi)*((40)))));
		b_v_M5=b_a_wci[B_INT(b_v_ni)];
		b_v_M6=((b_v_ryi)*((40)));
		b_t_10=((((b_v_M4)+(b_v_M5)))+(b_v_ci));
		b_t_11=(((((((55296.0))+(b_v_M6)))+(b_v_M5)))+(b_v_ci));
b_f21_t: ;
		b_v_mcf=b_a_gti[B_INT(((b_v_kri)+(b_v_ci)))];
		b_poke(b_t_10,b_v_mcf);
		b_poke(b_t_11,(8));
		b_t_10 += 1;
		b_t_11 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_21)) goto b_f21_t;
b_f21_e: ;
		/* line 2105 */
b_L2105: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f22_e;
b_f22_t: ;
		/* line 2202 */
b_L2202: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) >= ((0)))){ goto b_L2206; }
		/* line 2203 */
b_L2203: ;
		b_v_zi=b_int(((b_rnd(B_INT((1))))*((7))));
		b_a_wwi[B_INT(b_v_ni)]=b_a_swi[B_INT(b_v_zi)];
		b_a_whi[B_INT(b_v_ni)]=b_a_shi[B_INT(b_v_zi)];
		b_a_gbi[B_INT(b_v_ni)]=b_a_sbi[B_INT(b_v_zi)];
		/* line 2204 */
b_L2204: ;
		b_a_wci[B_INT(b_v_ni)]=b_int(((b_rnd(B_INT((1))))*((((41))-(b_a_wwi[B_INT(b_v_ni)])))));
		b_a_wri[B_INT(b_v_ni)]=b_a_whi[B_INT(b_v_ni)];
		b_v_ryi=(1);
		b_fl_23=b_a_whi[B_INT(b_v_ni)];
		if(b_v_ryi > b_fl_23) goto b_f23_e;
b_f23_t: ;
		b_gosubStack[b_gosubSP++]=36; goto b_L2100;
b_ret36: ;
		b_v_ryi += 1;
		if(b_v_ryi <= (b_fl_23)) goto b_f23_t;
b_f23_e: ;
		/* line 2205 */
b_L2205: ;
		goto b_return;
		/* line 2206 */
b_L2206: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f22_t;
b_f22_e: ;
		/* line 2207 */
b_L2207: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		b_v_ki=(64);
		/* line 2302 */
b_L2302: ;
		b_v_pcf=((b_v_xi)+(((breal_t)(b_v_pwi)/(breal_t)((2)))));
		/* line 2303 */
b_L2303: ;
		b_v_drf=(-1);
		b_v_dni=(-1);
		/* line 2304 */
b_L2304: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f24_e;
b_f24_t: ;
		/* line 2305 */
b_L2305: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) < ((0)))){ goto b_L2311; }
		/* line 2306 */
b_L2306: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) < ((15)))){ goto b_L2311; }
		/* line 2307 */
b_L2307: ;
		b_v_mtf=((b_a_wci[B_INT(b_v_ni)])+(((breal_t)(b_a_wwi[B_INT(b_v_ni)])/(breal_t)((2)))));
		/* line 2308 */
b_L2308: ;
		b_v_mdf=b_abs(((b_v_mtf)-(b_v_pcf)));
		/* line 2309 */
b_L2309: ;
		if(-((b_v_drf) < ((0)))){
			b_v_drf=b_v_mdf;
			b_v_dni=b_v_ni;
			goto b_L2311;
		}
		/* line 2310 */
b_L2310: ;
		if(-((b_v_mdf) < (b_v_drf))){
			b_v_drf=b_v_mdf;
			b_v_dni=b_v_ni;
		}
		/* line 2311 */
b_L2311: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f24_t;
b_f24_e: ;
		/* line 2312 */
b_L2312: ;
		if(-((b_v_drf) < ((0)))){ goto b_L2316; }
		/* line 2313 */
b_L2313: ;
		b_v_mcf=((b_a_wci[B_INT(b_v_dni)])+(((breal_t)(b_a_wwi[B_INT(b_v_dni)])/(breal_t)((2)))));
		/* line 2314 */
b_L2314: ;
		if(-((b_v_mcf) < (b_v_pcf))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 2315 */
b_L2315: ;
		b_v_ki=(10);
		goto b_return;
		/* line 2316 */
b_L2316: ;
		/* line 2317 */
b_L2317: ;
		if(-((b_v_pcf) < ((19)))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 2318 */
b_L2318: ;
		if(-((b_v_pcf) > ((21)))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 2319 */
b_L2319: ;
		b_v_ki=(64);
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f25_e;
b_f25_t: ;
		b_v_bai=(((1024))+(((b_v_ri)*((40)))));
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f26_e;
		b_t_15=((b_v_bai)+(b_v_ci));
b_f26_t: ;
		b_poke(b_t_15,(32));
		b_t_15 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f26_t;
b_f26_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f25_t;
b_f25_e: ;
		/* line 2402 */
b_L2402: ;
		b_gosubStack[b_gosubSP++]=37; goto b_L1500;
b_ret37: ;
		/* line 2403 */
b_L2403: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f27_e;
b_f27_t: ;
		if(-((b_a_wri[B_INT(b_v_ni)]) >= ((0)))){
			b_v_ryi=((((b_a_wri[B_INT(b_v_ni)])-(b_a_whi[B_INT(b_v_ni)])))+((1)));
			b_fl_28=b_a_wri[B_INT(b_v_ni)];
			if(b_v_ryi > b_fl_28) goto b_f28_e;
b_f28_t: ;
			b_gosubStack[b_gosubSP++]=38; goto b_L2000;
b_ret38: ;
			b_v_ryi += 1;
			if(b_v_ryi <= (b_fl_28)) goto b_f28_t;
b_f28_e: ;
		}
		/* line 2404 */
b_L2404: ;
		b_a_wri[B_INT(b_v_ni)]=(-1);
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f27_t;
b_f27_e: ;
		/* line 2405 */
b_L2405: ;
		b_v_xi=(20);
		b_v_sf=(0);
		b_v_lvi=(3);
		b_v_dli=(200);
		b_v_scf=(0);
		b_v_hti=(0);
		b_v_pwi=(1);
		b_v_spf=(0.34999999997671694);
		b_v_mrf=(0);
		b_v_gcf=(99);
		b_v_hci=(20);
		b_v_pdi=(0);
		b_v_gfi=(0);
		/* line 2406 */
b_L2406: ;
		b_gosubStack[b_gosubSP++]=39; goto b_L1000;
b_ret39: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L1100;
b_ret40: ;
		b_gosubStack[b_gosubSP++]=41; goto b_L1200;
b_ret41: ;
		b_gosubStack[b_gosubSP++]=42; goto b_L1600;
b_ret42: ;
		/* line 2407 */
b_L2407: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		b_a_swi[B_INT((0))]=(1);
		b_a_shi[B_INT((0))]=(1);
		b_a_swi[B_INT((1))]=(1);
		b_a_shi[B_INT((1))]=(2);
		b_a_swi[B_INT((2))]=(2);
		b_a_shi[B_INT((2))]=(1);
		/* line 2502 */
b_L2502: ;
		b_a_swi[B_INT((3))]=(2);
		b_a_shi[B_INT((3))]=(2);
		b_a_swi[B_INT((4))]=(3);
		b_a_shi[B_INT((4))]=(2);
		b_a_swi[B_INT((5))]=(2);
		b_a_shi[B_INT((5))]=(3);
		b_a_swi[B_INT((6))]=(3);
		b_a_shi[B_INT((6))]=(3);
		/* line 2503 */
b_L2503: ;
		b_a_sbi[B_INT((0))]=(0);
		b_a_sbi[B_INT((1))]=(1);
		b_a_sbi[B_INT((2))]=(3);
		b_a_sbi[B_INT((3))]=(5);
		b_a_sbi[B_INT((4))]=(9);
		b_a_sbi[B_INT((5))]=(15);
		b_a_sbi[B_INT((6))]=(21);
		/* line 2504 */
b_L2504: ;
		b_a_gti[B_INT((0))]=(87);
		b_a_gti[B_INT((1))]=(119);
		b_a_gti[B_INT((2))]=(121);
		b_a_gti[B_INT((3))]=(101);
		b_a_gti[B_INT((4))]=(225);
		/* line 2505 */
b_L2505: ;
		b_a_gti[B_INT((5))]=(126);
		b_a_gti[B_INT((6))]=(251);
		b_a_gti[B_INT((7))]=(236);
		b_a_gti[B_INT((8))]=(108);
		b_a_gti[B_INT((9))]=(126);
		b_a_gti[B_INT((10))]=(119);
		/* line 2506 */
b_L2506: ;
		b_a_gti[B_INT((11))]=(124);
		b_a_gti[B_INT((12))]=(123);
		b_a_gti[B_INT((13))]=(98);
		b_a_gti[B_INT((14))]=(108);
		b_a_gti[B_INT((15))]=(126);
		b_a_gti[B_INT((16))]=(124);
		/* line 2507 */
b_L2507: ;
		b_a_gti[B_INT((17))]=(101);
		b_a_gti[B_INT((18))]=(225);
		b_a_gti[B_INT((19))]=(123);
		b_a_gti[B_INT((20))]=(108);
		b_a_gti[B_INT((21))]=(126);
		b_a_gti[B_INT((22))]=(119);
		/* line 2508 */
b_L2508: ;
		b_a_gti[B_INT((23))]=(124);
		b_a_gti[B_INT((24))]=(97);
		b_a_gti[B_INT((25))]=(32);
		b_a_gti[B_INT((26))]=(225);
		b_a_gti[B_INT((27))]=(123);
		b_a_gti[B_INT((28))]=(98);
		b_a_gti[B_INT((29))]=(108);
		/* line 2509 */
b_L2509: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
