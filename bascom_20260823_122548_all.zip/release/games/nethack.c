/* OPTIMIZE_C -- nethack.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_rxi[13];
static int b_a_ryi[13];
static int b_a_rwi[13];
static int b_a_rhi[13];
static bint_t b_a_oxi[17];
static bint_t b_a_oyi[17];
static bint_t b_a_ohi[17];
static int b_a_oti[17];
static bint_t b_a_odi[17];
static bint_t b_a_ixi[17];
static bint_t b_a_iyi[17];
static bint_t b_a_iti[17];
static bint_t b_a_ivi[17];
static int b_a_obi[8];
static int b_a_oai[8];
static int b_a_oei[8];
static int b_a_oci[8];
static int b_a_osi[8];
static int b_a_ici[9];
static int b_a_opi[3];
static bint_t b_a_omi[3];
static int b_a_rci[12];
static bint_t b_a_kii[8];
static int b_v_twi;
static int b_v_tfi;
static int b_v_tsi;
static int b_v_tui;
static int b_v_tci;
static breal_t b_v_rsf;
static bint_t b_v_dei;
static bint_t b_v_hpi;
static bint_t b_v_mai;
static bint_t b_v_lei;
static bint_t b_v_xpi;
static bint_t b_v_goi;
static bint_t b_v_ati;
static int b_v_wei;
static bint_t b_v_ari;
static bint_t b_v_foi;
static bint_t b_v_spi;
static int b_v_poi;
static int b_v_pci;
static bint_t b_v_hti;
static bint_t b_v_fli;
static int b_v_gvi;
static bint_t b_v_pii;
static int b_v_phi;
static int b_v_ppi;
static bint_t b_v_fti;
static int b_v_msi;
static int b_v_mgi;
static bint_t b_v_ami;
static int b_v_mvi;
static bint_t b_v_cxi;
static int b_v_bci;
static int b_v_bfi;
static int b_v_ipi;
static int b_v_pui;
static bint_t b_v_sti;
static bint_t b_v_swi;
static bint_t b_v_hii;
static bint_t b_v_kti;
static bint_t b_v_ji;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_ti;
static int b_v_pyi;
static bint_t b_v_pxi;
static int b_v_shi;
static bint_t b_v_nxi;
static int b_v_nyi;
static bint_t b_v_mii;
static int b_v_nmi;
static int b_v_sni;
static bint_t b_v_hfi;
static bint_t b_v_gxi;
static bint_t b_v_wxi;
static bint_t b_v_vxi;
static bint_t b_v_gyi;
static bint_t b_v_wyi;
static bint_t b_v_vyi;
static int b_v_coi;
static bint_t b_v_qi;
static bint_t b_v_nii;
static bint_t b_v_sxi;
static bint_t b_v_syi;
static int b_v_ri;
static bint_t b_v_sai;
static int b_v_ci;
static int b_v_dmi;
static int b_v_cbi;
static int b_v_gli;
static bint_t b_v_sbi;
static bint_t b_v_cai;
static bint_t b_v_xbi;
static bint_t b_v_ii;
static bint_t b_v_mbi;
static bstr_t b_v_ks;
static int b_v_bti;
static bint_t b_v_bpi;
static bint_t b_v_di;
static bint_t b_v_jxi;
static bint_t b_v_jyi;
static bint_t b_v_hvi;
static bint_t b_v_hmi;
static bint_t b_v_mxi;
static bint_t b_v_myi;
static bint_t b_v_rri;
static bint_t b_v_axi;
static bint_t b_v_ayi;
static bint_t b_v_dyi;
static bint_t b_v_dxi;
static int b_v_rzi;
static int b_v_dki;
static int b_v_adi;
static int b_v_bki;
static bint_t b_v_tyi;
static bint_t b_v_ni;
static bint_t b_v_hei;
static bint_t b_v_gi;
static bint_t b_v_txi;
static bstr_t b_v_ts;
static int b_v_lzi;
static bint_t b_v_chi;
static int b_v_cci;
static bint_t b_v_sci;
static bint_t b_v_mci;
static int b_v_pwi;
static bint_t b_v_dgi;
static bint_t b_v_eci;
static int b_v_nri;
static int b_v_yyi;
static int b_v_xxi;
static bint_t b_v_cii;
static int b_v_rmi;
static int b_v_mti;
static int b_v_lxi;
static int b_v_lyi;
static int b_v_hxi;
static int b_v_hyi;
static bint_t b_v_xi;
static bint_t b_v_yi;
static int b_v_bri;
static int b_v_bxi;
static int b_v_byi;
static int b_v_bmi;
static int b_v_bji;
static int b_v_sdi;
static bint_t b_v_M0;
static int b_v_M1;
static int b_v_M2;
static bint_t b_v_M3;
static bint_t b_v_M4;
static int b_v_M5;
static int b_v_M6;
static int b_v_M7;
static int b_v_M8;
static int b_v_M9;
static int b_v_M10;
static int b_v_M11;
static int b_v_M12;
static int b_v_M13;
static int b_v_M14;
static int b_v_M15;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[4];
static int b_rtfor_sp=0;
static bint_t b_fl_1;
static bint_t b_fl_2;
static bint_t b_fl_6;
static bint_t b_fl_7;
static int b_fl_24;
static bint_t b_fl_26;
static bint_t b_fl_27;
static bint_t b_fl_29;
static bint_t b_fl_31;
static bint_t b_fl_32;
static bint_t b_fl_35;
static bint_t b_fl_38;
static int b_fl_40;
static int b_fl_41;
static int b_fl_42;
static bint_t b_fl_43;
static bint_t b_fl_44;
static int b_fl_45;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		b_poke((53280.0),(6));
		b_poke((53281.0),(0));
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L5800;
b_ret0: ;
		/* line 80 */
b_L80: ;
		b_v_twi=(35);
		b_v_tfi=(46);
		b_v_tsi=(62);
		b_v_tui=(60);
		b_v_tci=(11);
		/* line 90 */
b_L90: ;
		b_v_rsf=b_rnd(B_INT((-(((B_INT(b_peek((unsigned int)((53266.0)))))+((1)))))));
		/* line 100 */
b_L100: ;
		b_v_dei=(1);
		b_v_hpi=(20);
		b_v_mai=(20);
		b_v_lei=(1);
		b_v_xpi=(0);
		b_v_goi=(0);
		b_v_ati=(3);
		b_v_wei=(0);
		b_v_ari=(0);
		b_v_foi=(500);
		b_v_spi=(0);
		b_v_poi=(0);
		b_v_pci=(7);
		b_v_hti=(0);
		b_v_fli=(0);
		b_v_gvi=(0);
		b_v_pii=(0);
		b_v_phi=(2);
		b_v_ppi=(0);
		/* line 110 */
b_L110: ;
		b_v_fti=(0);
		b_v_msi=(7);
		b_v_mgi=(19);
		b_v_ami=(0);
		b_v_mvi=(1);
		b_v_cxi=(0);
		b_v_bci=(0);
		b_v_bfi=(0);
		b_v_ipi=(0);
		b_v_pui=(0);
		b_v_sti=(0);
		b_v_swi=(0);
		b_v_hii=(0);
		b_v_kti=(0);
		/* line 120 */
b_L120: ;
		b_poke((650),(128));
		b_poke((53272.0),(23));
		b_poke((54296.0),(15));
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f0_e;
		b_t_0=(((((55296.0))+((960))))+(b_v_ji));
b_f0_t: ;
		b_poke(b_t_0,(1));
		b_t_0 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f0_t;
b_f0_e: ;
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L5600;
b_ret1: ;
		/* line 140 */
b_L140: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		if(-((b_v_hpi) > (b_v_mai))){
			b_v_hpi=b_v_mai;
		}
		/* line 150 */
b_L150: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 160 */
b_L160: ;
		if(-((b_v_ki) == ((62)))){
			b_poke((650),(0));
			b_poke((53272.0),(21));
			goto b_end;
		}
		/* line 170 */
b_L170: ;
		if(-((b_v_ki) == ((33)))){
			b_gosubStack[b_gosubSP++]=2; goto b_L2100;
b_ret2: ;
			b_gosubStack[b_gosubSP++]=3; goto b_L1400;
b_ret3: ;
			b_gosubStack[b_gosubSP++]=4; goto b_L1300;
b_ret4: ;
			goto b_L490;
		}
		/* line 180 */
b_L180: ;
		if(-((b_v_ki) == ((29)))){
			b_gosubStack[b_gosubSP++]=5; goto b_L2100;
b_ret5: ;
			b_gosubStack[b_gosubSP++]=6; goto b_L1400;
b_ret6: ;
			b_gosubStack[b_gosubSP++]=7; goto b_L1300;
b_ret7: ;
			goto b_L490;
		}
		/* line 190 */
b_L190: ;
		if(-((b_v_ki) == ((60)))){
			b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_v_pyi)*((64))))))+(b_v_pxi)))));
			if(-((b_v_ti) == ((62)))){
				b_gosubStack[b_gosubSP++]=8; goto b_L3800;
b_ret8: ;
				goto b_L490;
			}
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_ki) == ((60)))){
			if(-((b_v_ti) == ((60)))){
				b_gosubStack[b_gosubSP++]=9; goto b_L3900;
b_ret9: ;
				goto b_L490;
			}
		}
		/* line 210 */
b_L210: ;
		if(-((b_v_ki) == ((60)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L2800;
b_ret10: ;
			if(b_v_shi){
				b_gosubStack[b_gosubSP++]=11; goto b_L4500;
b_ret11: ;
				goto b_L490;
			}
		}
		/* line 220 */
b_L220: ;
		if(-((b_v_ki) == ((38)))){
			b_gosubStack[b_gosubSP++]=12; goto b_L2600;
b_ret12: ;
			b_gosubStack[b_gosubSP++]=13; goto b_L1400;
b_ret13: ;
			b_gosubStack[b_gosubSP++]=14; goto b_L1300;
b_ret14: ;
			goto b_L490;
		}
		/* line 230 */
b_L230: ;
		if(-((b_v_ki) == ((14)))){
			b_gosubStack[b_gosubSP++]=15; goto b_L4000;
b_ret15: ;
			goto b_L490;
		}
		/* line 240 */
b_L240: ;
		if(-((b_v_ki) == ((7)))){
			if(b_v_sfi){
				b_v_ki=(9);
			}
		}
		/* line 250 */
b_L250: ;
		if(-((b_v_ki) == ((7)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(13);
			}
		}
		/* line 260 */
b_L260: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 270 */
b_L270: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 280 */
b_L280: ;
		b_v_nxi=b_v_pxi;
		b_v_nyi=b_v_pyi;
		/* line 290 */
b_L290: ;
		if(-((b_v_ki) == ((9)))){
			b_v_nyi=((b_v_pyi)-((1)));
		}
		/* line 300 */
b_L300: ;
		if(-((b_v_ki) == ((13)))){
			b_v_nyi=((b_v_pyi)+((1)));
		}
		/* line 310 */
b_L310: ;
		if(-((b_v_ki) == ((10)))){
			b_v_nxi=((b_v_pxi)-((1)));
		}
		/* line 320 */
b_L320: ;
		if(-((b_v_ki) == ((18)))){
			b_v_nxi=((b_v_pxi)+((1)));
		}
		/* line 330 */
b_L330: ;
		if(-((b_v_nxi) < ((0)))){
			b_v_nxi=(0);
		}
		/* line 340 */
b_L340: ;
		if(-((b_v_nxi) > ((63)))){
			b_v_nxi=(63);
		}
		/* line 350 */
b_L350: ;
		if(-((b_v_nyi) < ((0)))){
			b_v_nyi=(0);
		}
		/* line 360 */
b_L360: ;
		if(-((b_v_nyi) > ((63)))){
			b_v_nyi=(63);
		}
		/* line 370 */
b_L370: ;
		if(-((b_v_nxi) == (b_v_pxi))){
			if(-((b_v_nyi) == (b_v_pyi))){ goto b_L490; }
		}
		/* line 380 */
b_L380: ;
		b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_v_nyi)*((64))))))+(b_v_nxi)))));
		/* line 390 */
b_L390: ;
		if(-((b_v_ti) == ((0)))){
			b_gosubStack[b_gosubSP++]=16; goto b_L4400;
b_ret16: ;
			if(-((b_v_ti) == ((0)))){ goto b_L490; }
		}
		/* line 400 */
b_L400: ;
		b_v_mii=(0);
		/* line 410 */
b_L410: ;
		b_v_ji=(1);
		b_fl_1=b_v_nmi;
		if(b_v_ji > b_fl_1) goto b_f1_e;
b_f1_t: ;
		/* line 420 */
b_L420: ;
		if(-((b_a_ohi[B_INT(b_v_ji)]) <= ((0)))){ goto b_L440; }
		/* line 430 */
b_L430: ;
		if(-((b_a_oxi[B_INT(b_v_ji)]) == (b_v_nxi))){
			if(-((b_a_oyi[B_INT(b_v_ji)]) == (b_v_nyi))){
				b_v_mii=b_v_ji;
			}
		}
		/* line 440 */
b_L440: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_1)) goto b_f1_t;
b_f1_e: ;
		/* line 450 */
b_L450: ;
		if(-((b_v_mii) > ((0)))){
			b_gosubStack[b_gosubSP++]=17; goto b_L2300;
b_ret17: ;
			goto b_L490;
		}
		/* line 460 */
b_L460: ;
		b_a_opi[B_INT((0))]=b_v_pxi;
		b_a_opi[B_INT((1))]=b_v_pyi;
		b_v_pxi=b_v_nxi;
		b_v_pyi=b_v_nyi;
		/* line 470 */
b_L470: ;
		b_v_sti=((b_v_sti)+((1)));
		b_gosubStack[b_gosubSP++]=18; goto b_L4200;
b_ret18: ;
		/* line 480 */
b_L480: ;
		b_v_sni=(1);
		b_gosubStack[b_gosubSP++]=19; goto b_L6000;
b_ret19: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L1100;
b_ret20: ;
		/* line 490 */
b_L490: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L4900;
b_ret21: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L3400;
b_ret22: ;
		/* line 500 */
b_L500: ;
		b_v_fti=((b_v_fti)+((1)));
		if(-((b_v_fti) >= (b_v_msi))){
			b_v_fti=(0);
			b_gosubStack[b_gosubSP++]=23; goto b_L3000;
b_ret23: ;
		}
		/* line 510 */
b_L510: ;
		b_v_hfi=((b_v_hfi)+((1)));
		if(-((b_v_hfi) >= ((20)))){
			b_v_hfi=(0);
			b_gosubStack[b_gosubSP++]=24; goto b_L3300;
b_ret24: ;
		}
		/* line 520 */
b_L520: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L3200;
b_ret25: ;
		/* line 530 */
b_L530: ;
		if(-((b_v_gvi) == ((1)))){
			b_v_gvi=(0);
			goto b_L80;
		}
		/* line 540 */
b_L540: ;
		goto b_L140;
		/* line 1000 */
b_L1000: ;
		b_v_gxi=((b_v_wxi)-(b_v_vxi));
		b_v_gyi=((b_v_wyi)-(b_v_vyi));
		/* line 1001 */
b_L1001: ;
		if((B_INT((B_INT((B_INT(-((b_v_gxi) < ((0)))) | B_INT(-((b_v_gxi) > ((39)))))) | B_INT(-((b_v_gyi) < ((0)))))) | B_INT(-((b_v_gyi) > ((22)))))){
			goto b_return;
		}
		/* line 1002 */
b_L1002: ;
		b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_v_wyi)*((64))))))+(b_v_wxi)))));
		b_v_coi=b_v_tci;
		/* line 1003 */
b_L1003: ;
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
			goto b_L1009;
		}
		/* line 1004 */
b_L1004: ;
		if(-((b_v_ti) == ((62)))){
			goto b_L1009;
		}
		/* line 1005 */
b_L1005: ;
		if(-((b_v_ti) == ((60)))){
			goto b_L1009;
		}
		/* line 1006 */
b_L1006: ;
		b_v_qi=(1);
		b_fl_2=b_v_nii;
		if(b_v_qi > b_fl_2) goto b_f2_e;
b_f2_t: ;
		if(-((b_a_iti[B_INT(b_v_qi)]) == ((0)))){ goto b_L1008; }
		/* line 1007 */
b_L1007: ;
		if(-((b_a_ixi[B_INT(b_v_qi)]) == (b_v_wxi))){
			if(-((b_a_iyi[B_INT(b_v_qi)]) == (b_v_wyi))){
				b_v_ti=b_a_ici[B_INT(b_a_iti[B_INT(b_v_qi)])];
				b_v_coi=(5);
				if(-((b_a_iti[B_INT(b_v_qi)]) == ((8)))){
					b_v_coi=(6);
				}
			}
		}
		/* line 1008 */
b_L1008: ;
		b_v_qi += 1;
		if(b_v_qi <= (b_fl_2)) goto b_f2_t;
b_f2_e: ;
		/* line 1009 */
b_L1009: ;
		b_poke((((((1024))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_ti);
		b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_coi);
		/* line 1010 */
b_L1010: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		b_v_wxi=b_a_opi[B_INT((0))];
		b_v_wyi=b_a_opi[B_INT((1))];
		b_gosubStack[b_gosubSP++]=26; goto b_L1000;
b_ret26: ;
		/* line 1101 */
b_L1101: ;
		b_v_sxi=((b_v_pxi)-(b_v_vxi));
		b_v_syi=((b_v_pyi)-(b_v_vyi));
		/* line 1102 */
b_L1102: ;
		if((B_INT((B_INT((B_INT(-((b_v_sxi) >= ((0)))) & B_INT(-((b_v_sxi) <= ((39)))))) & B_INT(-((b_v_syi) >= ((0)))))) & B_INT(-((b_v_syi) <= ((22)))))){
			b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),(0));
			b_poke((((((55296.0))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_pci);
		}
		/* line 1103 */
b_L1103: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L1200;
b_ret27: ;
		/* line 1104 */
b_L1104: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		b_v_sxi=((b_v_pxi)-(b_v_vxi));
		b_v_syi=((b_v_pyi)-(b_v_vyi));
		/* line 1201 */
b_L1201: ;
		if(-((b_v_sxi) < ((8)))){
			if(-((b_v_vxi) > ((0)))){
				b_gosubStack[b_gosubSP++]=28; goto b_L2000;
b_ret28: ;
			}
		}
		/* line 1202 */
b_L1202: ;
		if(-((b_v_sxi) > ((31)))){
			if(-((b_v_vxi) < ((24)))){
				b_gosubStack[b_gosubSP++]=29; goto b_L1900;
b_ret29: ;
			}
		}
		/* line 1203 */
b_L1203: ;
		if(-((b_v_syi) < ((8)))){
			if(-((b_v_vyi) > ((0)))){
				b_gosubStack[b_gosubSP++]=30; goto b_L1700;
b_ret30: ;
			}
		}
		/* line 1204 */
b_L1204: ;
		if(-((b_v_syi) > ((14)))){
			if(-((b_v_vyi) < ((41)))){
				b_gosubStack[b_gosubSP++]=31; goto b_L1800;
b_ret31: ;
			}
		}
		/* line 1205 */
b_L1205: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f3_e;
b_f3_t: ;
		/* line 1301 */
b_L1301: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		/* line 1302 */
b_L1302: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f4_e;
		b_v_M0=((b_v_wyi)*((64)));
b_f4_t: ;
		/* line 1303 */
b_L1303: ;
		b_v_wxi=((b_v_vxi)+(b_v_ci));
		b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(b_v_M0)))+(b_v_wxi)))));
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
		}
		/* line 1304 */
b_L1304: ;
		b_poke(b_v_sai,b_v_ti);
		b_v_sai=((b_v_sai)+((1)));
		/* line 1305 */
b_L1305: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f4_t;
b_f4_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f3_t;
b_f3_e: ;
		/* line 1306 */
b_L1306: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=32; goto b_L1500;
b_ret32: ;
		/* line 1307 */
b_L1307: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		b_v_ji=(0);
		if(b_v_ji > 919) goto b_f5_e;
b_f5_t: ;
		b_poke((((55296.0))+(b_v_ji)),b_v_tci);
		b_v_ji += 1;
		if(b_v_ji <= 919) goto b_f5_t;
b_f5_e: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		b_v_qi=(1);
		b_fl_6=b_v_nii;
		if(b_v_qi > b_fl_6) goto b_f6_e;
b_f6_t: ;
		if(-((b_a_iti[B_INT(b_v_qi)]) == ((0)))){ goto b_L1503; }
		/* line 1501 */
b_L1501: ;
		b_v_gxi=((b_a_ixi[B_INT(b_v_qi)])-(b_v_vxi));
		b_v_gyi=((b_a_iyi[B_INT(b_v_qi)])-(b_v_vyi));
		b_v_cbi=(5);
		if(-((b_a_iti[B_INT(b_v_qi)]) == ((8)))){
			b_v_cbi=(6);
		}
		/* line 1502 */
b_L1502: ;
		if((B_INT((B_INT((B_INT(-((b_v_gxi) >= ((0)))) & B_INT(-((b_v_gxi) <= ((39)))))) & B_INT(-((b_v_gyi) >= ((0)))))) & B_INT(-((b_v_gyi) <= ((22)))))){
			b_v_gli=b_a_ici[B_INT(b_a_iti[B_INT(b_v_qi)])];
			b_gosubStack[b_gosubSP++]=33; goto b_L1600;
b_ret33: ;
		}
		/* line 1503 */
b_L1503: ;
		b_v_qi += 1;
		if(b_v_qi <= (b_fl_6)) goto b_f6_t;
b_f6_e: ;
		/* line 1504 */
b_L1504: ;
		b_v_ji=(1);
		b_fl_7=b_v_nmi;
		if(b_v_ji > b_fl_7) goto b_f7_e;
b_f7_t: ;
		if(-((b_a_ohi[B_INT(b_v_ji)]) <= ((0)))){ goto b_L1507; }
		/* line 1505 */
b_L1505: ;
		b_v_gxi=((b_a_oxi[B_INT(b_v_ji)])-(b_v_vxi));
		b_v_gyi=((b_a_oyi[B_INT(b_v_ji)])-(b_v_vyi));
		/* line 1506 */
b_L1506: ;
		if((B_INT((B_INT((B_INT(-((b_v_gxi) >= ((0)))) & B_INT(-((b_v_gxi) <= ((39)))))) & B_INT(-((b_v_gyi) >= ((0)))))) & B_INT(-((b_v_gyi) <= ((22)))))){
			b_v_gli=b_a_oci[B_INT(b_a_oti[B_INT(b_v_ji)])];
			b_v_cbi=(2);
			b_gosubStack[b_gosubSP++]=34; goto b_L1600;
b_ret34: ;
		}
		/* line 1507 */
b_L1507: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_7)) goto b_f7_t;
b_f7_e: ;
		/* line 1508 */
b_L1508: ;
		b_v_gxi=((b_v_pxi)-(b_v_vxi));
		b_v_gyi=((b_v_pyi)-(b_v_vyi));
		/* line 1509 */
b_L1509: ;
		if((B_INT((B_INT((B_INT(-((b_v_gxi) >= ((0)))) & B_INT(-((b_v_gxi) <= ((39)))))) & B_INT(-((b_v_gyi) >= ((0)))))) & B_INT(-((b_v_gyi) <= ((22)))))){
			b_v_gli=(0);
			b_v_cbi=b_v_pci;
			b_gosubStack[b_gosubSP++]=35; goto b_L1600;
b_ret35: ;
		}
		/* line 1510 */
b_L1510: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		b_v_coi=b_v_cbi;
		if(-((b_v_dmi) == ((0)))){
			b_v_coi=b_v_tci;
		}
		/* line 1601 */
b_L1601: ;
		b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_coi);
		if(-((b_v_dmi) == ((1)))){
			b_poke((((((1024))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_gli);
		}
		/* line 1602 */
b_L1602: ;
		goto b_return;
		/* line 1603 */
b_L1603: ;
		b_v_wxi=b_v_pxi;
		b_v_wyi=b_v_pyi;
		b_gosubStack[b_gosubSP++]=36; goto b_L1000;
b_ret36: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		b_v_sai=(1943);
		b_v_sbi=((b_v_sai)-((320)));
		b_v_cai=(((((55296.0))+((880))))+((39)));
		b_v_xbi=((b_v_cai)-((320)));
		/* line 1701 */
b_L1701: ;
		b_v_ii=(0);
		if(b_v_ii > 599) goto b_f8_e;
b_f8_t: ;
		b_poke(b_v_sai,B_INT(b_peek((unsigned int)(b_v_sbi))));
		b_poke(b_v_cai,B_INT(b_peek((unsigned int)(b_v_xbi))));
		b_v_sai=((b_v_sai)-((1)));
		b_v_sbi=((b_v_sbi)-((1)));
		b_v_cai=((b_v_cai)-((1)));
		b_v_xbi=((b_v_xbi)-((1)));
		b_v_ii += 1;
		if(b_v_ii <= 599) goto b_f8_t;
b_f8_e: ;
		/* line 1702 */
b_L1702: ;
		b_v_vyi=((b_v_vyi)-((8)));
		if(-((b_v_vyi) < ((0)))){
			b_v_vyi=(0);
		}
		/* line 1703 */
b_L1703: ;
		b_v_ri=(0);
		if(b_v_ri > 7) goto b_f9_e;
b_f9_t: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_cai=(((55296.0))+(((b_v_ri)*((40)))));
		b_v_mbi=(((49152.0))+(((b_v_wyi)*((64)))));
		/* line 1704 */
b_L1704: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f10_e;
		b_t_7=((b_v_sai)+(b_v_ci));
		b_t_8=((b_v_cai)+(b_v_ci));
b_f10_t: ;
		b_v_wxi=((b_v_vxi)+(b_v_ci));
		b_v_ti=B_INT(b_peek((unsigned int)(((b_v_mbi)+(b_v_wxi)))));
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
		}
		/* line 1705 */
b_L1705: ;
		b_poke(b_t_7,b_v_ti);
		b_poke(b_t_8,b_v_tci);
		b_t_7 += 1;
		b_t_8 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f10_t;
b_f10_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 7) goto b_f9_t;
b_f9_e: ;
		/* line 1706 */
b_L1706: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=37; goto b_L1500;
b_ret37: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		b_v_sai=(1024);
		b_v_sbi=(1344);
		b_v_cai=(55296.0);
		b_v_xbi=(((55296.0))+((320)));
		/* line 1801 */
b_L1801: ;
		b_v_ii=(0);
		if(b_v_ii > 599) goto b_f11_e;
b_f11_t: ;
		b_poke(b_v_sai,B_INT(b_peek((unsigned int)(b_v_sbi))));
		b_poke(b_v_cai,B_INT(b_peek((unsigned int)(b_v_xbi))));
		b_v_ii += 1;
		if(b_v_ii <= 599) goto b_f11_t;
b_f11_e: ;
		/* line 1802 */
b_L1802: ;
		b_v_vyi=((b_v_vyi)+((8)));
		if(-((b_v_vyi) > ((41)))){
			b_v_vyi=(41);
		}
		/* line 1803 */
b_L1803: ;
		b_v_ri=(15);
		if(b_v_ri > 22) goto b_f12_e;
b_f12_t: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_cai=(((55296.0))+(((b_v_ri)*((40)))));
		b_v_mbi=(((49152.0))+(((b_v_wyi)*((64)))));
		/* line 1804 */
b_L1804: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f13_e;
		b_t_9=((b_v_sai)+(b_v_ci));
		b_t_10=((b_v_cai)+(b_v_ci));
b_f13_t: ;
		b_v_wxi=((b_v_vxi)+(b_v_ci));
		b_v_ti=B_INT(b_peek((unsigned int)(((b_v_mbi)+(b_v_wxi)))));
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
		}
		/* line 1805 */
b_L1805: ;
		b_poke(b_t_9,b_v_ti);
		b_poke(b_t_10,b_v_tci);
		b_t_9 += 1;
		b_t_10 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f13_t;
b_f13_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f12_t;
b_f12_e: ;
		/* line 1806 */
b_L1806: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=38; goto b_L1500;
b_ret38: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f14_e;
b_f14_t: ;
		/* line 1901 */
b_L1901: ;
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_sbi=((b_v_sai)+((8)));
		b_v_cai=(((55296.0))+(((b_v_ri)*((40)))));
		b_v_xbi=((b_v_cai)+((8)));
		/* line 1902 */
b_L1902: ;
		b_v_ci=(0);
		if(b_v_ci > 31) goto b_f15_e;
b_f15_t: ;
		b_poke(b_v_sai,B_INT(b_peek((unsigned int)(b_v_sbi))));
		b_poke(b_v_cai,B_INT(b_peek((unsigned int)(b_v_xbi))));
		b_v_ci += 1;
		if(b_v_ci <= 31) goto b_f15_t;
b_f15_e: ;
		/* line 1903 */
b_L1903: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f14_t;
b_f14_e: ;
		/* line 1904 */
b_L1904: ;
		b_v_vxi=((b_v_vxi)+((8)));
		if(-((b_v_vxi) > ((24)))){
			b_v_vxi=(24);
		}
		/* line 1905 */
b_L1905: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f16_e;
b_f16_t: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((((1024))+(((b_v_ri)*((40))))))+((32)));
		b_v_cai=(((((55296.0))+(((b_v_ri)*((40))))))+((32)));
		b_v_mbi=(((49152.0))+(((b_v_wyi)*((64)))));
		/* line 1906 */
b_L1906: ;
		b_v_ci=(0);
		if(b_v_ci > 7) goto b_f17_e;
		b_t_11=((b_v_sai)+(b_v_ci));
		b_t_12=((b_v_cai)+(b_v_ci));
b_f17_t: ;
		b_v_wxi=((((b_v_vxi)+(b_v_ci)))+((32)));
		b_v_ti=B_INT(b_peek((unsigned int)(((b_v_mbi)+(b_v_wxi)))));
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
		}
		/* line 1907 */
b_L1907: ;
		b_poke(b_t_11,b_v_ti);
		b_poke(b_t_12,b_v_tci);
		b_t_11 += 1;
		b_t_12 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 7) goto b_f17_t;
b_f17_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f16_t;
b_f16_e: ;
		/* line 1908 */
b_L1908: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=39; goto b_L1500;
b_ret39: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f18_e;
b_f18_t: ;
		/* line 2001 */
b_L2001: ;
		b_v_sai=(((((1024))+(((b_v_ri)*((40))))))+((39)));
		b_v_sbi=((b_v_sai)-((8)));
		b_v_cai=(((((55296.0))+(((b_v_ri)*((40))))))+((39)));
		b_v_xbi=((b_v_cai)-((8)));
		/* line 2002 */
b_L2002: ;
		b_v_ci=(0);
		if(b_v_ci > 31) goto b_f19_e;
b_f19_t: ;
		b_poke(b_v_sai,B_INT(b_peek((unsigned int)(b_v_sbi))));
		b_poke(b_v_cai,B_INT(b_peek((unsigned int)(b_v_xbi))));
		b_v_sai=((b_v_sai)-((1)));
		b_v_sbi=((b_v_sbi)-((1)));
		b_v_cai=((b_v_cai)-((1)));
		b_v_xbi=((b_v_xbi)-((1)));
		b_v_ci += 1;
		if(b_v_ci <= 31) goto b_f19_t;
b_f19_e: ;
		/* line 2003 */
b_L2003: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f18_t;
b_f18_e: ;
		/* line 2004 */
b_L2004: ;
		b_v_vxi=((b_v_vxi)-((8)));
		if(-((b_v_vxi) < ((0)))){
			b_v_vxi=(0);
		}
		/* line 2005 */
b_L2005: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f20_e;
b_f20_t: ;
		b_v_wyi=((b_v_vyi)+(b_v_ri));
		b_v_sai=(((1024))+(((b_v_ri)*((40)))));
		b_v_cai=(((55296.0))+(((b_v_ri)*((40)))));
		b_v_mbi=(((49152.0))+(((b_v_wyi)*((64)))));
		/* line 2006 */
b_L2006: ;
		b_v_ci=(0);
		if(b_v_ci > 7) goto b_f21_e;
		b_t_13=((b_v_sai)+(b_v_ci));
		b_t_14=((b_v_cai)+(b_v_ci));
b_f21_t: ;
		b_v_wxi=((b_v_vxi)+(b_v_ci));
		b_v_ti=B_INT(b_peek((unsigned int)(((b_v_mbi)+(b_v_wxi)))));
		if(-((b_v_ti) == ((0)))){
			b_v_ti=(35);
		}
		/* line 2007 */
b_L2007: ;
		b_poke(b_t_13,b_v_ti);
		b_poke(b_t_14,b_v_tci);
		b_t_13 += 1;
		b_t_14 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 7) goto b_f21_t;
b_f21_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f20_t;
b_f20_e: ;
		/* line 2008 */
b_L2008: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=40; goto b_L1500;
b_ret40: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		b_putc(147);
		b_nl();
		/* line 2101 */
b_L2101: ;
		{ bstr_t _t=b_lit("*** NETHACK ***",15); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2102 */
b_L2102: ;
		b_nl();
		/* line 2103 */
b_L2103: ;
		{ bstr_t _t=b_lit("DEPTH :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_dei);
		b_nl();
		/* line 2104 */
b_L2104: ;
		{ bstr_t _t=b_lit("HP    :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_hpi);
		b_putc(47);
		b_putint(b_v_mai);
		b_nl();
		/* line 2105 */
b_L2105: ;
		{ bstr_t _t=b_lit("LEVEL :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		{ bstr_t _t=b_lit(" EXP:",5); b_str(_t.p,_t.len); }
		b_putint(b_v_xpi);
		b_nl();
		/* line 2106 */
b_L2106: ;
		{ bstr_t _t=b_lit("GOLD  :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_goi);
		b_nl();
		/* line 2107 */
b_L2107: ;
		{ bstr_t _t=b_lit("FOOD  :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_foi);
		{ bstr_t _t=b_lit(" PICK:",6); b_str(_t.p,_t.len); }
		b_putint(b_v_pii);
		b_nl();
		/* line 2108 */
b_L2108: ;
		{ bstr_t _t=b_lit("WEAPON +",8); b_str(_t.p,_t.len); }
		b_putint(b_v_wei);
		{ bstr_t _t=b_lit(" ATK",4); b_str(_t.p,_t.len); }
		b_putint(((b_v_ati)+(b_v_wei)));
		b_nl();
		/* line 2109 */
b_L2109: ;
		{ bstr_t _t=b_lit("ARMOR +",7); b_str(_t.p,_t.len); }
		b_putint(b_v_ari);
		{ bstr_t _t=b_lit(" SPD",4); b_str(_t.p,_t.len); }
		b_putint(b_v_spi);
		b_nl();
		/* line 2110 */
b_L2110: ;
		b_nl();
		/* line 2111 */
b_L2111: ;
		{ bstr_t _t=b_lit("WASD MOVE  SPC STAIRS",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2112 */
b_L2112: ;
		{ bstr_t _t=b_lit("E EAT  I STAT  O MOBS  Q QUIT",29); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2113 */
b_L2113: ;
		{ bstr_t _t=b_lit("BUMP FIGHT  SPC SHOP",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2114 */
b_L2114: ;
		{ bstr_t _t=b_lit("PICKAXE DIGS # WALLS",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2115 */
b_L2115: ;
		b_a_rci[B_INT((0))]=(7);
		b_a_rci[B_INT((1))]=(12);
		b_a_rci[B_INT((2))]=(3);
		b_a_rci[B_INT((3))]=(5);
		b_a_rci[B_INT((4))]=(7);
		b_a_rci[B_INT((5))]=(8);
		b_a_rci[B_INT((6))]=(13);
		b_a_rci[B_INT((7))]=(4);
		b_a_rci[B_INT((8))]=(6);
		b_a_rci[B_INT((9))]=(12);
		b_a_rci[B_INT((10))]=(12);
		b_a_rci[B_INT((11))]=(3);
		/* line 2116 */
b_L2116: ;
		b_v_ri=(0);
		if(b_v_ri > 11) goto b_f22_e;
b_f22_t: ;
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f23_e;
		b_v_M1=((b_v_ri)*((40)));
		b_v_M2=b_a_rci[B_INT(b_v_ri)];
		b_t_15=(((((55296.0))+(b_v_M1)))+(b_v_ji));
b_f23_t: ;
		b_poke(b_t_15,b_v_M2);
		b_t_15 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f23_t;
b_f23_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 11) goto b_f22_t;
b_f22_e: ;
		/* line 2117 */
b_L2117: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2117; }
		/* line 2118 */
b_L2118: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		b_putc(147);
		b_nl();
		/* line 2201 */
b_L2201: ;
		{ bstr_t _t=b_lit("LEVEL UP",8); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2202 */
b_L2202: ;
		{ bstr_t _t=b_lit("LEVEL :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		{ bstr_t _t=b_lit("  POINTS:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_poi);
		b_nl();
		/* line 2203 */
b_L2203: ;
		b_nl();
		/* line 2204 */
b_L2204: ;
		{ bstr_t _t=b_lit("1  +1 MAX HP",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2205 */
b_L2205: ;
		{ bstr_t _t=b_lit("2  +1 ATK",9); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2206 */
b_L2206: ;
		{ bstr_t _t=b_lit("3  +1 DEF",9); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2207 */
b_L2207: ;
		{ bstr_t _t=b_lit("4  +1 SPD",9); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2208 */
b_L2208: ;
		b_nl();
		/* line 2209 */
b_L2209: ;
		{ bstr_t _t=b_lit("HP",2); b_str(_t.p,_t.len); }
		b_putint(b_v_hpi);
		b_putc(47);
		b_putint(b_v_mai);
		{ bstr_t _t=b_lit(" ATK",4); b_str(_t.p,_t.len); }
		b_putint(b_v_ati);
		{ bstr_t _t=b_lit(" DEF",4); b_str(_t.p,_t.len); }
		b_putint(b_v_ari);
		{ bstr_t _t=b_lit(" SPD",4); b_str(_t.p,_t.len); }
		b_putint(b_v_spi);
		b_nl();
		/* line 2210 */
b_L2210: ;
		{ bstr_t _t=b_lit("XP",2); b_str(_t.p,_t.len); }
		b_putint(b_v_xpi);
		{ bstr_t _t=b_lit(" $",2); b_str(_t.p,_t.len); }
		b_putint(b_v_goi);
		{ bstr_t _t=b_lit(" D",2); b_str(_t.p,_t.len); }
		b_putint(b_v_dei);
		{ bstr_t _t=b_lit(" FD",3); b_str(_t.p,_t.len); }
		b_putint(b_v_foi);
		{ bstr_t _t=b_lit(" PK",3); b_str(_t.p,_t.len); }
		b_putint(b_v_pii);
		b_nl();
		/* line 2211 */
b_L2211: ;
		{ bstr_t _t=b_lit("1-4 SPEND",9); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2212 */
b_L2212: ;
		b_v_bti=(0);
		b_v_bpi=(5);
		/* line 2213 */
b_L2213: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){
			b_v_bti=((b_v_bti)+((1)));
			if(-((b_v_bti) >= ((15)))){
				b_v_bti=(0);
				b_v_bpi=(((5))-(b_v_bpi));
			}
		}
		/* line 2214 */
b_L2214: ;
		b_poke((53280.0),b_v_bpi);
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2213; }
		/* line 2215 */
b_L2215: ;
		b_poke((53280.0),(5));
		/* line 2216 */
b_L2216: ;
		if(-((b_v_poi) <= ((0)))){ goto b_L2221; }
		/* line 2217 */
b_L2217: ;
		if(-(b_strcmp(b_v_ks,b_lit("1",1)) == 0)){
			b_v_mai=((b_v_mai)+((1)));
			b_v_hpi=((b_v_hpi)+((1)));
			b_v_poi=((b_v_poi)-((1)));
		}
		/* line 2218 */
b_L2218: ;
		if(-(b_strcmp(b_v_ks,b_lit("2",1)) == 0)){
			b_v_ati=((b_v_ati)+((1)));
			b_v_poi=((b_v_poi)-((1)));
		}
		/* line 2219 */
b_L2219: ;
		if(-(b_strcmp(b_v_ks,b_lit("3",1)) == 0)){
			b_v_ari=((b_v_ari)+((1)));
			b_v_poi=((b_v_poi)-((1)));
		}
		/* line 2220 */
b_L2220: ;
		if(-(b_strcmp(b_v_ks,b_lit("4",1)) == 0)){
			b_v_spi=((b_v_spi)+((1)));
			b_v_poi=((b_v_poi)-((1)));
		}
		/* line 2221 */
b_L2221: ;
		if(-((b_v_poi) > ((0)))){
			b_v_bti=(0);
			b_v_bpi=(5);
			goto b_L2213;
		}
		/* line 2222 */
b_L2222: ;
		b_v_msi=(((7))+(((b_v_spi)*((4)))));
		if(-((b_v_msi) > ((40)))){
			b_v_msi=(40);
		}
		/* line 2223 */
b_L2223: ;
		b_poke((53280.0),(B_INT(((b_v_dei)+((5)))) & B_INT((15))));
		/* line 2224 */
b_L2224: ;
		b_gosubStack[b_gosubSP++]=41; goto b_L1400;
b_ret41: ;
		b_gosubStack[b_gosubSP++]=42; goto b_L1300;
b_ret42: ;
		/* line 2225 */
b_L2225: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		b_v_swi=((b_v_swi)+((1)));
		b_v_sni=(2);
		b_gosubStack[b_gosubSP++]=43; goto b_L6000;
b_ret43: ;
		b_v_mvi=b_a_oti[B_INT(b_v_mii)];
		/* line 2301 */
b_L2301: ;
		b_v_di=(((1))+(b_int(((b_rnd(B_INT((1))))*(((b_v_ati)+(b_v_wei)))))));
		/* line 2302 */
b_L2302: ;
		b_a_ohi[B_INT(b_v_mii)]=((b_a_ohi[B_INT(b_v_mii)])-(b_v_di));
		/* line 2303 */
b_L2303: ;
		if(-((b_a_ohi[B_INT(b_v_mii)]) > ((0)))){
			b_v_jxi=b_a_oxi[B_INT(b_v_mii)];
			b_v_jyi=b_a_oyi[B_INT(b_v_mii)];
			b_v_hvi=b_v_di;
			b_v_hmi=b_v_mii;
			b_v_hti=(6);
			b_gosubStack[b_gosubSP++]=44; goto b_L3500;
b_ret44: ;
			b_v_mgi=(1);
			b_v_ami=b_v_di;
			goto b_L2309;
		}
		/* line 2304 */
b_L2304: ;
		b_a_ohi[B_INT(b_v_mii)]=(((-30))+(b_v_dei));
		if(-((b_a_ohi[B_INT(b_v_mii)]) > ((-12)))){
			b_a_ohi[B_INT(b_v_mii)]=(-12);
		}
		/* line 2305 */
b_L2305: ;
		b_v_xpi=((b_v_xpi)+(b_a_oei[B_INT(b_a_oti[B_INT(b_v_mii)])]));
		b_a_kii[B_INT(b_a_oti[B_INT(b_v_mii)])]=((b_a_kii[B_INT(b_a_oti[B_INT(b_v_mii)])])+((1)));
		b_v_kti=((b_v_kti)+((1)));
		/* line 2306 */
b_L2306: ;
		b_gosubStack[b_gosubSP++]=45; goto b_L4300;
b_ret45: ;
		/* line 2307 */
b_L2307: ;
		b_v_mgi=(2);
		/* line 2308 */
b_L2308: ;
		b_gosubStack[b_gosubSP++]=46; goto b_L3100;
b_ret46: ;
		/* line 2309 */
b_L2309: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		b_v_mxi=b_a_oxi[B_INT(b_v_ji)];
		b_v_myi=b_a_oyi[B_INT(b_v_ji)];
		b_a_omi[B_INT((0))]=b_v_mxi;
		b_a_omi[B_INT((1))]=b_v_myi;
		/* line 2401 */
b_L2401: ;
		b_v_rri=b_int(((b_rnd(B_INT((1))))*((((8))+(b_v_dei)))));
		if(-((b_v_rri) == ((0)))){
			b_gosubStack[b_gosubSP++]=47; goto b_L2700;
b_ret47: ;
			goto b_L2408;
		}
		/* line 2402 */
b_L2402: ;
		if(-((b_v_axi) >= (b_v_ayi))){ goto b_L2406; }
		/* line 2403 */
b_L2403: ;
		if(-((b_v_dyi) < ((0)))){
			b_v_myi=((b_v_myi)+((1)));
		}
		/* line 2404 */
b_L2404: ;
		if(-((b_v_dyi) > ((0)))){
			b_v_myi=((b_v_myi)-((1)));
		}
		/* line 2405 */
b_L2405: ;
		goto b_L2408;
		/* line 2406 */
b_L2406: ;
		if(-((b_v_dxi) < ((0)))){
			b_v_mxi=((b_v_mxi)+((1)));
		}
		/* line 2407 */
b_L2407: ;
		if(-((b_v_dxi) > ((0)))){
			b_v_mxi=((b_v_mxi)-((1)));
		}
		/* line 2408 */
b_L2408: ;
		if((B_INT(-((b_v_mxi) < ((0)))) | B_INT(-((b_v_mxi) > ((63)))))){
			goto b_return;
		}
		/* line 2409 */
b_L2409: ;
		if((B_INT(-((b_v_myi) < ((0)))) | B_INT(-((b_v_myi) > ((63)))))){
			goto b_return;
		}
		/* line 2410 */
b_L2410: ;
		b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_v_myi)*((64))))))+(b_v_mxi)))));
		if(-((b_v_ti) == ((0)))){
			b_gosubStack[b_gosubSP++]=48; goto b_L2500;
b_ret48: ;
			if(-((b_v_ti) == ((0)))){
				goto b_return;
			}
		}
		/* line 2411 */
b_L2411: ;
		if(-((b_v_ti) == ((60)))){
			goto b_return;
		}
		/* line 2412 */
b_L2412: ;
		if(-((b_v_ti) == ((62)))){
			goto b_return;
		}
		/* line 2413 */
b_L2413: ;
		if(-((b_v_mxi) == (b_v_pxi))){
			if(-((b_v_myi) == (b_v_pyi))){
				goto b_return;
			}
		}
		/* line 2414 */
b_L2414: ;
		b_v_ki=(1);
		b_fl_24=b_v_nmi;
		if(b_v_ki > b_fl_24) goto b_f24_e;
b_f24_t: ;
		if(-((b_v_ki) == (b_v_ji))){ goto b_L2416; }
		/* line 2415 */
b_L2415: ;
		if(-((b_a_ohi[B_INT(b_v_ki)]) > ((0)))){
			if(-((b_a_oxi[B_INT(b_v_ki)]) == (b_v_mxi))){
				if(-((b_a_oyi[B_INT(b_v_ki)]) == (b_v_myi))){
					goto b_return;
				}
			}
		}
		/* line 2416 */
b_L2416: ;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_24)) goto b_f24_t;
b_f24_e: ;
		/* line 2417 */
b_L2417: ;
		b_v_wxi=b_a_omi[B_INT((0))];
		b_v_wyi=b_a_omi[B_INT((1))];
		b_gosubStack[b_gosubSP++]=49; goto b_L1000;
b_ret49: ;
		/* line 2418 */
b_L2418: ;
		b_a_oxi[B_INT(b_v_ji)]=b_v_mxi;
		b_a_oyi[B_INT(b_v_ji)]=b_v_myi;
		/* line 2419 */
b_L2419: ;
		b_v_gxi=((b_v_mxi)-(b_v_vxi));
		b_v_gyi=((b_v_myi)-(b_v_vyi));
		if((B_INT((B_INT((B_INT(-((b_v_gxi) < ((0)))) | B_INT(-((b_v_gxi) > ((39)))))) | B_INT(-((b_v_gyi) < ((0)))))) | B_INT(-((b_v_gyi) > ((22)))))){
			goto b_return;
		}
		/* line 2420 */
b_L2420: ;
		b_poke((((((1024))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_a_oci[B_INT(b_a_oti[B_INT(b_v_ji)])]);
		b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),(2));
		/* line 2421 */
b_L2421: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		b_v_mxi=b_a_omi[B_INT((0))];
		b_v_myi=b_a_omi[B_INT((1))];
		b_v_ti=(0);
		/* line 2501 */
b_L2501: ;
		if(-((b_v_axi) >= (b_v_ayi))){ goto b_L2505; }
		/* line 2502 */
b_L2502: ;
		if(-((b_v_dxi) < ((0)))){
			b_v_mxi=((b_v_mxi)+((1)));
		}
		/* line 2503 */
b_L2503: ;
		if(-((b_v_dxi) > ((0)))){
			b_v_mxi=((b_v_mxi)-((1)));
		}
		/* line 2504 */
b_L2504: ;
		goto b_L2507;
		/* line 2505 */
b_L2505: ;
		if(-((b_v_dyi) < ((0)))){
			b_v_myi=((b_v_myi)+((1)));
		}
		/* line 2506 */
b_L2506: ;
		if(-((b_v_dyi) > ((0)))){
			b_v_myi=((b_v_myi)-((1)));
		}
		/* line 2507 */
b_L2507: ;
		if((B_INT((B_INT((B_INT(-((b_v_mxi) < ((0)))) | B_INT(-((b_v_mxi) > ((63)))))) | B_INT(-((b_v_myi) < ((0)))))) | B_INT(-((b_v_myi) > ((63)))))){
			goto b_return;
		}
		/* line 2508 */
b_L2508: ;
		b_v_ti=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_v_myi)*((64))))))+(b_v_mxi)))));
		goto b_return;
		/* line 2600 */
b_L2600: ;
		b_putc(147);
		b_nl();
		/* line 2601 */
b_L2601: ;
		{ bstr_t _t=b_lit("*** MOBS VS YOU ***",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2602 */
b_L2602: ;
		{ bstr_t _t=b_lit("YOU HP",6); b_str(_t.p,_t.len); }
		b_putint(b_v_hpi);
		b_putc(47);
		b_putint(b_v_mai);
		{ bstr_t _t=b_lit(" A",2); b_str(_t.p,_t.len); }
		b_putint(((b_v_ati)+(b_v_wei)));
		{ bstr_t _t=b_lit(" R",2); b_str(_t.p,_t.len); }
		b_putint(b_v_ari);
		{ bstr_t _t=b_lit(" L",2); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		{ bstr_t _t=b_lit(" $",2); b_str(_t.p,_t.len); }
		b_putint(b_v_goi);
		{ bstr_t _t=b_lit(" D",2); b_str(_t.p,_t.len); }
		b_putint(b_v_dei);
		b_nl();
		/* line 2603 */
b_L2603: ;
		b_nl();
		/* line 2604 */
b_L2604: ;
		{ bstr_t _t=b_lit("MOB HP A S XP KIL",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2605 */
b_L2605: ;
		b_v_ii=(1);
		if(b_v_ii > 7) goto b_f25_e;
b_f25_t: ;
		switch(b_v_ii){
			case 1: goto b_L2606; break;
			case 2: goto b_L2607; break;
			case 3: goto b_L2608; break;
			case 4: goto b_L2609; break;
			case 5: goto b_L2610; break;
			case 6: goto b_L2611; break;
			case 7: goto b_L2612; break;
			default: break;}
		/* line 2606 */
b_L2606: ;
		{ bstr_t _t=b_lit("R RAT    ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2607 */
b_L2607: ;
		{ bstr_t _t=b_lit("K KOBOLD ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2608 */
b_L2608: ;
		{ bstr_t _t=b_lit("O ORC    ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2609 */
b_L2609: ;
		{ bstr_t _t=b_lit("T TROLL  ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2610 */
b_L2610: ;
		{ bstr_t _t=b_lit("W WRAITH ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2611 */
b_L2611: ;
		{ bstr_t _t=b_lit("D DRAGON ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		goto b_L2613;
		/* line 2612 */
b_L2612: ;
		{ bstr_t _t=b_lit("D BOSS   ",9); b_str(_t.p,_t.len); }
		b_putint(b_a_obi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oai[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_osi[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_oei[B_INT(b_v_ii)]);
		b_putc(32);
		b_putint(b_a_kii[B_INT(b_v_ii)]);
		b_nl();
		/* line 2613 */
b_L2613: ;
		b_v_ii += 1;
		if(b_v_ii <= 7) goto b_f25_t;
b_f25_e: ;
		/* line 2614 */
b_L2614: ;
		b_nl();
		/* line 2615 */
b_L2615: ;
		{ bstr_t _t=b_lit("A=ATK R=DEF S=SPD K=KILLS",25); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2616 */
b_L2616: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2616; }
		/* line 2617 */
b_L2617: ;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		b_v_rzi=b_int(((b_rnd(B_INT((1))))*((4))));
		/* line 2701 */
b_L2701: ;
		if(-((b_v_rzi) == ((0)))){
			b_v_myi=((b_v_myi)-((1)));
			goto b_return;
		}
		/* line 2702 */
b_L2702: ;
		if(-((b_v_rzi) == ((1)))){
			b_v_myi=((b_v_myi)+((1)));
			goto b_return;
		}
		/* line 2703 */
b_L2703: ;
		if(-((b_v_rzi) == ((2)))){
			b_v_mxi=((b_v_mxi)-((1)));
			goto b_return;
		}
		/* line 2704 */
b_L2704: ;
		b_v_mxi=((b_v_mxi)+((1)));
		goto b_return;
		/* line 2800 */
b_L2800: ;
		b_v_shi=(0);
		b_v_ii=(1);
		b_fl_26=b_v_nii;
		if(b_v_ii > b_fl_26) goto b_f26_e;
b_f26_t: ;
		if(-((b_a_iti[B_INT(b_v_ii)]) == ((0)))){ goto b_L2802; }
		/* line 2801 */
b_L2801: ;
		if(-((b_a_iti[B_INT(b_v_ii)]) == ((8)))){
			if(-((b_a_ixi[B_INT(b_v_ii)]) == (b_v_pxi))){
				if(-((b_a_iyi[B_INT(b_v_ii)]) == (b_v_pyi))){
					b_v_shi=(1);
				}
			}
		}
		/* line 2802 */
b_L2802: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_26)) goto b_f26_t;
b_f26_e: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		b_v_mvi=b_a_oti[B_INT(b_v_ji)];
		/* line 2901 */
b_L2901: ;
		b_v_di=(((1))+(b_int(((b_rnd(B_INT((1))))*(b_a_oai[B_INT(b_a_oti[B_INT(b_v_ji)])])))));
		/* line 2902 */
b_L2902: ;
		b_v_di=((b_v_di)-(b_v_ari));
		if(-((b_v_di) < ((1)))){
			b_v_di=(1);
		}
		/* line 2903 */
b_L2903: ;
		b_v_hpi=((b_v_hpi)-(b_v_di));
		b_v_hii=((b_v_hii)+((1)));
		/* line 2904 */
b_L2904: ;
		b_v_mgi=(3);
		b_v_ami=b_v_di;
		b_v_pci=(2);
		b_v_fli=(8);
		b_v_bci=(1);
		b_v_bfi=(8);
		b_v_dki=(2);
		/* line 2905 */
b_L2905: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		b_v_ji=(1);
		b_fl_27=b_v_nmi;
		if(b_v_ji > b_fl_27) goto b_f27_e;
b_f27_t: ;
		/* line 3001 */
b_L3001: ;
		if(-((b_a_ohi[B_INT(b_v_ji)]) < ((0)))){
			b_a_ohi[B_INT(b_v_ji)]=((b_a_ohi[B_INT(b_v_ji)])+((1)));
			if(-((b_a_ohi[B_INT(b_v_ji)]) == ((0)))){
				b_a_ohi[B_INT(b_v_ji)]=((((b_v_dei)*((4))))+((4)));
				b_a_odi[B_INT(b_v_ji)]=(2);
			}
		}
		/* line 3002 */
b_L3002: ;
		if(-((b_a_ohi[B_INT(b_v_ji)]) <= ((0)))){ goto b_L3013; }
		/* line 3003 */
b_L3003: ;
		b_a_odi[B_INT(b_v_ji)]=((b_a_odi[B_INT(b_v_ji)])-((1)));
		if(-((b_a_odi[B_INT(b_v_ji)]) > ((0)))){ goto b_L3013; }
		/* line 3004 */
b_L3004: ;
		b_v_dxi=((b_a_oxi[B_INT(b_v_ji)])-(b_v_pxi));
		b_v_dyi=((b_a_oyi[B_INT(b_v_ji)])-(b_v_pyi));
		/* line 3005 */
b_L3005: ;
		b_v_axi=b_v_dxi;
		if(-((b_v_axi) < ((0)))){
			b_v_axi=(-(b_v_axi));
		}
		/* line 3006 */
b_L3006: ;
		b_v_ayi=b_v_dyi;
		if(-((b_v_ayi) < ((0)))){
			b_v_ayi=(-(b_v_ayi));
		}
		/* line 3007 */
b_L3007: ;
		b_v_adi=b_v_axi;
		if(-((b_v_ayi) > (b_v_axi))){
			b_v_adi=b_v_ayi;
		}
		/* line 3008 */
b_L3008: ;
		if(-((b_v_adi) == ((1)))){
			b_gosubStack[b_gosubSP++]=50; goto b_L2900;
b_ret50: ;
			b_a_odi[B_INT(b_v_ji)]=b_a_osi[B_INT(b_a_oti[B_INT(b_v_ji)])];
			goto b_L3013;
		}
		/* line 3009 */
b_L3009: ;
		if(-((b_v_adi) == ((0)))){ goto b_L3013; }
		/* line 3010 */
b_L3010: ;
		if(-((b_v_adi) > ((30)))){ goto b_L3013; }
		/* line 3011 */
b_L3011: ;
		b_gosubStack[b_gosubSP++]=51; goto b_L2400;
b_ret51: ;
		/* line 3012 */
b_L3012: ;
		b_a_odi[B_INT(b_v_ji)]=b_a_osi[B_INT(b_a_oti[B_INT(b_v_ji)])];
		/* line 3013 */
b_L3013: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_27)) goto b_f27_t;
b_f27_e: ;
		/* line 3014 */
b_L3014: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		if(-((b_v_xpi) >= (((b_v_lei)*((20)))))){ goto b_L3102; }
		/* line 3101 */
b_L3101: ;
		goto b_return;
		/* line 3102 */
b_L3102: ;
		b_v_lei=((b_v_lei)+((1)));
		/* line 3103 */
b_L3103: ;
		b_v_poi=(1);
		b_v_mgi=(4);
		b_v_sni=(4);
		b_gosubStack[b_gosubSP++]=52; goto b_L6000;
b_ret52: ;
		/* line 3104 */
b_L3104: ;
		b_gosubStack[b_gosubSP++]=53; goto b_L2200;
b_ret53: ;
		/* line 3105 */
b_L3105: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		if(-((b_v_hpi) > ((0)))){
			goto b_return;
		}
		/* line 3201 */
b_L3201: ;
		b_poke((650),(0));
		b_poke((53280.0),(2));
		b_poke((53281.0),(2));
		/* line 3202 */
b_L3202: ;
		b_v_bti=(0);
		b_v_bpi=(2);
		b_v_bki=(1);
		if(b_v_bki > 60) goto b_f28_e;
b_f28_t: ;
		b_v_bti=((b_v_bti)+((1)));
		if(-((b_v_bti) >= ((10)))){
			b_v_bti=(0);
			b_v_bpi=(((2))-(b_v_bpi));
		}
		/* line 3203 */
b_L3203: ;
		b_poke((53280.0),b_v_bpi);
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		b_v_bki += 1;
		if(b_v_bki <= 60) goto b_f28_t;
b_f28_e: ;
		/* line 3204 */
b_L3204: ;
		b_poke((53280.0),(2));
		/* line 3205 */
b_L3205: ;
		b_putc(147);
		b_nl();
		/* line 3206 */
b_L3206: ;
		if(-((b_v_dki) == ((1)))){
			{ bstr_t _t=b_lit("YOU STARVED!",12); b_str(_t.p,_t.len); }
			b_nl();
			goto b_L3208;
		}
		/* line 3207 */
b_L3207: ;
		{ bstr_t _t=b_lit("YOU DIED",8); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3208 */
b_L3208: ;
		{ bstr_t _t=b_lit("DEPTH :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_dei);
		{ bstr_t _t=b_lit("  GOLD:",7); b_str(_t.p,_t.len); }
		b_putint(b_v_goi);
		b_nl();
		/* line 3209 */
b_L3209: ;
		{ bstr_t _t=b_lit("EXP   :",7); b_str(_t.p,_t.len); }
		b_putint(b_v_xpi);
		{ bstr_t _t=b_lit("  LEVEL:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		b_nl();
		/* line 3210 */
b_L3210: ;
		{ bstr_t _t=b_lit("ST",2); b_str(_t.p,_t.len); }
		b_putint(b_v_sti);
		{ bstr_t _t=b_lit(" KT",3); b_str(_t.p,_t.len); }
		b_putint(b_v_kti);
		{ bstr_t _t=b_lit(" SW",3); b_str(_t.p,_t.len); }
		b_putint(b_v_swi);
		{ bstr_t _t=b_lit(" HT",3); b_str(_t.p,_t.len); }
		b_putint(b_v_hii);
		b_nl();
		/* line 3211 */
b_L3211: ;
		b_nl();
		{ bstr_t _t=b_lit("SPACE",5); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3212 */
b_L3212: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit(" ",1)) != 0)){ goto b_L3212; }
		/* line 3213 */
b_L3213: ;
		b_poke((53281.0),(0));
		b_v_gvi=(1);
		goto b_return;
		/* line 3300 */
b_L3300: ;
		b_v_foi=((b_v_foi)-((1)));
		/* line 3301 */
b_L3301: ;
		if(-((b_v_foi) > ((0)))){
			goto b_return;
		}
		/* line 3302 */
b_L3302: ;
		b_v_foi=(0);
		b_v_hpi=((b_v_hpi)-((1)));
		b_v_mgi=(5);
		b_v_dki=(1);
		/* line 3303 */
b_L3303: ;
		goto b_return;
		/* line 3400 */
b_L3400: ;
		if(-((b_v_hti) > ((0)))){
			b_v_hti=((b_v_hti)-((1)));
			if(-((b_v_hti) == ((0)))){
				b_gosubStack[b_gosubSP++]=54; goto b_L3600;
b_ret54: ;
			}
		}
		/* line 3401 */
b_L3401: ;
		if(-((b_v_fli) > ((0)))){ goto b_L3406; }
		/* line 3402 */
b_L3402: ;
		b_v_ipi=((b_v_ipi)+((1)));
		if(-((b_v_ipi) >= ((15)))){
			b_v_ipi=(0);
			b_v_pui=(((1))-(b_v_pui));
		}
		/* line 3403 */
b_L3403: ;
		b_v_coi=(7);
		if(-((b_v_pui) == ((1)))){
			b_v_coi=(14);
		}
		/* line 3404 */
b_L3404: ;
		b_v_gxi=((b_v_pxi)-(b_v_vxi));
		b_v_gyi=((b_v_pyi)-(b_v_vyi));
		if((B_INT((B_INT((B_INT(-((b_v_gxi) >= ((0)))) & B_INT(-((b_v_gxi) <= ((39)))))) & B_INT(-((b_v_gyi) >= ((0)))))) & B_INT(-((b_v_gyi) <= ((22)))))){
			b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_coi);
		}
		/* line 3405 */
b_L3405: ;
		goto b_L3408;
		/* line 3406 */
b_L3406: ;
		b_v_fli=((b_v_fli)-((1)));
		if(-((b_v_fli) == ((0)))){
			b_v_pci=(7);
		}
		/* line 3407 */
b_L3407: ;
		b_gosubStack[b_gosubSP++]=55; goto b_L3700;
b_ret55: ;
		/* line 3408 */
b_L3408: ;
		if(-((b_v_bfi) > ((0)))){
			b_v_bfi=((b_v_bfi)-((1)));
			if(-((b_v_bfi) == ((0)))){
				b_v_bci=(0);
			}
		}
		/* line 3409 */
b_L3409: ;
		if(-((b_v_hpi) <= ((0)))){ goto b_L3413; }
		/* line 3410 */
b_L3410: ;
		if(-((((b_v_hpi)*((3)))) >= (b_v_mai))){ goto b_L3413; }
		/* line 3411 */
b_L3411: ;
		b_v_ppi=((b_v_ppi)+((1)));
		if(-((b_v_ppi) >= ((8)))){
			b_v_ppi=(0);
			b_v_phi=(((2))-(b_v_phi));
		}
		/* line 3412 */
b_L3412: ;
		b_poke((53280.0),b_v_phi);
		goto b_return;
		/* line 3413 */
b_L3413: ;
		b_poke((53280.0),(B_INT(((b_v_dei)+((5)))) & B_INT((15))));
		goto b_return;
		/* line 3500 */
b_L3500: ;
		b_v_gxi=((b_v_jxi)-(b_v_vxi));
		b_v_gyi=((b_v_jyi)-(b_v_vyi));
		if((B_INT((B_INT((B_INT(-((b_v_gxi) < ((0)))) | B_INT(-((b_v_gxi) > ((39)))))) | B_INT(-((b_v_gyi) < ((0)))))) | B_INT(-((b_v_gyi) > ((22)))))){
			b_v_hti=(0);
			goto b_return;
		}
		/* line 3501 */
b_L3501: ;
		b_v_cxi=b_v_gxi;
		b_v_tyi=b_v_gyi;
		b_v_ni=b_v_hvi;
		b_gosubStack[b_gosubSP++]=56; goto b_L5300;
b_ret56: ;
		b_v_hei=((b_v_cxi)-((1)));
		/* line 3502 */
b_L3502: ;
		b_v_ji=b_v_gxi;
		b_fl_29=b_v_hei;
		if(b_v_ji > b_fl_29) goto b_f29_e;
		b_v_M3=((b_v_gyi)*((40)));
		b_t_19=(((((55296.0))+(b_v_M3)))+(b_v_ji));
b_f29_t: ;
		b_poke(b_t_19,(2));
		b_t_19 += 1;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_29)) goto b_f29_t;
b_f29_e: ;
		/* line 3503 */
b_L3503: ;
		goto b_return;
		/* line 3600 */
b_L3600: ;
		if(-((b_a_ohi[B_INT(b_v_hmi)]) > ((0)))){
			if(-((b_a_oxi[B_INT(b_v_hmi)]) == (b_v_jxi))){
				if(-((b_a_oyi[B_INT(b_v_hmi)]) == (b_v_jyi))){ goto b_L3602; }
			}
		}
		/* line 3601 */
b_L3601: ;
		b_v_wxi=b_v_jxi;
		b_v_wyi=b_v_jyi;
		b_gosubStack[b_gosubSP++]=57; goto b_L1000;
b_ret57: ;
		goto b_L3604;
		/* line 3602 */
b_L3602: ;
		b_v_gxi=((b_v_jxi)-(b_v_vxi));
		b_v_gyi=((b_v_jyi)-(b_v_vyi));
		if((B_INT((B_INT((B_INT(-((b_v_gxi) < ((0)))) | B_INT(-((b_v_gxi) > ((39)))))) | B_INT(-((b_v_gyi) < ((0)))))) | B_INT(-((b_v_gyi) > ((22)))))){
			goto b_return;
		}
		/* line 3603 */
b_L3603: ;
		b_poke((((((1024))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_a_oci[B_INT(b_a_oti[B_INT(b_v_hmi)])]);
		b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),(2));
		/* line 3604 */
b_L3604: ;
		if(-((b_v_hei) > (b_v_gxi))){
			b_v_wxi=((b_v_jxi)+((1)));
			b_v_wyi=b_v_jyi;
			b_gosubStack[b_gosubSP++]=58; goto b_L1000;
b_ret58: ;
		}
		/* line 3605 */
b_L3605: ;
		goto b_return;
		/* line 3700 */
b_L3700: ;
		b_v_gxi=((b_v_pxi)-(b_v_vxi));
		b_v_gyi=((b_v_pyi)-(b_v_vyi));
		if((B_INT((B_INT((B_INT(-((b_v_gxi) < ((0)))) | B_INT(-((b_v_gxi) > ((39)))))) | B_INT(-((b_v_gyi) < ((0)))))) | B_INT(-((b_v_gyi) > ((22)))))){
			goto b_return;
		}
		/* line 3701 */
b_L3701: ;
		b_poke((((((1024))+(((b_v_gyi)*((40))))))+(b_v_gxi)),(0));
		b_poke((((((55296.0))+(((b_v_gyi)*((40))))))+(b_v_gxi)),b_v_pci);
		goto b_return;
		/* line 3800 */
b_L3800: ;
		b_v_dei=((b_v_dei)+((1)));
		b_v_mgi=(6);
		b_v_sni=(5);
		b_gosubStack[b_gosubSP++]=59; goto b_L6000;
b_ret59: ;
		/* line 3801 */
b_L3801: ;
		b_gosubStack[b_gosubSP++]=60; goto b_L4100;
b_ret60: ;
		/* line 3802 */
b_L3802: ;
		b_gosubStack[b_gosubSP++]=61; goto b_L5600;
b_ret61: ;
		/* line 3803 */
b_L3803: ;
		b_v_bci=(2);
		b_v_bfi=(8);
		b_v_gi=((((b_v_lei)*((2))))+((3)));
		b_v_hpi=((b_v_hpi)+(b_v_gi));
		if(-((b_v_hpi) > (b_v_mai))){
			b_v_hpi=b_v_mai;
		}
		/* line 3804 */
b_L3804: ;
		goto b_return;
		/* line 3900 */
b_L3900: ;
		if(-((b_v_dei) <= ((1)))){
			b_v_mgi=(7);
			goto b_return;
		}
		/* line 3901 */
b_L3901: ;
		b_v_dei=((b_v_dei)-((1)));
		b_v_mgi=(8);
		b_v_sni=(6);
		b_gosubStack[b_gosubSP++]=62; goto b_L6000;
b_ret62: ;
		/* line 3902 */
b_L3902: ;
		b_gosubStack[b_gosubSP++]=63; goto b_L4100;
b_ret63: ;
		/* line 3903 */
b_L3903: ;
		b_gosubStack[b_gosubSP++]=64; goto b_L5600;
b_ret64: ;
		/* line 3904 */
b_L3904: ;
		goto b_return;
		/* line 4000 */
b_L4000: ;
		if(-((b_v_foi) < ((50)))){
			b_v_mgi=(9);
			goto b_return;
		}
		/* line 4001 */
b_L4001: ;
		b_v_foi=((b_v_foi)-((50)));
		if(-((b_v_hpi) < (b_v_mai))){
			b_v_bci=(2);
			b_v_bfi=(8);
			b_v_hpi=((b_v_hpi)+((5)));
			if(-((b_v_hpi) > (b_v_mai))){
				b_v_hpi=b_v_mai;
			}
		}
		/* line 4002 */
b_L4002: ;
		b_v_mgi=(10);
		/* line 4003 */
b_L4003: ;
		goto b_return;
		/* line 4100 */
b_L4100: ;
		b_v_txi=(15);
		b_v_tyi=(12);
		b_v_ts=b_keep(b_lit("LOADING",7));
		b_gosubStack[b_gosubSP++]=65; goto b_L4700;
b_ret65: ;
		/* line 4101 */
b_L4101: ;
		b_v_ji=(0);
		if(b_v_ji > 9) goto b_f30_e;
		b_t_20=(((((((55296.0))+((480))))+((15))))+(b_v_ji));
b_f30_t: ;
		b_poke(b_t_20,(7));
		b_t_20 += 1;
		b_v_ji += 1;
		if(b_v_ji <= 9) goto b_f30_t;
b_f30_e: ;
		/* line 4102 */
b_L4102: ;
		goto b_return;
		/* line 4200 */
b_L4200: ;
		b_v_ii=(1);
		b_fl_31=b_v_nii;
		if(b_v_ii > b_fl_31) goto b_f31_e;
b_f31_t: ;
		if(-((b_a_iti[B_INT(b_v_ii)]) == ((0)))){ goto b_L4215; }
		/* line 4201 */
b_L4201: ;
		if(-((b_a_ixi[B_INT(b_v_ii)]) != (b_v_pxi))){ goto b_L4215; }
		/* line 4202 */
b_L4202: ;
		if(-((b_a_iyi[B_INT(b_v_ii)]) != (b_v_pyi))){ goto b_L4215; }
		/* line 4203 */
b_L4203: ;
		b_v_ti=b_a_iti[B_INT(b_v_ii)];
		/* line 4204 */
b_L4204: ;
		if(-((b_v_ti) == ((1)))){
			b_v_goi=((b_v_goi)+(b_a_ivi[B_INT(b_v_ii)]));
			b_v_mgi=(11);
			b_v_ami=b_a_ivi[B_INT(b_v_ii)];
			goto b_L4214;
		}
		/* line 4205 */
b_L4205: ;
		if(-((b_v_ti) == ((2)))){
			b_v_foi=((b_v_foi)+(b_a_ivi[B_INT(b_v_ii)]));
			b_v_mgi=(12);
			goto b_L4214;
		}
		/* line 4206 */
b_L4206: ;
		if(-((b_v_ti) == ((3)))){
			b_v_bci=(2);
			b_v_bfi=(8);
			b_v_hpi=b_v_mai;
			b_v_mgi=(13);
			goto b_L4214;
		}
		/* line 4207 */
b_L4207: ;
		if(-((b_v_ti) == ((4)))){
			if(-((b_a_ivi[B_INT(b_v_ii)]) > (b_v_wei))){
				b_v_wei=b_a_ivi[B_INT(b_v_ii)];
				b_v_ami=((b_v_ati)+(b_v_wei));
				b_v_mgi=(14);
				goto b_L4214;
			}
		}
		/* line 4208 */
b_L4208: ;
		if(-((b_v_ti) == ((4)))){
			b_v_ami=((b_v_ati)+(b_v_wei));
			b_v_mgi=(15);
			goto b_L4214;
		}
		/* line 4209 */
b_L4209: ;
		if(-((b_v_ti) == ((5)))){
			if(-((b_a_ivi[B_INT(b_v_ii)]) > (b_v_ari))){
				b_v_ari=b_a_ivi[B_INT(b_v_ii)];
				b_v_ami=b_v_ari;
				b_v_mgi=(16);
				goto b_L4214;
			}
		}
		/* line 4210 */
b_L4210: ;
		if(-((b_v_ti) == ((5)))){
			b_v_ami=b_v_ari;
			b_v_mgi=(17);
		}
		/* line 4211 */
b_L4211: ;
		if(-((b_v_ti) == ((6)))){
			b_v_bci=(2);
			b_v_bfi=(8);
			b_v_hpi=((b_v_hpi)+((15)));
			b_v_mgi=(21);
			if(-((b_v_hpi) > (b_v_mai))){
				b_v_hpi=b_v_mai;
			}
		}
		/* line 4212 */
b_L4212: ;
		if(-((b_v_ti) == ((7)))){
			b_v_pii=((b_v_pii)+(b_a_ivi[B_INT(b_v_ii)]));
			b_v_mgi=(24);
			b_v_ami=b_a_ivi[B_INT(b_v_ii)];
			goto b_L4214;
		}
		/* line 4213 */
b_L4213: ;
		if(-((b_v_ti) == ((8)))){ goto b_L4215; }
		/* line 4214 */
b_L4214: ;
		b_a_iti[B_INT(b_v_ii)]=(0);
		goto b_return;
		/* line 4215 */
b_L4215: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_31)) goto b_f31_t;
b_f31_e: ;
		/* line 4216 */
b_L4216: ;
		goto b_return;
		/* line 4300 */
b_L4300: ;
		b_v_ii=(1);
		b_fl_32=b_v_nii;
		if(b_v_ii > b_fl_32) goto b_f32_e;
		{ b_rtfor_t _f; _f.top_id=32; _f.pI=&b_v_ii; _f.vtype=0; _f.lim.i=b_fl_32; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f32_t: ;
		if(-((b_a_iti[B_INT(b_v_ii)]) == ((0)))){ goto b_L4304; }
		/* line 4301 */
b_L4301: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_32)) goto b_f32_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f32_e: ;
		/* line 4302 */
b_L4302: ;
		if(-((b_v_nii) < ((16)))){
			b_v_nii=((b_v_nii)+((1)));
			b_v_ii=b_v_nii;
			goto b_L4304;
		}
		/* line 4303 */
b_L4303: ;
		b_v_wxi=b_a_oxi[B_INT(b_v_mii)];
		b_v_wyi=b_a_oyi[B_INT(b_v_mii)];
		b_gosubStack[b_gosubSP++]=66; goto b_L1000;
b_ret66: ;
		b_v_gi=(((1))+(((b_int(((b_rnd(B_INT((1))))*((10)))))*(((b_v_dei)+((1)))))));
		b_v_goi=((b_v_goi)+(b_v_gi));
		goto b_return;
		/* line 4304 */
b_L4304: ;
		b_v_lzi=b_int(((b_rnd(B_INT((1))))*((100))));
		b_a_iti[B_INT(b_v_ii)]=(1);
		/* line 4305 */
b_L4305: ;
		if(-((b_v_lzi) >= ((55)))){
			b_a_iti[B_INT(b_v_ii)]=(2);
		}
		/* line 4306 */
b_L4306: ;
		if(-((b_v_lzi) >= ((70)))){
			b_a_iti[B_INT(b_v_ii)]=(3);
		}
		/* line 4307 */
b_L4307: ;
		if(-((b_v_lzi) >= ((80)))){
			b_a_iti[B_INT(b_v_ii)]=(6);
		}
		/* line 4308 */
b_L4308: ;
		if(-((b_v_lzi) >= ((90)))){
			b_a_iti[B_INT(b_v_ii)]=(4);
		}
		/* line 4309 */
b_L4309: ;
		if(-((b_v_lzi) >= ((97)))){
			b_a_iti[B_INT(b_v_ii)]=(5);
		}
		/* line 4310 */
b_L4310: ;
		if(-((b_v_lzi) >= ((99)))){
			b_a_iti[B_INT(b_v_ii)]=(7);
		}
		/* line 4311 */
b_L4311: ;
		b_a_ixi[B_INT(b_v_ii)]=b_a_oxi[B_INT(b_v_mii)];
		b_a_iyi[B_INT(b_v_ii)]=b_a_oyi[B_INT(b_v_mii)];
		b_a_ivi[B_INT(b_v_ii)]=(0);
		/* line 4312 */
b_L4312: ;
		switch(b_a_iti[B_INT(b_v_ii)]){
			case 1: goto b_L4313; break;
			case 2: goto b_L4314; break;
			case 3: goto b_L4315; break;
			case 4: goto b_L4316; break;
			case 5: goto b_L4317; break;
			case 6: goto b_L4318; break;
			case 7: goto b_L4319; break;
			default: break;}
		/* line 4313 */
b_L4313: ;
		b_a_ivi[B_INT(b_v_ii)]=(((5))+(((b_int(((b_rnd(B_INT((1))))*((20)))))*(((b_v_dei)+((1)))))));
		goto b_L4320;
		/* line 4314 */
b_L4314: ;
		b_a_ivi[B_INT(b_v_ii)]=(40);
		goto b_L4320;
		/* line 4315 */
b_L4315: ;
		b_a_ivi[B_INT(b_v_ii)]=(0);
		goto b_L4320;
		/* line 4316 */
b_L4316: ;
		b_a_ivi[B_INT(b_v_ii)]=(((((1))+(b_int(((b_rnd(B_INT((1))))*((3)))))))+(b_int(((breal_t)(b_v_dei)/(breal_t)((3))))));
		goto b_L4320;
		/* line 4317 */
b_L4317: ;
		b_a_ivi[B_INT(b_v_ii)]=(((((1))+(b_int(((b_rnd(B_INT((1))))*((2)))))))+(b_int(((breal_t)(b_v_dei)/(breal_t)((4))))));
		goto b_L4320;
		/* line 4318 */
b_L4318: ;
		b_a_ivi[B_INT(b_v_ii)]=(1);
		goto b_L4320;
		/* line 4319 */
b_L4319: ;
		b_a_ivi[B_INT(b_v_ii)]=(10);
		/* line 4320 */
b_L4320: ;
		b_v_wxi=b_a_ixi[B_INT(b_v_ii)];
		b_v_wyi=b_a_iyi[B_INT(b_v_ii)];
		b_gosubStack[b_gosubSP++]=67; goto b_L1000;
b_ret67: ;
		goto b_return;
		/* line 4400 */
b_L4400: ;
		if(-((b_v_pii) <= ((0)))){
			b_v_mgi=(18);
			goto b_return;
		}
		/* line 4401 */
b_L4401: ;
		b_poke((((((49152.0))+(((b_v_nyi)*((64))))))+(b_v_nxi)),(46));
		b_v_pii=((b_v_pii)-((1)));
		b_v_mgi=(23);
		b_v_ami=b_v_pii;
		b_v_ti=(46);
		goto b_return;
		/* line 4500 */
b_L4500: ;
		b_v_sni=(3);
		b_gosubStack[b_gosubSP++]=68; goto b_L6000;
b_ret68: ;
		b_putc(147);
		b_nl();
		b_gosubStack[b_gosubSP++]=69; goto b_L4600;
b_ret69: ;
		b_nl();
		/* line 4501 */
b_L4501: ;
		{ bstr_t _t=b_lit("SHOP $",6); b_str(_t.p,_t.len); }
		b_putint(b_v_goi);
		b_nl();
		/* line 4502 */
b_L4502: ;
		b_nl();
		/* line 4503 */
b_L4503: ;
		{ bstr_t _t=b_lit("1 FOOD   20$",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4504 */
b_L4504: ;
		{ bstr_t _t=b_lit("2 HEAL  100$",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4505 */
b_L4505: ;
		{ bstr_t _t=b_lit("3 +ATK  200$",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4506 */
b_L4506: ;
		{ bstr_t _t=b_lit("4 +DEF  200$",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4507 */
b_L4507: ;
		{ bstr_t _t=b_lit("5 PICKAXE 150$",14); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4508 */
b_L4508: ;
		{ bstr_t _t=b_lit("X LEAVE",7); b_str(_t.p,_t.len); }
		b_nl();
		/* line 4509 */
b_L4509: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L4509; }
		/* line 4510 */
b_L4510: ;
		if(-(b_strcmp(b_v_ks,b_lit("X",1)) == 0)){ goto b_L4517; }
		/* line 4511 */
b_L4511: ;
		if(-(b_strcmp(b_v_ks,b_lit("1",1)) == 0)){
			if(-((b_v_goi) >= ((20)))){
				b_v_goi=((b_v_goi)-((20)));
				b_v_foi=((b_v_foi)+((40)));
				b_v_mgi=(12);
				goto b_L4500;
			}
		}
		/* line 4512 */
b_L4512: ;
		if(-(b_strcmp(b_v_ks,b_lit("2",1)) == 0)){
			if(-((b_v_goi) >= ((100)))){
				b_v_goi=((b_v_goi)-((100)));
				b_v_hpi=b_v_mai;
				b_v_mgi=(13);
				goto b_L4500;
			}
		}
		/* line 4513 */
b_L4513: ;
		if(-(b_strcmp(b_v_ks,b_lit("3",1)) == 0)){
			if(-((b_v_goi) >= ((200)))){
				b_v_goi=((b_v_goi)-((200)));
				b_v_ati=((b_v_ati)+((1)));
				b_v_ami=b_v_ati;
				b_v_mgi=(25);
				goto b_L4500;
			}
		}
		/* line 4514 */
b_L4514: ;
		if(-(b_strcmp(b_v_ks,b_lit("4",1)) == 0)){
			if(-((b_v_goi) >= ((200)))){
				b_v_goi=((b_v_goi)-((200)));
				b_v_ari=((b_v_ari)+((1)));
				b_v_ami=b_v_ari;
				b_v_mgi=(26);
				goto b_L4500;
			}
		}
		/* line 4515 */
b_L4515: ;
		if(-(b_strcmp(b_v_ks,b_lit("5",1)) == 0)){
			if(-((b_v_goi) >= ((150)))){
				b_v_goi=((b_v_goi)-((150)));
				b_v_pii=((b_v_pii)+((10)));
				b_v_ami=(10);
				b_v_mgi=(24);
				goto b_L4500;
			}
		}
		/* line 4516 */
b_L4516: ;
		b_v_mgi=(27);
		/* line 4517 */
b_L4517: ;
		b_v_sni=(3);
		b_gosubStack[b_gosubSP++]=70; goto b_L6000;
b_ret70: ;
		b_gosubStack[b_gosubSP++]=71; goto b_L1400;
b_ret71: ;
		b_gosubStack[b_gosubSP++]=72; goto b_L1300;
b_ret72: ;
		goto b_return;
		/* line 4600 */
b_L4600: ;
		b_poke((1024),(104));
		b_poke((1045),(105));
		b_poke((1384),(106));
		b_poke((1405),(107));
		/* line 4601 */
b_L4601: ;
		b_v_ji=(1);
		if(b_v_ji > 20) goto b_f33_e;
b_f33_t: ;
		b_poke((((1024))+(b_v_ji)),(98));
		b_v_ji += 1;
		if(b_v_ji <= 20) goto b_f33_t;
b_f33_e: ;
		b_v_ji=(1);
		if(b_v_ji > 20) goto b_f34_e;
b_f34_t: ;
		b_poke((((1384))+(b_v_ji)),(98));
		b_v_ji += 1;
		if(b_v_ji <= 20) goto b_f34_t;
b_f34_e: ;
		/* line 4602 */
b_L4602: ;
		goto b_return;
		/* line 4700 */
b_L4700: ;
		b_v_ji=(1);
		b_fl_35=B_INT(b_len(b_v_ts));
		if(b_v_ji > b_fl_35) goto b_f35_e;
		b_v_M4=(((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi));
		b_t_22=((((b_v_M4)+(b_v_ji)))-((1)));
b_f35_t: ;
		/* line 4701 */
b_L4701: ;
		b_v_chi=b_asc(b_mid(b_v_ts,B_INT(b_v_ji),B_INT((1))));
		/* line 4702 */
b_L4702: ;
		if((B_INT(-((b_v_chi) >= ((64)))) & B_INT(-((b_v_chi) <= ((95)))))){
			b_v_chi=((b_v_chi)-((64)));
		}
		/* line 4703 */
b_L4703: ;
		b_poke(b_t_22,b_v_chi);
		/* line 4704 */
b_L4704: ;
		b_t_22 += 1;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_35)) goto b_f35_t;
b_f35_e: ;
		/* line 4705 */
b_L4705: ;
		goto b_return;
		/* line 4800 */
b_L4800: ;
		if(-((b_v_foi) < ((200)))){
			b_v_cci=(7);
		}
		/* line 4801 */
b_L4801: ;
		if(-((b_v_foi) < ((100)))){
			b_v_cci=(8);
		}
		/* line 4802 */
b_L4802: ;
		if(-((b_v_foi) < ((50)))){
			if(-((b_v_fti) < ((4)))){
				b_v_cci=(2);
			}
		}
		/* line 4803 */
b_L4803: ;
		goto b_return;
		/* line 4900 */
b_L4900: ;
		b_v_cxi=(0);
		b_v_tyi=(24);
		/* line 4901 */
b_L4901: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(5);
		if(-((b_v_bci) == ((1)))){
			b_v_cci=(2);
		}
		/* line 4902 */
b_L4902: ;
		if(-((b_v_bci) == ((2)))){
			b_v_cci=(13);
		}
		/* line 4903 */
b_L4903: ;
		b_v_ts=b_keep(b_lit("HP ",3));
		b_gosubStack[b_gosubSP++]=73; goto b_L5200;
b_ret73: ;
		b_v_ni=b_v_hpi;
		b_gosubStack[b_gosubSP++]=74; goto b_L5300;
b_ret74: ;
		b_gosubStack[b_gosubSP++]=75; goto b_L5500;
b_ret75: ;
		/* line 4904 */
b_L4904: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(12);
		b_v_ts=b_keep(b_lit("/ ",2));
		b_gosubStack[b_gosubSP++]=76; goto b_L5200;
b_ret76: ;
		b_v_ni=b_v_mai;
		b_gosubStack[b_gosubSP++]=77; goto b_L5300;
b_ret77: ;
		b_gosubStack[b_gosubSP++]=78; goto b_L5500;
b_ret78: ;
		/* line 4905 */
b_L4905: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(7);
		b_v_ts=b_keep(b_lit(" L",2));
		b_gosubStack[b_gosubSP++]=79; goto b_L5200;
b_ret79: ;
		b_v_ni=b_v_lei;
		b_gosubStack[b_gosubSP++]=80; goto b_L5300;
b_ret80: ;
		b_gosubStack[b_gosubSP++]=81; goto b_L5500;
b_ret81: ;
		/* line 4906 */
b_L4906: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(5);
		b_v_ts=b_keep(b_lit(" A",2));
		b_gosubStack[b_gosubSP++]=82; goto b_L5200;
b_ret82: ;
		b_v_ni=((b_v_ati)+(b_v_wei));
		b_gosubStack[b_gosubSP++]=83; goto b_L5300;
b_ret83: ;
		b_gosubStack[b_gosubSP++]=84; goto b_L5500;
b_ret84: ;
		/* line 4907 */
b_L4907: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(2);
		b_v_ts=b_keep(b_lit(" D",2));
		b_gosubStack[b_gosubSP++]=85; goto b_L5200;
b_ret85: ;
		b_v_ni=b_v_ari;
		b_gosubStack[b_gosubSP++]=86; goto b_L5300;
b_ret86: ;
		b_gosubStack[b_gosubSP++]=87; goto b_L5500;
b_ret87: ;
		/* line 4908 */
b_L4908: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(8);
		b_v_ts=b_keep(b_lit(" $",2));
		b_gosubStack[b_gosubSP++]=88; goto b_L5200;
b_ret88: ;
		b_v_ni=b_v_goi;
		b_gosubStack[b_gosubSP++]=89; goto b_L5300;
b_ret89: ;
		b_gosubStack[b_gosubSP++]=90; goto b_L5500;
b_ret90: ;
		/* line 4909 */
b_L4909: ;
		b_v_sci=b_v_cxi;
		b_v_cci=(5);
		b_gosubStack[b_gosubSP++]=91; goto b_L4800;
b_ret91: ;
		b_v_ts=b_keep(b_lit("% ",2));
		b_gosubStack[b_gosubSP++]=92; goto b_L5200;
b_ret92: ;
		b_v_ni=b_v_foi;
		b_gosubStack[b_gosubSP++]=93; goto b_L5300;
b_ret93: ;
		b_gosubStack[b_gosubSP++]=94; goto b_L5500;
b_ret94: ;
		/* line 4910 */
b_L4910: ;
		b_v_mci=b_v_cxi;
		b_gosubStack[b_gosubSP++]=95; goto b_L5000;
b_ret95: ;
		/* line 4911 */
b_L4911: ;
		if(-((b_v_cxi) < ((40)))){
			b_v_ji=b_v_cxi;
			if(b_v_ji > 39) goto b_f36_e;
			b_t_23=(((1984))+(b_v_ji));
b_f36_t: ;
			b_poke(b_t_23,(32));
			b_t_23 += 1;
			b_v_ji += 1;
			if(b_v_ji <= 39) goto b_f36_t;
b_f36_e: ;
		}
		/* line 4912 */
b_L4912: ;
		if(-((b_v_mci) < ((40)))){
			b_v_ji=b_v_mci;
			if(b_v_ji > 39) goto b_f37_e;
			b_t_24=(((56256.0))+(b_v_ji));
b_f37_t: ;
			b_poke(b_t_24,(3));
			b_t_24 += 1;
			b_v_ji += 1;
			if(b_v_ji <= 39) goto b_f37_t;
b_f37_e: ;
		}
		/* line 4913 */
b_L4913: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		switch(b_v_mgi){
			case 1: goto b_L5001; break;
			case 2: goto b_L5002; break;
			case 3: goto b_L5003; break;
			case 4: goto b_L5004; break;
			case 5: goto b_L5005; break;
			case 6: goto b_L5006; break;
			case 7: goto b_L5007; break;
			case 8: goto b_L5008; break;
			case 9: goto b_L5009; break;
			case 10: goto b_L5010; break;
			case 11: goto b_L5011; break;
			case 12: goto b_L5012; break;
			case 13: goto b_L5013; break;
			case 14: goto b_L5014; break;
			case 15: goto b_L5015; break;
			case 16: goto b_L5016; break;
			case 17: goto b_L5017; break;
			case 18: goto b_L5018; break;
			case 19: goto b_L5019; break;
			case 20: goto b_L5023; break;
			case 21: goto b_L5024; break;
			case 22: goto b_L5025; break;
			case 23: goto b_L5026; break;
			case 24: goto b_L5027; break;
			case 25: goto b_L5020; break;
			case 26: goto b_L5021; break;
			case 27: goto b_L5022; break;
			default: break;}
		/* line 5001 */
b_L5001: ;
		b_v_ts=b_keep(b_lit("HIT ",4));
		b_gosubStack[b_gosubSP++]=96; goto b_L5200;
b_ret96: ;
		b_gosubStack[b_gosubSP++]=97; goto b_L5100;
b_ret97: ;
		b_v_ts=b_keep(b_lit(" - ",3));
		b_gosubStack[b_gosubSP++]=98; goto b_L5200;
b_ret98: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=99; goto b_L5300;
b_ret99: ;
		goto b_return;
		/* line 5002 */
b_L5002: ;
		b_v_ts=b_keep(b_lit("SLAY ",5));
		b_gosubStack[b_gosubSP++]=100; goto b_L5200;
b_ret100: ;
		b_gosubStack[b_gosubSP++]=101; goto b_L5100;
b_ret101: ;
		goto b_return;
		/* line 5003 */
b_L5003: ;
		b_gosubStack[b_gosubSP++]=102; goto b_L5100;
b_ret102: ;
		b_v_ts=b_keep(b_lit(" - ",3));
		b_gosubStack[b_gosubSP++]=103; goto b_L5200;
b_ret103: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=104; goto b_L5300;
b_ret104: ;
		goto b_return;
		/* line 5004 */
b_L5004: ;
		b_v_ts=b_keep(b_lit("LEVEL UP!",9));
		b_gosubStack[b_gosubSP++]=105; goto b_L5200;
b_ret105: ;
		goto b_return;
		/* line 5005 */
b_L5005: ;
		b_v_ts=b_keep(b_lit("STARVING",8));
		b_gosubStack[b_gosubSP++]=106; goto b_L5200;
b_ret106: ;
		goto b_return;
		/* line 5006 */
b_L5006: ;
		b_v_ts=b_keep(b_lit("NEW LEVEL",9));
		b_gosubStack[b_gosubSP++]=107; goto b_L5200;
b_ret107: ;
		goto b_return;
		/* line 5007 */
b_L5007: ;
		b_v_ts=b_keep(b_lit("TOP FLOOR",9));
		b_gosubStack[b_gosubSP++]=108; goto b_L5200;
b_ret108: ;
		goto b_return;
		/* line 5008 */
b_L5008: ;
		b_v_ts=b_keep(b_lit("ASCEND",6));
		b_gosubStack[b_gosubSP++]=109; goto b_L5200;
b_ret109: ;
		goto b_return;
		/* line 5009 */
b_L5009: ;
		b_v_ts=b_keep(b_lit("NO FOOD",7));
		b_gosubStack[b_gosubSP++]=110; goto b_L5200;
b_ret110: ;
		goto b_return;
		/* line 5010 */
b_L5010: ;
		b_v_ts=b_keep(b_lit("EAT +5HP",8));
		b_gosubStack[b_gosubSP++]=111; goto b_L5200;
b_ret111: ;
		goto b_return;
		/* line 5011 */
b_L5011: ;
		b_v_ts=b_keep(b_lit("+$ ",3));
		b_gosubStack[b_gosubSP++]=112; goto b_L5200;
b_ret112: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=113; goto b_L5300;
b_ret113: ;
		goto b_return;
		/* line 5012 */
b_L5012: ;
		b_v_ts=b_keep(b_lit("+FOOD",5));
		b_gosubStack[b_gosubSP++]=114; goto b_L5200;
b_ret114: ;
		goto b_return;
		/* line 5013 */
b_L5013: ;
		b_v_ts=b_keep(b_lit("HEALED",6));
		b_gosubStack[b_gosubSP++]=115; goto b_L5200;
b_ret115: ;
		goto b_return;
		/* line 5014 */
b_L5014: ;
		b_v_ts=b_keep(b_lit("+WEAPON ATK ",12));
		b_gosubStack[b_gosubSP++]=116; goto b_L5200;
b_ret116: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=117; goto b_L5300;
b_ret117: ;
		goto b_return;
		/* line 5015 */
b_L5015: ;
		b_v_ts=b_keep(b_lit("WEAK ATK ",9));
		b_gosubStack[b_gosubSP++]=118; goto b_L5200;
b_ret118: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=119; goto b_L5300;
b_ret119: ;
		goto b_return;
		/* line 5016 */
b_L5016: ;
		b_v_ts=b_keep(b_lit("+ARMOR DEF ",11));
		b_gosubStack[b_gosubSP++]=120; goto b_L5200;
b_ret120: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=121; goto b_L5300;
b_ret121: ;
		goto b_return;
		/* line 5017 */
b_L5017: ;
		b_v_ts=b_keep(b_lit("WEAK DEF ",9));
		b_gosubStack[b_gosubSP++]=122; goto b_L5200;
b_ret122: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=123; goto b_L5300;
b_ret123: ;
		goto b_return;
		/* line 5018 */
b_L5018: ;
		b_v_ts=b_keep(b_lit("WALL",4));
		b_gosubStack[b_gosubSP++]=124; goto b_L5200;
b_ret124: ;
		goto b_return;
		/* line 5019 */
b_L5019: ;
		b_v_ts=b_keep(b_lit("SPC E I H O Q",13));
		b_gosubStack[b_gosubSP++]=125; goto b_L5200;
b_ret125: ;
		goto b_return;
		/* line 5020 */
b_L5020: ;
		b_v_ts=b_keep(b_lit("+ATK ",5));
		b_gosubStack[b_gosubSP++]=126; goto b_L5200;
b_ret126: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=127; goto b_L5300;
b_ret127: ;
		goto b_return;
		/* line 5021 */
b_L5021: ;
		b_v_ts=b_keep(b_lit("+DEF ",5));
		b_gosubStack[b_gosubSP++]=128; goto b_L5200;
b_ret128: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=129; goto b_L5300;
b_ret129: ;
		goto b_return;
		/* line 5022 */
b_L5022: ;
		b_v_ts=b_keep(b_lit("NO GOLD",7));
		b_gosubStack[b_gosubSP++]=130; goto b_L5200;
b_ret130: ;
		goto b_return;
		/* line 5023 */
b_L5023: ;
		b_v_ts=b_keep(b_lit("POTION",6));
		b_gosubStack[b_gosubSP++]=131; goto b_L5200;
b_ret131: ;
		goto b_return;
		/* line 5024 */
b_L5024: ;
		b_v_ts=b_keep(b_lit("+15HP",5));
		b_gosubStack[b_gosubSP++]=132; goto b_L5200;
b_ret132: ;
		goto b_return;
		/* line 5025 */
b_L5025: ;
		b_v_ts=b_keep(b_lit("NO POTION",9));
		b_gosubStack[b_gosubSP++]=133; goto b_L5200;
b_ret133: ;
		goto b_return;
		/* line 5026 */
b_L5026: ;
		b_v_ts=b_keep(b_lit("PICK ",5));
		b_gosubStack[b_gosubSP++]=134; goto b_L5200;
b_ret134: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=135; goto b_L5300;
b_ret135: ;
		goto b_return;
		/* line 5027 */
b_L5027: ;
		b_v_ts=b_keep(b_lit("+PICKAXE",8));
		b_gosubStack[b_gosubSP++]=136; goto b_L5200;
b_ret136: ;
		b_v_ni=b_v_ami;
		b_gosubStack[b_gosubSP++]=137; goto b_L5300;
b_ret137: ;
		goto b_return;
		/* line 5100 */
b_L5100: ;
		if(-((b_v_cxi) >= ((40)))){
			goto b_return;
		}
		/* line 5101 */
b_L5101: ;
		switch(b_v_mvi){
			case 1: goto b_L5102; break;
			case 2: goto b_L5103; break;
			case 3: goto b_L5104; break;
			case 4: goto b_L5105; break;
			case 5: goto b_L5106; break;
			case 6: goto b_L5107; break;
			case 7: goto b_L5109; break;
			default: break;}
		/* line 5102 */
b_L5102: ;
		b_v_ts=b_keep(b_lit("RAT",3));
		goto b_L5108;
		/* line 5103 */
b_L5103: ;
		b_v_ts=b_keep(b_lit("KOBOLD",6));
		goto b_L5108;
		/* line 5104 */
b_L5104: ;
		b_v_ts=b_keep(b_lit("ORC",3));
		goto b_L5108;
		/* line 5105 */
b_L5105: ;
		b_v_ts=b_keep(b_lit("TROLL",5));
		goto b_L5108;
		/* line 5106 */
b_L5106: ;
		b_v_ts=b_keep(b_lit("WRAITH",6));
		goto b_L5108;
		/* line 5107 */
b_L5107: ;
		b_v_ts=b_keep(b_lit("DRAGON",6));
		/* line 5108 */
b_L5108: ;
		b_gosubStack[b_gosubSP++]=138; goto b_L5200;
b_ret138: ;
		goto b_return;
		/* line 5109 */
b_L5109: ;
		b_v_ts=b_keep(b_lit("D-BOSS",6));
		goto b_L5108;
		/* line 5200 */
b_L5200: ;
		if(-((b_v_cxi) >= ((40)))){
			goto b_return;
		}
		/* line 5201 */
b_L5201: ;
		b_v_txi=b_v_cxi;
		b_gosubStack[b_gosubSP++]=139; goto b_L4700;
b_ret139: ;
		b_v_cxi=((b_v_cxi)+(B_INT(b_len(b_v_ts))));
		goto b_return;
		/* line 5300 */
b_L5300: ;
		if(-((b_v_ni) == ((0)))){
			b_poke((((((1024))+(((b_v_tyi)*((40))))))+(b_v_cxi)),(48));
			b_v_cxi=((b_v_cxi)+((1)));
			goto b_return;
		}
		/* line 5301 */
b_L5301: ;
		if(-((b_v_ni) >= ((10000)))){
			b_v_pwi=(10000);
			b_gosubStack[b_gosubSP++]=140; goto b_L5400;
b_ret140: ;
			b_v_pwi=(1000);
			b_gosubStack[b_gosubSP++]=141; goto b_L5400;
b_ret141: ;
			b_v_pwi=(100);
			b_gosubStack[b_gosubSP++]=142; goto b_L5400;
b_ret142: ;
			b_v_pwi=(10);
			b_gosubStack[b_gosubSP++]=143; goto b_L5400;
b_ret143: ;
			b_v_pwi=(1);
			b_gosubStack[b_gosubSP++]=144; goto b_L5400;
b_ret144: ;
			goto b_return;
		}
		/* line 5302 */
b_L5302: ;
		if(-((b_v_ni) >= ((1000)))){
			b_v_pwi=(1000);
			b_gosubStack[b_gosubSP++]=145; goto b_L5400;
b_ret145: ;
			b_v_pwi=(100);
			b_gosubStack[b_gosubSP++]=146; goto b_L5400;
b_ret146: ;
			b_v_pwi=(10);
			b_gosubStack[b_gosubSP++]=147; goto b_L5400;
b_ret147: ;
			b_v_pwi=(1);
			b_gosubStack[b_gosubSP++]=148; goto b_L5400;
b_ret148: ;
			goto b_return;
		}
		/* line 5303 */
b_L5303: ;
		if(-((b_v_ni) >= ((100)))){
			b_v_pwi=(100);
			b_gosubStack[b_gosubSP++]=149; goto b_L5400;
b_ret149: ;
			b_v_pwi=(10);
			b_gosubStack[b_gosubSP++]=150; goto b_L5400;
b_ret150: ;
			b_v_pwi=(1);
			b_gosubStack[b_gosubSP++]=151; goto b_L5400;
b_ret151: ;
			goto b_return;
		}
		/* line 5304 */
b_L5304: ;
		if(-((b_v_ni) >= ((10)))){
			b_v_pwi=(10);
			b_gosubStack[b_gosubSP++]=152; goto b_L5400;
b_ret152: ;
			b_v_pwi=(1);
			b_gosubStack[b_gosubSP++]=153; goto b_L5400;
b_ret153: ;
			goto b_return;
		}
		/* line 5305 */
b_L5305: ;
		b_v_pwi=(1);
		b_gosubStack[b_gosubSP++]=154; goto b_L5400;
b_ret154: ;
		goto b_return;
		/* line 5400 */
b_L5400: ;
		b_v_dgi=(0);
		/* line 5401 */
b_L5401: ;
		if(-((b_v_ni) < (b_v_pwi))){ goto b_L5403; }
		/* line 5402 */
b_L5402: ;
		b_v_ni=((b_v_ni)-(b_v_pwi));
		b_v_dgi=((b_v_dgi)+((1)));
		goto b_L5401;
		/* line 5403 */
b_L5403: ;
		b_poke((((((1024))+(((b_v_tyi)*((40))))))+(b_v_cxi)),(((48))+(b_v_dgi)));
		b_v_cxi=((b_v_cxi)+((1)));
		goto b_return;
		/* line 5500 */
b_L5500: ;
		if(-((b_v_sci) >= ((40)))){
			goto b_return;
		}
		/* line 5501 */
b_L5501: ;
		b_v_eci=b_v_cxi;
		if(-((b_v_eci) > ((40)))){
			b_v_eci=(40);
		}
		/* line 5502 */
b_L5502: ;
		if(-((b_v_eci) <= (b_v_sci))){
			goto b_return;
		}
		/* line 5503 */
b_L5503: ;
		b_v_ji=b_v_sci;
		b_fl_38=((b_v_eci)-((1)));
		if(b_v_ji > b_fl_38) goto b_f38_e;
		b_t_25=(((56256.0))+(b_v_ji));
b_f38_t: ;
		b_poke(b_t_25,b_v_cci);
		b_t_25 += 1;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_38)) goto b_f38_t;
b_f38_e: ;
		goto b_return;
		/* line 5600 */
b_L5600: ;
		b_v_ii=(0);
		if(b_v_ii > 4095) goto b_f39_e;
b_f39_t: ;
		b_poke((((49152.0))+(b_v_ii)),(0));
		b_v_ii += 1;
		if(b_v_ii <= 4095) goto b_f39_t;
b_f39_e: ;
		/* line 5601 */
b_L5601: ;
		b_v_nri=(((9))+(b_int(((b_rnd(B_INT((1))))*((4))))));
		if(-((b_v_nri) > ((12)))){
			b_v_nri=(12);
		}
		/* line 5602 */
b_L5602: ;
		b_v_ri=(1);
		b_fl_40=b_v_nri;
		if(b_v_ri > b_fl_40) goto b_f40_e;
b_f40_t: ;
		/* line 5603 */
b_L5603: ;
		b_a_rxi[B_INT(b_v_ri)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((58))))));
		b_a_ryi[B_INT(b_v_ri)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((58))))));
		/* line 5604 */
b_L5604: ;
		b_a_rwi[B_INT(b_v_ri)]=(((4))+(b_int(((b_rnd(B_INT((1))))*((6))))));
		b_a_rhi[B_INT(b_v_ri)]=(((3))+(b_int(((b_rnd(B_INT((1))))*((4))))));
		/* line 5605 */
b_L5605: ;
		if(-((((b_a_rxi[B_INT(b_v_ri)])+(b_a_rwi[B_INT(b_v_ri)]))) > ((62)))){
			b_a_rxi[B_INT(b_v_ri)]=(((62))-(b_a_rwi[B_INT(b_v_ri)]));
		}
		/* line 5606 */
b_L5606: ;
		if(-((((b_a_ryi[B_INT(b_v_ri)])+(b_a_rhi[B_INT(b_v_ri)]))) > ((62)))){
			b_a_ryi[B_INT(b_v_ri)]=(((62))-(b_a_rhi[B_INT(b_v_ri)]));
		}
		/* line 5607 */
b_L5607: ;
		if(-((b_a_rxi[B_INT(b_v_ri)]) < ((1)))){
			b_a_rxi[B_INT(b_v_ri)]=(1);
		}
		/* line 5608 */
b_L5608: ;
		if(-((b_a_ryi[B_INT(b_v_ri)]) < ((1)))){
			b_a_ryi[B_INT(b_v_ri)]=(1);
		}
		/* line 5609 */
b_L5609: ;
		b_v_yyi=b_a_ryi[B_INT(b_v_ri)];
		b_fl_41=((b_a_ryi[B_INT(b_v_ri)])+(b_a_rhi[B_INT(b_v_ri)]));
		if(b_v_yyi > b_fl_41) goto b_f41_e;
b_f41_t: ;
		/* line 5610 */
b_L5610: ;
		b_v_xxi=b_a_rxi[B_INT(b_v_ri)];
		b_fl_42=((b_a_rxi[B_INT(b_v_ri)])+(b_a_rwi[B_INT(b_v_ri)]));
		if(b_v_xxi > b_fl_42) goto b_f42_e;
		b_v_M5=((b_v_yyi)*((64)));
b_f42_t: ;
		/* line 5611 */
b_L5611: ;
		b_v_cii=((b_v_M5)+(b_v_xxi));
		b_poke((((49152.0))+(b_v_cii)),(46));
		/* line 5612 */
b_L5612: ;
		b_v_xxi += 1;
		if(b_v_xxi <= (b_fl_42)) goto b_f42_t;
b_f42_e: ;
		b_v_yyi += 1;
		if(b_v_yyi <= (b_fl_41)) goto b_f41_t;
b_f41_e: ;
		/* line 5613 */
b_L5613: ;
		if(-((b_v_ri) > ((1)))){
			b_gosubStack[b_gosubSP++]=155; goto b_L5700;
b_ret155: ;
		}
		/* line 5614 */
b_L5614: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_40)) goto b_f40_t;
b_f40_e: ;
		/* line 5615 */
b_L5615: ;
		b_v_pxi=((b_a_rxi[B_INT((1))])+(b_int(((breal_t)(b_a_rwi[B_INT((1))])/(breal_t)((2))))));
		b_v_pyi=((b_a_ryi[B_INT((1))])+(b_int(((breal_t)(b_a_rhi[B_INT((1))])/(breal_t)((2))))));
		/* line 5616 */
b_L5616: ;
		b_v_cii=((((b_a_ryi[B_INT((1))])*((64))))+(b_a_rxi[B_INT((1))]));
		b_poke((((49152.0))+(b_v_cii)),(60));
		/* line 5617 */
b_L5617: ;
		b_v_cii=((((((b_a_ryi[B_INT((1))])+(b_a_rhi[B_INT((1))])))*((64))))+(((b_a_rxi[B_INT((1))])+(b_a_rwi[B_INT((1))]))));
		b_poke((((49152.0))+(b_v_cii)),(62));
		/* line 5618 */
b_L5618: ;
		b_v_nmi=(((3))+(((b_v_dei)*((2)))));
		if(-((b_v_nmi) > ((15)))){
			b_v_nmi=(15);
		}
		/* line 5619 */
b_L5619: ;
		b_v_ii=(1);
		b_fl_43=b_v_nmi;
		if(b_v_ii > b_fl_43) goto b_f43_e;
		b_v_M6=((b_v_nri)-((1)));
		b_v_M7=((b_v_dei)+((1)));
		b_v_M8=((b_v_dei)*((3)));
b_f43_t: ;
		/* line 5620 */
b_L5620: ;
		b_v_rmi=(((2))+(b_int(((b_rnd(B_INT((1))))*(b_v_M6)))));
		/* line 5621 */
b_L5621: ;
		b_v_mti=(((1))+(b_int(((b_rnd(B_INT((1))))*(b_v_M7)))));
		if(-((b_v_mti) > ((6)))){
			b_v_mti=(6);
		}
		/* line 5622 */
b_L5622: ;
		b_a_oti[B_INT(b_v_ii)]=b_v_mti;
		b_a_ohi[B_INT(b_v_ii)]=((((b_a_obi[B_INT(b_v_mti)])+(b_v_M8)))-((1)));
		b_a_odi[B_INT(b_v_ii)]=b_a_osi[B_INT(b_v_mti)];
		/* line 5623 */
b_L5623: ;
		b_a_oxi[B_INT(b_v_ii)]=((b_a_rxi[B_INT(b_v_rmi)])+(b_int(((b_rnd(B_INT((1))))*(((b_a_rwi[B_INT(b_v_rmi)])+((1))))))));
		/* line 5624 */
b_L5624: ;
		b_a_oyi[B_INT(b_v_ii)]=((b_a_ryi[B_INT(b_v_rmi)])+(b_int(((b_rnd(B_INT((1))))*(((b_a_rhi[B_INT(b_v_rmi)])+((1))))))));
		/* line 5625 */
b_L5625: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_43)) goto b_f43_t;
b_f43_e: ;
		b_gosubStack[b_gosubSP++]=156; goto b_L5900;
b_ret156: ;
		/* line 5626 */
b_L5626: ;
		b_v_nii=(((6))+(b_int(((b_rnd(B_INT((1))))*((3))))));
		/* line 5627 */
b_L5627: ;
		b_v_ii=(1);
		b_fl_44=b_v_nii;
		if(b_v_ii > b_fl_44) goto b_f44_e;
b_f44_t: ;
		/* line 5628 */
b_L5628: ;
		b_a_ixi[B_INT(b_v_ii)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((62))))));
		b_a_iyi[B_INT(b_v_ii)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((62))))));
		/* line 5629 */
b_L5629: ;
		b_v_ppi=B_INT(b_peek((unsigned int)((((((49152.0))+(((b_a_iyi[B_INT(b_v_ii)])*((64))))))+(b_a_ixi[B_INT(b_v_ii)])))));
		if(-((b_v_ppi) != ((46)))){ goto b_L5628; }
		/* line 5630 */
b_L5630: ;
		b_a_iti[B_INT(b_v_ii)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((6))))));
		b_a_ivi[B_INT(b_v_ii)]=(0);
		/* line 5631 */
b_L5631: ;
		if(-((b_a_iti[B_INT(b_v_ii)]) < ((7)))){
			switch(b_a_iti[B_INT(b_v_ii)]){
				case 1: goto b_L5632; break;
				case 2: goto b_L5633; break;
				case 3: goto b_L5634; break;
				case 4: goto b_L5635; break;
				case 5: goto b_L5636; break;
				case 6: goto b_L5637; break;
				default: break;}
		}
		/* line 5632 */
b_L5632: ;
		b_a_ivi[B_INT(b_v_ii)]=(((5))+(((b_int(((b_rnd(B_INT((1))))*((20)))))*(((b_v_dei)+((1)))))));
		goto b_L5638;
		/* line 5633 */
b_L5633: ;
		b_a_ivi[B_INT(b_v_ii)]=(40);
		goto b_L5638;
		/* line 5634 */
b_L5634: ;
		b_a_ivi[B_INT(b_v_ii)]=(0);
		goto b_L5638;
		/* line 5635 */
b_L5635: ;
		b_a_ivi[B_INT(b_v_ii)]=(((((1))+(b_int(((b_rnd(B_INT((1))))*((3)))))))+(b_int(((breal_t)(b_v_dei)/(breal_t)((3))))));
		goto b_L5638;
		/* line 5636 */
b_L5636: ;
		b_a_ivi[B_INT(b_v_ii)]=(((((1))+(b_int(((b_rnd(B_INT((1))))*((2)))))))+(b_int(((breal_t)(b_v_dei)/(breal_t)((4))))));
		goto b_L5638;
		/* line 5637 */
b_L5637: ;
		b_a_ivi[B_INT(b_v_ii)]=(((((((10))+(b_int(((b_rnd(B_INT((1))))*((20)))))))+(b_v_dei)))+(b_v_dei));
		/* line 5638 */
b_L5638: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_44)) goto b_f44_t;
b_f44_e: ;
		/* line 5639 */
b_L5639: ;
		b_v_nii=((b_v_nii)+((1)));
		/* line 5640 */
b_L5640: ;
		b_a_ixi[B_INT(b_v_nii)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((62))))));
		b_a_iyi[B_INT(b_v_nii)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((62))))));
		/* line 5641 */
b_L5641: ;
		if(-((B_INT(b_peek((unsigned int)((((((49152.0))+(((b_a_iyi[B_INT(b_v_nii)])*((64))))))+(b_a_ixi[B_INT(b_v_nii)])))))) != ((46)))){ goto b_L5640; }
		/* line 5642 */
b_L5642: ;
		b_a_iti[B_INT(b_v_nii)]=(8);
		b_a_ivi[B_INT(b_v_nii)]=(0);
		/* line 5643 */
b_L5643: ;
		b_v_vxi=((b_v_pxi)-((20)));
		if(-((b_v_vxi) < ((0)))){
			b_v_vxi=(0);
		}
		/* line 5644 */
b_L5644: ;
		if(-((b_v_vxi) > ((24)))){
			b_v_vxi=(24);
		}
		/* line 5645 */
b_L5645: ;
		b_v_vyi=((b_v_pyi)-((11)));
		if(-((b_v_vyi) < ((0)))){
			b_v_vyi=(0);
		}
		/* line 5646 */
b_L5646: ;
		if(-((b_v_vyi) > ((41)))){
			b_v_vyi=(41);
		}
		/* line 5647 */
b_L5647: ;
		b_v_fti=(0);
		/* line 5648 */
b_L5648: ;
		b_poke((53280.0),(B_INT(((b_v_dei)+((5)))) & B_INT((15))));
		b_gosubStack[b_gosubSP++]=157; goto b_L1400;
b_ret157: ;
		b_gosubStack[b_gosubSP++]=158; goto b_L1300;
b_ret158: ;
		/* line 5649 */
b_L5649: ;
		goto b_return;
		/* line 5700 */
b_L5700: ;
		b_v_lxi=((b_a_rxi[B_INT(((b_v_ri)-((1))))])+(b_int(((breal_t)(b_a_rwi[B_INT(((b_v_ri)-((1))))])/(breal_t)((2))))));
		b_v_lyi=((b_a_ryi[B_INT(((b_v_ri)-((1))))])+(b_int(((breal_t)(b_a_rhi[B_INT(((b_v_ri)-((1))))])/(breal_t)((2))))));
		/* line 5701 */
b_L5701: ;
		b_v_hxi=((b_a_rxi[B_INT(b_v_ri)])+(b_int(((breal_t)(b_a_rwi[B_INT(b_v_ri)])/(breal_t)((2))))));
		b_v_hyi=((b_a_ryi[B_INT(b_v_ri)])+(b_int(((breal_t)(b_a_rhi[B_INT(b_v_ri)])/(breal_t)((2))))));
		/* line 5702 */
b_L5702: ;
		b_v_xi=b_v_lxi;
		b_v_yi=b_v_lyi;
		/* line 5703 */
b_L5703: ;
		b_v_cii=((((b_v_yi)*((64))))+(b_v_xi));
		b_poke((((49152.0))+(b_v_cii)),(46));
		/* line 5704 */
b_L5704: ;
		if(-((b_v_xi) == (b_v_hxi))){ goto b_L5707; }
		/* line 5705 */
b_L5705: ;
		if(-((b_v_xi) < (b_v_hxi))){
			b_v_xi=((b_v_xi)+((1)));
			goto b_L5703;
		}
		/* line 5706 */
b_L5706: ;
		b_v_xi=((b_v_xi)-((1)));
		goto b_L5703;
		/* line 5707 */
b_L5707: ;
		if(-((b_v_yi) == (b_v_hyi))){ goto b_L5710; }
		/* line 5708 */
b_L5708: ;
		if(-((b_v_yi) < (b_v_hyi))){
			b_v_yi=((b_v_yi)+((1)));
			goto b_L5703;
		}
		/* line 5709 */
b_L5709: ;
		b_v_yi=((b_v_yi)-((1)));
		goto b_L5703;
		/* line 5710 */
b_L5710: ;
		goto b_return;
		/* line 5800 */
b_L5800: ;
		b_a_oci[B_INT((1))]=(18);
		b_a_obi[B_INT((1))]=(4);
		b_a_oai[B_INT((1))]=(1);
		b_a_oei[B_INT((1))]=(2);
		b_a_osi[B_INT((1))]=(1);
		/* line 5801 */
b_L5801: ;
		b_a_oci[B_INT((2))]=(11);
		b_a_obi[B_INT((2))]=(8);
		b_a_oai[B_INT((2))]=(2);
		b_a_oei[B_INT((2))]=(4);
		b_a_osi[B_INT((2))]=(1);
		/* line 5802 */
b_L5802: ;
		b_a_oci[B_INT((3))]=(15);
		b_a_obi[B_INT((3))]=(14);
		b_a_oai[B_INT((3))]=(3);
		b_a_oei[B_INT((3))]=(8);
		b_a_osi[B_INT((3))]=(2);
		/* line 5803 */
b_L5803: ;
		b_a_oci[B_INT((4))]=(20);
		b_a_obi[B_INT((4))]=(22);
		b_a_oai[B_INT((4))]=(5);
		b_a_oei[B_INT((4))]=(16);
		b_a_osi[B_INT((4))]=(2);
		/* line 5804 */
b_L5804: ;
		b_a_oci[B_INT((5))]=(23);
		b_a_obi[B_INT((5))]=(18);
		b_a_oai[B_INT((5))]=(4);
		b_a_oei[B_INT((5))]=(24);
		b_a_osi[B_INT((5))]=(2);
		/* line 5805 */
b_L5805: ;
		b_a_oci[B_INT((6))]=(4);
		b_a_obi[B_INT((6))]=(40);
		b_a_oai[B_INT((6))]=(8);
		b_a_oei[B_INT((6))]=(50);
		b_a_osi[B_INT((6))]=(2);
		/* line 5806 */
b_L5806: ;
		b_a_ici[B_INT((1))]=(36);
		b_a_ici[B_INT((2))]=(37);
		b_a_ici[B_INT((3))]=(33);
		b_a_ici[B_INT((4))]=(41);
		/* line 5807 */
b_L5807: ;
		b_a_ici[B_INT((5))]=(27);
		b_a_ici[B_INT((6))]=(43);
		b_a_ici[B_INT((7))]=(40);
		b_a_ici[B_INT((8))]=(42);
		/* line 5808 */
b_L5808: ;
		b_a_oci[B_INT((7))]=(68);
		b_a_obi[B_INT((7))]=(80);
		b_a_oai[B_INT((7))]=(14);
		b_a_oei[B_INT((7))]=(120);
		b_a_osi[B_INT((7))]=(1);
		goto b_return;
		/* line 5900 */
b_L5900: ;
		if(-((b_v_dei) < ((2)))){
			goto b_return;
		}
		/* line 5901 */
b_L5901: ;
		if(-((b_int(((b_rnd(B_INT((1))))*((100))))) >= ((10)))){
			goto b_return;
		}
		/* line 5902 */
b_L5902: ;
		b_v_bri=b_v_nri;
		b_v_bxi=((b_a_rxi[B_INT(b_v_bri)])+(b_int(((breal_t)(b_a_rwi[B_INT(b_v_bri)])/(breal_t)((2))))));
		b_v_byi=((b_a_ryi[B_INT(b_v_bri)])+(b_int(((breal_t)(b_a_rhi[B_INT(b_v_bri)])/(breal_t)((2))))));
		/* line 5903 */
b_L5903: ;
		b_v_nmi=((b_v_nmi)+((1)));
		b_a_oti[B_INT(b_v_nmi)]=(7);
		b_a_ohi[B_INT(b_v_nmi)]=((b_a_obi[B_INT((7))])+(((b_v_dei)*((4)))));
		b_a_odi[B_INT(b_v_nmi)]=b_a_osi[B_INT((7))];
		b_a_oxi[B_INT(b_v_nmi)]=b_v_bxi;
		b_a_oyi[B_INT(b_v_nmi)]=b_v_byi;
		/* line 5904 */
b_L5904: ;
		b_v_bmi=b_int(((b_rnd(B_INT((1))))*((7))));
		if(-((((b_v_nmi)+(b_v_bmi))) > ((16)))){
			b_v_bmi=(((16))-(b_v_nmi));
		}
		/* line 5905 */
b_L5905: ;
		if(-((b_v_bmi) < ((0)))){
			b_v_bmi=(0);
		}
		/* line 5906 */
b_L5906: ;
		b_v_bji=(1);
		b_fl_45=b_v_bmi;
		if(b_v_bji > b_fl_45) goto b_f45_e;
		b_v_M9=b_a_obi[B_INT((6))];
		b_v_M10=((b_v_dei)*((2)));
		b_v_M11=b_a_osi[B_INT((6))];
		b_v_M12=b_a_rxi[B_INT(b_v_bri)];
		b_v_M13=b_a_rwi[B_INT(b_v_bri)];
		b_v_M14=b_a_ryi[B_INT(b_v_bri)];
		b_v_M15=b_a_rhi[B_INT(b_v_bri)];
b_f45_t: ;
		b_v_nmi=((b_v_nmi)+((1)));
		b_a_oti[B_INT(b_v_nmi)]=(6);
		b_a_ohi[B_INT(b_v_nmi)]=((((b_v_M9)+(b_v_M10)))-((2)));
		b_a_odi[B_INT(b_v_nmi)]=b_v_M11;
		/* line 5907 */
b_L5907: ;
		b_a_oxi[B_INT(b_v_nmi)]=((b_v_M12)+(b_int(((b_rnd(B_INT((1))))*(((b_v_M13)+((1))))))));
		b_a_oyi[B_INT(b_v_nmi)]=((b_v_M14)+(b_int(((b_rnd(B_INT((1))))*(((b_v_M15)+((1))))))));
		/* line 5908 */
b_L5908: ;
		b_v_bji += 1;
		if(b_v_bji <= (b_fl_45)) goto b_f45_t;
b_f45_e: ;
		goto b_return;
		/* line 6000 */
b_L6000: ;
		switch(b_v_sni){
			case 1: goto b_L6001; break;
			case 2: goto b_L6002; break;
			case 3: goto b_L6003; break;
			case 4: goto b_L6004; break;
			case 5: goto b_L6005; break;
			case 6: goto b_L6006; break;
			default: break;}
		/* line 6001 */
b_L6001: ;
		b_poke((54272.0),(144));
		b_poke((54273.0),(0));
		goto b_L6007;
		/* line 6002 */
b_L6002: ;
		b_poke((54272.0),(64));
		b_poke((54273.0),(1));
		goto b_L6007;
		/* line 6003 */
b_L6003: ;
		b_poke((54272.0),(200));
		b_poke((54273.0),(1));
		goto b_L6007;
		/* line 6004 */
b_L6004: ;
		b_poke((54272.0),(88));
		b_poke((54273.0),(2));
		goto b_L6007;
		/* line 6005 */
b_L6005: ;
		b_poke((54272.0),(200));
		b_poke((54273.0),(0));
		goto b_L6007;
		/* line 6006 */
b_L6006: ;
		b_poke((54272.0),(100));
		b_poke((54273.0),(2));
		/* line 6007 */
b_L6007: ;
		b_poke((54277.0),(8));
		b_poke((54278.0),(128));
		b_poke((54276.0),(17));
		b_v_sdi=(1);
		if(b_v_sdi > 150) goto b_f46_e;
b_f46_t: ;
		b_v_sdi += 1;
		if(b_v_sdi <= 150) goto b_f46_t;
b_f46_e: ;
		b_poke((54276.0),(16));
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			case 54: goto b_ret54;
			case 55: goto b_ret55;
			case 56: goto b_ret56;
			case 57: goto b_ret57;
			case 58: goto b_ret58;
			case 59: goto b_ret59;
			case 60: goto b_ret60;
			case 61: goto b_ret61;
			case 62: goto b_ret62;
			case 63: goto b_ret63;
			case 64: goto b_ret64;
			case 65: goto b_ret65;
			case 66: goto b_ret66;
			case 67: goto b_ret67;
			case 68: goto b_ret68;
			case 69: goto b_ret69;
			case 70: goto b_ret70;
			case 71: goto b_ret71;
			case 72: goto b_ret72;
			case 73: goto b_ret73;
			case 74: goto b_ret74;
			case 75: goto b_ret75;
			case 76: goto b_ret76;
			case 77: goto b_ret77;
			case 78: goto b_ret78;
			case 79: goto b_ret79;
			case 80: goto b_ret80;
			case 81: goto b_ret81;
			case 82: goto b_ret82;
			case 83: goto b_ret83;
			case 84: goto b_ret84;
			case 85: goto b_ret85;
			case 86: goto b_ret86;
			case 87: goto b_ret87;
			case 88: goto b_ret88;
			case 89: goto b_ret89;
			case 90: goto b_ret90;
			case 91: goto b_ret91;
			case 92: goto b_ret92;
			case 93: goto b_ret93;
			case 94: goto b_ret94;
			case 95: goto b_ret95;
			case 96: goto b_ret96;
			case 97: goto b_ret97;
			case 98: goto b_ret98;
			case 99: goto b_ret99;
			case 100: goto b_ret100;
			case 101: goto b_ret101;
			case 102: goto b_ret102;
			case 103: goto b_ret103;
			case 104: goto b_ret104;
			case 105: goto b_ret105;
			case 106: goto b_ret106;
			case 107: goto b_ret107;
			case 108: goto b_ret108;
			case 109: goto b_ret109;
			case 110: goto b_ret110;
			case 111: goto b_ret111;
			case 112: goto b_ret112;
			case 113: goto b_ret113;
			case 114: goto b_ret114;
			case 115: goto b_ret115;
			case 116: goto b_ret116;
			case 117: goto b_ret117;
			case 118: goto b_ret118;
			case 119: goto b_ret119;
			case 120: goto b_ret120;
			case 121: goto b_ret121;
			case 122: goto b_ret122;
			case 123: goto b_ret123;
			case 124: goto b_ret124;
			case 125: goto b_ret125;
			case 126: goto b_ret126;
			case 127: goto b_ret127;
			case 128: goto b_ret128;
			case 129: goto b_ret129;
			case 130: goto b_ret130;
			case 131: goto b_ret131;
			case 132: goto b_ret132;
			case 133: goto b_ret133;
			case 134: goto b_ret134;
			case 135: goto b_ret135;
			case 136: goto b_ret136;
			case 137: goto b_ret137;
			case 138: goto b_ret138;
			case 139: goto b_ret139;
			case 140: goto b_ret140;
			case 141: goto b_ret141;
			case 142: goto b_ret142;
			case 143: goto b_ret143;
			case 144: goto b_ret144;
			case 145: goto b_ret145;
			case 146: goto b_ret146;
			case 147: goto b_ret147;
			case 148: goto b_ret148;
			case 149: goto b_ret149;
			case 150: goto b_ret150;
			case 151: goto b_ret151;
			case 152: goto b_ret152;
			case 153: goto b_ret153;
			case 154: goto b_ret154;
			case 155: goto b_ret155;
			case 156: goto b_ret156;
			case 157: goto b_ret157;
			case 158: goto b_ret158;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
