/* OPTIMIZE_C -- wolf.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_ii;
static int b_a_sii[256];
static bint_t b_a_mi[256];
static int b_a_ofi[20];
static int b_a_lpi[40];
static int b_a_lbi[40];
static int b_a_lwi[40];
static int b_a_lhi[40];
static int b_v_xi;
static int b_v_yi;
static bint_t b_v_pai;
static int b_v_lvi;
static bint_t b_v_sti;
static int b_v_wni;
static int b_v_ki;
static int b_v_mvi;
static int b_v_mfi;
static int b_v_dmi;
static int b_v_hpi;
static int b_v_cxi;
static int b_v_cyi;
static bint_t b_v_fci;
static int b_v_rii;
static bint_t b_v_dxi;
static bint_t b_v_dyi;
static bint_t b_v_rxi;
static bint_t b_v_ryi;
static int b_v_sdi;
static int b_v_twi;
static int b_v_si;
static bint_t b_v_oxi;
static bint_t b_v_oyi;
static bint_t b_v_nxi;
static bint_t b_v_nyi;
static int b_v_hti;
static bint_t b_v_c1i;
static int b_v_swi;
static int b_v_wci;
static int b_v_pti;
static int b_v_psi;
static int b_v_eci;
static int b_v_oki;
static int b_v_wgi;
static bint_t b_v_cbi;
static bint_t b_v_ji;
static int b_v_opi;
static int b_v_obi;
static int b_v_oci;
static int b_v_tti;
static int b_v_tpi;
static int b_v_bti;
static int b_v_tri;
static int b_v_bri;
static int b_v_chi;
static int b_v_ai;
static int b_v_bi;
static int b_v_coi;
static bint_t b_v_qi;
static bint_t b_v_q1i;
static bint_t b_v_rci;
static int b_v_vi;
static int b_v_hai;
static bstr_t b_v_hds;
static bstr_t b_v_hus;
static breal_t b_v_cf;
static bint_t b_v_dci;
static bstr_t b_v_ks;
static bint_t b_v_fxi;
static bint_t b_v_fyi;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[3];
static int b_rtfor_sp=0;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,0,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,9,0,0},{1,0,12,0,0},{1,0,16,0,0},{1,0,19,0,0},{1,0,22,0,0},{1,0,25,0,0},{1,0,28,0,0},{1,0,31,0,0},{1,0,34,0,0},{1,0,37,0,0},{1,0,40,0,0},{1,0,43,0,0},{1,0,46,0,0},{1,0,49,0,0},{1,0,51,0,0},{1,0,54,0,0},{1,0,57,0,0},{1,0,60,0,0},{1,0,63,0,0},{1,0,65,0,0},{1,0,68,0,0},{1,0,71,0,0},{1,0,73,0,0},{1,0,76,0,0},{1,0,78,0,0},{1,0,81,0,0},{1,0,83,0,0},{1,0,85,0,0},{1,0,88,0,0},{1,0,90,0,0},{1,0,92,0,0},{1,0,94,0,0},{1,0,96,0,0},{1,0,98,0,0},{1,0,100,0,0},{1,0,102,0,0},{1,0,104,0,0},{1,0,106,0,0},{1,0,107,0,0},{1,0,109,0,0},{1,0,111,0,0},{1,0,112,0,0},{1,0,113,0,0},{1,0,115,0,0},{1,0,116,0,0},{1,0,117,0,0},{1,0,118,0,0},{1,0,120,0,0},{1,0,121,0,0},{1,0,122,0,0},{1,0,122,0,0},{1,0,123,0,0},{1,0,124,0,0},{1,0,125,0,0},{1,0,125,0,0},{1,0,126,0,0},{1,0,126,0,0},{1,0,126,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,127,0,0},{1,0,126,0,0},{1,0,126,0,0},{1,0,126,0,0},{1,0,125,0,0},{1,0,125,0,0},{1,0,124,0,0},{1,0,123,0,0},{1,0,122,0,0},{1,0,122,0,0},{1,0,121,0,0},{1,0,120,0,0},{1,0,118,0,0},{1,0,117,0,0},{1,0,116,0,0},{1,0,115,0,0},{1,0,113,0,0},{1,0,112,0,0},{1,0,111,0,0},{1,0,109,0,0},{1,0,107,0,0},{1,0,106,0,0},{1,0,104,0,0},{1,0,102,0,0},{1,0,100,0,0},{1,0,98,0,0},{1,0,96,0,0},{1,0,94,0,0},{1,0,92,0,0},{1,0,90,0,0},{1,0,88,0,0},{1,0,85,0,0},{1,0,83,0,0},{1,0,81,0,0},{1,0,78,0,0},{1,0,76,0,0},{1,0,73,0,0},{1,0,71,0,0},{1,0,68,0,0},{1,0,65,0,0},{1,0,63,0,0},{1,0,60,0,0},{1,0,57,0,0},{1,0,54,0,0},{1,0,51,0,0},{1,0,49,0,0},{1,0,46,0,0},{1,0,43,0,0},{1,0,40,0,0},{1,0,37,0,0},{1,0,34,0,0},{1,0,31,0,0},{1,0,28,0,0},{1,0,25,0,0},{1,0,22,0,0},{1,0,19,0,0},{1,0,16,0,0},{1,0,12,0,0},{1,0,9,0,0},{1,0,6,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,-3,0,0},{1,0,-6,0,0},{1,0,-9,0,0},{1,0,-12,0,0},{1,0,-16,0,0},{1,0,-19,0,0},{1,0,-22,0,0},{1,0,-25,0,0},{1,0,-28,0,0},{1,0,-31,0,0},{1,0,-34,0,0},{1,0,-37,0,0},{1,0,-40,0,0},{1,0,-43,0,0},{1,0,-46,0,0},{1,0,-49,0,0},{1,0,-51,0,0},{1,0,-54,0,0},{1,0,-57,0,0},{1,0,-60,0,0},{1,0,-63,0,0},{1,0,-65,0,0},{1,0,-68,0,0},{1,0,-71,0,0},{1,0,-73,0,0},{1,0,-76,0,0},{1,0,-78,0,0},{1,0,-81,0,0},{1,0,-83,0,0},{1,0,-85,0,0},{1,0,-88,0,0},{1,0,-90,0,0},{1,0,-92,0,0},{1,0,-94,0,0},{1,0,-96,0,0},{1,0,-98,0,0},{1,0,-100,0,0},{1,0,-102,0,0},{1,0,-104,0,0},{1,0,-106,0,0},{1,0,-107,0,0},{1,0,-109,0,0},{1,0,-111,0,0},{1,0,-112,0,0},{1,0,-113,0,0},{1,0,-115,0,0},{1,0,-116,0,0},{1,0,-117,0,0},{1,0,-118,0,0},{1,0,-120,0,0},{1,0,-121,0,0},{1,0,-122,0,0},{1,0,-122,0,0},{1,0,-123,0,0},{1,0,-124,0,0},{1,0,-125,0,0},{1,0,-125,0,0},{1,0,-126,0,0},{1,0,-126,0,0},{1,0,-126,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-127,0,0},{1,0,-126,0,0},{1,0,-126,0,0},{1,0,-126,0,0},{1,0,-125,0,0},{1,0,-125,0,0},{1,0,-124,0,0},{1,0,-123,0,0},{1,0,-122,0,0},{1,0,-122,0,0},{1,0,-121,0,0},{1,0,-120,0,0},{1,0,-118,0,0},{1,0,-117,0,0},{1,0,-116,0,0},{1,0,-115,0,0},{1,0,-113,0,0},{1,0,-112,0,0},{1,0,-111,0,0},{1,0,-109,0,0},{1,0,-107,0,0},{1,0,-106,0,0},{1,0,-104,0,0},{1,0,-102,0,0},{1,0,-100,0,0},{1,0,-98,0,0},{1,0,-96,0,0},{1,0,-94,0,0},{1,0,-92,0,0},{1,0,-90,0,0},{1,0,-88,0,0},{1,0,-85,0,0},{1,0,-83,0,0},{1,0,-81,0,0},{1,0,-78,0,0},{1,0,-76,0,0},{1,0,-73,0,0},{1,0,-71,0,0},{1,0,-68,0,0},{1,0,-65,0,0},{1,0,-63,0,0},{1,0,-60,0,0},{1,0,-57,0,0},{1,0,-54,0,0},{1,0,-51,0,0},{1,0,-49,0,0},{1,0,-46,0,0},{1,0,-43,0,0},{1,0,-40,0,0},{1,0,-37,0,0},{1,0,-34,0,0},{1,0,-31,0,0},{1,0,-28,0,0},{1,0,-25,0,0},{1,0,-22,0,0},{1,0,-19,0,0},{1,0,-16,0,0},{1,0,-12,0,0},{1,0,-9,0,0},{1,0,-6,0,0},{1,0,-3,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,4,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,-22,0,0},{1,0,-17,0,0},{1,0,-12,0,0},{1,0,-7,0,0},{1,0,-2,0,0},{1,0,3,0,0},{1,0,8,0,0},{1,0,13,0,0},{1,0,18,0,0},{1,0,23,0,0}};
int b_data_len = 522;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		b_poke((650),(128));
		/* line 60 */
b_L60: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		b_putc(147);
		b_nl();
		/* line 70 */
b_L70: ;
		b_v_ii=(1064);
		if(b_v_ii > 1983) goto b_f0_e;
b_f0_t: ;
		b_poke(b_v_ii,(35));
		b_v_ii += 1;
		if(b_v_ii <= 1983) goto b_f0_t;
b_f0_e: ;
		/* line 80 */
b_L80: ;
		/* line 90 */
b_L90: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1700;
b_ret0: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L1800;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L1900;
b_ret2: ;
		/* line 100 */
b_L100: ;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f1_e;
b_f1_t: ;
		b_a_lhi[B_INT(b_v_ii)]=(-1);
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f1_t;
b_f1_e: ;
		/* line 110 */
b_L110: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L2100;
b_ret3: ;
		/* line 120 */
b_L120: ;
		b_v_xi=(384);
		b_v_yi=(384);
		b_v_pai=(0);
		b_v_lvi=(1);
		b_v_sti=(0);
		b_v_wni=(0);
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f2_e;
b_f2_t: ;
		b_a_lhi[B_INT(b_v_ii)]=(-1);
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f2_t;
b_f2_e: ;
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1000;
b_ret4: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L2000;
b_ret5: ;
		/* line 140 */
b_L140: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_mvi=(0);
		b_v_mfi=(0);
		/* line 150 */
b_L150: ;
		if((B_INT(-((b_v_dmi) == ((1)))) & B_INT(-((b_v_ki) != ((64)))))){
			b_v_dmi=(0);
		}
		/* line 160 */
b_L160: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=6; goto b_L2200;
b_ret6: ;
		}
		/* line 170 */
b_L170: ;
		if(-((b_v_ki) == ((62)))){
			goto b_L2116;
		}
		/* line 180 */
b_L180: ;
		if(-((b_v_ki) == ((17)))){
			goto b_L110;
		}
		/* line 190 */
b_L190: ;
		if(-((b_v_ki) == ((10)))){
			b_v_pai=(B_INT(((b_v_pai)-((2)))) & B_INT((255)));
			b_v_mvi=(1);
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_ki) == ((18)))){
			b_v_pai=(B_INT(((b_v_pai)+((2)))) & B_INT((255)));
			b_v_mvi=(1);
		}
		/* line 210 */
b_L210: ;
		if(-((b_v_ki) == ((9)))){
			b_gosubStack[b_gosubSP++]=7; goto b_L1100;
b_ret7: ;
			b_v_mfi=(1);
			b_v_mvi=(1);
		}
		/* line 220 */
b_L220: ;
		if(-((b_v_ki) == ((13)))){
			b_gosubStack[b_gosubSP++]=8; goto b_L1200;
b_ret8: ;
			b_v_mfi=(1);
			b_v_mvi=(1);
		}
		/* line 230 */
b_L230: ;
		if(-((b_v_mvi) == ((1)))){
			b_gosubStack[b_gosubSP++]=9; goto b_L1000;
b_ret9: ;
		}
		/* line 240 */
b_L240: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L2000;
b_ret10: ;
		/* line 250 */
b_L250: ;
		b_wait((53265.0),(128),0);
		/* line 260 */
b_L260: ;
		if(-((b_v_mfi) == ((1)))){
			b_v_hpi=((b_v_hpi)-((1)));
			b_v_sti=((b_v_sti)+((1)));
		}
		/* line 270 */
b_L270: ;
		b_v_cxi=b_int(((breal_t)(b_v_xi)/(breal_t)((256))));
		b_v_cyi=b_int(((breal_t)(b_v_yi)/(breal_t)((256))));
		if(-((b_a_mi[B_INT(((((b_v_cyi)*((16))))+(b_v_cxi)))]) == ((4)))){
			b_v_wni=(1);
			goto b_L2116;
		}
		/* line 280 */
b_L280: ;
		if(-((b_v_hpi) <= ((0)))){
			b_v_wni=(0);
			goto b_L2116;
		}
		/* line 290 */
b_L290: ;
		b_v_fci=((b_v_fci)+((1)));
		/* line 300 */
b_L300: ;
		goto b_L140;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_ki=(0);
		if(b_v_ki > 9) goto b_f3_e;
b_f3_t: ;
		/* line 1002 */
b_L1002: ;
		b_v_rii=(B_INT(((b_v_pai)+(b_a_ofi[B_INT(b_v_ki)]))) & B_INT((255)));
		/* line 1003 */
b_L1003: ;
		b_v_dxi=b_a_sii[B_INT((B_INT(((b_v_rii)+((64)))) & B_INT((255))))];
		b_v_dyi=b_a_sii[B_INT(b_v_rii)];
		/* line 1004 */
b_L1004: ;
		b_v_rxi=b_v_xi;
		b_v_ryi=b_v_yi;
		b_v_sdi=(0);
		b_v_twi=(0);
		/* line 1005 */
b_L1005: ;
		b_v_si=(1);
		if(b_v_si > 80) goto b_f4_e;
		{ b_rtfor_t _f; _f.top_id=4; _f.pI=&b_v_si; _f.vtype=1; _f.lim.i=80; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f4_t: ;
		/* line 1006 */
b_L1006: ;
		b_v_oxi=b_int(((breal_t)(b_v_rxi)/(breal_t)((256))));
		b_v_oyi=b_int(((breal_t)(b_v_ryi)/(breal_t)((256))));
		/* line 1007 */
b_L1007: ;
		b_v_rxi=((b_v_rxi)+(b_v_dxi));
		b_v_ryi=((b_v_ryi)+(b_v_dyi));
		/* line 1008 */
b_L1008: ;
		b_v_nxi=b_int(((breal_t)(b_v_rxi)/(breal_t)((256))));
		b_v_nyi=b_int(((breal_t)(b_v_ryi)/(breal_t)((256))));
		/* line 1009 */
b_L1009: ;
		if((B_INT(-((b_v_nxi) == (b_v_oxi))) & B_INT(-((b_v_nyi) == (b_v_oyi))))){ goto b_L1018; }
		/* line 1010 */
b_L1010: ;
		if(-((b_v_nxi) < ((0)))){ goto b_L1019; }
		/* line 1011 */
b_L1011: ;
		if(-((b_v_nxi) > ((15)))){ goto b_L1019; }
		/* line 1012 */
b_L1012: ;
		if(-((b_v_nyi) < ((0)))){ goto b_L1019; }
		/* line 1013 */
b_L1013: ;
		if(-((b_v_nyi) > ((15)))){ goto b_L1019; }
		/* line 1014 */
b_L1014: ;
		b_v_twi=b_a_mi[B_INT(((((b_v_nyi)*((16))))+(b_v_nxi)))];
		/* line 1015 */
b_L1015: ;
		if(-((b_v_nxi) != (b_v_oxi))){
			b_v_sdi=(0);
		}
		/* line 1016 */
b_L1016: ;
		if(-((b_v_nyi) != (b_v_oyi))){
			b_v_sdi=(1);
		}
		/* line 1017 */
b_L1017: ;
		if(-((b_v_twi) != ((0)))){ goto b_L1019; }
		/* line 1018 */
b_L1018: ;
		b_v_si += 1;
		if(b_v_si <= 80) goto b_f4_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f4_e: ;
		/* line 1019 */
b_L1019: ;
		if(-((b_v_si) > ((80)))){
			b_v_hti=(0);
			goto b_L1024;
		}
		/* line 1020 */
b_L1020: ;
		b_v_hti=((breal_t)((44))/(breal_t)(b_v_si));
		/* line 1021 */
b_L1021: ;
		if(-((b_v_hti) > ((12)))){
			b_v_hti=(12);
		}
		/* line 1022 */
b_L1022: ;
		if(-((b_v_hti) < ((1)))){
			b_v_hti=(1);
		}
		/* line 1023 */
b_L1023: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L1400;
b_ret11: ;
		/* line 1024 */
b_L1024: ;
		b_v_c1i=((b_v_ki)*((4)));
		b_v_swi=b_v_wci;
		/* line 1025 */
b_L1025: ;
		if(-((b_v_ki) > ((0)))){
			if((B_INT(-((b_v_twi) != (b_v_pti))) | B_INT(-((b_v_sdi) != (b_v_psi))))){
				b_v_wci=b_v_eci;
			}
		}
		/* line 1026 */
b_L1026: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1500;
b_ret12: ;
		/* line 1027 */
b_L1027: ;
		b_v_wci=b_v_swi;
		b_v_c1i=((b_v_c1i)+((1)));
		b_gosubStack[b_gosubSP++]=13; goto b_L1500;
b_ret13: ;
		/* line 1028 */
b_L1028: ;
		b_v_c1i=((b_v_c1i)+((1)));
		b_gosubStack[b_gosubSP++]=14; goto b_L1500;
b_ret14: ;
		/* line 1029 */
b_L1029: ;
		b_v_c1i=((b_v_c1i)+((1)));
		b_gosubStack[b_gosubSP++]=15; goto b_L1500;
b_ret15: ;
		/* line 1030 */
b_L1030: ;
		b_v_pti=b_v_twi;
		b_v_psi=b_v_sdi;
		b_v_ki += 1;
		if(b_v_ki <= 9) goto b_f3_t;
b_f3_e: ;
		/* line 1031 */
b_L1031: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_dxi=b_a_sii[B_INT((B_INT(((b_v_pai)+((64)))) & B_INT((255))))];
		b_v_dyi=b_a_sii[B_INT(b_v_pai)];
		/* line 1102 */
b_L1102: ;
		b_v_nxi=((b_v_xi)+(((breal_t)(b_v_dxi)/(breal_t)((4)))));
		b_v_nyi=((b_v_yi)+(((breal_t)(b_v_dyi)/(breal_t)((4)))));
		/* line 1103 */
b_L1103: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L1300;
b_ret16: ;
		if(b_v_oki){
			b_v_xi=b_v_nxi;
			b_v_yi=b_v_nyi;
		}
		/* line 1104 */
b_L1104: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_dxi=b_a_sii[B_INT((B_INT(((b_v_pai)+((64)))) & B_INT((255))))];
		b_v_dyi=b_a_sii[B_INT(b_v_pai)];
		/* line 1202 */
b_L1202: ;
		b_v_nxi=((b_v_xi)-(((breal_t)(b_v_dxi)/(breal_t)((4)))));
		b_v_nyi=((b_v_yi)-(((breal_t)(b_v_dyi)/(breal_t)((4)))));
		/* line 1203 */
b_L1203: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L1300;
b_ret17: ;
		if(b_v_oki){
			b_v_xi=b_v_nxi;
			b_v_yi=b_v_nyi;
		}
		/* line 1204 */
b_L1204: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_v_cxi=b_int(((breal_t)(b_v_nxi)/(breal_t)((256))));
		b_v_cyi=b_int(((breal_t)(b_v_nyi)/(breal_t)((256))));
		b_v_oki=(0);
		/* line 1302 */
b_L1302: ;
		if(-((b_v_cxi) < ((0)))){
			goto b_return;
		}
		/* line 1303 */
b_L1303: ;
		if(-((b_v_cxi) > ((15)))){
			goto b_return;
		}
		/* line 1304 */
b_L1304: ;
		if(-((b_v_cyi) < ((0)))){
			goto b_return;
		}
		/* line 1305 */
b_L1305: ;
		if(-((b_v_cyi) > ((15)))){
			goto b_return;
		}
		/* line 1306 */
b_L1306: ;
		if((B_INT(-((b_a_mi[B_INT(((((b_v_cyi)*((16))))+(b_v_cxi)))]) != ((0)))) & B_INT(-((b_a_mi[B_INT(((((b_v_cyi)*((16))))+(b_v_cxi)))]) != ((4)))))){
			goto b_return;
		}
		/* line 1307 */
b_L1307: ;
		b_v_oki=(1);
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_v_wgi=(35);
		/* line 1402 */
b_L1402: ;
		if(-((b_v_twi) == ((4)))){
			b_v_wci=(7);
			b_v_wgi=(24);
			if(-((b_v_sdi) == ((1)))){
				b_v_wci=(13);
				goto b_L1406;
			}
		}
		/* line 1403 */
b_L1403: ;
		if(-((b_v_twi) == ((1)))){
			b_v_wci=(15);
			b_v_wgi=(35);
			if(-((b_v_sdi) == ((1)))){
				b_v_wci=(11);
			}
		}
		/* line 1404 */
b_L1404: ;
		if(-((b_v_twi) == ((2)))){
			b_v_wci=(10);
			b_v_wgi=(61);
			if(-((b_v_sdi) == ((1)))){
				b_v_wci=(2);
			}
		}
		/* line 1405 */
b_L1405: ;
		if(-((b_v_twi) == ((3)))){
			b_v_wci=(14);
			b_v_wgi=(42);
			if(-((b_v_sdi) == ((1)))){
				b_v_wci=(6);
			}
		}
		/* line 1406 */
b_L1406: ;
		if(-((b_v_si) > ((40)))){
			b_v_wci=(11);
			b_v_wgi=(58);
		}
		/* line 1407 */
b_L1407: ;
		b_v_eci=b_v_wci;
		/* line 1408 */
b_L1408: ;
		if(-((b_v_wci) == ((15)))){
			b_v_eci=(11);
		}
		/* line 1409 */
b_L1409: ;
		if(-((b_v_wci) == ((14)))){
			b_v_eci=(6);
		}
		/* line 1410 */
b_L1410: ;
		if(-((b_v_wci) == ((13)))){
			b_v_eci=(5);
		}
		/* line 1411 */
b_L1411: ;
		if(-((b_v_wci) == ((12)))){
			b_v_eci=(11);
		}
		/* line 1412 */
b_L1412: ;
		if(-((b_v_wci) == ((10)))){
			b_v_eci=(2);
		}
		/* line 1413 */
b_L1413: ;
		if(-((b_v_wci) == ((7)))){
			b_v_eci=(8);
		}
		/* line 1414 */
b_L1414: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_cbi=(((55296.0))+(b_v_c1i));
		b_v_ji=b_v_c1i;
		/* line 1502 */
b_L1502: ;
		if(-((b_a_lhi[B_INT(b_v_ji)]) < ((0)))){ goto b_L1614; }
		/* line 1503 */
b_L1503: ;
		b_v_opi=b_a_lpi[B_INT(b_v_ji)];
		b_v_obi=b_a_lbi[B_INT(b_v_ji)];
		b_v_oci=b_a_lwi[B_INT(b_v_ji)];
		/* line 1504 */
b_L1504: ;
		b_v_tti=(((12))-(b_int(((breal_t)(b_v_hti)/(breal_t)((2))))));
		b_v_tpi=b_v_tti;
		b_v_bti=((((b_v_tti)+(b_v_hti)))-((1)));
		/* line 1505 */
b_L1505: ;
		if(-((b_v_tpi) < ((6)))){
			b_v_tpi=(6);
		}
		/* line 1506 */
b_L1506: ;
		if(-((b_v_bti) > ((17)))){
			b_v_bti=(17);
		}
		/* line 1507 */
b_L1507: ;
		if(-((b_v_tpi) > (b_v_bti))){
			b_v_tpi=b_v_bti;
		}
		/* line 1508 */
b_L1508: ;
		b_v_tri=b_v_tpi;
		b_v_bri=b_v_bti;
		/* line 1509 */
b_L1509: ;
		if((B_INT((B_INT(-((b_v_tri) == (b_v_opi))) & B_INT(-((b_v_bri) == (b_v_obi))))) & B_INT(-((b_v_wci) == (b_v_oci))))){ goto b_L1519; }
		/* line 1510 */
b_L1510: ;
		if(-((b_v_wci) != (b_v_oci))){
			b_v_chi=b_v_wgi;
			b_v_ai=b_v_tri;
			b_v_bi=b_v_bri;
			b_v_coi=b_v_wci;
			b_gosubStack[b_gosubSP++]=18; goto b_L1600;
b_ret18: ;
		}
		/* line 1511 */
b_L1511: ;
		if(-((b_v_tri) == (b_v_opi))){ goto b_L1515; }
		/* line 1512 */
b_L1512: ;
		if(-((b_v_tri) > (b_v_opi))){ goto b_L1514; }
		/* line 1513 */
b_L1513: ;
		b_v_chi=b_v_wgi;
		b_v_ai=b_v_tri;
		b_v_bi=((b_v_opi)-((1)));
		b_v_coi=b_v_wci;
		b_gosubStack[b_gosubSP++]=19; goto b_L1600;
b_ret19: ;
		goto b_L1515;
		/* line 1514 */
b_L1514: ;
		b_v_chi=(32);
		b_v_ai=b_v_opi;
		b_v_bi=((b_v_tri)-((1)));
		b_v_coi=(0);
		b_gosubStack[b_gosubSP++]=20; goto b_L1600;
b_ret20: ;
		/* line 1515 */
b_L1515: ;
		if(-((b_v_bri) == (b_v_obi))){ goto b_L1519; }
		/* line 1516 */
b_L1516: ;
		if(-((b_v_bri) > (b_v_obi))){ goto b_L1518; }
		/* line 1517 */
b_L1517: ;
		b_v_chi=(46);
		b_v_ai=((b_v_bri)+((1)));
		b_v_bi=b_v_obi;
		b_v_coi=(8);
		b_gosubStack[b_gosubSP++]=21; goto b_L1600;
b_ret21: ;
		goto b_L1519;
		/* line 1518 */
b_L1518: ;
		b_v_chi=b_v_wgi;
		b_v_ai=((b_v_obi)+((1)));
		b_v_bi=b_v_bri;
		b_v_coi=b_v_wci;
		b_gosubStack[b_gosubSP++]=22; goto b_L1600;
b_ret22: ;
		/* line 1519 */
b_L1519: ;
		b_a_lpi[B_INT(b_v_ji)]=b_v_tri;
		b_a_lbi[B_INT(b_v_ji)]=b_v_bri;
		b_a_lhi[B_INT(b_v_ji)]=b_v_hti;
		b_a_lwi[B_INT(b_v_ji)]=b_v_wci;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		if(-((b_v_ai) < ((1)))){
			b_v_ai=(1);
		}
		/* line 1602 */
b_L1602: ;
		if(-((b_v_bi) > ((23)))){
			b_v_bi=(23);
		}
		/* line 1603 */
b_L1603: ;
		if(-((b_v_ai) > (b_v_bi))){
			goto b_return;
		}
		/* line 1604 */
b_L1604: ;
		b_v_qi=((b_v_cbi)+(((b_v_ai)*((40)))));
		b_v_q1i=(((((1024))+(b_v_c1i)))+(((b_v_ai)*((40)))));
		b_v_rci=((((b_v_bi)-(b_v_ai)))+((1)));
		/* line 1605 */
b_L1605: ;
		b_poke(b_v_qi,b_v_coi);
		b_poke(b_v_q1i,b_v_chi);
		b_v_qi=((b_v_qi)+((40)));
		b_v_q1i=((b_v_q1i)+((40)));
		b_v_rci=((b_v_rci)-((1)));
		if(b_v_rci){ goto b_L1605; }
		/* line 1606 */
b_L1606: ;
		goto b_return;
		/* line 1607 */
b_L1607: ;
		/* line 1608 */
b_L1608: ;
		if(-((b_v_ai) < ((1)))){
			b_v_ai=(1);
		}
		/* line 1609 */
b_L1609: ;
		if(-((b_v_bi) > ((23)))){
			b_v_bi=(23);
		}
		/* line 1610 */
b_L1610: ;
		if(-((b_v_ai) > (b_v_bi))){
			goto b_return;
		}
		/* line 1611 */
b_L1611: ;
		b_v_qi=((b_v_cbi)+(((b_v_ai)*((40)))));
		b_v_q1i=(((((1024))+(b_v_c1i)))+(((b_v_ai)*((40)))));
		b_v_rci=((((b_v_bi)-(b_v_ai)))+((1)));
		/* line 1612 */
b_L1612: ;
		b_poke(b_v_qi,b_v_coi);
		b_poke(b_v_q1i,b_v_chi);
		b_v_qi=((b_v_qi)+((40)));
		b_v_q1i=((b_v_q1i)+((40)));
		b_v_rci=((b_v_rci)-((1)));
		if(b_v_rci){ goto b_L1612; }
		/* line 1613 */
b_L1613: ;
		goto b_return;
		/* line 1614 */
b_L1614: ;
		/* line 1615 */
b_L1615: ;
		b_v_tti=(((12))-(b_int(((breal_t)(b_v_hti)/(breal_t)((2))))));
		b_v_tpi=b_v_tti;
		b_v_bti=((((b_v_tti)+(b_v_hti)))-((1)));
		/* line 1616 */
b_L1616: ;
		if(-((b_v_tpi) < ((6)))){
			b_v_tpi=(6);
		}
		/* line 1617 */
b_L1617: ;
		if(-((b_v_bti) > ((17)))){
			b_v_bti=(17);
		}
		/* line 1618 */
b_L1618: ;
		if(-((b_v_tpi) > (b_v_bti))){
			b_v_tpi=b_v_bti;
		}
		/* line 1619 */
b_L1619: ;
		b_v_tri=b_v_tpi;
		b_v_bri=b_v_bti;
		/* line 1620 */
b_L1620: ;
		b_v_chi=(32);
		b_v_ai=(1);
		b_v_bi=((b_v_tri)-((1)));
		b_v_coi=(0);
		b_gosubStack[b_gosubSP++]=23; goto b_L1600;
b_ret23: ;
		/* line 1621 */
b_L1621: ;
		b_v_chi=b_v_wgi;
		b_v_ai=b_v_tri;
		b_v_bi=b_v_bri;
		b_v_coi=b_v_wci;
		b_gosubStack[b_gosubSP++]=24; goto b_L1600;
b_ret24: ;
		/* line 1622 */
b_L1622: ;
		b_v_chi=(46);
		b_v_ai=((b_v_bri)+((1)));
		b_v_bi=(23);
		b_v_coi=(8);
		b_gosubStack[b_gosubSP++]=25; goto b_L1600;
b_ret25: ;
		/* line 1623 */
b_L1623: ;
		goto b_L1519;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f5_e;
b_f5_t: ;
		b_v_vi=b_read_int();
		b_a_sii[B_INT(b_v_ii)]=b_v_vi;
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f5_t;
b_f5_e: ;
		goto b_return;
		/* line 1702 */
b_L1702: ;
		/* line 1703 */
b_L1703: ;
		/* line 1704 */
b_L1704: ;
		/* line 1705 */
b_L1705: ;
		/* line 1706 */
b_L1706: ;
		/* line 1707 */
b_L1707: ;
		/* line 1708 */
b_L1708: ;
		/* line 1709 */
b_L1709: ;
		/* line 1710 */
b_L1710: ;
		/* line 1711 */
b_L1711: ;
		/* line 1712 */
b_L1712: ;
		/* line 1713 */
b_L1713: ;
		/* line 1714 */
b_L1714: ;
		/* line 1715 */
b_L1715: ;
		/* line 1716 */
b_L1716: ;
		/* line 1717 */
b_L1717: ;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_ii=(0);
		if(b_v_ii > 255) goto b_f6_e;
b_f6_t: ;
		b_v_vi=b_read_int();
		b_a_mi[B_INT(b_v_ii)]=b_v_vi;
		b_v_ii += 1;
		if(b_v_ii <= 255) goto b_f6_t;
b_f6_e: ;
		goto b_return;
		/* line 1802 */
b_L1802: ;
		/* line 1803 */
b_L1803: ;
		/* line 1804 */
b_L1804: ;
		/* line 1805 */
b_L1805: ;
		/* line 1806 */
b_L1806: ;
		/* line 1807 */
b_L1807: ;
		/* line 1808 */
b_L1808: ;
		/* line 1809 */
b_L1809: ;
		/* line 1810 */
b_L1810: ;
		/* line 1811 */
b_L1811: ;
		/* line 1812 */
b_L1812: ;
		/* line 1813 */
b_L1813: ;
		/* line 1814 */
b_L1814: ;
		/* line 1815 */
b_L1815: ;
		/* line 1816 */
b_L1816: ;
		/* line 1817 */
b_L1817: ;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_ii=(0);
		if(b_v_ii > 9) goto b_f7_e;
b_f7_t: ;
		b_v_vi=b_read_int();
		b_a_ofi[B_INT(b_v_ii)]=b_v_vi;
		b_v_ii += 1;
		if(b_v_ii <= 9) goto b_f7_t;
b_f7_e: ;
		goto b_return;
		/* line 1902 */
b_L1902: ;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_hai=(B_INT(b_v_pai) & B_INT((255)));
		b_v_hds=b_keep(b_lit("E",1));
		/* line 2002 */
b_L2002: ;
		if((B_INT(-((b_v_hai) >= ((32)))) & B_INT(-((b_v_hai) < ((96)))))){
			b_v_hds=b_keep(b_lit("S",1));
		}
		/* line 2003 */
b_L2003: ;
		if((B_INT(-((b_v_hai) >= ((96)))) & B_INT(-((b_v_hai) < ((160)))))){
			b_v_hds=b_keep(b_lit("W",1));
		}
		/* line 2004 */
b_L2004: ;
		if((B_INT(-((b_v_hai) >= ((160)))) & B_INT(-((b_v_hai) < ((224)))))){
			b_v_hds=b_keep(b_lit("N",1));
		}
		/* line 2005 */
b_L2005: ;
		b_v_hus=b_keep(b_concat(b_concat(b_concat(b_concat(b_concat(b_concat(b_lit("HP",2),b_strs((breal_t)(b_v_hpi))),b_lit(" ",1)),b_v_hds),b_lit(" LV",3)),b_strs((breal_t)(b_v_lvi))),b_lit(" EXIT",5)));
		/* line 2006 */
b_L2006: ;
		/* line 2007 */
b_L2007: ;
		b_v_ii=(1);
		if(b_v_ii > 40) goto b_f8_e;
		b_t_2=(((1023))+(b_v_ii));
		b_t_3=(((55295.0))+(b_v_ii));
b_f8_t: ;
		/* line 2008 */
b_L2008: ;
		b_v_cf=(32);
		if(-((b_v_ii) <= (B_INT(b_len(b_v_hus))))){
			b_v_cf=b_asc(b_mid(b_v_hus,B_INT(b_v_ii),B_INT((1))));
		}
		/* line 2009 */
b_L2009: ;
		if((B_INT(-((b_v_cf) >= ((65)))) & B_INT(-((b_v_cf) <= ((90)))))){
			b_v_cf=((b_v_cf)-((64)));
		}
		/* line 2010 */
b_L2010: ;
		b_poke(b_t_2,b_v_cf);
		b_poke(b_t_3,(1));
		/* line 2011 */
b_L2011: ;
		b_t_2 += 1;
		b_t_3 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 40) goto b_f8_t;
b_f8_e: ;
		/* line 2012 */
b_L2012: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
		}
		/* line 2013 */
b_L2013: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_putc(147);
		b_nl();
		/* line 2102 */
b_L2102: ;
		{ bstr_t _t=b_lit("**** WOLF - 3D MAZE ****",24); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2103 */
b_L2103: ;
		b_nl();
		{ bstr_t _t=b_lit("W=FORWARD  S=BACK",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2104 */
b_L2104: ;
		{ bstr_t _t=b_lit("A=TURN LEFT  D=TURN RIGHT",25); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2105 */
b_L2105: ;
		{ bstr_t _t=b_lit("Q=QUIT  R=RESTART",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2106 */
b_L2106: ;
		b_nl();
		{ bstr_t _t=b_lit("FIND THE EXIT (X)",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2107 */
b_L2107: ;
		b_nl();
		{ bstr_t _t=b_lit("SPACE=NORMAL  E=EASY  H=HARD",28); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2108 */
b_L2108: ;
		{ bstr_t _t=b_lit("DEMO STARTS IN A MOMENT",23); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2109 */
b_L2109: ;
		b_v_dci=(0);
		/* line 2110 */
b_L2110: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_dci=((b_v_dci)+((1)));
		/* line 2111 */
b_L2111: ;
		if(-((b_v_ki) == ((60)))){
			b_v_dmi=(0);
			b_v_hpi=(100);
			goto b_return;
		}
		/* line 2112 */
b_L2112: ;
		if(-((b_v_ki) == ((14)))){
			b_v_dmi=(0);
			b_v_hpi=(150);
			goto b_return;
		}
		/* line 2113 */
b_L2113: ;
		if(-((b_v_ki) == ((29)))){
			b_v_dmi=(0);
			b_v_hpi=(60);
			goto b_return;
		}
		/* line 2114 */
b_L2114: ;
		if(-((b_v_dci) > ((200)))){
			b_v_dmi=(1);
			b_v_hpi=(100);
			goto b_return;
		}
		/* line 2115 */
b_L2115: ;
		b_wait((53265.0),(128),0);
		goto b_L2110;
		/* line 2116 */
b_L2116: ;
		/* line 2117 */
b_L2117: ;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f9_e;
b_f9_t: ;
		b_a_lhi[B_INT(b_v_ii)]=(-1);
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f9_t;
b_f9_e: ;
		/* line 2118 */
b_L2118: ;
		b_putc(147);
		b_nl();
		/* line 2119 */
b_L2119: ;
		if(-((b_v_wni) == ((1)))){
			{ bstr_t _t=b_lit("*** YOU WIN! ***",16); b_str(_t.p,_t.len); }
			b_nl();
			goto b_L2121;
		}
		/* line 2120 */
b_L2120: ;
		{ bstr_t _t=b_lit("*** GAME OVER ***",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2121 */
b_L2121: ;
		b_nl();
		{ bstr_t _t=b_lit("LEVEL",5); b_str(_t.p,_t.len); }
		b_putint(b_v_lvi);
		{ bstr_t _t=b_lit("  STEPS",7); b_str(_t.p,_t.len); }
		b_putint(b_v_sti);
		b_nl();
		/* line 2122 */
b_L2122: ;
		b_nl();
		{ bstr_t _t=b_lit("R=RESTART  Q=QUIT",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2123 */
b_L2123: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2123; }
		/* line 2124 */
b_L2124: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L110;
		}
		/* line 2125 */
b_L2125: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 2126 */
b_L2126: ;
		goto b_L2123;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_v_dxi=b_a_sii[B_INT((B_INT(((b_v_pai)+((64)))) & B_INT((255))))];
		b_v_dyi=b_a_sii[B_INT(b_v_pai)];
		/* line 2202 */
b_L2202: ;
		b_v_fxi=b_int(((breal_t)(b_v_xi)/(breal_t)((256))));
		b_v_fyi=b_int(((breal_t)(b_v_yi)/(breal_t)((256))));
		/* line 2203 */
b_L2203: ;
		if(-((b_v_dxi) > ((32)))){
			b_v_fxi=((b_v_fxi)+((1)));
		}
		/* line 2204 */
b_L2204: ;
		if(-((b_v_dxi) < ((-32)))){
			b_v_fxi=((b_v_fxi)-((1)));
		}
		/* line 2205 */
b_L2205: ;
		if(-((b_v_dyi) > ((32)))){
			b_v_fyi=((b_v_fyi)+((1)));
		}
		/* line 2206 */
b_L2206: ;
		if(-((b_v_dyi) < ((-32)))){
			b_v_fyi=((b_v_fyi)-((1)));
		}
		/* line 2207 */
b_L2207: ;
		if((B_INT((B_INT((B_INT(-((b_v_fxi) >= ((0)))) & B_INT(-((b_v_fxi) < ((16)))))) & B_INT(-((b_v_fyi) >= ((0)))))) & B_INT(-((b_v_fyi) < ((16)))))){
			if((B_INT(-((b_a_mi[B_INT(((((b_v_fyi)*((16))))+(b_v_fxi)))]) == ((0)))) | B_INT(-((b_a_mi[B_INT(((((b_v_fyi)*((16))))+(b_v_fxi)))]) == ((4)))))){
				b_v_ki=(9);
				goto b_return;
			}
		}
		/* line 2208 */
b_L2208: ;
		b_v_pai=(B_INT(((b_v_pai)+((16)))) & B_INT((255)));
		b_v_mvi=(1);
		b_v_ki=(64);
		/* line 2209 */
b_L2209: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
