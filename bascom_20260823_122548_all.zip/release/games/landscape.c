/* OPTIMIZE_C -- landscape.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_sli[64];
static int b_v_dmi;
static bint_t b_v_oxi;
static bint_t b_v_oyi;
static bint_t b_v_sxi;
static int b_v_syi;
static int b_v_ki;
static int b_v_dxi;
static int b_v_dyi;
static int b_v_ri;
static bint_t b_v_iyi;
static bint_t b_v_rai;
static bint_t b_v_ci;
static bint_t b_v_ixi;
static int b_v_chi;
static int b_v_cli;
static int b_v_uci;
static int b_v_uli;
static bint_t b_v_cci;
static bint_t b_v_wxi;
static int b_v_rri;
static bint_t b_v_wyi;
static bint_t b_v_rbi;
static bint_t b_v_hti;
static int b_v_gdi;
static bint_t b_v_sai;
static unsigned int b_v_sbi;
static int b_v_ii;
static bint_t b_v_txi;
static int b_v_tyi;
static bstr_t b_v_ts;
static bint_t b_v_vvi;
static int b_v_qzi;
static int b_v_sgi;
static int b_v_d4i;
static int b_v_d3i;
static bint_t b_v_d2i;
static bint_t b_v_d1i;
static int b_v_u0i;
static int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static int b_v_M3;
static int b_v_M4;
static int b_v_M5;
static bint_t b_t_0;
static bint_t b_t_1;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[3];
static int b_rtfor_sp=0;
static int b_fl_14;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,0,0,0},{1,0,1,0,0},{1,0,2,0,0},{1,0,3,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,6,0,0},{1,0,6,0,0},{1,0,7,0,0},{1,0,8,0,0},{1,0,8,0,0},{1,0,9,0,0},{1,0,9,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,10,0,0},{1,0,9,0,0},{1,0,9,0,0},{1,0,8,0,0},{1,0,8,0,0},{1,0,7,0,0},{1,0,6,0,0},{1,0,6,0,0},{1,0,5,0,0},{1,0,4,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,-2,0,0},{1,0,-3,0,0},{1,0,-4,0,0},{1,0,-5,0,0},{1,0,-6,0,0},{1,0,-6,0,0},{1,0,-7,0,0},{1,0,-8,0,0},{1,0,-8,0,0},{1,0,-9,0,0},{1,0,-9,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-10,0,0},{1,0,-9,0,0},{1,0,-9,0,0},{1,0,-8,0,0},{1,0,-8,0,0},{1,0,-7,0,0},{1,0,-6,0,0},{1,0,-6,0,0},{1,0,-5,0,0},{1,0,-4,0,0},{1,0,-3,0,0},{1,0,-2,0,0},{1,0,-1,0,0}};
int b_data_len = 64;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 13 */
b_L13: ;
		/* line 14 */
b_L14: ;
		/* line 15 */
b_L15: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L9600;
b_ret0: ;
		b_poke((650),(128));
		b_v_dmi=(0);
		/* line 25 */
b_L25: ;
		/* line 28 */
b_L28: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L8300;
b_ret1: ;
		/* line 30 */
b_L30: ;
		b_v_oxi=(0);
		b_v_oyi=(0);
		b_v_sxi=(20);
		b_v_syi=(12);
		/* line 40 */
b_L40: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L1000;
b_ret2: ;
		/* line 45 */
b_L45: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L2100;
b_ret3: ;
		/* line 46 */
b_L46: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L8500;
b_ret4: ;
		/* line 70 */
b_L70: ;
		b_wait((53265.0),(128),0);
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 72 */
b_L72: ;
		if(-((b_v_ki) != ((64)))){
			b_v_dmi=(0);
		}
		/* line 75 */
b_L75: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 78 */
b_L78: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=5; goto b_L8400;
b_ret5: ;
		}
		/* line 80 */
b_L80: ;
		b_v_dxi=(0);
		b_v_dyi=(0);
		/* line 85 */
b_L85: ;
		if(-((b_v_ki) == ((18)))){
			b_v_dxi=(1);
		}
		/* line 90 */
b_L90: ;
		if(-((b_v_ki) == ((10)))){
			b_v_dxi=(-1);
		}
		/* line 95 */
b_L95: ;
		if(-((b_v_ki) == ((13)))){
			b_v_dyi=(1);
		}
		/* line 100 */
b_L100: ;
		if(-((b_v_ki) == ((9)))){
			b_v_dyi=(-1);
		}
		/* line 105 */
b_L105: ;
		if((B_INT(-((b_v_dxi) == ((0)))) & B_INT(-((b_v_dyi) == ((0)))))){ goto b_L70; }
		/* line 110 */
b_L110: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L2000;
b_ret6: ;
		/* line 115 */
b_L115: ;
		b_v_sxi=((b_v_sxi)+(b_v_dxi));
		b_v_syi=((b_v_syi)+(b_v_dyi));
		/* line 120 */
b_L120: ;
		b_gosubStack[b_gosubSP++]=7; goto b_L3000;
b_ret7: ;
		/* line 125 */
b_L125: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L2100;
b_ret8: ;
		/* line 127 */
b_L127: ;
		b_gosubStack[b_gosubSP++]=9; goto b_L8500;
b_ret9: ;
		/* line 130 */
b_L130: ;
		/* line 135 */
b_L135: ;
		goto b_L70;
		/* line 1000 */
b_L1000: ;
		/* line 1005 */
b_L1005: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f0_e;
b_f0_t: ;
		/* line 1008 */
b_L1008: ;
		b_v_iyi=((b_v_oyi)+(b_v_ri));
		b_v_rai=((b_v_ri)*((40)));
		/* line 1015 */
b_L1015: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f1_e;
b_f1_t: ;
		/* line 1020 */
b_L1020: ;
		b_v_ixi=((b_v_oxi)+(b_v_ci));
		/* line 1025 */
b_L1025: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L8000;
b_ret10: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L7000;
b_ret11: ;
		/* line 1030 */
b_L1030: ;
		b_poke((((((1024))+(b_v_rai)))+(b_v_ci)),b_v_chi);
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_ci)),b_v_cli);
		/* line 1035 */
b_L1035: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f1_t;
b_f1_e: ;
		/* line 1040 */
b_L1040: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f0_t;
b_f0_e: ;
		/* line 1045 */
b_L1045: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_uci);
		b_poke((((((55296.0))+(((b_v_syi)*((40))))))+(b_v_sxi)),b_v_uli);
		/* line 2010 */
b_L2010: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2105 */
b_L2105: ;
		b_v_uci=B_INT(b_peek((unsigned int)((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)))));
		b_v_uli=B_INT(b_peek((unsigned int)((((((55296.0))+(((b_v_syi)*((40))))))+(b_v_sxi)))));
		/* line 2110 */
b_L2110: ;
		b_poke((((((1024))+(((b_v_syi)*((40))))))+(b_v_sxi)),(88));
		b_poke((((((55296.0))+(((b_v_syi)*((40))))))+(b_v_sxi)),(10));
		/* line 2115 */
b_L2115: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3005 */
b_L3005: ;
		if(-((b_v_sxi) > ((31)))){
			b_gosubStack[b_gosubSP++]=12; goto b_L3100;
b_ret12: ;
			b_v_oxi=((b_v_oxi)+((1)));
			b_v_sxi=((b_v_sxi)-((1)));
			b_v_cci=(39);
			b_v_wxi=((b_v_oxi)+((39)));
			b_gosubStack[b_gosubSP++]=13; goto b_L5000;
b_ret13: ;
		}
		/* line 3010 */
b_L3010: ;
		if(-((b_v_sxi) < ((8)))){
			b_gosubStack[b_gosubSP++]=14; goto b_L3200;
b_ret14: ;
			b_v_oxi=((b_v_oxi)-((1)));
			b_v_sxi=((b_v_sxi)+((1)));
			b_v_cci=(0);
			b_v_wxi=b_v_oxi;
			b_gosubStack[b_gosubSP++]=15; goto b_L5000;
b_ret15: ;
		}
		/* line 3015 */
b_L3015: ;
		if(-((b_v_syi) > ((16)))){
			b_gosubStack[b_gosubSP++]=16; goto b_L3300;
b_ret16: ;
			b_v_oyi=((b_v_oyi)+((1)));
			b_v_syi=((b_v_syi)-((1)));
			b_v_rri=(23);
			b_v_wyi=((b_v_oyi)+((23)));
			b_gosubStack[b_gosubSP++]=17; goto b_L6000;
b_ret17: ;
		}
		/* line 3020 */
b_L3020: ;
		if(-((b_v_syi) < ((8)))){
			b_gosubStack[b_gosubSP++]=18; goto b_L3400;
b_ret18: ;
			b_v_oyi=((b_v_oyi)-((1)));
			b_v_syi=((b_v_syi)+((1)));
			b_v_rri=(0);
			b_v_wyi=b_v_oyi;
			b_gosubStack[b_gosubSP++]=19; goto b_L6000;
b_ret19: ;
		}
		/* line 3025 */
b_L3025: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3105 */
b_L3105: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f2_e;
b_f2_t: ;
		/* line 3110 */
b_L3110: ;
		b_v_rai=((b_v_ri)*((40)));
		/* line 3115 */
b_L3115: ;
		b_v_ci=(0);
		if(b_v_ci > 38) goto b_f3_e;
		b_v_M0=(((1024))+(b_v_rai));
b_f3_t: ;
		/* line 3120 */
b_L3120: ;
		b_poke(((b_v_M0)+(b_v_ci)),B_INT(b_peek((unsigned int)(((((b_v_M0)+(b_v_ci)))+((1)))))));
		/* line 3125 */
b_L3125: ;
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_ci)),B_INT(b_peek((unsigned int)((((((((55296.0))+(b_v_rai)))+(b_v_ci)))+((1)))))));
		/* line 3130 */
b_L3130: ;
		b_v_ci += 1;
		if(b_v_ci <= 38) goto b_f3_t;
b_f3_e: ;
		/* line 3135 */
b_L3135: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f2_t;
b_f2_e: ;
		/* line 3140 */
b_L3140: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3205 */
b_L3205: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f4_e;
b_f4_t: ;
		/* line 3210 */
b_L3210: ;
		b_v_rai=((b_v_ri)*((40)));
		/* line 3215 */
b_L3215: ;
		b_v_ci=(38);
		if(b_v_ci < 0) goto b_f5_e;
		b_v_M1=(((1024))+(b_v_rai));
b_f5_t: ;
		/* line 3220 */
b_L3220: ;
		b_poke(((((b_v_M1)+(b_v_ci)))+((1))),B_INT(b_peek((unsigned int)(((b_v_M1)+(b_v_ci))))));
		/* line 3225 */
b_L3225: ;
		b_poke((((((((55296.0))+(b_v_rai)))+(b_v_ci)))+((1))),B_INT(b_peek((unsigned int)((((((55296.0))+(b_v_rai)))+(b_v_ci))))));
		/* line 3230 */
b_L3230: ;
		b_v_ci += -1;
		if(b_v_ci >= 0) goto b_f5_t;
b_f5_e: ;
		/* line 3235 */
b_L3235: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f4_t;
b_f4_e: ;
		/* line 3240 */
b_L3240: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		/* line 3305 */
b_L3305: ;
		b_v_ri=(0);
		if(b_v_ri > 22) goto b_f6_e;
b_f6_t: ;
		/* line 3310 */
b_L3310: ;
		b_v_rai=((b_v_ri)*((40)));
		b_v_rbi=((((b_v_ri)+((1))))*((40)));
		/* line 3315 */
b_L3315: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f7_e;
		b_v_M2=(((1024))+(b_v_rai));
		b_v_M3=(((1024))+(b_v_rbi));
b_f7_t: ;
		/* line 3320 */
b_L3320: ;
		b_poke(((b_v_M2)+(b_v_ci)),B_INT(b_peek((unsigned int)(((b_v_M3)+(b_v_ci))))));
		/* line 3325 */
b_L3325: ;
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_ci)),B_INT(b_peek((unsigned int)((((((55296.0))+(b_v_rbi)))+(b_v_ci))))));
		/* line 3330 */
b_L3330: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f7_t;
b_f7_e: ;
		/* line 3335 */
b_L3335: ;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f6_t;
b_f6_e: ;
		/* line 3340 */
b_L3340: ;
		goto b_return;
		/* line 3400 */
b_L3400: ;
		/* line 3405 */
b_L3405: ;
		b_v_ri=(23);
		if(b_v_ri < 1) goto b_f8_e;
b_f8_t: ;
		/* line 3410 */
b_L3410: ;
		b_v_rai=((b_v_ri)*((40)));
		b_v_rbi=((((b_v_ri)-((1))))*((40)));
		/* line 3415 */
b_L3415: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f9_e;
		b_v_M4=(((1024))+(b_v_rai));
		b_v_M5=(((1024))+(b_v_rbi));
b_f9_t: ;
		/* line 3420 */
b_L3420: ;
		b_poke(((b_v_M4)+(b_v_ci)),B_INT(b_peek((unsigned int)(((b_v_M5)+(b_v_ci))))));
		/* line 3425 */
b_L3425: ;
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_ci)),B_INT(b_peek((unsigned int)((((((55296.0))+(b_v_rbi)))+(b_v_ci))))));
		/* line 3430 */
b_L3430: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f9_t;
b_f9_e: ;
		/* line 3435 */
b_L3435: ;
		b_v_ri += -1;
		if(b_v_ri >= 1) goto b_f8_t;
b_f8_e: ;
		/* line 3440 */
b_L3440: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5005 */
b_L5005: ;
		b_v_ixi=b_v_wxi;
		/* line 5010 */
b_L5010: ;
		b_v_ri=(0);
		if(b_v_ri > 23) goto b_f10_e;
b_f10_t: ;
		/* line 5015 */
b_L5015: ;
		b_v_iyi=((b_v_oyi)+(b_v_ri));
		b_v_rai=((b_v_ri)*((40)));
		/* line 5020 */
b_L5020: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L8000;
b_ret20: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L7000;
b_ret21: ;
		/* line 5025 */
b_L5025: ;
		b_poke((((((1024))+(b_v_rai)))+(b_v_cci)),b_v_chi);
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_cci)),b_v_cli);
		/* line 5030 */
b_L5030: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f10_t;
b_f10_e: ;
		/* line 5035 */
b_L5035: ;
		goto b_return;
		/* line 6000 */
b_L6000: ;
		/* line 6005 */
b_L6005: ;
		b_v_iyi=b_v_wyi;
		b_v_rai=((b_v_rri)*((40)));
		/* line 6010 */
b_L6010: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f11_e;
b_f11_t: ;
		/* line 6015 */
b_L6015: ;
		b_v_ixi=((b_v_oxi)+(b_v_ci));
		/* line 6020 */
b_L6020: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L8000;
b_ret22: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L7000;
b_ret23: ;
		/* line 6025 */
b_L6025: ;
		b_poke((((((1024))+(b_v_rai)))+(b_v_ci)),b_v_chi);
		b_poke((((((55296.0))+(b_v_rai)))+(b_v_ci)),b_v_cli);
		/* line 6030 */
b_L6030: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f11_t;
b_f11_e: ;
		/* line 6035 */
b_L6035: ;
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7005 */
b_L7005: ;
		b_v_chi=(35);
		b_v_cli=(1);
		/* line 7010 */
b_L7010: ;
		if(-((b_v_hti) < ((10)))){
			b_v_chi=(32);
			b_v_cli=(6);
			goto b_return;
		}
		/* line 7015 */
b_L7015: ;
		if(-((b_v_hti) < ((20)))){
			b_v_chi=(46);
			b_v_cli=(14);
			goto b_return;
		}
		/* line 7020 */
b_L7020: ;
		if(-((b_v_hti) < ((30)))){
			b_v_chi=(58);
			b_v_cli=(5);
			goto b_return;
		}
		/* line 7025 */
b_L7025: ;
		if(-((b_v_hti) < ((40)))){
			b_v_chi=(45);
			b_v_cli=(13);
			goto b_return;
		}
		/* line 7030 */
b_L7030: ;
		if(-((b_v_hti) < ((50)))){
			b_v_chi=(43);
			b_v_cli=(8);
			goto b_return;
		}
		/* line 7035 */
b_L7035: ;
		if(-((b_v_hti) < ((60)))){
			b_v_chi=(42);
			b_v_cli=(7);
			goto b_return;
		}
		/* line 7040 */
b_L7040: ;
		goto b_return;
		/* line 8000 */
b_L8000: ;
		/* line 8005 */
b_L8005: ;
		b_v_hti=((((((b_a_sli[B_INT((B_INT(((b_v_ixi)*((3)))) & B_INT((63))))])+(b_a_sli[B_INT((B_INT(((b_v_iyi)*((4)))) & B_INT((63))))])))+(b_a_sli[B_INT((B_INT(((((b_v_ixi)+(b_v_iyi)))*((2)))) & B_INT((63))))])))+((30)));
		/* line 8010 */
b_L8010: ;
		goto b_return;
		/* line 8300 */
b_L8300: ;
		/* line 8305 */
b_L8305: ;
		b_putc(147);
		b_nl();
		/* line 8310 */
b_L8310: ;
		{ bstr_t _t=b_lit("                LANDSCAPE",25); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8315 */
b_L8315: ;
		b_nl();
		{ bstr_t _t=b_lit("        W/A/S/D PAN  Q=QUIT",27); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8320 */
b_L8320: ;
		b_nl();
		{ bstr_t _t=b_lit("      EXPLORE ENDLESS TERRAIN",29); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8325 */
b_L8325: ;
		b_nl();
		{ bstr_t _t=b_lit("      SUM OF 3 SINES  NO RND",28); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8330 */
b_L8330: ;
		b_nl();
		{ bstr_t _t=b_lit("        SPACE TO PLAY  D=DEMO",29); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8335 */
b_L8335: ;
		b_v_gdi=(1);
		if(b_v_gdi > 200) goto b_f12_e;
		{ b_rtfor_t _f; _f.top_id=12; _f.pI=&b_v_gdi; _f.vtype=1; _f.lim.i=200; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f12_t: ;
		/* line 8337 */
b_L8337: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 8340 */
b_L8340: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 8345 */
b_L8345: ;
		if(-((b_v_ki) == ((18)))){
			b_v_dmi=(1);
			goto b_L8390;
		}
		/* line 8350 */
b_L8350: ;
		if(-((b_v_ki) != ((64)))){
			b_v_dmi=(0);
			goto b_L8390;
		}
		/* line 8355 */
b_L8355: ;
		b_v_gdi += 1;
		if(b_v_gdi <= 200) goto b_f12_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f12_e: ;
		/* line 8360 */
b_L8360: ;
		b_v_dmi=(1);
		/* line 8390 */
b_L8390: ;
		b_putc(147);
		b_nl();
		/* line 8395 */
b_L8395: ;
		goto b_return;
		/* line 8400 */
b_L8400: ;
		/* line 8405 */
b_L8405: ;
		b_v_ki=(64);
		/* line 8410 */
b_L8410: ;
		b_v_rri=b_int(((b_rnd(B_INT((1))))*((4))));
		/* line 8415 */
b_L8415: ;
		if(-((b_v_rri) == ((0)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 8420 */
b_L8420: ;
		if(-((b_v_rri) == ((1)))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 8425 */
b_L8425: ;
		if(-((b_v_rri) == ((2)))){
			b_v_ki=(13);
			goto b_return;
		}
		/* line 8430 */
b_L8430: ;
		b_v_ki=(18);
		goto b_return;
		/* line 8500 */
b_L8500: ;
		/* line 8505 */
b_L8505: ;
		b_v_sai=(1984);
		b_v_sbi=(((55296.0))+((960)));
		/* line 8510 */
b_L8510: ;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f13_e;
		b_t_0=((b_v_sai)+(b_v_ii));
		b_t_1=((b_v_sbi)+(b_v_ii));
b_f13_t: ;
		b_poke(b_t_0,(32));
		b_poke(b_t_1,(14));
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f13_t;
b_f13_e: ;
		/* line 8515 */
b_L8515: ;
		b_v_txi=(0);
		b_v_tyi=(24);
		b_v_ts=b_keep(b_lit("WASD PAN Q=QUIT",15));
		b_gosubStack[b_gosubSP++]=24; goto b_L8600;
b_ret24: ;
		/* line 8520 */
b_L8520: ;
		b_v_txi=(16);
		b_v_ts=b_keep(b_lit("X=",2));
		b_gosubStack[b_gosubSP++]=25; goto b_L8600;
b_ret25: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_vvi=b_v_oxi;
		b_gosubStack[b_gosubSP++]=26; goto b_L8700;
b_ret26: ;
		b_v_txi=((b_v_txi)+((5)));
		/* line 8525 */
b_L8525: ;
		b_v_txi=((b_v_txi)+((1)));
		b_v_ts=b_keep(b_lit("Y=",2));
		b_gosubStack[b_gosubSP++]=27; goto b_L8600;
b_ret27: ;
		b_v_txi=((b_v_txi)+((2)));
		b_v_vvi=b_v_oyi;
		b_gosubStack[b_gosubSP++]=28; goto b_L8700;
b_ret28: ;
		/* line 8530 */
b_L8530: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_txi=(32);
			b_v_ts=b_keep(b_lit("DEMO",4));
			b_gosubStack[b_gosubSP++]=29; goto b_L8600;
b_ret29: ;
		}
		/* line 8535 */
b_L8535: ;
		goto b_return;
		/* line 8600 */
b_L8600: ;
		/* line 8605 */
b_L8605: ;
		if(-(b_strcmp(b_v_ts,b_lit("",0)) == 0)){
			goto b_return;
		}
		/* line 8610 */
b_L8610: ;
		b_v_sai=(((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi));
		/* line 8615 */
b_L8615: ;
		b_v_ii=(1);
		b_fl_14=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_14) goto b_f14_e;
b_f14_t: ;
		/* line 8620 */
b_L8620: ;
		b_v_qzi=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 8625 */
b_L8625: ;
		if(-((b_v_qzi) >= ((64)))){
			if(-((b_v_qzi) <= ((95)))){
				b_v_qzi=((b_v_qzi)-((64)));
			}
		}
		/* line 8630 */
b_L8630: ;
		b_poke(b_v_sai,b_v_qzi);
		b_v_sai=((b_v_sai)+((1)));
		/* line 8635 */
b_L8635: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_14)) goto b_f14_t;
b_f14_e: ;
		/* line 8640 */
b_L8640: ;
		goto b_return;
		/* line 8700 */
b_L8700: ;
		/* line 8705 */
b_L8705: ;
		b_v_sgi=(0);
		if(-((b_v_vvi) < ((0)))){
			b_v_sgi=(1);
			b_v_vvi=(((0))-(b_v_vvi));
		}
		/* line 8710 */
b_L8710: ;
		b_v_d4i=((breal_t)(b_v_vvi)/(breal_t)((1000)));
		b_v_d3i=((breal_t)(((b_v_vvi)-(((b_v_d4i)*((1000))))))/(breal_t)((100)));
		b_v_d2i=((breal_t)(((((b_v_vvi)-(((b_v_d4i)*((1000))))))-(((b_v_d3i)*((100))))))/(breal_t)((10)));
		b_v_d1i=((((((b_v_vvi)-(((b_v_d4i)*((1000))))))-(((b_v_d3i)*((100))))))-(((b_v_d2i)*((10)))));
		/* line 8715 */
b_L8715: ;
		b_v_sai=(((1984))+(b_v_txi));
		if(-((b_v_sgi) == ((1)))){
			b_poke(b_v_sai,(45));
			b_poke(((b_v_sai)+((1))),((b_v_d4i)+((48))));
			b_poke(((b_v_sai)+((2))),((b_v_d3i)+((48))));
			b_poke(((b_v_sai)+((3))),((b_v_d2i)+((48))));
			b_poke(((b_v_sai)+((4))),((b_v_d1i)+((48))));
			goto b_return;
		}
		/* line 8720 */
b_L8720: ;
		b_poke(b_v_sai,(32));
		b_poke(((b_v_sai)+((1))),((b_v_d4i)+((48))));
		b_poke(((b_v_sai)+((2))),((b_v_d3i)+((48))));
		b_poke(((b_v_sai)+((3))),((b_v_d2i)+((48))));
		b_poke(((b_v_sai)+((4))),((b_v_d1i)+((48))));
		/* line 8725 */
b_L8725: ;
		goto b_return;
		/* line 9600 */
b_L9600: ;
		/* line 9605 */
b_L9605: ;
		b_v_ii=(0);
		if(b_v_ii > 63) goto b_f15_e;
b_f15_t: ;
		b_v_u0i=b_read_int();
		b_a_sli[B_INT(b_v_ii)]=b_v_u0i;
		b_v_ii += 1;
		if(b_v_ii <= 63) goto b_f15_t;
b_f15_e: ;
		/* line 9610 */
b_L9610: ;
		goto b_return;
		/* line 9620 */
b_L9620: ;
		/* line 9625 */
b_L9625: ;
		/* line 9630 */
b_L9630: ;
		/* line 9635 */
b_L9635: ;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
