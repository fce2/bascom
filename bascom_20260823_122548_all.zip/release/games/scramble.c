/* OPTIMIZE_C -- scramble.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_cei[40];
static bint_t b_a_fli[40];
static bint_t b_a_sti[40];
static int b_a_dxi[13];
static int b_a_dyi[13];
static int b_a_dci[13];
static breal_t b_v_gcf;
static int b_v_gwi;
static bint_t b_v_ci;
static bint_t b_v_syi;
static int b_v_lvi;
static int b_v_sci;
static breal_t b_v_tdf;
static bint_t b_v_lei;
static int b_v_d0i;
static int b_v_d1i;
static int b_v_d2i;
static bint_t b_v_d3i;
static int b_v_p0i;
static int b_v_p1i;
static int b_v_l1i;
static bint_t b_v_l0i;
static bint_t b_v_sxi;
static int b_v_hi;
static bint_t b_v_wi;
static int b_v_lui;
static int b_v_bfi;
static int b_v_sii;
static int b_v_lpi;
static int b_v_lbi;
static bint_t b_v_rdi;
static int b_v_goi;
static int b_v_dmi;
static bstr_t b_v_ts;
static int b_v_pxi;
static int b_v_pyi;
static bint_t b_v_oxi;
static bint_t b_v_oyi;
static bint_t b_v_ki;
static bint_t b_v_bxi;
static bint_t b_v_byi;
static bint_t b_v_sri;
static int b_v_cli;
static int b_v_mdi;
static bint_t b_v_ji;
static int b_v_cvi;
static bint_t b_v_fvi;
static bint_t b_v_bai;
static bint_t b_v_ri;
static breal_t b_v_dcf;
static int b_v_lci;
static breal_t b_v_dff;
static int b_v_lfi;
static int b_v_eri;
static bint_t b_v_eci;
static int b_v_aci;
static int b_v_nci;
static bint_t b_v_rri;
static bint_t b_v_cci;
static int b_v_ssi;
static int b_v_ai;
static int b_v_bi;
static int b_v_zi;
static bint_t b_v_txi;
static int b_v_pci;
static int b_v_ami;
static int b_v_hwi;
static bstr_t b_v_ks;
static bint_t b_v_cxi;
static bint_t b_v_cyi;
static int b_v_li;
static bint_t b_v_chi;
static breal_t b_v_z0f;
static int b_v_z1i;
static int b_v_z2i;
static int b_v_z3i;
static int b_v_bci;
static breal_t b_v_brf;
static int b_v_ii;
static bint_t b_v_mxi;
static bint_t b_v_mni;
static unsigned int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_fl_3;
static bint_t b_fl_4;
static bint_t b_fl_8;
static bint_t b_fl_9;
static bint_t b_fl_10;
static bint_t b_fl_11;
static bint_t b_fl_12;
static bint_t b_fl_13;
static int b_fl_15;
static breal_t b_fl_16;
static int b_fl_21;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,3,0,0},{1,0,6,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,42,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,60,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,81,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,60,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,62,0,0},{1,0,4,0,0},{1,0,12,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,-1,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,1,0,0},{1,0,62,0,0},{1,0,4,0,0},{1,0,12,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,-1,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,81,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,1,0,0},{1,0,62,0,0},{1,0,4,0,0},{1,0,12,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,60,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,-1,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,60,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,1,0,0},{1,0,62,0,0},{1,0,4,0,0},{1,0,12,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,-1,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,81,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,3,0,0},{1,0,1,0,0},{1,0,62,0,0},{1,0,3,0,0},{1,0,9,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,-1,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,1,0,0},{1,0,0,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,62,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,46,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,61,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,62,0,0}};
int b_data_len = 201;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		b_v_gcf=(12);
		b_v_gwi=(12);
		/* line 40 */
b_L40: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f0_e;
b_f0_t: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1800;
b_ret0: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f0_t;
b_f0_e: ;
		/* line 50 */
b_L50: ;
		b_v_syi=(12);
		b_v_lvi=(3);
		b_v_sci=(0);
		b_v_tdf=(0);
		b_v_lei=(1);
		b_v_d0i=(0);
		b_v_d1i=(0);
		b_v_d2i=(0);
		b_v_d3i=(0);
		b_v_p0i=(0);
		b_v_p1i=(0);
		b_v_l1i=(0);
		b_v_l0i=(1);
		b_v_sxi=(5);
		b_v_hi=(1);
		b_v_wi=(3);
		b_v_lui=(0);
		b_v_bfi=(0);
		b_v_sii=(1);
		b_v_lpi=(0);
		b_v_lbi=(-1);
		b_v_rdi=(-1);
		b_v_goi=(0);
		b_v_dmi=(1);
		/* line 60 */
b_L60: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		b_v_pxi=(0);
		b_v_pyi=(0);
		b_gosubStack[b_gosubSP++]=1; goto b_L2200;
b_ret1: ;
		/* line 70 */
b_L70: ;
		b_v_ts=b_keep(b_lit("LIVES",5));
		b_v_pxi=(11);
		b_v_pyi=(0);
		b_gosubStack[b_gosubSP++]=2; goto b_L2200;
b_ret2: ;
		/* line 80 */
b_L80: ;
		b_v_ts=b_keep(b_lit("LEVEL",5));
		b_v_pxi=(19);
		b_v_pyi=(0);
		b_gosubStack[b_gosubSP++]=3; goto b_L2200;
b_ret3: ;
		/* line 90 */
b_L90: ;
		b_poke((1030),(48));
		b_poke((1031),(48));
		b_poke((1032),(48));
		b_poke((1033),(48));
		b_poke((1041),(((48))+(b_v_lvi)));
		b_poke((1049),(((48))+(b_v_l1i)));
		b_poke((1050),(((48))+(b_v_l0i)));
		b_poke((1052),(((48))+(b_v_p1i)));
		b_poke((1053),(((48))+(b_v_p0i)));
		b_poke((1054),(37));
		/* line 100 */
b_L100: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1500;
b_ret4: ;
		/* line 110 */
b_L110: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1000;
b_ret5: ;
		/* line 120 */
b_L120: ;
		b_v_oxi=b_v_sxi;
		b_v_oyi=b_v_syi;
		/* line 130 */
b_L130: ;
		if(-((b_v_syi) < ((((1))+(b_v_hi))))){
			b_v_syi=(((1))+(b_v_hi));
		}
		/* line 140 */
b_L140: ;
		if(-((b_v_syi) > ((((24))-(b_v_hi))))){
			b_v_syi=(((24))-(b_v_hi));
		}
		/* line 148 */
b_L148: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		/* line 150 */
b_L150: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 155 */
b_L155: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) != ((64)))){
				b_v_dmi=(0);
			}
		}
		/* line 156 */
b_L156: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=6; goto b_L5500;
b_ret6: ;
		}
		/* line 160 */
b_L160: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 170 */
b_L170: ;
		if(-((b_v_ki) == ((9)))){
			if(-((b_v_syi) > ((((1))+(b_v_hi))))){
				b_v_syi=((b_v_syi)-((1)));
			}
		}
		/* line 180 */
b_L180: ;
		if(-((b_v_ki) == ((13)))){
			if(-((b_v_syi) < ((((24))-(b_v_hi))))){
				b_v_syi=((b_v_syi)+((1)));
			}
		}
		/* line 190 */
b_L190: ;
		if(-((b_v_ki) == ((10)))){
			if(-((b_v_sxi) > ((0)))){
				b_v_sxi=((b_v_sxi)-((1)));
			}
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_ki) == ((18)))){
			if(-((b_v_sxi) < ((((40))-(b_v_wi))))){
				b_v_sxi=((b_v_sxi)+((1)));
			}
		}
		/* line 210 */
b_L210: ;
		if(-((b_v_ki) == ((60)))){
			if(-((b_v_bfi) == ((0)))){
				if(-((((b_v_sxi)+(b_v_wi))) <= ((39)))){
					b_v_bfi=(1);
					b_v_bxi=((b_v_sxi)+(b_v_wi));
					b_v_byi=b_v_syi;
				}
			}
		}
		/* line 220 */
b_L220: ;
		b_v_ci=(0);
		if(b_v_ci > 38) goto b_f1_e;
b_f1_t: ;
		b_a_cei[B_INT(b_v_ci)]=b_a_cei[B_INT(((b_v_ci)+((1))))];
		b_a_fli[B_INT(b_v_ci)]=b_a_fli[B_INT(((b_v_ci)+((1))))];
		b_a_sti[B_INT(b_v_ci)]=b_a_sti[B_INT(((b_v_ci)+((1))))];
		b_v_ci += 1;
		if(b_v_ci <= 38) goto b_f1_t;
b_f1_e: ;
		/* line 230 */
b_L230: ;
		b_v_ci=(39);
		b_gosubStack[b_gosubSP++]=7; goto b_L1800;
b_ret7: ;
		/* line 240 */
b_L240: ;
		b_v_sri=((((b_v_sxi)+(b_v_wi)))-((1)));
		/* line 250 */
b_L250: ;
		if(b_v_bfi){
			b_v_bxi=((b_v_bxi)+((1)));
			if(-((b_v_bxi) > ((39)))){
				b_v_bfi=(0);
			}
		}
		/* line 255 */
b_L255: ;
		if(b_v_bfi){
			if(-((b_a_sti[B_INT(b_v_bxi)]) > ((0)))){
				if(-((b_a_sti[B_INT(b_v_bxi)]) == (b_v_byi))){
					b_v_sci=((b_v_sci)+((25)));
					b_v_tdf=((b_v_tdf)+((25)));
					b_a_sti[B_INT(b_v_bxi)]=(0);
					b_gosubStack[b_gosubSP++]=8; goto b_L1700;
b_ret8: ;
				}
			}
		}
		/* line 260 */
b_L260: ;
		if(b_v_bfi){
			if((B_INT(-((b_v_byi) < (b_a_cei[B_INT(b_v_bxi)]))) | B_INT(-((b_v_byi) > (b_a_fli[B_INT(b_v_bxi)]))))){
				b_gosubStack[b_gosubSP++]=9; goto b_L2100;
b_ret9: ;
			}
		}
		/* line 270 */
b_L270: ;
		if(b_v_lpi){
			b_v_lpi=(0);
			b_gosubStack[b_gosubSP++]=10; goto b_L1000;
b_ret10: ;
			goto b_L290;
		}
		/* line 280 */
b_L280: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L1300;
b_ret11: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1200;
b_ret12: ;
		/* line 290 */
b_L290: ;
		b_v_sci=((b_v_sci)+((1)));
		b_v_tdf=((b_v_tdf)+((1)));
		/* line 300 */
b_L300: ;
		b_gosubStack[b_gosubSP++]=13; goto b_L1700;
b_ret13: ;
		/* line 310 */
b_L310: ;
		if(-((b_v_sci) >= ((500)))){
			b_v_sci=(0);
			if(-((b_v_gwi) > ((4)))){
				b_v_gwi=((b_v_gwi)-((1)));
			}
		}
		/* line 320 */
b_L320: ;
		b_v_cli=(0);
		b_v_mdi=(1);
		b_gosubStack[b_gosubSP++]=14; goto b_L1400;
b_ret14: ;
		if(-((b_v_cli) == ((1)))){
			b_gosubStack[b_gosubSP++]=15; goto b_L1900;
b_ret15: ;
		}
		/* line 330 */
b_L330: ;
		if(b_v_goi){
			b_v_goi=(0);
			goto b_L2104;
		}
		/* line 340 */
b_L340: ;
		b_v_ji=(1);
		if(b_v_ji > 20) goto b_f2_e;
b_f2_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 20) goto b_f2_t;
b_f2_e: ;
		/* line 350 */
b_L350: ;
		goto b_L120;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_ci=(0);
		/* line 1002 */
b_L1002: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L1100;
b_ret16: ;
		/* line 1003 */
b_L1003: ;
		b_v_ci=((b_v_ci)+((1)));
		if(-((b_v_ci) <= ((39)))){ goto b_L1002; }
		/* line 1004 */
b_L1004: ;
		b_v_mdi=(0);
		b_gosubStack[b_gosubSP++]=17; goto b_L1400;
b_ret17: ;
		/* line 1005 */
b_L1005: ;
		b_v_oxi=b_v_sxi;
		b_v_oyi=b_v_syi;
		/* line 1006 */
b_L1006: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_cvi=b_a_cei[B_INT(b_v_ci)];
		b_v_fvi=b_a_fli[B_INT(b_v_ci)];
		b_v_bai=(((1024))+(b_v_ci));
		/* line 1102 */
b_L1102: ;
		b_v_ri=(1);
		b_fl_3=((b_v_cvi)-((1)));
		if(b_v_ri > b_fl_3) goto b_f3_e;
		b_t_6=((b_v_bai)+(((b_v_ri)*((40)))));
b_f3_t: ;
		b_poke(b_t_6,(160));
		b_t_6 += 40;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 1103 */
b_L1103: ;
		b_v_ri=b_v_cvi;
		b_fl_4=b_v_fvi;
		if(b_v_ri > b_fl_4) goto b_f4_e;
		b_t_7=((b_v_bai)+(((b_v_ri)*((40)))));
b_f4_t: ;
		b_poke(b_t_7,(32));
		b_t_7 += 40;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 1104 */
b_L1104: ;
		if(-((b_a_sti[B_INT(b_v_ci)]) > ((0)))){
			b_poke(((b_v_bai)+(((b_a_sti[B_INT(b_v_ci)])*((40))))),(46));
		}
		/* line 1105 */
b_L1105: ;
		b_v_ri=((b_v_fvi)+((1)));
		if(b_v_ri > 24) goto b_f5_e;
		b_t_8=((b_v_bai)+(((b_v_ri)*((40)))));
b_f5_t: ;
		b_poke(b_t_8,(160));
		b_t_8 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 24) goto b_f5_t;
b_f5_e: ;
		/* line 1106 */
b_L1106: ;
		if(-((b_v_ci) == ((0)))){
			goto b_return;
		}
		/* line 1107 */
b_L1107: ;
		b_v_dcf=((b_a_cei[B_INT(b_v_ci)])-(b_a_cei[B_INT(((b_v_ci)-((1))))]));
		b_v_lci=(160);
		if(-((b_v_dcf) > ((0)))){
			b_v_lci=(226);
		}
		/* line 1108 */
b_L1108: ;
		if(-((b_v_dcf) < ((0)))){
			b_v_lci=(236);
		}
		/* line 1109 */
b_L1109: ;
		if(-((b_a_cei[B_INT(b_v_ci)]) > ((1)))){
			b_poke(((b_v_bai)+(((((b_a_cei[B_INT(b_v_ci)])-((1))))*((40))))),b_v_lci);
		}
		/* line 1110 */
b_L1110: ;
		b_v_dff=((b_a_fli[B_INT(b_v_ci)])-(b_a_fli[B_INT(((b_v_ci)-((1))))]));
		b_v_lfi=(160);
		if(-((b_v_dff) > ((0)))){
			b_v_lfi=(252);
		}
		/* line 1111 */
b_L1111: ;
		if(-((b_v_dff) < ((0)))){
			b_v_lfi=(98);
		}
		/* line 1112 */
b_L1112: ;
		if(-((b_a_fli[B_INT(b_v_ci)]) < ((24)))){
			b_poke(((b_v_bai)+(((((b_a_fli[B_INT(b_v_ci)])+((1))))*((40))))),b_v_lfi);
		}
		/* line 1113 */
b_L1113: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_ri=(1);
		if(b_v_ri > 24) goto b_f6_e;
b_f6_t: ;
		/* line 1202 */
b_L1202: ;
		b_v_bai=(((1024))+(((b_v_ri)*((40)))));
		/* line 1203 */
b_L1203: ;
		if((B_INT(-((b_v_ri) >= (((b_v_syi)-((1)))))) & B_INT(-((b_v_ri) <= (((b_v_syi)+((1)))))))){ goto b_L1206; }
		/* line 1204 */
b_L1204: ;
		b_v_ci=(0);
		if(b_v_ci > 38) goto b_f7_e;
b_f7_t: ;
		b_poke(b_v_bai,B_INT(b_peek((unsigned int)(((b_v_bai)+((1)))))));
		b_v_ci += 1;
		if(b_v_ci <= 38) goto b_f7_t;
b_f7_e: ;
		/* line 1205 */
b_L1205: ;
		goto b_L1208;
		/* line 1206 */
b_L1206: ;
		if(-((b_v_sxi) > ((0)))){
			b_v_ci=(0);
			b_fl_8=((b_v_sxi)-((1)));
			if(b_v_ci > b_fl_8) goto b_f8_e;
b_f8_t: ;
			b_poke(b_v_bai,B_INT(b_peek((unsigned int)(((b_v_bai)+((1)))))));
			b_v_bai=((b_v_bai)+((1)));
			b_v_ci += 1;
			if(b_v_ci <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		}
		/* line 1207 */
b_L1207: ;
		b_v_bai=((b_v_bai)+(b_v_wi));
		if(-((((b_v_sxi)+(b_v_wi))) <= ((38)))){
			b_v_ci=(0);
			b_fl_9=(((((38))-(b_v_sxi)))-(b_v_wi));
			if(b_v_ci > b_fl_9) goto b_f9_e;
b_f9_t: ;
			b_poke(b_v_bai,B_INT(b_peek((unsigned int)(((b_v_bai)+((1)))))));
			b_v_bai=((b_v_bai)+((1)));
			b_v_ci += 1;
			if(b_v_ci <= (b_fl_9)) goto b_f9_t;
b_f9_e: ;
		}
		/* line 1208 */
b_L1208: ;
		b_v_ri += 1;
		if(b_v_ri <= 24) goto b_f6_t;
b_f6_e: ;
		/* line 1209 */
b_L1209: ;
		b_v_mdi=(0);
		b_gosubStack[b_gosubSP++]=18; goto b_L1400;
b_ret18: ;
		/* line 1210 */
b_L1210: ;
		b_v_ci=(39);
		b_gosubStack[b_gosubSP++]=19; goto b_L1100;
b_ret19: ;
		/* line 1211 */
b_L1211: ;
		b_v_ci=((b_v_sxi)-((1)));
		if((B_INT(-((b_v_ci) >= ((0)))) & B_INT(-((b_v_ci) <= ((39)))))){
			b_gosubStack[b_gosubSP++]=20; goto b_L1100;
b_ret20: ;
		}
		/* line 1212 */
b_L1212: ;
		b_v_ci=((b_v_sxi)-((2)));
		if((B_INT(-((b_v_ci) >= ((0)))) & B_INT(-((b_v_ci) <= ((39)))))){
			b_gosubStack[b_gosubSP++]=21; goto b_L1100;
b_ret21: ;
		}
		/* line 1213 */
b_L1213: ;
		if((B_INT(-((b_v_rdi) >= ((0)))) & B_INT(-((b_v_rdi) <= ((39)))))){
			b_v_ci=b_v_rdi;
			b_gosubStack[b_gosubSP++]=22; goto b_L1100;
b_ret22: ;
		}
		/* line 1214 */
b_L1214: ;
		b_v_rdi=(-1);
		/* line 1215 */
b_L1215: ;
		if((B_INT(-((b_v_lbi) >= ((0)))) & B_INT(-((b_v_lbi) <= ((39)))))){
			b_v_ci=((b_v_lbi)-((1)));
			if((B_INT(-((b_v_ci) >= ((0)))) & B_INT(-((b_v_ci) <= ((39)))))){
				b_gosubStack[b_gosubSP++]=23; goto b_L1100;
b_ret23: ;
			}
		}
		/* line 1216 */
b_L1216: ;
		if(b_v_bfi){
			if(-((b_v_bxi) <= ((39)))){
				b_poke((((((1024))+(b_v_bxi)))+(((b_v_byi)*((40))))),(62));
				b_v_lbi=b_v_bxi;
				goto b_L1218;
			}
		}
		/* line 1217 */
b_L1217: ;
		b_v_lbi=(-1);
		/* line 1218 */
b_L1218: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		if(-((b_v_oyi) == (b_v_syi))){
			goto b_return;
		}
		/* line 1302 */
b_L1302: ;
		if(-((b_v_oyi) < (b_v_syi))){
			b_v_eri=((b_v_oyi)-((1)));
			goto b_L1304;
		}
		/* line 1303 */
b_L1303: ;
		b_v_eri=((b_v_oyi)+((1)));
		/* line 1304 */
b_L1304: ;
		if(-((b_v_eri) < ((1)))){
			goto b_return;
		}
		/* line 1305 */
b_L1305: ;
		if(-((b_v_eri) > ((24)))){
			goto b_return;
		}
		/* line 1306 */
b_L1306: ;
		b_v_eci=(0);
		b_fl_10=((b_v_wi)-((1)));
		if(b_v_eci > b_fl_10) goto b_f10_e;
b_f10_t: ;
		/* line 1307 */
b_L1307: ;
		b_v_aci=((b_v_oxi)+(b_v_eci));
		if(-((b_v_aci) < ((0)))){ goto b_L1311; }
		/* line 1308 */
b_L1308: ;
		if(-((b_v_aci) > ((39)))){ goto b_L1311; }
		/* line 1309 */
b_L1309: ;
		if(-((b_v_eri) >= (b_a_cei[B_INT(b_v_aci)]))){
			if(-((b_v_eri) <= (b_a_fli[B_INT(b_v_aci)]))){
				b_poke((((((1024))+(((b_v_eri)*((40))))))+(b_v_aci)),(32));
				goto b_L1311;
			}
		}
		/* line 1310 */
b_L1310: ;
		b_poke((((((1024))+(((b_v_eri)*((40))))))+(b_v_aci)),(160));
		/* line 1311 */
b_L1311: ;
		b_v_eci += 1;
		if(b_v_eci <= (b_fl_10)) goto b_f10_t;
b_f10_e: ;
		/* line 1312 */
b_L1312: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_v_ji=(1);
		b_fl_11=b_v_nci;
		if(b_v_ji > b_fl_11) goto b_f11_e;
b_f11_t: ;
		b_v_rri=b_a_dyi[B_INT(b_v_ji)];
		b_v_cci=b_a_dxi[B_INT(b_v_ji)];
		b_v_ssi=b_a_dci[B_INT(b_v_ji)];
		b_gosubStack[b_gosubSP++]=24; goto b_L1600;
b_ret24: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_11)) goto b_f11_t;
b_f11_e: ;
		/* line 1402 */
b_L1402: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_dataPtr = 0;
		b_v_ji=(1);
		b_fl_12=b_v_sii;
		if(b_v_ji > b_fl_12) goto b_f12_e;
b_f12_t: ;
		b_v_wi=b_read_int();
		b_v_nci=b_read_int();
		b_v_ki=(1);
		b_fl_13=b_v_nci;
		if(b_v_ki > b_fl_13) goto b_f13_e;
b_f13_t: ;
		b_v_ai=b_read_int();
		b_v_bi=b_read_int();
		b_v_zi=b_read_int();
		b_a_dxi[B_INT(b_v_ki)]=b_v_ai;
		b_a_dyi[B_INT(b_v_ki)]=b_v_bi;
		b_a_dci[B_INT(b_v_ki)]=b_v_zi;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_13)) goto b_f13_t;
b_f13_e: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_12)) goto b_f12_t;
b_f12_e: ;
		/* line 1502 */
b_L1502: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		if(-((b_v_mdi) == ((0)))){
			b_poke((((((1024))+(((b_v_sxi)+(b_v_cci)))))+(((((b_v_syi)+(b_v_rri)))*((40))))),b_v_ssi);
			goto b_return;
		}
		/* line 1602 */
b_L1602: ;
		b_v_txi=((b_v_sxi)+(b_v_cci));
		if((B_INT(-((b_v_txi) < ((0)))) | B_INT(-((b_v_txi) > ((39)))))){
			b_v_cli=(1);
			goto b_return;
		}
		/* line 1603 */
b_L1603: ;
		if((B_INT(-((((b_v_syi)+(b_v_rri))) < (b_a_cei[B_INT(b_v_txi)]))) | B_INT(-((((b_v_syi)+(b_v_rri))) > (b_a_fli[B_INT(b_v_txi)]))))){
			b_v_cli=(1);
			goto b_return;
		}
		/* line 1604 */
b_L1604: ;
		goto b_return;
		/* line 1605 */
b_L1605: ;
		/* line 1606 */
b_L1606: ;
		/* line 1607 */
b_L1607: ;
		/* line 1608 */
b_L1608: ;
		/* line 1609 */
b_L1609: ;
		/* line 1610 */
b_L1610: ;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_d0i=((b_v_d0i)+((1)));
		if(-((b_v_d0i) > ((9)))){
			b_v_d0i=(0);
			b_v_d1i=((b_v_d1i)+((1)));
			if(-((b_v_d1i) > ((9)))){
				b_v_d1i=(0);
				b_v_d2i=((b_v_d2i)+((1)));
				if(-((b_v_d2i) > ((9)))){
					b_v_d2i=(0);
					b_v_d3i=((b_v_d3i)+((1)));
				}
			}
		}
		/* line 1702 */
b_L1702: ;
		b_poke((1030),(((48))+(b_v_d3i)));
		b_poke((1031),(((48))+(b_v_d2i)));
		b_poke((1032),(((48))+(b_v_d1i)));
		b_poke((1033),(((48))+(b_v_d0i)));
		/* line 1703 */
b_L1703: ;
		b_poke((1041),(((48))+(b_v_lvi)));
		/* line 1704 */
b_L1704: ;
		b_v_p0i=((b_v_p0i)+((1)));
		if(-((b_v_p0i) > ((9)))){
			b_v_p0i=(0);
			b_v_p1i=((b_v_p1i)+((1)));
			if(-((b_v_p1i) > ((9)))){
				b_v_p1i=(0);
				b_v_lei=((b_v_lei)+((1)));
				b_v_lui=(1);
				b_v_sii=((b_v_sii)+((1)));
				if(-((b_v_sii) > ((6)))){
					b_v_sii=(1);
				}
			}
		}
		/* line 1705 */
b_L1705: ;
		if(-((b_v_lui) == ((1)))){
			b_v_lui=(0);
			b_v_lpi=(1);
			b_v_l1i=b_int(((breal_t)(b_v_lei)/(breal_t)((10))));
			b_v_l0i=((b_v_lei)-(((b_v_l1i)*((10)))));
			b_v_hi=(1);
			b_gosubStack[b_gosubSP++]=25; goto b_L1500;
b_ret25: ;
		}
		/* line 1706 */
b_L1706: ;
		b_poke((1049),(((48))+(b_v_l1i)));
		b_poke((1050),(((48))+(b_v_l0i)));
		/* line 1707 */
b_L1707: ;
		b_poke((1052),(((48))+(b_v_p1i)));
		b_poke((1053),(((48))+(b_v_p0i)));
		b_poke((1054),(37));
		/* line 1708 */
b_L1708: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
			goto b_L1710;
		}
		/* line 1709 */
b_L1709: ;
		b_poke((1060),(32));
		b_poke((1061),(32));
		b_poke((1062),(32));
		b_poke((1063),(32));
		b_poke((55332.0),(0));
		b_poke((55333.0),(0));
		b_poke((55334.0),(0));
		b_poke((55335.0),(0));
		/* line 1710 */
b_L1710: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_pci=((((b_v_p1i)*((10))))+(b_v_p0i));
		/* line 1802 */
b_L1802: ;
		b_v_ami=(((((1))+(b_int(((breal_t)(b_v_pci)/(breal_t)((34)))))))+(b_int(((breal_t)(b_v_lei)/(breal_t)((3))))));
		if(-((b_v_ami) > ((4)))){
			b_v_ami=(4);
		}
		/* line 1803 */
b_L1803: ;
		if(-((b_v_pci) >= ((90)))){
			b_v_ami=((b_v_ami)+((1)));
		}
		/* line 1804 */
b_L1804: ;
		if(-((b_v_ami) > ((5)))){
			b_v_ami=(5);
		}
		/* line 1805 */
b_L1805: ;
		b_v_gcf=((((b_v_gcf)+(b_int(((b_rnd(B_INT((1))))*((((((2))*(b_v_ami)))+((1)))))))))-(b_v_ami));
		/* line 1806 */
b_L1806: ;
		if(-((b_v_gcf) < ((5)))){
			b_v_gcf=(5);
		}
		/* line 1807 */
b_L1807: ;
		if(-((b_v_gcf) > ((19)))){
			b_v_gcf=(19);
		}
		/* line 1808 */
b_L1808: ;
		b_v_hwi=b_int(((breal_t)(b_v_gwi)/(breal_t)((2))));
		if(-((b_v_pci) >= ((90)))){
			if(-((b_rnd(B_INT((1)))) < ((0.20000000001164153)))){
				if(-((b_v_hwi) > ((2)))){
					b_v_hwi=((b_v_hwi)-((1)));
				}
			}
		}
		/* line 1809 */
b_L1809: ;
		b_a_cei[B_INT(b_v_ci)]=((b_v_gcf)-(b_v_hwi));
		b_a_fli[B_INT(b_v_ci)]=((b_v_gcf)+(b_v_hwi));
		/* line 1810 */
b_L1810: ;
		if(-((b_a_cei[B_INT(b_v_ci)]) < ((1)))){
			b_a_cei[B_INT(b_v_ci)]=(1);
		}
		/* line 1811 */
b_L1811: ;
		if(-((b_a_fli[B_INT(b_v_ci)]) > ((23)))){
			b_a_fli[B_INT(b_v_ci)]=(23);
		}
		/* line 1812 */
b_L1812: ;
		b_a_sti[B_INT(b_v_ci)]=(0);
		if(-((b_rnd(B_INT((1)))) < ((0.11999999999534339)))){
			b_a_sti[B_INT(b_v_ci)]=((b_a_cei[B_INT(b_v_ci)])+(b_int(((b_rnd(B_INT((1))))*(((((b_a_fli[B_INT(b_v_ci)])-(b_a_cei[B_INT(b_v_ci)])))+((1))))))));
		}
		/* line 1813 */
b_L1813: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_lvi=((b_v_lvi)-((1)));
		/* line 1902 */
b_L1902: ;
		b_poke((1041),(((48))+(b_v_lvi)));
		/* line 1903 */
b_L1903: ;
		if(-((b_v_lvi) <= ((0)))){
			b_v_goi=(1);
			goto b_return;
		}
		/* line 1904 */
b_L1904: ;
		b_gosubStack[b_gosubSP++]=26; goto b_L2000;
b_ret26: ;
		/* line 1905 */
b_L1905: ;
		b_v_ts=b_keep(b_lit("CRASH! PRESS KEY",16));
		b_v_pxi=(12);
		b_v_pyi=(12);
		b_gosubStack[b_gosubSP++]=27; goto b_L2200;
b_ret27: ;
		/* line 1906 */
b_L1906: ;
		b_poke((54296.0),(15));
		b_poke((54273.0),(20));
		b_poke((54277.0),(9));
		b_poke((54278.0),(0));
		b_poke((54276.0),(65));
		/* line 1907 */
b_L1907: ;
		if(-((b_v_dmi) == ((1)))){ goto b_L1909; }
		/* line 1908 */
b_L1908: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L1908; }
		/* line 1909 */
b_L1909: ;
		b_poke((54276.0),(64));
		/* line 1910 */
b_L1910: ;
		b_v_syi=b_v_gcf;
		if(-((b_v_syi) < ((((1))+(b_v_hi))))){
			b_v_syi=(((1))+(b_v_hi));
		}
		/* line 1911 */
b_L1911: ;
		if(-((b_v_syi) > ((((24))-(b_v_hi))))){
			b_v_syi=(((24))-(b_v_hi));
		}
		/* line 1912 */
b_L1912: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L1000;
b_ret28: ;
		/* line 1913 */
b_L1913: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_cxi=((b_v_sxi)+((1)));
		if(-((b_v_cxi) > ((39)))){
			b_v_cxi=(39);
		}
		/* line 2002 */
b_L2002: ;
		b_v_cyi=b_v_syi;
		if(-((b_v_cyi) < ((1)))){
			b_v_cyi=(1);
			if(-((b_v_cyi) > ((24)))){
				b_v_cyi=(24);
			}
		}
		/* line 2003 */
b_L2003: ;
		b_v_li=(1);
		if(b_v_li > 6) goto b_f14_e;
b_f14_t: ;
		/* line 2004 */
b_L2004: ;
		b_v_chi=(160);
		if(-((b_v_li) >= ((4)))){
			b_v_chi=(81);
		}
		/* line 2005 */
b_L2005: ;
		b_v_z0f=((b_v_cyi)-(b_v_li));
		if(-((b_v_z0f) < ((1)))){
			b_v_z0f=(1);
		}
		/* line 2006 */
b_L2006: ;
		b_v_z1i=((b_v_cyi)+(b_v_li));
		if(-((b_v_z1i) > ((24)))){
			b_v_z1i=(24);
		}
		/* line 2007 */
b_L2007: ;
		b_v_z2i=((b_v_cxi)-(b_v_li));
		if(-((b_v_z2i) < ((0)))){
			b_v_z2i=(0);
		}
		/* line 2008 */
b_L2008: ;
		b_v_z3i=((b_v_cxi)+(b_v_li));
		if(-((b_v_z3i) > ((39)))){
			b_v_z3i=(39);
		}
		/* line 2009 */
b_L2009: ;
		b_v_bci=b_v_z2i;
		b_fl_15=b_v_z3i;
		if(b_v_bci > b_fl_15) goto b_f15_e;
		b_v_M0=(((1024))+(((b_v_cyi)*((40)))));
		b_t_9=((b_v_M0)+(b_v_bci));
b_f15_t: ;
		b_poke(b_t_9,b_v_chi);
		b_t_9 += 1;
		b_v_bci += 1;
		if(b_v_bci <= (b_fl_15)) goto b_f15_t;
b_f15_e: ;
		/* line 2010 */
b_L2010: ;
		b_v_brf=b_v_z0f;
		b_fl_16=b_v_z1i;
		if(b_v_brf > b_fl_16) goto b_f16_e;
b_f16_t: ;
		b_poke((((((1024))+(((b_v_brf)*((40))))))+(b_v_cxi)),b_v_chi);
		b_v_brf += 1;
		if(b_v_brf <= (b_fl_16)) goto b_f16_t;
b_f16_e: ;
		/* line 2011 */
b_L2011: ;
		b_v_ji=(1);
		if(b_v_ji > 100) goto b_f17_e;
b_f17_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 100) goto b_f17_t;
b_f17_e: ;
		/* line 2012 */
b_L2012: ;
		b_v_li += 1;
		if(b_v_li <= 6) goto b_f14_t;
b_f14_e: ;
		/* line 2013 */
b_L2013: ;
		b_poke((((((1024))+(((b_v_cyi)*((40))))))+(b_v_cxi)),(81));
		/* line 2014 */
b_L2014: ;
		b_v_ji=(1);
		if(b_v_ji > 200) goto b_f18_e;
b_f18_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 200) goto b_f18_t;
b_f18_e: ;
		/* line 2015 */
b_L2015: ;
		b_v_ji=(1);
		if(b_v_ji > 15) goto b_f19_e;
b_f19_t: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		b_v_ji += 1;
		if(b_v_ji <= 15) goto b_f19_t;
b_f19_e: ;
		/* line 2016 */
b_L2016: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_v_rdi=b_v_bxi;
		/* line 2102 */
b_L2102: ;
		if(-((b_v_byi) < (b_a_cei[B_INT(b_v_bxi)]))){
			b_a_cei[B_INT(b_v_bxi)]=((b_a_cei[B_INT(b_v_bxi)])+(-((b_a_cei[B_INT(b_v_bxi)]) > ((1)))));
			b_v_bfi=(0);
			goto b_return;
		}
		/* line 2103 */
b_L2103: ;
		b_a_fli[B_INT(b_v_bxi)]=(((b_a_fli[B_INT(b_v_bxi)]))+(((b_a_fli[B_INT(b_v_bxi)]) < ((23)))));
		b_v_bfi=(0);
		goto b_return;
		/* line 2104 */
b_L2104: ;
		b_putc(147);
		b_nl();
		/* line 2105 */
b_L2105: ;
		b_nl();
		b_nl();
		{ bstr_t _t=b_lit("    *** GAME OVER ***",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2106 */
b_L2106: ;
		b_nl();
		{ bstr_t _t=b_lit("    DISTANCE:",13); b_str(_t.p,_t.len); }
		b_putint((bint_t)(b_v_tdf));
		b_nl();
		/* line 2107 */
b_L2107: ;
		b_nl();
		{ bstr_t _t=b_lit("    R=RESTART  Q=QUIT",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2108 */
b_L2108: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_ji=(1);
			if(b_v_ji > 800) goto b_f20_e;
b_f20_t: ;
			b_v_ji += 1;
			if(b_v_ji <= 800) goto b_f20_t;
b_f20_e: ;
			goto b_L50;
		}
		/* line 2109 */
b_L2109: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2109; }
		/* line 2110 */
b_L2110: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 2111 */
b_L2111: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L50;
		}
		/* line 2112 */
b_L2112: ;
		goto b_L2109;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_v_ii=(1);
		b_fl_21=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_21) goto b_f21_e;
		b_v_M1=(((1024))+(b_v_pxi));
		b_v_M2=((b_v_pyi)*((40)));
		b_t_10=((((((b_v_M1)+(b_v_ii)))-((1))))+(b_v_M2));
b_f21_t: ;
		/* line 2202 */
b_L2202: ;
		b_v_chi=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 2203 */
b_L2203: ;
		if((B_INT(-((b_v_chi) >= ((64)))) & B_INT(-((b_v_chi) <= ((95)))))){
			b_v_chi=((b_v_chi)-((64)));
		}
		/* line 2204 */
b_L2204: ;
		b_poke(b_t_10,b_v_chi);
		/* line 2205 */
b_L2205: ;
		b_t_10 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_21)) goto b_f21_t;
b_f21_e: ;
		/* line 2206 */
b_L2206: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5505 */
b_L5505: ;
		b_v_mxi=b_a_cei[B_INT(b_v_sxi)];
		b_v_mni=b_a_fli[B_INT(b_v_sxi)];
		/* line 5506 */
b_L5506: ;
		if(-((((b_v_sxi)+((1)))) <= ((39)))){
			if(-((b_a_cei[B_INT(((b_v_sxi)+((1))))]) > (b_v_mxi))){
				b_v_mxi=b_a_cei[B_INT(((b_v_sxi)+((1))))];
			}
		}
		/* line 5507 */
b_L5507: ;
		if(-((((b_v_sxi)+((1)))) <= ((39)))){
			if(-((b_a_fli[B_INT(((b_v_sxi)+((1))))]) < (b_v_mni))){
				b_v_mni=b_a_fli[B_INT(((b_v_sxi)+((1))))];
			}
		}
		/* line 5508 */
b_L5508: ;
		if(-((((b_v_sxi)+((2)))) <= ((39)))){
			if(-((b_a_cei[B_INT(((b_v_sxi)+((2))))]) > (b_v_mxi))){
				b_v_mxi=b_a_cei[B_INT(((b_v_sxi)+((2))))];
			}
		}
		/* line 5509 */
b_L5509: ;
		if(-((((b_v_sxi)+((2)))) <= ((39)))){
			if(-((b_a_fli[B_INT(((b_v_sxi)+((2))))]) < (b_v_mni))){
				b_v_mni=b_a_fli[B_INT(((b_v_sxi)+((2))))];
			}
		}
		/* line 5510 */
b_L5510: ;
		b_v_cci=((breal_t)(((b_v_mxi)+(b_v_mni)))/(breal_t)((2)));
		/* line 5515 */
b_L5515: ;
		b_v_ki=(64);
		/* line 5520 */
b_L5520: ;
		if(-((b_v_syi) < (b_v_cci))){
			b_v_ki=(13);
		}
		/* line 5525 */
b_L5525: ;
		if(-((b_v_syi) > (b_v_cci))){
			b_v_ki=(9);
		}
		/* line 5530 */
b_L5530: ;
		if(-((b_rnd(B_INT((1)))) < ((0.11999999999534339)))){
			b_v_ki=(60);
		}
		/* line 5535 */
b_L5535: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
