/* OPTIMIZE_C -- minitetris.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_bi[200];
static int b_a_fbi[200];
static bint_t b_a_bgi[7];
static int b_a_nxi[4];
static int b_a_nyi[4];
static int b_a_txi[4];
static int b_a_tyi[4];
static int b_a_pxi[4];
static int b_a_pyi[4];
static int b_a_oxi[4];
static int b_a_oyi[4];
static bint_t b_a_di[5];
static int b_a_gci[16];
static int b_a_pci[7];
static int b_v_ii;
static int b_v_foi;
static int b_v_fci;
static int b_v_fti;
static bint_t b_v_sci;
static bint_t b_v_lni;
static int b_v_lvi;
static int b_v_dli;
static bint_t b_v_bii;
static bint_t b_v_npi;
static int b_v_gvi;
static int b_v_rfi;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_bxi;
static bint_t b_v_cli;
static bint_t b_v_lki;
static bint_t b_v_gdi;
static bint_t b_v_byi;
static bint_t b_v_pni;
static bint_t b_v_dri;
static bint_t b_v_ppi;
static int b_v_cpi;
static bint_t b_v_ri;
static bint_t b_v_ci;
static int b_v_cyi;
static int b_v_cxi;
static bint_t b_v_mi;
static int b_v_hpi;
static int b_v_dci;
static bint_t b_v_vi;
static bint_t b_v_bti;
static int b_v_cci;
static int b_v_fi;
static bint_t b_v_rri;
static bstr_t b_v_ts;
static int b_v_hxi;
static int b_v_hyi;
static bint_t b_v_ti;
static int b_v_ji;
static bint_t b_v_li;
static bint_t b_v_hhi;
static bstr_t b_v_ks;
static int b_v_cti;
static int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static int b_v_M3;
static bint_t b_v_M4;
static bint_t b_v_M5;
static bint_t b_v_M6;
static int b_v_M7;
static int b_v_M8;
static int b_v_M9;
static int b_v_M10;
static int b_v_M11;
static int b_v_M12;
static int b_v_M13;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
static bint_t b_t_31;
static bint_t b_t_32;
static bint_t b_t_33;
static bint_t b_t_34;
static bint_t b_t_35;
static bint_t b_t_36;
static bint_t b_t_37;
static bint_t b_t_38;
static bint_t b_t_39;
static bint_t b_t_40;
static bint_t b_t_41;
static int b_fl_31;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		b_poke((53280.0),(0));
		/* line 30 */
b_L30: ;
		b_poke((53281.0),(0));
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		/* line 80 */
b_L80: ;
		/* line 90 */
b_L90: ;
		/* line 100 */
b_L100: ;
		/* line 110 */
b_L110: ;
		/* line 120 */
b_L120: ;
		/* line 130 */
b_L130: ;
		/* line 140 */
b_L140: ;
		/* line 150 */
b_L150: ;
		/* line 160 */
b_L160: ;
		/* line 170 */
b_L170: ;
		/* line 180 */
b_L180: ;
		b_v_ii=(0);
		if(b_v_ii > 199) goto b_f0_e;
b_f0_t: ;
		/* line 190 */
b_L190: ;
		b_a_bi[B_INT(b_v_ii)]=(0);
		/* line 200 */
b_L200: ;
		b_v_ii += 1;
		if(b_v_ii <= 199) goto b_f0_t;
b_f0_e: ;
		/* line 210 */
b_L210: ;
		b_v_ii=(0);
		if(b_v_ii > 6) goto b_f1_e;
b_f1_t: ;
		/* line 220 */
b_L220: ;
		b_a_bgi[B_INT(b_v_ii)]=b_v_ii;
		/* line 230 */
b_L230: ;
		b_v_ii += 1;
		if(b_v_ii <= 6) goto b_f1_t;
b_f1_e: ;
		/* line 240 */
b_L240: ;
		b_a_gci[B_INT((0))]=(32);
		/* line 250 */
b_L250: ;
		b_a_gci[B_INT((1))]=(126);
		/* line 260 */
b_L260: ;
		b_a_gci[B_INT((2))]=(124);
		/* line 270 */
b_L270: ;
		b_a_gci[B_INT((3))]=(226);
		/* line 280 */
b_L280: ;
		b_a_gci[B_INT((4))]=(123);
		/* line 290 */
b_L290: ;
		b_a_gci[B_INT((5))]=(97);
		/* line 300 */
b_L300: ;
		b_a_gci[B_INT((6))]=(255);
		/* line 310 */
b_L310: ;
		b_a_gci[B_INT((7))]=(236);
		/* line 320 */
b_L320: ;
		b_a_gci[B_INT((8))]=(108);
		/* line 330 */
b_L330: ;
		b_a_gci[B_INT((9))]=(127);
		/* line 340 */
b_L340: ;
		b_a_gci[B_INT((10))]=(225);
		/* line 350 */
b_L350: ;
		b_a_gci[B_INT((11))]=(251);
		/* line 360 */
b_L360: ;
		b_a_gci[B_INT((12))]=(98);
		/* line 370 */
b_L370: ;
		b_a_gci[B_INT((13))]=(252);
		/* line 380 */
b_L380: ;
		b_a_gci[B_INT((14))]=(254);
		/* line 390 */
b_L390: ;
		b_a_gci[B_INT((15))]=(160);
		/* line 400 */
b_L400: ;
		b_a_pci[B_INT((0))]=(3);
		/* line 410 */
b_L410: ;
		b_a_pci[B_INT((1))]=(7);
		/* line 420 */
b_L420: ;
		b_a_pci[B_INT((2))]=(4);
		/* line 430 */
b_L430: ;
		b_a_pci[B_INT((3))]=(5);
		/* line 440 */
b_L440: ;
		b_a_pci[B_INT((4))]=(2);
		/* line 450 */
b_L450: ;
		b_a_pci[B_INT((5))]=(6);
		/* line 460 */
b_L460: ;
		b_a_pci[B_INT((6))]=(8);
		/* line 470 */
b_L470: ;
		b_v_foi=(1321);
		/* line 480 */
b_L480: ;
		b_v_fci=(297);
		/* line 490 */
b_L490: ;
		b_v_fti=(1);
		/* line 500 */
b_L500: ;
		b_v_sci=(0);
		/* line 510 */
b_L510: ;
		b_v_lni=(0);
		/* line 520 */
b_L520: ;
		b_v_lvi=(1);
		/* line 530 */
b_L530: ;
		b_v_dli=(24);
		/* line 540 */
b_L540: ;
		b_v_bii=(7);
		/* line 550 */
b_L550: ;
		b_v_npi=(0);
		/* line 560 */
b_L560: ;
		b_v_gvi=(0);
		/* line 570 */
b_L570: ;
		b_v_rfi=(1);
		/* line 580 */
b_L580: ;
		b_v_ii=(0);
		if(b_v_ii > 199) goto b_f2_e;
b_f2_t: ;
		/* line 590 */
b_L590: ;
		b_a_bi[B_INT(b_v_ii)]=(0);
		/* line 600 */
b_L600: ;
		b_v_ii += 1;
		if(b_v_ii <= 199) goto b_f2_t;
b_f2_e: ;
		/* line 610 */
b_L610: ;
		if(-((b_v_fti) == ((1)))){
			b_v_fti=(0);
			b_gosubStack[b_gosubSP++]=0; goto b_L2600;
b_ret0: ;
		}
		/* line 620 */
b_L620: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L2400;
b_ret1: ;
		/* line 630 */
b_L630: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L2100;
b_ret2: ;
		/* line 640 */
b_L640: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1000;
b_ret3: ;
		/* line 650 */
b_L650: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L2200;
b_ret4: ;
		/* line 660 */
b_L660: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1700;
b_ret5: ;
		/* line 670 */
b_L670: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L1500;
b_ret6: ;
		/* line 680 */
b_L680: ;
		b_v_rfi=(0);
		/* line 690 */
b_L690: ;
		if(-((b_v_gvi) == ((1)))){ goto b_L2700; }
		/* line 700 */
b_L700: ;
		if(-((b_v_rfi) == ((1)))){
			b_gosubStack[b_gosubSP++]=7; goto b_L1700;
b_ret7: ;
			b_gosubStack[b_gosubSP++]=8; goto b_L1500;
b_ret8: ;
			b_gosubStack[b_gosubSP++]=9; goto b_L2200;
b_ret9: ;
			b_v_rfi=(0);
		}
		/* line 710 */
b_L710: ;
		b_wait((53265.0),(128),0);
		/* line 720 */
b_L720: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		/* line 730 */
b_L730: ;
		b_poke((198),(0));
		/* line 740 */
b_L740: ;
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 750 */
b_L750: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 760 */
b_L760: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 770 */
b_L770: ;
		if(-((b_v_ki) == ((10)))){
			b_v_bxi=((b_v_bxi)-((1)));
			b_gosubStack[b_gosubSP++]=10; goto b_L1200;
b_ret10: ;
			if(-((b_v_cli) == ((1)))){
				b_v_bxi=((b_v_bxi)+((1)));
			}
		}
		/* line 780 */
b_L780: ;
		if(-((b_v_ki) == ((10)))){
			b_v_rfi=(1);
		}
		/* line 790 */
b_L790: ;
		if(-((b_v_ki) == ((18)))){
			b_v_bxi=((b_v_bxi)+((1)));
			b_gosubStack[b_gosubSP++]=11; goto b_L1200;
b_ret11: ;
			if(-((b_v_cli) == ((1)))){
				b_v_bxi=((b_v_bxi)-((1)));
			}
		}
		/* line 800 */
b_L800: ;
		if(-((b_v_ki) == ((18)))){
			b_v_rfi=(1);
		}
		/* line 810 */
b_L810: ;
		if(-((b_v_ki) == ((9)))){
			if(-((b_v_lki) != ((9)))){
				b_gosubStack[b_gosubSP++]=12; goto b_L1300;
b_ret12: ;
				b_v_rfi=(1);
			}
		}
		/* line 820 */
b_L820: ;
		if(-((b_v_ki) == ((62)))){ goto b_L2700; }
		/* line 830 */
b_L830: ;
		if(-((b_v_ki) == ((13)))){
			if(-((b_v_lki) != ((13)))){
				b_v_lki=b_v_ki;
				b_gosubStack[b_gosubSP++]=13; goto b_L2000;
b_ret13: ;
				goto b_L690;
			}
		}
		/* line 840 */
b_L840: ;
		b_v_lki=b_v_ki;
		/* line 850 */
b_L850: ;
		b_v_gdi=((b_v_gdi)-((1)));
		/* line 860 */
b_L860: ;
		if(-((b_v_gdi) > ((0)))){ goto b_L690; }
		/* line 870 */
b_L870: ;
		b_v_gdi=b_v_dli;
		/* line 880 */
b_L880: ;
		b_v_byi=((b_v_byi)+((1)));
		/* line 890 */
b_L890: ;
		b_gosubStack[b_gosubSP++]=14; goto b_L1200;
b_ret14: ;
		/* line 900 */
b_L900: ;
		if(-((b_v_cli) == ((1)))){
			b_v_byi=((b_v_byi)-((1)));
			b_gosubStack[b_gosubSP++]=15; goto b_L1400;
b_ret15: ;
			goto b_L690;
		}
		/* line 910 */
b_L910: ;
		b_v_rfi=(1);
		/* line 920 */
b_L920: ;
		goto b_L690;
		/* line 1000 */
b_L1000: ;
		b_v_pni=b_v_npi;
		/* line 1005 */
b_L1005: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L2900;
b_ret16: ;
		/* line 1010 */
b_L1010: ;
		b_v_npi=b_v_dri;
		/* line 1015 */
b_L1015: ;
		b_v_ppi=b_v_pni;
		/* line 1020 */
b_L1020: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L2800;
b_ret17: ;
		/* line 1025 */
b_L1025: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f3_e;
b_f3_t: ;
		/* line 1030 */
b_L1030: ;
		b_a_pxi[B_INT(b_v_ii)]=b_a_txi[B_INT(b_v_ii)];
		/* line 1035 */
b_L1035: ;
		b_a_pyi[B_INT(b_v_ii)]=b_a_tyi[B_INT(b_v_ii)];
		/* line 1040 */
b_L1040: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f3_t;
b_f3_e: ;
		/* line 1045 */
b_L1045: ;
		b_v_ppi=b_v_npi;
		/* line 1050 */
b_L1050: ;
		b_gosubStack[b_gosubSP++]=18; goto b_L2800;
b_ret18: ;
		/* line 1055 */
b_L1055: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f4_e;
b_f4_t: ;
		/* line 1060 */
b_L1060: ;
		b_a_nxi[B_INT(b_v_ii)]=b_a_txi[B_INT(b_v_ii)];
		/* line 1065 */
b_L1065: ;
		b_a_nyi[B_INT(b_v_ii)]=b_a_tyi[B_INT(b_v_ii)];
		/* line 1070 */
b_L1070: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f4_t;
b_f4_e: ;
		/* line 1075 */
b_L1075: ;
		b_v_cpi=b_a_pci[B_INT(b_v_pni)];
		/* line 1080 */
b_L1080: ;
		b_v_bxi=(3);
		/* line 1085 */
b_L1085: ;
		b_v_byi=(0);
		/* line 1090 */
b_L1090: ;
		b_v_gdi=b_v_dli;
		/* line 1095 */
b_L1095: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L1200;
b_ret19: ;
		/* line 1100 */
b_L1100: ;
		if(-((b_v_cli) == ((1)))){
			b_v_gvi=(1);
		}
		/* line 1105 */
b_L1105: ;
		b_v_rfi=(1);
		/* line 1110 */
b_L1110: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		b_v_cli=(0);
		/* line 1205 */
b_L1205: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f5_e;
b_f5_t: ;
		/* line 1210 */
b_L1210: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		/* line 1215 */
b_L1215: ;
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 1220 */
b_L1220: ;
		if((B_INT(-((b_v_ci) < ((0)))) | B_INT(-((b_v_ci) > ((9)))))){
			b_v_cli=(1);
		}
		/* line 1225 */
b_L1225: ;
		if(-((b_v_ri) > ((19)))){
			b_v_cli=(1);
		}
		/* line 1230 */
b_L1230: ;
		if(-((b_v_cli) == ((0)))){
			if(-((b_v_ri) >= ((0)))){
				if(-((b_a_bi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]) == ((1)))){
					b_v_cli=(1);
				}
			}
		}
		/* line 1235 */
b_L1235: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f5_t;
b_f5_e: ;
		/* line 1240 */
b_L1240: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f6_e;
b_f6_t: ;
		/* line 1305 */
b_L1305: ;
		b_a_oxi[B_INT(b_v_ii)]=b_a_pxi[B_INT(b_v_ii)];
		/* line 1310 */
b_L1310: ;
		b_a_oyi[B_INT(b_v_ii)]=b_a_pyi[B_INT(b_v_ii)];
		/* line 1315 */
b_L1315: ;
		b_a_pxi[B_INT(b_v_ii)]=(((3))-(b_a_pyi[B_INT(b_v_ii)]));
		/* line 1320 */
b_L1320: ;
		b_a_pyi[B_INT(b_v_ii)]=b_a_oxi[B_INT(b_v_ii)];
		/* line 1325 */
b_L1325: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f6_t;
b_f6_e: ;
		/* line 1330 */
b_L1330: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L1200;
b_ret20: ;
		/* line 1335 */
b_L1335: ;
		if(-((b_v_cli) == ((1)))){
			b_v_ii=(0);
			if(b_v_ii > 3) goto b_f7_e;
b_f7_t: ;
			b_a_pxi[B_INT(b_v_ii)]=b_a_oxi[B_INT(b_v_ii)];
			b_a_pyi[B_INT(b_v_ii)]=b_a_oyi[B_INT(b_v_ii)];
			b_v_ii += 1;
			if(b_v_ii <= 3) goto b_f7_t;
b_f7_e: ;
		}
		/* line 1340 */
b_L1340: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f8_e;
b_f8_t: ;
		/* line 1405 */
b_L1405: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		/* line 1410 */
b_L1410: ;
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 1415 */
b_L1415: ;
		if((B_INT((B_INT((B_INT(-((b_v_ri) >= ((0)))) & B_INT(-((b_v_ri) < ((20)))))) & B_INT(-((b_v_ci) >= ((0)))))) & B_INT(-((b_v_ci) < ((10)))))){
			b_a_bi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]=(1);
		}
		/* line 1420 */
b_L1420: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f8_t;
b_f8_e: ;
		/* line 1425 */
b_L1425: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L1800;
b_ret21: ;
		/* line 1430 */
b_L1430: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L1000;
b_ret22: ;
		/* line 1435 */
b_L1435: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		b_v_cyi=(0);
		if(b_v_cyi > 9) goto b_f9_e;
b_f9_t: ;
		/* line 1505 */
b_L1505: ;
		b_v_cxi=(0);
		if(b_v_cxi > 4) goto b_f10_e;
		b_v_M2=((b_v_foi)+(((b_v_cyi)*((40)))));
		b_v_M3=((b_v_cyi)*((40)));
		b_t_23=((b_v_M2)+(b_v_cxi));
		b_t_24=(((((((55296.0))+(b_v_fci)))+(b_v_M3)))+(b_v_cxi));
b_f10_t: ;
		/* line 1510 */
b_L1510: ;
		b_v_mi=(0);
		/* line 1515 */
b_L1515: ;
		b_v_hpi=(0);
		/* line 1520 */
b_L1520: ;
		b_v_dri=(0);
		if(b_v_dri > 1) goto b_f11_e;
b_f11_t: ;
		/* line 1525 */
b_L1525: ;
		b_v_dci=(0);
		if(b_v_dci > 1) goto b_f12_e;
		b_v_M0=((((b_v_cyi)*((2))))+(b_v_dri));
		b_v_M1=((b_v_cxi)*((2)));
b_f12_t: ;
		/* line 1530 */
b_L1530: ;
		b_v_ri=b_v_M0;
		/* line 1535 */
b_L1535: ;
		b_v_ci=((b_v_M1)+(b_v_dci));
		/* line 1540 */
b_L1540: ;
		b_v_vi=b_a_fbi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))];
		/* line 1545 */
b_L1545: ;
		if(-((b_v_vi) == ((0)))){ goto b_L1575; }
		/* line 1550 */
b_L1550: ;
		b_v_bti=(1);
		/* line 1555 */
b_L1555: ;
		if(-((b_v_dci) == ((1)))){
			b_v_bti=(2);
		}
		/* line 1560 */
b_L1560: ;
		if(-((b_v_dri) == ((1)))){
			b_v_bti=((b_v_bti)*((4)));
		}
		/* line 1565 */
b_L1565: ;
		b_v_mi=(B_INT(b_v_mi) | B_INT(b_v_bti));
		/* line 1570 */
b_L1570: ;
		if(-((b_v_vi) == ((2)))){
			b_v_hpi=(1);
		}
		/* line 1575 */
b_L1575: ;
		b_v_dci += 1;
		if(b_v_dci <= 1) goto b_f12_t;
b_f12_e: ;
		/* line 1580 */
b_L1580: ;
		b_v_dri += 1;
		if(b_v_dri <= 1) goto b_f11_t;
b_f11_e: ;
		/* line 1585 */
b_L1585: ;
		b_poke(b_t_23,b_a_gci[B_INT(b_v_mi)]);
		/* line 1590 */
b_L1590: ;
		b_v_cci=(0);
		/* line 1595 */
b_L1595: ;
		if(-((b_v_mi) > ((0)))){
			b_v_cci=(1);
		}
		/* line 1600 */
b_L1600: ;
		if(-((b_v_hpi) == ((1)))){
			b_v_cci=b_v_cpi;
		}
		/* line 1605 */
b_L1605: ;
		b_poke(b_t_24,b_v_cci);
		/* line 1610 */
b_L1610: ;
		b_t_23 += 1;
		b_t_24 += 1;
		b_v_cxi += 1;
		if(b_v_cxi <= 4) goto b_f10_t;
b_f10_e: ;
		/* line 1615 */
b_L1615: ;
		b_v_cyi += 1;
		if(b_v_cyi <= 9) goto b_f9_t;
b_f9_e: ;
		/* line 1620 */
b_L1620: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		b_v_ii=(0);
		if(b_v_ii > 199) goto b_f13_e;
b_f13_t: ;
		/* line 1705 */
b_L1705: ;
		/* line 1710 */
b_L1710: ;
		b_v_ii += 1;
		if(b_v_ii <= 199) goto b_f13_t;
b_f13_e: ;
		/* line 1715 */
b_L1715: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f14_e;
b_f14_t: ;
		/* line 1720 */
b_L1720: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		/* line 1725 */
b_L1725: ;
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 1730 */
b_L1730: ;
		if((B_INT((B_INT((B_INT(-((b_v_ri) >= ((0)))) & B_INT(-((b_v_ri) < ((20)))))) & B_INT(-((b_v_ci) >= ((0)))))) & B_INT(-((b_v_ci) < ((10)))))){
			b_a_fbi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]=(2);
		}
		/* line 1735 */
b_L1735: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f14_t;
b_f14_e: ;
		/* line 1740 */
b_L1740: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		b_v_ri=(19);
		if(b_v_ri < 0) goto b_f15_e;
b_f15_t: ;
		/* line 1805 */
b_L1805: ;
		b_v_fi=(1);
		/* line 1810 */
b_L1810: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f16_e;
		b_v_M4=((b_v_ri)*((10)));
b_f16_t: ;
		/* line 1815 */
b_L1815: ;
		if(-((b_a_bi[B_INT(((b_v_M4)+(b_v_ci)))]) == ((0)))){
			b_v_fi=(0);
		}
		/* line 1820 */
b_L1820: ;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f16_t;
b_f16_e: ;
		/* line 1825 */
b_L1825: ;
		if(-((b_v_fi) == ((0)))){ goto b_L1910; }
		/* line 1830 */
b_L1830: ;
		b_v_rri=b_v_ri;
		if(b_v_rri < 1) goto b_f17_e;
b_f17_t: ;
		/* line 1835 */
b_L1835: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f18_e;
		b_v_M5=((((b_v_rri)-((1))))*((10)));
		b_v_M6=((b_v_rri)*((10)));
b_f18_t: ;
		/* line 1840 */
b_L1840: ;
		b_a_bi[B_INT(((b_v_M6)+(b_v_ci)))]=b_a_bi[B_INT(((b_v_M5)+(b_v_ci)))];
		/* line 1845 */
b_L1845: ;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f18_t;
b_f18_e: ;
		/* line 1850 */
b_L1850: ;
		b_v_rri += -1;
		if(b_v_rri >= 1) goto b_f17_t;
b_f17_e: ;
		/* line 1855 */
b_L1855: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f19_e;
b_f19_t: ;
		/* line 1860 */
b_L1860: ;
		b_a_bi[B_INT(b_v_ci)]=(0);
		/* line 1865 */
b_L1865: ;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f19_t;
b_f19_e: ;
		/* line 1870 */
b_L1870: ;
		b_v_lni=((b_v_lni)+((1)));
		/* line 1875 */
b_L1875: ;
		b_v_sci=((b_v_sci)+((100)));
		/* line 1880 */
b_L1880: ;
		b_v_lvi=(((1))+(b_int(((breal_t)(b_v_sci)/(breal_t)((500))))));
		/* line 1885 */
b_L1885: ;
		if(-((b_v_lvi) > ((20)))){
			b_v_lvi=(20);
		}
		/* line 1890 */
b_L1890: ;
		b_v_dli=(((25))-(b_v_lvi));
		/* line 1895 */
b_L1895: ;
		if(-((b_v_dli) < ((3)))){
			b_v_dli=(3);
		}
		/* line 1900 */
b_L1900: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L2500;
b_ret23: ;
		/* line 1905 */
b_L1905: ;
		b_v_ri=((b_v_ri)+((1)));
		/* line 1910 */
b_L1910: ;
		b_v_ri += -1;
		if(b_v_ri >= 0) goto b_f15_t;
b_f15_e: ;
		/* line 1915 */
b_L1915: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		b_v_byi=((b_v_byi)+((1)));
		/* line 2005 */
b_L2005: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L1200;
b_ret24: ;
		/* line 2010 */
b_L2010: ;
		if(-((b_v_cli) == ((0)))){ goto b_L2000; }
		/* line 2015 */
b_L2015: ;
		b_v_byi=((b_v_byi)-((1)));
		/* line 2020 */
b_L2020: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L1400;
b_ret25: ;
		/* line 2025 */
b_L2025: ;
		b_v_rfi=(1);
		/* line 2030 */
b_L2030: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		b_v_ri=(7);
		if(b_v_ri > 17) goto b_f20_e;
		b_t_28=(((((1024))+(((b_v_ri)*((40))))))+((16)));
		b_t_29=(((((55296.0))+(((b_v_ri)*((40))))))+((16)));
		b_t_30=(((((1024))+(((b_v_ri)*((40))))))+((22)));
		b_t_31=(((((55296.0))+(((b_v_ri)*((40))))))+((22)));
b_f20_t: ;
		/* line 2105 */
b_L2105: ;
		b_poke(b_t_28,(102));
		/* line 2110 */
b_L2110: ;
		b_poke(b_t_29,(1));
		/* line 2115 */
b_L2115: ;
		b_poke(b_t_30,(102));
		/* line 2120 */
b_L2120: ;
		b_poke(b_t_31,(1));
		/* line 2125 */
b_L2125: ;
		b_t_28 += 40;
		b_t_29 += 40;
		b_t_30 += 40;
		b_t_31 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 17) goto b_f20_t;
b_f20_e: ;
		/* line 2130 */
b_L2130: ;
		b_v_ci=(16);
		if(b_v_ci > 22) goto b_f21_e;
		b_t_32=(((1704))+(b_v_ci));
		b_t_33=(((((55296.0))+((680))))+(b_v_ci));
b_f21_t: ;
		/* line 2135 */
b_L2135: ;
		b_poke(b_t_32,(102));
		/* line 2140 */
b_L2140: ;
		b_poke(b_t_33,(1));
		/* line 2145 */
b_L2145: ;
		b_t_32 += 1;
		b_t_33 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 22) goto b_f21_t;
b_f21_e: ;
		/* line 2150 */
b_L2150: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		b_v_cyi=(0);
		if(b_v_cyi > 1) goto b_f22_e;
b_f22_t: ;
		/* line 2205 */
b_L2205: ;
		b_v_cxi=(0);
		if(b_v_cxi > 1) goto b_f23_e;
		b_v_M9=(((((1024))+((((((7))+(b_v_cyi)))*((40))))))+((24)));
		b_v_M10=(((((7))+(b_v_cyi)))*((40)));
		b_v_M11=b_a_pci[B_INT(b_v_npi)];
		b_t_36=((b_v_M9)+(b_v_cxi));
		b_t_37=(((((((55296.0))+(b_v_M10)))+((24))))+(b_v_cxi));
b_f23_t: ;
		/* line 2210 */
b_L2210: ;
		b_v_mi=(0);
		/* line 2215 */
b_L2215: ;
		b_v_dri=(0);
		if(b_v_dri > 1) goto b_f24_e;
b_f24_t: ;
		/* line 2220 */
b_L2220: ;
		b_v_dci=(0);
		if(b_v_dci > 1) goto b_f25_e;
		b_v_M7=((((b_v_cyi)*((2))))+(b_v_dri));
		b_v_M8=((b_v_cxi)*((2)));
b_f25_t: ;
		/* line 2225 */
b_L2225: ;
		b_v_ri=b_v_M7;
		/* line 2230 */
b_L2230: ;
		b_v_ci=((b_v_M8)+(b_v_dci));
		/* line 2235 */
b_L2235: ;
		b_v_bti=(1);
		/* line 2240 */
b_L2240: ;
		if(-((b_v_dci) == ((1)))){
			b_v_bti=(2);
		}
		/* line 2245 */
b_L2245: ;
		if(-((b_v_dri) == ((1)))){
			b_v_bti=((b_v_bti)*((4)));
		}
		/* line 2250 */
b_L2250: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f26_e;
b_f26_t: ;
		/* line 2255 */
b_L2255: ;
		if(-((b_a_nxi[B_INT(b_v_ii)]) == (b_v_ci))){
			if(-((b_a_nyi[B_INT(b_v_ii)]) == (b_v_ri))){
				b_v_mi=(B_INT(b_v_mi) | B_INT(b_v_bti));
			}
		}
		/* line 2260 */
b_L2260: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f26_t;
b_f26_e: ;
		/* line 2265 */
b_L2265: ;
		b_v_dci += 1;
		if(b_v_dci <= 1) goto b_f25_t;
b_f25_e: ;
		/* line 2270 */
b_L2270: ;
		b_v_dri += 1;
		if(b_v_dri <= 1) goto b_f24_t;
b_f24_e: ;
		/* line 2275 */
b_L2275: ;
		b_poke(b_t_36,b_a_gci[B_INT(b_v_mi)]);
		/* line 2280 */
b_L2280: ;
		b_poke(b_t_37,b_v_M11);
		/* line 2285 */
b_L2285: ;
		b_t_36 += 1;
		b_t_37 += 1;
		b_v_cxi += 1;
		if(b_v_cxi <= 1) goto b_f23_t;
b_f23_e: ;
		/* line 2290 */
b_L2290: ;
		b_v_cyi += 1;
		if(b_v_cyi <= 1) goto b_f22_t;
b_f22_e: ;
		/* line 2295 */
b_L2295: ;
		b_v_ts=b_keep(b_lit("NEXT",4));
		/* line 2300 */
b_L2300: ;
		b_v_hxi=(24);
		/* line 2305 */
b_L2305: ;
		b_v_hyi=(5);
		/* line 2310 */
b_L2310: ;
		b_gosubStack[b_gosubSP++]=26; goto b_L3000;
b_ret26: ;
		/* line 2315 */
b_L2315: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		b_v_hxi=(0);
		/* line 2405 */
b_L2405: ;
		b_v_hyi=(0);
		/* line 2410 */
b_L2410: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		/* line 2415 */
b_L2415: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L3000;
b_ret27: ;
		/* line 2420 */
b_L2420: ;
		b_v_hxi=(12);
		/* line 2425 */
b_L2425: ;
		b_v_hyi=(0);
		/* line 2430 */
b_L2430: ;
		b_v_ts=b_keep(b_lit("LINES",5));
		/* line 2435 */
b_L2435: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L3000;
b_ret28: ;
		/* line 2440 */
b_L2440: ;
		b_v_hxi=(22);
		/* line 2445 */
b_L2445: ;
		b_v_hyi=(0);
		/* line 2450 */
b_L2450: ;
		b_v_ts=b_keep(b_lit("LEVEL",5));
		/* line 2455 */
b_L2455: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L3000;
b_ret29: ;
		/* line 2460 */
b_L2460: ;
		b_gosubStack[b_gosubSP++]=30; goto b_L2500;
b_ret30: ;
		/* line 2465 */
b_L2465: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		b_v_ti=b_v_sci;
		/* line 2505 */
b_L2505: ;
		b_v_ji=(0);
		if(b_v_ji > 4) goto b_f27_e;
b_f27_t: ;
		/* line 2510 */
b_L2510: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		/* line 2515 */
b_L2515: ;
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		/* line 2520 */
b_L2520: ;
		b_v_ji += 1;
		if(b_v_ji <= 4) goto b_f27_t;
b_f27_e: ;
		/* line 2525 */
b_L2525: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((4))])));
		/* line 2530 */
b_L2530: ;
		b_poke((1031),(((48))+(b_a_di[B_INT((3))])));
		/* line 2535 */
b_L2535: ;
		b_poke((1032),(((48))+(b_a_di[B_INT((2))])));
		/* line 2540 */
b_L2540: ;
		b_poke((1033),(((48))+(b_a_di[B_INT((1))])));
		/* line 2545 */
b_L2545: ;
		b_poke((1034),(((48))+(b_a_di[B_INT((0))])));
		/* line 2550 */
b_L2550: ;
		b_v_li=b_v_lni;
		/* line 2555 */
b_L2555: ;
		b_poke((1044),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		/* line 2560 */
b_L2560: ;
		b_v_li=b_int(((breal_t)(b_v_li)/(breal_t)((10))));
		/* line 2565 */
b_L2565: ;
		b_poke((1043),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		/* line 2570 */
b_L2570: ;
		b_v_li=b_int(((breal_t)(b_v_li)/(breal_t)((10))));
		/* line 2575 */
b_L2575: ;
		b_poke((1042),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		/* line 2580 */
b_L2580: ;
		b_poke((1052),(((48))+(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))));
		/* line 2585 */
b_L2585: ;
		b_poke((1053),(((((48))+(b_v_lvi)))-((((10))*(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))))));
		/* line 2590 */
b_L2590: ;
		goto b_return;
		/* line 2600 */
b_L2600: ;
		b_putc(147);
		b_nl();
		/* line 2605 */
b_L2605: ;
		b_v_ts=b_keep(b_lit("MINI TETRIS",11));
		/* line 2610 */
b_L2610: ;
		b_v_hxi=(15);
		/* line 2615 */
b_L2615: ;
		b_v_hyi=(0);
		/* line 2620 */
b_L2620: ;
		b_gosubStack[b_gosubSP++]=31; goto b_L3000;
b_ret31: ;
		/* line 2625 */
b_L2625: ;
		b_v_hhi=(15);
		if(b_v_hhi > 25) goto b_f28_e;
b_f28_t: ;
		/* line 2630 */
b_L2630: ;
		b_poke((((55296.0))+(b_v_hhi)),(7));
		/* line 2635 */
b_L2635: ;
		b_v_hhi += 1;
		if(b_v_hhi <= 25) goto b_f28_t;
b_f28_e: ;
		/* line 2640 */
b_L2640: ;
		b_v_ts=b_keep(b_lit("A/D MOVE  W ROTATE  S DROP",26));
		/* line 2645 */
b_L2645: ;
		b_v_hxi=(8);
		/* line 2650 */
b_L2650: ;
		b_v_hyi=(3);
		/* line 2655 */
b_L2655: ;
		b_gosubStack[b_gosubSP++]=32; goto b_L3000;
b_ret32: ;
		/* line 2660 */
b_L2660: ;
		b_v_ts=b_keep(b_lit("Q QUIT  R RESTART",17));
		/* line 2665 */
b_L2665: ;
		b_v_hxi=(12);
		/* line 2670 */
b_L2670: ;
		b_v_hyi=(5);
		/* line 2675 */
b_L2675: ;
		b_gosubStack[b_gosubSP++]=33; goto b_L3000;
b_ret33: ;
		/* line 2680 */
b_L2680: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		/* line 2685 */
b_L2685: ;
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2680; }
		/* line 2690 */
b_L2690: ;
		b_putc(147);
		b_nl();
		/* line 2695 */
b_L2695: ;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		b_putc(147);
		b_nl();
		/* line 2705 */
b_L2705: ;
		b_nl();
		/* line 2710 */
b_L2710: ;
		{ bstr_t _t=b_lit("   *** GAME OVER ***",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2715 */
b_L2715: ;
		{ bstr_t _t=b_lit("   SCORE:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 2720 */
b_L2720: ;
		{ bstr_t _t=b_lit("   LINES:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_lni);
		b_nl();
		/* line 2725 */
b_L2725: ;
		{ bstr_t _t=b_lit("   LEVEL:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_lvi);
		b_nl();
		/* line 2730 */
b_L2730: ;
		b_nl();
		/* line 2735 */
b_L2735: ;
		{ bstr_t _t=b_lit("   R=RESTART  Q=QUIT",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2740 */
b_L2740: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		/* line 2745 */
b_L2745: ;
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2740; }
		/* line 2750 */
b_L2750: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L500;
		}
		/* line 2755 */
b_L2755: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 2760 */
b_L2760: ;
		goto b_L2740;
		/* line 2800 */
b_L2800: ;
		if(-((b_v_ppi) == ((0)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(1);
			b_a_txi[B_INT((1))]=(1);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(2);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(3);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2805 */
b_L2805: ;
		if(-((b_v_ppi) == ((1)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(2);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2810 */
b_L2810: ;
		if(-((b_v_ppi) == ((2)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(0);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2815 */
b_L2815: ;
		if(-((b_v_ppi) == ((3)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(2);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(0);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(1);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2820 */
b_L2820: ;
		if(-((b_v_ppi) == ((4)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(1);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2825 */
b_L2825: ;
		if(-((b_v_ppi) == ((5)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(0);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 2830 */
b_L2830: ;
		b_a_txi[B_INT((0))]=(2);
		/* line 2835 */
b_L2835: ;
		b_a_tyi[B_INT((0))]=(0);
		/* line 2840 */
b_L2840: ;
		b_a_txi[B_INT((1))]=(0);
		/* line 2845 */
b_L2845: ;
		b_a_tyi[B_INT((1))]=(1);
		/* line 2850 */
b_L2850: ;
		b_a_txi[B_INT((2))]=(1);
		/* line 2855 */
b_L2855: ;
		b_a_tyi[B_INT((2))]=(1);
		/* line 2860 */
b_L2860: ;
		b_a_txi[B_INT((3))]=(2);
		/* line 2865 */
b_L2865: ;
		b_a_tyi[B_INT((3))]=(1);
		/* line 2870 */
b_L2870: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		if(-((b_v_bii) < ((7)))){ goto b_L2955; }
		/* line 2905 */
b_L2905: ;
		b_v_ii=(0);
		if(b_v_ii > 6) goto b_f29_e;
b_f29_t: ;
		/* line 2910 */
b_L2910: ;
		b_a_bgi[B_INT(b_v_ii)]=b_v_ii;
		/* line 2915 */
b_L2915: ;
		b_v_ii += 1;
		if(b_v_ii <= 6) goto b_f29_t;
b_f29_e: ;
		/* line 2920 */
b_L2920: ;
		b_v_ii=(0);
		if(b_v_ii > 5) goto b_f30_e;
b_f30_t: ;
		/* line 2925 */
b_L2925: ;
		b_v_ji=((b_v_ii)+(b_int(((b_rnd(B_INT((1))))*((((7))-(b_v_ii)))))));
		/* line 2930 */
b_L2930: ;
		b_v_ti=b_a_bgi[B_INT(b_v_ii)];
		/* line 2935 */
b_L2935: ;
		b_a_bgi[B_INT(b_v_ii)]=b_a_bgi[B_INT(b_v_ji)];
		/* line 2940 */
b_L2940: ;
		b_a_bgi[B_INT(b_v_ji)]=b_v_ti;
		/* line 2945 */
b_L2945: ;
		b_v_ii += 1;
		if(b_v_ii <= 5) goto b_f30_t;
b_f30_e: ;
		/* line 2950 */
b_L2950: ;
		b_v_bii=(0);
		/* line 2955 */
b_L2955: ;
		b_v_dri=b_a_bgi[B_INT(b_v_bii)];
		/* line 2960 */
b_L2960: ;
		b_v_bii=((b_v_bii)+((1)));
		/* line 2965 */
b_L2965: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		b_v_ii=(1);
		b_fl_31=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_31) goto b_f31_e;
		b_v_M12=(((1024))+(b_v_hxi));
		b_v_M13=((b_v_hyi)*((40)));
		b_t_41=((((((b_v_M12)+(b_v_ii)))-((1))))+(b_v_M13));
b_f31_t: ;
		/* line 3005 */
b_L3005: ;
		b_v_cti=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 3010 */
b_L3010: ;
		if(-((b_v_cti) >= ((64)))){
			if(-((b_v_cti) <= ((95)))){
				b_v_cti=((b_v_cti)-((64)));
			}
		}
		/* line 3015 */
b_L3015: ;
		b_poke(b_t_41,b_v_cti);
		/* line 3020 */
b_L3020: ;
		b_t_41 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_31)) goto b_f31_t;
b_f31_e: ;
		/* line 3025 */
b_L3025: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
