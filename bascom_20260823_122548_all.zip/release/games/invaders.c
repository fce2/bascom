/* OPTIMIZE_C -- invaders.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_pci;
static int b_v_pbi;
static int b_v_abi;
static int b_v_bki;
static int b_v_spi;
static bint_t b_a_ali[55];
static int b_a_agi[5];
static int b_a_aci[5];
static bint_t b_a_bui[24];
static bint_t b_a_qxi[3];
static int b_a_qyi[3];
static int b_a_qfi[3];
static bint_t b_a_di[5];
static int b_a_bci[40];
static bint_t b_a_cci[11];
static int b_v_dmi;
static bint_t b_v_sci;
static int b_v_lvi;
static bint_t b_v_wvi;
static int b_v_ggi;
static bint_t b_v_hti;
static int b_v_hui;
static int b_v_ufi;
static bint_t b_v_uci;
static bint_t b_v_uxi;
static bint_t b_v_pxi;
static int b_v_opi;
static int b_v_bfi;
static int b_v_byi;
static bint_t b_v_bxi;
static int b_v_ii;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_dfi;
static breal_t b_v_bpf;
static bint_t b_v_tci;
static bint_t b_v_fci;
static bint_t b_v_mvi;
static int b_v_aii;
static int b_v_mni;
static int b_v_mxi;
static bint_t b_v_axi;
static bint_t b_v_oxi;
static int b_v_ayi;
static int b_v_oyi;
static bint_t b_v_lxi;
static bint_t b_v_rxi;
static bint_t b_v_dii;
static int b_v_ci;
static int b_v_rci;
static int b_v_lri;
static int b_v_ri;
static int b_v_sii;
static bint_t b_v_hki;
static int b_v_rhi;
static int b_v_chi;
static int b_v_aci;
static bint_t b_v_adi;
static int b_v_yi;
static int b_v_xi;
static bint_t b_v_zki;
static bint_t b_v_cli;
static int b_v_rwi;
static bint_t b_v_bii;
static bint_t b_v_bhi;
static int b_v_bgi;
static int b_v_gei;
static int b_v_exi;
static int b_v_ji;
static bint_t b_v_ti;
static int b_v_qmi;
static int b_v_dki;
static int b_v_qci;
static int b_v_ati;
static int b_v_dgi;
static int b_v_fdi;
static int b_v_fti;
static bint_t b_v_ldi;
static int b_v_rfi;
static breal_t b_v_xxf;
static int b_v_fri;
static int b_v_cxi;
static int b_v_dti;
static int b_v_bbi;
static int b_v_jji;
static breal_t b_v_rrf;
static breal_t b_v_ccf;
static breal_t b_v_yyf;
static int b_v_rbi;
static bint_t b_v_sbi;
static bint_t b_v_dbi;
static bstr_t b_v_kls;
static bstr_t b_v_krs;
static bstr_t b_v_ks;
static int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static int b_v_M3;
static int b_v_M4;
static int b_v_M5;
static bint_t b_v_M6;
static bint_t b_v_M7;
static int b_v_M8;
static bint_t b_v_M9;
static int b_v_M10;
static int b_v_M11;
static int b_v_M12;
static int b_v_M13;
static int b_v_M14;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
static int b_fl_8;
static int b_fl_11;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		b_putc(147);
		b_nl();
		/* line 70 */
b_L70: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 80 */
b_L80: ;
		b_v_pci=(81);
		b_v_pbi=(124);
		b_v_abi=(42);
		b_v_bki=(160);
		b_v_spi=(32);
		/* line 90 */
b_L90: ;
		/* line 100 */
b_L100: ;
		b_v_dmi=(1);
		b_gosubStack[b_gosubSP++]=0; goto b_L3500;
b_ret0: ;
		/* line 110 */
b_L110: ;
		b_v_sci=(0);
		b_v_lvi=(3);
		b_v_wvi=(1);
		b_v_ggi=(0);
		b_v_hti=(0);
		b_v_hui=(1);
		b_v_bki=(1);
		b_v_ufi=(0);
		b_v_uci=(0);
		b_v_uxi=(0);
		/* line 120 */
b_L120: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L3400;
b_ret1: ;
		/* line 130 */
b_L130: ;
		b_v_pxi=(20);
		b_v_opi=(20);
		b_v_bfi=(0);
		b_v_byi=(0);
		b_v_bxi=(0);
		/* line 140 */
b_L140: ;
		b_v_ii=(0);
		if(b_v_ii > 2) goto b_f0_e;
b_f0_t: ;
		b_a_qfi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 2) goto b_f0_t;
b_f0_e: ;
		/* line 150 */
b_L150: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L3600;
b_ret2: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L3300;
b_ret3: ;
		/* line 160 */
b_L160: ;
		b_poke((((1944))+(b_v_pxi)),b_v_pci);
		b_poke((((((55296.0))+((920))))+(b_v_pxi)),(5));
		/* line 170 */
b_L170: ;
		/* line 180 */
b_L180: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		/* line 190 */
b_L190: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 192 */
b_L192: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 193 */
b_L193: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((14)))){
				b_v_dfi=(1);
				b_v_bpf=(0.017999999996391125);
				b_v_dmi=(0);
				b_v_hui=(1);
				goto b_L110;
			}
		}
		/* line 210 */
b_L210: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((29)))){
				b_v_dfi=(0);
				b_v_bpf=(0.04499999999825377);
				b_v_dmi=(0);
				b_v_hui=(1);
				goto b_L110;
			}
		}
		/* line 220 */
b_L220: ;
		if(-((b_v_ki) == ((62)))){
			goto b_L3800;
		}
		/* line 230 */
b_L230: ;
		if(-((b_v_ki) == ((36)))){
			b_v_dmi=(((1))-(b_v_dmi));
			b_v_hui=(1);
		}
		/* line 240 */
b_L240: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=4; goto b_L2600;
b_ret4: ;
		}
		/* line 250 */
b_L250: ;
		if(-((b_v_ki) == ((10)))){
			if(-((b_v_pxi) > ((0)))){
				b_v_pxi=((b_v_pxi)-((1)));
			}
		}
		/* line 270 */
b_L270: ;
		if(-((b_v_ki) == ((18)))){
			if(-((b_v_pxi) < ((39)))){
				b_v_pxi=((b_v_pxi)+((1)));
			}
		}
		/* line 290 */
b_L290: ;
		if(-((b_v_ki) == ((60)))){
			if(-((b_v_bfi) == ((0)))){
				b_v_bfi=(1);
				b_v_bxi=b_v_pxi;
				b_v_byi=(21);
			}
		}
		/* line 300 */
b_L300: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1000;
b_ret5: ;
		/* line 310 */
b_L310: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L1300;
b_ret6: ;
		/* line 320 */
b_L320: ;
		b_gosubStack[b_gosubSP++]=7; goto b_L1700;
b_ret7: ;
		/* line 330 */
b_L330: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L2300;
b_ret8: ;
		/* line 340 */
b_L340: ;
		b_gosubStack[b_gosubSP++]=9; goto b_L2100;
b_ret9: ;
		/* line 350 */
b_L350: ;
		if(-((b_v_ggi) == ((1)))){
			goto b_L3700;
		}
		/* line 360 */
b_L360: ;
		goto b_L180;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_tci=((b_v_tci)+((1)));
		b_v_fci=((b_v_fci)+((1)));
		if(-((b_v_fci) >= ((5)))){
			b_v_fci=(0);
		}
		/* line 1002 */
b_L1002: ;
		if(-((b_rnd(B_INT((1)))) < (b_v_bpf))){
			b_gosubStack[b_gosubSP++]=10; goto b_L1200;
b_ret10: ;
		}
		/* line 1003 */
b_L1003: ;
		if(-((b_v_tci) < (b_v_mvi))){
			goto b_return;
		}
		/* line 1004 */
b_L1004: ;
		b_v_tci=(0);
		/* line 1005 */
b_L1005: ;
		b_v_aii=(1);
		/* line 1006 */
b_L1006: ;
		if(-((b_v_mni) > (b_v_mxi))){
			goto b_return;
		}
		/* line 1007 */
b_L1007: ;
		b_v_axi=b_v_oxi;
		b_v_ayi=b_v_oyi;
		/* line 1008 */
b_L1008: ;
		b_v_lxi=((b_v_oxi)+(((b_v_mni)*((2)))));
		b_v_rxi=((b_v_oxi)+(((b_v_mxi)*((2)))));
		/* line 1009 */
b_L1009: ;
		if(-((b_v_dii) < ((0)))){
			if(-((b_v_lxi) <= ((0)))){
				b_v_dii=(((0))-(b_v_dii));
				b_v_oyi=((b_v_oyi)+((1)));
				goto b_L1012;
			}
		}
		/* line 1010 */
b_L1010: ;
		if(-((b_v_dii) > ((0)))){
			if(-((b_v_rxi) >= ((39)))){
				b_v_dii=(((0))-(b_v_dii));
				b_v_oyi=((b_v_oyi)+((1)));
				goto b_L1012;
			}
		}
		/* line 1011 */
b_L1011: ;
		b_v_oxi=((b_v_oxi)+(b_v_dii));
		/* line 1012 */
b_L1012: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L3200;
b_ret11: ;
		/* line 1013 */
b_L1013: ;
		if(-((((b_v_oyi)+((4)))) >= ((22)))){
			b_v_ggi=(1);
		}
		/* line 1014 */
b_L1014: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_mni=(11);
		b_v_mxi=(-1);
		/* line 1102 */
b_L1102: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f1_e;
b_f1_t: ;
		/* line 1103 */
b_L1103: ;
		if(-((b_a_cci[B_INT(b_v_ci)]) > ((0)))){
			if(-((b_v_ci) < (b_v_mni))){
				b_v_mni=b_v_ci;
			}
		}
		/* line 1104 */
b_L1104: ;
		if(-((b_a_cci[B_INT(b_v_ci)]) > ((0)))){
			if(-((b_v_ci) > (b_v_mxi))){
				b_v_mxi=b_v_ci;
			}
		}
		/* line 1105 */
b_L1105: ;
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f1_t;
b_f1_e: ;
		/* line 1106 */
b_L1106: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_rci=b_int(((b_rnd(B_INT((1))))*((11))));
		/* line 1202 */
b_L1202: ;
		b_v_lri=(-1);
		/* line 1203 */
b_L1203: ;
		b_v_ri=(4);
		if(b_v_ri < 0) goto b_f2_e;
b_f2_t: ;
		/* line 1204 */
b_L1204: ;
		if(-((b_v_lri) < ((0)))){
			if(-((b_a_ali[B_INT(((((b_v_ri)*((11))))+(b_v_rci)))]) == ((1)))){
				b_v_lri=b_v_ri;
			}
		}
		/* line 1205 */
b_L1205: ;
		b_v_ri += -1;
		if(b_v_ri >= 0) goto b_f2_t;
b_f2_e: ;
		/* line 1206 */
b_L1206: ;
		if(-((b_v_lri) < ((0)))){
			goto b_return;
		}
		/* line 1207 */
b_L1207: ;
		b_v_sii=(-1);
		/* line 1208 */
b_L1208: ;
		b_v_ii=(0);
		if(b_v_ii > 2) goto b_f3_e;
b_f3_t: ;
		/* line 1209 */
b_L1209: ;
		if(-((b_v_sii) < ((0)))){
			if(-((b_a_qfi[B_INT(b_v_ii)]) == ((0)))){
				b_v_sii=b_v_ii;
			}
		}
		/* line 1210 */
b_L1210: ;
		b_v_ii += 1;
		if(b_v_ii <= 2) goto b_f3_t;
b_f3_e: ;
		/* line 1211 */
b_L1211: ;
		if(-((b_v_sii) < ((0)))){
			goto b_return;
		}
		/* line 1212 */
b_L1212: ;
		b_a_qxi[B_INT(b_v_sii)]=((((b_v_rci)*((2))))+(b_v_oxi));
		b_a_qyi[B_INT(b_v_sii)]=((((b_v_oyi)+(b_v_lri)))+((1)));
		b_a_qfi[B_INT(b_v_sii)]=(1);
		/* line 1213 */
b_L1213: ;
		if(-((b_a_qyi[B_INT(b_v_sii)]) > ((23)))){
			b_a_qfi[B_INT(b_v_sii)]=(0);
		}
		/* line 1214 */
b_L1214: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		if(-((b_v_bfi) == ((0)))){
			goto b_return;
		}
		/* line 1302 */
b_L1302: ;
		b_poke((((((1024))+(((b_v_byi)*((40))))))+(b_v_bxi)),b_v_spi);
		/* line 1303 */
b_L1303: ;
		b_v_byi=((b_v_byi)-((1)));
		/* line 1304 */
b_L1304: ;
		if(-((b_v_byi) < ((1)))){
			b_v_bfi=(0);
			goto b_return;
		}
		/* line 1305 */
b_L1305: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1500;
b_ret12: ;
		if(-((b_v_hki) == ((1)))){
			b_v_bfi=(0);
			goto b_return;
		}
		/* line 1306 */
b_L1306: ;
		b_v_rhi=((b_v_byi)-(b_v_oyi));
		/* line 1307 */
b_L1307: ;
		if(-((b_v_rhi) < ((0)))){ goto b_L1316; }
		/* line 1308 */
b_L1308: ;
		if(-((b_v_rhi) > ((4)))){ goto b_L1316; }
		/* line 1309 */
b_L1309: ;
		b_v_chi=((b_v_bxi)-(b_v_oxi));
		/* line 1310 */
b_L1310: ;
		if(-((b_v_chi) < ((0)))){ goto b_L1316; }
		/* line 1311 */
b_L1311: ;
		if(-((b_v_chi) > ((20)))){ goto b_L1316; }
		/* line 1312 */
b_L1312: ;
		b_v_aci=b_int(((breal_t)(b_v_chi)/(breal_t)((2))));
		/* line 1313 */
b_L1313: ;
		if(-((((b_v_aci)*((2)))) != (b_v_chi))){ goto b_L1316; }
		/* line 1314 */
b_L1314: ;
		if(-((b_a_ali[B_INT(((((b_v_rhi)*((11))))+(b_v_aci)))]) == ((1)))){
			b_gosubStack[b_gosubSP++]=13; goto b_L1400;
b_ret13: ;
			goto b_return;
		}
		/* line 1315 */
b_L1315: ;
		if(-((b_v_ufi) == ((1)))){
			if(-((b_v_bxi) == (b_v_uxi))){
				if(-((b_v_byi) <= ((2)))){
					b_v_sci=((b_v_sci)+((100)));
					b_v_ufi=(0);
					b_poke((((1064))+(b_v_uxi)),(32));
					b_v_hui=(1);
					b_v_bfi=(0);
					b_poke((((((1024))+(((b_v_byi)*((40))))))+(b_v_bxi)),b_v_spi);
					goto b_return;
				}
			}
		}
		/* line 1316 */
b_L1316: ;
		b_poke((((((1024))+(((b_v_byi)*((40))))))+(b_v_bxi)),b_v_pbi);
		b_poke((((((55296.0))+(((b_v_byi)*((40))))))+(b_v_bxi)),(7));
		/* line 1317 */
b_L1317: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_a_ali[B_INT(((((b_v_rhi)*((11))))+(b_v_aci)))]=(0);
		/* line 1402 */
b_L1402: ;
		b_a_cci[B_INT(b_v_aci)]=((b_a_cci[B_INT(b_v_aci)])-((1)));
		if(-((b_a_cci[B_INT(b_v_aci)]) == ((0)))){
			if((B_INT(-((b_v_aci) == (b_v_mni))) | B_INT(-((b_v_aci) == (b_v_mxi))))){
				b_gosubStack[b_gosubSP++]=14; goto b_L1100;
b_ret14: ;
			}
		}
		/* line 1403 */
b_L1403: ;
		b_poke((((((1024))+(((b_v_byi)*((40))))))+(b_v_bxi)),b_v_spi);
		/* line 1404 */
b_L1404: ;
		b_v_adi=((b_v_adi)-((1)));
		/* line 1405 */
b_L1405: ;
		if(-((b_v_rhi) == ((0)))){
			b_v_sci=((b_v_sci)+((30)));
			goto b_L1408;
		}
		/* line 1406 */
b_L1406: ;
		if(-((b_v_rhi) < ((3)))){
			b_v_sci=((b_v_sci)+((20)));
			goto b_L1408;
		}
		/* line 1407 */
b_L1407: ;
		b_v_sci=((b_v_sci)+((10)));
		/* line 1408 */
b_L1408: ;
		b_v_mvi=b_int(((breal_t)(b_v_adi)/(breal_t)((4))));
		if(-((b_v_mvi) < ((3)))){
			b_v_mvi=(3);
		}
		/* line 1409 */
b_L1409: ;
		if(-((b_v_dfi) == ((1)))){
			b_v_mvi=((((b_v_mvi)*((2))))+(b_int(((breal_t)(b_v_mvi)/(breal_t)((2))))));
		}
		/* line 1410 */
b_L1410: ;
		b_v_hui=(1);
		b_v_bfi=(0);
		/* line 1411 */
b_L1411: ;
		if(-((b_v_adi) <= ((0)))){
			b_gosubStack[b_gosubSP++]=15; goto b_L1600;
b_ret15: ;
		}
		/* line 1412 */
b_L1412: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_hki=(0);
		b_v_yi=b_v_byi;
		b_v_xi=b_v_bxi;
		/* line 1502 */
b_L1502: ;
		if(-((b_v_yi) < ((19)))){
			goto b_return;
		}
		/* line 1503 */
b_L1503: ;
		if(-((b_v_yi) > ((20)))){
			goto b_return;
		}
		/* line 1504 */
b_L1504: ;
		if(-((b_v_xi) >= ((5)))){
			if(-((b_v_xi) <= ((7)))){
				b_v_zki=(0);
				goto b_L1509;
			}
		}
		/* line 1505 */
b_L1505: ;
		if(-((b_v_xi) >= ((15)))){
			if(-((b_v_xi) <= ((17)))){
				b_v_zki=(1);
				goto b_L1509;
			}
		}
		/* line 1506 */
b_L1506: ;
		if(-((b_v_xi) >= ((25)))){
			if(-((b_v_xi) <= ((27)))){
				b_v_zki=(2);
				goto b_L1509;
			}
		}
		/* line 1507 */
b_L1507: ;
		if(-((b_v_xi) >= ((35)))){
			if(-((b_v_xi) <= ((37)))){
				b_v_zki=(3);
				goto b_L1509;
			}
		}
		/* line 1508 */
b_L1508: ;
		goto b_return;
		/* line 1509 */
b_L1509: ;
		b_v_cli=((((b_v_xi)-((5))))-(((b_v_zki)*((10)))));
		b_v_rwi=((b_v_yi)-((19)));
		b_v_bii=((((((b_v_zki)*((6))))+(((b_v_rwi)*((3))))))+(b_v_cli));
		/* line 1510 */
b_L1510: ;
		if(-((b_a_bui[B_INT(b_v_bii)]) > ((0)))){
			b_a_bui[B_INT(b_v_bii)]=((b_a_bui[B_INT(b_v_bii)])-((1)));
			b_v_hki=(1);
			b_v_bhi=b_a_bui[B_INT(b_v_bii)];
			b_v_bki=(1);
			b_gosubStack[b_gosubSP++]=16; goto b_L3100;
b_ret16: ;
			b_poke((((((1024))+(((b_v_yi)*((40))))))+(b_v_xi)),b_v_bgi);
		}
		/* line 1511 */
b_L1511: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		b_v_wvi=((b_v_wvi)+((1)));
		b_v_hui=(1);
		b_v_aii=(1);
		/* line 1602 */
b_L1602: ;
		b_v_oxi=(10);
		b_v_oyi=(2);
		b_v_dii=(1);
		b_v_adi=(55);
		b_v_tci=(0);
		b_v_mvi=(13);
		if(-((b_v_dfi) == ((1)))){
			b_v_mvi=(32);
		}
		/* line 1603 */
b_L1603: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_mvi=((b_v_mvi)+((10)));
		}
		/* line 1604 */
b_L1604: ;
		if(-((b_v_wvi) > ((1)))){
			b_v_oyi=(((((2))+(b_v_wvi)))-((1)));
			if(-((b_v_oyi) > ((7)))){
				b_v_oyi=(7);
			}
		}
		/* line 1605 */
b_L1605: ;
		b_v_ii=(0);
		if(b_v_ii > 54) goto b_f4_e;
b_f4_t: ;
		b_a_ali[B_INT(b_v_ii)]=(1);
		b_v_ii += 1;
		if(b_v_ii <= 54) goto b_f4_t;
b_f4_e: ;
		/* line 1606 */
b_L1606: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f5_e;
b_f5_t: ;
		b_a_cci[B_INT(b_v_ci)]=(5);
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f5_t;
b_f5_e: ;
		b_v_mni=(0);
		b_v_mxi=(10);
		/* line 1607 */
b_L1607: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L3300;
b_ret17: ;
		/* line 1608 */
b_L1608: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		if(-((b_v_dfi) == ((1)))){
			if(-((b_v_fci) < ((3)))){
				goto b_return;
			}
		}
		/* line 1702 */
b_L1702: ;
		b_v_ii=(0);
		if(b_v_ii > 2) goto b_f6_e;
b_f6_t: ;
		/* line 1703 */
b_L1703: ;
		if(-((b_a_qfi[B_INT(b_v_ii)]) == ((0)))){ goto b_L1710; }
		/* line 1704 */
b_L1704: ;
		b_poke((((((1024))+(((b_a_qyi[B_INT(b_v_ii)])*((40))))))+(b_a_qxi[B_INT(b_v_ii)])),b_v_spi);
		/* line 1705 */
b_L1705: ;
		b_a_qyi[B_INT(b_v_ii)]=((b_a_qyi[B_INT(b_v_ii)])+((1)));
		/* line 1706 */
b_L1706: ;
		if(-((b_a_qyi[B_INT(b_v_ii)]) > ((23)))){
			b_a_qfi[B_INT(b_v_ii)]=(0);
			goto b_L1710;
		}
		/* line 1707 */
b_L1707: ;
		if(-((b_a_qxi[B_INT(b_v_ii)]) == (b_v_pxi))){
			if(-((b_a_qyi[B_INT(b_v_ii)]) == ((23)))){
				b_gosubStack[b_gosubSP++]=18; goto b_L1800;
b_ret18: ;
				goto b_L1710;
			}
		}
		/* line 1708 */
b_L1708: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L2000;
b_ret19: ;
		if(-((b_v_hki) == ((1)))){
			b_a_qfi[B_INT(b_v_ii)]=(0);
			goto b_L1710;
		}
		/* line 1709 */
b_L1709: ;
		b_poke((((((1024))+(((b_a_qyi[B_INT(b_v_ii)])*((40))))))+(b_a_qxi[B_INT(b_v_ii)])),b_v_abi);
		b_poke((((((55296.0))+(((b_a_qyi[B_INT(b_v_ii)])*((40))))))+(b_a_qxi[B_INT(b_v_ii)])),(2));
		/* line 1710 */
b_L1710: ;
		b_v_ii += 1;
		if(b_v_ii <= 2) goto b_f6_t;
b_f6_e: ;
		/* line 1711 */
b_L1711: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_lvi=((b_v_lvi)-((1)));
		b_v_hui=(1);
		b_a_qfi[B_INT(b_v_ii)]=(0);
		b_v_hti=(0);
		/* line 1802 */
b_L1802: ;
		if(-((b_v_lvi) <= ((0)))){
			b_v_ggi=(1);
			goto b_return;
		}
		/* line 1803 */
b_L1803: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L1900;
b_ret20: ;
		/* line 1804 */
b_L1804: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_ri=(1);
		if(b_v_ri > 9) goto b_f7_e;
b_f7_t: ;
		/* line 1902 */
b_L1902: ;
		b_v_gei=(81);
		if(-((b_v_ri) >= ((3)))){
			b_v_gei=(42);
			if(-((b_v_ri) >= ((5)))){
				b_v_gei=(46);
				if(-((b_v_ri) >= ((7)))){
					b_v_gei=(81);
				}
			}
		}
		/* line 1903 */
b_L1903: ;
		b_v_exi=((b_v_pxi)-(b_v_ri));
		b_fl_8=((b_v_pxi)+(b_v_ri));
		if(b_v_exi > b_fl_8) goto b_f8_e;
		b_t_5=(((1944))+(b_v_exi));
		b_t_6=(((((55296.0))+((920))))+(b_v_exi));
b_f8_t: ;
		/* line 1904 */
b_L1904: ;
		if(-((b_v_exi) < ((0)))){ goto b_L1907; }
		/* line 1905 */
b_L1905: ;
		if(-((b_v_exi) > ((39)))){ goto b_L1907; }
		/* line 1906 */
b_L1906: ;
		b_poke(b_t_5,b_v_gei);
		b_poke(b_t_6,(2));
		/* line 1907 */
b_L1907: ;
		b_t_5 += 1;
		b_t_6 += 1;
		b_v_exi += 1;
		if(b_v_exi <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		/* line 1908 */
b_L1908: ;
		b_v_ji=(1);
		if(b_v_ji > 1500) goto b_f9_e;
b_f9_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 1500) goto b_f9_t;
b_f9_e: ;
		/* line 1909 */
b_L1909: ;
		b_v_ri += 1;
		if(b_v_ri <= 9) goto b_f7_t;
b_f7_e: ;
		/* line 1910 */
b_L1910: ;
		b_v_ji=(1);
		if(b_v_ji > 3000) goto b_f10_e;
b_f10_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 3000) goto b_f10_t;
b_f10_e: ;
		/* line 1911 */
b_L1911: ;
		b_v_exi=((b_v_pxi)-((9)));
		b_fl_11=((b_v_pxi)+((9)));
		if(b_v_exi > b_fl_11) goto b_f11_e;
		b_t_7=(((1944))+(b_v_exi));
b_f11_t: ;
		/* line 1912 */
b_L1912: ;
		if(-((b_v_exi) < ((0)))){ goto b_L1915; }
		/* line 1913 */
b_L1913: ;
		if(-((b_v_exi) > ((39)))){ goto b_L1915; }
		/* line 1914 */
b_L1914: ;
		b_poke(b_t_7,b_v_spi);
		/* line 1915 */
b_L1915: ;
		b_t_7 += 1;
		b_v_exi += 1;
		if(b_v_exi <= (b_fl_11)) goto b_f11_t;
b_f11_e: ;
		/* line 1916 */
b_L1916: ;
		b_v_ji=(1);
		if(b_v_ji > 2500) goto b_f12_e;
b_f12_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 2500) goto b_f12_t;
b_f12_e: ;
		/* line 1917 */
b_L1917: ;
		b_poke((((1944))+(b_v_pxi)),b_v_pci);
		b_poke((((((55296.0))+((920))))+(b_v_pxi)),(5));
		b_v_opi=b_v_pxi;
		/* line 1918 */
b_L1918: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_hki=(0);
		b_v_yi=b_a_qyi[B_INT(b_v_ii)];
		b_v_xi=b_a_qxi[B_INT(b_v_ii)];
		/* line 2002 */
b_L2002: ;
		if(-((b_v_yi) < ((19)))){
			goto b_return;
		}
		/* line 2003 */
b_L2003: ;
		if(-((b_v_yi) > ((20)))){
			goto b_return;
		}
		/* line 2004 */
b_L2004: ;
		if(-((b_v_xi) >= ((5)))){
			if(-((b_v_xi) <= ((7)))){
				b_v_zki=(0);
				goto b_L2009;
			}
		}
		/* line 2005 */
b_L2005: ;
		if(-((b_v_xi) >= ((15)))){
			if(-((b_v_xi) <= ((17)))){
				b_v_zki=(1);
				goto b_L2009;
			}
		}
		/* line 2006 */
b_L2006: ;
		if(-((b_v_xi) >= ((25)))){
			if(-((b_v_xi) <= ((27)))){
				b_v_zki=(2);
				goto b_L2009;
			}
		}
		/* line 2007 */
b_L2007: ;
		if(-((b_v_xi) >= ((35)))){
			if(-((b_v_xi) <= ((37)))){
				b_v_zki=(3);
				goto b_L2009;
			}
		}
		/* line 2008 */
b_L2008: ;
		goto b_return;
		/* line 2009 */
b_L2009: ;
		b_v_cli=((((b_v_xi)-((5))))-(((b_v_zki)*((10)))));
		b_v_rwi=((b_v_yi)-((19)));
		b_v_bii=((((((b_v_zki)*((6))))+(((b_v_rwi)*((3))))))+(b_v_cli));
		/* line 2010 */
b_L2010: ;
		if(-((b_a_bui[B_INT(b_v_bii)]) > ((0)))){
			b_a_bui[B_INT(b_v_bii)]=((b_a_bui[B_INT(b_v_bii)])-((1)));
			b_v_hki=(1);
			b_v_bhi=b_a_bui[B_INT(b_v_bii)];
			b_v_bki=(1);
			b_gosubStack[b_gosubSP++]=21; goto b_L3100;
b_ret21: ;
			b_poke((((((1024))+(((b_v_yi)*((40))))))+(b_v_xi)),b_v_bgi);
		}
		/* line 2011 */
b_L2011: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		if(-((b_v_hti) > ((0)))){
			b_gosubStack[b_gosubSP++]=22; goto b_L2200;
b_ret22: ;
			goto b_L2103;
		}
		/* line 2102 */
b_L2102: ;
		if(-((b_v_opi) != (b_v_pxi))){
			b_poke((((1944))+(b_v_opi)),b_v_spi);
			b_poke((((1944))+(b_v_pxi)),b_v_pci);
			b_poke((((((55296.0))+((920))))+(b_v_pxi)),(5));
			b_v_opi=b_v_pxi;
		}
		/* line 2103 */
b_L2103: ;
		if(-((b_v_hui) == ((1)))){
			b_v_hui=(0);
			b_gosubStack[b_gosubSP++]=23; goto b_L2400;
b_ret23: ;
		}
		/* line 2104 */
b_L2104: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		if(-((b_v_opi) != (b_v_pxi))){
			b_poke((((1944))+(b_v_opi)),b_v_spi);
		}
		/* line 2202 */
b_L2202: ;
		b_poke((((1944))+(b_v_pxi)),(42));
		b_poke((((((55296.0))+((920))))+(b_v_pxi)),(2));
		b_v_hti=((b_v_hti)-((1)));
		b_v_opi=b_v_pxi;
		/* line 2203 */
b_L2203: ;
		if(-((b_v_hti) == ((0)))){
			b_poke((((1944))+(b_v_pxi)),b_v_pci);
			b_poke((((((55296.0))+((920))))+(b_v_pxi)),(5));
		}
		/* line 2204 */
b_L2204: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		if(-((b_v_ufi) == ((0)))){
			b_v_uci=((b_v_uci)+((1)));
			if(-((b_v_uci) >= ((600)))){
				b_v_uci=(0);
				b_v_ufi=(1);
				b_v_uxi=(0);
			}
		}
		/* line 2302 */
b_L2302: ;
		if(-((b_v_ufi) == ((0)))){
			goto b_return;
		}
		/* line 2303 */
b_L2303: ;
		b_poke((((1064))+(b_v_uxi)),(32));
		/* line 2304 */
b_L2304: ;
		b_v_uxi=((b_v_uxi)+((1)));
		if(-((b_v_uxi) > ((39)))){
			b_v_ufi=(0);
			goto b_return;
		}
		/* line 2305 */
b_L2305: ;
		b_poke((((1064))+(b_v_uxi)),(81));
		b_poke((((((55296.0))+((40))))+(b_v_uxi)),(1));
		/* line 2306 */
b_L2306: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_v_ti=b_v_sci;
		b_v_ji=(0);
		if(b_v_ji > 4) goto b_f13_e;
b_f13_t: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_ji += 1;
		if(b_v_ji <= 4) goto b_f13_t;
b_f13_e: ;
		/* line 2402 */
b_L2402: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((4))])));
		b_poke((1031),(((48))+(b_a_di[B_INT((3))])));
		b_poke((1032),(((48))+(b_a_di[B_INT((2))])));
		/* line 2403 */
b_L2403: ;
		b_poke((1033),(((48))+(b_a_di[B_INT((1))])));
		b_poke((1034),(((48))+(b_a_di[B_INT((0))])));
		/* line 2404 */
b_L2404: ;
		b_poke((1042),(((48))+(b_v_lvi)));
		/* line 2405 */
b_L2405: ;
		b_poke((1050),(((48))+(b_int(((breal_t)(b_v_wvi)/(breal_t)((10)))))));
		b_poke((1051),(((((48))+(b_v_wvi)))-((((10))*(b_int(((breal_t)(b_v_wvi)/(breal_t)((10)))))))));
		/* line 2406 */
b_L2406: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
			goto b_L2408;
		}
		/* line 2407 */
b_L2407: ;
		b_poke((1060),(32));
		b_poke((1061),(32));
		b_poke((1062),(32));
		b_poke((1063),(32));
		b_poke((55332.0),(0));
		b_poke((55333.0),(0));
		b_poke((55334.0),(0));
		b_poke((55335.0),(0));
		/* line 2408 */
b_L2408: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L2500;
b_ret24: ;
		/* line 2409 */
b_L2409: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		b_v_qmi=(1997);
		/* line 2502 */
b_L2502: ;
		if(-((b_v_dmi) == ((1)))){ goto b_L2504; }
		/* line 2503 */
b_L2503: ;
		b_v_ii=(0);
		if(b_v_ii > 13) goto b_f14_e;
		b_t_9=((b_v_qmi)+(b_v_ii));
		b_t_10=(((((55296.0))+(b_v_qmi)))+(b_v_ii));
b_f14_t: ;
		b_poke(b_t_9,(32));
		b_poke(b_t_10,(0));
		b_t_9 += 1;
		b_t_10 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 13) goto b_f14_t;
b_f14_e: ;
		goto b_return;
		/* line 2504 */
b_L2504: ;
		b_poke(((b_v_qmi)+((0))),(5));
		b_poke(((b_v_qmi)+((1))),(61));
		b_poke(((b_v_qmi)+((2))),(5));
		b_poke(((b_v_qmi)+((3))),(1));
		b_poke(((b_v_qmi)+((4))),(19));
		b_poke(((b_v_qmi)+((5))),(25));
		/* line 2505 */
b_L2505: ;
		b_poke(((b_v_qmi)+((6))),(32));
		b_poke(((b_v_qmi)+((7))),(32));
		b_poke(((b_v_qmi)+((8))),(8));
		b_poke(((b_v_qmi)+((9))),(61));
		/* line 2506 */
b_L2506: ;
		b_poke(((b_v_qmi)+((10))),(8));
		b_poke(((b_v_qmi)+((11))),(1));
		b_poke(((b_v_qmi)+((12))),(18));
		b_poke(((b_v_qmi)+((13))),(4));
		/* line 2507 */
b_L2507: ;
		b_v_ii=(0);
		if(b_v_ii > 13) goto b_f15_e;
		b_t_11=(((((55296.0))+(b_v_qmi)))+(b_v_ii));
b_f15_t: ;
		b_poke(b_t_11,(1));
		b_t_11 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 13) goto b_f15_t;
b_f15_e: ;
		goto b_return;
		/* line 2600 */
b_L2600: ;
		/* line 2601 */
b_L2601: ;
		b_v_ki=(64);
		/* line 2602 */
b_L2602: ;
		b_v_dki=(0);
		b_v_ii=(0);
		if(b_v_ii > 2) goto b_f16_e;
b_f16_t: ;
		/* line 2603 */
b_L2603: ;
		if(-((b_a_qfi[B_INT(b_v_ii)]) == ((0)))){ goto b_L2607; }
		/* line 2604 */
b_L2604: ;
		if(-((b_a_qyi[B_INT(b_v_ii)]) > ((22)))){ goto b_L2607; }
		/* line 2605 */
b_L2605: ;
		if(-((b_a_qyi[B_INT(b_v_ii)]) < ((18)))){ goto b_L2607; }
		/* line 2606 */
b_L2606: ;
		if(-((b_a_qxi[B_INT(b_v_ii)]) == (b_v_pxi))){
			b_v_dki=(1);
		}
		/* line 2607 */
b_L2607: ;
		b_v_ii += 1;
		if(b_v_ii <= 2) goto b_f16_t;
b_f16_e: ;
		/* line 2608 */
b_L2608: ;
		if(-((b_v_dki) == ((0)))){ goto b_L2616; }
		/* line 2609 */
b_L2609: ;
		b_v_ki=(18);
		if(-((b_v_pxi) >= ((20)))){
			b_v_ki=(10);
		}
		/* line 2610 */
b_L2610: ;
		if(-((b_v_ki) == ((18)))){
			b_v_qci=((b_v_pxi)+((1)));
			b_gosubStack[b_gosubSP++]=25; goto b_L2700;
b_ret25: ;
			if(-((b_v_hki) == ((1)))){
				b_v_ki=(10);
			}
		}
		/* line 2611 */
b_L2611: ;
		if(-((b_v_ki) == ((10)))){
			b_v_qci=((b_v_pxi)-((1)));
			b_gosubStack[b_gosubSP++]=26; goto b_L2700;
b_ret26: ;
			if(-((b_v_hki) == ((1)))){
				b_v_ki=(18);
			}
		}
		/* line 2612 */
b_L2612: ;
		if(-((b_v_ki) == ((18)))){
			if(-((b_v_pxi) >= ((39)))){
				b_v_ki=(10);
			}
		}
		/* line 2613 */
b_L2613: ;
		if(-((b_v_ki) == ((10)))){
			if(-((b_v_pxi) <= ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 2614 */
b_L2614: ;
		if(-((b_v_bfi) == ((0)))){
			if(-((b_abs((breal_t)(((b_v_ati)-(b_v_pxi))))) <= ((1)))){
				b_v_ki=(60);
			}
		}
		/* line 2615 */
b_L2615: ;
		goto b_return;
		/* line 2616 */
b_L2616: ;
		if(-((b_v_bfi) == ((0)))){
			b_gosubStack[b_gosubSP++]=27; goto b_L2800;
b_ret27: ;
		}
		/* line 2617 */
b_L2617: ;
		if(-((b_v_ati) < (b_v_pxi))){
			b_v_qci=((b_v_pxi)-((1)));
			b_gosubStack[b_gosubSP++]=28; goto b_L2700;
b_ret28: ;
			if(-((b_v_hki) == ((0)))){
				b_v_ki=(10);
			}
		}
		/* line 2618 */
b_L2618: ;
		if(-((b_v_ati) > (b_v_pxi))){
			b_v_qci=((b_v_pxi)+((1)));
			b_gosubStack[b_gosubSP++]=29; goto b_L2700;
b_ret29: ;
			if(-((b_v_hki) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 2619 */
b_L2619: ;
		if(-((b_v_ki) != ((64)))){
			goto b_return;
		}
		/* line 2620 */
b_L2620: ;
		if(-((b_v_bfi) == ((0)))){
			b_v_ki=(60);
		}
		/* line 2621 */
b_L2621: ;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		/* line 2701 */
b_L2701: ;
		b_v_hki=(0);
		b_v_ii=(0);
		if(b_v_ii > 2) goto b_f17_e;
b_f17_t: ;
		/* line 2702 */
b_L2702: ;
		if(-((b_a_qfi[B_INT(b_v_ii)]) == ((1)))){
			if(-((b_a_qxi[B_INT(b_v_ii)]) == (b_v_qci))){
				if(-((b_a_qyi[B_INT(b_v_ii)]) > ((17)))){
					if(-((b_a_qyi[B_INT(b_v_ii)]) < ((23)))){
						b_v_hki=(1);
					}
				}
			}
		}
		/* line 2703 */
b_L2703: ;
		b_v_ii += 1;
		if(b_v_ii <= 2) goto b_f17_t;
b_f17_e: ;
		goto b_return;
		/* line 2800 */
b_L2800: ;
		/* line 2801 */
b_L2801: ;
		b_v_lri=(-1);
		b_v_dgi=(99);
		b_v_fdi=(99);
		b_v_fti=(0);
		b_v_ldi=(0);
		b_v_rfi=(0);
		/* line 2802 */
b_L2802: ;
		if(-((b_v_bki) == ((0)))){ goto b_L2807; }
		/* line 2803 */
b_L2803: ;
		b_v_bki=(0);
		b_v_ji=(0);
		if(b_v_ji > 3) goto b_f18_e;
b_f18_t: ;
		b_v_ki=(0);
		if(b_v_ki > 2) goto b_f19_e;
b_f19_t: ;
		b_v_xxf=(((((5))+(((b_v_ji)*((10))))))+(b_v_ki));
		b_a_bci[(bint_t)(b_v_xxf)]=(0);
		/* line 2804 */
b_L2804: ;
		b_v_xi=b_v_xxf;
		b_v_yi=(19);
		b_gosubStack[b_gosubSP++]=30; goto b_L2900;
b_ret30: ;
		if(-((b_v_hki) == ((1)))){
			b_a_bci[(bint_t)(b_v_xxf)]=(1);
		}
		/* line 2805 */
b_L2805: ;
		b_v_yi=(20);
		b_gosubStack[b_gosubSP++]=31; goto b_L2900;
b_ret31: ;
		if(-((b_v_hki) == ((1)))){
			b_a_bci[(bint_t)(b_v_xxf)]=(1);
		}
		/* line 2806 */
b_L2806: ;
		b_v_ki += 1;
		if(b_v_ki <= 2) goto b_f19_t;
b_f19_e: ;
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f18_t;
b_f18_e: ;
		/* line 2807 */
b_L2807: ;
		b_v_ri=(4);
		if(b_v_ri < 0) goto b_f20_e;
b_f20_t: ;
		/* line 2808 */
b_L2808: ;
		if(-((b_v_rfi) == ((1)))){ goto b_L2820; }
		/* line 2809 */
b_L2809: ;
		b_v_fri=(((21))-(((b_v_oyi)+(b_v_ri))));
		b_v_ldi=((b_v_dii)*(b_int(((breal_t)(b_v_fri)/(breal_t)(b_v_mvi)))));
		/* line 2810 */
b_L2810: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f21_e;
		b_v_M0=((b_v_ri)*((11)));
b_f21_t: ;
		/* line 2811 */
b_L2811: ;
		if(-((b_a_ali[B_INT(((b_v_M0)+(b_v_ci)))]) == ((0)))){ goto b_L2819; }
		/* line 2812 */
b_L2812: ;
		b_v_rfi=(1);
		/* line 2813 */
b_L2813: ;
		b_v_cxi=((((((b_v_ci)*((2))))+(b_v_oxi)))+(b_v_ldi));
		/* line 2814 */
b_L2814: ;
		if(-((b_v_cxi) < ((0)))){
			b_v_cxi=(0);
		}
		/* line 2815 */
b_L2815: ;
		if(-((b_v_cxi) > ((39)))){
			b_v_cxi=(39);
		}
		/* line 2816 */
b_L2816: ;
		b_v_dti=b_abs((breal_t)(((b_v_cxi)-(b_v_pxi))));
		/* line 2817 */
b_L2817: ;
		if(-((b_a_bci[B_INT(b_v_cxi)]) == ((0)))){
			if(-((b_v_dti) < (b_v_dgi))){
				b_v_dgi=b_v_dti;
				b_v_ati=b_v_cxi;
			}
		}
		/* line 2818 */
b_L2818: ;
		if(-((b_a_bci[B_INT(b_v_cxi)]) == ((1)))){
			if(-((b_v_dti) < (b_v_fdi))){
				b_v_fdi=b_v_dti;
				b_v_fti=b_v_cxi;
			}
		}
		/* line 2819 */
b_L2819: ;
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f21_t;
b_f21_e: ;
		/* line 2820 */
b_L2820: ;
		b_v_ri += -1;
		if(b_v_ri >= 0) goto b_f20_t;
b_f20_e: ;
		/* line 2821 */
b_L2821: ;
		if(-((b_v_dgi) >= ((99)))){
			b_v_ati=b_v_fti;
		}
		/* line 2822 */
b_L2822: ;
		if((B_INT(-((b_v_dgi) >= ((99)))) & B_INT(-((b_v_fdi) >= ((99)))))){
			b_v_aii=(0);
			goto b_return;
		}
		/* line 2823 */
b_L2823: ;
		if(-((b_v_ati) < ((0)))){
			b_v_ati=(0);
		}
		/* line 2824 */
b_L2824: ;
		if(-((b_v_ati) > ((39)))){
			b_v_ati=(39);
		}
		/* line 2825 */
b_L2825: ;
		b_v_aii=(0);
		/* line 2826 */
b_L2826: ;
		goto b_return;
		/* line 2827 */
b_L2827: ;
		/* line 2900 */
b_L2900: ;
		/* line 2901 */
b_L2901: ;
		b_v_hki=(0);
		/* line 2902 */
b_L2902: ;
		if(-((b_v_xi) < ((5)))){
			goto b_return;
		}
		/* line 2903 */
b_L2903: ;
		if(-((b_v_xi) > ((37)))){
			goto b_return;
		}
		/* line 2904 */
b_L2904: ;
		if((B_INT(-((b_v_xi) >= ((5)))) & B_INT(-((b_v_xi) <= ((7)))))){
			b_v_zki=(0);
			goto b_L2909;
		}
		/* line 2905 */
b_L2905: ;
		if((B_INT(-((b_v_xi) >= ((15)))) & B_INT(-((b_v_xi) <= ((17)))))){
			b_v_zki=(1);
			goto b_L2909;
		}
		/* line 2906 */
b_L2906: ;
		if((B_INT(-((b_v_xi) >= ((25)))) & B_INT(-((b_v_xi) <= ((27)))))){
			b_v_zki=(2);
			goto b_L2909;
		}
		/* line 2907 */
b_L2907: ;
		if((B_INT(-((b_v_xi) >= ((35)))) & B_INT(-((b_v_xi) <= ((37)))))){
			b_v_zki=(3);
			goto b_L2909;
		}
		/* line 2908 */
b_L2908: ;
		goto b_return;
		/* line 2909 */
b_L2909: ;
		b_v_cli=((((b_v_xi)-((5))))-(((b_v_zki)*((10)))));
		/* line 2910 */
b_L2910: ;
		if(-((b_v_yi) < ((19)))){
			goto b_return;
		}
		/* line 2911 */
b_L2911: ;
		if(-((b_v_yi) > ((20)))){
			goto b_return;
		}
		/* line 2912 */
b_L2912: ;
		b_v_bii=((((((b_v_zki)*((6))))+(((((b_v_yi)-((19))))*((3))))))+(b_v_cli));
		/* line 2913 */
b_L2913: ;
		if(-((b_a_bui[B_INT(b_v_bii)]) > ((0)))){
			b_v_hki=(1);
		}
		/* line 2914 */
b_L2914: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3001 */
b_L3001: ;
		b_v_ii=(0);
		if(b_v_ii > 23) goto b_f22_e;
b_f22_t: ;
		/* line 3002 */
b_L3002: ;
		b_v_bbi=b_int(((breal_t)(b_v_ii)/(breal_t)((6))));
		b_v_jji=((b_v_ii)-(((b_v_bbi)*((6)))));
		b_v_rrf=b_int(((breal_t)(b_v_jji)/(breal_t)((3))));
		b_v_ccf=((b_v_jji)-(((b_v_rrf)*((3)))));
		/* line 3003 */
b_L3003: ;
		b_v_xxf=(((((5))+(((b_v_bbi)*((10))))))+(b_v_ccf));
		b_v_yyf=(((19))+(b_v_rrf));
		/* line 3004 */
b_L3004: ;
		b_v_bhi=b_a_bui[B_INT(b_v_ii)];
		b_gosubStack[b_gosubSP++]=32; goto b_L3100;
b_ret32: ;
		/* line 3005 */
b_L3005: ;
		b_poke((((((1024))+(((b_v_yyf)*((40))))))+(b_v_xxf)),b_v_bgi);
		b_poke((((((55296.0))+(((b_v_yyf)*((40))))))+(b_v_xxf)),(5));
		/* line 3006 */
b_L3006: ;
		b_v_ii += 1;
		if(b_v_ii <= 23) goto b_f22_t;
b_f22_e: ;
		/* line 3007 */
b_L3007: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3101 */
b_L3101: ;
		b_v_bgi=(32);
		/* line 3102 */
b_L3102: ;
		if(-((b_v_bhi) == ((9)))){
			b_v_bgi=(160);
		}
		/* line 3103 */
b_L3103: ;
		if(-((b_v_bhi) == ((8)))){
			b_v_bgi=(102);
		}
		/* line 3104 */
b_L3104: ;
		if(-((b_v_bhi) == ((7)))){
			b_v_bgi=(127);
		}
		/* line 3105 */
b_L3105: ;
		if(-((b_v_bhi) == ((6)))){
			b_v_bgi=(126);
		}
		/* line 3106 */
b_L3106: ;
		if(-((b_v_bhi) == ((5)))){
			b_v_bgi=(124);
		}
		/* line 3107 */
b_L3107: ;
		if(-((b_v_bhi) == ((4)))){
			b_v_bgi=(97);
		}
		/* line 3108 */
b_L3108: ;
		if(-((b_v_bhi) == ((3)))){
			b_v_bgi=(98);
		}
		/* line 3109 */
b_L3109: ;
		if(-((b_v_bhi) == ((2)))){
			b_v_bgi=(104);
		}
		/* line 3110 */
b_L3110: ;
		if(-((b_v_bhi) == ((1)))){
			b_v_bgi=(92);
		}
		/* line 3111 */
b_L3111: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3201 */
b_L3201: ;
		b_v_ri=(0);
		if(b_v_ri > 4) goto b_f23_e;
		b_v_M6=(((((1024))+(((b_v_ayi)*((40))))))+(b_v_axi));
		b_v_M7=(((((1024))+(((b_v_oyi)*((40))))))+(b_v_oxi));
b_f23_t: ;
		/* line 3202 */
b_L3202: ;
		b_v_rbi=((b_v_ri)*((40)));
		b_v_sbi=((b_v_M6)+(b_v_rbi));
		b_v_dbi=((b_v_M7)+(b_v_rbi));
		/* line 3203 */
b_L3203: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f24_e;
		b_v_M1=((b_v_ri)*((11)));
		b_v_M2=b_a_agi[B_INT(b_v_ri)];
		b_v_M3=((b_v_oyi)+(b_v_ri));
		b_v_M4=((b_v_oyi)*((40)));
		b_v_M5=b_a_aci[B_INT(b_v_ri)];
		b_t_18=((b_v_sbi)+(((b_v_ci)*((2)))));
		b_t_19=((b_v_dbi)+(((b_v_ci)*((2)))));
		b_t_20=(((((((((55296.0))+(b_v_M4)))+(b_v_oxi)))+(b_v_rbi)))+(((b_v_ci)*((2)))));
b_f24_t: ;
		/* line 3204 */
b_L3204: ;
		if(-((b_a_ali[B_INT(((b_v_M1)+(b_v_ci)))]) == ((0)))){ goto b_L3207; }
		/* line 3205 */
b_L3205: ;
		b_poke(b_t_18,b_v_spi);
		/* line 3206 */
b_L3206: ;
		b_poke(b_t_19,b_v_M2);
		if(-((b_v_M3) < ((19)))){
			b_poke(b_t_20,b_v_M5);
		}
		/* line 3207 */
b_L3207: ;
		b_t_18 += 2;
		b_t_19 += 2;
		b_t_20 += 2;
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f24_t;
b_f24_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 4) goto b_f23_t;
b_f23_e: ;
		/* line 3208 */
b_L3208: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		/* line 3301 */
b_L3301: ;
		b_v_ri=(0);
		if(b_v_ri > 4) goto b_f25_e;
b_f25_t: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f26_e;
		b_v_M8=((b_v_ri)*((11)));
		b_v_M9=(((((1024))+(((((b_v_oyi)+(b_v_ri)))*((40))))))+(b_v_oxi));
		b_v_M10=b_a_agi[B_INT(b_v_ri)];
		b_v_M11=((((b_v_oyi)+(b_v_ri)))*((40)));
		b_v_M12=b_a_aci[B_INT(b_v_ri)];
		b_t_21=((b_v_M9)+(((b_v_ci)*((2)))));
		b_t_22=(((((((55296.0))+(b_v_M11)))+(b_v_oxi)))+(((b_v_ci)*((2)))));
b_f26_t: ;
		/* line 3302 */
b_L3302: ;
		if(-((b_a_ali[B_INT(((b_v_M8)+(b_v_ci)))]) == ((1)))){
			b_poke(b_t_21,b_v_M10);
		}
		/* line 3303 */
b_L3303: ;
		if(-((b_a_ali[B_INT(((b_v_M8)+(b_v_ci)))]) == ((1)))){
			b_poke(b_t_22,b_v_M12);
		}
		/* line 3304 */
b_L3304: ;
		b_t_21 += 2;
		b_t_22 += 2;
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f26_t;
b_f26_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 4) goto b_f25_t;
b_f25_e: ;
		/* line 3305 */
b_L3305: ;
		goto b_return;
		/* line 3400 */
b_L3400: ;
		/* line 3401 */
b_L3401: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f27_e;
		b_t_23=(((1024))+(b_v_ci));
		b_t_24=(((55296.0))+(b_v_ci));
b_f27_t: ;
		b_poke(b_t_23,b_v_spi);
		b_poke(b_t_24,(0));
		b_t_23 += 1;
		b_t_24 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f27_t;
b_f27_e: ;
		/* line 3402 */
b_L3402: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f28_e;
b_f28_t: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f29_e;
		b_v_M13=(((1024))+(((b_v_ri)*((40)))));
		b_v_M14=((b_v_ri)*((40)));
		b_t_25=((b_v_M13)+(b_v_ci));
		b_t_26=(((((55296.0))+(b_v_M14)))+(b_v_ci));
b_f29_t: ;
		b_poke(b_t_25,b_v_spi);
		b_poke(b_t_26,(14));
		b_t_25 += 1;
		b_t_26 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f29_t;
b_f29_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f28_t;
b_f28_e: ;
		/* line 3403 */
b_L3403: ;
		b_poke((1024),(19));
		b_poke((1025),(3));
		b_poke((1026),(15));
		b_poke((1027),(18));
		b_poke((1028),(5));
		/* line 3404 */
b_L3404: ;
		b_poke((55296.0),(7));
		b_poke((((55296.0))+((1))),(7));
		b_poke((((55296.0))+((2))),(7));
		b_poke((((55296.0))+((3))),(7));
		b_poke((((55296.0))+((4))),(7));
		/* line 3405 */
b_L3405: ;
		b_poke((1030),(48));
		b_poke((1031),(48));
		b_poke((1032),(48));
		b_poke((1033),(48));
		b_poke((1034),(48));
		/* line 3406 */
b_L3406: ;
		b_poke((((55296.0))+((6))),(1));
		b_poke((((55296.0))+((7))),(1));
		b_poke((((55296.0))+((8))),(1));
		b_poke((((55296.0))+((9))),(1));
		b_poke((((55296.0))+((10))),(1));
		/* line 3407 */
b_L3407: ;
		b_poke((1036),(12));
		b_poke((1037),(9));
		b_poke((1038),(22));
		b_poke((1039),(5));
		b_poke((1040),(19));
		/* line 3408 */
b_L3408: ;
		b_poke((((55296.0))+((12))),(10));
		b_poke((((55296.0))+((13))),(10));
		b_poke((((55296.0))+((14))),(10));
		b_poke((((55296.0))+((15))),(10));
		b_poke((((55296.0))+((16))),(10));
		/* line 3409 */
b_L3409: ;
		b_poke((1042),(((48))+(b_v_lvi)));
		b_poke((((55296.0))+((18))),(1));
		/* line 3410 */
b_L3410: ;
		b_poke((1044),(23));
		b_poke((1045),(1));
		b_poke((1046),(22));
		b_poke((1047),(5));
		/* line 3411 */
b_L3411: ;
		b_poke((((55296.0))+((20))),(13));
		b_poke((((55296.0))+((21))),(13));
		b_poke((((55296.0))+((22))),(13));
		b_poke((((55296.0))+((23))),(13));
		/* line 3412 */
b_L3412: ;
		b_poke((1050),(((48))+(b_int(((breal_t)(b_v_wvi)/(breal_t)((10)))))));
		b_poke((1051),(((((48))+(b_v_wvi)))-((((10))*(b_int(((breal_t)(b_v_wvi)/(breal_t)((10)))))))));
		b_poke((((55296.0))+((26))),(1));
		b_poke((((55296.0))+((27))),(1));
		/* line 3413 */
b_L3413: ;
		b_gosubStack[b_gosubSP++]=33; goto b_L3000;
b_ret33: ;
		/* line 3414 */
b_L3414: ;
		goto b_return;
		/* line 3500 */
b_L3500: ;
		/* line 3501 */
b_L3501: ;
		b_a_agi[B_INT((0))]=(226);
		b_a_agi[B_INT((1))]=(251);
		b_a_agi[B_INT((2))]=(236);
		b_a_agi[B_INT((3))]=(98);
		b_a_agi[B_INT((4))]=(254);
		/* line 3502 */
b_L3502: ;
		b_a_aci[B_INT((0))]=(7);
		b_a_aci[B_INT((1))]=(3);
		b_a_aci[B_INT((2))]=(2);
		b_a_aci[B_INT((3))]=(6);
		b_a_aci[B_INT((4))]=(4);
		/* line 3503 */
b_L3503: ;
		b_v_ii=(0);
		if(b_v_ii > 23) goto b_f30_e;
b_f30_t: ;
		b_a_bui[B_INT(b_v_ii)]=(9);
		b_v_ii += 1;
		if(b_v_ii <= 23) goto b_f30_t;
b_f30_e: ;
		/* line 3504 */
b_L3504: ;
		b_v_kls=b_keep(b_lit("\235",1));
		b_v_krs=b_keep(b_lit("\035",1));
		/* line 3505 */
b_L3505: ;
		b_v_dfi=(0);
		b_v_bpf=(0.04499999999825377);
		/* line 3506 */
b_L3506: ;
		goto b_return;
		/* line 3600 */
b_L3600: ;
		/* line 3601 */
b_L3601: ;
		b_v_oxi=(10);
		b_v_oyi=(2);
		b_v_dii=(1);
		b_v_adi=(55);
		b_v_tci=(0);
		b_v_mvi=(13);
		if(-((b_v_dfi) == ((1)))){
			b_v_mvi=(32);
		}
		/* line 3602 */
b_L3602: ;
		b_v_aii=(1);
		if(-((b_v_dmi) == ((1)))){
			b_v_mvi=((b_v_mvi)+((10)));
		}
		/* line 3603 */
b_L3603: ;
		b_v_ii=(0);
		if(b_v_ii > 23) goto b_f31_e;
b_f31_t: ;
		b_a_bui[B_INT(b_v_ii)]=(9);
		b_v_ii += 1;
		if(b_v_ii <= 23) goto b_f31_t;
b_f31_e: ;
		/* line 3604 */
b_L3604: ;
		b_v_ii=(0);
		if(b_v_ii > 54) goto b_f32_e;
b_f32_t: ;
		b_a_ali[B_INT(b_v_ii)]=(1);
		b_v_ii += 1;
		if(b_v_ii <= 54) goto b_f32_t;
b_f32_e: ;
		/* line 3605 */
b_L3605: ;
		b_v_ci=(0);
		if(b_v_ci > 10) goto b_f33_e;
b_f33_t: ;
		b_a_cci[B_INT(b_v_ci)]=(5);
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f33_t;
b_f33_e: ;
		b_v_mni=(0);
		b_v_mxi=(10);
		/* line 3606 */
b_L3606: ;
		b_gosubStack[b_gosubSP++]=34; goto b_L3000;
b_ret34: ;
		/* line 3607 */
b_L3607: ;
		goto b_return;
		/* line 3700 */
b_L3700: ;
		/* line 3701 */
b_L3701: ;
		b_putc(147);
		b_nl();
		/* line 3702 */
b_L3702: ;
		b_nl();
		{ bstr_t _t=b_lit("   *** GAME OVER ***",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3703 */
b_L3703: ;
		b_nl();
		{ bstr_t _t=b_lit("   SCORE:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 3704 */
b_L3704: ;
		{ bstr_t _t=b_lit("   WAVE:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_wvi);
		b_nl();
		/* line 3705 */
b_L3705: ;
		b_nl();
		{ bstr_t _t=b_lit("   PRESS R TO RESTART, Q TO QUIT",32); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3706 */
b_L3706: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_ji=(1);
			if(b_v_ji > 120) goto b_f34_e;
b_f34_t: ;
			b_wait((53265.0),(128),0);
			b_v_ji += 1;
			if(b_v_ji <= 120) goto b_f34_t;
b_f34_e: ;
			goto b_L110;
		}
		/* line 3707 */
b_L3707: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L3707; }
		/* line 3708 */
b_L3708: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			b_v_dmi=(1);
			goto b_L110;
		}
		/* line 3709 */
b_L3709: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			goto b_L3800;
		}
		/* line 3710 */
b_L3710: ;
		goto b_L3706;
		/* line 3800 */
b_L3800: ;
		/* line 3801 */
b_L3801: ;
		b_putc(147);
		b_nl();
		b_sys((64738.0));
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
