/* OPTIMIZE_C -- wumpus.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static bint_t b_a_adi[84];
static bint_t b_a_pxi[21];
static bint_t b_a_pyi[21];
static int b_a_li[7];
static breal_t b_a_phf[6];
static bint_t b_v_cri;
static int b_v_pri;
static breal_t b_v_arf;
static breal_t b_v_wnf;
static int b_v_fli;
static bint_t b_v_aci;
static int b_v_ii;
static bint_t b_v_ji;
static int b_v_dpi;
static int b_v_ki;
static bint_t b_v_ni;
static bint_t b_v_x1i;
static bint_t b_v_y1i;
static bint_t b_v_x2i;
static bint_t b_v_y2i;
static bint_t b_v_dxi;
static bint_t b_v_dyi;
static int b_v_sxi;
static int b_v_syi;
static bint_t b_v_eri;
static bint_t b_v_sti;
static bint_t b_v_cai;
static int b_v_wui;
static int b_v_dri;
static int b_v_bti;
static bint_t b_v_ri;
static breal_t b_v_hrf;
static bint_t b_v_sai;
static bint_t b_v_txi;
static int b_v_tyi;
static bstr_t b_v_ts;
static breal_t b_v_vf;
static int b_v_wli;
static bint_t b_v_bci;
static bint_t b_v_nhi;
static int b_v_bdi;
static int b_v_qi;
static bint_t b_v_d1i;
static breal_t b_v_d2f;
static int b_v_svi;
static int b_v_sci;
static int b_v_fai;
static bstr_t b_v_mss;
static bint_t b_v_pci;
static breal_t b_v_axf;
static bint_t b_v_shi;
static breal_t b_v_nrf;
static breal_t b_v_rrf;
static int b_v_iyi;
static int b_v_M0;
static bint_t b_v_M1;
static bint_t b_v_M2;
static bint_t b_v_M3;
static bint_t b_v_M4;
static int b_v_M5;
static int b_v_M6;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_fl_9;
static bint_t b_fl_10;
static bint_t b_fl_19;
static int b_fl_20;
static bint_t b_fl_21;
static bint_t b_fl_22;
static int b_fl_24;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,2,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,1,0,0},{1,0,3,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,4,0,0},{1,0,12,0,0},{1,0,3,0,0},{1,0,5,0,0},{1,0,14,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,6,0,0},{1,0,5,0,0},{1,0,7,0,0},{1,0,15,0,0},{1,0,6,0,0},{1,0,8,0,0},{1,0,17,0,0},{1,0,1,0,0},{1,0,7,0,0},{1,0,9,0,0},{1,0,8,0,0},{1,0,10,0,0},{1,0,18,0,0},{1,0,2,0,0},{1,0,9,0,0},{1,0,11,0,0},{1,0,10,0,0},{1,0,12,0,0},{1,0,19,0,0},{1,0,3,0,0},{1,0,11,0,0},{1,0,13,0,0},{1,0,12,0,0},{1,0,14,0,0},{1,0,20,0,0},{1,0,4,0,0},{1,0,13,0,0},{1,0,15,0,0},{1,0,6,0,0},{1,0,14,0,0},{1,0,16,0,0},{1,0,15,0,0},{1,0,17,0,0},{1,0,20,0,0},{1,0,7,0,0},{1,0,16,0,0},{1,0,18,0,0},{1,0,9,0,0},{1,0,17,0,0},{1,0,19,0,0},{1,0,11,0,0},{1,0,18,0,0},{1,0,20,0,0},{1,0,13,0,0},{1,0,16,0,0},{1,0,19,0,0},{1,0,35,0,0},{1,0,11,0,0},{1,0,34,0,0},{1,0,13,0,0},{1,0,20,0,0},{1,0,19,0,0},{1,0,15,0,0},{1,0,19,0,0},{1,0,34,0,0},{1,0,9,0,0},{1,0,32,0,0},{1,0,6,0,0},{1,0,15,0,0},{1,0,3,0,0},{1,0,11,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,6,0,0},{1,0,32,0,0},{1,0,16,0,0},{1,0,29,0,0},{1,0,17,0,0},{1,0,25,0,0},{1,0,19,0,0},{1,0,8,0,0},{1,0,16,0,0},{1,0,11,0,0},{1,0,17,0,0},{1,0,29,0,0},{1,0,5,0,0},{1,0,25,0,0},{1,0,3,0,0},{1,0,20,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,9,0,0},{1,0,5,0,0},{1,0,11,0,0},{1,0,6,0,0},{1,0,13,0,0}};
int b_data_len = 100;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		b_putc(147);
		b_nl();
		/* line 50 */
b_L50: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1000;
b_ret0: ;
		/* line 80 */
b_L80: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L1100;
b_ret1: ;
		/* line 90 */
b_L90: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L1200;
b_ret2: ;
		/* line 100 */
b_L100: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1300;
b_ret3: ;
		/* line 110 */
b_L110: ;
		b_v_cri=b_a_li[B_INT((1))];
		b_v_pri=(0);
		b_v_arf=(5);
		b_v_wnf=(0);
		b_v_fli=(0);
		/* line 120 */
b_L120: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1800;
b_ret4: ;
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1900;
b_ret5: ;
		/* line 140 */
b_L140: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L2400;
b_ret6: ;
		/* line 150 */
b_L150: ;
		if(-((b_v_aci) == ((7)))){
			b_poke((198),(0));
			goto b_end;
		}
		/* line 160 */
b_L160: ;
		if(-((b_v_aci) == ((9)))){
			b_gosubStack[b_gosubSP++]=7; goto b_L3600;
b_ret7: ;
			goto b_L180;
		}
		/* line 170 */
b_L170: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L2800;
b_ret8: ;
		/* line 180 */
b_L180: ;
		if(-((b_v_fli) > ((0)))){
			b_gosubStack[b_gosubSP++]=9; goto b_L4000;
b_ret9: ;
			goto b_L110;
		}
		/* line 190 */
b_L190: ;
		if(-((b_v_fli) < ((0)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L4100;
b_ret10: ;
			goto b_L110;
		}
		/* line 200 */
b_L200: ;
		goto b_L120;
		/* line 210 */
b_L210: ;
		goto b_end;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_ii=(1);
		if(b_v_ii > 20) goto b_f0_e;
b_f0_t: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f1_e;
b_f1_t: ;
		b_a_adi[(B_INT(b_v_ii))*4+(B_INT(b_v_ji))]=b_read_int();
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f1_t;
b_f1_e: ;
		b_v_ii += 1;
		if(b_v_ii <= 20) goto b_f0_t;
b_f0_e: ;
		/* line 1002 */
b_L1002: ;
		goto b_return;
		/* line 1003 */
b_L1003: ;
		/* line 1004 */
b_L1004: ;
		/* line 1005 */
b_L1005: ;
		/* line 1006 */
b_L1006: ;
		/* line 1007 */
b_L1007: ;
		/* line 1008 */
b_L1008: ;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_ii=(1);
		if(b_v_ii > 20) goto b_f2_e;
b_f2_t: ;
		b_a_pxi[B_INT(b_v_ii)]=b_read_int();
		b_a_pyi[B_INT(b_v_ii)]=b_read_int();
		b_v_ii += 1;
		if(b_v_ii <= 20) goto b_f2_t;
b_f2_e: ;
		/* line 1102 */
b_L1102: ;
		goto b_return;
		/* line 1103 */
b_L1103: ;
		/* line 1104 */
b_L1104: ;
		/* line 1105 */
b_L1105: ;
		/* line 1106 */
b_L1106: ;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_dpi=(1);
		/* line 1202 */
b_L1202: ;
		b_v_ji=(1);
		if(b_v_ji > 6) goto b_f3_e;
b_f3_t: ;
		b_a_li[B_INT(b_v_ji)]=((b_int(((b_rnd(B_INT((1))))*((20)))))+((1)));
		b_v_ji += 1;
		if(b_v_ji <= 6) goto b_f3_t;
b_f3_e: ;
		/* line 1203 */
b_L1203: ;
		b_v_ji=(1);
		if(b_v_ji > 5) goto b_f4_e;
b_f4_t: ;
		b_v_ki=((b_v_ji)+((1)));
		if(b_v_ki > 6) goto b_f5_e;
		b_v_M0=b_a_li[B_INT(b_v_ji)];
b_f5_t: ;
		if(-((b_v_M0) == (b_a_li[B_INT(b_v_ki)]))){
			b_v_dpi=(0);
		}
		/* line 1204 */
b_L1204: ;
		b_v_ki += 1;
		if(b_v_ki <= 6) goto b_f5_t;
b_f5_e: ;
		b_v_ji += 1;
		if(b_v_ji <= 5) goto b_f4_t;
b_f4_e: ;
		/* line 1205 */
b_L1205: ;
		if(-((b_v_dpi) == ((0)))){ goto b_L1201; }
		/* line 1206 */
b_L1206: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_putc(147);
		b_nl();
		/* line 1302 */
b_L1302: ;
		b_v_ii=(1);
		if(b_v_ii > 20) goto b_f6_e;
b_f6_t: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f7_e;
b_f7_t: ;
		b_v_ni=b_a_adi[(B_INT(b_v_ii))*4+(B_INT(b_v_ji))];
		/* line 1303 */
b_L1303: ;
		if(-((b_v_ni) > (b_v_ii))){
			b_gosubStack[b_gosubSP++]=11; goto b_L1400;
b_ret11: ;
		}
		/* line 1304 */
b_L1304: ;
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f7_t;
b_f7_e: ;
		b_v_ii += 1;
		if(b_v_ii <= 20) goto b_f6_t;
b_f6_e: ;
		/* line 1305 */
b_L1305: ;
		b_v_ii=(1);
		if(b_v_ii > 20) goto b_f8_e;
b_f8_t: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1700;
b_ret12: ;
		b_v_ii += 1;
		if(b_v_ii <= 20) goto b_f8_t;
b_f8_e: ;
		/* line 1306 */
b_L1306: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_v_x1i=b_a_pxi[B_INT(b_v_ii)];
		b_v_y1i=b_a_pyi[B_INT(b_v_ii)];
		b_v_x2i=b_a_pxi[B_INT(b_v_ni)];
		b_v_y2i=b_a_pyi[B_INT(b_v_ni)];
		/* line 1402 */
b_L1402: ;
		b_v_dxi=b_abs((breal_t)(((b_v_x2i)-(b_v_x1i))));
		b_v_dyi=b_abs((breal_t)(((b_v_y2i)-(b_v_y1i))));
		/* line 1403 */
b_L1403: ;
		b_v_sxi=(0);
		if(-((b_v_x1i) < (b_v_x2i))){
			b_v_sxi=(1);
		}
		/* line 1404 */
b_L1404: ;
		if(-((b_v_x1i) > (b_v_x2i))){
			b_v_sxi=(-1);
		}
		/* line 1405 */
b_L1405: ;
		b_v_syi=(0);
		if(-((b_v_y1i) < (b_v_y2i))){
			b_v_syi=(1);
		}
		/* line 1406 */
b_L1406: ;
		if(-((b_v_y1i) > (b_v_y2i))){
			b_v_syi=(-1);
		}
		/* line 1407 */
b_L1407: ;
		if(-((b_v_dxi) >= (b_v_dyi))){
			b_gosubStack[b_gosubSP++]=13; goto b_L1500;
b_ret13: ;
		}
		else{
			b_gosubStack[b_gosubSP++]=14; goto b_L1600;
b_ret14: ;
		}
		/* line 1408 */
b_L1408: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_eri=(((((2))*(b_v_dyi)))-(b_v_dxi));
		/* line 1502 */
b_L1502: ;
		b_v_sti=(0);
		b_fl_9=b_v_dxi;
		if(b_v_sti > b_fl_9) goto b_f9_e;
		b_v_M1=(((2))*(b_v_dxi));
		b_v_M2=(((2))*(b_v_dyi));
b_f9_t: ;
		/* line 1503 */
b_L1503: ;
		if(-((b_v_sti) != ((0)))){
			if(-((b_v_sti) != (b_v_dxi))){
				b_v_cai=(((((1024))+(((b_v_y1i)*((40))))))+(b_v_x1i));
				b_poke(b_v_cai,(46));
				b_poke((((((55296.0))+(((b_v_y1i)*((40))))))+(b_v_x1i)),(12));
			}
		}
		/* line 1504 */
b_L1504: ;
		b_v_x1i=((b_v_x1i)+(b_v_sxi));
		/* line 1505 */
b_L1505: ;
		if(-((b_v_eri) >= ((0)))){
			b_v_y1i=((b_v_y1i)+(b_v_syi));
			b_v_eri=((b_v_eri)-(b_v_M1));
		}
		/* line 1506 */
b_L1506: ;
		b_v_eri=((b_v_eri)+(b_v_M2));
		/* line 1507 */
b_L1507: ;
		b_v_sti += 1;
		if(b_v_sti <= (b_fl_9)) goto b_f9_t;
b_f9_e: ;
		/* line 1508 */
b_L1508: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		b_v_eri=(((((2))*(b_v_dxi)))-(b_v_dyi));
		/* line 1602 */
b_L1602: ;
		b_v_sti=(0);
		b_fl_10=b_v_dyi;
		if(b_v_sti > b_fl_10) goto b_f10_e;
		b_v_M3=(((2))*(b_v_dyi));
		b_v_M4=(((2))*(b_v_dxi));
b_f10_t: ;
		/* line 1603 */
b_L1603: ;
		if(-((b_v_sti) != ((0)))){
			if(-((b_v_sti) != (b_v_dyi))){
				b_v_cai=(((((1024))+(((b_v_y1i)*((40))))))+(b_v_x1i));
				b_poke(b_v_cai,(46));
				b_poke((((((55296.0))+(((b_v_y1i)*((40))))))+(b_v_x1i)),(12));
			}
		}
		/* line 1604 */
b_L1604: ;
		b_v_y1i=((b_v_y1i)+(b_v_syi));
		/* line 1605 */
b_L1605: ;
		if(-((b_v_eri) >= ((0)))){
			b_v_x1i=((b_v_x1i)+(b_v_sxi));
			b_v_eri=((b_v_eri)-(b_v_M3));
		}
		/* line 1606 */
b_L1606: ;
		b_v_eri=((b_v_eri)+(b_v_M4));
		/* line 1607 */
b_L1607: ;
		b_v_sti += 1;
		if(b_v_sti <= (b_fl_10)) goto b_f10_t;
b_f10_e: ;
		/* line 1608 */
b_L1608: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_cai=(((((1024))+(((b_a_pyi[B_INT(b_v_ii)])*((40))))))+(b_a_pxi[B_INT(b_v_ii)]));
		b_poke(b_v_cai,(81));
		b_poke((((((55296.0))+(((b_a_pyi[B_INT(b_v_ii)])*((40))))))+(b_a_pxi[B_INT(b_v_ii)])),(14));
		/* line 1702 */
b_L1702: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_wui=(0);
		b_v_dri=(0);
		b_v_bti=(0);
		/* line 1802 */
b_L1802: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f11_e;
		b_v_M5=b_a_li[B_INT((2))];
b_f11_t: ;
		b_v_ri=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_ji))];
		/* line 1803 */
b_L1803: ;
		if(-((b_v_ri) == (b_v_M5))){
			b_v_wui=(1);
		}
		/* line 1804 */
b_L1804: ;
		if(-((b_v_ri) == (b_v_M5))){
			b_v_dri=(1);
		}
		/* line 1805 */
b_L1805: ;
		if(-((b_v_ri) == (b_v_M5))){
			b_v_dri=(1);
		}
		/* line 1806 */
b_L1806: ;
		if(-((b_v_ri) == (b_v_M5))){
			b_v_bti=(1);
		}
		/* line 1807 */
b_L1807: ;
		if(-((b_v_ri) == (b_v_M5))){
			b_v_bti=(1);
		}
		/* line 1808 */
b_L1808: ;
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f11_t;
b_f11_e: ;
		/* line 1809 */
b_L1809: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		if(-((b_v_pri) != ((0)))){
			b_v_hrf=b_v_pri;
			b_gosubStack[b_gosubSP++]=15; goto b_L2000;
b_ret15: ;
		}
		/* line 1902 */
b_L1902: ;
		b_v_hrf=b_v_cri;
		b_gosubStack[b_gosubSP++]=16; goto b_L2100;
b_ret16: ;
		/* line 1903 */
b_L1903: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L2200;
b_ret17: ;
		/* line 1904 */
b_L1904: ;
		b_gosubStack[b_gosubSP++]=18; goto b_L2300;
b_ret18: ;
		/* line 1905 */
b_L1905: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_poke((((((1024))+(((b_a_pyi[(bint_t)(b_v_hrf)])*((40))))))+(b_a_pxi[(bint_t)(b_v_hrf)])),(81));
		b_poke((((((55296.0))+(((b_a_pyi[(bint_t)(b_v_hrf)])*((40))))))+(b_a_pxi[(bint_t)(b_v_hrf)])),(14));
		/* line 2002 */
b_L2002: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f12_e;
b_f12_t: ;
		b_v_ri=b_a_adi[((bint_t)(b_v_hrf))*4+(B_INT(b_v_ji))];
		b_poke((((((1024))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(81));
		b_poke((((((55296.0))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(14));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f12_t;
b_f12_e: ;
		/* line 2003 */
b_L2003: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_poke((((((1024))+(((b_a_pyi[(bint_t)(b_v_hrf)])*((40))))))+(b_a_pxi[(bint_t)(b_v_hrf)])),(87));
		b_poke((((((55296.0))+(((b_a_pyi[(bint_t)(b_v_hrf)])*((40))))))+(b_a_pxi[(bint_t)(b_v_hrf)])),(1));
		/* line 2102 */
b_L2102: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f13_e;
b_f13_t: ;
		b_v_ri=b_a_adi[((bint_t)(b_v_hrf))*4+(B_INT(b_v_ji))];
		b_poke((((((1024))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(81));
		b_poke((((((55296.0))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(5));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f13_t;
b_f13_e: ;
		/* line 2103 */
b_L2103: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_v_sai=(1944);
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f14_e;
		b_t_2=((b_v_sai)+(b_v_ii));
		b_t_3=(((((55296.0))+((920))))+(b_v_ii));
b_f14_t: ;
		b_poke(b_t_2,(32));
		b_poke(b_t_3,(14));
		b_t_2 += 1;
		b_t_3 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f14_t;
b_f14_e: ;
		/* line 2202 */
b_L2202: ;
		b_v_txi=(1);
		b_v_tyi=(23);
		b_v_ts=b_keep(b_lit("ROOM",4));
		b_gosubStack[b_gosubSP++]=19; goto b_L2600;
b_ret19: ;
		b_v_txi=(6);
		b_v_vf=b_v_cri;
		b_gosubStack[b_gosubSP++]=20; goto b_L2700;
b_ret20: ;
		/* line 2203 */
b_L2203: ;
		b_v_txi=(10);
		b_v_ts=b_keep(b_lit("TUNNELS",7));
		b_gosubStack[b_gosubSP++]=21; goto b_L2600;
b_ret21: ;
		/* line 2204 */
b_L2204: ;
		b_v_txi=(19);
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f15_e;
b_f15_t: ;
		b_v_vf=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_ji))];
		b_gosubStack[b_gosubSP++]=22; goto b_L2700;
b_ret22: ;
		b_v_txi=((b_v_txi)+((3)));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f15_t;
b_f15_e: ;
		/* line 2205 */
b_L2205: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		b_v_sai=(1984);
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f16_e;
		b_t_4=((b_v_sai)+(b_v_ii));
		b_t_5=(((((55296.0))+((960))))+(b_v_ii));
b_f16_t: ;
		b_poke(b_t_4,(32));
		b_poke(b_t_5,(14));
		b_t_4 += 1;
		b_t_5 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f16_t;
b_f16_e: ;
		/* line 2302 */
b_L2302: ;
		b_v_txi=(1);
		b_v_tyi=(24);
		b_v_ts=b_keep(b_lit("ARROWS",6));
		b_gosubStack[b_gosubSP++]=23; goto b_L2600;
b_ret23: ;
		b_v_txi=(8);
		b_v_vf=b_v_arf;
		b_gosubStack[b_gosubSP++]=24; goto b_L2700;
b_ret24: ;
		/* line 2303 */
b_L2303: ;
		b_v_txi=(11);
		b_v_ts=b_keep(b_lit("WINS",4));
		b_gosubStack[b_gosubSP++]=25; goto b_L2600;
b_ret25: ;
		b_v_txi=(16);
		b_v_vf=b_v_wnf;
		b_gosubStack[b_gosubSP++]=26; goto b_L2700;
b_ret26: ;
		/* line 2304 */
b_L2304: ;
		b_v_txi=(19);
		b_v_ts=b_keep(b_lit("",0));
		/* line 2305 */
b_L2305: ;
		if(-((b_v_wui) == ((1)))){
			b_v_ts=b_keep(b_lit("SMELL WUMPUS",12));
		}
		/* line 2306 */
b_L2306: ;
		if(-((b_v_wui) == ((0)))){
			if(-((b_v_dri) == ((1)))){
				b_v_ts=b_keep(b_lit("FEEL DRAFT",10));
			}
		}
		/* line 2307 */
b_L2307: ;
		if(-((b_v_wui) == ((0)))){
			if(-((b_v_dri) == ((0)))){
				if(-((b_v_bti) == ((1)))){
					b_v_ts=b_keep(b_lit("HEAR BATS",9));
				}
			}
		}
		/* line 2308 */
b_L2308: ;
		b_v_txi=(19);
		b_v_tyi=(24);
		b_gosubStack[b_gosubSP++]=27; goto b_L2600;
b_ret27: ;
		/* line 2309 */
b_L2309: ;
		b_v_wli=B_INT(b_len(b_v_ts));
		/* line 2310 */
b_L2310: ;
		b_v_txi=(31);
		b_v_ts=b_keep(b_lit("1/2/3 S Q",9));
		b_gosubStack[b_gosubSP++]=28; goto b_L2600;
b_ret28: ;
		/* line 2311 */
b_L2311: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_v_aci=(0);
		/* line 2402 */
b_L2402: ;
		b_wait((53265.0),(128),0);
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 2403 */
b_L2403: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L2500;
b_ret29: ;
		/* line 2404 */
b_L2404: ;
		if(-((b_v_ki) == ((56)))){
			b_v_aci=(1);
			goto b_L2410;
		}
		/* line 2405 */
b_L2405: ;
		if(-((b_v_ki) == ((59)))){
			b_v_aci=(2);
			goto b_L2410;
		}
		/* line 2406 */
b_L2406: ;
		if(-((b_v_ki) == ((8)))){
			b_v_aci=(3);
			goto b_L2410;
		}
		/* line 2407 */
b_L2407: ;
		if(-((b_v_ki) == ((13)))){
			b_v_aci=(9);
			goto b_L2410;
		}
		/* line 2408 */
b_L2408: ;
		if(-((b_v_ki) == ((62)))){
			b_v_aci=(7);
			goto b_L2410;
		}
		/* line 2409 */
b_L2409: ;
		goto b_L2402;
		/* line 2410 */
b_L2410: ;
		b_poke((((((55296.0))+(((b_a_pyi[B_INT(b_v_cri)])*((40))))))+(b_a_pxi[B_INT(b_v_cri)])),(1));
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f17_e;
b_f17_t: ;
		b_v_ri=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_ji))];
		b_poke((((((1024))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(81));
		b_poke((((((55296.0))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)])),(5));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f17_t;
b_f17_e: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		b_v_bci=((b_v_bci)+((1)));
		if(-((b_v_bci) >= ((45)))){
			b_v_bci=(0);
		}
		/* line 2502 */
b_L2502: ;
		b_v_nhi=((b_int(((breal_t)(b_v_bci)/(breal_t)((15)))))+((1)));
		/* line 2503 */
b_L2503: ;
		b_v_sai=(((((55296.0))+(((b_a_pyi[B_INT(b_v_cri)])*((40))))))+(b_a_pxi[B_INT(b_v_cri)]));
		b_poke(b_v_sai,(1));
		if(-((b_v_wui) == ((1)))){
			b_poke(b_v_sai,(2));
			goto b_L2505;
		}
		/* line 2504 */
b_L2504: ;
		if(-((b_v_bci) >= ((22)))){
			b_poke(b_v_sai,(7));
		}
		/* line 2505 */
b_L2505: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f18_e;
b_f18_t: ;
		b_v_ri=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_ji))];
		b_v_sai=(((((1024))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)]));
		b_poke(b_v_sai,(81));
		b_poke(((b_v_sai)+((54272.0))),(5));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f18_t;
b_f18_e: ;
		/* line 2506 */
b_L2506: ;
		b_v_ri=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_nhi))];
		b_v_sai=(((((1024))+(((b_a_pyi[B_INT(b_v_ri)])*((40))))))+(b_a_pxi[B_INT(b_v_ri)]));
		b_poke(b_v_sai,(((48))+(b_v_nhi)));
		b_poke(((b_v_sai)+((54272.0))),(7));
		/* line 2507 */
b_L2507: ;
		if(-((b_v_wli) <= ((0)))){
			goto b_L2511;
		}
		/* line 2508 */
b_L2508: ;
		b_v_ji=(0);
		b_fl_19=((b_v_wli)-((1)));
		if(b_v_ji > b_fl_19) goto b_f19_e;
b_f19_t: ;
		b_v_sai=(((((((55296.0))+((960))))+((19))))+(b_v_ji));
		/* line 2509 */
b_L2509: ;
		b_poke(b_v_sai,(14));
		if(-((b_v_bci) >= ((22)))){
			b_poke(b_v_sai,(2));
		}
		/* line 2510 */
b_L2510: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_19)) goto b_f19_t;
b_f19_e: ;
		/* line 2511 */
b_L2511: ;
		b_v_bdi=(0);
		if(-((b_v_bti) == ((1)))){
			b_v_bdi=(4);
		}
		/* line 2512 */
b_L2512: ;
		if(-((b_v_dri) == ((1)))){
			b_v_bdi=(8);
		}
		/* line 2513 */
b_L2513: ;
		if(-((b_v_wui) == ((1)))){
			b_v_bdi=(2);
		}
		/* line 2514 */
b_L2514: ;
		if((B_INT(-((b_v_bdi) == ((0)))) | B_INT(-((b_v_bci) < ((22)))))){
			b_poke((53280.0),(0));
		}
		else{
			b_poke((53280.0),b_v_bdi);
		}
		/* line 2515 */
b_L2515: ;
		goto b_return;
		/* line 2600 */
b_L2600: ;
		/* line 2601 */
b_L2601: ;
		if(-(b_strcmp(b_v_ts,b_lit("",0)) == 0)){
			goto b_return;
		}
		/* line 2602 */
b_L2602: ;
		b_v_sai=(((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi));
		/* line 2603 */
b_L2603: ;
		b_v_ii=(1);
		b_fl_20=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_20) goto b_f20_e;
b_f20_t: ;
		/* line 2604 */
b_L2604: ;
		b_v_qi=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 2605 */
b_L2605: ;
		if(-((b_v_qi) >= ((64)))){
			if(-((b_v_qi) <= ((95)))){
				b_v_qi=((b_v_qi)-((64)));
			}
		}
		/* line 2606 */
b_L2606: ;
		b_poke(b_v_sai,b_v_qi);
		b_v_sai=((b_v_sai)+((1)));
		/* line 2607 */
b_L2607: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_20)) goto b_f20_t;
b_f20_e: ;
		/* line 2608 */
b_L2608: ;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		/* line 2701 */
b_L2701: ;
		b_v_d1i=b_int((b_v_vf/(breal_t)((10))));
		b_v_d2f=((b_v_vf)-(((b_v_d1i)*((10)))));
		/* line 2702 */
b_L2702: ;
		b_v_sai=(((((1024))+(((b_v_tyi)*((40))))))+(b_v_txi));
		b_poke(b_v_sai,(((48))+(b_v_d1i)));
		b_poke(((b_v_sai)+((1))),(((48))+(b_v_d2f)));
		/* line 2703 */
b_L2703: ;
		goto b_return;
		/* line 2800 */
b_L2800: ;
		/* line 2801 */
b_L2801: ;
		b_v_pri=b_v_cri;
		/* line 2802 */
b_L2802: ;
		b_v_cri=b_a_adi[(B_INT(b_v_cri))*4+(B_INT(b_v_aci))];
		b_a_li[B_INT((1))]=b_v_cri;
		/* line 2803 */
b_L2803: ;
		b_gosubStack[b_gosubSP++]=30; goto b_L2900;
b_ret30: ;
		/* line 2804 */
b_L2804: ;
		b_gosubStack[b_gosubSP++]=31; goto b_L3300;
b_ret31: ;
		/* line 2805 */
b_L2805: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		/* line 2901 */
b_L2901: ;
		b_v_x1i=b_a_pxi[B_INT(b_v_pri)];
		b_v_y1i=b_a_pyi[B_INT(b_v_pri)];
		b_v_x2i=b_a_pxi[B_INT(b_v_cri)];
		b_v_y2i=b_a_pyi[B_INT(b_v_cri)];
		/* line 2902 */
b_L2902: ;
		b_v_dxi=b_abs((breal_t)(((b_v_x2i)-(b_v_x1i))));
		b_v_dyi=b_abs((breal_t)(((b_v_y2i)-(b_v_y1i))));
		/* line 2903 */
b_L2903: ;
		b_v_sxi=(0);
		if(-((b_v_x1i) < (b_v_x2i))){
			b_v_sxi=(1);
		}
		/* line 2904 */
b_L2904: ;
		if(-((b_v_x1i) > (b_v_x2i))){
			b_v_sxi=(-1);
		}
		/* line 2905 */
b_L2905: ;
		b_v_syi=(0);
		if(-((b_v_y1i) < (b_v_y2i))){
			b_v_syi=(1);
		}
		/* line 2906 */
b_L2906: ;
		if(-((b_v_y1i) > (b_v_y2i))){
			b_v_syi=(-1);
		}
		/* line 2907 */
b_L2907: ;
		if(-((b_v_dxi) >= (b_v_dyi))){
			b_gosubStack[b_gosubSP++]=32; goto b_L3000;
b_ret32: ;
		}
		else{
			b_gosubStack[b_gosubSP++]=33; goto b_L3100;
b_ret33: ;
		}
		/* line 2908 */
b_L2908: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3001 */
b_L3001: ;
		b_v_eri=(((((2))*(b_v_dyi)))-(b_v_dxi));
		/* line 3002 */
b_L3002: ;
		b_v_sti=(0);
		b_fl_21=b_v_dxi;
		if(b_v_sti > b_fl_21) goto b_f21_e;
b_f21_t: ;
		/* line 3003 */
b_L3003: ;
		if(-((b_v_sti) != ((0)))){
			if(-((b_v_sti) != (b_v_dxi))){
				b_gosubStack[b_gosubSP++]=34; goto b_L3200;
b_ret34: ;
			}
		}
		/* line 3004 */
b_L3004: ;
		b_v_x1i=((b_v_x1i)+(b_v_sxi));
		/* line 3005 */
b_L3005: ;
		if(-((b_v_eri) >= ((0)))){
			b_v_y1i=((b_v_y1i)+(b_v_syi));
			b_v_eri=((b_v_eri)-((((2))*(b_v_dxi))));
		}
		/* line 3006 */
b_L3006: ;
		b_v_eri=((b_v_eri)+((((2))*(b_v_dyi))));
		/* line 3007 */
b_L3007: ;
		b_v_sti += 1;
		if(b_v_sti <= (b_fl_21)) goto b_f21_t;
b_f21_e: ;
		/* line 3008 */
b_L3008: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3101 */
b_L3101: ;
		b_v_eri=(((((2))*(b_v_dxi)))-(b_v_dyi));
		/* line 3102 */
b_L3102: ;
		b_v_sti=(0);
		b_fl_22=b_v_dyi;
		if(b_v_sti > b_fl_22) goto b_f22_e;
b_f22_t: ;
		/* line 3103 */
b_L3103: ;
		if(-((b_v_sti) != ((0)))){
			if(-((b_v_sti) != (b_v_dyi))){
				b_gosubStack[b_gosubSP++]=35; goto b_L3200;
b_ret35: ;
			}
		}
		/* line 3104 */
b_L3104: ;
		b_v_y1i=((b_v_y1i)+(b_v_syi));
		/* line 3105 */
b_L3105: ;
		if(-((b_v_eri) >= ((0)))){
			b_v_x1i=((b_v_x1i)+(b_v_sxi));
			b_v_eri=((b_v_eri)-((((2))*(b_v_dyi))));
		}
		/* line 3106 */
b_L3106: ;
		b_v_eri=((b_v_eri)+((((2))*(b_v_dxi))));
		/* line 3107 */
b_L3107: ;
		b_v_sti += 1;
		if(b_v_sti <= (b_fl_22)) goto b_f22_t;
b_f22_e: ;
		/* line 3108 */
b_L3108: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3201 */
b_L3201: ;
		b_v_cai=(((((1024))+(((b_v_y1i)*((40))))))+(b_v_x1i));
		b_v_svi=B_INT(b_peek((unsigned int)(b_v_cai)));
		b_v_sci=B_INT(b_peek((unsigned int)(((b_v_cai)+((54272.0))))));
		/* line 3202 */
b_L3202: ;
		b_poke(b_v_cai,(81));
		b_poke(((b_v_cai)+((54272.0))),(7));
		/* line 3203 */
b_L3203: ;
		b_v_fai=(1);
		if(b_v_fai > 4) goto b_f23_e;
b_f23_t: ;
		b_wait((53265.0),(128),0);
		b_v_fai += 1;
		if(b_v_fai <= 4) goto b_f23_t;
b_f23_e: ;
		/* line 3204 */
b_L3204: ;
		b_poke(b_v_cai,b_v_svi);
		b_poke(((b_v_cai)+((54272.0))),b_v_sci);
		/* line 3205 */
b_L3205: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		/* line 3301 */
b_L3301: ;
		b_v_fli=(0);
		/* line 3302 */
b_L3302: ;
		if(-((b_v_cri) == (b_a_li[B_INT((2))]))){
			b_gosubStack[b_gosubSP++]=36; goto b_L3400;
b_ret36: ;
			goto b_return;
		}
		/* line 3303 */
b_L3303: ;
		if(-((b_v_cri) == (b_a_li[B_INT((3))]))){
			b_v_mss=b_keep(b_lit("FELL IN PIT",11));
			b_v_fli=(-1);
			goto b_return;
		}
		/* line 3304 */
b_L3304: ;
		if(-((b_v_cri) == (b_a_li[B_INT((4))]))){
			b_v_mss=b_keep(b_lit("FELL IN PIT",11));
			b_v_fli=(-1);
			goto b_return;
		}
		/* line 3305 */
b_L3305: ;
		if(-((b_v_cri) == (b_a_li[B_INT((5))]))){
			b_gosubStack[b_gosubSP++]=37; goto b_L3500;
b_ret37: ;
			goto b_L3301;
		}
		/* line 3306 */
b_L3306: ;
		if(-((b_v_cri) == (b_a_li[B_INT((6))]))){
			b_gosubStack[b_gosubSP++]=38; goto b_L3500;
b_ret38: ;
			goto b_L3301;
		}
		/* line 3307 */
b_L3307: ;
		goto b_return;
		/* line 3400 */
b_L3400: ;
		/* line 3401 */
b_L3401: ;
		b_v_mss=b_keep(b_lit("WUMPUS GOT YOU",14));
		/* line 3402 */
b_L3402: ;
		b_v_ki=((b_int(((b_rnd(B_INT((1))))*((4)))))+((1)));
		/* line 3403 */
b_L3403: ;
		if(-((b_v_ki) != ((4)))){
			b_a_li[B_INT((2))]=b_a_adi[(B_INT(b_a_li[B_INT((2))]))*4+(B_INT(b_v_ki))];
		}
		/* line 3404 */
b_L3404: ;
		if(-((b_a_li[B_INT((2))]) == (b_v_cri))){
			b_v_fli=(-1);
		}
		/* line 3405 */
b_L3405: ;
		goto b_return;
		/* line 3500 */
b_L3500: ;
		/* line 3501 */
b_L3501: ;
		b_v_cri=((b_int(((b_rnd(B_INT((1))))*((20)))))+((1)));
		b_a_li[B_INT((1))]=b_v_cri;
		/* line 3502 */
b_L3502: ;
		goto b_return;
		/* line 3600 */
b_L3600: ;
		/* line 3601 */
b_L3601: ;
		b_v_pci=(0);
		b_v_axf=b_v_cri;
		/* line 3602 */
b_L3602: ;
		b_v_hrf=b_v_cri;
		b_gosubStack[b_gosubSP++]=39; goto b_L2000;
b_ret39: ;
		/* line 3603 */
b_L3603: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L3800;
b_ret40: ;
		/* line 3604 */
b_L3604: ;
		b_gosubStack[b_gosubSP++]=41; goto b_L3900;
b_ret41: ;
		/* line 3605 */
b_L3605: ;
		if(-((b_v_shi) == ((88)))){
			b_v_hrf=b_v_axf;
			b_gosubStack[b_gosubSP++]=42; goto b_L2000;
b_ret42: ;
			b_v_fli=(0);
			goto b_return;
		}
		/* line 3606 */
b_L3606: ;
		if(-((b_v_shi) == ((70)))){
			if(-((b_v_pci) >= ((1)))){
				b_v_hrf=b_v_axf;
				b_gosubStack[b_gosubSP++]=43; goto b_L2000;
b_ret43: ;
				goto b_L3611;
			}
		}
		/* line 3607 */
b_L3607: ;
		if(-((b_v_shi) == ((70)))){
			goto b_L3604;
		}
		/* line 3608 */
b_L3608: ;
		b_v_nrf=b_a_adi[((bint_t)(b_v_axf))*4+(B_INT(b_v_shi))];
		/* line 3609 */
b_L3609: ;
		if(-((b_v_pci) >= ((2)))){
			if(-((b_v_nrf) == (b_a_phf[B_INT(((b_v_pci)-((1))))]))){
				b_gosubStack[b_gosubSP++]=44; goto b_L3800;
b_ret44: ;
				goto b_L3604;
			}
		}
		/* line 3610 */
b_L3610: ;
		b_v_hrf=b_v_axf;
		b_gosubStack[b_gosubSP++]=45; goto b_L2000;
b_ret45: ;
		b_v_pci=((b_v_pci)+((1)));
		b_a_phf[B_INT(b_v_pci)]=b_v_nrf;
		b_v_axf=b_v_nrf;
		b_gosubStack[b_gosubSP++]=46; goto b_L3800;
b_ret46: ;
		goto b_L3604;
		/* line 3611 */
b_L3611: ;
		/* line 3612 */
b_L3612: ;
		b_v_sti=b_v_cri;
		/* line 3613 */
b_L3613: ;
		b_v_ki=(1);
		b_fl_24=b_v_pci;
		if(b_v_ki > b_fl_24) goto b_f24_e;
b_f24_t: ;
		/* line 3614 */
b_L3614: ;
		b_v_rrf=b_a_phf[B_INT(b_v_ki)];
		/* line 3615 */
b_L3615: ;
		b_gosubStack[b_gosubSP++]=47; goto b_L3700;
b_ret47: ;
		/* line 3616 */
b_L3616: ;
		if(-((b_v_rrf) == (b_a_li[B_INT((2))]))){
			b_v_fli=(1);
			goto b_return;
		}
		/* line 3617 */
b_L3617: ;
		if(-((b_v_rrf) == (b_v_sti))){
			b_v_mss=b_keep(b_lit("SHOT YOURSELF",13));
			b_v_fli=(-1);
			goto b_return;
		}
		/* line 3618 */
b_L3618: ;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_24)) goto b_f24_t;
b_f24_e: ;
		/* line 3619 */
b_L3619: ;
		b_v_fli=(0);
		b_gosubStack[b_gosubSP++]=48; goto b_L3400;
b_ret48: ;
		/* line 3620 */
b_L3620: ;
		b_v_arf=((b_v_arf)-((1)));
		if(-((b_v_arf) <= ((0)))){
			b_v_mss=b_keep(b_lit("OUT OF ARROWS",13));
			b_v_fli=(-1);
		}
		/* line 3621 */
b_L3621: ;
		goto b_return;
		/* line 3700 */
b_L3700: ;
		/* line 3701 */
b_L3701: ;
		b_v_sai=(((((1024))+(((b_a_pyi[(bint_t)(b_v_rrf)])*((40))))))+(b_a_pxi[(bint_t)(b_v_rrf)]));
		b_v_svi=B_INT(b_peek((unsigned int)(b_v_sai)));
		b_v_sci=B_INT(b_peek((unsigned int)(((b_v_sai)+((54272.0))))));
		/* line 3702 */
b_L3702: ;
		b_poke(b_v_sai,(42));
		b_poke(((b_v_sai)+((54272.0))),(7));
		/* line 3703 */
b_L3703: ;
		b_v_fai=(1);
		if(b_v_fai > 10) goto b_f25_e;
b_f25_t: ;
		b_wait((53265.0),(128),0);
		b_v_fai += 1;
		if(b_v_fai <= 10) goto b_f25_t;
b_f25_e: ;
		/* line 3704 */
b_L3704: ;
		b_poke(b_v_sai,b_v_svi);
		b_poke(((b_v_sai)+((54272.0))),b_v_sci);
		/* line 3705 */
b_L3705: ;
		goto b_return;
		/* line 3800 */
b_L3800: ;
		/* line 3801 */
b_L3801: ;
		b_v_hrf=b_v_axf;
		b_gosubStack[b_gosubSP++]=49; goto b_L2100;
b_ret49: ;
		/* line 3802 */
b_L3802: ;
		b_v_sai=(1984);
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f26_e;
		b_t_6=((b_v_sai)+(b_v_ii));
		b_t_7=(((((55296.0))+((960))))+(b_v_ii));
b_f26_t: ;
		b_poke(b_t_6,(32));
		b_poke(b_t_7,(14));
		b_t_6 += 1;
		b_t_7 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f26_t;
b_f26_e: ;
		/* line 3803 */
b_L3803: ;
		b_v_txi=(1);
		b_v_tyi=(24);
		b_v_ts=b_keep(b_lit("SHOOT",5));
		b_gosubStack[b_gosubSP++]=50; goto b_L2600;
b_ret50: ;
		b_v_txi=(8);
		b_v_vf=b_v_pci;
		b_gosubStack[b_gosubSP++]=51; goto b_L2700;
b_ret51: ;
		/* line 3804 */
b_L3804: ;
		b_v_txi=(12);
		b_v_ts=b_keep(b_lit("HOPS",4));
		b_gosubStack[b_gosubSP++]=52; goto b_L2600;
b_ret52: ;
		/* line 3805 */
b_L3805: ;
		b_v_txi=(19);
		b_v_ts=b_keep(b_lit("1/2/3 F FIRE X CANC",19));
		b_gosubStack[b_gosubSP++]=53; goto b_L2600;
b_ret53: ;
		/* line 3806 */
b_L3806: ;
		goto b_return;
		/* line 3900 */
b_L3900: ;
		/* line 3901 */
b_L3901: ;
		b_v_shi=(0);
		/* line 3902 */
b_L3902: ;
		b_wait((53265.0),(128),0);
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 3903 */
b_L3903: ;
		if(-((b_v_ki) == ((56)))){
			b_v_shi=(1);
			goto b_return;
		}
		/* line 3904 */
b_L3904: ;
		if(-((b_v_ki) == ((59)))){
			b_v_shi=(2);
			goto b_return;
		}
		/* line 3905 */
b_L3905: ;
		if(-((b_v_ki) == ((8)))){
			b_v_shi=(3);
			goto b_return;
		}
		/* line 3906 */
b_L3906: ;
		if(-((b_v_ki) == ((21)))){
			b_v_shi=(70);
			goto b_return;
		}
		/* line 3907 */
b_L3907: ;
		if(-((b_v_ki) == ((23)))){
			b_v_shi=(88);
			goto b_return;
		}
		/* line 3908 */
b_L3908: ;
		goto b_L3902;
		/* line 4000 */
b_L4000: ;
		/* line 4001 */
b_L4001: ;
		b_v_wnf=((b_v_wnf)+((1)));
		/* line 4002 */
b_L4002: ;
		b_gosubStack[b_gosubSP++]=54; goto b_L4300;
b_ret54: ;
		/* line 4003 */
b_L4003: ;
		b_v_txi=(10);
		b_v_tyi=(12);
		b_v_ts=b_keep(b_lit("AHA YOU GOT THE WUMPUS",22));
		b_gosubStack[b_gosubSP++]=55; goto b_L2600;
b_ret55: ;
		/* line 4004 */
b_L4004: ;
		b_gosubStack[b_gosubSP++]=56; goto b_L4200;
b_ret56: ;
		/* line 4005 */
b_L4005: ;
		goto b_return;
		/* line 4100 */
b_L4100: ;
		/* line 4101 */
b_L4101: ;
		b_gosubStack[b_gosubSP++]=57; goto b_L4300;
b_ret57: ;
		/* line 4102 */
b_L4102: ;
		b_v_txi=(9);
		b_v_tyi=(12);
		b_v_vf=(0);
		b_v_ts=b_keep(b_v_mss);
		b_gosubStack[b_gosubSP++]=58; goto b_L2600;
b_ret58: ;
		/* line 4103 */
b_L4103: ;
		b_gosubStack[b_gosubSP++]=59; goto b_L4200;
b_ret59: ;
		/* line 4104 */
b_L4104: ;
		goto b_return;
		/* line 4200 */
b_L4200: ;
		/* line 4201 */
b_L4201: ;
		b_v_txi=(10);
		b_v_tyi=(14);
		b_v_ts=b_keep(b_lit("PLAY AGAIN Y/N",14));
		b_gosubStack[b_gosubSP++]=60; goto b_L2600;
b_ret60: ;
		/* line 4202 */
b_L4202: ;
		b_wait((53265.0),(128),0);
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		/* line 4203 */
b_L4203: ;
		if(-((b_v_ki) == ((39)))){
			b_poke((198),(0));
			goto b_end;
		}
		/* line 4204 */
b_L4204: ;
		if(-((b_v_ki) == ((25)))){
			goto b_return;
		}
		/* line 4205 */
b_L4205: ;
		goto b_L4202;
		/* line 4300 */
b_L4300: ;
		/* line 4301 */
b_L4301: ;
		b_poke((53280.0),(0));
		/* line 4302 */
b_L4302: ;
		b_v_iyi=(10);
		if(b_v_iyi > 15) goto b_f27_e;
b_f27_t: ;
		b_v_sai=(((1024))+(((b_v_iyi)*((40)))));
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f28_e;
		b_v_M6=((b_v_iyi)*((40)));
		b_t_8=((b_v_sai)+(b_v_ii));
		b_t_9=(((((55296.0))+(b_v_M6)))+(b_v_ii));
b_f28_t: ;
		b_poke(b_t_8,(32));
		b_poke(b_t_9,(7));
		b_t_8 += 1;
		b_t_9 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f28_t;
b_f28_e: ;
		b_v_iyi += 1;
		if(b_v_iyi <= 15) goto b_f27_t;
b_f27_e: ;
		/* line 4303 */
b_L4303: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			case 54: goto b_ret54;
			case 55: goto b_ret55;
			case 56: goto b_ret56;
			case 57: goto b_ret57;
			case 58: goto b_ret58;
			case 59: goto b_ret59;
			case 60: goto b_ret60;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
