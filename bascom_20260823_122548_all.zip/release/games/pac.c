/* OPTIMIZE_C -- pac.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_mwi;
static int b_v_mhi;
static int b_v_moi;
static bint_t b_a_mgi[425];
static int b_a_gri[5];
static int b_a_gci[5];
static int b_a_gmi[5];
static bint_t b_a_gdi[5];
static bint_t b_a_di[5];
static int b_a_ogi[5];
static int b_v_wli;
static int b_v_pli;
static int b_v_pwi;
static int b_v_emi;
static int b_v_pmi;
static int b_v_ghi;
static int b_v_vgi;
static bint_t b_v_sci;
static bint_t b_v_lvi;
static int b_v_ovi;
static int b_v_hti;
static bint_t b_v_pei;
static int b_v_pri;
static int b_v_pci;
static int b_v_pdi;
static int b_v_ndi;
static int b_v_tci;
static int b_v_vui;
static bint_t b_v_vti;
static int b_v_phi;
static bint_t b_v_fci;
static int b_v_ii;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_dmi;
static int b_v_tki;
static int b_v_ji;
static bstr_t b_v_ts;
static int b_v_hxi;
static int b_v_hyi;
static bint_t b_v_ci;
static int b_v_ri;
static int b_v_sai;
static bint_t b_v_vi;
static unsigned int b_v_cai;
static int b_v_gzi;
static int b_v_zri;
static int b_v_zci;
static int b_v_qri;
static int b_v_qci;
static bint_t b_v_bdi;
static bint_t b_v_tgi;
static int b_v_bvi;
static int b_v_ddi;
static int b_v_rri;
static int b_v_cci;
static bint_t b_v_dsi;
static int b_v_cti;
static bint_t b_v_txi;
static int b_v_lei;
static bint_t b_v_hhi;
static bstr_t b_v_ks;
static int b_v_M0;
static int b_v_M1;
static bint_t b_v_M2;
static int b_v_M3;
static int b_v_M4;
static int b_v_M5;
static int b_v_M6;
static bint_t b_v_M7;
static int b_v_M8;
static bint_t b_v_M9;
static bint_t b_v_M10;
static int b_v_M11;
static int b_v_M12;
static int b_v_M13;
static int b_v_M14;
static int b_v_M15;
static int b_v_M16;
static int b_v_M17;
static int b_v_M18;
static int b_v_M19;
static int b_v_M20;
static int b_v_M21;
static int b_v_M22;
static int b_v_M23;
static int b_v_M24;
static int b_v_M25;
static int b_v_M26;
static int b_v_M27;
static int b_v_M28;
static int b_v_M29;
static int b_v_M30;
static int b_v_M31;
static int b_v_M32;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static int b_fl_35;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		b_putc(147);
		b_nl();
		/* line 60 */
b_L60: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 70 */
b_L70: ;
		b_v_mwi=(25);
		b_v_mhi=(17);
		b_v_moi=(5);
		/* line 80 */
b_L80: ;
		/* line 90 */
b_L90: ;
		b_v_wli=(102);
		b_v_pli=(46);
		b_v_pwi=(42);
		b_v_emi=(32);
		b_v_pmi=(81);
		b_v_ghi=(88);
		b_v_vgi=(90);
		/* line 100 */
b_L100: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L2000;
b_ret0: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L2400;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L2100;
b_ret2: ;
		/* line 110 */
b_L110: ;
		b_v_sci=(0);
		b_v_lvi=(3);
		b_v_ovi=(0);
		b_v_hti=(0);
		b_v_pei=(0);
		/* line 120 */
b_L120: ;
		b_v_pri=(8);
		b_v_pci=(12);
		b_v_pdi=(1);
		b_v_ndi=(1);
		b_v_tci=(0);
		b_v_vui=(0);
		b_v_vti=(0);
		b_v_phi=(0);
		b_v_fci=(0);
		/* line 130 */
b_L130: ;
		b_a_gri[B_INT((0))]=(3);
		b_a_gci[B_INT((0))]=(3);
		b_a_gri[B_INT((1))]=(3);
		b_a_gci[B_INT((1))]=(21);
		b_a_gri[B_INT((2))]=(13);
		b_a_gci[B_INT((2))]=(3);
		b_a_gri[B_INT((3))]=(13);
		b_a_gci[B_INT((3))]=(21);
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f0_e;
b_f0_t: ;
		b_a_gdi[B_INT(b_v_ii)]=(0);
		b_a_ogi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f0_t;
b_f0_e: ;
		/* line 140 */
b_L140: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1100;
b_ret3: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1000;
b_ret4: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L2300;
b_ret5: ;
		/* line 150 */
b_L150: ;
		/* line 160 */
b_L160: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 170 */
b_L170: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) != ((64)))){
				b_v_dmi=(0);
			}
		}
		/* line 180 */
b_L180: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=6; goto b_L2500;
b_ret6: ;
		}
		/* line 190 */
b_L190: ;
		if(-((b_v_ki) == ((62)))){
			goto b_L2417;
		}
		/* line 195 */
b_L195: ;
		if(-((b_v_ki) == ((7)))){
			if(b_v_sfi){
				b_v_ki=(9);
			}
		}
		/* line 196 */
b_L196: ;
		if(-((b_v_ki) == ((7)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(13);
			}
		}
		/* line 197 */
b_L197: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 198 */
b_L198: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_ki) == ((9)))){
			b_v_ndi=(0);
		}
		/* line 220 */
b_L220: ;
		if(-((b_v_ki) == ((18)))){
			b_v_ndi=(1);
		}
		/* line 240 */
b_L240: ;
		if(-((b_v_ki) == ((13)))){
			b_v_ndi=(2);
		}
		/* line 260 */
b_L260: ;
		if(-((b_v_ki) == ((10)))){
			b_v_ndi=(3);
		}
		/* line 280 */
b_L280: ;
		b_v_tci=((b_v_tci)+((1)));
		b_v_fci=((b_v_fci)+((1)));
		/* line 290 */
b_L290: ;
		if(-((b_v_phi) == ((0)))){
			if(-((b_v_fci) >= ((1200)))){
				b_v_phi=(1);
				b_v_fci=(0);
				b_gosubStack[b_gosubSP++]=7; goto b_L1300;
b_ret7: ;
			}
		}
		/* line 300 */
b_L300: ;
		if(-((b_v_phi) == ((1)))){
			if(-((b_v_fci) >= ((420)))){
				b_v_phi=(0);
				b_v_fci=(0);
				b_gosubStack[b_gosubSP++]=8; goto b_L1400;
b_ret8: ;
			}
		}
		/* line 310 */
b_L310: ;
		if(-((b_v_tci) >= (b_v_tki))){
			b_v_tci=(0);
			b_gosubStack[b_gosubSP++]=9; goto b_L1500;
b_ret9: ;
			b_gosubStack[b_gosubSP++]=10; goto b_L1600;
b_ret10: ;
		}
		/* line 320 */
b_L320: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L2300;
b_ret11: ;
		/* line 330 */
b_L330: ;
		if(-((b_v_ovi) == ((1)))){
			goto b_L2507;
		}
		/* line 340 */
b_L340: ;
		b_v_ji=(1);
		if(b_v_ji > 30) goto b_f1_e;
b_f1_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 30) goto b_f1_t;
b_f1_e: ;
		/* line 350 */
b_L350: ;
		goto b_L160;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		b_v_hxi=(0);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=12; goto b_L2200;
b_ret12: ;
		/* line 1002 */
b_L1002: ;
		b_v_ts=b_keep(b_lit("LIVES",5));
		b_v_hxi=(12);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=13; goto b_L2200;
b_ret13: ;
		/* line 1003 */
b_L1003: ;
		b_v_ts=b_keep(b_lit("LEVEL",5));
		b_v_hxi=(20);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=14; goto b_L2200;
b_ret14: ;
		/* line 1004 */
b_L1004: ;
		b_v_ts=b_keep(b_lit("EAT",3));
		b_v_hxi=(30);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=15; goto b_L2200;
b_ret15: ;
		/* line 1005 */
b_L1005: ;
		b_v_ci=(0);
		if(b_v_ci > 34) goto b_f2_e;
b_f2_t: ;
		b_poke((((55296.0))+(b_v_ci)),(7));
		b_v_ci += 1;
		if(b_v_ci <= 34) goto b_f2_t;
b_f2_e: ;
		/* line 1006 */
b_L1006: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_ri=(0);
		if(b_v_ri > 16) goto b_f3_e;
b_f3_t: ;
		b_v_ci=(0);
		if(b_v_ci > 24) goto b_f4_e;
		b_v_M0=(((1024))+(((((b_v_ri)+((3))))*((40)))));
		b_v_M1=((b_v_ri)*(b_v_mwi));
		b_v_M2=((((b_v_ri)+((3))))*((40)));
b_f4_t: ;
		/* line 1102 */
b_L1102: ;
		b_v_sai=((b_v_M0)+(((b_v_ci)+(b_v_moi))));
		b_v_vi=b_a_mgi[B_INT(((b_v_M1)+(b_v_ci)))];
		b_v_cai=(((((55296.0))+(b_v_M2)))+(((b_v_ci)+(b_v_moi))));
		/* line 1103 */
b_L1103: ;
		if(-((b_v_vi) == ((1)))){
			b_poke(b_v_sai,b_v_wli);
			b_poke(b_v_cai,(1));
		}
		/* line 1104 */
b_L1104: ;
		if(-((b_v_vi) == ((0)))){
			b_poke(b_v_sai,b_v_pli);
			b_poke(b_v_cai,(14));
		}
		/* line 1105 */
b_L1105: ;
		if(-((b_v_vi) == ((2)))){
			b_poke(b_v_sai,b_v_pwi);
			b_poke(b_v_cai,(10));
		}
		/* line 1106 */
b_L1106: ;
		if(-((b_v_vi) == ((3)))){
			b_poke(b_v_sai,b_v_emi);
			b_poke(b_v_cai,(0));
		}
		/* line 1107 */
b_L1107: ;
		b_v_ci += 1;
		if(b_v_ci <= 24) goto b_f4_t;
b_f4_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 16) goto b_f3_t;
b_f3_e: ;
		/* line 1108 */
b_L1108: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L1200;
b_ret16: ;
		/* line 1109 */
b_L1109: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_poke((((((1024))+(((((b_v_pri)+((3))))*((40))))))+(((b_v_pci)+(b_v_moi)))),b_v_pmi);
		b_poke((((((55296.0))+(((((b_v_pri)+((3))))*((40))))))+(((b_v_pci)+(b_v_moi)))),(7));
		/* line 1202 */
b_L1202: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f5_e;
b_f5_t: ;
		/* line 1203 */
b_L1203: ;
		b_v_gzi=b_v_ghi;
		if(-((b_v_vui) > ((0)))){
			b_v_gzi=b_v_vgi;
		}
		/* line 1204 */
b_L1204: ;
		b_poke((((((1024))+(((((b_a_gri[B_INT(b_v_ii)])+((3))))*((40))))))+(((b_a_gci[B_INT(b_v_ii)])+(b_v_moi)))),b_v_gzi);
		/* line 1205 */
b_L1205: ;
		b_poke((((((55296.0))+(((((b_a_gri[B_INT(b_v_ii)])+((3))))*((40))))))+(((b_a_gci[B_INT(b_v_ii)])+(b_v_moi)))),(((2))+(b_v_ii)));
		/* line 1206 */
b_L1206: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f5_t;
b_f5_e: ;
		/* line 1207 */
b_L1207: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f6_e;
b_f6_t: ;
		b_a_ogi[B_INT(b_v_ii)]=b_a_gmi[B_INT(b_v_ii)];
		b_a_gmi[B_INT(b_v_ii)]=(3);
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f6_t;
b_f6_e: ;
		/* line 1302 */
b_L1302: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_a_gmi[B_INT((0))]=b_a_ogi[B_INT((0))];
		b_a_gmi[B_INT((1))]=b_a_ogi[B_INT((1))];
		b_a_gmi[B_INT((2))]=b_a_ogi[B_INT((2))];
		b_a_gmi[B_INT((3))]=b_a_ogi[B_INT((3))];
		/* line 1402 */
b_L1402: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_zri=b_v_pri;
		b_v_zci=b_v_pci;
		/* line 1502 */
b_L1502: ;
		if(-((b_v_ndi) == ((0)))){
			if(-((b_v_pri) > ((0)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)-((1))))*(b_v_mwi)))+(b_v_pci)))]) != ((1)))){
					b_v_pdi=(0);
				}
			}
		}
		/* line 1503 */
b_L1503: ;
		if(-((b_v_ndi) == ((1)))){
			if(-((b_v_pci) < ((24)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))+((1))))]) != ((1)))){
					b_v_pdi=(1);
				}
			}
		}
		/* line 1504 */
b_L1504: ;
		if(-((b_v_ndi) == ((2)))){
			if(-((b_v_pri) < ((16)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)+((1))))*(b_v_mwi)))+(b_v_pci)))]) != ((1)))){
					b_v_pdi=(2);
				}
			}
		}
		/* line 1505 */
b_L1505: ;
		if(-((b_v_ndi) == ((3)))){
			if(-((b_v_pci) > ((0)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))-((1))))]) != ((1)))){
					b_v_pdi=(3);
				}
			}
		}
		/* line 1506 */
b_L1506: ;
		if(-((b_v_pdi) == ((0)))){
			if(-((b_v_pri) > ((0)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)-((1))))*(b_v_mwi)))+(b_v_pci)))]) != ((1)))){
					b_v_pri=((b_v_pri)-((1)));
				}
			}
		}
		/* line 1507 */
b_L1507: ;
		if(-((b_v_pdi) == ((1)))){
			if(-((b_v_pci) < ((24)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))+((1))))]) != ((1)))){
					b_v_pci=((b_v_pci)+((1)));
				}
			}
		}
		/* line 1508 */
b_L1508: ;
		if(-((b_v_pdi) == ((2)))){
			if(-((b_v_pri) < ((16)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)+((1))))*(b_v_mwi)))+(b_v_pci)))]) != ((1)))){
					b_v_pri=((b_v_pri)+((1)));
				}
			}
		}
		/* line 1509 */
b_L1509: ;
		if(-((b_v_pdi) == ((3)))){
			if(-((b_v_pci) > ((0)))){
				if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))-((1))))]) != ((1)))){
					b_v_pci=((b_v_pci)-((1)));
				}
			}
		}
		/* line 1510 */
b_L1510: ;
		/* line 1511 */
b_L1511: ;
		if(-((b_v_pri) == ((8)))){
			if(-((b_v_pci) < ((0)))){
				b_v_pci=(24);
			}
		}
		/* line 1512 */
b_L1512: ;
		if(-((b_v_pri) == ((8)))){
			if(-((b_v_pci) > ((24)))){
				b_v_pci=(0);
			}
		}
		/* line 1513 */
b_L1513: ;
		/* line 1514 */
b_L1514: ;
		b_poke((((((1024))+(((((b_v_zri)+((3))))*((40))))))+(((b_v_zci)+(b_v_moi)))),b_v_emi);
		b_poke((((((55296.0))+(((((b_v_zri)+((3))))*((40))))))+(((b_v_zci)+(b_v_moi)))),(0));
		/* line 1515 */
b_L1515: ;
		b_v_vi=b_a_mgi[B_INT(((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))];
		if(-((b_v_vi) == ((0)))){
			b_a_mgi[B_INT(((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))]=(3);
			b_v_sci=((b_v_sci)+((10)));
			b_v_pei=((b_v_pei)+((1)));
		}
		/* line 1516 */
b_L1516: ;
		if(-((b_v_vi) == ((2)))){
			b_a_mgi[B_INT(((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))]=(3);
			b_v_sci=((b_v_sci)+((50)));
			b_v_vui=(1);
			b_v_vti=(60);
			b_v_pei=((b_v_pei)+((1)));
		}
		/* line 1517 */
b_L1517: ;
		b_poke((((((1024))+(((((b_v_pri)+((3))))*((40))))))+(((b_v_pci)+(b_v_moi)))),b_v_pmi);
		b_poke((((((55296.0))+(((((b_v_pri)+((3))))*((40))))))+(((b_v_pci)+(b_v_moi)))),(7));
		/* line 1518 */
b_L1518: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		if(-((b_v_vui) > ((0)))){
			b_v_vti=((b_v_vti)-((1)));
			if(-((b_v_vti) <= ((0)))){
				b_v_vui=(0);
			}
		}
		/* line 1602 */
b_L1602: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f7_e;
b_f7_t: ;
		/* line 1603 */
b_L1603: ;
		b_v_qri=b_a_gri[B_INT(b_v_ii)];
		b_v_qci=b_a_gci[B_INT(b_v_ii)];
		/* line 1604 */
b_L1604: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L1700;
b_ret17: ;
		/* line 1605 */
b_L1605: ;
		if(-((b_v_bdi) == ((0)))){
			b_a_gri[B_INT(b_v_ii)]=((b_a_gri[B_INT(b_v_ii)])-((1)));
		}
		/* line 1606 */
b_L1606: ;
		if(-((b_v_bdi) == ((1)))){
			b_a_gci[B_INT(b_v_ii)]=((b_a_gci[B_INT(b_v_ii)])+((1)));
		}
		/* line 1607 */
b_L1607: ;
		if(-((b_v_bdi) == ((2)))){
			b_a_gri[B_INT(b_v_ii)]=((b_a_gri[B_INT(b_v_ii)])+((1)));
		}
		/* line 1608 */
b_L1608: ;
		if(-((b_v_bdi) == ((3)))){
			b_a_gci[B_INT(b_v_ii)]=((b_a_gci[B_INT(b_v_ii)])-((1)));
		}
		/* line 1609 */
b_L1609: ;
		if(-((b_a_gri[B_INT(b_v_ii)]) < ((0)))){
			b_a_gri[B_INT(b_v_ii)]=(16);
		}
		/* line 1610 */
b_L1610: ;
		if(-((b_a_gci[B_INT(b_v_ii)]) < ((0)))){
			b_a_gci[B_INT(b_v_ii)]=(24);
		}
		/* line 1611 */
b_L1611: ;
		if(-((b_a_gri[B_INT(b_v_ii)]) > ((16)))){
			b_a_gri[B_INT(b_v_ii)]=(0);
		}
		/* line 1612 */
b_L1612: ;
		if(-((b_a_gci[B_INT(b_v_ii)]) > ((24)))){
			b_a_gci[B_INT(b_v_ii)]=(0);
		}
		/* line 1613 */
b_L1613: ;
		b_poke((((((1024))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),b_v_emi);
		b_poke((((((55296.0))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),(0));
		/* line 1614 */
b_L1614: ;
		b_v_vi=b_a_mgi[B_INT(((((b_v_qri)*(b_v_mwi)))+(b_v_qci)))];
		if(-((b_v_vi) == ((0)))){
			b_poke((((((1024))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),b_v_pli);
			b_poke((((((55296.0))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),(14));
		}
		/* line 1615 */
b_L1615: ;
		if(-((b_v_vi) == ((2)))){
			b_poke((((((1024))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),b_v_pwi);
			b_poke((((((55296.0))+(((((b_v_qri)+((3))))*((40))))))+(((b_v_qci)+(b_v_moi)))),(10));
		}
		/* line 1616 */
b_L1616: ;
		b_v_gzi=b_v_ghi;
		if(-((b_v_vui) > ((0)))){
			b_v_gzi=b_v_vgi;
		}
		/* line 1617 */
b_L1617: ;
		b_poke((((((1024))+(((((b_a_gri[B_INT(b_v_ii)])+((3))))*((40))))))+(((b_a_gci[B_INT(b_v_ii)])+(b_v_moi)))),b_v_gzi);
		b_poke((((((55296.0))+(((((b_a_gri[B_INT(b_v_ii)])+((3))))*((40))))))+(((b_a_gci[B_INT(b_v_ii)])+(b_v_moi)))),(((2))+(b_v_ii)));
		/* line 1618 */
b_L1618: ;
		if(-((b_a_gri[B_INT(b_v_ii)]) == (b_v_pri))){
			if(-((b_a_gci[B_INT(b_v_ii)]) == (b_v_pci))){
				b_gosubStack[b_gosubSP++]=18; goto b_L1800;
b_ret18: ;
			}
		}
		/* line 1619 */
b_L1619: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f7_t;
b_f7_e: ;
		/* line 1620 */
b_L1620: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_tgi=b_v_pri;
		b_v_tgi=b_v_pci;
		/* line 1702 */
b_L1702: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((1)))){
			if(-((b_v_pdi) == ((0)))){
				b_v_tgi=((b_v_pri)-((4)));
			}
		}
		/* line 1703 */
b_L1703: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((1)))){
			if(-((b_v_pdi) == ((1)))){
				b_v_tgi=((b_v_pci)+((4)));
			}
		}
		/* line 1704 */
b_L1704: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((1)))){
			if(-((b_v_pdi) == ((2)))){
				b_v_tgi=((b_v_pri)+((4)));
			}
		}
		/* line 1705 */
b_L1705: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((1)))){
			if(-((b_v_pdi) == ((3)))){
				b_v_tgi=((b_v_pci)-((4)));
			}
		}
		/* line 1706 */
b_L1706: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((3)))){
			b_v_tgi=(0);
			b_v_tgi=(0);
		}
		/* line 1707 */
b_L1707: ;
		if(-((b_v_vui) > ((0)))){
			b_v_tgi=(0);
			b_v_tgi=(0);
			if(-((b_v_ii) == ((1)))){
				b_v_tgi=(16);
				b_v_tgi=(24);
			}
		}
		/* line 1708 */
b_L1708: ;
		if(-((b_a_gmi[B_INT(b_v_ii)]) == ((2)))){
			if(-((b_rnd(B_INT((1)))) < ((0.40000000002328306)))){
				b_v_tgi=b_int(((b_rnd(B_INT((1))))*((17))));
				b_v_tgi=b_int(((b_rnd(B_INT((1))))*((25))));
			}
		}
		/* line 1709 */
b_L1709: ;
		b_v_bvi=(999);
		b_v_bdi=(-1);
		/* line 1710 */
b_L1710: ;
		b_v_ddi=(0);
		if(b_v_ddi > 3) goto b_f8_e;
		b_v_M3=((b_v_qri)-((1)));
		b_v_M4=((b_v_qci)+((1)));
		b_v_M5=((b_v_qri)+((1)));
		b_v_M6=((b_v_qci)-((1)));
		b_v_M7=b_a_gdi[B_INT(b_v_ii)];
b_f8_t: ;
		/* line 1711 */
b_L1711: ;
		if(-((b_v_ddi) == ((0)))){
			b_v_rri=b_v_M3;
			b_v_cci=b_v_qci;
		}
		/* line 1712 */
b_L1712: ;
		if(-((b_v_ddi) == ((1)))){
			b_v_rri=b_v_qri;
			b_v_cci=b_v_M4;
		}
		/* line 1713 */
b_L1713: ;
		if(-((b_v_ddi) == ((2)))){
			b_v_rri=b_v_M5;
			b_v_cci=b_v_qci;
		}
		/* line 1714 */
b_L1714: ;
		if(-((b_v_ddi) == ((3)))){
			b_v_rri=b_v_qri;
			b_v_cci=b_v_M6;
		}
		/* line 1715 */
b_L1715: ;
		if(-((b_v_rri) < ((0)))){
			b_v_rri=(16);
		}
		/* line 1716 */
b_L1716: ;
		if(-((b_v_rri) > ((16)))){
			b_v_rri=(0);
		}
		/* line 1717 */
b_L1717: ;
		if(-((b_v_cci) < ((0)))){
			b_v_cci=(24);
		}
		/* line 1718 */
b_L1718: ;
		if(-((b_v_cci) > ((24)))){
			b_v_cci=(0);
		}
		/* line 1719 */
b_L1719: ;
		if(-((b_a_mgi[B_INT(((((b_v_rri)*(b_v_mwi)))+(b_v_cci)))]) == ((1)))){ goto b_L1726; }
		/* line 1720 */
b_L1720: ;
		if((B_INT(-((b_v_ddi) == ((0)))) & B_INT(-((b_v_M7) == ((2)))))){ goto b_L1726; }
		/* line 1721 */
b_L1721: ;
		if((B_INT(-((b_v_ddi) == ((1)))) & B_INT(-((b_v_M7) == ((3)))))){ goto b_L1726; }
		/* line 1722 */
b_L1722: ;
		if((B_INT(-((b_v_ddi) == ((2)))) & B_INT(-((b_v_M7) == ((0)))))){ goto b_L1726; }
		/* line 1723 */
b_L1723: ;
		if((B_INT(-((b_v_ddi) == ((3)))) & B_INT(-((b_v_M7) == ((1)))))){ goto b_L1726; }
		/* line 1724 */
b_L1724: ;
		b_v_dsi=((b_abs((breal_t)(((b_v_rri)-(b_v_tgi)))))+(b_abs((breal_t)(((b_v_cci)-(b_v_tgi))))));
		/* line 1725 */
b_L1725: ;
		if(-((b_v_dsi) < (b_v_bvi))){
			b_v_bvi=b_v_dsi;
			b_v_bdi=b_v_ddi;
		}
		/* line 1726 */
b_L1726: ;
		b_v_ddi += 1;
		if(b_v_ddi <= 3) goto b_f8_t;
b_f8_e: ;
		/* line 1727 */
b_L1727: ;
		if(-((b_v_bdi) == ((-1)))){
			b_v_bdi=b_a_gdi[B_INT(b_v_ii)];
		}
		/* line 1728 */
b_L1728: ;
		b_a_gdi[B_INT(b_v_ii)]=b_v_bdi;
		/* line 1729 */
b_L1729: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		if(-((b_v_vui) > ((0)))){
			b_v_sci=((b_v_sci)+((200)));
			b_a_gri[B_INT(b_v_ii)]=(8);
			b_a_gci[B_INT(b_v_ii)]=(((10))+(b_v_ii));
			b_a_gdi[B_INT(b_v_ii)]=(0);
			goto b_return;
		}
		/* line 1802 */
b_L1802: ;
		if(-((b_v_hti) > ((0)))){
			goto b_return;
		}
		/* line 1803 */
b_L1803: ;
		b_v_lvi=((b_v_lvi)-((1)));
		b_v_hti=(40);
		b_gosubStack[b_gosubSP++]=19; goto b_L1900;
b_ret19: ;
		/* line 1804 */
b_L1804: ;
		if(-((b_v_lvi) <= ((0)))){
			b_v_ovi=(1);
		}
		/* line 1805 */
b_L1805: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_ji=(1);
		if(b_v_ji > 3) goto b_f9_e;
		b_v_M8=(((((1024))+(((((b_v_pri)+((3))))*((40))))))+(((b_v_pci)+(b_v_moi))));
		b_v_M9=((((b_v_pri)+((3))))*((40)));
		b_v_M10=((b_v_pci)+(b_v_moi));
b_f9_t: ;
		/* line 1902 */
b_L1902: ;
		b_poke(b_v_M8,(42));
		b_poke((((((55296.0))+(b_v_M9)))+(b_v_M10)),(2));
		/* line 1903 */
b_L1903: ;
		b_v_ki=(1);
		if(b_v_ki > 500) goto b_f10_e;
b_f10_t: ;
		b_v_ki += 1;
		if(b_v_ki <= 500) goto b_f10_t;
b_f10_e: ;
		/* line 1904 */
b_L1904: ;
		b_poke(b_v_M8,b_v_pmi);
		b_poke((((((55296.0))+(b_v_M9)))+(b_v_M10)),(7));
		/* line 1905 */
b_L1905: ;
		b_v_ki=(1);
		if(b_v_ki > 500) goto b_f11_e;
b_f11_t: ;
		b_v_ki += 1;
		if(b_v_ki <= 500) goto b_f11_t;
b_f11_e: ;
		/* line 1906 */
b_L1906: ;
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f9_t;
b_f9_e: ;
		/* line 1907 */
b_L1907: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_ri=(0);
		if(b_v_ri > 16) goto b_f12_e;
b_f12_t: ;
		b_v_ci=(0);
		if(b_v_ci > 24) goto b_f13_e;
		b_v_M11=((b_v_ri)*(b_v_mwi));
b_f13_t: ;
		b_a_mgi[B_INT(((b_v_M11)+(b_v_ci)))]=(0);
		b_v_ci += 1;
		if(b_v_ci <= 24) goto b_f13_t;
b_f13_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 16) goto b_f12_t;
b_f12_e: ;
		/* line 2002 */
b_L2002: ;
		b_v_ci=(0);
		if(b_v_ci > 24) goto b_f14_e;
		b_v_M12=(((16))*(b_v_mwi));
b_f14_t: ;
		b_a_mgi[B_INT(b_v_ci)]=(1);
		b_a_mgi[B_INT(((b_v_M12)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 24) goto b_f14_t;
b_f14_e: ;
		/* line 2003 */
b_L2003: ;
		b_v_ri=(0);
		if(b_v_ri > 16) goto b_f15_e;
b_f15_t: ;
		b_a_mgi[B_INT(((b_v_ri)*(b_v_mwi)))]=(1);
		b_a_mgi[B_INT(((((b_v_ri)*(b_v_mwi)))+((24))))]=(1);
		b_v_ri += 1;
		if(b_v_ri <= 16) goto b_f15_t;
b_f15_e: ;
		/* line 2004 */
b_L2004: ;
		b_v_ci=(2);
		if(b_v_ci > 5) goto b_f16_e;
		b_v_M13=(((2))*(b_v_mwi));
b_f16_t: ;
		b_a_mgi[B_INT(((b_v_M13)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 5) goto b_f16_t;
b_f16_e: ;
		/* line 2005 */
b_L2005: ;
		b_v_ci=(19);
		if(b_v_ci > 22) goto b_f17_e;
		b_v_M14=(((2))*(b_v_mwi));
b_f17_t: ;
		b_a_mgi[B_INT(((b_v_M14)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 22) goto b_f17_t;
b_f17_e: ;
		/* line 2006 */
b_L2006: ;
		b_v_ci=(2);
		if(b_v_ci > 5) goto b_f18_e;
		b_v_M15=(((14))*(b_v_mwi));
b_f18_t: ;
		b_a_mgi[B_INT(((b_v_M15)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 5) goto b_f18_t;
b_f18_e: ;
		/* line 2007 */
b_L2007: ;
		b_v_ci=(19);
		if(b_v_ci > 22) goto b_f19_e;
		b_v_M16=(((14))*(b_v_mwi));
b_f19_t: ;
		b_a_mgi[B_INT(((b_v_M16)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 22) goto b_f19_t;
b_f19_e: ;
		/* line 2008 */
b_L2008: ;
		b_v_ci=(9);
		if(b_v_ci > 11) goto b_f20_e;
		b_v_M17=(((4))*(b_v_mwi));
b_f20_t: ;
		b_a_mgi[B_INT(((b_v_M17)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 11) goto b_f20_t;
b_f20_e: ;
		/* line 2009 */
b_L2009: ;
		b_v_ci=(13);
		if(b_v_ci > 15) goto b_f21_e;
		b_v_M18=(((4))*(b_v_mwi));
b_f21_t: ;
		b_a_mgi[B_INT(((b_v_M18)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 15) goto b_f21_t;
b_f21_e: ;
		/* line 2010 */
b_L2010: ;
		b_v_ci=(9);
		if(b_v_ci > 11) goto b_f22_e;
		b_v_M19=(((12))*(b_v_mwi));
b_f22_t: ;
		b_a_mgi[B_INT(((b_v_M19)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 11) goto b_f22_t;
b_f22_e: ;
		/* line 2011 */
b_L2011: ;
		b_v_ci=(13);
		if(b_v_ci > 15) goto b_f23_e;
		b_v_M20=(((12))*(b_v_mwi));
b_f23_t: ;
		b_a_mgi[B_INT(((b_v_M20)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 15) goto b_f23_t;
b_f23_e: ;
		/* line 2012 */
b_L2012: ;
		b_v_ci=(2);
		if(b_v_ci > 3) goto b_f24_e;
		b_v_M21=(((6))*(b_v_mwi));
b_f24_t: ;
		b_a_mgi[B_INT(((b_v_M21)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 3) goto b_f24_t;
b_f24_e: ;
		/* line 2013 */
b_L2013: ;
		b_v_ci=(21);
		if(b_v_ci > 22) goto b_f25_e;
		b_v_M22=(((6))*(b_v_mwi));
b_f25_t: ;
		b_a_mgi[B_INT(((b_v_M22)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 22) goto b_f25_t;
b_f25_e: ;
		/* line 2014 */
b_L2014: ;
		b_v_ci=(9);
		if(b_v_ci > 10) goto b_f26_e;
		b_v_M23=(((6))*(b_v_mwi));
b_f26_t: ;
		b_a_mgi[B_INT(((b_v_M23)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f26_t;
b_f26_e: ;
		/* line 2015 */
b_L2015: ;
		b_v_ci=(14);
		if(b_v_ci > 15) goto b_f27_e;
		b_v_M24=(((6))*(b_v_mwi));
b_f27_t: ;
		b_a_mgi[B_INT(((b_v_M24)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 15) goto b_f27_t;
b_f27_e: ;
		/* line 2016 */
b_L2016: ;
		b_v_ci=(2);
		if(b_v_ci > 3) goto b_f28_e;
		b_v_M25=(((10))*(b_v_mwi));
b_f28_t: ;
		b_a_mgi[B_INT(((b_v_M25)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 3) goto b_f28_t;
b_f28_e: ;
		/* line 2017 */
b_L2017: ;
		b_v_ci=(21);
		if(b_v_ci > 22) goto b_f29_e;
		b_v_M26=(((10))*(b_v_mwi));
b_f29_t: ;
		b_a_mgi[B_INT(((b_v_M26)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 22) goto b_f29_t;
b_f29_e: ;
		/* line 2018 */
b_L2018: ;
		b_v_ci=(9);
		if(b_v_ci > 10) goto b_f30_e;
		b_v_M27=(((10))*(b_v_mwi));
b_f30_t: ;
		b_a_mgi[B_INT(((b_v_M27)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 10) goto b_f30_t;
b_f30_e: ;
		/* line 2019 */
b_L2019: ;
		b_v_ci=(14);
		if(b_v_ci > 15) goto b_f31_e;
		b_v_M28=(((10))*(b_v_mwi));
b_f31_t: ;
		b_a_mgi[B_INT(((b_v_M28)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 15) goto b_f31_t;
b_f31_e: ;
		/* line 2020 */
b_L2020: ;
		b_a_mgi[B_INT((((((8))*(b_v_mwi)))+((0))))]=(0);
		b_a_mgi[B_INT((((((8))*(b_v_mwi)))+((24))))]=(0);
		/* line 2021 */
b_L2021: ;
		b_a_mgi[B_INT((((((1))*(b_v_mwi)))+((1))))]=(2);
		b_a_mgi[B_INT((((((1))*(b_v_mwi)))+((23))))]=(2);
		b_a_mgi[B_INT((((((15))*(b_v_mwi)))+((1))))]=(2);
		b_a_mgi[B_INT((((((15))*(b_v_mwi)))+((23))))]=(2);
		/* line 2022 */
b_L2022: ;
		b_a_gmi[B_INT((0))]=(0);
		b_a_gmi[B_INT((1))]=(1);
		b_a_gmi[B_INT((2))]=(2);
		b_a_gmi[B_INT((3))]=(3);
		/* line 2023 */
b_L2023: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f32_e;
b_f32_t: ;
		b_a_gdi[B_INT(b_v_ii)]=(0);
		b_a_ogi[B_INT(b_v_ii)]=b_a_gmi[B_INT(b_v_ii)];
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f32_t;
b_f32_e: ;
		/* line 2024 */
b_L2024: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_v_ri=(0);
		if(b_v_ri > 24) goto b_f33_e;
b_f33_t: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f34_e;
		b_v_M29=(((1024))+(((b_v_ri)*((40)))));
		b_v_M30=((b_v_ri)*((40)));
		b_t_10=((b_v_M29)+(b_v_ci));
		b_t_11=(((((55296.0))+(b_v_M30)))+(b_v_ci));
b_f34_t: ;
		b_poke(b_t_10,b_v_emi);
		b_poke(b_t_11,(0));
		b_t_10 += 1;
		b_t_11 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f34_t;
b_f34_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 24) goto b_f33_t;
b_f33_e: ;
		/* line 2102 */
b_L2102: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_v_ii=(1);
		b_fl_35=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_35) goto b_f35_e;
		b_v_M31=(((1024))+(b_v_hxi));
		b_v_M32=((b_v_hyi)*((40)));
		b_t_12=((((((b_v_M31)+(b_v_ii)))-((1))))+(b_v_M32));
b_f35_t: ;
		/* line 2202 */
b_L2202: ;
		b_v_cti=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 2203 */
b_L2203: ;
		if(-((b_v_cti) >= ((64)))){
			if(-((b_v_cti) <= ((95)))){
				b_v_cti=((b_v_cti)-((64)));
			}
		}
		/* line 2204 */
b_L2204: ;
		b_poke(b_t_12,b_v_cti);
		/* line 2205 */
b_L2205: ;
		b_t_12 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_35)) goto b_f35_t;
b_f35_e: ;
		/* line 2206 */
b_L2206: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		b_v_txi=b_v_sci;
		b_v_ji=(0);
		if(b_v_ji > 4) goto b_f36_e;
b_f36_t: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_txi)-((((10))*(b_int(((breal_t)(b_v_txi)/(breal_t)((10))))))));
		b_v_txi=b_int(((breal_t)(b_v_txi)/(breal_t)((10))));
		b_v_ji += 1;
		if(b_v_ji <= 4) goto b_f36_t;
b_f36_e: ;
		/* line 2302 */
b_L2302: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((4))])));
		b_poke((1031),(((48))+(b_a_di[B_INT((3))])));
		b_poke((1032),(((48))+(b_a_di[B_INT((2))])));
		b_poke((1033),(((48))+(b_a_di[B_INT((1))])));
		b_poke((1034),(((48))+(b_a_di[B_INT((0))])));
		/* line 2303 */
b_L2303: ;
		b_poke((1042),(((48))+(b_v_lvi)));
		b_poke((1050),(((48))+(b_int(((breal_t)(b_v_lei)/(breal_t)((10)))))));
		b_poke((1051),(((((48))+(b_v_lei)))-((((10))*(b_int(((breal_t)(b_v_lei)/(breal_t)((10)))))))));
		/* line 2304 */
b_L2304: ;
		b_poke((1057),(((48))+(b_int(((breal_t)(b_v_pei)/(breal_t)((10)))))));
		b_poke((1058),(((((48))+(b_v_pei)))-((((10))*(b_int(((breal_t)(b_v_pei)/(breal_t)((10)))))))));
		b_poke((1059),(32));
		/* line 2305 */
b_L2305: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
		}
		/* line 2306 */
b_L2306: ;
		if(-((b_v_dmi) == ((0)))){
			b_poke((1060),(32));
			b_poke((1061),(32));
			b_poke((1062),(32));
			b_poke((1063),(32));
			b_poke((55332.0),(0));
			b_poke((55333.0),(0));
			b_poke((55334.0),(0));
			b_poke((55335.0),(0));
		}
		/* line 2307 */
b_L2307: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_putc(147);
		b_nl();
		/* line 2402 */
b_L2402: ;
		b_v_ts=b_keep(b_lit("MAZECHASE",9));
		b_v_hxi=(15);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=20; goto b_L2200;
b_ret20: ;
		b_v_hhi=(15);
		if(b_v_hhi > 24) goto b_f37_e;
b_f37_t: ;
		b_poke((((55296.0))+(b_v_hhi)),(7));
		b_v_hhi += 1;
		if(b_v_hhi <= 24) goto b_f37_t;
b_f37_e: ;
		/* line 2403 */
b_L2403: ;
		b_v_ts=b_keep(b_lit("EAT ALL PELLETS",15));
		b_v_hxi=(13);
		b_v_hyi=(2);
		b_gosubStack[b_gosubSP++]=21; goto b_L2200;
b_ret21: ;
		/* line 2404 */
b_L2404: ;
		b_v_ts=b_keep(b_lit("POWER * EATS GHOSTS",19));
		b_v_hxi=(11);
		b_v_hyi=(3);
		b_gosubStack[b_gosubSP++]=22; goto b_L2200;
b_ret22: ;
		/* line 2405 */
b_L2405: ;
		b_v_ts=b_keep(b_lit("CRSR OR WASD MOVE",17));
		b_v_hxi=(12);
		b_v_hyi=(4);
		b_gosubStack[b_gosubSP++]=23; goto b_L2200;
b_ret23: ;
		/* line 2406 */
b_L2406: ;
		b_v_ts=b_keep(b_lit("E=EASY  H=HARD",14));
		b_v_hxi=(12);
		b_v_hyi=(5);
		b_gosubStack[b_gosubSP++]=24; goto b_L2200;
b_ret24: ;
		/* line 2407 */
b_L2407: ;
		b_v_dmi=(1);
		b_v_tgi=(0);
		b_v_tki=(7);
		b_v_lei=(1);
		/* line 2408 */
b_L2408: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2413; }
		/* line 2409 */
b_L2409: ;
		if(-(b_strcmp(b_v_ks,b_lit("E",1)) == 0)){
			b_v_dmi=(0);
			b_v_tki=(8);
			b_v_lei=(1);
			goto b_L2416;
		}
		/* line 2410 */
b_L2410: ;
		if(-(b_strcmp(b_v_ks,b_lit("H",1)) == 0)){
			b_v_dmi=(0);
			b_v_tki=(6);
			b_v_lei=(3);
			goto b_L2416;
		}
		/* line 2411 */
b_L2411: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 2412 */
b_L2412: ;
		b_v_dmi=(0);
		goto b_L2416;
		/* line 2413 */
b_L2413: ;
		b_wait((53265.0),(128),0);
		/* line 2414 */
b_L2414: ;
		b_v_tgi=((b_v_tgi)+((1)));
		if(-((b_v_tgi) < ((240)))){ goto b_L2408; }
		/* line 2415 */
b_L2415: ;
		b_v_dmi=(1);
		b_v_tki=(7);
		b_v_lei=(1);
		/* line 2416 */
b_L2416: ;
		b_putc(147);
		b_nl();
		goto b_return;
		/* line 2417 */
b_L2417: ;
		/* line 2418 */
b_L2418: ;
		b_putc(147);
		b_nl();
		b_sys((64738.0));
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		if(-((b_rnd(B_INT((1)))) < ((0.30000000004656613)))){
			b_v_ndi=b_int(((b_rnd(B_INT((1))))*((4))));
			goto b_return;
		}
		/* line 2502 */
b_L2502: ;
		if(-((b_v_pri) > ((0)))){
			if(-((b_a_mgi[B_INT(((((((b_v_pri)-((1))))*(b_v_mwi)))+(b_v_pci)))]) == ((0)))){
				b_v_ndi=(0);
				goto b_return;
			}
		}
		/* line 2503 */
b_L2503: ;
		if(-((b_v_pci) < ((24)))){
			if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))+((1))))]) == ((0)))){
				b_v_ndi=(1);
				goto b_return;
			}
		}
		/* line 2504 */
b_L2504: ;
		if(-((b_v_pri) < ((16)))){
			if(-((b_a_mgi[B_INT(((((((b_v_pri)+((1))))*(b_v_mwi)))+(b_v_pci)))]) == ((0)))){
				b_v_ndi=(2);
				goto b_return;
			}
		}
		/* line 2505 */
b_L2505: ;
		if(-((b_v_pci) > ((0)))){
			if(-((b_a_mgi[B_INT(((((((b_v_pri)*(b_v_mwi)))+(b_v_pci)))-((1))))]) == ((0)))){
				b_v_ndi=(3);
				goto b_return;
			}
		}
		/* line 2506 */
b_L2506: ;
		goto b_return;
		/* line 2507 */
b_L2507: ;
		/* line 2508 */
b_L2508: ;
		b_putc(147);
		b_nl();
		/* line 2509 */
b_L2509: ;
		b_nl();
		{ bstr_t _t=b_lit("  *** GAME OVER ***",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2510 */
b_L2510: ;
		{ bstr_t _t=b_lit("  SCORE:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		{ bstr_t _t=b_lit("  LEVEL:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		b_nl();
		/* line 2511 */
b_L2511: ;
		b_nl();
		{ bstr_t _t=b_lit("  R=RESTART  Q=QUIT",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2512 */
b_L2512: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L2512; }
		/* line 2513 */
b_L2513: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L100;
		}
		/* line 2514 */
b_L2514: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 2515 */
b_L2515: ;
		goto b_L2512;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
