/* OPTIMIZE_C -- swarm.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_eri[14];
static int b_a_eci[14];
static int b_a_eki[14];
static bint_t b_a_esi[14];
static bint_t b_a_ehi[14];
static bint_t b_a_eti[14];
static int b_a_byi[8];
static int b_a_bxi[8];
static int b_a_bfi[8];
static int b_a_dyi[8];
static int b_a_dxi[8];
static bint_t b_v_pxi;
static int b_v_pyi;
static bint_t b_v_hpi;
static bint_t b_v_sci;
static int b_v_ovi;
static bint_t b_v_kci;
static bint_t b_v_cli;
static int b_v_cdi;
static bint_t b_v_sli;
static int b_v_spi;
static int b_v_fri;
static int b_v_emi;
static int b_v_fpi;
static int b_v_kpi;
static int b_v_ni;
static int b_v_wti;
static bint_t b_v_sdi;
static int b_v_ki;
static bint_t b_v_ndi;
static int b_v_txi;
static int b_v_tyi;
static bint_t b_v_di;
static bint_t b_v_d0i;
static bint_t b_v_ti;
static bint_t b_v_d1i;
static bint_t b_v_d2i;
static bint_t b_v_d3i;
static bint_t b_v_d4i;
static bint_t b_v_hti;
static bint_t b_v_hoi;
static int b_v_t1i;
static bint_t b_v_t2i;
static bint_t b_v_mi;
static int b_v_ji;
static int b_v_rsi;
static int b_v_rci;
static int b_v_rri;
static int b_v_rbi;
static int b_v_rti;
static bstr_t b_v_ts;
static breal_t b_v_rf;
static bint_t b_v_bai;
static int b_v_ci;
static int b_v_ii;
static breal_t b_v_chf;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static int b_fl_13;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		/* line 80 */
b_L80: ;
		/* line 90 */
b_L90: ;
		/* line 100 */
b_L100: ;
		/* line 110 */
b_L110: ;
		/* line 120 */
b_L120: ;
		/* line 130 */
b_L130: ;
		b_v_pxi=(20);
		/* line 140 */
b_L140: ;
		b_v_pyi=(12);
		/* line 150 */
b_L150: ;
		b_v_hpi=(20);
		/* line 160 */
b_L160: ;
		b_v_sci=(0);
		/* line 170 */
b_L170: ;
		b_v_ovi=(0);
		/* line 190 */
b_L190: ;
		b_v_kci=(0);
		/* line 200 */
b_L200: ;
		b_v_cli=(0);
		/* line 210 */
b_L210: ;
		b_v_cdi=(0);
		/* line 220 */
b_L220: ;
		b_v_sli=(0);
		/* line 230 */
b_L230: ;
		b_v_spi=(8);
		/* line 240 */
b_L240: ;
		b_v_fri=(0);
		/* line 250 */
b_L250: ;
		b_v_emi=(3);
		/* line 260 */
b_L260: ;
		b_v_fpi=(5);
		/* line 270 */
b_L270: ;
		b_v_kpi=(0);
		/* line 280 */
b_L280: ;
		b_v_ni=(0);
		if(b_v_ni > 13) goto b_f0_e;
b_f0_t: ;
		/* line 290 */
b_L290: ;
		b_a_eki[B_INT(b_v_ni)]=(0);
		/* line 300 */
b_L300: ;
		b_v_ni += 1;
		if(b_v_ni <= 13) goto b_f0_t;
b_f0_e: ;
		/* line 310 */
b_L310: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f1_e;
b_f1_t: ;
		/* line 320 */
b_L320: ;
		b_a_bfi[B_INT(b_v_ni)]=(0);
		/* line 330 */
b_L330: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f1_t;
b_f1_e: ;
		/* line 340 */
b_L340: ;
		b_poke((53280.0),(0));
		/* line 350 */
b_L350: ;
		b_poke((53281.0),(0));
		/* line 360 */
b_L360: ;
		b_poke((650),(128));
		/* line 405 */
b_L405: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L3300;
b_ret0: ;
		/* line 410 */
b_L410: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L2600;
b_ret1: ;
		/* line 420 */
b_L420: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L2700;
b_ret2: ;
		/* line 430 */
b_L430: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1100;
b_ret3: ;
		/* line 440 */
b_L440: ;
		b_v_wti=(1);
		if(b_v_wti > 40) goto b_f2_e;
b_f2_t: ;
		/* line 450 */
b_L450: ;
		b_v_wti += 1;
		if(b_v_wti <= 40) goto b_f2_t;
b_f2_e: ;
		/* line 460 */
b_L460: ;
		b_v_sdi=((b_v_sdi)+((1)));
		/* line 470 */
b_L470: ;
		if(-((b_v_sdi) >= ((10)))){
			b_v_sdi=(0);
			b_v_wti=(1);
			if(b_v_wti > 40) goto b_f3_e;
b_f3_t: ;
			b_v_wti += 1;
			if(b_v_wti <= 40) goto b_f3_t;
b_f3_e: ;
		}
		/* line 480 */
b_L480: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		/* line 490 */
b_L490: ;
		b_poke((198),(0));
		/* line 530 */
b_L530: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 550 */
b_L550: ;
		if(-((b_v_ki) == ((9)))){
			b_gosubStack[b_gosubSP++]=4; goto b_L1000;
b_ret4: ;
			if(-((b_v_pyi) > ((1)))){
				b_v_pyi=((b_v_pyi)-((1)));
				b_gosubStack[b_gosubSP++]=5; goto b_L1100;
b_ret5: ;
			}
		}
		/* line 560 */
b_L560: ;
		if(-((b_v_ki) == ((13)))){
			b_gosubStack[b_gosubSP++]=6; goto b_L1000;
b_ret6: ;
			if(-((b_v_pyi) < ((23)))){
				b_v_pyi=((b_v_pyi)+((1)));
				b_gosubStack[b_gosubSP++]=7; goto b_L1100;
b_ret7: ;
			}
		}
		/* line 570 */
b_L570: ;
		if(-((b_v_ki) == ((10)))){
			b_gosubStack[b_gosubSP++]=8; goto b_L1000;
b_ret8: ;
			if(-((b_v_pxi) > ((1)))){
				b_v_pxi=((b_v_pxi)-((1)));
				b_gosubStack[b_gosubSP++]=9; goto b_L1100;
b_ret9: ;
			}
		}
		/* line 580 */
b_L580: ;
		if(-((b_v_ki) == ((18)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L1000;
b_ret10: ;
			if(-((b_v_pxi) < ((38)))){
				b_v_pxi=((b_v_pxi)+((1)));
				b_gosubStack[b_gosubSP++]=11; goto b_L1100;
b_ret11: ;
			}
		}
		/* line 590 */
b_L590: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1700;
b_ret12: ;
		/* line 600 */
b_L600: ;
		b_gosubStack[b_gosubSP++]=13; goto b_L1800;
b_ret13: ;
		/* line 610 */
b_L610: ;
		if(-((b_v_kpi) == ((1)))){
			b_v_sci=((((b_v_sci)+((10))))+(((b_v_kci)*((5)))));
			b_v_kpi=(0);
		}
		/* line 620 */
b_L620: ;
		b_gosubStack[b_gosubSP++]=14; goto b_L2400;
b_ret14: ;
		/* line 630 */
b_L630: ;
		b_gosubStack[b_gosubSP++]=15; goto b_L1400;
b_ret15: ;
		/* line 640 */
b_L640: ;
		b_v_cdi=((b_v_cdi)+((1)));
		/* line 650 */
b_L650: ;
		if(-((b_v_cdi) >= (b_v_fpi))){
			b_v_cdi=(0);
			b_gosubStack[b_gosubSP++]=16; goto b_L1200;
b_ret16: ;
		}
		/* line 660 */
b_L660: ;
		b_v_sci=((b_v_sci)+((1)));
		/* line 670 */
b_L670: ;
		if(-((b_v_cli) > ((0)))){
			b_v_cli=((b_v_cli)-((1)));
			if(-((b_v_cli) == ((0)))){
				b_v_kci=(0);
			}
		}
		/* line 680 */
b_L680: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L1100;
b_ret17: ;
		/* line 690 */
b_L690: ;
		if(-((b_v_hpi) <= ((0)))){
			b_v_ovi=(1);
		}
		/* line 700 */
b_L700: ;
		if(b_v_ovi){ goto b_L2740; }
		/* line 710 */
b_L710: ;
		goto b_L440;
		/* line 1000 */
b_L1000: ;
		b_poke((((((1024))+(b_v_pxi)))+(((b_v_pyi)*((40))))),(32));
		/* line 1005 */
b_L1005: ;
		b_poke((((((55296.0))+(b_v_pxi)))+(((b_v_pyi)*((40))))),(0));
		/* line 1010 */
b_L1010: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		b_poke((((((1024))+(b_v_pxi)))+(((b_v_pyi)*((40))))),(81));
		/* line 1105 */
b_L1105: ;
		b_poke((((((55296.0))+(b_v_pxi)))+(((b_v_pyi)*((40))))),(1));
		/* line 1110 */
b_L1110: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		b_v_ndi=(99);
		/* line 1205 */
b_L1205: ;
		b_v_txi=b_v_pxi;
		/* line 1210 */
b_L1210: ;
		b_v_tyi=b_v_pyi;
		/* line 1215 */
b_L1215: ;
		b_v_ni=(0);
		if(b_v_ni > 13) goto b_f4_e;
b_f4_t: ;
		/* line 1220 */
b_L1220: ;
		if(-((b_a_eki[B_INT(b_v_ni)]) == ((1)))){
			b_v_di=((b_abs((breal_t)(((b_a_eri[B_INT(b_v_ni)])-(b_v_pyi)))))+(b_abs((breal_t)(((b_a_eci[B_INT(b_v_ni)])-(b_v_pxi))))));
			if(-((b_v_di) < (b_v_ndi))){
				b_v_ndi=b_v_di;
				b_v_txi=b_a_eci[B_INT(b_v_ni)];
				b_v_tyi=b_a_eri[B_INT(b_v_ni)];
			}
		}
		/* line 1225 */
b_L1225: ;
		b_v_ni += 1;
		if(b_v_ni <= 13) goto b_f4_t;
b_f4_e: ;
		/* line 1230 */
b_L1230: ;
		if(-((b_v_ndi) == ((99)))){
			goto b_return;
		}
		/* line 1235 */
b_L1235: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f5_e;
b_f5_t: ;
		/* line 1240 */
b_L1240: ;
		if(-((b_a_bfi[B_INT(b_v_ni)]) == ((1)))){ goto b_L1300; }
		/* line 1245 */
b_L1245: ;
		b_a_dxi[B_INT(b_v_ni)]=(0);
		/* line 1250 */
b_L1250: ;
		b_a_dyi[B_INT(b_v_ni)]=(0);
		/* line 1255 */
b_L1255: ;
		if(-((b_v_txi) < (b_v_pxi))){
			b_a_dxi[B_INT(b_v_ni)]=(-1);
		}
		/* line 1260 */
b_L1260: ;
		if(-((b_v_txi) > (b_v_pxi))){
			b_a_dxi[B_INT(b_v_ni)]=(1);
		}
		/* line 1265 */
b_L1265: ;
		if(-((b_v_tyi) < (b_v_pyi))){
			b_a_dyi[B_INT(b_v_ni)]=(-1);
		}
		/* line 1270 */
b_L1270: ;
		if(-((b_v_tyi) > (b_v_pyi))){
			b_a_dyi[B_INT(b_v_ni)]=(1);
		}
		/* line 1275 */
b_L1275: ;
		if(-((b_a_dxi[B_INT(b_v_ni)]) == ((0)))){
			if(-((b_a_dyi[B_INT(b_v_ni)]) == ((0)))){
				b_a_dyi[B_INT(b_v_ni)]=(-1);
			}
		}
		/* line 1280 */
b_L1280: ;
		b_a_bxi[B_INT(b_v_ni)]=((b_v_pxi)+(b_a_dxi[B_INT(b_v_ni)]));
		/* line 1285 */
b_L1285: ;
		b_a_byi[B_INT(b_v_ni)]=((b_v_pyi)+(b_a_dyi[B_INT(b_v_ni)]));
		/* line 1290 */
b_L1290: ;
		b_a_bfi[B_INT(b_v_ni)]=(1);
		/* line 1295 */
b_L1295: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f5_t;
b_f5_e: ;
		/* line 1305 */
b_L1305: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		b_v_d0i=((breal_t)(b_v_sci)/(breal_t)((10000)));
		/* line 1405 */
b_L1405: ;
		b_v_ti=((b_v_sci)-(((b_v_d0i)*((10000)))));
		/* line 1410 */
b_L1410: ;
		b_v_d1i=((breal_t)(b_v_ti)/(breal_t)((1000)));
		/* line 1415 */
b_L1415: ;
		b_v_ti=((b_v_ti)-(((b_v_d1i)*((1000)))));
		/* line 1420 */
b_L1420: ;
		b_v_d2i=((breal_t)(b_v_ti)/(breal_t)((100)));
		/* line 1425 */
b_L1425: ;
		b_v_ti=((b_v_ti)-(((b_v_d2i)*((100)))));
		/* line 1430 */
b_L1430: ;
		b_v_d3i=((breal_t)(b_v_ti)/(breal_t)((10)));
		/* line 1435 */
b_L1435: ;
		b_v_d4i=((b_v_ti)-(((b_v_d3i)*((10)))));
		/* line 1440 */
b_L1440: ;
		b_poke((1030),(((48))+(b_v_d0i)));
		/* line 1445 */
b_L1445: ;
		b_poke((1031),(((48))+(b_v_d1i)));
		/* line 1450 */
b_L1450: ;
		b_poke((1032),(((48))+(b_v_d2i)));
		/* line 1455 */
b_L1455: ;
		b_poke((1033),(((48))+(b_v_d3i)));
		/* line 1460 */
b_L1460: ;
		b_poke((1034),(((48))+(b_v_d4i)));
		/* line 1465 */
b_L1465: ;
		b_poke((1037),(8));
		/* line 1470 */
b_L1470: ;
		b_poke((1038),(16));
		/* line 1475 */
b_L1475: ;
		b_poke((1039),(32));
		/* line 1480 */
b_L1480: ;
		b_v_hti=((breal_t)(b_v_hpi)/(breal_t)((10)));
		/* line 1485 */
b_L1485: ;
		b_v_hoi=((b_v_hpi)-(((b_v_hti)*((10)))));
		/* line 1490 */
b_L1490: ;
		b_poke((1040),(((48))+(b_v_hti)));
		/* line 1495 */
b_L1495: ;
		b_poke((1041),(((48))+(b_v_hoi)));
		/* line 1500 */
b_L1500: ;
		b_poke((1042),(32));
		/* line 1505 */
b_L1505: ;
		b_poke((1043),(3));
		/* line 1510 */
b_L1510: ;
		b_poke((1044),(8));
		/* line 1515 */
b_L1515: ;
		b_poke((1045),(1));
		/* line 1520 */
b_L1520: ;
		b_poke((1046),(9));
		/* line 1525 */
b_L1525: ;
		b_poke((1047),(14));
		/* line 1530 */
b_L1530: ;
		b_poke((1048),(32));
		/* line 1535 */
b_L1535: ;
		b_v_t1i=((breal_t)(b_v_kci)/(breal_t)((10)));
		/* line 1540 */
b_L1540: ;
		b_v_t2i=((b_v_kci)-(((b_v_t1i)*((10)))));
		/* line 1545 */
b_L1545: ;
		b_poke((1049),(((48))+(b_v_t1i)));
		/* line 1550 */
b_L1550: ;
		b_poke((1050),(((48))+(b_v_t2i)));
		/* line 1600 */
b_L1600: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		b_v_ni=(0);
		if(b_v_ni > 13) goto b_f6_e;
b_f6_t: ;
		/* line 1705 */
b_L1705: ;
		if(-((b_a_eki[B_INT(b_v_ni)]) == ((0)))){ goto b_L1760; }
		/* line 1710 */
b_L1710: ;
		b_a_eti[B_INT(b_v_ni)]=((b_a_eti[B_INT(b_v_ni)])-((1)));
		/* line 1715 */
b_L1715: ;
		if(-((b_a_eti[B_INT(b_v_ni)]) > ((0)))){ goto b_L1755; }
		/* line 1720 */
b_L1720: ;
		b_a_eti[B_INT(b_v_ni)]=b_v_emi;
		/* line 1725 */
b_L1725: ;
		b_gosubStack[b_gosubSP++]=18; goto b_L2000;
b_ret18: ;
		/* line 1730 */
b_L1730: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) < (b_v_pyi))){
			b_a_eri[B_INT(b_v_ni)]=((b_a_eri[B_INT(b_v_ni)])+((1)));
		}
		/* line 1735 */
b_L1735: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) > (b_v_pyi))){
			b_a_eri[B_INT(b_v_ni)]=((b_a_eri[B_INT(b_v_ni)])-((1)));
		}
		/* line 1740 */
b_L1740: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) < (b_v_pxi))){
			b_a_eci[B_INT(b_v_ni)]=((b_a_eci[B_INT(b_v_ni)])+((1)));
		}
		/* line 1745 */
b_L1745: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) > (b_v_pxi))){
			b_a_eci[B_INT(b_v_ni)]=((b_a_eci[B_INT(b_v_ni)])-((1)));
		}
		/* line 1750 */
b_L1750: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L2200;
b_ret19: ;
		/* line 1755 */
b_L1755: ;
		if(-((b_v_pxi) >= (b_a_eci[B_INT(b_v_ni)]))){
			if(-((b_v_pxi) <= (((b_a_eci[B_INT(b_v_ni)])+(b_a_esi[B_INT(b_v_ni)]))))){
				if(-((b_v_pyi) >= (b_a_eri[B_INT(b_v_ni)]))){
					if(-((b_v_pyi) <= (((b_a_eri[B_INT(b_v_ni)])+(b_a_esi[B_INT(b_v_ni)]))))){
						b_gosubStack[b_gosubSP++]=20; goto b_L2100;
b_ret20: ;
					}
				}
			}
		}
		/* line 1760 */
b_L1760: ;
		b_v_ni += 1;
		if(b_v_ni <= 13) goto b_f6_t;
b_f6_e: ;
		/* line 1765 */
b_L1765: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f7_e;
b_f7_t: ;
		/* line 1805 */
b_L1805: ;
		if(-((b_a_bfi[B_INT(b_v_ni)]) == ((0)))){ goto b_L1880; }
		/* line 1810 */
b_L1810: ;
		b_poke((((((1024))+(b_a_bxi[B_INT(b_v_ni)])))+(((b_a_byi[B_INT(b_v_ni)])*((40))))),(32));
		/* line 1815 */
b_L1815: ;
		b_a_bxi[B_INT(b_v_ni)]=((b_a_bxi[B_INT(b_v_ni)])+(b_a_dxi[B_INT(b_v_ni)]));
		/* line 1820 */
b_L1820: ;
		b_a_byi[B_INT(b_v_ni)]=((b_a_byi[B_INT(b_v_ni)])+(b_a_dyi[B_INT(b_v_ni)]));
		/* line 1825 */
b_L1825: ;
		if(-((b_a_byi[B_INT(b_v_ni)]) < ((1)))){
			b_a_bfi[B_INT(b_v_ni)]=(0);
			goto b_L1880;
		}
		/* line 1830 */
b_L1830: ;
		if(-((b_a_byi[B_INT(b_v_ni)]) > ((24)))){
			b_a_bfi[B_INT(b_v_ni)]=(0);
			goto b_L1880;
		}
		/* line 1835 */
b_L1835: ;
		if(-((b_a_bxi[B_INT(b_v_ni)]) < ((0)))){
			b_a_bfi[B_INT(b_v_ni)]=(0);
			goto b_L1880;
		}
		/* line 1840 */
b_L1840: ;
		if(-((b_a_bxi[B_INT(b_v_ni)]) > ((39)))){
			b_a_bfi[B_INT(b_v_ni)]=(0);
			goto b_L1880;
		}
		/* line 1845 */
b_L1845: ;
		b_v_mi=(0);
		/* line 1850 */
b_L1850: ;
		if(-((b_a_eki[B_INT(b_v_mi)]) == ((0)))){ goto b_L1860; }
		/* line 1855 */
b_L1855: ;
		if(-((b_a_bxi[B_INT(b_v_ni)]) >= (b_a_eci[B_INT(b_v_mi)]))){
			if(-((b_a_bxi[B_INT(b_v_ni)]) <= (((b_a_eci[B_INT(b_v_mi)])+(b_a_esi[B_INT(b_v_mi)]))))){
				if(-((b_a_byi[B_INT(b_v_ni)]) >= (b_a_eri[B_INT(b_v_mi)]))){
					if(-((b_a_byi[B_INT(b_v_ni)]) <= (((b_a_eri[B_INT(b_v_mi)])+(b_a_esi[B_INT(b_v_mi)]))))){
						b_gosubStack[b_gosubSP++]=21; goto b_L1900;
b_ret21: ;
						b_a_bfi[B_INT(b_v_ni)]=(0);
						goto b_L1880;
					}
				}
			}
		}
		/* line 1860 */
b_L1860: ;
		b_v_mi=((b_v_mi)+((1)));
		/* line 1865 */
b_L1865: ;
		if(-((b_v_mi) <= ((13)))){ goto b_L1850; }
		/* line 1870 */
b_L1870: ;
		b_poke((((((1024))+(b_a_bxi[B_INT(b_v_ni)])))+(((b_a_byi[B_INT(b_v_ni)])*((40))))),(46));
		/* line 1875 */
b_L1875: ;
		b_poke((((((55296.0))+(b_a_bxi[B_INT(b_v_ni)])))+(((b_a_byi[B_INT(b_v_ni)])*((40))))),(7));
		/* line 1880 */
b_L1880: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f7_t;
b_f7_e: ;
		/* line 1885 */
b_L1885: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		if(-((b_a_ehi[B_INT(b_v_mi)]) > ((1)))){
			b_a_ehi[B_INT(b_v_mi)]=((b_a_ehi[B_INT(b_v_mi)])-((1)));
			goto b_return;
		}
		/* line 1905 */
b_L1905: ;
		b_a_eki[B_INT(b_v_mi)]=(0);
		/* line 1910 */
b_L1910: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_mi)])))+(((b_a_eri[B_INT(b_v_mi)])*((40))))),(32));
		/* line 1915 */
b_L1915: ;
		if(-((b_a_esi[B_INT(b_v_mi)]) == ((0)))){ goto b_L1935; }
		/* line 1920 */
b_L1920: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_mi)])))+((1))))+(((b_a_eri[B_INT(b_v_mi)])*((40))))),(32));
		/* line 1925 */
b_L1925: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_mi)])))+(((((b_a_eri[B_INT(b_v_mi)])+((1))))*((40))))),(32));
		/* line 1930 */
b_L1930: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_mi)])))+((1))))+(((((b_a_eri[B_INT(b_v_mi)])+((1))))*((40))))),(32));
		/* line 1935 */
b_L1935: ;
		b_v_kci=((b_v_kci)+((1)));
		/* line 1940 */
b_L1940: ;
		b_v_cli=(30);
		/* line 1945 */
b_L1945: ;
		b_v_kpi=(1);
		/* line 1950 */
b_L1950: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) > ((39)))){
			goto b_return;
		}
		/* line 2005 */
b_L2005: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) < ((0)))){
			goto b_return;
		}
		/* line 2010 */
b_L2010: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) < ((1)))){
			goto b_return;
		}
		/* line 2015 */
b_L2015: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) > ((24)))){
			goto b_return;
		}
		/* line 2020 */
b_L2020: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(32));
		/* line 2025 */
b_L2025: ;
		if(-((b_a_esi[B_INT(b_v_ni)]) == ((0)))){
			goto b_return;
		}
		/* line 2030 */
b_L2030: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(32));
		/* line 2035 */
b_L2035: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(32));
		/* line 2040 */
b_L2040: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(32));
		/* line 2045 */
b_L2045: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		b_v_hpi=((b_v_hpi)-((1)));
		/* line 2105 */
b_L2105: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L2000;
b_ret22: ;
		/* line 2110 */
b_L2110: ;
		b_a_eki[B_INT(b_v_ni)]=(0);
		/* line 2115 */
b_L2115: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L2300;
b_ret23: ;
		/* line 2120 */
b_L2120: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) > ((39)))){
			goto b_return;
		}
		/* line 2205 */
b_L2205: ;
		if(-((b_a_eci[B_INT(b_v_ni)]) < ((0)))){
			goto b_return;
		}
		/* line 2210 */
b_L2210: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) < ((1)))){
			goto b_return;
		}
		/* line 2215 */
b_L2215: ;
		if(-((b_a_eri[B_INT(b_v_ni)]) > ((24)))){
			goto b_return;
		}
		/* line 2220 */
b_L2220: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(42));
		/* line 2225 */
b_L2225: ;
		b_poke((((((55296.0))+(b_a_eci[B_INT(b_v_ni)])))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(2));
		/* line 2230 */
b_L2230: ;
		if(-((b_a_esi[B_INT(b_v_ni)]) == ((0)))){
			goto b_return;
		}
		/* line 2235 */
b_L2235: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(42));
		/* line 2240 */
b_L2240: ;
		b_poke((((((((55296.0))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((b_a_eri[B_INT(b_v_ni)])*((40))))),(2));
		/* line 2245 */
b_L2245: ;
		b_poke((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(42));
		/* line 2250 */
b_L2250: ;
		b_poke((((((55296.0))+(b_a_eci[B_INT(b_v_ni)])))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(2));
		/* line 2255 */
b_L2255: ;
		b_poke((((((((1024))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(42));
		/* line 2260 */
b_L2260: ;
		b_poke((((((((55296.0))+(b_a_eci[B_INT(b_v_ni)])))+((1))))+(((((b_a_eri[B_INT(b_v_ni)])+((1))))*((40))))),(2));
		/* line 2265 */
b_L2265: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		b_poke((53280.0),(2));
		/* line 2305 */
b_L2305: ;
		b_v_ji=(1);
		if(b_v_ji > 50) goto b_f8_e;
b_f8_t: ;
		/* line 2310 */
b_L2310: ;
		b_v_ji += 1;
		if(b_v_ji <= 50) goto b_f8_t;
b_f8_e: ;
		/* line 2315 */
b_L2315: ;
		b_poke((53280.0),(0));
		/* line 2320 */
b_L2320: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		if(-((((b_v_sci)-(b_v_sli))) < (b_v_spi))){
			goto b_return;
		}
		/* line 2405 */
b_L2405: ;
		b_v_sli=b_v_sci;
		/* line 2410 */
b_L2410: ;
		b_v_rsi=b_int(((b_rnd(B_INT((1))))*((4))));
		/* line 2415 */
b_L2415: ;
		b_v_rci=b_int(((b_rnd(B_INT((1))))*((40))));
		/* line 2420 */
b_L2420: ;
		b_v_rri=b_int(((b_rnd(B_INT((1))))*((23))));
		/* line 2425 */
b_L2425: ;
		b_v_rbi=b_int(((b_rnd(B_INT((1))))*((100))));
		/* line 2430 */
b_L2430: ;
		b_v_rti=b_int(((b_rnd(B_INT((1))))*(b_v_emi)));
		/* line 2435 */
b_L2435: ;
		b_v_ni=(0);
		if(b_v_ni > 13) goto b_f9_e;
b_f9_t: ;
		/* line 2440 */
b_L2440: ;
		if(-((b_a_eki[B_INT(b_v_ni)]) == ((1)))){ goto b_L2500; }
		/* line 2445 */
b_L2445: ;
		if(-((b_v_rsi) == ((0)))){
			b_a_eci[B_INT(b_v_ni)]=b_v_rci;
			b_a_eri[B_INT(b_v_ni)]=(1);
		}
		/* line 2450 */
b_L2450: ;
		if(-((b_v_rsi) == ((1)))){
			b_a_eci[B_INT(b_v_ni)]=b_v_rci;
			b_a_eri[B_INT(b_v_ni)]=(23);
		}
		/* line 2455 */
b_L2455: ;
		if(-((b_v_rsi) == ((2)))){
			b_a_eci[B_INT(b_v_ni)]=(1);
			b_a_eri[B_INT(b_v_ni)]=(((1))+(b_v_rri));
		}
		/* line 2460 */
b_L2460: ;
		if(-((b_v_rsi) == ((3)))){
			b_a_eci[B_INT(b_v_ni)]=(38);
			b_a_eri[B_INT(b_v_ni)]=(((1))+(b_v_rri));
		}
		/* line 2465 */
b_L2465: ;
		b_a_esi[B_INT(b_v_ni)]=(0);
		/* line 2470 */
b_L2470: ;
		b_a_ehi[B_INT(b_v_ni)]=(1);
		/* line 2475 */
b_L2475: ;
		if(-((b_v_rbi) < ((2)))){
			b_a_esi[B_INT(b_v_ni)]=(1);
			b_a_ehi[B_INT(b_v_ni)]=(3);
		}
		/* line 2480 */
b_L2480: ;
		if(-((b_a_esi[B_INT(b_v_ni)]) == ((1)))){
			if(-((b_a_eci[B_INT(b_v_ni)]) > ((38)))){
				b_a_eci[B_INT(b_v_ni)]=(38);
			}
		}
		/* line 2485 */
b_L2485: ;
		b_a_eti[B_INT(b_v_ni)]=b_v_rti;
		/* line 2490 */
b_L2490: ;
		b_a_eki[B_INT(b_v_ni)]=(1);
		/* line 2495 */
b_L2495: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		b_v_ni += 1;
		if(b_v_ni <= 13) goto b_f9_t;
b_f9_e: ;
		/* line 2505 */
b_L2505: ;
		goto b_return;
		/* line 2600 */
b_L2600: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		/* line 2605 */
b_L2605: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L3000;
b_ret24: ;
		/* line 2610 */
b_L2610: ;
		b_poke((1035),(32));
		/* line 2615 */
b_L2615: ;
		b_poke((1036),(32));
		/* line 2620 */
b_L2620: ;
		b_poke((1041),(32));
		/* line 2625 */
b_L2625: ;
		b_poke((1042),(32));
		/* line 2630 */
b_L2630: ;
		b_poke((1051),(32));
		/* line 2635 */
b_L2635: ;
		b_poke((1052),(32));
		/* line 2640 */
b_L2640: ;
		b_poke((1053),(32));
		/* line 2645 */
b_L2645: ;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		b_v_rf=(1);
		/* line 2705 */
b_L2705: ;
		b_v_bai=(((1024))+(((b_v_rf)*((40)))));
		/* line 2710 */
b_L2710: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f10_e;
		b_t_5=((b_v_bai)+(b_v_ci));
b_f10_t: ;
		/* line 2715 */
b_L2715: ;
		b_poke(b_t_5,(32));
		/* line 2720 */
b_L2720: ;
		b_t_5 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f10_t;
b_f10_e: ;
		/* line 2725 */
b_L2725: ;
		b_v_rf=((b_v_rf)+((1)));
		/* line 2730 */
b_L2730: ;
		if(-((b_v_rf) <= ((24)))){ goto b_L2705; }
		/* line 2735 */
b_L2735: ;
		goto b_return;
		/* line 2740 */
b_L2740: ;
		b_putc(147);
		b_nl();
		/* line 2745 */
b_L2745: ;
		b_nl();
		/* line 2750 */
b_L2750: ;
		b_nl();
		/* line 2755 */
b_L2755: ;
		{ bstr_t _t=b_lit("    *** GAME OVER ***",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2760 */
b_L2760: ;
		b_nl();
		/* line 2765 */
b_L2765: ;
		{ bstr_t _t=b_lit("    SCORE:",10); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 2770 */
b_L2770: ;
		b_nl();
		/* line 2775 */
b_L2775: ;
		{ bstr_t _t=b_lit("    R=RESTART  Q=QUIT",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 2780 */
b_L2780: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		/* line 2785 */
b_L2785: ;
		b_poke((198),(0));
		/* line 2790 */
b_L2790: ;
		if(-((b_v_ki) == ((17)))){ goto b_L2805; }
		/* line 2795 */
b_L2795: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 2800 */
b_L2800: ;
		goto b_L2780;
		/* line 2805 */
b_L2805: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L3300;
b_ret25: ;
		/* line 2810 */
b_L2810: ;
		b_v_pxi=(20);
		/* line 2815 */
b_L2815: ;
		b_v_pyi=(12);
		/* line 2820 */
b_L2820: ;
		b_v_hpi=(20);
		/* line 2825 */
b_L2825: ;
		b_v_sci=(0);
		/* line 2830 */
b_L2830: ;
		b_v_ovi=(0);
		/* line 2835 */
b_L2835: ;
		b_v_kci=(0);
		/* line 2840 */
b_L2840: ;
		b_v_cli=(0);
		/* line 2845 */
b_L2845: ;
		b_v_cdi=(0);
		/* line 2850 */
b_L2850: ;
		b_v_sli=(0);
		/* line 2855 */
b_L2855: ;
		b_v_fri=(0);
		/* line 2860 */
b_L2860: ;
		b_v_sdi=(0);
		/* line 2865 */
b_L2865: ;
		b_v_ni=(0);
		if(b_v_ni > 13) goto b_f11_e;
b_f11_t: ;
		/* line 2870 */
b_L2870: ;
		b_a_eki[B_INT(b_v_ni)]=(0);
		/* line 2875 */
b_L2875: ;
		b_v_ni += 1;
		if(b_v_ni <= 13) goto b_f11_t;
b_f11_e: ;
		/* line 2880 */
b_L2880: ;
		b_v_ni=(0);
		if(b_v_ni > 7) goto b_f12_e;
b_f12_t: ;
		/* line 2885 */
b_L2885: ;
		b_a_bfi[B_INT(b_v_ni)]=(0);
		/* line 2890 */
b_L2890: ;
		b_v_ni += 1;
		if(b_v_ni <= 7) goto b_f12_t;
b_f12_e: ;
		/* line 2895 */
b_L2895: ;
		b_gosubStack[b_gosubSP++]=26; goto b_L2700;
b_ret26: ;
		/* line 2900 */
b_L2900: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L2600;
b_ret27: ;
		/* line 2905 */
b_L2905: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L1100;
b_ret28: ;
		/* line 2910 */
b_L2910: ;
		goto b_L440;
		/* line 3000 */
b_L3000: ;
		b_v_ii=(1);
		b_fl_13=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_13) goto b_f13_e;
		b_t_8=(((((1024))+(b_v_ii)))-((1)));
b_f13_t: ;
		/* line 3005 */
b_L3005: ;
		b_v_chf=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 3010 */
b_L3010: ;
		if((B_INT(-((b_v_chf) >= ((64)))) & B_INT(-((b_v_chf) <= ((95)))))){
			b_v_chf=((b_v_chf)-((64)));
		}
		/* line 3015 */
b_L3015: ;
		b_poke(b_t_8,b_v_chf);
		/* line 3020 */
b_L3020: ;
		b_t_8 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_13)) goto b_f13_t;
b_f13_e: ;
		/* line 3025 */
b_L3025: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		b_putc(147);
		b_nl();
		/* line 3305 */
b_L3305: ;
		b_nl();
		/* line 3310 */
b_L3310: ;
		b_nl();
		/* line 3315 */
b_L3315: ;
		{ bstr_t _t=b_lit("       *** SWARM ***",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3320 */
b_L3320: ;
		b_nl();
		/* line 3325 */
b_L3325: ;
		{ bstr_t _t=b_lit("     E=EASY",11); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3330 */
b_L3330: ;
		{ bstr_t _t=b_lit("     SPACE=NORMAL",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3335 */
b_L3335: ;
		{ bstr_t _t=b_lit("     H=HARD",11); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3340 */
b_L3340: ;
		b_nl();
		/* line 3345 */
b_L3345: ;
		{ bstr_t _t=b_lit("     Q=QUIT",11); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3350 */
b_L3350: ;
		b_nl();
		/* line 3355 */
b_L3355: ;
		b_wait((53265.0),(128),0);
		/* line 3360 */
b_L3360: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		/* line 3365 */
b_L3365: ;
		b_poke((198),(0));
		/* line 3370 */
b_L3370: ;
		if(-((b_v_ki) == ((64)))){ goto b_L3355; }
		/* line 3375 */
b_L3375: ;
		if(-((b_v_ki) == ((14)))){
			b_v_emi=(7);
			b_v_spi=(12);
			b_v_fpi=(2);
			goto b_L3395;
		}
		/* line 3380 */
b_L3380: ;
		if(-((b_v_ki) == ((29)))){
			b_v_emi=(2);
			b_v_spi=(6);
			b_v_fpi=(6);
			goto b_L3395;
		}
		/* line 3385 */
b_L3385: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 3390 */
b_L3390: ;
		b_v_emi=(3);
		b_v_spi=(8);
		b_v_fpi=(5);
		/* line 3395 */
b_L3395: ;
		b_putc(147);
		b_nl();
		/* line 3400 */
b_L3400: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
