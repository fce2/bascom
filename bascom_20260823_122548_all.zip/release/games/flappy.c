/* OPTIMIZE_C -- flappy.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static bint_t b_a_pxi[4];
static int b_a_pgi[4];
static breal_t b_v_rsf;
static int b_v_bci;
static int b_v_pci;
static int b_v_hfi;
static bint_t b_v_bxi;
static int b_v_gwi;
static int b_v_fpi;
static int b_v_tmi;
static int b_v_spi;
static bint_t b_v_dmi;
static int b_v_svi;
static int b_v_dfi;
static bint_t b_v_sxi;
static bint_t b_v_ddi;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_lki;
static int b_v_vpi;
static int b_v_ffi;
static int b_v_tgi;
static bint_t b_v_npi;
static int b_v_ngi;
static int b_v_ii;
static bint_t b_v_byi;
static bint_t b_v_oyi;
static bint_t b_v_ypi;
static bint_t b_v_dti;
static int b_v_sli;
static int b_v_sii;
static bint_t b_v_opi;
static bint_t b_v_cxi;
static bint_t b_v_sci;
static int b_v_ri;
static int b_v_gpi;
static int b_v_ci;
static int b_v_qmi;
static int b_v_dyi;
static bint_t b_v_ti;
static bint_t b_v_d0i;
static bint_t b_v_d1i;
static bint_t b_v_d2i;
static bstr_t b_v_ks;
static int b_v_ji;
static int b_v_li;
static int b_v_chi;
static int b_v_vti;
static int b_v_vbi;
static int b_v_vli;
static int b_v_vri;
static int b_v_hhi;
static bint_t b_v_bri;
static int b_v_g2i;
static int b_v_fi;
static int b_v_gi;
static bint_t b_v_tki;
static int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static int b_v_M3;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
static bint_t b_t_31;
static bint_t b_t_32;
static bint_t b_t_33;
static bint_t b_t_34;
static bint_t b_t_35;
static int b_fl_13;
static int b_fl_14;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 20 */
b_L20: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 22 */
b_L22: ;
		/* line 25 */
b_L25: ;
		b_v_rsf=b_rnd(B_INT((-(((B_INT(b_peek((unsigned int)((53266.0)))))+((1)))))));
		/* line 30 */
b_L30: ;
		b_v_bci=(81);
		b_v_pci=(160);
		b_v_hfi=(3);
		/* line 35 */
b_L35: ;
		b_v_bxi=(5);
		b_v_gwi=(1);
		b_v_fpi=(27);
		b_v_tmi=(64);
		b_v_spi=(16);
		b_v_dmi=(1);
		b_v_svi=(32);
		b_v_hfi=(5);
		b_v_dfi=(1);
		/* line 40 */
b_L40: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L9000;
b_ret0: ;
		/* line 42 */
b_L42: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L5600;
b_ret1: ;
		/* line 45 */
b_L45: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L5000;
b_ret2: ;
		/* line 48 */
b_L48: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L4000;
b_ret3: ;
		/* line 49 */
b_L49: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L7500;
b_ret4: ;
		/* line 100 */
b_L100: ;
		/* line 110 */
b_L110: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		/* line 120 */
b_L120: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1000;
b_ret5: ;
		/* line 122 */
b_L122: ;
		if(-((b_v_sxi) == ((1)))){
			b_v_dmi=(0);
			b_gosubStack[b_gosubSP++]=6; goto b_L5600;
b_ret6: ;
			b_gosubStack[b_gosubSP++]=7; goto b_L5500;
b_ret7: ;
			goto b_L45;
		}
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L2000;
b_ret8: ;
		/* line 140 */
b_L140: ;
		b_gosubStack[b_gosubSP++]=9; goto b_L3000;
b_ret9: ;
		/* line 150 */
b_L150: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L6000;
b_ret10: ;
		/* line 155 */
b_L155: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
		}
		/* line 156 */
b_L156: ;
		if(-((b_v_dmi) == ((0)))){
			b_poke((1060),(32));
			b_poke((1061),(32));
			b_poke((1062),(32));
			b_poke((1063),(32));
			b_poke((55332.0),(0));
			b_poke((55333.0),(0));
			b_poke((55334.0),(0));
			b_poke((55335.0),(0));
		}
		/* line 160 */
b_L160: ;
		if(-((b_v_ddi) == ((1)))){
			b_gosubStack[b_gosubSP++]=11; goto b_L7000;
b_ret11: ;
		}
		/* line 170 */
b_L170: ;
		if(-((b_v_ddi) == ((1)))){
			goto b_L45;
		}
		/* line 180 */
b_L180: ;
		goto b_L100;
		/* line 1000 */
b_L1000: ;
		/* line 1005 */
b_L1005: ;
		b_v_sxi=(0);
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 1008 */
b_L1008: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 1010 */
b_L1010: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((14)))){
				b_v_sxi=(1);
				b_v_dfi=(1);
				goto b_return;
			}
		}
		/* line 1011 */
b_L1011: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((29)))){
				b_v_sxi=(1);
				b_v_dfi=(0);
				goto b_return;
			}
		}
		/* line 1012 */
b_L1012: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=12; goto b_L1500;
b_ret12: ;
			goto b_return;
		}
		/* line 1014 */
b_L1014: ;
		if(-((b_v_ki) == ((7)))){
			if(b_v_sfi){
				b_v_ki=(60);
			}
		}
		/* line 1015 */
b_L1015: ;
		if(-((b_v_ki) == ((60)))){
			if(-((b_v_lki) != ((60)))){
				b_v_vpi=(-(b_v_fpi));
				b_v_ffi=(5);
			}
		}
		/* line 1016 */
b_L1016: ;
		b_v_lki=b_v_ki;
		/* line 1020 */
b_L1020: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1505 */
b_L1505: ;
		b_v_tgi=(12);
		b_v_npi=(41);
		b_v_ngi=(-1);
		/* line 1510 */
b_L1510: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f0_e;
b_f0_t: ;
		/* line 1515 */
b_L1515: ;
		if(-((b_a_pxi[B_INT(b_v_ii)]) < (b_v_bxi))){ goto b_L1525; }
		/* line 1520 */
b_L1520: ;
		if(-((b_a_pxi[B_INT(b_v_ii)]) < (b_v_npi))){
			b_v_npi=b_a_pxi[B_INT(b_v_ii)];
			b_v_ngi=b_v_ii;
		}
		/* line 1525 */
b_L1525: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f0_t;
b_f0_e: ;
		/* line 1530 */
b_L1530: ;
		if(-((b_v_ngi) >= ((0)))){
			b_v_tgi=b_a_pgi[B_INT(b_v_ngi)];
		}
		/* line 1535 */
b_L1535: ;
		if(-((b_v_byi) > (b_v_tgi))){
			if(-((b_v_vpi) > ((-12)))){
				b_v_vpi=(-(b_v_fpi));
				b_v_ffi=(5);
			}
		}
		/* line 1540 */
b_L1540: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		b_v_vpi=((b_v_vpi)+(b_v_gwi));
		/* line 2010 */
b_L2010: ;
		if(-((b_v_vpi) > (b_v_tmi))){
			b_v_vpi=b_v_tmi;
		}
		/* line 2015 */
b_L2015: ;
		if(-((b_v_vpi) < ((-(b_v_tmi))))){
			b_v_vpi=(-(b_v_tmi));
		}
		/* line 2020 */
b_L2020: ;
		b_v_oyi=b_v_byi;
		/* line 2025 */
b_L2025: ;
		b_v_ypi=((b_v_ypi)+(b_v_vpi));
		/* line 2030 */
b_L2030: ;
		b_v_byi=b_int(((breal_t)(b_v_ypi)/(breal_t)((128))));
		/* line 2032 */
b_L2032: ;
		if(-((b_v_byi) < ((1)))){ goto b_L2040; }
		/* line 2033 */
b_L2033: ;
		if(-((b_v_byi) > ((23)))){ goto b_L2040; }
		/* line 2035 */
b_L2035: ;
		goto b_return;
		/* line 2040 */
b_L2040: ;
		b_v_ddi=(1);
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3005 */
b_L3005: ;
		b_v_dti=((b_v_dti)+((1)));
		/* line 3007 */
b_L3007: ;
		if(-((b_v_dti) < (b_v_svi))){ goto b_L3060; }
		/* line 3008 */
b_L3008: ;
		b_v_dti=(0);
		/* line 3009 */
b_L3009: ;
		b_v_sli=(-1);
		/* line 3010 */
b_L3010: ;
		if(-((b_a_pxi[B_INT((0))]) == ((-1)))){
			b_v_sli=(0);
		}
		/* line 3011 */
b_L3011: ;
		if(-((b_a_pxi[B_INT((1))]) == ((-1)))){
			if(-((b_v_sli) == ((-1)))){
				b_v_sli=(1);
			}
		}
		/* line 3012 */
b_L3012: ;
		if(-((b_a_pxi[B_INT((2))]) == ((-1)))){
			if(-((b_v_sli) == ((-1)))){
				b_v_sli=(2);
			}
		}
		/* line 3013 */
b_L3013: ;
		if(-((b_a_pxi[B_INT((3))]) == ((-1)))){
			if(-((b_v_sli) == ((-1)))){
				b_v_sli=(3);
			}
		}
		/* line 3015 */
b_L3015: ;
		if(-((b_v_sli) == ((-1)))){ goto b_L3060; }
		/* line 3020 */
b_L3020: ;
		b_a_pxi[B_INT(b_v_sli)]=(40);
		/* line 3025 */
b_L3025: ;
		if(-((b_v_dfi) == ((1)))){
			b_a_pgi[B_INT(b_v_sli)]=(((8))+(b_int(((b_rnd(B_INT((1))))*((9))))));
		}
		/* line 3026 */
b_L3026: ;
		if(-((b_v_dfi) == ((0)))){
			b_a_pgi[B_INT(b_v_sli)]=(((4))+(b_int(((b_rnd(B_INT((1))))*((17))))));
		}
		/* line 3060 */
b_L3060: ;
		b_v_sii=(0);
		/* line 3065 */
b_L3065: ;
		if(-((b_v_sii) > ((3)))){ goto b_L3150; }
		/* line 3070 */
b_L3070: ;
		if(-((b_a_pxi[B_INT(b_v_sii)]) == ((-1)))){ goto b_L3138; }
		/* line 3072 */
b_L3072: ;
		b_v_opi=b_a_pxi[B_INT(b_v_sii)];
		/* line 3074 */
b_L3074: ;
		b_a_pxi[B_INT(b_v_sii)]=((b_v_opi)-((1)));
		/* line 3076 */
b_L3076: ;
		b_v_cxi=b_a_pxi[B_INT(b_v_sii)];
		/* line 3078 */
b_L3078: ;
		if(-((b_v_opi) >= ((0)))){
			if(-((b_v_opi) <= ((39)))){
				b_gosubStack[b_gosubSP++]=13; goto b_L3160;
b_ret13: ;
			}
		}
		/* line 3080 */
b_L3080: ;
		if(-((b_v_cxi) >= ((0)))){
			if(-((b_v_cxi) <= ((39)))){
				b_gosubStack[b_gosubSP++]=14; goto b_L3200;
b_ret14: ;
			}
		}
		/* line 3082 */
b_L3082: ;
		if(-((b_v_cxi) < ((0)))){
			b_a_pxi[B_INT(b_v_sii)]=(-1);
		}
		/* line 3090 */
b_L3090: ;
		if(-((b_a_pxi[B_INT(b_v_sii)]) != (b_v_bxi))){ goto b_L3138; }
		/* line 3092 */
b_L3092: ;
		if(-((b_v_byi) < (((b_a_pgi[B_INT(b_v_sii)])-(b_v_hfi))))){ goto b_L3380; }
		/* line 3094 */
b_L3094: ;
		if(-((b_v_byi) > (((b_a_pgi[B_INT(b_v_sii)])+(b_v_hfi))))){ goto b_L3380; }
		/* line 3096 */
b_L3096: ;
		b_v_sci=((b_v_sci)+((1)));
		b_gosubStack[b_gosubSP++]=15; goto b_L7300;
b_ret15: ;
		/* line 3138 */
b_L3138: ;
		b_v_sii=((b_v_sii)+((1)));
		goto b_L3065;
		/* line 3150 */
b_L3150: ;
		goto b_return;
		/* line 3160 */
b_L3160: ;
		/* line 3165 */
b_L3165: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f1_e;
		b_t_1=(((((1024))+(((b_v_ri)*((40))))))+(b_v_opi));
b_f1_t: ;
		b_poke(b_t_1,(32));
		b_t_1 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f1_t;
b_f1_e: ;
		/* line 3170 */
b_L3170: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3205 */
b_L3205: ;
		b_v_gpi=b_a_pgi[B_INT(b_v_sii)];
		/* line 3210 */
b_L3210: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f2_e;
		b_t_2=(((((1024))+(((b_v_ri)*((40))))))+(b_v_cxi));
		b_t_3=(((((55296.0))+(((b_v_ri)*((40))))))+(b_v_cxi));
b_f2_t: ;
		/* line 3215 */
b_L3215: ;
		if(-((b_v_ri) < (((b_v_gpi)-(b_v_hfi))))){ goto b_L3235; }
		/* line 3220 */
b_L3220: ;
		if(-((b_v_ri) > (((b_v_gpi)+(b_v_hfi))))){ goto b_L3235; }
		/* line 3225 */
b_L3225: ;
		goto b_L3240;
		/* line 3235 */
b_L3235: ;
		b_poke(b_t_2,b_v_pci);
		b_poke(b_t_3,(5));
		/* line 3240 */
b_L3240: ;
		b_t_2 += 40;
		b_t_3 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f2_t;
b_f2_e: ;
		/* line 3245 */
b_L3245: ;
		goto b_return;
		/* line 3380 */
b_L3380: ;
		b_v_ddi=(1);
		goto b_L3138;
		/* line 4000 */
b_L4000: ;
		/* line 4005 */
b_L4005: ;
		b_v_byi=(12);
		b_v_ypi=(1536);
		b_v_vpi=(0);
		b_v_oyi=(12);
		/* line 4010 */
b_L4010: ;
		b_v_ddi=(0);
		b_v_sci=(0);
		b_v_dti=(0);
		b_v_ffi=(0);
		/* line 4015 */
b_L4015: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f3_e;
b_f3_t: ;
		b_a_pxi[B_INT(b_v_ii)]=(-1);
		b_a_pgi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f3_t;
b_f3_e: ;
		/* line 4020 */
b_L4020: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f4_e;
b_f4_t: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f5_e;
		b_v_M0=(((1024))+(((b_v_ri)*((40)))));
		b_t_6=((b_v_M0)+(b_v_ci));
b_f5_t: ;
		b_poke(b_t_6,(32));
		b_t_6 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f5_t;
b_f5_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f4_t;
b_f4_e: ;
		/* line 4025 */
b_L4025: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L7300;
b_ret16: ;
		/* line 4030 */
b_L4030: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5005 */
b_L5005: ;
		b_putc(147);
		b_nl();
		/* line 5010 */
b_L5010: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 5015 */
b_L5015: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f6_e;
		b_t_7=(((1984))+(b_v_ci));
		b_t_8=(((((55296.0))+((960))))+(b_v_ci));
b_f6_t: ;
		b_poke(b_t_7,(160));
		b_poke(b_t_8,(9));
		b_t_7 += 1;
		b_t_8 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f6_t;
b_f6_e: ;
		/* line 5030 */
b_L5030: ;
		b_poke((1024),(19));
		b_poke((1025),(3));
		b_poke((1026),(15));
		b_poke((1027),(18));
		b_poke((1028),(5));
		/* line 5035 */
b_L5035: ;
		b_poke((((55296.0))+((0))),(7));
		b_poke((((55296.0))+((1))),(7));
		b_poke((((55296.0))+((2))),(7));
		b_poke((((55296.0))+((3))),(7));
		b_poke((((55296.0))+((4))),(7));
		/* line 5045 */
b_L5045: ;
		b_poke((1057),(32));
		b_poke((1058),(32));
		b_poke((1059),(32));
		b_poke((1060),(32));
		b_poke((1061),(32));
		b_poke((1062),(32));
		b_poke((1063),(32));
		/* line 5046 */
b_L5046: ;
		b_poke((55329.0),(0));
		b_poke((55330.0),(0));
		b_poke((55331.0),(0));
		b_poke((55332.0),(0));
		b_poke((55333.0),(0));
		b_poke((55334.0),(0));
		b_poke((55335.0),(0));
		/* line 5048 */
b_L5048: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L5500;
b_ret17: ;
		/* line 5050 */
b_L5050: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5505 */
b_L5505: ;
		b_v_qmi=(973);
		/* line 5510 */
b_L5510: ;
		if(-((b_v_dmi) == ((0)))){
			b_v_ii=(0);
			if(b_v_ii > 13) goto b_f7_e;
			b_t_9=(((((1024))+(b_v_qmi)))+(b_v_ii));
			b_t_10=(((((55296.0))+(b_v_qmi)))+(b_v_ii));
b_f7_t: ;
			b_poke(b_t_9,(160));
			b_poke(b_t_10,(9));
			b_t_9 += 1;
			b_t_10 += 1;
			b_v_ii += 1;
			if(b_v_ii <= 13) goto b_f7_t;
b_f7_e: ;
			goto b_return;
		}
		/* line 5520 */
b_L5520: ;
		b_poke((((1024))+(b_v_qmi)),(5));
		b_poke((((((1024))+(b_v_qmi)))+((1))),(61));
		b_poke((((((1024))+(b_v_qmi)))+((2))),(5));
		b_poke((((((1024))+(b_v_qmi)))+((3))),(1));
		b_poke((((((1024))+(b_v_qmi)))+((4))),(19));
		b_poke((((((1024))+(b_v_qmi)))+((5))),(25));
		/* line 5525 */
b_L5525: ;
		b_poke((((((1024))+(b_v_qmi)))+((6))),(32));
		b_poke((((((1024))+(b_v_qmi)))+((7))),(32));
		b_poke((((((1024))+(b_v_qmi)))+((8))),(8));
		b_poke((((((1024))+(b_v_qmi)))+((9))),(61));
		/* line 5530 */
b_L5530: ;
		b_poke((((((1024))+(b_v_qmi)))+((10))),(8));
		b_poke((((((1024))+(b_v_qmi)))+((11))),(1));
		b_poke((((((1024))+(b_v_qmi)))+((12))),(18));
		b_poke((((((1024))+(b_v_qmi)))+((13))),(4));
		/* line 5535 */
b_L5535: ;
		b_v_ii=(0);
		if(b_v_ii > 13) goto b_f8_e;
		b_t_11=(((((55296.0))+(b_v_qmi)))+(b_v_ii));
b_f8_t: ;
		b_poke(b_t_11,(7));
		b_t_11 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 13) goto b_f8_t;
b_f8_e: ;
		/* line 5540 */
b_L5540: ;
		goto b_return;
		/* line 5600 */
b_L5600: ;
		/* line 5605 */
b_L5605: ;
		if(-((b_v_dfi) == ((1)))){
			b_v_svi=(32);
			b_v_hfi=(5);
			goto b_return;
		}
		/* line 5610 */
b_L5610: ;
		b_v_svi=b_v_spi;
		b_v_hfi=(3);
		goto b_return;
		/* line 6000 */
b_L6000: ;
		/* line 6005 */
b_L6005: ;
		b_v_dyi=b_v_byi;
		if(-((b_v_dyi) < ((1)))){
			b_v_dyi=(1);
		}
		/* line 6008 */
b_L6008: ;
		if(-((b_v_dyi) > ((23)))){
			b_v_dyi=(23);
		}
		/* line 6010 */
b_L6010: ;
		if(-((b_v_oyi) >= ((1)))){
			if(-((b_v_oyi) <= ((23)))){
				b_poke((((((1024))+(((b_v_oyi)*((40))))))+(b_v_bxi)),(32));
			}
		}
		/* line 6015 */
b_L6015: ;
		b_poke((((((1024))+(((b_v_dyi)*((40))))))+(b_v_bxi)),b_v_bci);
		/* line 6020 */
b_L6020: ;
		if(-((b_v_ffi) > ((0)))){
			b_poke((((((55296.0))+(((b_v_dyi)*((40))))))+(b_v_bxi)),(2));
			b_v_ffi=((b_v_ffi)-((1)));
			goto b_return;
		}
		/* line 6025 */
b_L6025: ;
		b_poke((((((55296.0))+(((b_v_dyi)*((40))))))+(b_v_bxi)),(7));
		/* line 6030 */
b_L6030: ;
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7001 */
b_L7001: ;
		b_gosubStack[b_gosubSP++]=18; goto b_L7100;
b_ret18: ;
		/* line 7002 */
b_L7002: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f9_e;
b_f9_t: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f10_e;
		b_v_M1=(((1024))+(((b_v_ri)*((40)))));
		b_t_12=((b_v_M1)+(b_v_ci));
b_f10_t: ;
		b_poke(b_t_12,(32));
		b_t_12 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f10_t;
b_f10_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f9_t;
b_f9_e: ;
		/* line 7005 */
b_L7005: ;
		b_poke((1439),(7));
		b_poke((1440),(1));
		b_poke((1441),(13));
		b_poke((1442),(5));
		b_poke((1443),(32));
		/* line 7006 */
b_L7006: ;
		b_poke((1444),(15));
		b_poke((1445),(22));
		b_poke((1446),(5));
		b_poke((1447),(18));
		/* line 7010 */
b_L7010: ;
		b_poke((1517),(19));
		b_poke((1518),(3));
		b_poke((1519),(15));
		b_poke((1520),(18));
		b_poke((1521),(5));
		b_poke((1522),(58));
		/* line 7011 */
b_L7011: ;
		b_v_ti=b_v_sci;
		b_v_d0i=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_d1i=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_d2i=b_v_ti;
		/* line 7012 */
b_L7012: ;
		b_poke((1523),(((48))+(b_v_d2i)));
		b_poke((1524),(((48))+(b_v_d1i)));
		b_poke((1525),(((48))+(b_v_d0i)));
		/* line 7014 */
b_L7014: ;
		if(-((b_v_dmi) == ((1)))){ goto b_L7030; }
		/* line 7015 */
b_L7015: ;
		b_poke((1595),(18));
		b_poke((1596),(61));
		b_poke((1597),(18));
		b_poke((1598),(5));
		b_poke((1599),(19));
		/* line 7016 */
b_L7016: ;
		b_poke((1600),(20));
		b_poke((1601),(1));
		b_poke((1602),(18));
		b_poke((1603),(20));
		b_poke((1604),(32));
		/* line 7017 */
b_L7017: ;
		b_poke((1605),(32));
		b_poke((1606),(17));
		b_poke((1607),(61));
		b_poke((1608),(17));
		b_poke((1609),(21));
		/* line 7018 */
b_L7018: ;
		b_poke((1610),(9));
		b_poke((1611),(20));
		/* line 7020 */
b_L7020: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L7020; }
		/* line 7022 */
b_L7022: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_return;
		}
		/* line 7023 */
b_L7023: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 7024 */
b_L7024: ;
		goto b_L7020;
		/* line 7030 */
b_L7030: ;
		/* line 7032 */
b_L7032: ;
		b_poke((1596),(19));
		b_poke((1597),(16));
		b_poke((1598),(1));
		b_poke((1599),(3));
		b_poke((1600),(5));
		/* line 7033 */
b_L7033: ;
		b_poke((1601),(32));
		b_poke((1602),(20));
		b_poke((1603),(15));
		b_poke((1604),(32));
		b_poke((1605),(16));
		/* line 7034 */
b_L7034: ;
		b_poke((1606),(12));
		b_poke((1607),(1));
		b_poke((1608),(25));
		/* line 7036 */
b_L7036: ;
		b_v_ji=(1);
		if(b_v_ji > 90) goto b_f11_e;
b_f11_t: ;
		b_wait((53265.0),(128),0);
		b_v_ji += 1;
		if(b_v_ji <= 90) goto b_f11_t;
b_f11_e: ;
		/* line 7038 */
b_L7038: ;
		goto b_return;
		/* line 7100 */
b_L7100: ;
		/* line 7110 */
b_L7110: ;
		b_v_li=(1);
		if(b_v_li > 6) goto b_f12_e;
b_f12_t: ;
		/* line 7115 */
b_L7115: ;
		b_v_chi=(42);
		if(-((b_v_li) >= ((4)))){
			b_v_chi=(46);
		}
		/* line 7120 */
b_L7120: ;
		b_v_vti=((b_v_dyi)-(b_v_li));
		if(-((b_v_vti) < ((1)))){
			b_v_vti=(1);
		}
		/* line 7125 */
b_L7125: ;
		b_v_vbi=((b_v_dyi)+(b_v_li));
		if(-((b_v_vbi) > ((23)))){
			b_v_vbi=(23);
		}
		/* line 7130 */
b_L7130: ;
		b_v_vli=((b_v_bxi)-(b_v_li));
		if(-((b_v_vli) < ((0)))){
			b_v_vli=(0);
		}
		/* line 7135 */
b_L7135: ;
		b_v_vri=((b_v_bxi)+(b_v_li));
		if(-((b_v_vri) > ((39)))){
			b_v_vri=(39);
		}
		/* line 7140 */
b_L7140: ;
		b_v_ci=b_v_vli;
		b_fl_13=b_v_vri;
		if(b_v_ci > b_fl_13) goto b_f13_e;
		b_v_M2=(((1024))+(((b_v_dyi)*((40)))));
		b_v_M3=((b_v_dyi)*((40)));
		b_t_13=((b_v_M2)+(b_v_ci));
		b_t_14=(((((55296.0))+(b_v_M3)))+(b_v_ci));
b_f13_t: ;
		b_poke(b_t_13,b_v_chi);
		b_poke(b_t_14,(2));
		b_t_13 += 1;
		b_t_14 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_13)) goto b_f13_t;
b_f13_e: ;
		/* line 7145 */
b_L7145: ;
		b_v_ki=b_v_vti;
		b_fl_14=b_v_vbi;
		if(b_v_ki > b_fl_14) goto b_f14_e;
		b_t_15=(((((1024))+(((b_v_ki)*((40))))))+(b_v_bxi));
		b_t_16=(((((55296.0))+(((b_v_ki)*((40))))))+(b_v_bxi));
b_f14_t: ;
		b_poke(b_t_15,b_v_chi);
		b_poke(b_t_16,(2));
		b_t_15 += 40;
		b_t_16 += 40;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_14)) goto b_f14_t;
b_f14_e: ;
		/* line 7150 */
b_L7150: ;
		b_v_ji=(1);
		if(b_v_ji > 1000) goto b_f15_e;
b_f15_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 1000) goto b_f15_t;
b_f15_e: ;
		/* line 7155 */
b_L7155: ;
		b_v_li += 1;
		if(b_v_li <= 6) goto b_f12_t;
b_f12_e: ;
		/* line 7160 */
b_L7160: ;
		b_poke((((((1024))+(((b_v_dyi)*((40))))))+(b_v_bxi)),b_v_bci);
		b_poke((((((55296.0))+(((b_v_dyi)*((40))))))+(b_v_bxi)),(7));
		/* line 7165 */
b_L7165: ;
		b_v_ji=(1);
		if(b_v_ji > 2000) goto b_f16_e;
b_f16_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 2000) goto b_f16_t;
b_f16_e: ;
		/* line 7170 */
b_L7170: ;
		goto b_return;
		/* line 7300 */
b_L7300: ;
		/* line 7305 */
b_L7305: ;
		b_v_ti=b_v_sci;
		/* line 7310 */
b_L7310: ;
		b_v_d0i=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		/* line 7315 */
b_L7315: ;
		b_v_d1i=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		/* line 7320 */
b_L7320: ;
		b_v_d2i=b_v_ti;
		/* line 7325 */
b_L7325: ;
		b_poke((1030),(((48))+(b_v_d2i)));
		b_poke((1031),(((48))+(b_v_d1i)));
		b_poke((1032),(((48))+(b_v_d0i)));
		/* line 7330 */
b_L7330: ;
		goto b_return;
		/* line 7500 */
b_L7500: ;
		/* line 7505 */
b_L7505: ;
		if(-((b_v_dmi) == ((1)))){
			goto b_return;
		}
		/* line 7510 */
b_L7510: ;
		b_poke((1519),(7));
		b_poke((1520),(5));
		b_poke((1521),(20));
		b_poke((1522),(32));
		b_poke((1523),(18));
		/* line 7515 */
b_L7515: ;
		b_poke((1524),(5));
		b_poke((1525),(1));
		b_poke((1526),(4));
		b_poke((1527),(25));
		/* line 7520 */
b_L7520: ;
		b_v_ji=(1);
		if(b_v_ji > 60) goto b_f17_e;
b_f17_t: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		b_v_ji += 1;
		if(b_v_ji <= 60) goto b_f17_t;
b_f17_e: ;
		/* line 7525 */
b_L7525: ;
		b_v_ci=(15);
		if(b_v_ci > 23) goto b_f18_e;
b_f18_t: ;
		b_poke((((1504))+(b_v_ci)),(32));
		b_v_ci += 1;
		if(b_v_ci <= 23) goto b_f18_t;
b_f18_e: ;
		/* line 7530 */
b_L7530: ;
		goto b_return;
		/* line 9000 */
b_L9000: ;
		/* line 9005 */
b_L9005: ;
		b_putc(147);
		b_nl();
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 9010 */
b_L9010: ;
		b_v_hhi=(0);
		if(b_v_hhi > 39) goto b_f19_e;
		b_t_17=(((1024))+(b_v_hhi));
		b_t_18=(((55296.0))+(b_v_hhi));
b_f19_t: ;
		b_poke(b_t_17,(160));
		b_poke(b_t_18,(7));
		b_t_17 += 1;
		b_t_18 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 39) goto b_f19_t;
b_f19_e: ;
		/* line 9015 */
b_L9015: ;
		b_v_hhi=(0);
		if(b_v_hhi > 39) goto b_f20_e;
		b_t_19=(((1984))+(b_v_hhi));
		b_t_20=(((((55296.0))+((960))))+(b_v_hhi));
b_f20_t: ;
		b_poke(b_t_19,(160));
		b_poke(b_t_20,(7));
		b_t_19 += 1;
		b_t_20 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 39) goto b_f20_t;
b_f20_e: ;
		/* line 9020 */
b_L9020: ;
		b_v_hhi=(3);
		if(b_v_hhi > 36) goto b_f21_e;
		b_t_21=(((1144))+(b_v_hhi));
		b_t_22=(((((55296.0))+((120))))+(b_v_hhi));
b_f21_t: ;
		b_poke(b_t_21,(81));
		b_poke(b_t_22,(5));
		b_t_21 += 1;
		b_t_22 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 36) goto b_f21_t;
b_f21_e: ;
		/* line 9022 */
b_L9022: ;
		b_v_hhi=(3);
		if(b_v_hhi > 36) goto b_f22_e;
		b_t_23=(((1544))+(b_v_hhi));
		b_t_24=(((((55296.0))+((520))))+(b_v_hhi));
b_f22_t: ;
		b_poke(b_t_23,(87));
		b_poke(b_t_24,(5));
		b_t_23 += 1;
		b_t_24 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 36) goto b_f22_t;
b_f22_e: ;
		/* line 9025 */
b_L9025: ;
		b_poke((214),(4));
		b_nl();
		b_tab((12));
		{ bstr_t _t=b_lit("** FLAPPY **",12); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9028 */
b_L9028: ;
		b_poke((214),(6));
		b_nl();
		b_tab((10));
		{ bstr_t _t=b_lit("TAP SPACE TO FLAP",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9030 */
b_L9030: ;
		b_poke((214),(8));
		b_nl();
		b_tab((8));
		{ bstr_t _t=b_lit("AVOID THE GREEN PIPES",21); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9032 */
b_L9032: ;
		b_poke((214),(10));
		b_nl();
		b_tab((16));
		{ bstr_t _t=b_lit("Q = QUIT",8); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9034 */
b_L9034: ;
		b_poke((214),(14));
		b_nl();
		b_tab((8));
		{ bstr_t _t=b_lit("CHOOSE:  E=EASY   H=HARD",24); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9036 */
b_L9036: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f23_e;
		b_t_25=(((((55296.0))+((200))))+(b_v_hhi));
b_f23_t: ;
		b_poke(b_t_25,(7));
		b_t_25 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f23_t;
b_f23_e: ;
		/* line 9038 */
b_L9038: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f24_e;
		b_t_26=(((((55296.0))+((280))))+(b_v_hhi));
b_f24_t: ;
		b_poke(b_t_26,(3));
		b_t_26 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f24_t;
b_f24_e: ;
		/* line 9040 */
b_L9040: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f25_e;
		b_t_27=(((((55296.0))+((360))))+(b_v_hhi));
b_f25_t: ;
		b_poke(b_t_27,(5));
		b_t_27 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f25_t;
b_f25_e: ;
		/* line 9042 */
b_L9042: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f26_e;
		b_t_28=(((((55296.0))+((440))))+(b_v_hhi));
b_f26_t: ;
		b_poke(b_t_28,(7));
		b_t_28 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f26_t;
b_f26_e: ;
		/* line 9044 */
b_L9044: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f27_e;
		b_t_29=(((((55296.0))+((600))))+(b_v_hhi));
b_f27_t: ;
		b_poke(b_t_29,(1));
		b_t_29 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f27_t;
b_f27_e: ;
		/* line 9046 */
b_L9046: ;
		b_v_hhi=(17);
		if(b_v_hhi > 22) goto b_f28_e;
		b_t_30=(((((55296.0))+((600))))+(b_v_hhi));
b_f28_t: ;
		b_poke(b_t_30,(5));
		b_t_30 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 22) goto b_f28_t;
b_f28_e: ;
		/* line 9048 */
b_L9048: ;
		b_v_hhi=(26);
		if(b_v_hhi > 31) goto b_f29_e;
		b_t_31=(((((55296.0))+((600))))+(b_v_hhi));
b_f29_t: ;
		b_poke(b_t_31,(2));
		b_t_31 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 31) goto b_f29_t;
b_f29_e: ;
		/* line 9050 */
b_L9050: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f30_e;
		b_t_32=(((1024))+(((b_v_ri)*((40)))));
		b_t_33=(((55296.0))+(((b_v_ri)*((40)))));
		b_t_34=(((((1024))+(((b_v_ri)*((40))))))+((39)));
		b_t_35=(((((55296.0))+(((b_v_ri)*((40))))))+((39)));
b_f30_t: ;
		b_poke(b_t_32,(102));
		b_poke(b_t_33,(7));
		b_poke(b_t_34,(102));
		b_poke(b_t_35,(7));
		b_t_32 += 40;
		b_t_33 += 40;
		b_t_34 += 40;
		b_t_35 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f30_t;
b_f30_e: ;
		/* line 9055 */
b_L9055: ;
		b_v_bri=(16);
		b_v_g2i=(0);
		/* line 9060 */
b_L9060: ;
		b_v_fi=(1);
		if(b_v_fi > 16) goto b_f31_e;
b_f31_t: ;
		/* line 9065 */
b_L9065: ;
		b_v_gi=(81);
		if(-((b_v_g2i) == ((0)))){
			b_v_gi=(87);
		}
		/* line 9068 */
b_L9068: ;
		b_v_g2i=(((1))-(b_v_g2i));
		/* line 9070 */
b_L9070: ;
		b_poke((((1744))+(b_v_bri)),b_v_gi);
		b_poke((((((55296.0))+((720))))+(b_v_bri)),(7));
		/* line 9075 */
b_L9075: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		/* line 9080 */
b_L9080: ;
		b_poke((((1744))+(b_v_bri)),(32));
		/* line 9085 */
b_L9085: ;
		b_v_bri=((b_v_bri)+((1)));
		if(-((b_v_bri) > ((22)))){
			b_v_bri=(16);
		}
		/* line 9090 */
b_L9090: ;
		b_v_fi += 1;
		if(b_v_fi <= 16) goto b_f31_t;
b_f31_e: ;
		/* line 9095 */
b_L9095: ;
		b_poke((198),(0));
		b_v_tki=(0);
		/* line 9100 */
b_L9100: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("E",1)) == 0)){
			b_v_dfi=(1);
			b_v_dmi=(0);
			goto b_L9130;
		}
		/* line 9105 */
b_L9105: ;
		if(-(b_strcmp(b_v_ks,b_lit("H",1)) == 0)){
			b_v_dfi=(0);
			b_v_dmi=(0);
			goto b_L9130;
		}
		/* line 9108 */
b_L9108: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 9110 */
b_L9110: ;
		b_v_tki=((b_v_tki)+((1)));
		if(-((b_v_tki) > ((240)))){
			b_v_dfi=(1);
			b_v_dmi=(1);
			goto b_L9130;
		}
		/* line 9112 */
b_L9112: ;
		b_wait((53265.0),(128),(128));
		b_wait((53265.0),(128),0);
		/* line 9115 */
b_L9115: ;
		goto b_L9100;
		/* line 9130 */
b_L9130: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
