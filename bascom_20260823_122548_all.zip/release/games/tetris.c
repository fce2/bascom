/* OPTIMIZE_C -- tetris.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_a_bi[200];
static int b_a_bci[200];
static int b_a_fbi[200];
static int b_v_ii;
static int b_a_pxi[4];
static int b_a_pyi[4];
static int b_a_oxi[4];
static int b_a_oyi[4];
static int b_a_nxi[4];
static int b_a_nyi[4];
static int b_a_txi[4];
static int b_a_tyi[4];
static bint_t b_a_di[5];
static int b_a_pci[7];
static int b_v_shi;
static unsigned int b_v_chi;
static bint_t b_a_bgi[7];
static bint_t b_v_bii;
static bint_t b_v_npi;
static int b_v_dmi;
static bint_t b_v_sci;
static int b_v_lvi;
static bint_t b_v_lni;
static int b_v_dli;
static int b_v_ogi;
static int b_v_rfi;
static int b_v_gvi;
static int b_v_ki;
static int b_v_sfi;
static bint_t b_v_bxi;
static bint_t b_v_cli;
static bint_t b_v_lki;
static bint_t b_v_byi;
static bint_t b_v_gdi;
static int b_v_ji;
static bint_t b_v_pni;
static bint_t b_v_dri;
static bint_t b_v_ppi;
static int b_v_cpi;
static bint_t b_v_ri;
static bint_t b_v_ci;
static bint_t b_v_rbi;
static bint_t b_v_vi;
static int b_v_cci;
static int b_v_fi;
static bint_t b_v_rri;
static int b_v_vci;
static bint_t b_v_pri;
static bint_t b_v_qci;
static int b_v_hxi;
static int b_v_hyi;
static bstr_t b_v_ts;
static bint_t b_v_ti;
static bint_t b_v_li;
static bint_t b_v_hhi;
static bint_t b_v_tgi;
static bstr_t b_v_ks;
static bint_t b_v_dci;
static bint_t b_v_mpi;
static bint_t b_v_hi;
static int b_v_cti;
static bint_t b_v_M0;
static bint_t b_v_M1;
static bint_t b_v_M2;
static bint_t b_v_M3;
static bint_t b_v_M4;
static int b_v_M5;
static int b_v_M6;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
static bint_t b_t_31;
static bint_t b_t_32;
static bint_t b_t_33;
static bint_t b_t_34;
static bint_t b_t_35;
static bint_t b_t_36;
static bint_t b_t_37;
static bint_t b_t_38;
static bint_t b_t_39;
static bint_t b_t_40;
static bint_t b_t_41;
static bint_t b_t_42;
static bint_t b_t_43;
static bint_t b_t_44;
static bint_t b_t_45;
static bint_t b_t_46;
static bint_t b_t_47;
static bint_t b_t_48;
static bint_t b_t_49;
static int b_fl_31;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 13 */
b_L13: ;
		/* line 14 */
b_L14: ;
		/* line 15 */
b_L15: ;
		/* line 16 */
b_L16: ;
		/* line 20 */
b_L20: ;
		b_putc(147);
		b_nl();
		/* line 25 */
b_L25: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 30 */
b_L30: ;
		b_v_ii=(0);
		if(b_v_ii > 199) goto b_f0_e;
b_f0_t: ;
		b_a_bi[B_INT(b_v_ii)]=(0);
		b_a_bci[B_INT(b_v_ii)]=(0);
		b_a_fbi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 199) goto b_f0_t;
b_f0_e: ;
		/* line 32 */
b_L32: ;
		/* line 34 */
b_L34: ;
		b_a_pci[B_INT((0))]=(3);
		b_a_pci[B_INT((1))]=(7);
		b_a_pci[B_INT((2))]=(4);
		b_a_pci[B_INT((3))]=(5);
		b_a_pci[B_INT((4))]=(2);
		b_a_pci[B_INT((5))]=(6);
		b_a_pci[B_INT((6))]=(8);
		/* line 36 */
b_L36: ;
		b_v_shi=(1105);
		b_v_chi=(55377.0);
		/* line 37 */
b_L37: ;
		b_v_ii=(0);
		if(b_v_ii > 6) goto b_f1_e;
b_f1_t: ;
		b_a_bgi[B_INT(b_v_ii)]=b_v_ii;
		b_v_ii += 1;
		if(b_v_ii <= 6) goto b_f1_t;
b_f1_e: ;
		b_v_bii=(7);
		b_v_npi=(0);
		/* line 38 */
b_L38: ;
		b_v_dmi=(1);
		/* line 40 */
b_L40: ;
		b_v_sci=(0);
		b_v_lvi=(1);
		b_v_lni=(0);
		b_v_dli=(24);
		b_v_ogi=(0);
		b_v_rfi=(1);
		b_v_gvi=(0);
		/* line 42 */
b_L42: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L8200;
b_ret0: ;
		/* line 43 */
b_L43: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L8000;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L7000;
b_ret2: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L2000;
b_ret3: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L7200;
b_ret4: ;
		/* line 50 */
b_L50: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L5900;
b_ret5: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L5800;
b_ret6: ;
		b_v_rfi=(0);
		/* line 60 */
b_L60: ;
		/* line 65 */
b_L65: ;
		if(-((b_v_gvi) == ((1)))){ goto b_L8500; }
		/* line 70 */
b_L70: ;
		if(-((b_v_ogi) == ((1)))){ goto b_L1000; }
		/* line 75 */
b_L75: ;
		if(-((b_v_rfi) == ((1)))){
			b_gosubStack[b_gosubSP++]=7; goto b_L5900;
b_ret7: ;
			b_gosubStack[b_gosubSP++]=8; goto b_L5800;
b_ret8: ;
			b_gosubStack[b_gosubSP++]=9; goto b_L7200;
b_ret9: ;
			b_v_rfi=(0);
		}
		/* line 90 */
b_L90: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 92 */
b_L92: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) != ((64)))){
				b_v_dmi=(0);
			}
		}
		/* line 95 */
b_L95: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=10; goto b_L9500;
b_ret10: ;
		}
		/* line 96 */
b_L96: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 97 */
b_L97: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 100 */
b_L100: ;
		if(-((b_v_ki) == ((10)))){
			b_v_bxi=((b_v_bxi)-((1)));
			b_gosubStack[b_gosubSP++]=11; goto b_L3100;
b_ret11: ;
			if(-((b_v_cli) == ((1)))){
				b_v_bxi=((b_v_bxi)+((1)));
			}
		}
		/* line 105 */
b_L105: ;
		if(-((b_v_ki) == ((10)))){
			b_v_rfi=(1);
		}
		/* line 110 */
b_L110: ;
		if(-((b_v_ki) == ((18)))){
			b_v_bxi=((b_v_bxi)+((1)));
			b_gosubStack[b_gosubSP++]=12; goto b_L3100;
b_ret12: ;
			if(-((b_v_cli) == ((1)))){
				b_v_bxi=((b_v_bxi)-((1)));
			}
		}
		/* line 115 */
b_L115: ;
		if(-((b_v_ki) == ((18)))){
			b_v_rfi=(1);
		}
		/* line 120 */
b_L120: ;
		if(-((b_v_ki) == ((9)))){
			if(-((b_v_lki) != ((9)))){
				b_gosubStack[b_gosubSP++]=13; goto b_L4000;
b_ret13: ;
				b_v_rfi=(1);
			}
		}
		/* line 125 */
b_L125: ;
		if(-((b_v_ki) == ((62)))){ goto b_L8500; }
		/* line 127 */
b_L127: ;
		if(-((b_v_ki) == ((60)))){
			b_v_byi=((b_v_byi)+((1)));
			b_gosubStack[b_gosubSP++]=14; goto b_L3100;
b_ret14: ;
			if(-((b_v_cli) == ((1)))){
				b_v_byi=((b_v_byi)-((1)));
				b_gosubStack[b_gosubSP++]=15; goto b_L5000;
b_ret15: ;
				goto b_L70;
			}
		}
		/* line 128 */
b_L128: ;
		if(-((b_v_ki) == ((60)))){
			b_v_rfi=(1);
		}
		/* line 130 */
b_L130: ;
		if(-((b_v_ki) == ((13)))){
			if(-((b_v_lki) != ((13)))){
				b_v_lki=b_v_ki;
				b_gosubStack[b_gosubSP++]=16; goto b_L6300;
b_ret16: ;
				goto b_L70;
			}
		}
		/* line 135 */
b_L135: ;
		b_v_lki=b_v_ki;
		/* line 140 */
b_L140: ;
		b_v_gdi=((b_v_gdi)-((1)));
		/* line 150 */
b_L150: ;
		if(-((b_v_gdi) > ((0)))){ goto b_L70; }
		/* line 160 */
b_L160: ;
		b_v_gdi=b_v_dli;
		b_v_byi=((b_v_byi)+((1)));
		b_gosubStack[b_gosubSP++]=17; goto b_L3100;
b_ret17: ;
		if(-((b_v_cli) == ((1)))){
			b_v_byi=((b_v_byi)-((1)));
			b_gosubStack[b_gosubSP++]=18; goto b_L5000;
b_ret18: ;
			goto b_L70;
		}
		/* line 165 */
b_L165: ;
		b_v_rfi=(1);
		/* line 180 */
b_L180: ;
		goto b_L70;
		/* line 1000 */
b_L1000: ;
		/* line 1005 */
b_L1005: ;
		b_v_ogi=(0);
		/* line 1010 */
b_L1010: ;
		b_poke((54296.0),(15));
		b_poke((54273.0),(40));
		b_poke((54277.0),(0));
		b_poke((54278.0),(8));
		b_poke((54276.0),(65));
		/* line 1020 */
b_L1020: ;
		b_v_ji=(1);
		if(b_v_ji > 200) goto b_f2_e;
b_f2_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 200) goto b_f2_t;
b_f2_e: ;
		/* line 1030 */
b_L1030: ;
		b_poke((54276.0),(64));
		/* line 1040 */
b_L1040: ;
		b_v_gvi=(1);
		/* line 1050 */
b_L1050: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		b_v_pni=b_v_npi;
		/* line 2010 */
b_L2010: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L9600;
b_ret19: ;
		b_v_npi=b_v_dri;
		/* line 2015 */
b_L2015: ;
		b_v_ppi=b_v_pni;
		b_gosubStack[b_gosubSP++]=20; goto b_L9100;
b_ret20: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f3_e;
b_f3_t: ;
		b_a_pxi[B_INT(b_v_ii)]=b_a_txi[B_INT(b_v_ii)];
		b_a_pyi[B_INT(b_v_ii)]=b_a_tyi[B_INT(b_v_ii)];
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f3_t;
b_f3_e: ;
		/* line 2020 */
b_L2020: ;
		b_v_ppi=b_v_npi;
		b_gosubStack[b_gosubSP++]=21; goto b_L9100;
b_ret21: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f4_e;
b_f4_t: ;
		b_a_nxi[B_INT(b_v_ii)]=b_a_txi[B_INT(b_v_ii)];
		b_a_nyi[B_INT(b_v_ii)]=b_a_tyi[B_INT(b_v_ii)];
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f4_t;
b_f4_e: ;
		/* line 2030 */
b_L2030: ;
		b_v_cpi=b_a_pci[B_INT(b_v_pni)];
		b_v_bxi=(3);
		b_v_byi=(0);
		b_v_gdi=b_v_dli;
		/* line 2040 */
b_L2040: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L3100;
b_ret22: ;
		if(-((b_v_cli) == ((1)))){
			b_gosubStack[b_gosubSP++]=23; goto b_L1000;
b_ret23: ;
		}
		/* line 2045 */
b_L2045: ;
		b_v_rfi=(1);
		/* line 2050 */
b_L2050: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3110 */
b_L3110: ;
		b_v_cli=(0);
		/* line 3120 */
b_L3120: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f5_e;
b_f5_t: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 3130 */
b_L3130: ;
		if(-((b_v_ci) < ((0)))){
			b_v_cli=(1);
		}
		/* line 3140 */
b_L3140: ;
		if(-((b_v_ci) > ((9)))){
			b_v_cli=(1);
		}
		/* line 3150 */
b_L3150: ;
		if(-((b_v_ri) > ((19)))){
			b_v_cli=(1);
		}
		/* line 3160 */
b_L3160: ;
		if(-((b_v_cli) == ((0)))){
			if(-((b_v_ri) >= ((0)))){
				if(-((b_a_bi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]) == ((1)))){
					b_v_cli=(1);
				}
			}
		}
		/* line 3170 */
b_L3170: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f5_t;
b_f5_e: ;
		/* line 3180 */
b_L3180: ;
		goto b_return;
		/* line 4000 */
b_L4000: ;
		/* line 4010 */
b_L4010: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f6_e;
b_f6_t: ;
		b_a_oxi[B_INT(b_v_ii)]=b_a_pxi[B_INT(b_v_ii)];
		b_a_oyi[B_INT(b_v_ii)]=b_a_pyi[B_INT(b_v_ii)];
		/* line 4020 */
b_L4020: ;
		b_a_pxi[B_INT(b_v_ii)]=(((3))-(b_a_pyi[B_INT(b_v_ii)]));
		b_a_pyi[B_INT(b_v_ii)]=b_a_oxi[B_INT(b_v_ii)];
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f6_t;
b_f6_e: ;
		/* line 4030 */
b_L4030: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L3100;
b_ret24: ;
		/* line 4040 */
b_L4040: ;
		if(-((b_v_cli) == ((1)))){
			b_v_ii=(0);
			if(b_v_ii > 3) goto b_f7_e;
b_f7_t: ;
			b_a_pxi[B_INT(b_v_ii)]=b_a_oxi[B_INT(b_v_ii)];
			b_a_pyi[B_INT(b_v_ii)]=b_a_oyi[B_INT(b_v_ii)];
			b_v_ii += 1;
			if(b_v_ii <= 3) goto b_f7_t;
b_f7_e: ;
		}
		/* line 4050 */
b_L4050: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5010 */
b_L5010: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f8_e;
b_f8_t: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 5011 */
b_L5011: ;
		if(-((b_v_ri) >= ((0)))){
			if(-((b_v_ri) < ((20)))){
				if(-((b_v_ci) >= ((0)))){
					if(-((b_v_ci) < ((10)))){
						b_a_bi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]=(1);
						b_a_bci[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]=b_v_cpi;
					}
				}
			}
		}
		/* line 5020 */
b_L5020: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f8_t;
b_f8_e: ;
		/* line 5030 */
b_L5030: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L6000;
b_ret25: ;
		/* line 5040 */
b_L5040: ;
		b_gosubStack[b_gosubSP++]=26; goto b_L2000;
b_ret26: ;
		/* line 5050 */
b_L5050: ;
		goto b_return;
		/* line 5800 */
b_L5800: ;
		/* line 5810 */
b_L5810: ;
		b_v_ri=(0);
		if(b_v_ri > 19) goto b_f9_e;
b_f9_t: ;
		/* line 5815 */
b_L5815: ;
		b_v_rbi=((b_v_ri)*((10)));
		/* line 5820 */
b_L5820: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f10_e;
		b_t_24=((((b_v_shi)+(((b_v_ri)*((40))))))+(b_v_ci));
		b_t_25=((((b_v_chi)+(((b_v_ri)*((40))))))+(b_v_ci));
b_f10_t: ;
		/* line 5825 */
b_L5825: ;
		b_v_vi=b_a_fbi[B_INT(((b_v_rbi)+(b_v_ci)))];
		/* line 5830 */
b_L5830: ;
		if(-((b_v_vi) == ((0)))){
			b_poke(b_t_24,(32));
			b_poke(b_t_25,(0));
			goto b_L5845;
		}
		/* line 5835 */
b_L5835: ;
		b_v_cci=b_a_bci[B_INT(((b_v_rbi)+(b_v_ci)))];
		if(-((b_v_vi) == ((2)))){
			b_v_cci=b_v_cpi;
		}
		/* line 5840 */
b_L5840: ;
		b_poke(b_t_24,(81));
		b_poke(b_t_25,b_v_cci);
		/* line 5845 */
b_L5845: ;
		b_t_24 += 1;
		b_t_25 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f10_t;
b_f10_e: ;
		/* line 5850 */
b_L5850: ;
		b_v_ri += 1;
		if(b_v_ri <= 19) goto b_f9_t;
b_f9_e: ;
		/* line 5855 */
b_L5855: ;
		goto b_return;
		/* line 5900 */
b_L5900: ;
		/* line 5910 */
b_L5910: ;
		b_v_ii=(0);
		if(b_v_ii > 199) goto b_f11_e;
b_f11_t: ;
		b_v_ii += 1;
		if(b_v_ii <= 199) goto b_f11_t;
b_f11_e: ;
		/* line 5920 */
b_L5920: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f12_e;
b_f12_t: ;
		b_v_ri=((b_v_byi)+(b_a_pyi[B_INT(b_v_ii)]));
		b_v_ci=((b_v_bxi)+(b_a_pxi[B_INT(b_v_ii)]));
		/* line 5925 */
b_L5925: ;
		if(-((b_v_ri) >= ((0)))){
			if(-((b_v_ri) < ((20)))){
				if(-((b_v_ci) >= ((0)))){
					if(-((b_v_ci) < ((10)))){
						b_a_fbi[B_INT(((((b_v_ri)*((10))))+(b_v_ci)))]=(2);
					}
				}
			}
		}
		/* line 5930 */
b_L5930: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f12_t;
b_f12_e: ;
		/* line 5940 */
b_L5940: ;
		goto b_return;
		/* line 6000 */
b_L6000: ;
		/* line 6010 */
b_L6010: ;
		b_v_ri=(19);
		if(b_v_ri < 0) goto b_f13_e;
b_f13_t: ;
		/* line 6020 */
b_L6020: ;
		b_v_fi=(1);
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f14_e;
		b_v_M0=((b_v_ri)*((10)));
b_f14_t: ;
		if(-((b_a_bi[B_INT(((b_v_M0)+(b_v_ci)))]) == ((0)))){
			b_v_fi=(0);
		}
		/* line 6030 */
b_L6030: ;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f14_t;
b_f14_e: ;
		/* line 6040 */
b_L6040: ;
		if(-((b_v_fi) == ((0)))){ goto b_L6120; }
		/* line 6050 */
b_L6050: ;
		b_v_rri=b_v_ri;
		if(b_v_rri < 1) goto b_f15_e;
b_f15_t: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f16_e;
		b_v_M1=((((b_v_rri)-((1))))*((10)));
		b_v_M2=((b_v_rri)*((10)));
b_f16_t: ;
		b_a_bi[B_INT(((b_v_M2)+(b_v_ci)))]=b_a_bi[B_INT(((b_v_M1)+(b_v_ci)))];
		b_a_bci[B_INT(((b_v_M2)+(b_v_ci)))]=b_a_bci[B_INT(((b_v_M1)+(b_v_ci)))];
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f16_t;
b_f16_e: ;
		b_v_rri += -1;
		if(b_v_rri >= 1) goto b_f15_t;
b_f15_e: ;
		/* line 6060 */
b_L6060: ;
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f17_e;
b_f17_t: ;
		b_a_bi[B_INT(b_v_ci)]=(0);
		b_a_bci[B_INT(b_v_ci)]=(0);
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f17_t;
b_f17_e: ;
		/* line 6070 */
b_L6070: ;
		b_v_lni=((b_v_lni)+((1)));
		b_v_sci=((b_v_sci)+((100)));
		/* line 6080 */
b_L6080: ;
		b_v_lvi=(((1))+(b_int(((breal_t)(b_v_sci)/(breal_t)((500))))));
		if(-((b_v_lvi) > ((20)))){
			b_v_lvi=(20);
		}
		/* line 6090 */
b_L6090: ;
		b_v_dli=(((25))-(b_v_lvi));
		if(-((b_v_dli) < ((3)))){
			b_v_dli=(3);
		}
		/* line 6100 */
b_L6100: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L8100;
b_ret27: ;
		/* line 6110 */
b_L6110: ;
		b_v_ri=((b_v_ri)+((1)));
		/* line 6120 */
b_L6120: ;
		b_v_ri += -1;
		if(b_v_ri >= 0) goto b_f13_t;
b_f13_e: ;
		/* line 6130 */
b_L6130: ;
		goto b_return;
		/* line 6300 */
b_L6300: ;
		/* line 6310 */
b_L6310: ;
		b_v_byi=((b_v_byi)+((1)));
		b_gosubStack[b_gosubSP++]=28; goto b_L3100;
b_ret28: ;
		/* line 6320 */
b_L6320: ;
		if(-((b_v_cli) == ((0)))){ goto b_L6310; }
		/* line 6330 */
b_L6330: ;
		b_v_byi=((b_v_byi)-((1)));
		b_gosubStack[b_gosubSP++]=29; goto b_L5000;
b_ret29: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7005 */
b_L7005: ;
		b_v_ri=(2);
		if(b_v_ri > 22) goto b_f18_e;
		b_t_30=(((((1024))+(((b_v_ri)*((40))))))+((0)));
		b_t_31=(((((55296.0))+(((b_v_ri)*((40))))))+((0)));
		b_t_32=(((((1024))+(((b_v_ri)*((40))))))+((11)));
		b_t_33=(((((55296.0))+(((b_v_ri)*((40))))))+((11)));
b_f18_t: ;
		/* line 7006 */
b_L7006: ;
		b_poke(b_t_30,(102));
		b_poke(b_t_31,(1));
		/* line 7007 */
b_L7007: ;
		b_poke(b_t_32,(102));
		b_poke(b_t_33,(1));
		/* line 7008 */
b_L7008: ;
		b_t_30 += 40;
		b_t_31 += 40;
		b_t_32 += 40;
		b_t_33 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 22) goto b_f18_t;
b_f18_e: ;
		/* line 7009 */
b_L7009: ;
		b_v_ci=(0);
		if(b_v_ci > 11) goto b_f19_e;
		b_t_34=(((1904))+(b_v_ci));
		b_t_35=(((((55296.0))+((880))))+(b_v_ci));
b_f19_t: ;
		b_poke(b_t_34,(102));
		b_poke(b_t_35,(1));
		b_t_34 += 1;
		b_t_35 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 11) goto b_f19_t;
b_f19_e: ;
		/* line 7010 */
b_L7010: ;
		goto b_return;
		/* line 7200 */
b_L7200: ;
		/* line 7205 */
b_L7205: ;
		b_v_ri=(7);
		if(b_v_ri > 12) goto b_f20_e;
		b_t_36=(((((1024))+(((b_v_ri)*((40))))))+((14)));
		b_t_37=(((((55296.0))+(((b_v_ri)*((40))))))+((14)));
		b_t_38=(((((1024))+(((b_v_ri)*((40))))))+((19)));
		b_t_39=(((((55296.0))+(((b_v_ri)*((40))))))+((19)));
b_f20_t: ;
		b_poke(b_t_36,(102));
		b_poke(b_t_37,(1));
		b_poke(b_t_38,(102));
		b_poke(b_t_39,(1));
		b_t_36 += 40;
		b_t_37 += 40;
		b_t_38 += 40;
		b_t_39 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 12) goto b_f20_t;
b_f20_e: ;
		/* line 7206 */
b_L7206: ;
		b_v_ci=(14);
		if(b_v_ci > 19) goto b_f21_e;
		b_t_40=(((1504))+(b_v_ci));
		b_t_41=(((((55296.0))+((480))))+(b_v_ci));
b_f21_t: ;
		b_poke(b_t_40,(102));
		b_poke(b_t_41,(1));
		b_t_40 += 1;
		b_t_41 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 19) goto b_f21_t;
b_f21_e: ;
		/* line 7210 */
b_L7210: ;
		b_v_ri=(7);
		if(b_v_ri > 11) goto b_f22_e;
b_f22_t: ;
		b_v_ci=(15);
		if(b_v_ci > 18) goto b_f23_e;
		b_v_M3=(((1024))+(((b_v_ri)*((40)))));
		b_v_M4=((b_v_ri)*((40)));
		b_t_42=((b_v_M3)+(b_v_ci));
		b_t_43=(((((55296.0))+(b_v_M4)))+(b_v_ci));
b_f23_t: ;
		b_poke(b_t_42,(32));
		b_poke(b_t_43,(0));
		b_t_42 += 1;
		b_t_43 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 18) goto b_f23_t;
b_f23_e: ;
		b_v_ri += 1;
		if(b_v_ri <= 11) goto b_f22_t;
b_f22_e: ;
		/* line 7215 */
b_L7215: ;
		b_v_vci=b_a_pci[B_INT(b_v_npi)];
		/* line 7220 */
b_L7220: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f24_e;
b_f24_t: ;
		b_v_pri=(((7))+(b_a_nyi[B_INT(b_v_ii)]));
		b_v_qci=(((15))+(b_a_nxi[B_INT(b_v_ii)]));
		/* line 7225 */
b_L7225: ;
		if(-((b_v_pri) >= ((7)))){
			if(-((b_v_pri) <= ((11)))){
				if(-((b_v_qci) >= ((15)))){
					if(-((b_v_qci) <= ((18)))){
						b_poke((((((1024))+(((b_v_pri)*((40))))))+(b_v_qci)),(81));
						b_poke((((((55296.0))+(((b_v_pri)*((40))))))+(b_v_qci)),b_v_vci);
					}
				}
			}
		}
		/* line 7230 */
b_L7230: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f24_t;
b_f24_e: ;
		/* line 7240 */
b_L7240: ;
		b_poke((1278),(14));
		b_poke((1279),(5));
		b_poke((1280),(24));
		b_poke((1281),(20));
		/* line 7245 */
b_L7245: ;
		b_poke((((((55296.0))+((240))))+((14))),(1));
		b_poke((((((55296.0))+((240))))+((15))),(1));
		b_poke((((((55296.0))+((240))))+((16))),(1));
		b_poke((((((55296.0))+((240))))+((17))),(1));
		/* line 7250 */
b_L7250: ;
		goto b_return;
		/* line 8000 */
b_L8000: ;
		/* line 8005 */
b_L8005: ;
		b_v_hxi=(0);
		b_v_hyi=(0);
		b_v_ts=b_keep(b_lit("SCORE",5));
		b_gosubStack[b_gosubSP++]=30; goto b_L9700;
b_ret30: ;
		/* line 8008 */
b_L8008: ;
		b_v_hxi=(12);
		b_v_ts=b_keep(b_lit("LINES",5));
		b_gosubStack[b_gosubSP++]=31; goto b_L9700;
b_ret31: ;
		/* line 8009 */
b_L8009: ;
		b_v_hxi=(22);
		b_v_ts=b_keep(b_lit("LEVEL",5));
		b_gosubStack[b_gosubSP++]=32; goto b_L9700;
b_ret32: ;
		/* line 8010 */
b_L8010: ;
		b_gosubStack[b_gosubSP++]=33; goto b_L8100;
b_ret33: ;
		/* line 8025 */
b_L8025: ;
		goto b_return;
		/* line 8100 */
b_L8100: ;
		/* line 8110 */
b_L8110: ;
		b_v_ti=b_v_sci;
		b_v_ji=(0);
		if(b_v_ji > 4) goto b_f25_e;
b_f25_t: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_ji += 1;
		if(b_v_ji <= 4) goto b_f25_t;
b_f25_e: ;
		/* line 8120 */
b_L8120: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((4))])));
		b_poke((1031),(((48))+(b_a_di[B_INT((3))])));
		b_poke((1032),(((48))+(b_a_di[B_INT((2))])));
		/* line 8125 */
b_L8125: ;
		b_poke((1033),(((48))+(b_a_di[B_INT((1))])));
		b_poke((1034),(((48))+(b_a_di[B_INT((0))])));
		/* line 8130 */
b_L8130: ;
		b_v_li=b_v_lni;
		b_poke((1044),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		b_v_li=b_int(((breal_t)(b_v_li)/(breal_t)((10))));
		/* line 8135 */
b_L8135: ;
		b_poke((1043),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		b_v_li=b_int(((breal_t)(b_v_li)/(breal_t)((10))));
		/* line 8136 */
b_L8136: ;
		b_poke((1042),(((((48))+(b_v_li)))-((((10))*(b_int(((breal_t)(b_v_li)/(breal_t)((10)))))))));
		/* line 8140 */
b_L8140: ;
		b_poke((1052),(((48))+(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))));
		b_poke((1053),(((((48))+(b_v_lvi)))-((((10))*(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))))));
		/* line 8145 */
b_L8145: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
		}
		/* line 8146 */
b_L8146: ;
		if(-((b_v_dmi) == ((0)))){
			b_poke((1060),(32));
			b_poke((1061),(32));
			b_poke((1062),(32));
			b_poke((1063),(32));
			b_poke((55332.0),(0));
			b_poke((55333.0),(0));
			b_poke((55334.0),(0));
			b_poke((55335.0),(0));
		}
		/* line 8150 */
b_L8150: ;
		goto b_return;
		/* line 8200 */
b_L8200: ;
		/* line 8205 */
b_L8205: ;
		b_putc(147);
		b_nl();
		/* line 8210 */
b_L8210: ;
		b_v_ts=b_keep(b_lit("TETRIS",6));
		b_v_hxi=(17);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=34; goto b_L9700;
b_ret34: ;
		b_v_hhi=(17);
		if(b_v_hhi > 22) goto b_f26_e;
b_f26_t: ;
		b_poke((((55296.0))+(b_v_hhi)),(7));
		b_v_hhi += 1;
		if(b_v_hhi <= 22) goto b_f26_t;
b_f26_e: ;
		/* line 8215 */
b_L8215: ;
		b_v_ts=b_keep(b_lit("A/D OR CRSR MOVE",16));
		b_v_hxi=(11);
		b_v_hyi=(2);
		b_gosubStack[b_gosubSP++]=35; goto b_L9700;
b_ret35: ;
		/* line 8220 */
b_L8220: ;
		b_v_ts=b_keep(b_lit("W ROTATE  S HARD DROP",21));
		b_v_hxi=(9);
		b_v_hyi=(3);
		b_gosubStack[b_gosubSP++]=36; goto b_L9700;
b_ret36: ;
		/* line 8221 */
b_L8221: ;
		b_v_ts=b_keep(b_lit("SPACE SOFT DROP  Q QUIT",23));
		b_v_hxi=(7);
		b_v_hyi=(4);
		b_gosubStack[b_gosubSP++]=37; goto b_L9700;
b_ret37: ;
		/* line 8225 */
b_L8225: ;
		b_v_ts=b_keep(b_lit("E=EASY  H=HARD",14));
		b_v_hxi=(12);
		b_v_hyi=(5);
		b_gosubStack[b_gosubSP++]=38; goto b_L9700;
b_ret38: ;
		/* line 8228 */
b_L8228: ;
		b_v_dmi=(1);
		b_v_tgi=(0);
		/* line 8230 */
b_L8230: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L8235; }
		/* line 8231 */
b_L8231: ;
		if(-(b_strcmp(b_v_ks,b_lit("E",1)) == 0)){
			b_v_dmi=(0);
			b_v_dli=(18);
			goto b_L8260;
		}
		/* line 8232 */
b_L8232: ;
		if(-(b_strcmp(b_v_ks,b_lit("H",1)) == 0)){
			b_v_dmi=(0);
			b_v_dli=(10);
			goto b_L8260;
		}
		/* line 8233 */
b_L8233: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 8234 */
b_L8234: ;
		b_v_dmi=(0);
		goto b_L8260;
		/* line 8235 */
b_L8235: ;
		b_wait((53265.0),(128),0);
		/* line 8236 */
b_L8236: ;
		b_v_tgi=((b_v_tgi)+((1)));
		if(-((b_v_tgi) < ((240)))){ goto b_L8230; }
		/* line 8245 */
b_L8245: ;
		b_v_dmi=(1);
		b_v_dli=(14);
		/* line 8260 */
b_L8260: ;
		b_putc(147);
		b_nl();
		goto b_return;
		/* line 8500 */
b_L8500: ;
		/* line 8505 */
b_L8505: ;
		b_putc(147);
		b_nl();
		/* line 8510 */
b_L8510: ;
		b_nl();
		{ bstr_t _t=b_lit("   *** GAME OVER ***",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8515 */
b_L8515: ;
		{ bstr_t _t=b_lit("   SCORE:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 8520 */
b_L8520: ;
		{ bstr_t _t=b_lit("   LINES:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_lni);
		b_nl();
		/* line 8525 */
b_L8525: ;
		{ bstr_t _t=b_lit("   LEVEL:",9); b_str(_t.p,_t.len); }
		b_putint(b_v_lvi);
		b_nl();
		/* line 8530 */
b_L8530: ;
		b_nl();
		{ bstr_t _t=b_lit("   R=RESTART  Q=QUIT",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8535 */
b_L8535: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L8535; }
		/* line 8540 */
b_L8540: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L40;
		}
		/* line 8545 */
b_L8545: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 8550 */
b_L8550: ;
		goto b_L8535;
		/* line 9000 */
b_L9000: ;
		/* line 9100 */
b_L9100: ;
		if(-((b_v_ppi) == ((0)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(1);
			b_a_txi[B_INT((1))]=(1);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(2);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(3);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9101 */
b_L9101: ;
		if(-((b_v_ppi) == ((1)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(2);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9102 */
b_L9102: ;
		if(-((b_v_ppi) == ((2)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(0);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9103 */
b_L9103: ;
		if(-((b_v_ppi) == ((3)))){
			b_a_txi[B_INT((0))]=(1);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(2);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(0);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(1);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9104 */
b_L9104: ;
		if(-((b_v_ppi) == ((4)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(1);
			b_a_tyi[B_INT((1))]=(0);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9105 */
b_L9105: ;
		if(-((b_v_ppi) == ((5)))){
			b_a_txi[B_INT((0))]=(0);
			b_a_tyi[B_INT((0))]=(0);
			b_a_txi[B_INT((1))]=(0);
			b_a_tyi[B_INT((1))]=(1);
			b_a_txi[B_INT((2))]=(1);
			b_a_tyi[B_INT((2))]=(1);
			b_a_txi[B_INT((3))]=(2);
			b_a_tyi[B_INT((3))]=(1);
			goto b_return;
		}
		/* line 9106 */
b_L9106: ;
		b_a_txi[B_INT((0))]=(2);
		b_a_tyi[B_INT((0))]=(0);
		b_a_txi[B_INT((1))]=(0);
		b_a_tyi[B_INT((1))]=(1);
		b_a_txi[B_INT((2))]=(1);
		b_a_tyi[B_INT((2))]=(1);
		b_a_txi[B_INT((3))]=(2);
		b_a_tyi[B_INT((3))]=(1);
		goto b_return;
		/* line 9500 */
b_L9500: ;
		/* line 9505 */
b_L9505: ;
		b_v_ki=(64);
		/* line 9510 */
b_L9510: ;
		/* line 9515 */
b_L9515: ;
		b_v_dci=(0);
		b_v_mpi=(99);
		b_v_ci=(0);
		if(b_v_ci > 9) goto b_f27_e;
b_f27_t: ;
		/* line 9516 */
b_L9516: ;
		b_v_hi=(0);
		b_v_rri=(0);
		if(b_v_rri > 19) goto b_f28_e;
b_f28_t: ;
		if(-((b_a_bi[B_INT(((((b_v_rri)*((10))))+(b_v_ci)))]) == ((1)))){
			b_v_hi=(((20))-(b_v_rri));
			b_v_rri=(19);
		}
		/* line 9518 */
b_L9518: ;
		b_v_rri += 1;
		if(b_v_rri <= 19) goto b_f28_t;
b_f28_e: ;
		/* line 9519 */
b_L9519: ;
		if(-((b_v_hi) < (b_v_mpi))){
			b_v_mpi=b_v_hi;
			b_v_dci=b_v_ci;
		}
		/* line 9520 */
b_L9520: ;
		b_v_ci += 1;
		if(b_v_ci <= 9) goto b_f27_t;
b_f27_e: ;
		/* line 9525 */
b_L9525: ;
		/* line 9530 */
b_L9530: ;
		if(-((((b_v_bxi)+((1)))) < (b_v_dci))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 9535 */
b_L9535: ;
		if(-((((b_v_bxi)+((1)))) > (b_v_dci))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 9540 */
b_L9540: ;
		/* line 9545 */
b_L9545: ;
		if(-((b_rnd(B_INT((1)))) < ((0.30000000004656613)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 9550 */
b_L9550: ;
		if(-((b_rnd(B_INT((1)))) < ((0.40000000002328306)))){
			b_v_ki=(60);
			goto b_return;
		}
		/* line 9555 */
b_L9555: ;
		goto b_return;
		/* line 9600 */
b_L9600: ;
		/* line 9605 */
b_L9605: ;
		if(-((b_v_bii) < ((7)))){ goto b_L9660; }
		/* line 9610 */
b_L9610: ;
		/* line 9615 */
b_L9615: ;
		b_v_ii=(0);
		if(b_v_ii > 6) goto b_f29_e;
b_f29_t: ;
		b_a_bgi[B_INT(b_v_ii)]=b_v_ii;
		b_v_ii += 1;
		if(b_v_ii <= 6) goto b_f29_t;
b_f29_e: ;
		/* line 9620 */
b_L9620: ;
		b_v_ii=(0);
		if(b_v_ii > 5) goto b_f30_e;
b_f30_t: ;
		/* line 9630 */
b_L9630: ;
		b_v_ji=((b_v_ii)+(b_int(((b_rnd(B_INT((1))))*((((7))-(b_v_ii)))))));
		/* line 9635 */
b_L9635: ;
		b_v_ti=b_a_bgi[B_INT(b_v_ii)];
		b_a_bgi[B_INT(b_v_ii)]=b_a_bgi[B_INT(b_v_ji)];
		b_a_bgi[B_INT(b_v_ji)]=b_v_ti;
		/* line 9640 */
b_L9640: ;
		b_v_ii += 1;
		if(b_v_ii <= 5) goto b_f30_t;
b_f30_e: ;
		/* line 9650 */
b_L9650: ;
		b_v_bii=(0);
		/* line 9660 */
b_L9660: ;
		b_v_dri=b_a_bgi[B_INT(b_v_bii)];
		b_v_bii=((b_v_bii)+((1)));
		/* line 9665 */
b_L9665: ;
		goto b_return;
		/* line 9700 */
b_L9700: ;
		/* line 9710 */
b_L9710: ;
		b_v_ii=(1);
		b_fl_31=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_31) goto b_f31_e;
		b_v_M5=(((1024))+(b_v_hxi));
		b_v_M6=((b_v_hyi)*((40)));
		b_t_49=((((((b_v_M5)+(b_v_ii)))-((1))))+(b_v_M6));
b_f31_t: ;
		/* line 9715 */
b_L9715: ;
		b_v_cti=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 9720 */
b_L9720: ;
		if(-((b_v_cti) >= ((64)))){
			if(-((b_v_cti) <= ((95)))){
				b_v_cti=((b_v_cti)-((64)));
			}
		}
		/* line 9725 */
b_L9725: ;
		b_poke(b_t_49,b_v_cti);
		/* line 9730 */
b_L9730: ;
		b_t_49 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_31)) goto b_f31_t;
b_f31_e: ;
		/* line 9735 */
b_L9735: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
