/* OPTIMIZE_C -- ladder.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_fli;
static int b_v_ldi;
static int b_v_pli;
static int b_v_bri;
static int b_v_gli;
static int b_v_emi;
static int b_v_gxi;
static int b_v_gyi;
static bint_t b_a_mpi[1000];
static int b_a_rxi[4];
static int b_a_ryi[4];
static int b_a_vxi[4];
static int b_a_vyi[4];
static int b_a_rdi[4];
static bint_t b_a_bfi[4];
static int b_a_rsi[4];
static bint_t b_a_di[5];
static int b_v_lfi;
static bint_t b_v_lvi;
static bint_t b_v_sci;
static int b_v_ggi;
static int b_v_wni;
static int b_v_bsi;
static int b_v_hdi;
static int b_v_ddi;
static int b_v_cli;
static int b_v_ki;
static int b_v_sfi;
static int b_v_dmi;
static bint_t b_v_pxi;
static bint_t b_v_pyi;
static bint_t b_v_bpi;
static bint_t b_v_ii;
static int b_v_sii;
static bint_t b_v_ji;
static bint_t b_v_ivi;
static bint_t b_v_ti;
static int b_v_tgi;
static bint_t b_v_tci;
static bint_t b_v_oxi;
static bint_t b_v_oyi;
static bint_t b_v_nxi;
static int b_v_nyi;
static int b_v_pci;
static bint_t b_v_udi;
static unsigned int b_v_zai;
static int b_v_zci;
static unsigned int b_v_zdi;
static bstr_t b_v_ts;
static int b_v_txi;
static int b_v_tyi;
static int b_v_chi;
static int b_v_pi;
static bint_t b_v_pri;
static int b_v_ci;
static int b_v_li;
static bint_t b_v_lxi;
static int b_v_lti;
static int b_v_lbi;
static bint_t b_v_ri;
static int b_v_gdi;
static bstr_t b_v_ks;
static int b_v_cci;
static bint_t b_v_M0;
static int b_v_M1;
static int b_v_M2;
static bint_t b_v_M3;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[3];
static int b_rtfor_sp=0;
static bint_t b_fl_7;
static bint_t b_fl_12;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,22,0,0},{1,0,19,0,0},{1,0,16,0,0},{1,0,13,0,0},{1,0,10,0,0},{1,0,7,0,0},{1,0,4,0,0},{1,0,8,0,0},{1,0,5,0,0},{1,0,6,0,0},{1,0,30,0,0},{1,0,5,0,0},{1,0,6,0,0},{1,0,12,0,0},{1,0,8,0,0},{1,0,9,0,0},{1,0,28,0,0},{1,0,8,0,0},{1,0,9,0,0},{1,0,8,0,0},{1,0,11,0,0},{1,0,12,0,0},{1,0,30,0,0},{1,0,11,0,0},{1,0,12,0,0},{1,0,12,0,0},{1,0,14,0,0},{1,0,15,0,0},{1,0,28,0,0},{1,0,14,0,0},{1,0,15,0,0},{1,0,8,0,0},{1,0,17,0,0},{1,0,18,0,0},{1,0,30,0,0},{1,0,17,0,0},{1,0,18,0,0},{1,0,12,0,0},{1,0,20,0,0},{1,0,21,0,0},{1,0,28,0,0},{1,0,20,0,0},{1,0,21,0,0}};
int b_data_len = 43;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 13 */
b_L13: ;
		/* line 14 */
b_L14: ;
		/* line 15 */
b_L15: ;
		/* line 20 */
b_L20: ;
		b_putc(147);
		b_nl();
		/* line 25 */
b_L25: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 30 */
b_L30: ;
		b_v_fli=(160);
		b_v_ldi=(8);
		b_v_pli=(81);
		b_v_bri=(15);
		b_v_gli=(16);
		b_v_emi=(32);
		/* line 35 */
b_L35: ;
		b_v_gxi=(36);
		b_v_gyi=(4);
		/* line 36 */
b_L36: ;
		/* line 40 */
b_L40: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L8000;
b_ret0: ;
		/* line 42 */
b_L42: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L8300;
b_ret1: ;
		/* line 50 */
b_L50: ;
		b_v_lfi=(3);
		b_v_lvi=(1);
		b_v_sci=(0);
		b_v_ggi=(0);
		b_v_wni=(0);
		b_v_bsi=(30);
		b_v_hdi=(1);
		b_v_ddi=(1);
		b_v_cli=(0);
		/* line 55 */
b_L55: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L7000;
b_ret2: ;
		/* line 60 */
b_L60: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L6100;
b_ret3: ;
		/* line 70 */
b_L70: ;
		/* line 80 */
b_L80: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 85 */
b_L85: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_sfi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 86 */
b_L86: ;
		if(-((b_v_ki) != ((64)))){
			b_v_dmi=(0);
		}
		/* line 87 */
b_L87: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=4; goto b_L5500;
b_ret4: ;
		}
		/* line 88 */
b_L88: ;
		if(-((b_v_ki) == ((7)))){
			if(b_v_sfi){
				b_v_ki=(9);
			}
		}
		/* line 89 */
b_L89: ;
		if(-((b_v_ki) == ((7)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(13);
			}
		}
		/* line 90 */
b_L90: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_sfi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 91 */
b_L91: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_sfi){
				b_v_ki=(10);
			}
		}
		/* line 92 */
b_L92: ;
		if(-((b_v_ki) == ((62)))){
			goto b_L9500;
		}
		/* line 100 */
b_L100: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L5000;
b_ret5: ;
		/* line 105 */
b_L105: ;
		if(-((b_v_pxi) == (b_v_gxi))){
			if(-((b_v_pyi) == (b_v_gyi))){
				b_gosubStack[b_gosubSP++]=6; goto b_L3200;
b_ret6: ;
				goto b_L80;
			}
		}
		/* line 110 */
b_L110: ;
		b_gosubStack[b_gosubSP++]=7; goto b_L2000;
b_ret7: ;
		/* line 120 */
b_L120: ;
		b_gosubStack[b_gosubSP++]=8; goto b_L3000;
b_ret8: ;
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=9; goto b_L4000;
b_ret9: ;
		/* line 135 */
b_L135: ;
		if(-((b_v_hdi) == ((1)))){
			b_v_hdi=(0);
			b_gosubStack[b_gosubSP++]=10; goto b_L7100;
b_ret10: ;
		}
		/* line 150 */
b_L150: ;
		if(-((b_v_ggi) == ((1)))){
			goto b_L8500;
		}
		/* line 160 */
b_L160: ;
		goto b_L80;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		b_v_bpi=((b_v_bpi)+((1)));
		/* line 2008 */
b_L2008: ;
		if(-((b_v_bpi) >= (b_v_bsi))){
			b_v_bpi=(0);
			b_gosubStack[b_gosubSP++]=11; goto b_L2100;
b_ret11: ;
		}
		/* line 2010 */
b_L2010: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f0_e;
b_f0_t: ;
		/* line 2012 */
b_L2012: ;
		if(-((b_a_bfi[B_INT(b_v_ii)]) == ((0)))){ goto b_L2090; }
		/* line 2015 */
b_L2015: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L2200;
b_ret12: ;
		/* line 2090 */
b_L2090: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f0_t;
b_f0_e: ;
		/* line 2095 */
b_L2095: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2105 */
b_L2105: ;
		b_v_sii=(-1);
		/* line 2107 */
b_L2107: ;
		b_v_ji=(0);
		if(b_v_ji > 3) goto b_f1_e;
b_f1_t: ;
		/* line 2108 */
b_L2108: ;
		if(-((b_v_sii) < ((0)))){
			if(-((b_a_bfi[B_INT(b_v_ji)]) == ((0)))){
				b_v_sii=b_v_ji;
			}
		}
		/* line 2109 */
b_L2109: ;
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f1_t;
b_f1_e: ;
		/* line 2130 */
b_L2130: ;
		if(-((b_v_sii) < ((0)))){
			goto b_return;
		}
		/* line 2135 */
b_L2135: ;
		b_a_rxi[B_INT(b_v_sii)]=(2);
		b_a_ryi[B_INT(b_v_sii)]=(4);
		b_a_rdi[B_INT(b_v_sii)]=(1);
		b_a_bfi[B_INT(b_v_sii)]=(1);
		b_a_rsi[B_INT(b_v_sii)]=(0);
		/* line 2140 */
b_L2140: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2205 */
b_L2205: ;
		b_a_vxi[B_INT(b_v_ii)]=b_a_rxi[B_INT(b_v_ii)];
		b_a_vyi[B_INT(b_v_ii)]=b_a_ryi[B_INT(b_v_ii)];
		/* line 2210 */
b_L2210: ;
		if(-((b_a_rsi[B_INT(b_v_ii)]) == ((1)))){
			goto b_L2300;
		}
		/* line 2220 */
b_L2220: ;
		b_a_rxi[B_INT(b_v_ii)]=((b_a_rxi[B_INT(b_v_ii)])+(b_a_rdi[B_INT(b_v_ii)]));
		/* line 2225 */
b_L2225: ;
		if(-((b_a_rxi[B_INT(b_v_ii)]) < ((1)))){
			b_a_rxi[B_INT(b_v_ii)]=(1);
			b_a_rsi[B_INT(b_v_ii)]=(1);
			goto b_L2290;
		}
		/* line 2230 */
b_L2230: ;
		if(-((b_a_rxi[B_INT(b_v_ii)]) > ((38)))){
			b_a_rxi[B_INT(b_v_ii)]=(38);
			b_a_rsi[B_INT(b_v_ii)]=(1);
			goto b_L2290;
		}
		/* line 2290 */
b_L2290: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2305 */
b_L2305: ;
		b_a_ryi[B_INT(b_v_ii)]=((b_a_ryi[B_INT(b_v_ii)])+((1)));
		/* line 2306 */
b_L2306: ;
		if(-((b_a_ryi[B_INT(b_v_ii)]) > ((24)))){
			b_a_bfi[B_INT(b_v_ii)]=(0);
			goto b_return;
		}
		/* line 2310 */
b_L2310: ;
		if(-((b_a_mpi[B_INT(((((b_a_ryi[B_INT(b_v_ii)])*((40))))+(b_a_rxi[B_INT(b_v_ii)])))]) == ((1)))){
			b_a_rsi[B_INT(b_v_ii)]=(0);
			b_a_rdi[B_INT(b_v_ii)]=(((0))-(b_a_rdi[B_INT(b_v_ii)]));
			goto b_return;
		}
		/* line 2315 */
b_L2315: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3005 */
b_L3005: ;
		if(-((b_v_ivi) > ((0)))){
			goto b_return;
		}
		/* line 3010 */
b_L3010: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f2_e;
b_f2_t: ;
		/* line 3015 */
b_L3015: ;
		if(-((b_a_bfi[B_INT(b_v_ii)]) == ((0)))){ goto b_L3030; }
		/* line 3020 */
b_L3020: ;
		if(-((b_a_rxi[B_INT(b_v_ii)]) == (b_v_pxi))){
			if(-((b_a_ryi[B_INT(b_v_ii)]) == (b_v_pyi))){
				b_gosubStack[b_gosubSP++]=13; goto b_L3100;
b_ret13: ;
			}
		}
		/* line 3030 */
b_L3030: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f2_t;
b_f2_e: ;
		/* line 3035 */
b_L3035: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3105 */
b_L3105: ;
		b_v_lfi=((b_v_lfi)-((1)));
		b_v_ivi=(40);
		b_v_hdi=(1);
		/* line 3107 */
b_L3107: ;
		b_v_ti=b_a_mpi[B_INT(((((b_v_pyi)*((40))))+(b_v_pxi)))];
		b_gosubStack[b_gosubSP++]=14; goto b_L5900;
b_ret14: ;
		b_poke((((((1024))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_tgi);
		b_poke((((((55296.0))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_tci);
		/* line 3110 */
b_L3110: ;
		if(-((b_v_lfi) <= ((0)))){
			b_v_ggi=(1);
			goto b_return;
		}
		/* line 3115 */
b_L3115: ;
		b_v_pxi=(20);
		b_v_pyi=(22);
		b_v_oxi=(20);
		b_v_oyi=(22);
		b_v_ddi=(1);
		b_v_cli=(0);
		/* line 3120 */
b_L3120: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3205 */
b_L3205: ;
		b_v_sci=((b_v_sci)+((100)));
		b_v_lvi=((b_v_lvi)+((1)));
		b_v_hdi=(1);
		/* line 3210 */
b_L3210: ;
		b_v_bsi=((b_v_bsi)-((4)));
		if(-((b_v_bsi) < ((10)))){
			b_v_bsi=(10);
		}
		/* line 3215 */
b_L3215: ;
		b_gosubStack[b_gosubSP++]=15; goto b_L6100;
b_ret15: ;
		/* line 3220 */
b_L3220: ;
		goto b_return;
		/* line 4000 */
b_L4000: ;
		/* line 4005 */
b_L4005: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f3_e;
b_f3_t: ;
		/* line 4010 */
b_L4010: ;
		if(-((b_a_bfi[B_INT(b_v_ii)]) == ((0)))){ goto b_L4040; }
		/* line 4015 */
b_L4015: ;
		b_v_ti=b_a_mpi[B_INT(((((b_a_vyi[B_INT(b_v_ii)])*((40))))+(b_a_vxi[B_INT(b_v_ii)])))];
		b_gosubStack[b_gosubSP++]=16; goto b_L5900;
b_ret16: ;
		b_poke((((((1024))+(((b_a_vyi[B_INT(b_v_ii)])*((40))))))+(b_a_vxi[B_INT(b_v_ii)])),b_v_tgi);
		b_poke((((((55296.0))+(((b_a_vyi[B_INT(b_v_ii)])*((40))))))+(b_a_vxi[B_INT(b_v_ii)])),b_v_tci);
		/* line 4020 */
b_L4020: ;
		b_poke((((((1024))+(((b_a_ryi[B_INT(b_v_ii)])*((40))))))+(b_a_rxi[B_INT(b_v_ii)])),b_v_bri);
		b_poke((((((55296.0))+(((b_a_ryi[B_INT(b_v_ii)])*((40))))))+(b_a_rxi[B_INT(b_v_ii)])),(8));
		/* line 4040 */
b_L4040: ;
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f3_t;
b_f3_e: ;
		/* line 4045 */
b_L4045: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5005 */
b_L5005: ;
		b_v_ti=b_a_mpi[B_INT(((((b_v_oyi)*((40))))+(b_v_oxi)))];
		b_gosubStack[b_gosubSP++]=17; goto b_L5900;
b_ret17: ;
		b_poke((((((1024))+(((b_v_oyi)*((40))))))+(b_v_oxi)),b_v_tgi);
		b_poke((((((55296.0))+(((b_v_oyi)*((40))))))+(b_v_oxi)),b_v_tci);
		/* line 5008 */
b_L5008: ;
		b_v_nxi=b_v_pxi;
		b_v_nyi=b_v_pyi;
		/* line 5010 */
b_L5010: ;
		if(-((b_v_ki) == ((10)))){
			b_gosubStack[b_gosubSP++]=18; goto b_L5100;
b_ret18: ;
		}
		/* line 5015 */
b_L5015: ;
		if(-((b_v_ki) == ((18)))){
			b_gosubStack[b_gosubSP++]=19; goto b_L5150;
b_ret19: ;
		}
		/* line 5020 */
b_L5020: ;
		if(-((b_v_ki) == ((9)))){
			b_gosubStack[b_gosubSP++]=20; goto b_L5200;
b_ret20: ;
		}
		/* line 5025 */
b_L5025: ;
		if(-((b_v_ki) == ((13)))){
			b_gosubStack[b_gosubSP++]=21; goto b_L5300;
b_ret21: ;
		}
		/* line 5030 */
b_L5030: ;
		b_v_pxi=b_v_nxi;
		b_v_pyi=b_v_nyi;
		b_v_oxi=b_v_pxi;
		b_v_oyi=b_v_pyi;
		/* line 5035 */
b_L5035: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L5400;
b_ret22: ;
		/* line 5040 */
b_L5040: ;
		goto b_return;
		/* line 5100 */
b_L5100: ;
		/* line 5105 */
b_L5105: ;
		if(-((b_v_nxi) > ((0)))){
			if((B_INT(-((b_a_mpi[B_INT(((((((b_v_nyi)*((40))))+(b_v_nxi)))-((1))))]) == ((1)))) | B_INT(-((b_a_mpi[B_INT(((((((b_v_nyi)*((40))))+(b_v_nxi)))-((1))))]) == ((3)))))){
				b_v_nxi=((b_v_nxi)-((1)));
			}
		}
		/* line 5110 */
b_L5110: ;
		goto b_return;
		/* line 5150 */
b_L5150: ;
		/* line 5155 */
b_L5155: ;
		if(-((b_v_nxi) < ((39)))){
			if((B_INT(-((b_a_mpi[B_INT(((((((b_v_nyi)*((40))))+(b_v_nxi)))+((1))))]) == ((1)))) | B_INT(-((b_a_mpi[B_INT(((((((b_v_nyi)*((40))))+(b_v_nxi)))+((1))))]) == ((3)))))){
				b_v_nxi=((b_v_nxi)+((1)));
			}
		}
		/* line 5160 */
b_L5160: ;
		goto b_return;
		/* line 5200 */
b_L5200: ;
		/* line 5205 */
b_L5205: ;
		if(-((b_v_nyi) < ((1)))){
			goto b_return;
		}
		/* line 5210 */
b_L5210: ;
		b_v_tci=b_a_mpi[B_INT(((((((b_v_nyi)-((1))))*((40))))+(b_v_nxi)))];
		/* line 5215 */
b_L5215: ;
		if(-((b_v_tci) == ((2)))){
			b_v_nyi=((b_v_nyi)-((1)));
			goto b_return;
		}
		/* line 5220 */
b_L5220: ;
		if(-((b_v_tci) == ((1)))){
			if(-((b_a_mpi[B_INT(((((b_v_nyi)*((40))))+(b_v_nxi)))]) == ((2)))){
				b_v_nyi=((b_v_nyi)-((1)));
				goto b_return;
			}
		}
		/* line 5225 */
b_L5225: ;
		if(-((b_v_tci) == ((3)))){
			if(-((b_a_mpi[B_INT(((((b_v_nyi)*((40))))+(b_v_nxi)))]) == ((2)))){
				b_v_nyi=((b_v_nyi)-((1)));
				goto b_return;
			}
		}
		/* line 5230 */
b_L5230: ;
		goto b_return;
		/* line 5300 */
b_L5300: ;
		/* line 5305 */
b_L5305: ;
		if(-((b_v_nyi) > ((23)))){
			goto b_return;
		}
		/* line 5310 */
b_L5310: ;
		b_v_tci=b_a_mpi[B_INT(((((((b_v_nyi)+((1))))*((40))))+(b_v_nxi)))];
		/* line 5315 */
b_L5315: ;
		if(-((b_v_tci) == ((2)))){
			b_v_nyi=((b_v_nyi)+((1)));
			goto b_return;
		}
		/* line 5320 */
b_L5320: ;
		if(-((b_v_tci) == ((1)))){
			if(-((b_a_mpi[B_INT(((((b_v_nyi)*((40))))+(b_v_nxi)))]) == ((2)))){
				b_v_nyi=((b_v_nyi)+((1)));
				goto b_return;
			}
		}
		/* line 5325 */
b_L5325: ;
		if(-((b_v_tci) == ((3)))){
			if(-((b_a_mpi[B_INT(((((b_v_nyi)*((40))))+(b_v_nxi)))]) == ((2)))){
				b_v_nyi=((b_v_nyi)+((1)));
				goto b_return;
			}
		}
		/* line 5330 */
b_L5330: ;
		goto b_return;
		/* line 5400 */
b_L5400: ;
		/* line 5405 */
b_L5405: ;
		if(-((b_v_ivi) > ((0)))){
			b_v_ivi=((b_v_ivi)-((1)));
		}
		/* line 5410 */
b_L5410: ;
		b_v_pci=(7);
		if(-((b_v_ivi) > ((0)))){
			b_v_pci=(2);
		}
		/* line 5415 */
b_L5415: ;
		b_poke((((((1024))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_pli);
		b_poke((((((55296.0))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_pci);
		/* line 5420 */
b_L5420: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5505 */
b_L5505: ;
		b_v_ki=(64);
		/* line 5506 */
b_L5506: ;
		if(-((b_rnd(B_INT((1)))) < ((0.079999999987194315)))){
			goto b_return;
		}
		/* line 5510 */
b_L5510: ;
		if(-((b_v_pyi) <= (b_v_gyi))){ goto b_L5570; }
		/* line 5515 */
b_L5515: ;
		b_v_tci=b_a_mpi[B_INT(((((b_v_pyi)*((40))))+(b_v_pxi)))];
		/* line 5520 */
b_L5520: ;
		if(-((b_v_tci) == ((2)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 5525 */
b_L5525: ;
		b_v_udi=b_a_mpi[B_INT(((((((b_v_pyi)-((1))))*((40))))+(b_v_pxi)))];
		if(-((b_v_udi) == ((2)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 5530 */
b_L5530: ;
		/* line 5532 */
b_L5532: ;
		b_v_zai=(99);
		b_v_zci=(-1);
		/* line 5534 */
b_L5534: ;
		b_v_ji=(1);
		if(b_v_ji > 38) goto b_f4_e;
		b_v_M0=((((b_v_pyi)-((1))))*((40)));
b_f4_t: ;
		/* line 5535 */
b_L5535: ;
		if(-((b_a_mpi[B_INT(((b_v_M0)+(b_v_ji)))]) == ((2)))){
			b_v_zdi=b_abs((breal_t)(((b_v_ji)-(b_v_pxi))));
			if(-((b_v_zdi) < (b_v_zai))){
				b_v_zai=b_v_zdi;
				b_v_zci=b_v_ji;
			}
		}
		/* line 5536 */
b_L5536: ;
		b_v_ji += 1;
		if(b_v_ji <= 38) goto b_f4_t;
b_f4_e: ;
		/* line 5538 */
b_L5538: ;
		if(-((b_v_zci) < ((0)))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 5539 */
b_L5539: ;
		if(-((b_v_pxi) < (b_v_zci))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 5540 */
b_L5540: ;
		if(-((b_v_pxi) > (b_v_zci))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 5542 */
b_L5542: ;
		goto b_return;
		/* line 5570 */
b_L5570: ;
		if(-((b_v_pxi) < (b_v_gxi))){
			b_v_ki=(18);
			goto b_return;
		}
		/* line 5575 */
b_L5575: ;
		if(-((b_v_pxi) > (b_v_gxi))){
			b_v_ki=(10);
			goto b_return;
		}
		/* line 5580 */
b_L5580: ;
		goto b_return;
		/* line 5900 */
b_L5900: ;
		/* line 5905 */
b_L5905: ;
		b_v_tgi=b_v_emi;
		b_v_tci=(0);
		/* line 5910 */
b_L5910: ;
		if(-((b_v_ti) == ((1)))){
			b_v_tgi=b_v_fli;
			b_v_tci=(6);
		}
		/* line 5915 */
b_L5915: ;
		if(-((b_v_ti) == ((2)))){
			b_v_tgi=b_v_ldi;
			b_v_tci=(5);
		}
		/* line 5920 */
b_L5920: ;
		if(-((b_v_ti) == ((3)))){
			b_v_tgi=b_v_gli;
			b_v_tci=(2);
		}
		/* line 5925 */
b_L5925: ;
		goto b_return;
		/* line 6100 */
b_L6100: ;
		/* line 6105 */
b_L6105: ;
		b_v_ii=(0);
		if(b_v_ii > 3) goto b_f5_e;
b_f5_t: ;
		b_a_bfi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 3) goto b_f5_t;
b_f5_e: ;
		/* line 6110 */
b_L6110: ;
		b_v_pxi=(20);
		b_v_pyi=(22);
		b_v_oxi=(20);
		b_v_oyi=(22);
		b_v_ivi=(0);
		b_v_bpi=(0);
		b_v_ddi=(((1))-((((2))*(b_int(((b_rnd(B_INT((1))))*((2))))))));
		b_v_cli=(0);
		/* line 6115 */
b_L6115: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L9000;
b_ret23: ;
		/* line 6118 */
b_L6118: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L8400;
b_ret24: ;
		/* line 6120 */
b_L6120: ;
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7005 */
b_L7005: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		b_v_txi=(0);
		b_v_tyi=(0);
		b_gosubStack[b_gosubSP++]=25; goto b_L7500;
b_ret25: ;
		/* line 7010 */
b_L7010: ;
		b_v_ts=b_keep(b_lit("LIVES",5));
		b_v_txi=(12);
		b_v_tyi=(0);
		b_gosubStack[b_gosubSP++]=26; goto b_L7500;
b_ret26: ;
		/* line 7015 */
b_L7015: ;
		b_v_ts=b_keep(b_lit("LEVEL",5));
		b_v_txi=(20);
		b_v_tyi=(0);
		b_gosubStack[b_gosubSP++]=27; goto b_L7500;
b_ret27: ;
		/* line 7020 */
b_L7020: ;
		/* line 7025 */
b_L7025: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L7100;
b_ret28: ;
		/* line 7030 */
b_L7030: ;
		goto b_return;
		/* line 7100 */
b_L7100: ;
		/* line 7105 */
b_L7105: ;
		b_v_ti=b_v_sci;
		b_v_ji=(0);
		if(b_v_ji > 4) goto b_f6_e;
b_f6_t: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_ji += 1;
		if(b_v_ji <= 4) goto b_f6_t;
b_f6_e: ;
		/* line 7110 */
b_L7110: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((4))])));
		b_poke((1031),(((48))+(b_a_di[B_INT((3))])));
		b_poke((1032),(((48))+(b_a_di[B_INT((2))])));
		/* line 7112 */
b_L7112: ;
		b_poke((1033),(((48))+(b_a_di[B_INT((1))])));
		b_poke((1034),(((48))+(b_a_di[B_INT((0))])));
		/* line 7115 */
b_L7115: ;
		b_poke((1042),(((48))+(b_v_lfi)));
		/* line 7120 */
b_L7120: ;
		b_poke((1050),(((48))+(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))));
		b_poke((1051),(((((48))+(b_v_lvi)))-((((10))*(b_int(((breal_t)(b_v_lvi)/(breal_t)((10)))))))));
		/* line 7122 */
b_L7122: ;
		if(-((b_v_dmi) == ((1)))){
			b_poke((1060),(4));
			b_poke((1061),(5));
			b_poke((1062),(13));
			b_poke((1063),(15));
			b_poke((55332.0),(7));
			b_poke((55333.0),(7));
			b_poke((55334.0),(7));
			b_poke((55335.0),(7));
		}
		/* line 7124 */
b_L7124: ;
		if(-((b_v_dmi) == ((0)))){
			b_poke((1060),(32));
			b_poke((1061),(32));
			b_poke((1062),(32));
			b_poke((1063),(32));
			b_poke((55332.0),(0));
			b_poke((55333.0),(0));
			b_poke((55334.0),(0));
			b_poke((55335.0),(0));
		}
		/* line 7125 */
b_L7125: ;
		goto b_return;
		/* line 7500 */
b_L7500: ;
		/* line 7505 */
b_L7505: ;
		b_v_ii=(1);
		b_fl_7=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_7) goto b_f7_e;
		b_v_M1=(((1024))+(b_v_txi));
		b_v_M2=((b_v_tyi)*((40)));
		b_t_3=((((((b_v_M1)+(b_v_ii)))-((1))))+(b_v_M2));
b_f7_t: ;
		/* line 7510 */
b_L7510: ;
		b_v_chi=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 7515 */
b_L7515: ;
		if(-((b_v_chi) >= ((64)))){
			if(-((b_v_chi) <= ((95)))){
				b_v_chi=((b_v_chi)-((64)));
			}
		}
		/* line 7520 */
b_L7520: ;
		b_poke(b_t_3,b_v_chi);
		/* line 7525 */
b_L7525: ;
		b_t_3 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_7)) goto b_f7_t;
b_f7_e: ;
		/* line 7530 */
b_L7530: ;
		goto b_return;
		/* line 8000 */
b_L8000: ;
		/* line 8005 */
b_L8005: ;
		b_v_ii=(0);
		if(b_v_ii > 999) goto b_f8_e;
b_f8_t: ;
		b_a_mpi[B_INT(b_v_ii)]=(0);
		b_v_ii += 1;
		if(b_v_ii <= 999) goto b_f8_t;
b_f8_e: ;
		/* line 8010 */
b_L8010: ;
		b_v_pi=(0);
		if(b_v_pi > 6) goto b_f9_e;
b_f9_t: ;
		b_v_pri=b_read_int();
		b_v_ci=(1);
		if(b_v_ci > 38) goto b_f10_e;
		b_v_M3=((b_v_pri)*((40)));
b_f10_t: ;
		b_a_mpi[B_INT(((b_v_M3)+(b_v_ci)))]=(1);
		b_v_ci += 1;
		if(b_v_ci <= 38) goto b_f10_t;
b_f10_e: ;
		b_v_pi += 1;
		if(b_v_pi <= 6) goto b_f9_t;
b_f9_e: ;
		/* line 8020 */
b_L8020: ;
		b_v_li=(0);
		if(b_v_li > 11) goto b_f11_e;
b_f11_t: ;
		b_v_lxi=b_read_int();
		b_v_lti=b_read_int();
		b_v_lbi=b_read_int();
		b_v_ri=b_v_lti;
		b_fl_12=b_v_lbi;
		if(b_v_ri > b_fl_12) goto b_f12_e;
b_f12_t: ;
		b_a_mpi[B_INT(((((b_v_ri)*((40))))+(b_v_lxi)))]=(2);
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_12)) goto b_f12_t;
b_f12_e: ;
		b_v_li += 1;
		if(b_v_li <= 11) goto b_f11_t;
b_f11_e: ;
		/* line 8030 */
b_L8030: ;
		b_a_mpi[B_INT(((((b_v_gyi)*((40))))+(b_v_gxi)))]=(3);
		/* line 8040 */
b_L8040: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L9000;
b_ret29: ;
		/* line 8045 */
b_L8045: ;
		goto b_return;
		/* line 8050 */
b_L8050: ;
		/* line 8060 */
b_L8060: ;
		/* line 8065 */
b_L8065: ;
		/* line 8070 */
b_L8070: ;
		/* line 8075 */
b_L8075: ;
		/* line 8080 */
b_L8080: ;
		/* line 8085 */
b_L8085: ;
		/* line 8090 */
b_L8090: ;
		/* line 8095 */
b_L8095: ;
		/* line 8100 */
b_L8100: ;
		/* line 8105 */
b_L8105: ;
		/* line 8110 */
b_L8110: ;
		/* line 8115 */
b_L8115: ;
		/* line 8300 */
b_L8300: ;
		/* line 8305 */
b_L8305: ;
		b_putc(147);
		b_nl();
		/* line 8310 */
b_L8310: ;
		b_v_ts=b_keep(b_lit("LADDER",6));
		b_v_txi=(17);
		b_v_tyi=(0);
		b_gosubStack[b_gosubSP++]=30; goto b_L7500;
b_ret30: ;
		/* line 8315 */
b_L8315: ;
		b_v_ts=b_keep(b_lit("W/A/S/D OR CRSR TO MOVE",23));
		b_v_txi=(8);
		b_v_tyi=(2);
		b_gosubStack[b_gosubSP++]=31; goto b_L7500;
b_ret31: ;
		/* line 8320 */
b_L8320: ;
		b_v_ts=b_keep(b_lit("CLIMB TO GOAL  AVOID BARRELS",28));
		b_v_txi=(6);
		b_v_tyi=(3);
		b_gosubStack[b_gosubSP++]=32; goto b_L7500;
b_ret32: ;
		/* line 8325 */
b_L8325: ;
		b_v_ts=b_keep(b_lit("Q=QUIT",6));
		b_v_txi=(8);
		b_v_tyi=(4);
		b_gosubStack[b_gosubSP++]=33; goto b_L7500;
b_ret33: ;
		/* line 8330 */
b_L8330: ;
		b_v_ts=b_keep(b_lit("SPACE TO PLAY  D=DEMO",21));
		b_v_txi=(8);
		b_v_tyi=(5);
		b_gosubStack[b_gosubSP++]=34; goto b_L7500;
b_ret34: ;
		/* line 8335 */
b_L8335: ;
		b_v_gdi=(1);
		if(b_v_gdi > 200) goto b_f13_e;
		{ b_rtfor_t _f; _f.top_id=13; _f.pI=&b_v_gdi; _f.vtype=1; _f.lim.i=200; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f13_t: ;
		/* line 8337 */
b_L8337: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 8340 */
b_L8340: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		/* line 8345 */
b_L8345: ;
		if(-(b_strcmp(b_v_ks,b_lit("D",1)) == 0)){
			b_v_dmi=(1);
			goto b_L8390;
		}
		/* line 8350 */
b_L8350: ;
		if(-(b_strcmp(b_v_ks,b_lit("",0)) != 0)){
			b_v_dmi=(0);
			goto b_L8390;
		}
		/* line 8355 */
b_L8355: ;
		b_v_gdi += 1;
		if(b_v_gdi <= 200) goto b_f13_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f13_e: ;
		/* line 8360 */
b_L8360: ;
		b_v_dmi=(1);
		/* line 8390 */
b_L8390: ;
		b_putc(147);
		b_nl();
		/* line 8395 */
b_L8395: ;
		goto b_return;
		/* line 8400 */
b_L8400: ;
		/* line 8405 */
b_L8405: ;
		b_v_ts=b_keep(b_lit("GET READY",9));
		b_v_txi=(16);
		b_v_tyi=(12);
		b_gosubStack[b_gosubSP++]=35; goto b_L7500;
b_ret35: ;
		/* line 8410 */
b_L8410: ;
		b_v_gdi=(1);
		if(b_v_gdi > 90) goto b_f14_e;
b_f14_t: ;
		/* line 8412 */
b_L8412: ;
		b_wait((53265.0),(128),0);
		b_wait((53265.0),(128),(128));
		/* line 8415 */
b_L8415: ;
		b_v_gdi += 1;
		if(b_v_gdi <= 90) goto b_f14_t;
b_f14_e: ;
		/* line 8418 */
b_L8418: ;
		b_gosubStack[b_gosubSP++]=36; goto b_L9000;
b_ret36: ;
		/* line 8420 */
b_L8420: ;
		goto b_return;
		/* line 8500 */
b_L8500: ;
		/* line 8505 */
b_L8505: ;
		b_putc(147);
		b_nl();
		/* line 8510 */
b_L8510: ;
		b_nl();
		{ bstr_t _t=b_lit("  *** GAME OVER ***",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8515 */
b_L8515: ;
		b_nl();
		{ bstr_t _t=b_lit("  SCORE:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 8520 */
b_L8520: ;
		{ bstr_t _t=b_lit("  LEVEL:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_lvi);
		b_nl();
		/* line 8525 */
b_L8525: ;
		b_nl();
		{ bstr_t _t=b_lit("  R=RESTART  Q=QUIT",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 8530 */
b_L8530: ;
		if(-((b_v_dmi) == ((1)))){ goto b_L8550; }
		/* line 8532 */
b_L8532: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L8532; }
		/* line 8535 */
b_L8535: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L50;
		}
		/* line 8540 */
b_L8540: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			goto b_L9500;
		}
		/* line 8545 */
b_L8545: ;
		goto b_L8530;
		/* line 8550 */
b_L8550: ;
		b_v_ji=(1);
		if(b_v_ji > 1500) goto b_f15_e;
b_f15_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 1500) goto b_f15_t;
b_f15_e: ;
		goto b_L50;
		/* line 9000 */
b_L9000: ;
		/* line 9005 */
b_L9005: ;
		b_v_ii=(1);
		if(b_v_ii > 24) goto b_f16_e;
b_f16_t: ;
		b_v_ji=(0);
		if(b_v_ji > 39) goto b_f17_e;
b_f17_t: ;
		/* line 9010 */
b_L9010: ;
		b_v_ti=b_a_mpi[B_INT(((((b_v_ii)*((40))))+(b_v_ji)))];
		b_gosubStack[b_gosubSP++]=37; goto b_L5900;
b_ret37: ;
		/* line 9015 */
b_L9015: ;
		b_poke((((((1024))+(((b_v_ii)*((40))))))+(b_v_ji)),b_v_tgi);
		/* line 9020 */
b_L9020: ;
		b_v_cci=(0);
		if(-((b_v_ti) == ((1)))){
			b_v_cci=(6);
		}
		/* line 9025 */
b_L9025: ;
		if(-((b_v_ti) == ((2)))){
			b_v_cci=(5);
		}
		/* line 9030 */
b_L9030: ;
		if(-((b_v_ti) == ((3)))){
			b_v_cci=(2);
		}
		/* line 9035 */
b_L9035: ;
		b_poke((((((55296.0))+(((b_v_ii)*((40))))))+(b_v_ji)),b_v_cci);
		/* line 9040 */
b_L9040: ;
		b_v_ji += 1;
		if(b_v_ji <= 39) goto b_f17_t;
b_f17_e: ;
		b_v_ii += 1;
		if(b_v_ii <= 24) goto b_f16_t;
b_f16_e: ;
		/* line 9045 */
b_L9045: ;
		goto b_return;
		/* line 9500 */
b_L9500: ;
		/* line 9505 */
b_L9505: ;
		b_putc(147);
		b_nl();
		goto b_end;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
