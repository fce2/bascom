/* OPTIMIZE_C -- frogger.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_fci;
static int b_v_cci;
static int b_v_lci;
static int b_v_wci;
static int b_v_dci;
static int b_v_rci;
static int b_a_lai[520];
static int b_a_rwi[13];
static bint_t b_a_tyi[13];
static bint_t b_a_dxi[13];
static bint_t b_a_mvi[13];
static int b_a_gpi[13];
static int b_a_wdi[13];
static bint_t b_a_cti[13];
static bint_t b_a_di[4];
static int b_a_shi[13];
static bint_t b_a_lni[25];
static int b_a_coi[13];
static bint_t b_v_sci;
static int b_v_gli;
static bint_t b_v_lei;
static int b_v_dli;
static int b_v_dri;
static bint_t b_v_fxi;
static bint_t b_v_fyi;
static bint_t b_v_sti;
static bint_t b_v_pxi;
static bint_t b_v_pyi;
static bint_t b_v_dmi;
static bint_t b_v_dti;
static bint_t b_v_ki;
static int b_v_ksi;
static bint_t b_v_lvi;
static bint_t b_v_mdi;
static bint_t b_v_ezi;
static int b_v_hhi;
static int b_v_ri;
static bint_t b_v_tgi;
static bstr_t b_v_ks;
static breal_t b_v_lf;
static breal_t b_v_lif;
static bint_t b_v_lxi;
static breal_t b_v_bf;
static bint_t b_v_ti;
static bint_t b_v_cii;
static int b_v_mi;
static bint_t b_v_mii;
static bint_t b_v_bai;
static int b_v_ski;
static bint_t b_v_kii;
static bint_t b_v_chi;
static bstr_t b_v_ts;
static bint_t b_v_hxi;
static bint_t b_v_hyi;
static int b_v_nii;
static int b_v_gxi;
static bint_t b_v_qci;
static bint_t b_v_sfi;
static bint_t b_v_ufi;
static int b_v_uxi;
static int b_v_ii;
static int b_v_cti;
static bint_t b_v_ci;
static bint_t b_v_ji;
static int b_v_r0i;
static int b_v_r1i;
static int b_v_r2i;
static int b_v_r3i;
static int b_v_r4i;
static int b_v_r5i;
static int b_v_r6i;
static int b_v_obi;
static int b_v_bgi;
static bint_t b_v_si;
static bint_t b_v_jii;
static bint_t b_v_pi;
static int b_v_cvi;
static bint_t b_v_M0;
static int b_v_M1;
static int b_v_M2;
static bint_t b_v_M3;
static bint_t b_v_M4;
static bint_t b_v_M5;
static breal_t b_v_M6;
static breal_t b_v_M7;
static bint_t b_v_M8;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;
static bint_t b_t_8;
static bint_t b_t_9;
static bint_t b_t_10;
static bint_t b_t_11;
static bint_t b_t_12;
static bint_t b_t_13;
static bint_t b_t_14;
static bint_t b_t_15;
static bint_t b_t_16;
static bint_t b_t_17;
static bint_t b_t_18;
static bint_t b_t_19;
static bint_t b_t_20;
static bint_t b_t_21;
static bint_t b_t_22;
static bint_t b_t_23;
static bint_t b_t_24;
static bint_t b_t_25;
static bint_t b_t_26;
static bint_t b_t_27;
static bint_t b_t_28;
static bint_t b_t_29;
static bint_t b_t_30;
static breal_t b_fl_11;
static breal_t b_fl_12;
static breal_t b_fl_15;
static breal_t b_fl_18;
static int b_fl_20;
static breal_t b_fl_25;
static bint_t b_fl_27;
static bint_t b_fl_28;
static breal_t b_fl_29;
static bint_t b_fl_31;
static bint_t b_fl_32;
static bint_t b_fl_36;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,4,0,0},{1,0,6,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,3,0,0},{1,0,14,0,0},{1,0,4,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,5,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,7,0,0},{1,0,20,0,0},{1,0,6,0,0},{1,0,14,0,0},{1,0,7,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,2,0,0},{1,0,2,0,0},{1,0,8,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,7,0,0},{1,0,9,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,1,0,0},{1,0,8,0,0},{1,0,10,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,10,0,0},{1,0,11,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,8,0,0},{1,0,2,0,0},{1,0,3,0,0},{1,0,2,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,4,0,0},{1,0,6,0,0},{1,0,3,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,3,0,0},{1,0,14,0,0},{1,0,4,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,3,0,0},{1,0,6,0,0},{1,0,5,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,7,0,0},{1,0,20,0,0},{1,0,6,0,0},{1,0,14,0,0},{1,0,6,0,0},{1,0,0,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,4,0,0},{1,0,6,0,0},{1,0,7,0,0},{1,0,0,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,3,0,0},{1,0,14,0,0},{1,0,9,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,2,0,0},{1,0,2,0,0},{1,0,10,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,7,0,0},{1,0,11,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,5,0,0},{1,0,1,0,0},{1,0,8,0,0},{1,0,12,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,10,0,0},{1,0,13,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,8,0,0},{1,0,2,0,0},{1,0,3,0,0},{1,0,14,0,0},{1,0,1,0,0},{1,0,-1,0,0},{1,0,5,0,0},{1,0,8,0,0},{1,0,2,0,0},{1,0,7,0,0},{1,0,15,0,0},{1,0,1,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,2,0,0},{1,0,10,0,0}};
int b_data_len = 154;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 11 */
b_L11: ;
		/* line 12 */
b_L12: ;
		/* line 13 */
b_L13: ;
		/* line 14 */
b_L14: ;
		/* line 20 */
b_L20: ;
		b_putc(147);
		b_nl();
		/* line 25 */
b_L25: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 30 */
b_L30: ;
		b_v_fci=(81);
		b_v_cci=(88);
		b_v_lci=(160);
		b_v_wci=(102);
		b_v_dci=(87);
		b_v_rci=(32);
		/* line 35 */
b_L35: ;
		/* line 40 */
b_L40: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1100;
b_ret0: ;
		/* line 42 */
b_L42: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L8000;
b_ret1: ;
		/* line 45 */
b_L45: ;
		b_v_sci=(0);
		b_v_gli=(0);
		b_v_lei=(1);
		b_v_dli=(15);
		b_v_dri=(0);
		/* line 50 */
b_L50: ;
		b_v_fxi=(20);
		b_v_fyi=b_v_sti;
		b_v_pxi=(20);
		b_v_pyi=b_v_sti;
		/* line 55 */
b_L55: ;
		b_putc(147);
		b_nl();
		b_gosubStack[b_gosubSP++]=2; goto b_L8300;
b_ret2: ;
		/* line 60 */
b_L60: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L7000;
b_ret3: ;
		/* line 62 */
b_L62: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=4; goto b_L5650;
b_ret4: ;
		}
		/* line 65 */
b_L65: ;
		b_poke((((((1024))+(((b_v_fyi)*((40))))))+(b_v_fxi)),b_v_fci);
		b_poke((((((55296.0))+(((b_v_fyi)*((40))))))+(b_v_fxi)),(7));
		/* line 67 */
b_L67: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L4000;
b_ret5: ;
		/* line 70 */
b_L70: ;
		/* line 71 */
b_L71: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_dti=((b_v_dti)+((1)));
			if(-((b_v_dti) >= ((5)))){
				b_v_dti=(0);
				goto b_L80;
			}
		}
		/* line 72 */
b_L72: ;
		if(-((b_v_dmi) == ((1)))){
			goto b_L170;
		}
		/* line 80 */
b_L80: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L3000;
b_ret6: ;
		/* line 90 */
b_L90: ;
		b_gosubStack[b_gosubSP++]=7; goto b_L5000;
b_ret7: ;
		/* line 100 */
b_L100: ;
		if(-((b_v_dri) == ((1)))){
			b_gosubStack[b_gosubSP++]=8; goto b_L9000;
b_ret8: ;
			goto b_L70;
		}
		/* line 110 */
b_L110: ;
		b_v_ki=B_INT(b_peek((unsigned int)((197))));
		b_poke((198),(0));
		b_v_ksi=(B_INT(B_INT(b_peek((unsigned int)((653))))) & B_INT((1)));
		/* line 112 */
b_L112: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((14)))){
				b_v_dmi=(0);
				b_v_lvi=(5);
				b_v_sti=(12);
				b_v_mdi=(6);
				b_v_ezi=(1);
				goto b_L42;
			}
		}
		/* line 113 */
b_L113: ;
		if(-((b_v_dmi) == ((1)))){
			if(-((b_v_ki) == ((29)))){
				b_v_dmi=(0);
				b_v_lvi=(3);
				b_v_sti=(16);
				b_v_mdi=(8);
				b_v_ezi=(0);
				goto b_L42;
			}
		}
		/* line 114 */
b_L114: ;
		if(-((b_v_dmi) == ((1)))){
			b_gosubStack[b_gosubSP++]=9; goto b_L5700;
b_ret9: ;
		}
		/* line 115 */
b_L115: ;
		if(-((b_v_ki) == ((7)))){
			if(b_v_ksi){
				b_v_ki=(9);
			}
		}
		/* line 116 */
b_L116: ;
		if(-((b_v_ki) == ((7)))){
			if(-((b_v_ksi) == ((0)))){
				b_v_ki=(13);
			}
		}
		/* line 117 */
b_L117: ;
		if(-((b_v_ki) == ((2)))){
			if(b_v_ksi){
				b_v_ki=(10);
			}
		}
		/* line 118 */
b_L118: ;
		if(-((b_v_ki) == ((2)))){
			if(-((b_v_ksi) == ((0)))){
				b_v_ki=(18);
			}
		}
		/* line 120 */
b_L120: ;
		if(-((b_v_ki) == ((62)))){
			b_sys((64738.0));
		}
		/* line 130 */
b_L130: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L2500;
b_ret10: ;
		/* line 140 */
b_L140: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L5000;
b_ret11: ;
		/* line 150 */
b_L150: ;
		if(-((b_v_dri) == ((1)))){
			b_gosubStack[b_gosubSP++]=12; goto b_L9000;
b_ret12: ;
			goto b_L70;
		}
		/* line 160 */
b_L160: ;
		b_gosubStack[b_gosubSP++]=13; goto b_L2000;
b_ret13: ;
		/* line 170 */
b_L170: ;
		b_poke((((((1024))+(((b_v_fyi)*((40))))))+(b_v_fxi)),b_v_fci);
		b_poke((((((55296.0))+(((b_v_fyi)*((40))))))+(b_v_fxi)),(7));
		b_v_pxi=b_v_fxi;
		b_v_pyi=b_v_fyi;
		/* line 180 */
b_L180: ;
		b_gosubStack[b_gosubSP++]=14; goto b_L4000;
b_ret14: ;
		/* line 190 */
b_L190: ;
		b_wait((53265.0),(128),0);
		/* line 200 */
b_L200: ;
		goto b_L70;
		/* line 1100 */
b_L1100: ;
		/* line 1105 */
b_L1105: ;
		b_putc(147);
		b_nl();
		/* line 1106 */
b_L1106: ;
		b_v_hhi=(0);
		if(b_v_hhi > 39) goto b_f0_e;
		b_t_0=(((1024))+(b_v_hhi));
		b_t_1=(((55296.0))+(b_v_hhi));
b_f0_t: ;
		b_poke(b_t_0,(160));
		b_poke(b_t_1,(7));
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 39) goto b_f0_t;
b_f0_e: ;
		/* line 1107 */
b_L1107: ;
		b_v_hhi=(0);
		if(b_v_hhi > 39) goto b_f1_e;
		b_t_2=(((1984))+(b_v_hhi));
		b_t_3=(((((55296.0))+((960))))+(b_v_hhi));
b_f1_t: ;
		b_poke(b_t_2,(160));
		b_poke(b_t_3,(7));
		b_t_2 += 1;
		b_t_3 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 39) goto b_f1_t;
b_f1_e: ;
		/* line 1110 */
b_L1110: ;
		b_v_hhi=(3);
		if(b_v_hhi > 36) goto b_f2_e;
		b_t_4=(((1144))+(b_v_hhi));
		b_t_5=(((((55296.0))+((120))))+(b_v_hhi));
b_f2_t: ;
		b_poke(b_t_4,(81));
		b_poke(b_t_5,(5));
		b_t_4 += 1;
		b_t_5 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 36) goto b_f2_t;
b_f2_e: ;
		/* line 1112 */
b_L1112: ;
		b_v_hhi=(3);
		if(b_v_hhi > 36) goto b_f3_e;
		b_t_6=(((1544))+(b_v_hhi));
		b_t_7=(((((55296.0))+((520))))+(b_v_hhi));
b_f3_t: ;
		b_poke(b_t_6,(87));
		b_poke(b_t_7,(5));
		b_t_6 += 1;
		b_t_7 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 36) goto b_f3_t;
b_f3_e: ;
		/* line 1114 */
b_L1114: ;
		b_poke((214),(4));
		b_nl();
		b_tab((11));
		{ bstr_t _t=b_lit("**** FROGGER ****",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1116 */
b_L1116: ;
		b_poke((214),(6));
		b_nl();
		b_tab((9));
		{ bstr_t _t=b_lit("CROSS ROAD AND RIVER",20); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1118 */
b_L1118: ;
		b_poke((214),(7));
		b_nl();
		b_tab((10));
		{ bstr_t _t=b_lit("TO THE HOMES AT TOP",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1120 */
b_L1120: ;
		b_poke((214),(9));
		b_nl();
		b_tab((6));
		{ bstr_t _t=b_lit("W/S UP-DOWN  A/D LEFT-RIGHT",27); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1122 */
b_L1122: ;
		b_poke((214),(10));
		b_nl();
		b_tab((16));
		{ bstr_t _t=b_lit("Q = QUIT",8); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1124 */
b_L1124: ;
		b_poke((214),(14));
		b_nl();
		b_tab((8));
		{ bstr_t _t=b_lit("CHOOSE:  E=EASY   H=HARD",24); b_str(_t.p,_t.len); }
		b_nl();
		/* line 1126 */
b_L1126: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f4_e;
		b_t_8=(((((55296.0))+((200))))+(b_v_hhi));
b_f4_t: ;
		b_poke(b_t_8,(7));
		b_t_8 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f4_t;
b_f4_e: ;
		/* line 1128 */
b_L1128: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f5_e;
		b_t_9=(((((55296.0))+((280))))+(b_v_hhi));
		b_t_10=(((((55296.0))+((320))))+(b_v_hhi));
b_f5_t: ;
		b_poke(b_t_9,(3));
		b_poke(b_t_10,(3));
		b_t_9 += 1;
		b_t_10 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f5_t;
b_f5_e: ;
		/* line 1130 */
b_L1130: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f6_e;
		b_t_11=(((((55296.0))+((400))))+(b_v_hhi));
		b_t_12=(((((55296.0))+((440))))+(b_v_hhi));
b_f6_t: ;
		b_poke(b_t_11,(1));
		b_poke(b_t_12,(1));
		b_t_11 += 1;
		b_t_12 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f6_t;
b_f6_e: ;
		/* line 1132 */
b_L1132: ;
		b_v_hhi=(2);
		if(b_v_hhi > 37) goto b_f7_e;
		b_t_13=(((((55296.0))+((600))))+(b_v_hhi));
b_f7_t: ;
		b_poke(b_t_13,(1));
		b_t_13 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 37) goto b_f7_t;
b_f7_e: ;
		/* line 1134 */
b_L1134: ;
		b_v_hhi=(17);
		if(b_v_hhi > 22) goto b_f8_e;
		b_t_14=(((((55296.0))+((600))))+(b_v_hhi));
b_f8_t: ;
		b_poke(b_t_14,(5));
		b_t_14 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 22) goto b_f8_t;
b_f8_e: ;
		/* line 1136 */
b_L1136: ;
		b_v_hhi=(26);
		if(b_v_hhi > 31) goto b_f9_e;
		b_t_15=(((((55296.0))+((600))))+(b_v_hhi));
b_f9_t: ;
		b_poke(b_t_15,(2));
		b_t_15 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 31) goto b_f9_t;
b_f9_e: ;
		/* line 1138 */
b_L1138: ;
		b_v_ri=(1);
		if(b_v_ri > 23) goto b_f10_e;
		b_t_16=(((1024))+(((b_v_ri)*((40)))));
		b_t_17=(((55296.0))+(((b_v_ri)*((40)))));
		b_t_18=(((((1024))+(((b_v_ri)*((40))))))+((39)));
		b_t_19=(((((55296.0))+(((b_v_ri)*((40))))))+((39)));
b_f10_t: ;
		b_poke(b_t_16,(102));
		b_poke(b_t_17,(7));
		b_poke(b_t_18,(102));
		b_poke(b_t_19,(7));
		b_t_16 += 40;
		b_t_17 += 40;
		b_t_18 += 40;
		b_t_19 += 40;
		b_v_ri += 1;
		if(b_v_ri <= 23) goto b_f10_t;
b_f10_e: ;
		/* line 1144 */
b_L1144: ;
		b_v_tgi=(0);
		/* line 1146 */
b_L1146: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("E",1)) == 0)){
			b_v_lvi=(5);
			b_v_sti=(12);
			b_v_mdi=(6);
			b_v_ezi=(1);
			b_v_dmi=(0);
			goto b_L1170;
		}
		/* line 1148 */
b_L1148: ;
		if(-(b_strcmp(b_v_ks,b_lit("H",1)) == 0)){
			b_v_lvi=(3);
			b_v_sti=(16);
			b_v_mdi=(8);
			b_v_ezi=(0);
			b_v_dmi=(0);
			goto b_L1170;
		}
		/* line 1149 */
b_L1149: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 1152 */
b_L1152: ;
		b_v_tgi=((b_v_tgi)+((1)));
		if(-((b_v_tgi) > ((10000)))){
			b_v_lvi=(5);
			b_v_sti=(12);
			b_v_mdi=(6);
			b_v_ezi=(1);
			b_v_dmi=(1);
			goto b_L1170;
		}
		/* line 1153 */
b_L1153: ;
		goto b_L1146;
		/* line 1170 */
b_L1170: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1205 */
b_L1205: ;
		b_v_lf=(0);
		b_fl_11=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_11) goto b_f11_e;
b_f11_t: ;
		b_v_lif=b_v_lf;
		b_a_mvi[(bint_t)(b_v_lif)]=((b_a_mvi[(bint_t)(b_v_lif)])*((2)));
		if(-((b_a_mvi[(bint_t)(b_v_lif)]) > ((14)))){
			b_a_mvi[(bint_t)(b_v_lif)]=(14);
		}
		/* line 1206 */
b_L1206: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_11)) goto b_f11_t;
b_f11_e: ;
		/* line 1210 */
b_L1210: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2005 */
b_L2005: ;
		if(-((b_v_pyi) < ((0)))){
			goto b_return;
		}
		/* line 2007 */
b_L2007: ;
		if(-((b_v_pyi) > ((24)))){
			goto b_return;
		}
		/* line 2010 */
b_L2010: ;
		b_v_lxi=b_a_lni[B_INT(b_v_pyi)];
		b_v_rci=(5);
		if(-((b_v_lxi) >= ((0)))){
			b_v_rci=b_a_coi[B_INT(b_v_lxi)];
		}
		/* line 2011 */
b_L2011: ;
		if(-((b_v_pyi) == (b_v_sti))){
			b_v_rci=(13);
		}
		/* line 2015 */
b_L2015: ;
		if(-((b_v_lxi) >= ((0)))){
			b_poke((((((1024))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_a_lai[B_INT(((((b_v_lxi)*((40))))+(b_v_pxi)))]);
			b_poke((((((55296.0))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_rci);
			goto b_return;
		}
		/* line 2020 */
b_L2020: ;
		if(-((b_v_pyi) == ((1)))){
			b_poke((((((1024))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_dci);
			b_poke((((((55296.0))+(((b_v_pyi)*((40))))))+(b_v_pxi)),(5));
			goto b_return;
		}
		/* line 2025 */
b_L2025: ;
		b_poke((((((1024))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_wci);
		b_poke((((((55296.0))+(((b_v_pyi)*((40))))))+(b_v_pxi)),b_v_rci);
		goto b_return;
		/* line 2030 */
b_L2030: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2505 */
b_L2505: ;
		if(-((b_v_ki) == ((9)))){
			if(-((b_v_fyi) > ((1)))){
				b_v_fyi=((b_v_fyi)-((1)));
			}
		}
		/* line 2515 */
b_L2515: ;
		if(-((b_v_ki) == ((13)))){
			if(-((b_v_fyi) < (b_v_sti))){
				b_v_fyi=((b_v_fyi)+((1)));
			}
		}
		/* line 2525 */
b_L2525: ;
		if(-((b_v_ki) == ((10)))){
			if(-((b_v_fxi) > ((0)))){
				b_v_fxi=((b_v_fxi)-((1)));
			}
		}
		/* line 2535 */
b_L2535: ;
		if(-((b_v_ki) == ((18)))){
			if(-((b_v_fxi) < ((39)))){
				b_v_fxi=((b_v_fxi)+((1)));
			}
		}
		/* line 2545 */
b_L2545: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3005 */
b_L3005: ;
		b_v_lf=(0);
		b_fl_12=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_12) goto b_f12_e;
b_f12_t: ;
		/* line 3006 */
b_L3006: ;
		b_v_lif=b_v_lf;
		/* line 3010 */
b_L3010: ;
		b_a_cti[(bint_t)(b_v_lif)]=((b_a_cti[(bint_t)(b_v_lif)])+((1)));
		/* line 3015 */
b_L3015: ;
		if(-((b_a_cti[(bint_t)(b_v_lif)]) < (b_a_mvi[(bint_t)(b_v_lif)]))){ goto b_L3070; }
		/* line 3020 */
b_L3020: ;
		b_a_cti[(bint_t)(b_v_lif)]=(0);
		b_a_shi[(bint_t)(b_v_lif)]=(1);
		/* line 3025 */
b_L3025: ;
		if(-((b_a_dxi[(bint_t)(b_v_lif)]) == ((1)))){
			b_v_bf=((b_v_lif)*((40)));
			b_v_ti=b_a_lai[(bint_t)(((b_v_bf)+((39))))];
			b_v_hhi=(39);
			if(b_v_hhi < 1) goto b_f13_e;
b_f13_t: ;
			b_v_cii=b_v_hhi;
			b_a_lai[(bint_t)(((b_v_bf)+(b_v_cii)))]=b_a_lai[(bint_t)(((((b_v_bf)+(b_v_cii)))-((1))))];
			b_v_hhi += -1;
			if(b_v_hhi >= 1) goto b_f13_t;
b_f13_e: ;
			b_a_lai[(bint_t)(((b_v_bf)+((0))))]=b_v_ti;
		}
		/* line 3026 */
b_L3026: ;
		if(-((b_a_dxi[(bint_t)(b_v_lif)]) != ((1)))){
			b_v_bf=((b_v_lif)*((40)));
			b_v_ti=b_a_lai[(bint_t)(((b_v_bf)+((0))))];
			b_v_mi=(0);
			if(b_v_mi > 38) goto b_f14_e;
b_f14_t: ;
			b_v_mii=b_v_mi;
			b_a_lai[(bint_t)(((b_v_bf)+(b_v_mii)))]=b_a_lai[(bint_t)(((((b_v_bf)+(b_v_mii)))+((1))))];
			b_v_mi += 1;
			if(b_v_mi <= 38) goto b_f14_t;
b_f14_e: ;
			b_a_lai[(bint_t)(((b_v_bf)+((39))))]=b_v_ti;
		}
		/* line 3030 */
b_L3030: ;
		if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
			if(-((b_v_fyi) == (b_a_rwi[(bint_t)(b_v_lif)]))){
				b_gosubStack[b_gosubSP++]=15; goto b_L3300;
b_ret15: ;
			}
		}
		/* line 3070 */
b_L3070: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_12)) goto b_f12_t;
b_f12_e: ;
		/* line 3075 */
b_L3075: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3105 */
b_L3105: ;
		/* line 3300 */
b_L3300: ;
		/* line 3310 */
b_L3310: ;
		b_v_fxi=((b_v_fxi)+(b_a_dxi[(bint_t)(b_v_lif)]));
		/* line 3315 */
b_L3315: ;
		if(-((b_v_fxi) < ((0)))){
			b_v_dri=(1);
		}
		/* line 3320 */
b_L3320: ;
		if(-((b_v_fxi) > ((39)))){
			b_v_dri=(1);
		}
		/* line 3325 */
b_L3325: ;
		goto b_return;
		/* line 4000 */
b_L4000: ;
		/* line 4005 */
b_L4005: ;
		b_v_lf=(0);
		b_fl_15=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_15) goto b_f15_e;
b_f15_t: ;
		/* line 4006 */
b_L4006: ;
		b_v_lif=b_v_lf;
		/* line 4008 */
b_L4008: ;
		if(-((b_a_shi[(bint_t)(b_v_lif)]) == ((0)))){ goto b_L4020; }
		/* line 4010 */
b_L4010: ;
		b_v_bf=((b_v_lif)*((40)));
		b_v_bai=(((1024))+(((b_a_rwi[(bint_t)(b_v_lif)])*((40)))));
		/* line 4012 */
b_L4012: ;
		b_v_ski=(0);
		if(-((b_a_rwi[(bint_t)(b_v_lif)]) == (b_v_fyi))){
			b_v_ski=(1);
		}
		/* line 4015 */
b_L4015: ;
		b_v_hhi=(0);
		if(b_v_hhi > 39) goto b_f16_e;
		b_v_M0=b_a_rwi[(bint_t)(b_v_lif)];
		b_v_M1=b_a_coi[(bint_t)(b_v_lif)];
b_f16_t: ;
		b_v_cii=b_v_hhi;
		/* line 4016 */
b_L4016: ;
		if((B_INT(-((b_v_ski) == ((0)))) | B_INT(-((b_v_cii) != (b_v_fxi))))){
			b_poke(((b_v_bai)+(b_v_cii)),b_a_lai[(bint_t)(((b_v_bf)+(b_v_cii)))]);
			b_poke((((((55296.0))+(((b_v_M0)*((40))))))+(b_v_cii)),b_v_M1);
		}
		/* line 4017 */
b_L4017: ;
		b_v_hhi += 1;
		if(b_v_hhi <= 39) goto b_f16_t;
b_f16_e: ;
		/* line 4020 */
b_L4020: ;
		b_a_shi[(bint_t)(b_v_lif)]=(0);
		/* line 4025 */
b_L4025: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_15)) goto b_f15_t;
b_f15_e: ;
		/* line 4030 */
b_L4030: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5005 */
b_L5005: ;
		b_v_dri=(0);
		/* line 5010 */
b_L5010: ;
		if(-((b_v_fyi) == ((1)))){
			b_gosubStack[b_gosubSP++]=16; goto b_L5400;
b_ret16: ;
			goto b_return;
		}
		/* line 5015 */
b_L5015: ;
		if(-((b_v_fyi) == (b_v_mdi))){
			goto b_return;
		}
		/* line 5020 */
b_L5020: ;
		if(-((b_v_fyi) == (b_v_sti))){
			goto b_return;
		}
		/* line 5025 */
b_L5025: ;
		b_v_lif=(-1);
		b_v_ki=(0);
		if(b_v_ki > 8) goto b_f17_e;
b_f17_t: ;
		b_v_kii=b_v_ki;
		if(-((b_a_rwi[B_INT(b_v_kii)]) == (b_v_fyi))){
			b_v_lif=b_v_kii;
		}
		/* line 5030 */
b_L5030: ;
		b_v_ki += 1;
		if(b_v_ki <= 8) goto b_f17_t;
b_f17_e: ;
		/* line 5035 */
b_L5035: ;
		if(-((b_v_lif) < ((0)))){
			goto b_return;
		}
		/* line 5040 */
b_L5040: ;
		if(-((b_v_fxi) < ((0)))){
			b_v_dri=(1);
			goto b_return;
		}
		/* line 5045 */
b_L5045: ;
		if(-((b_v_fxi) > ((39)))){
			b_v_dri=(1);
			goto b_return;
		}
		/* line 5050 */
b_L5050: ;
		b_v_chi=b_a_lai[(bint_t)(((((b_v_lif)*((40))))+(b_v_fxi)))];
		/* line 5055 */
b_L5055: ;
		if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((1)))){
			if(-((b_v_chi) == (b_v_cci))){
				b_v_dri=(1);
				goto b_return;
			}
		}
		/* line 5060 */
b_L5060: ;
		if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
			if(-((b_v_chi) == (b_v_wci))){
				b_v_dri=(1);
				goto b_return;
			}
		}
		/* line 5065 */
b_L5065: ;
		goto b_return;
		/* line 5400 */
b_L5400: ;
		/* line 5405 */
b_L5405: ;
		b_v_sci=((b_v_sci)+((50)));
		b_v_gli=((b_v_gli)+((1)));
		/* line 5408 */
b_L5408: ;
		b_gosubStack[b_gosubSP++]=17; goto b_L7300;
b_ret17: ;
		/* line 5410 */
b_L5410: ;
		b_poke((((1064))+(b_v_fxi)),b_v_fci);
		b_poke((((((55296.0))+((40))))+(b_v_fxi)),(7));
		/* line 5415 */
b_L5415: ;
		if(-((b_v_gli) >= ((5)))){
			b_v_gli=(0);
			b_v_lei=((b_v_lei)+((1)));
			b_gosubStack[b_gosubSP++]=18; goto b_L5500;
b_ret18: ;
			b_gosubStack[b_gosubSP++]=19; goto b_L7000;
b_ret19: ;
		}
		/* line 5420 */
b_L5420: ;
		b_v_fxi=(20);
		b_v_fyi=b_v_sti;
		b_v_pxi=(20);
		b_v_pyi=b_v_sti;
		/* line 5425 */
b_L5425: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5505 */
b_L5505: ;
		b_v_lf=(0);
		b_fl_18=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_18) goto b_f18_e;
b_f18_t: ;
		b_v_lif=b_v_lf;
		if(-((b_a_mvi[(bint_t)(b_v_lif)]) > ((2)))){
			b_a_mvi[(bint_t)(b_v_lif)]=((b_a_mvi[(bint_t)(b_v_lif)])-((1)));
		}
		/* line 5510 */
b_L5510: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_18)) goto b_f18_t;
b_f18_e: ;
		/* line 5512 */
b_L5512: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L7300;
b_ret20: ;
		/* line 5515 */
b_L5515: ;
		goto b_return;
		/* line 5650 */
b_L5650: ;
		/* line 5655 */
b_L5655: ;
		b_v_ts=b_keep(b_lit("DEMO E=EASY H=HARD",18));
		b_v_hxi=(10);
		b_v_hyi=(23);
		b_gosubStack[b_gosubSP++]=21; goto b_L6000;
b_ret21: ;
		/* line 5660 */
b_L5660: ;
		b_v_hhi=(10);
		if(b_v_hhi > 27) goto b_f19_e;
		b_t_20=(((((55296.0))+((920))))+(b_v_hhi));
b_f19_t: ;
		b_poke(b_t_20,(7));
		b_t_20 += 1;
		b_v_hhi += 1;
		if(b_v_hhi <= 27) goto b_f19_t;
b_f19_e: ;
		/* line 5665 */
b_L5665: ;
		goto b_return;
		/* line 5700 */
b_L5700: ;
		/* line 5705 */
b_L5705: ;
		b_v_ki=(64);
		/* line 5710 */
b_L5710: ;
		if(-((b_v_fyi) <= ((1)))){
			goto b_return;
		}
		/* line 5715 */
b_L5715: ;
		b_v_lif=b_a_lni[B_INT(b_v_fyi)];
		/* line 5720 */
b_L5720: ;
		if(-((b_v_lif) >= ((0)))){
			if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
				if(-((b_v_fxi) < ((6)))){
					if(-((b_a_lai[(bint_t)(((((((b_v_lif)*((40))))+(b_v_fxi)))+((1))))]) == (b_v_lci))){
						b_v_ki=(18);
						goto b_return;
					}
				}
			}
		}
		/* line 5721 */
b_L5721: ;
		if(-((b_v_lif) >= ((0)))){
			if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
				if(-((b_v_fxi) > ((33)))){
					if(-((b_a_lai[(bint_t)(((((((b_v_lif)*((40))))+(b_v_fxi)))-((1))))]) == (b_v_lci))){
						b_v_ki=(10);
						goto b_return;
					}
				}
			}
		}
		/* line 5725 */
b_L5725: ;
		b_v_nii=b_a_lni[B_INT(((b_v_fyi)-((1))))];
		/* line 5728 */
b_L5728: ;
		b_v_gxi=(20);
		if(-((b_v_gli) == ((0)))){
			b_v_gxi=(12);
		}
		/* line 5729 */
b_L5729: ;
		if(-((b_v_gli) == ((1)))){
			b_v_gxi=(28);
		}
		/* line 5730 */
b_L5730: ;
		if(-((b_v_gli) == ((2)))){
			b_v_gxi=(16);
		}
		/* line 5731 */
b_L5731: ;
		if(-((b_v_gli) == ((3)))){
			b_v_gxi=(24);
		}
		/* line 5732 */
b_L5732: ;
		/* line 5733 */
b_L5733: ;
		/* line 5735 */
b_L5735: ;
		if(-((b_v_fxi) < (b_v_gxi))){
			b_v_qci=((b_v_fxi)+((1)));
			b_gosubStack[b_gosubSP++]=22; goto b_L5780;
b_ret22: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(18);
				goto b_return;
			}
		}
		/* line 5736 */
b_L5736: ;
		if(-((b_v_fxi) > (b_v_gxi))){
			b_v_qci=((b_v_fxi)-((1)));
			b_gosubStack[b_gosubSP++]=23; goto b_L5780;
b_ret23: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(10);
				goto b_return;
			}
		}
		/* line 5737 */
b_L5737: ;
		if(-((b_v_nii) < ((0)))){
			b_v_ki=(9);
			goto b_return;
		}
		/* line 5738 */
b_L5738: ;
		if(-((b_a_tyi[B_INT(b_v_nii)]) == ((0)))){
			if(-((b_a_lai[B_INT(((((b_v_nii)*((40))))+(b_v_fxi)))]) == (b_v_lci))){
				b_v_ki=(9);
				goto b_return;
			}
		}
		/* line 5739 */
b_L5739: ;
		if(-((b_a_tyi[B_INT(b_v_nii)]) == ((1)))){
			b_v_qci=b_v_fxi;
			b_gosubStack[b_gosubSP++]=24; goto b_L5805;
b_ret24: ;
			if(-((b_v_ufi) == ((1)))){
				b_v_ki=(9);
				goto b_return;
			}
		}
		/* line 5740 */
b_L5740: ;
		/* line 5741 */
b_L5741: ;
		if(-((b_v_fxi) < ((20)))){ goto b_L5748; }
		/* line 5742 */
b_L5742: ;
		b_v_qci=((b_v_fxi)-((1)));
		if(-((b_v_qci) >= ((0)))){
			b_gosubStack[b_gosubSP++]=25; goto b_L5780;
b_ret25: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(10);
				goto b_return;
			}
		}
		/* line 5744 */
b_L5744: ;
		b_v_qci=((b_v_fxi)+((1)));
		if(-((b_v_qci) < ((40)))){
			b_gosubStack[b_gosubSP++]=26; goto b_L5780;
b_ret26: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(18);
				goto b_return;
			}
		}
		/* line 5746 */
b_L5746: ;
		goto b_return;
		/* line 5748 */
b_L5748: ;
		b_v_qci=((b_v_fxi)+((1)));
		if(-((b_v_qci) < ((40)))){
			b_gosubStack[b_gosubSP++]=27; goto b_L5780;
b_ret27: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(18);
				goto b_return;
			}
		}
		/* line 5749 */
b_L5749: ;
		b_v_qci=((b_v_fxi)-((1)));
		if(-((b_v_qci) >= ((0)))){
			b_gosubStack[b_gosubSP++]=28; goto b_L5780;
b_ret28: ;
			if(-((b_v_sfi) == ((1)))){
				b_v_ki=(10);
				goto b_return;
			}
		}
		/* line 5750 */
b_L5750: ;
		goto b_return;
		/* line 5780 */
b_L5780: ;
		/* line 5785 */
b_L5785: ;
		b_v_sfi=(0);
		/* line 5786 */
b_L5786: ;
		if(-((b_v_lif) >= ((0)))){
			if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
				if(-((b_a_lai[(bint_t)(((((b_v_lif)*((40))))+(b_v_qci)))]) != (b_v_lci))){
					goto b_return;
				}
			}
		}
		/* line 5787 */
b_L5787: ;
		if(-((b_v_lif) >= ((0)))){
			if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((1)))){
				if(-((b_a_lai[(bint_t)(((((b_v_lif)*((40))))+(b_v_qci)))]) == (b_v_cci))){
					goto b_return;
				}
			}
		}
		/* line 5788 */
b_L5788: ;
		if(-((b_v_lif) >= ((0)))){
			if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((1)))){
				b_v_uxi=((b_v_qci)-(b_a_dxi[(bint_t)(b_v_lif)]));
				if(-((b_v_uxi) < ((0)))){
					b_v_uxi=(39);
					if(-((b_v_uxi) > ((39)))){
						b_v_uxi=(0);
						if(-((b_a_lai[(bint_t)(((((b_v_lif)*((40))))+(b_v_uxi)))]) == (b_v_cci))){
							goto b_return;
						}
					}
				}
			}
		}
		/* line 5789 */
b_L5789: ;
		if(-((b_v_nii) < ((0)))){
			b_v_sfi=(1);
			goto b_return;
		}
		/* line 5790 */
b_L5790: ;
		if(-((b_a_tyi[B_INT(b_v_nii)]) == ((0)))){
			if(-((b_a_lai[B_INT(((((b_v_nii)*((40))))+(b_v_qci)))]) == (b_v_lci))){
				b_v_sfi=(1);
				goto b_return;
			}
		}
		/* line 5791 */
b_L5791: ;
		if(-((b_a_tyi[B_INT(b_v_nii)]) == ((1)))){
			b_gosubStack[b_gosubSP++]=29; goto b_L5805;
b_ret29: ;
			if(-((b_v_ufi) == ((1)))){
				b_v_sfi=(1);
				goto b_return;
			}
		}
		/* line 5792 */
b_L5792: ;
		goto b_return;
		/* line 5805 */
b_L5805: ;
		/* line 5806 */
b_L5806: ;
		b_v_ufi=(0);
		/* line 5807 */
b_L5807: ;
		if(-((b_a_lai[B_INT(((((b_v_nii)*((40))))+(b_v_qci)))]) == (b_v_cci))){
			goto b_return;
		}
		/* line 5808 */
b_L5808: ;
		b_v_uxi=((b_v_qci)-(b_a_dxi[B_INT(b_v_nii)]));
		/* line 5809 */
b_L5809: ;
		if(-((b_v_uxi) < ((0)))){
			b_v_uxi=(39);
		}
		/* line 5810 */
b_L5810: ;
		if(-((b_v_uxi) > ((39)))){
			b_v_uxi=(0);
		}
		/* line 5811 */
b_L5811: ;
		if(-((b_a_lai[B_INT(((((b_v_nii)*((40))))+(b_v_uxi)))]) != (b_v_cci))){
			b_v_ufi=(1);
		}
		/* line 5812 */
b_L5812: ;
		goto b_return;
		/* line 6000 */
b_L6000: ;
		/* line 6005 */
b_L6005: ;
		b_v_ii=(1);
		b_fl_20=B_INT(b_len(b_v_ts));
		if(b_v_ii > b_fl_20) goto b_f20_e;
		b_v_M2=(((1024))+(b_v_hxi));
		b_v_M3=((b_v_hyi)*((40)));
		b_t_21=((((((b_v_M2)+(b_v_ii)))-((1))))+(b_v_M3));
b_f20_t: ;
		/* line 6010 */
b_L6010: ;
		b_v_cti=b_asc(b_mid(b_v_ts,B_INT(b_v_ii),B_INT((1))));
		/* line 6015 */
b_L6015: ;
		if(-((b_v_cti) >= ((64)))){
			if(-((b_v_cti) <= ((95)))){
				b_v_cti=((b_v_cti)-((64)));
			}
		}
		/* line 6020 */
b_L6020: ;
		b_poke(b_t_21,b_v_cti);
		/* line 6025 */
b_L6025: ;
		b_t_21 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_20)) goto b_f20_t;
b_f20_e: ;
		/* line 6030 */
b_L6030: ;
		goto b_return;
		/* line 7000 */
b_L7000: ;
		/* line 7005 */
b_L7005: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f21_e;
		b_v_M4=(((1024))+(((b_v_mdi)*((40)))));
		b_v_M5=(((1024))+(((b_v_sti)*((40)))));
		b_t_22=(((1064))+(b_v_ci));
		b_t_23=((b_v_M4)+(b_v_ci));
		b_t_24=((b_v_M5)+(b_v_ci));
b_f21_t: ;
		/* line 7010 */
b_L7010: ;
		b_poke(b_t_22,b_v_dci);
		/* line 7015 */
b_L7015: ;
		b_poke(b_t_23,b_v_wci);
		/* line 7020 */
b_L7020: ;
		b_poke(b_t_24,b_v_wci);
		/* line 7025 */
b_L7025: ;
		b_t_22 += 1;
		b_t_23 += 1;
		b_t_24 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f21_t;
b_f21_e: ;
		/* line 7030 */
b_L7030: ;
		b_v_ts=b_keep(b_lit("SCORE",5));
		b_v_hxi=(0);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=30; goto b_L6000;
b_ret30: ;
		/* line 7035 */
b_L7035: ;
		b_v_ts=b_keep(b_lit("LIVES",5));
		b_v_hxi=(11);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=31; goto b_L6000;
b_ret31: ;
		/* line 7040 */
b_L7040: ;
		b_v_ts=b_keep(b_lit("LEVEL",5));
		b_v_hxi=(20);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=32; goto b_L6000;
b_ret32: ;
		/* line 7045 */
b_L7045: ;
		b_v_ts=b_keep(b_lit("HOME",4));
		b_v_hxi=(29);
		b_v_hyi=(0);
		b_gosubStack[b_gosubSP++]=33; goto b_L6000;
b_ret33: ;
		/* line 7046 */
b_L7046: ;
		if(-((b_v_dmi) == ((1)))){
			b_v_ts=b_keep(b_lit("DEMO",4));
			b_v_hxi=(36);
			b_v_hyi=(0);
			b_gosubStack[b_gosubSP++]=34; goto b_L6000;
b_ret34: ;
		}
		/* line 7047 */
b_L7047: ;
		if(-((b_v_dmi) == ((0)))){
			b_poke((1060),(32));
			b_poke((1061),(32));
			b_poke((1062),(32));
			b_poke((1063),(32));
		}
		/* line 7050 */
b_L7050: ;
		b_gosubStack[b_gosubSP++]=35; goto b_L7300;
b_ret35: ;
		/* line 7055 */
b_L7055: ;
		goto b_return;
		/* line 7300 */
b_L7300: ;
		/* line 7305 */
b_L7305: ;
		b_v_ti=b_v_sci;
		b_v_ji=(0);
		if(b_v_ji > 3) goto b_f22_e;
b_f22_t: ;
		b_a_di[B_INT(b_v_ji)]=((b_v_ti)-((((10))*(b_int(((breal_t)(b_v_ti)/(breal_t)((10))))))));
		b_v_ti=b_int(((breal_t)(b_v_ti)/(breal_t)((10))));
		b_v_ji += 1;
		if(b_v_ji <= 3) goto b_f22_t;
b_f22_e: ;
		/* line 7310 */
b_L7310: ;
		b_poke((1030),(((48))+(b_a_di[B_INT((3))])));
		b_poke((1031),(((48))+(b_a_di[B_INT((2))])));
		b_poke((1032),(((48))+(b_a_di[B_INT((1))])));
		b_poke((1033),(((48))+(b_a_di[B_INT((0))])));
		/* line 7315 */
b_L7315: ;
		b_poke((1042),(((48))+(b_v_lvi)));
		/* line 7320 */
b_L7320: ;
		b_poke((1050),(((48))+(b_int(((breal_t)(b_v_lei)/(breal_t)((10)))))));
		b_poke((1051),(((((48))+(b_v_lei)))-((((10))*(b_int(((breal_t)(b_v_lei)/(breal_t)((10)))))))));
		/* line 7325 */
b_L7325: ;
		b_poke((1058),(((48))+(b_v_gli)));
		b_poke((1059),(32));
		/* line 7330 */
b_L7330: ;
		goto b_return;
		/* line 8000 */
b_L8000: ;
		/* line 8003 */
b_L8003: ;
		b_dataPtr = 0;
		/* line 8004 */
b_L8004: ;
		b_v_ji=(0);
		if(b_v_ji > 24) goto b_f23_e;
b_f23_t: ;
		b_a_lni[B_INT(b_v_ji)]=(-1);
		b_v_ji += 1;
		if(b_v_ji <= 24) goto b_f23_t;
b_f23_e: ;
		/* line 8005 */
b_L8005: ;
		if(-((b_v_sti) == ((16)))){
			b_v_ji=(1);
			if(b_v_ji > 63) goto b_f24_e;
b_f24_t: ;
			b_v_ci=b_read_int();
			b_v_ji += 1;
			if(b_v_ji <= 63) goto b_f24_t;
b_f24_e: ;
		}
		/* line 8006 */
b_L8006: ;
		b_v_lf=(0);
		b_fl_25=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_25) goto b_f25_e;
b_f25_t: ;
		b_v_lif=b_v_lf;
		/* line 8010 */
b_L8010: ;
		b_v_r0i=b_read_int();
		b_v_r1i=b_read_int();
		b_v_r2i=b_read_int();
		b_v_r3i=b_read_int();
		b_v_r4i=b_read_int();
		b_v_r5i=b_read_int();
		b_v_r6i=b_read_int();
		/* line 8012 */
b_L8012: ;
		b_a_rwi[(bint_t)(b_v_lif)]=b_v_r0i;
		b_a_tyi[(bint_t)(b_v_lif)]=b_v_r1i;
		b_a_dxi[(bint_t)(b_v_lif)]=b_v_r2i;
		b_a_mvi[(bint_t)(b_v_lif)]=b_v_r3i;
		b_a_gpi[(bint_t)(b_v_lif)]=b_v_r4i;
		b_a_wdi[(bint_t)(b_v_lif)]=b_v_r5i;
		b_a_coi[(bint_t)(b_v_lif)]=b_v_r6i;
		b_a_lni[B_INT(b_a_rwi[(bint_t)(b_v_lif)])]=b_v_lif;
		/* line 8015 */
b_L8015: ;
		b_a_cti[(bint_t)(b_v_lif)]=(0);
		/* line 8020 */
b_L8020: ;
		b_v_obi=b_v_cci;
		if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
			b_v_obi=b_v_lci;
		}
		/* line 8025 */
b_L8025: ;
		b_v_bgi=b_v_rci;
		if(-((b_a_tyi[(bint_t)(b_v_lif)]) == ((0)))){
			b_v_bgi=b_v_wci;
		}
		/* line 8030 */
b_L8030: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f26_e;
		b_v_M6=((b_v_lif)*((40)));
b_f26_t: ;
		b_v_cii=b_v_ci;
		b_a_lai[(bint_t)(((b_v_M6)+(b_v_cii)))]=b_v_bgi;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f26_t;
b_f26_e: ;
		/* line 8035 */
b_L8035: ;
		b_v_si=(0);
		/* line 8036 */
b_L8036: ;
		b_v_ji=(0);
		b_fl_27=((b_a_wdi[(bint_t)(b_v_lif)])-((1)));
		if(b_v_ji > b_fl_27) goto b_f27_e;
		b_v_M7=((b_v_lif)*((40)));
b_f27_t: ;
		/* line 8037 */
b_L8037: ;
		b_v_jii=b_v_ji;
		b_v_pi=((b_v_si)+(b_v_jii));
		if(-((b_v_pi) >= ((40)))){
			b_v_pi=((b_v_pi)-((40)));
		}
		/* line 8038 */
b_L8038: ;
		b_a_lai[(bint_t)(((b_v_M7)+(b_v_pi)))]=b_v_obi;
		/* line 8039 */
b_L8039: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_27)) goto b_f27_t;
b_f27_e: ;
		/* line 8040 */
b_L8040: ;
		b_v_si=((b_v_si)+(b_a_gpi[(bint_t)(b_v_lif)]));
		if(-((b_v_si) < ((40)))){ goto b_L8036; }
		/* line 8045 */
b_L8045: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_25)) goto b_f25_t;
b_f25_e: ;
		/* line 8050 */
b_L8050: ;
		b_v_ji=(0);
		b_fl_28=((b_v_sti)-((4)));
		if(b_v_ji > b_fl_28) goto b_f28_e;
b_f28_t: ;
		b_a_shi[B_INT(b_v_ji)]=(1);
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_28)) goto b_f28_t;
b_f28_e: ;
		/* line 8052 */
b_L8052: ;
		if(-((b_v_ezi) == ((1)))){
			b_gosubStack[b_gosubSP++]=36; goto b_L1200;
b_ret36: ;
		}
		/* line 8060 */
b_L8060: ;
		/* line 8061 */
b_L8061: ;
		goto b_return;
		/* line 8300 */
b_L8300: ;
		/* line 8301 */
b_L8301: ;
		b_gosubStack[b_gosubSP++]=37; goto b_L8320;
b_ret37: ;
		/* line 8302 */
b_L8302: ;
		b_v_lf=(0);
		b_fl_29=((b_v_sti)-((4)));
		if(b_v_lf > b_fl_29) goto b_f29_e;
b_f29_t: ;
		b_v_lif=b_v_lf;
		/* line 8303 */
b_L8303: ;
		b_v_cvi=b_a_coi[(bint_t)(b_v_lif)];
		/* line 8304 */
b_L8304: ;
		b_poke((2),b_a_rwi[(bint_t)(b_v_lif)]);
		b_poke((4),b_v_cvi);
		b_sys((49152.0));
		/* line 8306 */
b_L8306: ;
		b_v_lf += 1;
		if(b_v_lf <= (b_fl_29)) goto b_f29_t;
b_f29_e: ;
		/* line 8308 */
b_L8308: ;
		b_poke((2),(0));
		b_poke((4),(1));
		b_sys((49152.0));
		/* line 8309 */
b_L8309: ;
		b_poke((2),(1));
		b_poke((4),(5));
		b_sys((49152.0));
		/* line 8310 */
b_L8310: ;
		b_poke((2),b_v_mdi);
		b_poke((4),(5));
		b_sys((49152.0));
		/* line 8311 */
b_L8311: ;
		b_poke((2),b_v_sti);
		b_poke((4),(13));
		b_sys((49152.0));
		/* line 8314 */
b_L8314: ;
		goto b_return;
		/* line 8320 */
b_L8320: ;
		/* line 8321 */
b_L8321: ;
		b_poke((49152.0),(165));
		b_poke((49153.0),(2));
		b_poke((49154.0),(10));
		b_poke((49155.0),(10));
		b_poke((49156.0),(24));
		b_poke((49157.0),(101));
		b_poke((49158.0),(2));
		b_poke((49159.0),(133));
		b_poke((49160.0),(2));
		b_poke((49161.0),(169));
		b_poke((49162.0),(0));
		b_poke((49163.0),(133));
		b_poke((49164.0),(3));
		b_poke((49165.0),(6));
		b_poke((49166.0),(2));
		/* line 8322 */
b_L8322: ;
		b_poke((49167.0),(38));
		b_poke((49168.0),(3));
		b_poke((49169.0),(6));
		b_poke((49170.0),(2));
		b_poke((49171.0),(38));
		b_poke((49172.0),(3));
		b_poke((49173.0),(6));
		b_poke((49174.0),(2));
		b_poke((49175.0),(38));
		b_poke((49176.0),(3));
		b_poke((49177.0),(24));
		b_poke((49178.0),(165));
		b_poke((49179.0),(3));
		b_poke((49180.0),(105));
		b_poke((49181.0),(216));
		/* line 8323 */
b_L8323: ;
		b_poke((49182.0),(133));
		b_poke((49183.0),(3));
		b_poke((49184.0),(165));
		b_poke((49185.0),(4));
		b_poke((49186.0),(160));
		b_poke((49187.0),(0));
		b_poke((49188.0),(145));
		b_poke((49189.0),(2));
		b_poke((49190.0),(200));
		b_poke((49191.0),(192));
		b_poke((49192.0),(40));
		b_poke((49193.0),(208));
		b_poke((49194.0),(249));
		b_poke((49195.0),(96));
		/* line 8324 */
b_L8324: ;
		goto b_return;
		/* line 8065 */
b_L8065: ;
		/* line 8070 */
b_L8070: ;
		/* line 8075 */
b_L8075: ;
		/* line 8080 */
b_L8080: ;
		/* line 8085 */
b_L8085: ;
		/* line 8090 */
b_L8090: ;
		/* line 8095 */
b_L8095: ;
		/* line 8100 */
b_L8100: ;
		/* line 8105 */
b_L8105: ;
		/* line 8200 */
b_L8200: ;
		/* line 8201 */
b_L8201: ;
		/* line 8202 */
b_L8202: ;
		/* line 8203 */
b_L8203: ;
		/* line 8204 */
b_L8204: ;
		/* line 8205 */
b_L8205: ;
		/* line 8206 */
b_L8206: ;
		/* line 8207 */
b_L8207: ;
		/* line 8208 */
b_L8208: ;
		/* line 8209 */
b_L8209: ;
		/* line 8210 */
b_L8210: ;
		/* line 8211 */
b_L8211: ;
		/* line 8212 */
b_L8212: ;
		/* line 9000 */
b_L9000: ;
		/* line 9005 */
b_L9005: ;
		if(-((b_v_dmi) == ((0)))){
			b_v_lvi=((b_v_lvi)-((1)));
		}
		/* line 9010 */
b_L9010: ;
		b_gosubStack[b_gosubSP++]=38; goto b_L7300;
b_ret38: ;
		/* line 9015 */
b_L9015: ;
		if(-((b_v_lvi) <= ((0)))){ goto b_L9500; }
		/* line 9016 */
b_L9016: ;
		b_v_hxi=b_v_fxi;
		b_v_hyi=b_v_fyi;
		/* line 9017 */
b_L9017: ;
		if(-((b_v_fxi) < ((0)))){
			b_v_hxi=b_v_pxi;
			b_v_hyi=b_v_pyi;
		}
		/* line 9018 */
b_L9018: ;
		if(-((b_v_fxi) > ((39)))){
			b_v_hxi=b_v_pxi;
			b_v_hyi=b_v_pyi;
		}
		/* line 9019 */
b_L9019: ;
		/* line 9020 */
b_L9020: ;
		/* line 9021 */
b_L9021: ;
		b_v_lf=(1);
		if(b_v_lf > 6) goto b_f30_e;
b_f30_t: ;
		/* line 9022 */
b_L9022: ;
		b_v_chi=(42);
		if(-((b_v_lf) >= ((4)))){
			b_v_chi=(46);
		}
		/* line 9025 */
b_L9025: ;
		b_a_di[B_INT((0))]=((b_v_hyi)-(b_v_lf));
		if(-((b_a_di[B_INT((0))]) < ((1)))){
			b_a_di[B_INT((0))]=(1);
		}
		/* line 9026 */
b_L9026: ;
		b_a_di[B_INT((1))]=((b_v_hyi)+(b_v_lf));
		if(-((b_a_di[B_INT((1))]) > (b_v_sti))){
			b_a_di[B_INT((1))]=b_v_sti;
		}
		/* line 9027 */
b_L9027: ;
		b_a_di[B_INT((2))]=((b_v_hxi)-(b_v_lf));
		if(-((b_a_di[B_INT((2))]) < ((0)))){
			b_a_di[B_INT((2))]=(0);
		}
		/* line 9028 */
b_L9028: ;
		b_a_di[B_INT((3))]=((b_v_hxi)+(b_v_lf));
		if(-((b_a_di[B_INT((3))]) > ((39)))){
			b_a_di[B_INT((3))]=(39);
		}
		/* line 9029 */
b_L9029: ;
		b_v_ci=b_a_di[B_INT((2))];
		b_fl_31=b_a_di[B_INT((3))];
		if(b_v_ci > b_fl_31) goto b_f31_e;
		b_v_M8=(((1024))+(((b_v_hyi)*((40)))));
		b_t_28=((b_v_M8)+(b_v_ci));
b_f31_t: ;
		b_poke(b_t_28,b_v_chi);
		b_t_28 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_31)) goto b_f31_t;
b_f31_e: ;
		/* line 9030 */
b_L9030: ;
		b_v_ki=b_a_di[B_INT((0))];
		b_fl_32=b_a_di[B_INT((1))];
		if(b_v_ki > b_fl_32) goto b_f32_e;
		b_t_29=(((((1024))+(((b_v_ki)*((40))))))+(b_v_hxi));
b_f32_t: ;
		b_poke(b_t_29,b_v_chi);
		b_t_29 += 40;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_32)) goto b_f32_t;
b_f32_e: ;
		/* line 9031 */
b_L9031: ;
		b_v_ji=(1);
		if(b_v_ji > 2000) goto b_f33_e;
b_f33_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 2000) goto b_f33_t;
b_f33_e: ;
		/* line 9032 */
b_L9032: ;
		b_v_lf += 1;
		if(b_v_lf <= 6) goto b_f30_t;
b_f30_e: ;
		/* line 9033 */
b_L9033: ;
		b_poke((((((1024))+(((b_v_hyi)*((40))))))+(b_v_hxi)),(81));
		/* line 9034 */
b_L9034: ;
		b_v_ji=(1);
		if(b_v_ji > 4000) goto b_f34_e;
b_f34_t: ;
		b_v_ji += 1;
		if(b_v_ji <= 4000) goto b_f34_t;
b_f34_e: ;
		/* line 9035 */
b_L9035: ;
		b_v_ji=(1);
		if(b_v_ji > 15) goto b_f35_e;
b_f35_t: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		b_v_ji += 1;
		if(b_v_ji <= 15) goto b_f35_t;
b_f35_e: ;
		/* line 9036 */
b_L9036: ;
		b_v_fxi=(20);
		b_v_fyi=b_v_sti;
		/* line 9037 */
b_L9037: ;
		b_v_ji=(0);
		b_fl_36=((b_v_sti)-((4)));
		if(b_v_ji > b_fl_36) goto b_f36_e;
b_f36_t: ;
		b_a_shi[B_INT(b_v_ji)]=(1);
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_36)) goto b_f36_t;
b_f36_e: ;
		/* line 9038 */
b_L9038: ;
		b_gosubStack[b_gosubSP++]=39; goto b_L4000;
b_ret39: ;
		/* line 9039 */
b_L9039: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L7000;
b_ret40: ;
		/* line 9040 */
b_L9040: ;
		goto b_return;
		/* line 9500 */
b_L9500: ;
		/* line 9505 */
b_L9505: ;
		b_putc(147);
		b_nl();
		/* line 9510 */
b_L9510: ;
		b_nl();
		{ bstr_t _t=b_lit("  *** GAME OVER ***",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9515 */
b_L9515: ;
		{ bstr_t _t=b_lit("  SCORE:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		b_nl();
		/* line 9520 */
b_L9520: ;
		{ bstr_t _t=b_lit("  LEVEL:",8); b_str(_t.p,_t.len); }
		b_putint(b_v_lei);
		b_nl();
		/* line 9525 */
b_L9525: ;
		b_nl();
		{ bstr_t _t=b_lit("  R=RESTART  Q=QUIT",19); b_str(_t.p,_t.len); }
		b_nl();
		/* line 9530 */
b_L9530: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L9530; }
		/* line 9535 */
b_L9535: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			goto b_L40;
		}
		/* line 9540 */
b_L9540: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			b_sys((64738.0));
		}
		/* line 9545 */
b_L9545: ;
		goto b_L9530;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
