; -- manzoo.bas
; C64 BASIC V2 -> 6502  |  2389 bytes PRG, 19 source lines
	* = $0801
	; entry  $0B81   (10 SYS -> code)
	; vars   $1100 .. $1156   (22 vars, 86 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$32,$39,$34,$35,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- float const pool ----

fconst0:
0813 :  .byte $90,$50,$20,$00,$00

fconst1:
0818 :  .byte $90,$50,$21,$00,$00

fconst2:
081D :  .byte $85,$1C,$00,$00,$00

fconst3:
0822 :  .byte $90,$58,$00,$00,$00

fconst4:
0827 :  .byte $80,$73,$33,$33,$33

fconst5:
082C :  .byte $79,$65,$60,$41,$89

fconst6:
0831 :  .byte $85,$00,$00,$00,$00

fconst7:
0836 :  .byte $85,$50,$00,$00,$00

fconst8:
083B :  .byte $84,$40,$00,$00,$00

fconst9:
0840 :  .byte $00,$00,$00,$00,$00

fconst10:
0845 :  .byte $8B,$00,$00,$00,$00

fconst11:
084A :  .byte $82,$00,$00,$00,$00

fconst12:
084F :  .byte $81,$00,$00,$00,$00

fconst13:
0854 :  .byte $89,$00,$00,$00,$00

ftemp:
0859 :  .res 10	; float temp slots
; ---- DATA pool ----

data_pool_addr:
0863 :  .byte $01,$88,$BE,$CC,$08,$31,$01,$85,$66,$CE,$D9,$17,$01,$87,$07,$AE	; DATA image
	.byte $14,$7B,$01,$80,$E5,$60,$41,$89,$01,$89,$E3,$7B,$43,$96,$01,$80
	.byte $83,$12,$6E,$98,$01,$89,$A0,$00,$00,$00,$01,$83,$23,$D7,$0A,$3D
	.byte $01,$85,$B5,$DD,$2F,$1B,$01,$88,$26,$87,$2B,$02
; ---- runtime helpers ----

RT_zero:
089F :  LDY #0 ; $00
08A1 :  LDX ZP_SCR16 + 1 ; $FE
08A3 :  BEQ .z_tail

.z_page:
08A5 :  LDA #0 ; $00

.z_pl:
08A7 :  STA (ZP_PTR),Y ; $FB
08A9 :  INY
08AA :  BNE .z_pl
08AC :  INC ZP_PTR + 1 ; $FC
08AE :  DEX
08AF :  BNE .z_page

.z_tail:

.z_tail:
08B1 :  LDX ZP_SCR16 ; $FD
08B3 :  BEQ .z_done_l

.z_tl:
08B5 :  LDA #0 ; $00
08B7 :  STA (ZP_PTR),Y ; $FB
08B9 :  INY
08BA :  DEX
08BB :  BNE .z_tl

.z_done_l:

.z_done_l:
08BD :  RTS

RT_fmul_align:

RT_fmul:

RT_fadd:
0B67 :  JSR $BA8C
0B6A :  LDA $61
0B6C :  JMP RT_fmul_align ; $08BE

RT_fsub:
0B6F :  JSR $BA8C
0B72 :  LDA $66
0B74 :  EOR #$FF
0B76 :  STA $66
0B78 :  EOR $6E
0B7A :  STA $6F
0B7C :  LDA $61
0B7E :  JMP RT_fmul_align ; $08BE

; ---- zero variable area (bss excluded from PRG; runtime-init via RT_zero) ----
0B81 :  LDA #0 ; $00
0B83 :  STA ZP_PTR ; $FB
0B85 :  LDA #0 ; $00
0B87 :  STA ZP_PTR + 1 ; $FC
0B89 :  LDA #0 ; $00
0B8B :  STA ZP_SCR16 ; $FD
0B8D :  LDA #0 ; $00
0B8F :  STA ZP_SCR16 + 1 ; $FE
0B91 :  JSR RT_zero ; $089F
; ---- DATPTR init ----
0B94 :  LDA #<addr ; $63
0B96 :  STA ZP_DATPTR ; $41
0B98 :  LDA #>addr ; $08
0B9A :  STA ZP_DATPTR + 1 ; $42
; ---- BASIC source ----
; 5     $0B9C  POKE 53280,0:POKE 53281,0:PRINT CHR$(147)
; 1,"manzoo.bas"

L5:
0B9C :  LDA #(u8)s->e2->ival ; $00
0B9E :  STA ; $D020
0BA1 :  LDA #(u8)s->e2->ival ; $00
0BA3 :  STA ; $D021
0BA6 :  LDA #LO(e->ival) ; $93
0BA8 :  LDX #LO((e->ival >> 8)) ; $00
0BAA :  JSR ROM_CHROUT ; $FFD2
0BAD :  LDA #13 ; $0D
0BAF :  JSR ROM_CHROUT ; $FFD2
; 6     $0BB2  RESTORE:P=0:READ CX:READ CY:DX=16:DY=26
; 2,"manzoo.bas"

L6:
0BB2 :  LDA #<addr ; $63
0BB4 :  STA ZP_DATPTR ; $41
0BB6 :  LDA #>addr ; $08
0BB8 :  STA ZP_DATPTR + 1 ; $42
0BBA :  LDA #clo ; $00
0BBC :  STA P
0BBF :  CLC
0BC0 :  LDA ZP_DATPTR ; $41
0BC2 :  ADC #1 ; $01
0BC4 :  STA ZP_DATPTR ; $41
0BC6 :  LDA ZP_DATPTR + 1 ; $42
0BC8 :  ADC #0 ; $00
0BCA :  STA ZP_DATPTR + 1 ; $42
0BCC :  LDY #0 ; $00
0BCE :  LDA (ZP_DATPTR),Y ; $41
0BD0 :  STA CX_F
0BD3 :  INY
0BD4 :  LDA (ZP_DATPTR),Y ; $41
0BD6 :  STA CX_F+1
0BD9 :  INY
0BDA :  LDA (ZP_DATPTR),Y ; $41
0BDC :  STA CX_F+2
0BDF :  INY
0BE0 :  LDA (ZP_DATPTR),Y ; $41
0BE2 :  STA CX_F+3
0BE5 :  INY
0BE6 :  LDA (ZP_DATPTR),Y ; $41
0BE8 :  STA CX_F+4
0BEB :  INY
0BEC :  CLC
0BED :  LDA ZP_DATPTR ; $41
0BEF :  ADC #5 ; $05
0BF1 :  STA ZP_DATPTR ; $41
0BF3 :  LDA ZP_DATPTR + 1 ; $42
0BF5 :  ADC #0 ; $00
0BF7 :  STA ZP_DATPTR + 1 ; $42
0BF9 :  CLC
0BFA :  LDA ZP_DATPTR ; $41
0BFC :  ADC #1 ; $01
0BFE :  STA ZP_DATPTR ; $41
0C00 :  LDA ZP_DATPTR + 1 ; $42
0C02 :  ADC #0 ; $00
0C04 :  STA ZP_DATPTR + 1 ; $42
0C06 :  LDY #0 ; $00
0C08 :  LDA (ZP_DATPTR),Y ; $41
0C0A :  STA CY_F
0C0D :  INY
0C0E :  LDA (ZP_DATPTR),Y ; $41
0C10 :  STA CY_F+1
0C13 :  INY
0C14 :  LDA (ZP_DATPTR),Y ; $41
0C16 :  STA CY_F+2
0C19 :  INY
0C1A :  LDA (ZP_DATPTR),Y ; $41
0C1C :  STA CY_F+3
0C1F :  INY
0C20 :  LDA (ZP_DATPTR),Y ; $41
0C22 :  STA CY_F+4
0C25 :  INY
0C26 :  CLC
0C27 :  LDA ZP_DATPTR ; $41
0C29 :  ADC #5 ; $05
0C2B :  STA ZP_DATPTR ; $41
0C2D :  LDA ZP_DATPTR + 1 ; $42
0C2F :  ADC #0 ; $00
0C31 :  STA ZP_DATPTR + 1 ; $42
0C33 :  LDA #<addr ; $31
0C35 :  LDY #>addr ; $08
0C37 :  JSR ROM_MEM_FAC ; $BBA2
0C3A :  LDX #<DX_F
0C3C :  LDY #>DX_F+1
0C3E :  JSR ROM_FAC_MEM ; $BBD4
0C41 :  LDA #<addr ; $36
0C43 :  LDY #>addr ; $08
0C45 :  JSR ROM_MEM_FAC ; $BBA2
0C48 :  LDX #<DY_F
0C4A :  LDY #>DY_F+1
0C4C :  JSR ROM_FAC_MEM ; $BBD4
; 10    $0C4F  XR=CX-19.5*DX:YI=CY-12*DY
; 3,"manzoo.bas"

L10:
0C4F :  LDA #<CX_F
0C51 :  LDY #>CX_F+1
0C53 :  JSR ROM_MEM_FAC ; $BBA2
0C56 :  LDX #<addr ; $59
0C58 :  LDY #>addr ; $08
0C5A :  JSR ROM_FAC_MEM ; $BBD4
0C5D :  LDA #<addr ; $1D
0C5F :  LDY #>addr ; $08
0C61 :  JSR ROM_MEM_FAC ; $BBA2
0C64 :  LDX #<addr ; $5E
0C66 :  LDY #>addr ; $08
0C68 :  JSR ROM_FAC_MEM ; $BBD4
0C6B :  LDA #<DX_F
0C6D :  LDY #>DX_F+1
0C6F :  JSR ROM_MEM_FAC ; $BBA2
0C72 :  LDA #<addr ; $5E
0C74 :  LDY #>addr ; $08
0C76 :  JSR ROM_MEM_ARG ; $BA8C
0C79 :  LDA FACEXP ; $61
0C7B :  LDA #<addr ; $5E
0C7D :  LDY #>addr ; $08
0C7F :  JSR RT_fmul ; $0A3B
0C82 :  LDA #<addr ; $59
0C84 :  LDY #>addr ; $08
0C86 :  JSR ROM_MEM_ARG ; $BA8C
0C89 :  LDA FACEXP ; $61
0C8B :  LDA #<addr ; $59
0C8D :  LDY #>addr ; $08
0C8F :  JSR ROM_MINUS ; $B850
0C92 :  LDX #<XR_F
0C94 :  LDY #>XR_F+1
0C96 :  JSR ROM_FAC_MEM ; $BBD4
0C99 :  LDA #<CY_F
0C9B :  LDY #>CY_F+1
0C9D :  JSR ROM_MEM_FAC ; $BBA2
0CA0 :  LDX #<addr ; $59
0CA2 :  LDY #>addr ; $08
0CA4 :  JSR ROM_FAC_MEM ; $BBD4
0CA7 :  LDA #<addr ; $3B
0CA9 :  LDY #>addr ; $08
0CAB :  JSR ROM_MEM_FAC ; $BBA2
0CAE :  LDX #<addr ; $5E
0CB0 :  LDY #>addr ; $08
0CB2 :  JSR ROM_FAC_MEM ; $BBD4
0CB5 :  LDA #<DY_F
0CB7 :  LDY #>DY_F+1
0CB9 :  JSR ROM_MEM_FAC ; $BBA2
0CBC :  LDA #<addr ; $5E
0CBE :  LDY #>addr ; $08
0CC0 :  JSR ROM_MEM_ARG ; $BA8C
0CC3 :  LDA FACEXP ; $61
0CC5 :  LDA #<addr ; $5E
0CC7 :  LDY #>addr ; $08
0CC9 :  JSR RT_fmul ; $0A3B
0CCC :  LDA #<addr ; $59
0CCE :  LDY #>addr ; $08
0CD0 :  JSR ROM_MEM_ARG ; $BA8C
0CD3 :  LDA FACEXP ; $61
0CD5 :  LDA #<addr ; $59
0CD7 :  LDY #>addr ; $08
0CD9 :  JSR ROM_MINUS ; $B850
0CDC :  LDX #<YI_F
0CDE :  LDY #>YI_F+1
0CE0 :  JSR ROM_FAC_MEM ; $BBD4
; 20    $0CE3  SA=1024:CA=55296
; 4,"manzoo.bas"

L20:
0CE3 :  LDA #LO(e->ival) ; $00
0CE5 :  LDX #LO((e->ival >> 8)) ; $04
0CE7 :  STA SA
0CEA :  STX SA+1
0CED :  LDA #LO(K) ; $00
0CEF :  LDX #HI(K) ; $D8
0CF1 :  STA CA
0CF4 :  STX CA+1
; 30    $0CF7  CI=YI:FOR J=0 TO 24
; 5,"manzoo.bas"

L30:
0CF7 :  LDA #<YI_F
0CF9 :  LDY #>YI_F+1
0CFB :  JSR ROM_MEM_FAC ; $BBA2
0CFE :  LDX #<CI_F
0D00 :  LDY #>CI_F+1
0D02 :  JSR ROM_FAC_MEM ; $BBD4
0D05 :  LDA #LO(e->ival) ; $00
0D07 :  LDX #LO((e->ival >> 8)) ; $00
0D09 :  STA J
0D0C :  STX J+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 40    $0D0F  CR=XR:FOR I=0 TO 39
; 6,"manzoo.bas"

L40:
0D0F :  LDA #<XR_F
0D11 :  LDY #>XR_F+1
0D13 :  JSR ROM_MEM_FAC ; $BBA2
0D16 :  LDX #<CR_F
0D18 :  LDY #>CR_F+1
0D1A :  JSR ROM_FAC_MEM ; $BBD4
0D1D :  LDA #LO(e->ival) ; $00
0D1F :  LDX #LO((e->ival >> 8)) ; $00
0D21 :  STA I
0D24 :  STX I+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 50    $0D27  ZR=0:ZI=0:K=0
; 7,"manzoo.bas"

L50:
0D27 :  LDA #<addr ; $40
0D29 :  LDY #>addr ; $08
0D2B :  JSR ROM_MEM_FAC ; $BBA2
0D2E :  LDX #<ZR_F
0D30 :  LDY #>ZR_F+1
0D32 :  JSR ROM_FAC_MEM ; $BBD4
0D35 :  LDA #<addr ; $40
0D37 :  LDY #>addr ; $08
0D39 :  JSR ROM_MEM_FAC ; $BBA2
0D3C :  LDX #<ZI_F
0D3E :  LDY #>ZI_F+1
0D40 :  JSR ROM_FAC_MEM ; $BBD4
0D43 :  LDA #<addr ; $40
0D45 :  LDY #>addr ; $08
0D47 :  JSR ROM_MEM_FAC ; $BBA2
0D4A :  LDX #<K_F
0D4C :  LDY #>K_F+1
0D4E :  JSR ROM_FAC_MEM ; $BBD4
; 60    $0D51  RR=ZR*ZR/256:II=ZI*ZI/256:IF RR+II>1024 THEN 100
; 8,"manzoo.bas"

L60:
0D51 :  LDA #<ZR_F
0D53 :  LDY #>ZR_F+1
0D55 :  JSR ROM_MEM_FAC ; $BBA2
0D58 :  LDA #<ZR_F
0D5A :  LDY #>ZR_F+1
0D5C :  JSR RT_fmul ; $0A3B
; opt: pow2scale (float *2^k -> FAC exp += k)
0D5F :  SEC
0D60 :  LDA FACEXP ; $61
0D62 :  SBC #n ; $08
0D64 :  BCS .pow2s_ok
0D66 :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0D68 :  STA FACEXP ; $61
0D6A :  LDX #<RR_F
0D6C :  LDY #>RR_F+1
0D6E :  JSR ROM_FAC_MEM ; $BBD4
0D71 :  LDA #<ZI_F
0D73 :  LDY #>ZI_F+1
0D75 :  JSR ROM_MEM_FAC ; $BBA2
0D78 :  LDA #<ZI_F
0D7A :  LDY #>ZI_F+1
0D7C :  JSR RT_fmul ; $0A3B
; opt: pow2scale (float *2^k -> FAC exp += k)
0D7F :  SEC
0D80 :  LDA FACEXP ; $61
0D82 :  SBC #n ; $08
0D84 :  BCS .pow2s_ok
0D86 :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0D88 :  STA FACEXP ; $61
0D8A :  LDX #<II_F
0D8C :  LDY #>II_F+1
0D8E :  JSR ROM_FAC_MEM ; $BBD4
0D91 :  LDA #<II_F
0D93 :  LDY #>II_F+1
0D95 :  JSR ROM_MEM_FAC ; $BBA2
0D98 :  LDA #<RR_F
0D9A :  LDY #>RR_F+1
0D9C :  JSR RT_fadd ; $0B67
0D9F :  LDA #<addr ; $45
0DA1 :  LDY #>addr ; $08
0DA3 :  JSR ROM_FCOMP ; $BC5B
0DA6 :  BMI .false
0DA8 :  BEQ .false
0DAA :  LDA #0xFF ; $FF
0DAC :  BNE .cmp_tail
0DAE :  LDA #0x00 ; $00

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0DB0 :  BEQ .if_skip
0DB2 :  JMP L100

.if_skip:
; 70    $0DB5  NZ=ZR*ZI*2/256
; 9,"manzoo.bas"

L70:
0DB5 :  LDA #<ZI_F
0DB7 :  LDY #>ZI_F+1
0DB9 :  JSR ROM_MEM_FAC ; $BBA2
0DBC :  LDA #<ZR_F
0DBE :  LDY #>ZR_F+1
0DC0 :  JSR RT_fmul ; $0A3B
; opt: pow2scale (float *2^k -> FAC exp += k)
0DC3 :  LDA FACEXP ; $61
0DC5 :  BEQ .pow2s_done
0DC7 :  CLC
0DC8 :  ADC #k ; $01
0DCA :  STA FACEXP ; $61

.pow2s_done:

.pow2s_done:
; opt: pow2scale (float *2^k -> FAC exp += k)
0DCC :  SEC
0DCD :  LDA FACEXP ; $61
0DCF :  SBC #n ; $08
0DD1 :  BCS .pow2s_ok
0DD3 :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0DD5 :  STA FACEXP ; $61
0DD7 :  LDX #<NZ_F
0DD9 :  LDY #>NZ_F+1
0DDB :  JSR ROM_FAC_MEM ; $BBD4
; 80    $0DDE  ZI=NZ+CI:ZR=RR-II+CR:K=K+1:IF K<256 THEN 60
; 10,"manzoo.bas"

L80:
0DDE :  LDA #<CI_F
0DE0 :  LDY #>CI_F+1
0DE2 :  JSR ROM_MEM_FAC ; $BBA2
0DE5 :  LDA #<NZ_F
0DE7 :  LDY #>NZ_F+1
0DE9 :  JSR RT_fadd ; $0B67
0DEC :  LDX #<ZI_F
0DEE :  LDY #>ZI_F+1
0DF0 :  JSR ROM_FAC_MEM ; $BBD4
0DF3 :  LDA #<II_F
0DF5 :  LDY #>II_F+1
0DF7 :  JSR ROM_MEM_FAC ; $BBA2
0DFA :  LDA #<RR_F
0DFC :  LDY #>RR_F+1
0DFE :  JSR RT_fsub ; $0B6F
0E01 :  LDX #<addr ; $59
0E03 :  LDY #>addr ; $08
0E05 :  JSR ROM_FAC_MEM ; $BBD4
0E08 :  LDA #<CR_F
0E0A :  LDY #>CR_F+1
0E0C :  JSR ROM_MEM_FAC ; $BBA2
0E0F :  LDA #<addr ; $59
0E11 :  LDY #>addr ; $08
0E13 :  JSR ROM_MEM_ARG ; $BA8C
0E16 :  LDA FACEXP ; $61
0E18 :  JSR ROM_PLUS ; $B86A
0E1B :  LDX #<ZR_F
0E1D :  LDY #>ZR_F+1
0E1F :  JSR ROM_FAC_MEM ; $BBD4
0E22 :  LDA #<addr ; $4F
0E24 :  LDY #>addr ; $08
0E26 :  JSR ROM_MEM_FAC ; $BBA2
0E29 :  LDA #<K_F
0E2B :  LDY #>K_F+1
0E2D :  JSR RT_fadd ; $0B67
0E30 :  LDX #<K_F
0E32 :  LDY #>K_F+1
0E34 :  JSR ROM_FAC_MEM ; $BBD4
0E37 :  LDA #<K_F
0E39 :  LDY #>K_F+1
0E3B :  JSR ROM_MEM_FAC ; $BBA2
0E3E :  LDA #<addr ; $54
0E40 :  LDY #>addr ; $08
0E42 :  JSR ROM_FCOMP ; $BC5B
0E45 :  BMI .true
0E47 :  LDA #0x00 ; $00
0E49 :  BEQ .cmp_tail
0E4B :  LDA #0xFF ; $FF

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0E4D :  BEQ .if_skip
0E4F :  JMP L60

.if_skip:
; 90    $0E52  POKE SA,160:POKE CA,0:GOTO 120
; 11,"manzoo.bas"

L90:
0E52 :  LDA SA
0E55 :  LDX SA+1
0E58 :  STA ZP_PTR ; $FB
0E5A :  STX ZP_PTR + 1 ; $FC
0E5C :  LDA #(u8)s->e2->ival ; $A0
0E5E :  LDY #0 ; $00
0E60 :  STA (ZP_PTR),Y ; $FB
0E62 :  LDA CA
0E65 :  LDX CA+1
0E68 :  STA ZP_PTR ; $FB
0E6A :  STX ZP_PTR + 1 ; $FC
0E6C :  LDA #(u8)s->e2->ival ; $00
0E6E :  LDY #0 ; $00
0E70 :  STA (ZP_PTR),Y ; $FB
0E72 :  JMP L120

; 100   $0E75  C=K AND 15:IF C=0 THEN C=6
; 12,"manzoo.bas"

L100:
0E75 :  LDA #<K_F
0E77 :  LDY #>K_F+1
0E79 :  JSR ROM_MEM_FAC ; $BBA2
0E7C :  JSR ROM_FAC_INT ; $BC9B
0E7F :  LDA FACMO3 ; $65
0E81 :  LDX FACMO2 ; $64
0E83 :  AND #imm ; $0F
0E85 :  STA C
0E88 :  BEQ +3 ; long IF-skip (body >127B)
0E8A :  JMP .if_skip

0E8D :  LDA #clo ; $06
0E8F :  STA C

.if_skip:
; 110   $0E92  POKE SA,160:POKE CA,C
; 13,"manzoo.bas"

L110:
0E92 :  LDA SA
0E95 :  LDX SA+1
0E98 :  STA ZP_PTR ; $FB
0E9A :  STX ZP_PTR + 1 ; $FC
0E9C :  LDA #(u8)s->e2->ival ; $A0
0E9E :  LDY #0 ; $00
0EA0 :  STA (ZP_PTR),Y ; $FB
0EA2 :  LDA CA
0EA5 :  LDX CA+1
0EA8 :  STA ZP_PTR ; $FB
0EAA :  STX ZP_PTR + 1 ; $FC
0EAC :  LDA C
0EAF :  LDY #0 ; $00
0EB1 :  STA (ZP_PTR),Y ; $FB
; 120   $0EB3  CR=CR+DX:SA=SA+1:CA=CA+1:NEXT
; 14,"manzoo.bas"

L120:
0EB3 :  LDA #<DX_F
0EB5 :  LDY #>DX_F+1
0EB7 :  JSR ROM_MEM_FAC ; $BBA2
0EBA :  LDA #<CR_F
0EBC :  LDY #>CR_F+1
0EBE :  JSR RT_fadd ; $0B67
0EC1 :  LDX #<CR_F
0EC3 :  LDY #>CR_F+1
0EC5 :  JSR ROM_FAC_MEM ; $BBD4
0EC8 :  INC SA
0ECB :  BNE .pm1_skip
0ECD :  INC SA+1

.pm1_skip:
0ED0 :  INC CA
0ED3 :  BNE .pm1_skip
0ED5 :  INC CA+1

.pm1_skip:
0ED8 :  INC I
0EDB :  LDA I
0EDE :  CMP #L->lim_lo ; $27
0EE0 :  BEQ .nxt_back
0EE2 :  BCS .nxt_done

.nxt_back:
0EE4 :  JMP .for_body ; $0D27

.nxt_done:
; 130   $0EE7  CI=CI+DY:NEXT
; 15,"manzoo.bas"

L130:
0EE7 :  LDA #<DY_F
0EE9 :  LDY #>DY_F+1
0EEB :  JSR ROM_MEM_FAC ; $BBA2
0EEE :  LDA #<CI_F
0EF0 :  LDY #>CI_F+1
0EF2 :  JSR RT_fadd ; $0B67
0EF5 :  LDX #<CI_F
0EF7 :  LDY #>CI_F+1
0EF9 :  JSR ROM_FAC_MEM ; $BBD4
0EFC :  INC J
0EFF :  LDA J
0F02 :  CMP #L->lim_lo ; $18
0F04 :  BEQ .nxt_back
0F06 :  BCS .nxt_done

.nxt_back:
0F08 :  JMP .for_body ; $0D0F

.nxt_done:
; 135   $0F0B  DX=DX*0.95:DY=DY*0.95:IF DX>0.007 THEN 10
; 16,"manzoo.bas"

L135:
0F0B :  LDA #<addr ; $27
0F0D :  LDY #>addr ; $08
0F0F :  JSR ROM_MEM_FAC ; $BBA2
0F12 :  LDA #<DX_F
0F14 :  LDY #>DX_F+1
0F16 :  JSR RT_fmul ; $0A3B
0F19 :  LDX #<DX_F
0F1B :  LDY #>DX_F+1
0F1D :  JSR ROM_FAC_MEM ; $BBD4
0F20 :  LDA #<addr ; $27
0F22 :  LDY #>addr ; $08
0F24 :  JSR ROM_MEM_FAC ; $BBA2
0F27 :  LDA #<DY_F
0F29 :  LDY #>DY_F+1
0F2B :  JSR RT_fmul ; $0A3B
0F2E :  LDX #<DY_F
0F30 :  LDY #>DY_F+1
0F32 :  JSR ROM_FAC_MEM ; $BBD4
0F35 :  LDA #<DX_F
0F37 :  LDY #>DX_F+1
0F39 :  JSR ROM_MEM_FAC ; $BBA2
0F3C :  LDA #<addr ; $2C
0F3E :  LDY #>addr ; $08
0F40 :  JSR ROM_FCOMP ; $BC5B
0F43 :  BMI .false
0F45 :  BEQ .false
0F47 :  LDA #0xFF ; $FF
0F49 :  BNE .cmp_tail
0F4B :  LDA #0x00 ; $00

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0F4D :  BEQ .if_skip
0F4F :  JMP L10

.if_skip:
; 136   $0F52  P=P+1:IF P>4 THEN P=0:RESTORE
; 17,"manzoo.bas"

L136:
0F52 :  INC P
; opt: compare-narrow
0F55 :  LDA P
0F58 :  CMP #klo ; $04
0F5A :  BNE +3 ; long IF-skip (body >127B)
0F5C :  JMP .if_skip

0F5F :  BCS +3 ; long IF-skip (body >127B)
0F61 :  JMP .if_skip

0F64 :  LDA #clo ; $00
0F66 :  STA P
0F69 :  LDA #<addr ; $63
0F6B :  STA ZP_DATPTR ; $41
0F6D :  LDA #>addr ; $08
0F6F :  STA ZP_DATPTR + 1 ; $42

.if_skip:
; 137   $0F71  READ CX:READ CY:DX=16:DY=26:GOTO 10
; 18,"manzoo.bas"

L137:
0F71 :  CLC
0F72 :  LDA ZP_DATPTR ; $41
0F74 :  ADC #1 ; $01
0F76 :  STA ZP_DATPTR ; $41
0F78 :  LDA ZP_DATPTR + 1 ; $42
0F7A :  ADC #0 ; $00
0F7C :  STA ZP_DATPTR + 1 ; $42
0F7E :  LDY #0 ; $00
0F80 :  LDA (ZP_DATPTR),Y ; $41
0F82 :  STA CX_F
0F85 :  INY
0F86 :  LDA (ZP_DATPTR),Y ; $41
0F88 :  STA CX_F+1
0F8B :  INY
0F8C :  LDA (ZP_DATPTR),Y ; $41
0F8E :  STA CX_F+2
0F91 :  INY
0F92 :  LDA (ZP_DATPTR),Y ; $41
0F94 :  STA CX_F+3
0F97 :  INY
0F98 :  LDA (ZP_DATPTR),Y ; $41
0F9A :  STA CX_F+4
0F9D :  INY
0F9E :  CLC
0F9F :  LDA ZP_DATPTR ; $41
0FA1 :  ADC #5 ; $05
0FA3 :  STA ZP_DATPTR ; $41
0FA5 :  LDA ZP_DATPTR + 1 ; $42
0FA7 :  ADC #0 ; $00
0FA9 :  STA ZP_DATPTR + 1 ; $42
0FAB :  CLC
0FAC :  LDA ZP_DATPTR ; $41
0FAE :  ADC #1 ; $01
0FB0 :  STA ZP_DATPTR ; $41
0FB2 :  LDA ZP_DATPTR + 1 ; $42
0FB4 :  ADC #0 ; $00
0FB6 :  STA ZP_DATPTR + 1 ; $42
0FB8 :  LDY #0 ; $00
0FBA :  LDA (ZP_DATPTR),Y ; $41
0FBC :  STA CY_F
0FBF :  INY
0FC0 :  LDA (ZP_DATPTR),Y ; $41
0FC2 :  STA CY_F+1
0FC5 :  INY
0FC6 :  LDA (ZP_DATPTR),Y ; $41
0FC8 :  STA CY_F+2
0FCB :  INY
0FCC :  LDA (ZP_DATPTR),Y ; $41
0FCE :  STA CY_F+3
0FD1 :  INY
0FD2 :  LDA (ZP_DATPTR),Y ; $41
0FD4 :  STA CY_F+4
0FD7 :  INY
0FD8 :  CLC
0FD9 :  LDA ZP_DATPTR ; $41
0FDB :  ADC #5 ; $05
0FDD :  STA ZP_DATPTR ; $41
0FDF :  LDA ZP_DATPTR + 1 ; $42
0FE1 :  ADC #0 ; $00
0FE3 :  STA ZP_DATPTR + 1 ; $42
0FE5 :  LDA #<addr ; $31
0FE7 :  LDY #>addr ; $08
0FE9 :  JSR ROM_MEM_FAC ; $BBA2
0FEC :  LDX #<DX_F
0FEE :  LDY #>DX_F+1
0FF0 :  JSR ROM_FAC_MEM ; $BBD4
0FF3 :  LDA #<addr ; $36
0FF5 :  LDY #>addr ; $08
0FF7 :  JSR ROM_MEM_FAC ; $BBA2
0FFA :  LDX #<DY_F
0FFC :  LDY #>DY_F+1
0FFE :  JSR ROM_FAC_MEM ; $BBD4
1001 :  JMP L10

; 138   $1004  DATA -190.797,28.851,67.84,-0.896,-454.963,-0.512,-320,5.12,-22.733,166.528
; 19,"manzoo.bas"

L138:
; halt
; ---- variables (zero-filled) ----
P = $1100
; P      $1100 (2 bytes)
CX_F = $1102
; CX     $1102 (5 bytes)
CY_F = $1107
; CY     $1107 (5 bytes)
DX_F = $110C
; DX     $110C (5 bytes)
DY_F = $1111
; DY     $1111 (5 bytes)
XR_F = $1116
; XR     $1116 (5 bytes)
YI_F = $111B
; YI     $111B (5 bytes)
SA = $1120
; SA     $1120 (2 bytes)
CA = $1122
; CA     $1122 (2 bytes)
CI_F = $1124
; CI     $1124 (5 bytes)
J = $1129
; J      $1129 (2 bytes)
CR_F = $112B
; CR     $112B (5 bytes)
I = $1130
; I      $1130 (2 bytes)
ZR_F = $1132
; ZR     $1132 (5 bytes)
ZI_F = $1137
; ZI     $1137 (5 bytes)
K_F = $113C
; K      $113C (5 bytes)
RR_F = $1141
; RR     $1141 (5 bytes)
II_F = $1146
; II     $1146 (5 bytes)
NZ_F = $114B
; NZ     $114B (5 bytes)
C = $1150
; C      $1150 (2 bytes)
LIMIT1 = $1152
; LIMIT1 $1152 (2 bytes)
LIMIT2 = $1154
; LIMIT2 $1154 (2 bytes)
1004 :  .res 338	; variable area
