/* OPTIMIZE_C -- breath.bas */
#include "runtime.h"

/* ---- variables ---- */
static breal_t b_v_pif;
static int b_v_ni;
static breal_t b_v_stf;
static int b_v_ii;
static breal_t b_v_af;
static breal_t b_v_vf;
static bint_t b_v_bi;
static int b_v_ri;
static int b_v_ki;
static int b_fl_0;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	/* line 10 */
b_L10: ;
	b_v_pif=(3.141592999920249);
	/* line 20 */
b_L20: ;
	b_v_ni=(64);
	/* line 30 */
b_L30: ;
	b_v_stf=((((2))*(b_v_pif))/(breal_t)(b_v_ni));
	/* line 40 */
b_L40: ;
	#ifdef __AVRCC__
	*(volatile unsigned char*)(36) = (32);
	#else
	b_poke(36,(32));
	#endif
	/* line 50 */
b_L50: ;
	b_v_ii=(0);
	b_fl_0=((b_v_ni)-((1)));
	if(b_v_ii > b_fl_0) goto b_f0_e;
b_f0_t: ;
	/* line 60 */
b_L60: ;
	b_v_af=((b_v_ii)*(b_v_stf));
	/* line 70 */
b_L70: ;
	b_v_vf=b_sin(b_v_af);
	/* line 80 */
b_L80: ;
	b_v_bi=b_int(((((b_v_vf)+((1))))*((127.5))));
	/* line 90 */
b_L90: ;
	b_v_ri=(1);
	if(b_v_ri > 60) goto b_f1_e;
b_f1_t: ;
	/* line 100 */
b_L100: ;
	b_v_ki=(0);
	if(b_v_ki > 255) goto b_f2_e;
b_f2_t: ;
	/* line 110 */
b_L110: ;
	if(-((b_v_ki) < (b_v_bi))){
		#ifdef __AVRCC__
		*(volatile unsigned char*)(37) = (32);
		#else
		b_poke(37,(32));
		#endif
	}
	/* line 120 */
b_L120: ;
	if(-((b_v_ki) >= (b_v_bi))){
		#ifdef __AVRCC__
		*(volatile unsigned char*)(37) = (0);
		#else
		b_poke(37,(0));
		#endif
	}
	/* line 130 */
b_L130: ;
	b_v_ki += 1;
	if(b_v_ki <= 255) goto b_f2_t;
b_f2_e: ;
	/* line 140 */
b_L140: ;
	b_v_ri += 1;
	if(b_v_ri <= 60) goto b_f1_t;
b_f1_e: ;
	/* line 150 */
b_L150: ;
	b_v_ii += 1;
	if(b_v_ii <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
	/* line 160 */
b_L160: ;
	goto b_L50;
b_return: ;
b_end:
	b_flush();
	return 0;
}
