
breath.elf:     file format elf32-avr


Disassembly of section .text:

00000000 <__vectors>:
   0:	0c 94 34 00 	jmp	0x68	; 0x68 <__ctors_end>
   4:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
   8:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
   c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  10:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  14:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  18:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  1c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  20:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  24:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  28:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  2c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  30:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  34:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  38:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  3c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  40:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  44:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  48:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  4c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  50:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  54:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  58:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  5c:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  60:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>
  64:	0c 94 51 00 	jmp	0xa2	; 0xa2 <__bad_interrupt>

00000068 <__ctors_end>:
  68:	11 24       	eor	r1, r1
  6a:	1f be       	out	0x3f, r1	; 63
  6c:	cf ef       	ldi	r28, 0xFF	; 255
  6e:	d8 e0       	ldi	r29, 0x08	; 8
  70:	de bf       	out	0x3e, r29	; 62
  72:	cd bf       	out	0x3d, r28	; 61

00000074 <__do_copy_data>:
  74:	11 e0       	ldi	r17, 0x01	; 1

00000076 <.Loc.1>:
  76:	a0 e0       	ldi	r26, 0x00	; 0

00000078 <.Loc.2>:
  78:	b1 e0       	ldi	r27, 0x01	; 1

0000007a <.Loc.3>:
  7a:	ea e8       	ldi	r30, 0x8A	; 138

0000007c <.Loc.4>:
  7c:	f6 e0       	ldi	r31, 0x06	; 6

0000007e <.Loc.5>:
  7e:	02 c0       	rjmp	.+4      	; 0x84 <.L__do_copy_data_start>

00000080 <.L__do_copy_data_loop>:
  80:	05 90       	lpm	r0, Z+

00000082 <.Loc.7>:
  82:	0d 92       	st	X+, r0

00000084 <.L__do_copy_data_start>:
  84:	a0 30       	cpi	r26, 0x00	; 0

00000086 <.Loc.9>:
  86:	b1 07       	cpc	r27, r17

00000088 <.Loc.10>:
  88:	d9 f7       	brne	.-10     	; 0x80 <.L__do_copy_data_loop>

0000008a <__do_clear_bss>:
  8a:	21 e0       	ldi	r18, 0x01	; 1

0000008c <.Loc.1>:
  8c:	a0 e0       	ldi	r26, 0x00	; 0

0000008e <.Loc.2>:
  8e:	b1 e0       	ldi	r27, 0x01	; 1

00000090 <.Loc.3>:
  90:	01 c0       	rjmp	.+2      	; 0x94 <.Loc.5>

00000092 <.Loc.4>:
  92:	1d 92       	st	X+, r1

00000094 <.Loc.5>:
  94:	a4 30       	cpi	r26, 0x04	; 4

00000096 <.Loc.6>:
  96:	b2 07       	cpc	r27, r18

00000098 <.Loc.7>:
  98:	e1 f7       	brne	.-8      	; 0x92 <.Loc.4>

0000009a <L0^A>:
  9a:	0e 94 53 00 	call	0xa6	; 0xa6 <main>
  9e:	0c 94 34 03 	jmp	0x668	; 0x668 <_exit>

000000a2 <__bad_interrupt>:
  a2:	0c 94 00 00 	jmp	0	; 0x0 <__vectors>

000000a6 <main>:
  a6:	00 d0       	rcall	.+0      	; 0xa8 <L0^A>

000000a8 <L0^A>:
  a8:	00 d0       	rcall	.+0      	; 0xaa <L0^A>

000000aa <L0^A>:
  aa:	00 d0       	rcall	.+0      	; 0xac <L0^A>

000000ac <L0^A>:
  ac:	cd b7       	in	r28, 0x3d	; 61
  ae:	de b7       	in	r29, 0x3e	; 62
  b0:	10 92 02 01 	sts	0x0102, r1	; 0x800102 <b_mem>
  b4:	10 92 03 01 	sts	0x0103, r1	; 0x800103 <b_mem+0x1>
  b8:	10 92 00 01 	sts	0x0100, r1	; 0x800100 <b_dataPtr>
  bc:	10 92 01 01 	sts	0x0101, r1	; 0x800101 <b_dataPtr+0x1>
  c0:	10 92 c5 00 	sts	0x00C5, r1	; 0x8000c5 <__TEXT_REGION_LENGTH__+0x7f80c5>
  c4:	80 e1       	ldi	r24, 0x10	; 16
  c6:	80 93 c4 00 	sts	0x00C4, r24	; 0x8000c4 <__TEXT_REGION_LENGTH__+0x7f80c4>
  ca:	88 e1       	ldi	r24, 0x18	; 24
  cc:	80 93 c1 00 	sts	0x00C1, r24	; 0x8000c1 <__TEXT_REGION_LENGTH__+0x7f80c1>
  d0:	86 e0       	ldi	r24, 0x06	; 6
  d2:	80 93 c2 00 	sts	0x00C2, r24	; 0x8000c2 <__TEXT_REGION_LENGTH__+0x7f80c2>
  d6:	00 91 02 01 	lds	r16, 0x0102	; 0x800102 <b_mem>
  da:	10 91 03 01 	lds	r17, 0x0103	; 0x800103 <b_mem+0x1>
  de:	80 e2       	ldi	r24, 0x20	; 32
  e0:	f8 01       	movw	r30, r16
  e2:	84 a3       	std	Z+36, r24	; 0x24

000000e4 <.L2>:
  e4:	1d 82       	std	Y+5, r1	; 0x05
  e6:	1e 82       	std	Y+6, r1	; 0x06

000000e8 <.L5>:
  e8:	2d 81       	ldd	r18, Y+5	; 0x05
  ea:	3e 81       	ldd	r19, Y+6	; 0x06
  ec:	b9 01       	movw	r22, r18
  ee:	33 0f       	add	r19, r19
  f0:	88 0b       	sbc	r24, r24
  f2:	98 2f       	mov	r25, r24
  f4:	0e 94 87 01 	call	0x30e	; 0x30e <__floatsisf>
  f8:	2c ed       	ldi	r18, 0xDC	; 220
  fa:	3f e0       	ldi	r19, 0x0F	; 15
  fc:	49 ec       	ldi	r20, 0xC9	; 201
  fe:	5d e3       	ldi	r21, 0x3D	; 61
 100:	0e 94 37 02 	call	0x46e	; 0x46e <__mulsf3>
 104:	0e 94 a4 02 	call	0x548	; 0x548 <sinf>
 108:	20 e0       	ldi	r18, 0x00	; 0
 10a:	30 e0       	ldi	r19, 0x00	; 0
 10c:	40 e8       	ldi	r20, 0x80	; 128
 10e:	5f e3       	ldi	r21, 0x3F	; 63
 110:	0e 94 de 00 	call	0x1bc	; 0x1bc <__addsf3>
 114:	20 e0       	ldi	r18, 0x00	; 0
 116:	30 e0       	ldi	r19, 0x00	; 0
 118:	4f ef       	ldi	r20, 0xFF	; 255
 11a:	52 e4       	ldi	r21, 0x42	; 66
 11c:	0e 94 37 02 	call	0x46e	; 0x46e <__mulsf3>
 120:	69 83       	std	Y+1, r22	; 0x01
 122:	7a 83       	std	Y+2, r23	; 0x02
 124:	8b 83       	std	Y+3, r24	; 0x03
 126:	9c 83       	std	Y+4, r25	; 0x04
 128:	0e 94 4f 01 	call	0x29e	; 0x29e <__fixsfsi>
 12c:	6b 01       	movw	r12, r22
 12e:	7c 01       	movw	r14, r24
 130:	40 e0       	ldi	r20, 0x00	; 0
 132:	50 e0       	ldi	r21, 0x00	; 0
 134:	9a 01       	movw	r18, r20
 136:	69 81       	ldd	r22, Y+1	; 0x01
 138:	7a 81       	ldd	r23, Y+2	; 0x02
 13a:	8b 81       	ldd	r24, Y+3	; 0x03
 13c:	9c 81       	ldd	r25, Y+4	; 0x04
 13e:	0e 94 4a 01 	call	0x294	; 0x294 <__cmpsf2>
 142:	87 ff       	sbrs	r24, 7
 144:	13 c0       	rjmp	.+38     	; 0x16c <.L7>
 146:	b6 01       	movw	r22, r12
 148:	c7 01       	movw	r24, r14
 14a:	0e 94 87 01 	call	0x30e	; 0x30e <__floatsisf>
 14e:	9b 01       	movw	r18, r22
 150:	ac 01       	movw	r20, r24
 152:	69 81       	ldd	r22, Y+1	; 0x01
 154:	7a 81       	ldd	r23, Y+2	; 0x02
 156:	8b 81       	ldd	r24, Y+3	; 0x03
 158:	9c 81       	ldd	r25, Y+4	; 0x04
 15a:	0e 94 4a 01 	call	0x294	; 0x294 <__cmpsf2>
 15e:	81 15       	cp	r24, r1
 160:	29 f0       	breq	.+10     	; 0x16c <.L7>
 162:	31 e0       	ldi	r19, 0x01	; 1
 164:	c3 1a       	sub	r12, r19
 166:	d1 08       	sbc	r13, r1
 168:	e1 08       	sbc	r14, r1
 16a:	f1 08       	sbc	r15, r1

0000016c <.L7>:
 16c:	2c e3       	ldi	r18, 0x3C	; 60
 16e:	30 e0       	ldi	r19, 0x00	; 0

00000170 <.L10>:
 170:	a0 e0       	ldi	r26, 0x00	; 0
 172:	b0 e0       	ldi	r27, 0x00	; 0
 174:	cd 01       	movw	r24, r26

00000176 <.L12>:
 176:	8c 15       	cp	r24, r12
 178:	9d 05       	cpc	r25, r13
 17a:	ae 05       	cpc	r26, r14
 17c:	bf 05       	cpc	r27, r15
 17e:	cc f0       	brlt	.+50     	; 0x1b2 <.L14>
 180:	f8 01       	movw	r30, r16
 182:	15 a2       	std	Z+37, r1	; 0x25

00000184 <.L15>:
 184:	01 96       	adiw	r24, 0x01	; 1
 186:	a1 1d       	adc	r26, r1
 188:	b1 1d       	adc	r27, r1
 18a:	81 15       	cp	r24, r1
 18c:	e1 e0       	ldi	r30, 0x01	; 1
 18e:	9e 07       	cpc	r25, r30
 190:	a1 05       	cpc	r26, r1
 192:	b1 05       	cpc	r27, r1
 194:	81 f7       	brne	.-32     	; 0x176 <.L12>
 196:	21 50       	subi	r18, 0x01	; 1
 198:	30 40       	sbci	r19, 0x00	; 0
 19a:	51 f7       	brne	.-44     	; 0x170 <.L10>
 19c:	2d 81       	ldd	r18, Y+5	; 0x05
 19e:	3e 81       	ldd	r19, Y+6	; 0x06
 1a0:	2f 5f       	subi	r18, 0xFF	; 255
 1a2:	3f 4f       	sbci	r19, 0xFF	; 255
 1a4:	2d 83       	std	Y+5, r18	; 0x05
 1a6:	3e 83       	std	Y+6, r19	; 0x06
 1a8:	20 34       	cpi	r18, 0x40	; 64
 1aa:	31 05       	cpc	r19, r1
 1ac:	09 f0       	breq	.+2      	; 0x1b0 <L0^A+0x2>

000001ae <L0^A>:
 1ae:	9c cf       	rjmp	.-200    	; 0xe8 <.L5>
 1b0:	99 cf       	rjmp	.-206    	; 0xe4 <.L2>

000001b2 <.L14>:
 1b2:	40 e2       	ldi	r20, 0x20	; 32
 1b4:	f8 01       	movw	r30, r16
 1b6:	45 a3       	std	Z+37, r20	; 0x25
 1b8:	e5 cf       	rjmp	.-54     	; 0x184 <.L15>

000001ba <__subsf3>:
 1ba:	50 58       	subi	r21, 0x80	; 128

000001bc <__addsf3>:
 1bc:	bb 27       	eor	r27, r27
 1be:	aa 27       	eor	r26, r26
 1c0:	0e 94 f5 00 	call	0x1ea	; 0x1ea <__addsf3x>
 1c4:	0c 94 fd 01 	jmp	0x3fa	; 0x3fa <__fp_round>

000001c8 <.L0^B1>:
 1c8:	0e 94 ef 01 	call	0x3de	; 0x3de <__fp_pscA>
 1cc:	38 f0       	brcs	.+14     	; 0x1dc <.L_nan>
 1ce:	0e 94 f6 01 	call	0x3ec	; 0x3ec <__fp_pscB>
 1d2:	20 f0       	brcs	.+8      	; 0x1dc <.L_nan>
 1d4:	39 f4       	brne	.+14     	; 0x1e4 <.L_inf>
 1d6:	9f 3f       	cpi	r25, 0xFF	; 255
 1d8:	19 f4       	brne	.+6      	; 0x1e0 <.L_infB>
 1da:	26 f4       	brtc	.+8      	; 0x1e4 <.L_inf>

000001dc <.L_nan>:
 1dc:	0c 94 ec 01 	jmp	0x3d8	; 0x3d8 <__fp_nan>

000001e0 <.L_infB>:
 1e0:	0e f4       	brtc	.+2      	; 0x1e4 <.L_inf>
 1e2:	e0 95       	com	r30

000001e4 <.L_inf>:
 1e4:	e7 fb       	bst	r30, 7
 1e6:	0c 94 e6 01 	jmp	0x3cc	; 0x3cc <__fp_inf>

000001ea <__addsf3x>:
 1ea:	e9 2f       	mov	r30, r25
 1ec:	0e 94 0e 02 	call	0x41c	; 0x41c <__fp_split3>
 1f0:	58 f3       	brcs	.-42     	; 0x1c8 <.L0^B1>
 1f2:	ba 17       	cp	r27, r26
 1f4:	62 07       	cpc	r22, r18
 1f6:	73 07       	cpc	r23, r19
 1f8:	84 07       	cpc	r24, r20
 1fa:	95 07       	cpc	r25, r21
 1fc:	20 f0       	brcs	.+8      	; 0x206 <.L2^B1>
 1fe:	79 f4       	brne	.+30     	; 0x21e <.L4^B1>
 200:	a6 f5       	brtc	.+104    	; 0x26a <.L_add>
 202:	0c 94 30 02 	jmp	0x460	; 0x460 <__fp_zero>

00000206 <.L2^B1>:
 206:	0e f4       	brtc	.+2      	; 0x20a <.L3^B1>
 208:	e0 95       	com	r30

0000020a <.L3^B1>:
 20a:	0b 2e       	mov	r0, r27
 20c:	ba 2f       	mov	r27, r26
 20e:	a0 2d       	mov	r26, r0
 210:	0b 01       	movw	r0, r22
 212:	b9 01       	movw	r22, r18
 214:	90 01       	movw	r18, r0
 216:	0c 01       	movw	r0, r24
 218:	ca 01       	movw	r24, r20
 21a:	a0 01       	movw	r20, r0
 21c:	11 24       	eor	r1, r1

0000021e <.L4^B1>:
 21e:	ff 27       	eor	r31, r31
 220:	59 1b       	sub	r21, r25

00000222 <.L5^B1>:
 222:	99 f0       	breq	.+38     	; 0x24a <.L7^B1>
 224:	59 3f       	cpi	r21, 0xF9	; 249
 226:	50 f4       	brcc	.+20     	; 0x23c <.L6^B1>
 228:	50 3e       	cpi	r21, 0xE0	; 224
 22a:	68 f1       	brcs	.+90     	; 0x286 <.L_ret>
 22c:	1a 16       	cp	r1, r26
 22e:	f0 40       	sbci	r31, 0x00	; 0
 230:	a2 2f       	mov	r26, r18
 232:	23 2f       	mov	r18, r19
 234:	34 2f       	mov	r19, r20
 236:	44 27       	eor	r20, r20
 238:	58 5f       	subi	r21, 0xF8	; 248
 23a:	f3 cf       	rjmp	.-26     	; 0x222 <.L5^B1>

0000023c <.L6^B1>:
 23c:	46 95       	lsr	r20
 23e:	37 95       	ror	r19
 240:	27 95       	ror	r18
 242:	a7 95       	ror	r26
 244:	f0 40       	sbci	r31, 0x00	; 0
 246:	53 95       	inc	r21
 248:	c9 f7       	brne	.-14     	; 0x23c <.L6^B1>

0000024a <.L7^B1>:
 24a:	7e f4       	brtc	.+30     	; 0x26a <.L_add>
 24c:	1f 16       	cp	r1, r31
 24e:	ba 0b       	sbc	r27, r26
 250:	62 0b       	sbc	r22, r18
 252:	73 0b       	sbc	r23, r19
 254:	84 0b       	sbc	r24, r20
 256:	ba f0       	brmi	.+46     	; 0x286 <.L_ret>

00000258 <.L8^B1>:
 258:	91 50       	subi	r25, 0x01	; 1
 25a:	a1 f0       	breq	.+40     	; 0x284 <.L9^B1>
 25c:	ff 0f       	add	r31, r31
 25e:	bb 1f       	adc	r27, r27
 260:	66 1f       	adc	r22, r22
 262:	77 1f       	adc	r23, r23
 264:	88 1f       	adc	r24, r24
 266:	c2 f7       	brpl	.-16     	; 0x258 <.L8^B1>
 268:	0e c0       	rjmp	.+28     	; 0x286 <.L_ret>

0000026a <.L_add>:
 26a:	ba 0f       	add	r27, r26
 26c:	62 1f       	adc	r22, r18
 26e:	73 1f       	adc	r23, r19
 270:	84 1f       	adc	r24, r20
 272:	48 f4       	brcc	.+18     	; 0x286 <.L_ret>
 274:	87 95       	ror	r24
 276:	77 95       	ror	r23
 278:	67 95       	ror	r22
 27a:	b7 95       	ror	r27
 27c:	f7 95       	ror	r31
 27e:	9e 3f       	cpi	r25, 0xFE	; 254
 280:	08 f0       	brcs	.+2      	; 0x284 <.L9^B1>
 282:	b0 cf       	rjmp	.-160    	; 0x1e4 <.L_inf>

00000284 <.L9^B1>:
 284:	93 95       	inc	r25

00000286 <.L_ret>:
 286:	88 0f       	add	r24, r24
 288:	08 f0       	brcs	.+2      	; 0x28c <.L1^B1>
 28a:	99 27       	eor	r25, r25

0000028c <.L1^B1>:
 28c:	ee 0f       	add	r30, r30
 28e:	97 95       	ror	r25
 290:	87 95       	ror	r24
 292:	08 95       	ret

00000294 <__cmpsf2>:
 294:	0e 94 c2 01 	call	0x384	; 0x384 <__fp_cmp>
 298:	08 f4       	brcc	.+2      	; 0x29c <.L1^B1>
 29a:	81 e0       	ldi	r24, 0x01	; 1

0000029c <.L1^B1>:
 29c:	08 95       	ret

0000029e <__fixsfsi>:
 29e:	0e 94 56 01 	call	0x2ac	; 0x2ac <__fixunssfsi>
 2a2:	68 94       	set
 2a4:	b1 11       	cpse	r27, r1
 2a6:	0c 94 31 02 	jmp	0x462	; 0x462 <__fp_szero>
 2aa:	08 95       	ret

000002ac <__fixunssfsi>:
 2ac:	0e 94 16 02 	call	0x42c	; 0x42c <__fp_splitA>
 2b0:	88 f0       	brcs	.+34     	; 0x2d4 <.L_err>
 2b2:	9f 57       	subi	r25, 0x7F	; 127
 2b4:	98 f0       	brcs	.+38     	; 0x2dc <.L_zr>
 2b6:	b9 2f       	mov	r27, r25
 2b8:	99 27       	eor	r25, r25
 2ba:	b7 51       	subi	r27, 0x17	; 23
 2bc:	b0 f0       	brcs	.+44     	; 0x2ea <.L4^B1>
 2be:	e1 f0       	breq	.+56     	; 0x2f8 <.L_sign>

000002c0 <.L1^B1>:
 2c0:	66 0f       	add	r22, r22
 2c2:	77 1f       	adc	r23, r23
 2c4:	88 1f       	adc	r24, r24
 2c6:	99 1f       	adc	r25, r25
 2c8:	1a f0       	brmi	.+6      	; 0x2d0 <.L2^B1>
 2ca:	ba 95       	dec	r27
 2cc:	c9 f7       	brne	.-14     	; 0x2c0 <.L1^B1>
 2ce:	14 c0       	rjmp	.+40     	; 0x2f8 <.L_sign>

000002d0 <.L2^B1>:
 2d0:	b1 30       	cpi	r27, 0x01	; 1
 2d2:	91 f0       	breq	.+36     	; 0x2f8 <.L_sign>

000002d4 <.L_err>:
 2d4:	0e 94 30 02 	call	0x460	; 0x460 <__fp_zero>
 2d8:	b1 e0       	ldi	r27, 0x01	; 1
 2da:	08 95       	ret

000002dc <.L_zr>:
 2dc:	0c 94 30 02 	jmp	0x460	; 0x460 <__fp_zero>

000002e0 <.L3^B1>:
 2e0:	67 2f       	mov	r22, r23
 2e2:	78 2f       	mov	r23, r24
 2e4:	88 27       	eor	r24, r24
 2e6:	b8 5f       	subi	r27, 0xF8	; 248
 2e8:	39 f0       	breq	.+14     	; 0x2f8 <.L_sign>

000002ea <.L4^B1>:
 2ea:	b9 3f       	cpi	r27, 0xF9	; 249
 2ec:	cc f3       	brlt	.-14     	; 0x2e0 <.L3^B1>

000002ee <.L5^B1>:
 2ee:	86 95       	lsr	r24
 2f0:	77 95       	ror	r23
 2f2:	67 95       	ror	r22
 2f4:	b3 95       	inc	r27
 2f6:	d9 f7       	brne	.-10     	; 0x2ee <.L5^B1>

000002f8 <.L_sign>:
 2f8:	3e f4       	brtc	.+14     	; 0x308 <.L6^B1>
 2fa:	90 95       	com	r25
 2fc:	80 95       	com	r24
 2fe:	70 95       	com	r23
 300:	61 95       	neg	r22
 302:	7f 4f       	sbci	r23, 0xFF	; 255
 304:	8f 4f       	sbci	r24, 0xFF	; 255
 306:	9f 4f       	sbci	r25, 0xFF	; 255

00000308 <.L6^B1>:
 308:	08 95       	ret

0000030a <__floatunsisf>:
 30a:	e8 94       	clt
 30c:	09 c0       	rjmp	.+18     	; 0x320 <.L1^B1>

0000030e <__floatsisf>:
 30e:	97 fb       	bst	r25, 7
 310:	3e f4       	brtc	.+14     	; 0x320 <.L1^B1>
 312:	90 95       	com	r25
 314:	80 95       	com	r24
 316:	70 95       	com	r23
 318:	61 95       	neg	r22
 31a:	7f 4f       	sbci	r23, 0xFF	; 255
 31c:	8f 4f       	sbci	r24, 0xFF	; 255
 31e:	9f 4f       	sbci	r25, 0xFF	; 255

00000320 <.L1^B1>:
 320:	99 23       	and	r25, r25
 322:	a9 f0       	breq	.+42     	; 0x34e <.L4^B1>
 324:	f9 2f       	mov	r31, r25
 326:	96 e9       	ldi	r25, 0x96	; 150
 328:	bb 27       	eor	r27, r27

0000032a <.L2^B1>:
 32a:	93 95       	inc	r25
 32c:	f6 95       	lsr	r31
 32e:	87 95       	ror	r24
 330:	77 95       	ror	r23
 332:	67 95       	ror	r22
 334:	b7 95       	ror	r27
 336:	f1 11       	cpse	r31, r1
 338:	f8 cf       	rjmp	.-16     	; 0x32a <.L2^B1>
 33a:	fa f4       	brpl	.+62     	; 0x37a <.L_pack>
 33c:	bb 0f       	add	r27, r27
 33e:	11 f4       	brne	.+4      	; 0x344 <.L3^B1>
 340:	60 ff       	sbrs	r22, 0
 342:	1b c0       	rjmp	.+54     	; 0x37a <.L_pack>

00000344 <.L3^B1>:
 344:	6f 5f       	subi	r22, 0xFF	; 255
 346:	7f 4f       	sbci	r23, 0xFF	; 255
 348:	8f 4f       	sbci	r24, 0xFF	; 255
 34a:	9f 4f       	sbci	r25, 0xFF	; 255
 34c:	16 c0       	rjmp	.+44     	; 0x37a <.L_pack>

0000034e <.L4^B1>:
 34e:	88 23       	and	r24, r24
 350:	11 f0       	breq	.+4      	; 0x356 <.L5^B1>
 352:	96 e9       	ldi	r25, 0x96	; 150
 354:	11 c0       	rjmp	.+34     	; 0x378 <.L8^B1>

00000356 <.L5^B1>:
 356:	77 23       	and	r23, r23
 358:	21 f0       	breq	.+8      	; 0x362 <.L6^B1>
 35a:	9e e8       	ldi	r25, 0x8E	; 142
 35c:	87 2f       	mov	r24, r23
 35e:	76 2f       	mov	r23, r22
 360:	05 c0       	rjmp	.+10     	; 0x36c <.L7^B1>

00000362 <.L6^B1>:
 362:	66 23       	and	r22, r22
 364:	71 f0       	breq	.+28     	; 0x382 <.L9^B1>
 366:	96 e8       	ldi	r25, 0x86	; 134
 368:	86 2f       	mov	r24, r22
 36a:	70 e0       	ldi	r23, 0x00	; 0

0000036c <.L7^B1>:
 36c:	60 e0       	ldi	r22, 0x00	; 0
 36e:	2a f0       	brmi	.+10     	; 0x37a <.L_pack>

00000370 <.L10^B1>:
 370:	9a 95       	dec	r25
 372:	66 0f       	add	r22, r22
 374:	77 1f       	adc	r23, r23
 376:	88 1f       	adc	r24, r24

00000378 <.L8^B1>:
 378:	da f7       	brpl	.-10     	; 0x370 <.L10^B1>

0000037a <.L_pack>:
 37a:	88 0f       	add	r24, r24
 37c:	96 95       	lsr	r25
 37e:	87 95       	ror	r24
 380:	97 f9       	bld	r25, 7

00000382 <.L9^B1>:
 382:	08 95       	ret

00000384 <__fp_cmp>:
 384:	99 0f       	add	r25, r25
 386:	00 08       	sbc	r0, r0
 388:	55 0f       	add	r21, r21
 38a:	aa 0b       	sbc	r26, r26
 38c:	e0 e8       	ldi	r30, 0x80	; 128
 38e:	fe ef       	ldi	r31, 0xFE	; 254
 390:	16 16       	cp	r1, r22
 392:	17 06       	cpc	r1, r23
 394:	e8 07       	cpc	r30, r24
 396:	f9 07       	cpc	r31, r25
 398:	c0 f0       	brcs	.+48     	; 0x3ca <.L9^B1>
 39a:	12 16       	cp	r1, r18
 39c:	13 06       	cpc	r1, r19
 39e:	e4 07       	cpc	r30, r20
 3a0:	f5 07       	cpc	r31, r21
 3a2:	98 f0       	brcs	.+38     	; 0x3ca <.L9^B1>
 3a4:	62 1b       	sub	r22, r18
 3a6:	73 0b       	sbc	r23, r19
 3a8:	84 0b       	sbc	r24, r20
 3aa:	95 0b       	sbc	r25, r21
 3ac:	39 f4       	brne	.+14     	; 0x3bc <.L1^B1>
 3ae:	0a 26       	eor	r0, r26
 3b0:	61 f0       	breq	.+24     	; 0x3ca <.L9^B1>
 3b2:	23 2b       	or	r18, r19
 3b4:	24 2b       	or	r18, r20
 3b6:	25 2b       	or	r18, r21
 3b8:	21 f4       	brne	.+8      	; 0x3c2 <.L2^B1>
 3ba:	08 95       	ret

000003bc <.L1^B1>:
 3bc:	0a 26       	eor	r0, r26
 3be:	09 f4       	brne	.+2      	; 0x3c2 <.L2^B1>
 3c0:	a1 40       	sbci	r26, 0x01	; 1

000003c2 <.L2^B1>:
 3c2:	a6 95       	lsr	r26
 3c4:	8f ef       	ldi	r24, 0xFF	; 255
 3c6:	81 1d       	adc	r24, r1
 3c8:	81 1d       	adc	r24, r1

000003ca <.L9^B1>:
 3ca:	08 95       	ret

000003cc <__fp_inf>:
 3cc:	97 f9       	bld	r25, 7
 3ce:	9f 67       	ori	r25, 0x7F	; 127
 3d0:	80 e8       	ldi	r24, 0x80	; 128
 3d2:	70 e0       	ldi	r23, 0x00	; 0
 3d4:	60 e0       	ldi	r22, 0x00	; 0
 3d6:	08 95       	ret

000003d8 <__fp_nan>:
 3d8:	9f ef       	ldi	r25, 0xFF	; 255
 3da:	80 ec       	ldi	r24, 0xC0	; 192
 3dc:	08 95       	ret

000003de <__fp_pscA>:
 3de:	00 24       	eor	r0, r0
 3e0:	0a 94       	dec	r0
 3e2:	16 16       	cp	r1, r22
 3e4:	17 06       	cpc	r1, r23
 3e6:	18 06       	cpc	r1, r24
 3e8:	09 06       	cpc	r0, r25
 3ea:	08 95       	ret

000003ec <__fp_pscB>:
 3ec:	00 24       	eor	r0, r0
 3ee:	0a 94       	dec	r0
 3f0:	12 16       	cp	r1, r18
 3f2:	13 06       	cpc	r1, r19
 3f4:	14 06       	cpc	r1, r20
 3f6:	05 06       	cpc	r0, r21
 3f8:	08 95       	ret

000003fa <__fp_round>:
 3fa:	09 2e       	mov	r0, r25
 3fc:	03 94       	inc	r0
 3fe:	00 0c       	add	r0, r0
 400:	11 f4       	brne	.+4      	; 0x406 <.L1^B1>
 402:	88 23       	and	r24, r24
 404:	52 f0       	brmi	.+20     	; 0x41a <.L3^B1>

00000406 <.L1^B1>:
 406:	bb 0f       	add	r27, r27
 408:	40 f4       	brcc	.+16     	; 0x41a <.L3^B1>
 40a:	bf 2b       	or	r27, r31
 40c:	11 f4       	brne	.+4      	; 0x412 <.L2^B1>
 40e:	60 ff       	sbrs	r22, 0
 410:	04 c0       	rjmp	.+8      	; 0x41a <.L3^B1>

00000412 <.L2^B1>:
 412:	6f 5f       	subi	r22, 0xFF	; 255
 414:	7f 4f       	sbci	r23, 0xFF	; 255
 416:	8f 4f       	sbci	r24, 0xFF	; 255
 418:	9f 4f       	sbci	r25, 0xFF	; 255

0000041a <.L3^B1>:
 41a:	08 95       	ret

0000041c <__fp_split3>:
 41c:	57 fd       	sbrc	r21, 7
 41e:	90 58       	subi	r25, 0x80	; 128
 420:	44 0f       	add	r20, r20
 422:	55 1f       	adc	r21, r21
 424:	59 f0       	breq	.+22     	; 0x43c <.L4^B1>
 426:	5f 3f       	cpi	r21, 0xFF	; 255
 428:	71 f0       	breq	.+28     	; 0x446 <.L5^B1>

0000042a <.L1^B1>:
 42a:	47 95       	ror	r20

0000042c <__fp_splitA>:
 42c:	88 0f       	add	r24, r24
 42e:	97 fb       	bst	r25, 7
 430:	99 1f       	adc	r25, r25
 432:	61 f0       	breq	.+24     	; 0x44c <.L6^B1>
 434:	9f 3f       	cpi	r25, 0xFF	; 255
 436:	79 f0       	breq	.+30     	; 0x456 <.L7^B1>

00000438 <.L3^B1>:
 438:	87 95       	ror	r24
 43a:	08 95       	ret

0000043c <.L4^B1>:
 43c:	12 16       	cp	r1, r18
 43e:	13 06       	cpc	r1, r19
 440:	14 06       	cpc	r1, r20
 442:	55 1f       	adc	r21, r21
 444:	f2 cf       	rjmp	.-28     	; 0x42a <.L1^B1>

00000446 <.L5^B1>:
 446:	46 95       	lsr	r20
 448:	f1 df       	rcall	.-30     	; 0x42c <__fp_splitA>
 44a:	08 c0       	rjmp	.+16     	; 0x45c <.L8^B1>

0000044c <.L6^B1>:
 44c:	16 16       	cp	r1, r22
 44e:	17 06       	cpc	r1, r23
 450:	18 06       	cpc	r1, r24
 452:	99 1f       	adc	r25, r25
 454:	f1 cf       	rjmp	.-30     	; 0x438 <.L3^B1>

00000456 <.L7^B1>:
 456:	86 95       	lsr	r24
 458:	71 05       	cpc	r23, r1
 45a:	61 05       	cpc	r22, r1

0000045c <.L8^B1>:
 45c:	08 94       	sec
 45e:	08 95       	ret

00000460 <__fp_zero>:
 460:	e8 94       	clt

00000462 <__fp_szero>:
 462:	bb 27       	eor	r27, r27
 464:	66 27       	eor	r22, r22
 466:	77 27       	eor	r23, r23
 468:	cb 01       	movw	r24, r22
 46a:	97 f9       	bld	r25, 7
 46c:	08 95       	ret

0000046e <__mulsf3>:
 46e:	0e 94 4a 02 	call	0x494	; 0x494 <__mulsf3x>
 472:	0c 94 fd 01 	jmp	0x3fa	; 0x3fa <__fp_round>

00000476 <.L0^B1>:
 476:	0e 94 ef 01 	call	0x3de	; 0x3de <__fp_pscA>
 47a:	38 f0       	brcs	.+14     	; 0x48a <.L1^B1>
 47c:	0e 94 f6 01 	call	0x3ec	; 0x3ec <__fp_pscB>
 480:	20 f0       	brcs	.+8      	; 0x48a <.L1^B1>
 482:	95 23       	and	r25, r21
 484:	11 f0       	breq	.+4      	; 0x48a <.L1^B1>
 486:	0c 94 e6 01 	jmp	0x3cc	; 0x3cc <__fp_inf>

0000048a <.L1^B1>:
 48a:	0c 94 ec 01 	jmp	0x3d8	; 0x3d8 <__fp_nan>

0000048e <.L2^B1>:
 48e:	11 24       	eor	r1, r1
 490:	0c 94 31 02 	jmp	0x462	; 0x462 <__fp_szero>

00000494 <__mulsf3x>:
 494:	0e 94 0e 02 	call	0x41c	; 0x41c <__fp_split3>
 498:	70 f3       	brcs	.-36     	; 0x476 <.L0^B1>

0000049a <__mulsf3_pse>:
 49a:	95 9f       	mul	r25, r21
 49c:	c1 f3       	breq	.-16     	; 0x48e <.L2^B1>
 49e:	95 0f       	add	r25, r21
 4a0:	50 e0       	ldi	r21, 0x00	; 0
 4a2:	55 1f       	adc	r21, r21
 4a4:	62 9f       	mul	r22, r18
 4a6:	f0 01       	movw	r30, r0
 4a8:	72 9f       	mul	r23, r18
 4aa:	bb 27       	eor	r27, r27
 4ac:	f0 0d       	add	r31, r0
 4ae:	b1 1d       	adc	r27, r1
 4b0:	63 9f       	mul	r22, r19
 4b2:	aa 27       	eor	r26, r26
 4b4:	f0 0d       	add	r31, r0
 4b6:	b1 1d       	adc	r27, r1
 4b8:	aa 1f       	adc	r26, r26
 4ba:	64 9f       	mul	r22, r20
 4bc:	66 27       	eor	r22, r22
 4be:	b0 0d       	add	r27, r0
 4c0:	a1 1d       	adc	r26, r1
 4c2:	66 1f       	adc	r22, r22
 4c4:	82 9f       	mul	r24, r18
 4c6:	22 27       	eor	r18, r18
 4c8:	b0 0d       	add	r27, r0
 4ca:	a1 1d       	adc	r26, r1
 4cc:	62 1f       	adc	r22, r18
 4ce:	73 9f       	mul	r23, r19
 4d0:	b0 0d       	add	r27, r0
 4d2:	a1 1d       	adc	r26, r1
 4d4:	62 1f       	adc	r22, r18
 4d6:	83 9f       	mul	r24, r19
 4d8:	a0 0d       	add	r26, r0
 4da:	61 1d       	adc	r22, r1
 4dc:	22 1f       	adc	r18, r18
 4de:	74 9f       	mul	r23, r20
 4e0:	33 27       	eor	r19, r19
 4e2:	a0 0d       	add	r26, r0
 4e4:	61 1d       	adc	r22, r1
 4e6:	23 1f       	adc	r18, r19
 4e8:	84 9f       	mul	r24, r20
 4ea:	60 0d       	add	r22, r0
 4ec:	21 1d       	adc	r18, r1
 4ee:	82 2f       	mov	r24, r18
 4f0:	76 2f       	mov	r23, r22
 4f2:	6a 2f       	mov	r22, r26
 4f4:	11 24       	eor	r1, r1
 4f6:	9f 57       	subi	r25, 0x7F	; 127
 4f8:	50 40       	sbci	r21, 0x00	; 0
 4fa:	9a f0       	brmi	.+38     	; 0x522 <.L13^B1>
 4fc:	f1 f0       	breq	.+60     	; 0x53a <.L15^B1>

000004fe <.L10^B1>:
 4fe:	88 23       	and	r24, r24
 500:	4a f0       	brmi	.+18     	; 0x514 <.L11^B1>
 502:	ee 0f       	add	r30, r30
 504:	ff 1f       	adc	r31, r31
 506:	bb 1f       	adc	r27, r27
 508:	66 1f       	adc	r22, r22
 50a:	77 1f       	adc	r23, r23
 50c:	88 1f       	adc	r24, r24
 50e:	91 50       	subi	r25, 0x01	; 1
 510:	50 40       	sbci	r21, 0x00	; 0
 512:	a9 f7       	brne	.-22     	; 0x4fe <.L10^B1>

00000514 <.L11^B1>:
 514:	9e 3f       	cpi	r25, 0xFE	; 254
 516:	51 05       	cpc	r21, r1
 518:	80 f0       	brcs	.+32     	; 0x53a <.L15^B1>
 51a:	0c 94 e6 01 	jmp	0x3cc	; 0x3cc <__fp_inf>

0000051e <.L12^B1>:
 51e:	0c 94 31 02 	jmp	0x462	; 0x462 <__fp_szero>

00000522 <.L13^B1>:
 522:	5f 3f       	cpi	r21, 0xFF	; 255
 524:	e4 f3       	brlt	.-8      	; 0x51e <.L12^B1>
 526:	98 3e       	cpi	r25, 0xE8	; 232
 528:	d4 f3       	brlt	.-12     	; 0x51e <.L12^B1>

0000052a <.L14^B1>:
 52a:	86 95       	lsr	r24
 52c:	77 95       	ror	r23
 52e:	67 95       	ror	r22
 530:	b7 95       	ror	r27
 532:	f7 95       	ror	r31
 534:	e7 95       	ror	r30
 536:	9f 5f       	subi	r25, 0xFF	; 255
 538:	c1 f7       	brne	.-16     	; 0x52a <.L14^B1>

0000053a <.L15^B1>:
 53a:	fe 2b       	or	r31, r30
 53c:	88 0f       	add	r24, r24
 53e:	91 1d       	adc	r25, r1
 540:	96 95       	lsr	r25
 542:	87 95       	ror	r24
 544:	97 f9       	bld	r25, 7
 546:	08 95       	ret

00000548 <sinf>:
 548:	9f 93       	push	r25
 54a:	0e 94 ae 02 	call	0x55c	; 0x55c <__fp_rempio2>
 54e:	0f 90       	pop	r0
 550:	07 fc       	sbrc	r0, 7
 552:	ee 5f       	subi	r30, 0xFE	; 254
 554:	0c 94 d7 02 	jmp	0x5ae	; 0x5ae <__fp_sinus>

00000558 <.L0^B1>:
 558:	0c 94 ec 01 	jmp	0x3d8	; 0x3d8 <__fp_nan>

0000055c <__fp_rempio2>:
 55c:	0e 94 16 02 	call	0x42c	; 0x42c <__fp_splitA>
 560:	d8 f3       	brcs	.-10     	; 0x558 <.L0^B1>
 562:	e8 94       	clt
 564:	e0 e0       	ldi	r30, 0x00	; 0
 566:	bb 27       	eor	r27, r27
 568:	9f 57       	subi	r25, 0x7F	; 127
 56a:	f0 f0       	brcs	.+60     	; 0x5a8 <.L5^B1>
 56c:	2a ed       	ldi	r18, 0xDA	; 218
 56e:	3f e0       	ldi	r19, 0x0F	; 15
 570:	49 ec       	ldi	r20, 0xC9	; 201
 572:	06 c0       	rjmp	.+12     	; 0x580 <.L1^B1>

00000574 <.Loop>:
 574:	ee 0f       	add	r30, r30
 576:	bb 0f       	add	r27, r27
 578:	66 1f       	adc	r22, r22
 57a:	77 1f       	adc	r23, r23
 57c:	88 1f       	adc	r24, r24
 57e:	28 f0       	brcs	.+10     	; 0x58a <.L2^B1>

00000580 <.L1^B1>:
 580:	b2 3a       	cpi	r27, 0xA2	; 162
 582:	62 07       	cpc	r22, r18
 584:	73 07       	cpc	r23, r19
 586:	84 07       	cpc	r24, r20
 588:	28 f0       	brcs	.+10     	; 0x594 <.L3^B1>

0000058a <.L2^B1>:
 58a:	b2 5a       	subi	r27, 0xA2	; 162
 58c:	62 0b       	sbc	r22, r18
 58e:	73 0b       	sbc	r23, r19
 590:	84 0b       	sbc	r24, r20
 592:	e3 95       	inc	r30

00000594 <.L3^B1>:
 594:	9a 95       	dec	r25
 596:	72 f7       	brpl	.-36     	; 0x574 <.Loop>
 598:	80 38       	cpi	r24, 0x80	; 128
 59a:	30 f4       	brcc	.+12     	; 0x5a8 <.L5^B1>

0000059c <.L4^B1>:
 59c:	9a 95       	dec	r25
 59e:	bb 0f       	add	r27, r27
 5a0:	66 1f       	adc	r22, r22
 5a2:	77 1f       	adc	r23, r23
 5a4:	88 1f       	adc	r24, r24
 5a6:	d2 f7       	brpl	.-12     	; 0x59c <.L4^B1>

000005a8 <.L5^B1>:
 5a8:	90 48       	sbci	r25, 0x80	; 128
 5aa:	0c 94 ed 02 	jmp	0x5da	; 0x5da <__fp_mpack_finite>

000005ae <__fp_sinus>:
 5ae:	ef 93       	push	r30
 5b0:	e0 ff       	sbrs	r30, 0
 5b2:	07 c0       	rjmp	.+14     	; 0x5c2 <.L1^B1>
 5b4:	a2 ea       	ldi	r26, 0xA2	; 162
 5b6:	2a ed       	ldi	r18, 0xDA	; 218
 5b8:	3f e0       	ldi	r19, 0x0F	; 15
 5ba:	49 ec       	ldi	r20, 0xC9	; 201
 5bc:	5f eb       	ldi	r21, 0xBF	; 191
 5be:	0e 94 f5 00 	call	0x1ea	; 0x1ea <__addsf3x>

000005c2 <.L1^B1>:
 5c2:	0e 94 fd 01 	call	0x3fa	; 0x3fa <__fp_round>
 5c6:	0f 90       	pop	r0
 5c8:	03 94       	inc	r0
 5ca:	01 fc       	sbrc	r0, 1
 5cc:	90 58       	subi	r25, 0x80	; 128
 5ce:	ec e6       	ldi	r30, 0x6C	; 108
 5d0:	f6 e0       	ldi	r31, 0x06	; 6
 5d2:	0c 94 f9 02 	jmp	0x5f2	; 0x5f2 <__fp_powsodd>

000005d6 <__fp_mpack>:
 5d6:	9f 3f       	cpi	r25, 0xFF	; 255
 5d8:	31 f0       	breq	.+12     	; 0x5e6 <.L1^B1>

000005da <__fp_mpack_finite>:
 5da:	91 50       	subi	r25, 0x01	; 1
 5dc:	20 f4       	brcc	.+8      	; 0x5e6 <.L1^B1>
 5de:	87 95       	ror	r24
 5e0:	77 95       	ror	r23
 5e2:	67 95       	ror	r22
 5e4:	b7 95       	ror	r27

000005e6 <.L1^B1>:
 5e6:	88 0f       	add	r24, r24
 5e8:	91 1d       	adc	r25, r1
 5ea:	96 95       	lsr	r25
 5ec:	87 95       	ror	r24
 5ee:	97 f9       	bld	r25, 7
 5f0:	08 95       	ret

000005f2 <__fp_powsodd>:
 5f2:	9f 93       	push	r25
 5f4:	8f 93       	push	r24
 5f6:	7f 93       	push	r23
 5f8:	6f 93       	push	r22
 5fa:	ff 93       	push	r31
 5fc:	ef 93       	push	r30
 5fe:	9b 01       	movw	r18, r22
 600:	ac 01       	movw	r20, r24
 602:	0e 94 37 02 	call	0x46e	; 0x46e <__mulsf3>
 606:	ef 91       	pop	r30
 608:	ff 91       	pop	r31
 60a:	0e 94 0d 03 	call	0x61a	; 0x61a <__fp_powser>
 60e:	2f 91       	pop	r18
 610:	3f 91       	pop	r19
 612:	4f 91       	pop	r20
 614:	5f 91       	pop	r21
 616:	0c 94 37 02 	jmp	0x46e	; 0x46e <__mulsf3>

0000061a <__fp_powser>:
 61a:	df 93       	push	r29
 61c:	cf 93       	push	r28
 61e:	1f 93       	push	r17
 620:	0f 93       	push	r16
 622:	ff 92       	push	r15
 624:	ef 92       	push	r14
 626:	df 92       	push	r13
 628:	7b 01       	movw	r14, r22
 62a:	8c 01       	movw	r16, r24
 62c:	68 94       	set
 62e:	06 c0       	rjmp	.+12     	; 0x63c <.Load5>

00000630 <.L1^B1>:
 630:	da 2e       	mov	r13, r26

00000632 <.Loop>:
 632:	ef 01       	movw	r28, r30
 634:	0e 94 4a 02 	call	0x494	; 0x494 <__mulsf3x>
 638:	fe 01       	movw	r30, r28
 63a:	e8 94       	clt

0000063c <.Load5>:
 63c:	a5 91       	lpm	r26, Z+
 63e:	25 91       	lpm	r18, Z+
 640:	35 91       	lpm	r19, Z+
 642:	45 91       	lpm	r20, Z+
 644:	55 91       	lpm	r21, Z+
 646:	a6 f3       	brts	.-24     	; 0x630 <.L1^B1>
 648:	ef 01       	movw	r28, r30
 64a:	0e 94 f5 00 	call	0x1ea	; 0x1ea <__addsf3x>
 64e:	fe 01       	movw	r30, r28
 650:	97 01       	movw	r18, r14
 652:	a8 01       	movw	r20, r16
 654:	da 94       	dec	r13
 656:	69 f7       	brne	.-38     	; 0x632 <.Loop>
 658:	df 90       	pop	r13
 65a:	ef 90       	pop	r14
 65c:	ff 90       	pop	r15
 65e:	0f 91       	pop	r16
 660:	1f 91       	pop	r17
 662:	cf 91       	pop	r28
 664:	df 91       	pop	r29
 666:	08 95       	ret

00000668 <_exit>:
 668:	f8 94       	cli

0000066a <__stop_program>:
 66a:	ff cf       	rjmp	.-2      	; 0x66a <__stop_program>

0000066c <L0^A>:
 66c:	05 a8       	ldd	r0, Z+53	; 0x35
 66e:	4c cd       	rjmp	.-1384   	; 0x108 <.Lname44>
 670:	b2 d4       	rcall	.+2404   	; 0xfd6 <__stack+0x6d7>
 672:	4e b9       	out	0x0e, r20	; 14
 674:	38 36       	cpi	r19, 0x68	; 104
 676:	a9 02       	muls	r26, r25
 678:	0c 50       	subi	r16, 0x0C	; 12
 67a:	b9 91       	ld	r27, Y+
 67c:	86 88       	ldd	r8, Z+22	; 0x16
 67e:	08 3c       	cpi	r16, 0xC8	; 200
 680:	a6 aa       	std	Z+54, r10	; 0x36
 682:	aa 2a       	or	r10, r26
 684:	be 00       	.word	0x00be	; ????
 686:	00 00       	nop
 688:	80 3f       	cpi	r24, 0xF0	; 240
