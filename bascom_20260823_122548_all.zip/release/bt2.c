/* OPTIMIZE_C -- bt2.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static breal_t b_a_kxf[11];
static breal_t b_a_kyf[11];
static breal_t b_a_kzf[11];
static int b_a_kri[11];
static breal_t b_a_oxf[11];
static breal_t b_a_ozf[11];
static int b_v_aki;
static breal_t b_v_caf;
static int b_v_bxi;
static int b_v_byi;
static int b_v_bzi;
static int b_v_bei;
static bint_t b_v_lxi;
static bint_t b_v_lyi;
static bint_t b_v_lzi;
static int b_v_gbi;
static breal_t b_v_frf;
static breal_t b_v_ccf;
static breal_t b_v_ssf;
static int b_v_ii;
static bint_t b_v_cfi;
static bint_t b_v_pbi;
static breal_t b_v_zwf;
static breal_t b_v_yf;
static breal_t b_v_zxf;
static breal_t b_v_pwf;
static int b_v_pxi;
static breal_t b_v_xf;
static breal_t b_v_rxf;
static breal_t b_v_ryf;
static breal_t b_v_rzf;
static breal_t b_v_oxf;
static breal_t b_v_oyf;
static breal_t b_v_ozf;
static int b_v_rdi;
static breal_t b_v_tf;
static breal_t b_v_laf;
static breal_t b_v_sxf;
static int b_v_syi;
static breal_t b_v_szf;
static breal_t b_v_faf;
static breal_t b_v_kf;
static breal_t b_v_x1f;
static breal_t b_v_x2f;
static breal_t b_v_x3f;
static breal_t b_v_f1f;
static breal_t b_v_f2f;
static breal_t b_v_f3f;
static breal_t b_v_df;
static breal_t b_v_nxf;
static breal_t b_v_nyf;
static breal_t b_v_nzf;
static bstr_t b_v_as;
static breal_t b_v_pf;
static breal_t b_v_qf;
static breal_t b_v_z1f;
static breal_t b_v_z2f;
static breal_t b_v_wuf;
static breal_t b_v_z0f;
static bint_t b_t_0;
static bint_t b_t_1;
static int b_fl_0;
static int b_fl_4;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 100 */
b_L100: ;
		/* line 200 */
b_L200: ;
		/* line 201 */
b_L201: ;
		b_v_aki=(2);
		b_v_caf=(0);
		/* line 202 */
b_L202: ;
		b_a_oxf[B_INT((0))]=(3);
		/* line 203 */
b_L203: ;
		b_a_kyf[B_INT((0))]=(9);
		/* line 204 */
b_L204: ;
		b_a_ozf[B_INT((0))]=(50);
		/* line 205 */
b_L205: ;
		b_a_kri[B_INT((0))]=(9);
		/* line 206 */
b_L206: ;
		b_a_oxf[B_INT((1))]=(-12);
		/* line 207 */
b_L207: ;
		b_a_kyf[B_INT((1))]=(7);
		/* line 208 */
b_L208: ;
		b_a_ozf[B_INT((1))]=(80);
		/* line 209 */
b_L209: ;
		b_a_kri[B_INT((1))]=(7);
		/* line 210 */
b_L210: ;
		b_a_oxf[B_INT((2))]=(-3);
		/* line 211 */
b_L211: ;
		b_a_kyf[B_INT((2))]=(3);
		/* line 212 */
b_L212: ;
		b_a_ozf[B_INT((2))]=(35);
		/* line 213 */
b_L213: ;
		b_a_kri[B_INT((2))]=(3);
		/* line 214 */
b_L214: ;
		b_v_bxi=(0);
		/* line 215 */
b_L215: ;
		b_v_byi=(5);
		/* line 216 */
b_L216: ;
		b_v_bzi=(-17);
		/* line 217 */
b_L217: ;
		b_v_bei=(25);
		/* line 218 */
b_L218: ;
		b_v_lxi=(-50);
		/* line 219 */
b_L219: ;
		b_v_lyi=(300);
		/* line 220 */
b_L220: ;
		b_v_lzi=(50);
		/* line 221 */
b_L221: ;
		b_v_gbi=(10);
		/* line 222 */
b_L222: ;
		b_poke((53272.0),(11));
		/* line 223 */
b_L223: ;
		b_poke((53265.0),(59));
		/* line 224 */
b_L224: ;
		b_poke((56576.0),(148));
		/* line 250 */
b_L250: ;
		b_v_frf=(0);
		/* line 260 */
b_L260: ;
		/* line 261 */
b_L261: ;
		b_a_oxf[B_INT((0))]=(((3))+((((15))*(b_sin(((b_v_frf)*((0.10000000000582077))))))));
		/* line 262 */
b_L262: ;
		b_a_ozf[B_INT((0))]=(((50))+((((15))*(((b_cos(((b_v_frf)*((0.10000000000582077)))))-((1)))))));
		/* line 263 */
b_L263: ;
		b_a_kyf[B_INT((0))]=(((9))+((((3))*(b_sin(((b_v_frf)*((0.20000000001164153))))))));
		/* line 264 */
b_L264: ;
		b_v_ccf=b_cos(b_v_caf);
		b_v_ssf=b_sin(b_v_caf);
		/* line 265 */
b_L265: ;
		b_v_ii=(0);
		b_fl_0=b_v_aki;
		if(b_v_ii > b_fl_0) goto b_f0_e;
b_f0_t: ;
		b_a_kxf[B_INT(b_v_ii)]=((((b_a_oxf[B_INT(b_v_ii)])*(b_v_ccf)))-(((((b_a_ozf[B_INT(b_v_ii)])-((50))))*(b_v_ssf))));
		b_a_kzf[B_INT(b_v_ii)]=(((((50))+(((b_a_oxf[B_INT(b_v_ii)])*(b_v_ssf)))))+(((((b_a_ozf[B_INT(b_v_ii)])-((50))))*(b_v_ccf))));
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 266 */
b_L266: ;
		if(-((b_v_cfi) == ((0)))){ goto b_L300; }
		/* line 267 */
b_L267: ;
		goto b_L304;
		/* line 300 */
b_L300: ;
		b_v_ii=(1024);
		if(b_v_ii > 2023) goto b_f1_e;
		b_t_0=(((48128.0))+(b_v_ii));
		b_t_1=(((54272.0))+(b_v_ii));
b_f1_t: ;
		/* line 301 */
b_L301: ;
		b_poke(b_t_0,(15));
		/* line 302 */
b_L302: ;
		b_poke(b_t_1,(0));
		/* line 303 */
b_L303: ;
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 2023) goto b_f1_t;
b_f1_e: ;
		b_v_cfi=(1);
		/* line 304 */
b_L304: ;
		b_v_pbi=(0);
		if(b_v_pbi > 8000) goto b_f2_e;
b_f2_t: ;
		/* line 306 */
b_L306: ;
		b_v_zwf=(B_INT(b_v_pbi) & B_INT((7)));
		/* line 307 */
b_L307: ;
		b_v_yf=((((b_int(((breal_t)(b_v_pbi)/(breal_t)((320)))))*((8))))+(b_v_zwf));
		/* line 308 */
b_L308: ;
		b_v_zwf=b_int(((breal_t)(b_v_pbi)/(breal_t)((8))));
		/* line 309 */
b_L309: ;
		b_v_zxf=((((b_v_zwf)-(((b_int((b_v_zwf/(breal_t)((40)))))*((40))))))*((8)));
		/* line 310 */
b_L310: ;
		b_v_pwf=(0);
		/* line 400 */
b_L400: ;
		b_v_pxi=(0);
		if(b_v_pxi > 7) goto b_f3_e;
b_f3_t: ;
		/* line 401 */
b_L401: ;
		b_v_xf=((b_v_zxf)+(b_v_pxi));
		/* line 402 */
b_L402: ;
		b_v_zwf=((breal_t)(b_v_gbi)/(breal_t)((320)));
		/* line 403 */
b_L403: ;
		b_v_rxf=((((b_v_xf)*(b_v_zwf)))-(((breal_t)(b_v_gbi)/(breal_t)((2)))));
		/* line 404 */
b_L404: ;
		b_v_ryf=(((((-(b_v_yf)))*(b_v_zwf)))+(((((breal_t)((200))/(breal_t)((2))))*(b_v_zwf))));
		/* line 405 */
b_L405: ;
		b_v_rzf=b_v_bei;
		/* line 406 */
b_L406: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 407 */
b_L407: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 408 */
b_L408: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 409 */
b_L409: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 410 */
b_L410: ;
		b_v_oxf=b_v_bxi;
		/* line 411 */
b_L411: ;
		b_v_oyf=b_v_byi;
		/* line 412 */
b_L412: ;
		b_v_ozf=b_v_bzi;
		/* line 413 */
b_L413: ;
		b_v_rdi=(0);
		/* line 500 */
b_L500: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1000;
b_ret0: ;
		/* line 501 */
b_L501: ;
		switch((-(-((((b_v_oyf)+(((b_v_tf)*(b_v_ryf))))) > ((0)))))){
			case 1: goto b_L600; break;
			default: break;}
		/* line 502 */
b_L502: ;
		b_v_laf=((-(b_v_oyf))/b_v_ryf);
		/* line 503 */
b_L503: ;
		b_v_sxf=((b_v_oxf)+(((b_v_laf)*(b_v_rxf))));
		/* line 504 */
b_L504: ;
		b_v_syi=(0);
		/* line 505 */
b_L505: ;
		b_v_szf=((b_v_ozf)+(((b_v_laf)*(b_v_rzf))));
		/* line 506 */
b_L506: ;
		b_v_zwf=(((B_INT(b_int((b_v_sxf/(breal_t)((5))))) & B_INT((1))))+((B_INT(b_int((b_v_szf/(breal_t)((5))))) & B_INT((1)))));
		/* line 507 */
b_L507: ;
		b_v_faf=((-((b_v_zwf) == ((1))))+((1)));
		/* line 508 */
b_L508: ;
		b_v_oxf=b_v_sxf;
		/* line 509 */
b_L509: ;
		b_v_oyf=b_v_syi;
		/* line 510 */
b_L510: ;
		b_v_ozf=b_v_szf;
		/* line 511 */
b_L511: ;
		b_v_rxf=((b_v_oxf)+(b_v_lxi));
		/* line 512 */
b_L512: ;
		b_v_ryf=((b_v_oyf)+(b_v_lyi));
		/* line 513 */
b_L513: ;
		b_v_rzf=((b_v_ozf)+(b_v_lzi));
		/* line 514 */
b_L514: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L1000;
b_ret1: ;
		/* line 515 */
b_L515: ;
		switch((-(-((b_v_kf) == ((-1)))))){
			case 1: goto b_L900; break;
			default: break;}
		/* line 516 */
b_L516: ;
		b_v_faf=((-((((bint_t)(b_v_xf) & B_INT((1)))) != (((bint_t)(b_v_yf) & B_INT((1))))))+((1)));
		/* line 517 */
b_L517: ;
		goto b_L900;
		/* line 600 */
b_L600: ;
		if(-((b_v_kf) == ((-1)))){
			b_v_faf=(0);
			goto b_L900;
		}
		/* line 700 */
b_L700: ;
		b_v_x1f=((((((b_a_kxf[(bint_t)(b_v_kf)])*(b_v_rxf)))+(((b_a_kyf[(bint_t)(b_v_kf)])*(b_v_ryf)))))+(((b_a_kzf[(bint_t)(b_v_kf)])*(b_v_rzf))));
		/* line 701 */
b_L701: ;
		b_v_x2f=((((((b_v_oxf)*(b_v_rxf)))+(((b_v_oyf)*(b_v_ryf)))))+(((b_v_ozf)*(b_v_rzf))));
		/* line 702 */
b_L702: ;
		b_v_x3f=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 703 */
b_L703: ;
		b_v_laf=(((b_v_x1f)-(b_v_x2f))/b_v_x3f);
		/* line 704 */
b_L704: ;
		b_v_f1f=((((b_v_oxf)+(((b_v_laf)*(b_v_rxf)))))-(b_a_kxf[(bint_t)(b_v_kf)]));
		/* line 705 */
b_L705: ;
		b_v_f2f=((((b_v_oyf)+(((b_v_laf)*(b_v_ryf)))))-(b_a_kyf[(bint_t)(b_v_kf)]));
		/* line 706 */
b_L706: ;
		b_v_f3f=((((b_v_ozf)+(((b_v_laf)*(b_v_rzf)))))-(b_a_kzf[(bint_t)(b_v_kf)]));
		/* line 707 */
b_L707: ;
		b_v_df=b_sqr(((((((b_v_f1f)*(b_v_f1f)))+(((b_v_f2f)*(b_v_f2f)))))+(((b_v_f3f)*(b_v_f3f)))));
		/* line 708 */
b_L708: ;
		if(-((((b_a_kri[(bint_t)(b_v_kf)])*((0.94999999995343387)))) < (b_v_df))){
			b_v_faf=(1);
			goto b_L900;
		}
		/* line 710 */
b_L710: ;
		b_v_rdi=((b_v_rdi)+((1)));
		if(-((b_v_rdi) > ((8)))){
			b_v_faf=(1);
			goto b_L900;
		}
		/* line 800 */
b_L800: ;
		b_v_oxf=((b_v_oxf)+(((b_v_tf)*(b_v_rxf))));
		/* line 801 */
b_L801: ;
		b_v_oyf=((b_v_oyf)+(((b_v_tf)*(b_v_ryf))));
		/* line 802 */
b_L802: ;
		b_v_ozf=((b_v_ozf)+(((b_v_tf)*(b_v_rzf))));
		/* line 803 */
b_L803: ;
		b_v_nxf=((b_a_kxf[(bint_t)(b_v_kf)])-(b_v_oxf));
		/* line 804 */
b_L804: ;
		b_v_nyf=((b_a_kyf[(bint_t)(b_v_kf)])-(b_v_oyf));
		/* line 805 */
b_L805: ;
		b_v_nzf=((b_a_kzf[(bint_t)(b_v_kf)])-(b_v_ozf));
		/* line 806 */
b_L806: ;
		b_v_zwf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 807 */
b_L807: ;
		b_v_rxf=((b_v_rxf)-((((((2))*(b_v_zwf)))*(b_v_nxf))));
		/* line 808 */
b_L808: ;
		b_v_ryf=((b_v_ryf)-((((((2))*(b_v_zwf)))*(b_v_nyf))));
		/* line 809 */
b_L809: ;
		b_v_rzf=((b_v_rzf)-((((((2))*(b_v_zwf)))*(b_v_nzf))));
		/* line 810 */
b_L810: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 811 */
b_L811: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 812 */
b_L812: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 813 */
b_L813: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 814 */
b_L814: ;
		goto b_L500;
		/* line 900 */
b_L900: ;
		b_v_pwf=((((b_v_pwf)*((2))))+(b_v_faf));
		/* line 901 */
b_L901: ;
		b_v_pxi += 1;
		if(b_v_pxi <= 7) goto b_f3_t;
b_f3_e: ;
		/* line 902 */
b_L902: ;
		b_poke((((57344.0))+(b_v_pbi)),b_v_pwf);
		/* line 903 */
b_L903: ;
		b_v_pbi += 1;
		if(b_v_pbi <= 8000) goto b_f2_t;
b_f2_e: ;
		/* line 904 */
b_L904: ;
		b_v_frf=((b_v_frf)+((1)));
		/* line 905 */
b_L905: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		/* line 906 */
b_L906: ;
		if(-(b_strcmp(b_v_as,b_lit("\035",1)) == 0)){
			b_v_caf=((b_v_caf)+((0.10000000000582077)));
			goto b_L260;
		}
		/* line 907 */
b_L907: ;
		if(-(b_strcmp(b_v_as,b_lit("\235",1)) == 0)){
			b_v_caf=((b_v_caf)-((0.10000000000582077)));
			goto b_L260;
		}
		/* line 908 */
b_L908: ;
		if(-(b_strcmp(b_v_as,b_lit("\221",1)) == 0)){
			b_v_byi=((b_v_byi)+((1)));
			goto b_L260;
		}
		/* line 909 */
b_L909: ;
		if(-(b_strcmp(b_v_as,b_lit("\021",1)) == 0)){
			b_v_byi=((b_v_byi)-((1)));
			goto b_L260;
		}
		/* line 910 */
b_L910: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)))){
			b_v_bzi=((b_v_bzi)+((1)));
			goto b_L260;
		}
		/* line 911 */
b_L911: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)))){
			b_v_bzi=((b_v_bzi)-((1)));
			goto b_L260;
		}
		/* line 912 */
b_L912: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)))){
			b_v_bxi=((b_v_bxi)-((1)));
			goto b_L260;
		}
		/* line 913 */
b_L913: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)))){
			b_v_bxi=((b_v_bxi)+((1)));
			goto b_L260;
		}
		/* line 914 */
b_L914: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("X",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("X",1)) == 0)))){ goto b_L920; }
		/* line 915 */
b_L915: ;
		goto b_L260;
		/* line 920 */
b_L920: ;
		goto b_end;
		/* line 1000 */
b_L1000: ;
		b_v_kf=(-1);
		/* line 1001 */
b_L1001: ;
		b_v_tf=(99999.0);
		/* line 1002 */
b_L1002: ;
		b_v_ii=(0);
		b_fl_4=b_v_aki;
		if(b_v_ii > b_fl_4) goto b_f4_e;
b_f4_t: ;
		/* line 1003 */
b_L1003: ;
		b_v_zwf=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 1004 */
b_L1004: ;
		b_v_pf=((((2))*(((((((b_v_rxf)*(((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))))+(((b_v_ryf)*(((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))))))+(((b_v_rzf)*(((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)]))))))))/b_v_zwf);
		/* line 1005 */
b_L1005: ;
		b_v_qf=(((((((((((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))*(((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))))+(((((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))*(((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))))))+(((((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)])))*(((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)])))))))-(((b_a_kri[B_INT(b_v_ii)])*(b_a_kri[B_INT(b_v_ii)]))))/b_v_zwf);
		/* line 1006 */
b_L1006: ;
		b_v_z1f=((-(b_v_pf))/(breal_t)((2)));
		/* line 1007 */
b_L1007: ;
		b_v_z2f=(((((b_v_pf)*(b_v_pf))/(breal_t)((4))))-(b_v_qf));
		/* line 1008 */
b_L1008: ;
		if(-((b_v_z2f) < ((0)))){
			b_v_ii += 1;
			if(b_v_ii <= (b_fl_4)) goto b_f4_t;
			goto b_return;
		}
		/* line 1100 */
b_L1100: ;
		b_v_wuf=b_sqr(b_v_z2f);
		/* line 1101 */
b_L1101: ;
		b_v_x1f=((b_v_z1f)+(b_v_wuf));
		/* line 1102 */
b_L1102: ;
		b_v_x2f=((b_v_z1f)-(b_v_wuf));
		/* line 1103 */
b_L1103: ;
		b_v_z0f=(-((B_INT(-((b_v_x1f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x1f) < (b_v_tf))))));
		/* line 1104 */
b_L1104: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 1105 */
b_L1105: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 1106 */
b_L1106: ;
		b_v_tf=((((b_v_z0f)*(b_v_x1f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 1107 */
b_L1107: ;
		b_v_z0f=(-((B_INT(-((b_v_x2f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x2f) < (b_v_tf))))));
		/* line 1108 */
b_L1108: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 1109 */
b_L1109: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 1110 */
b_L1110: ;
		b_v_tf=((((b_v_z0f)*(b_v_x2f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 1111 */
b_L1111: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 1112 */
b_L1112: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
