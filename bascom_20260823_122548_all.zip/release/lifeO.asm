; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e fe 21 STX $21fe ; (spentry + 0)
0811 : a2 22 __ LDX #$22
0813 : a0 90 __ LDY #$90
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 22 __ CPX #$22
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 fa __ CPY #$fa
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 62 __ LDA #$62
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  50, "C:/Users/g/claude/cpus/6502/examples/compiler/release/life.c"
.s1:
0880 : a2 0f __ LDX #$0f
0882 : b5 53 __ LDA T0 + 0,x 
0884 : 9d 64 9f STA $9f64,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 32 13 JSR $1332 ; (b_init.s4 + 0)
088d : 20 03 14 JSR $1403 ; (tsb_init.s4 + 0)
0890 : a9 93 __ LDA #$93
0892 : 85 13 __ STA P6 
0894 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
0897 : a9 0d __ LDA #$0d
0899 : 85 13 __ STA P6 
089b : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
089e : a9 00 __ LDA #$00
08a0 : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
08a3 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
.l5:
08a6 : a9 00 __ LDA #$00
08a8 : 8d da 22 STA $22da ; (b_v_ci + 0)
08ab : 8d db 22 STA $22db ; (b_v_ci + 1)
08ae : ad d8 22 LDA $22d8 ; (b_v_ri + 0)
08b1 : 85 57 __ STA T2 + 0 
08b3 : 0a __ __ ASL
08b4 : 85 1b __ STA ACCU + 0 
08b6 : ad d9 22 LDA $22d9 ; (b_v_ri + 1)
08b9 : 85 58 __ STA T2 + 1 
08bb : 2a __ __ ROL
08bc : 06 1b __ ASL ACCU + 0 
08be : 2a __ __ ROL
08bf : aa __ __ TAX
08c0 : 18 __ __ CLC
08c1 : a5 1b __ LDA ACCU + 0 
08c3 : 65 57 __ ADC T2 + 0 
08c5 : 85 53 __ STA T0 + 0 
08c7 : 8a __ __ TXA
08c8 : 65 58 __ ADC T2 + 1 
08ca : 06 53 __ ASL T0 + 0 
08cc : 2a __ __ ROL
08cd : 06 53 __ ASL T0 + 0 
08cf : 2a __ __ ROL
08d0 : 06 53 __ ASL T0 + 0 
08d2 : 2a __ __ ROL
08d3 : aa __ __ TAX
08d4 : a5 53 __ LDA T0 + 0 
08d6 : 8d e0 22 STA $22e0 ; (b_t_1 + 0)
08d9 : 18 __ __ CLC
08da : 69 59 __ ADC #$59
08dc : 8d dc 22 STA $22dc ; (b_t_0 + 0)
08df : 8a __ __ TXA
08e0 : 69 04 __ ADC #$04
08e2 : 8d dd 22 STA $22dd ; (b_t_0 + 1)
08e5 : 8a __ __ TXA
08e6 : 18 __ __ CLC
08e7 : 69 60 __ ADC #$60
08e9 : 8d e1 22 STA $22e1 ; (b_t_1 + 1)
08ec : ad dd 22 LDA $22dd ; (b_t_0 + 1)
08ef : 29 80 __ AND #$80
08f1 : 10 02 __ BPL $08f5 ; (main.l5 + 79)
08f3 : a9 ff __ LDA #$ff
08f5 : 8d de 22 STA $22de ; (b_t_0 + 2)
08f8 : 8d df 22 STA $22df ; (b_t_0 + 3)
08fb : ad e1 22 LDA $22e1 ; (b_t_1 + 1)
08fe : 29 80 __ AND #$80
0900 : 10 02 __ BPL $0904 ; (main.l5 + 94)
0902 : a9 ff __ LDA #$ff
0904 : 8d e2 22 STA $22e2 ; (b_t_1 + 2)
0907 : 8d e3 22 STA $22e3 ; (b_t_1 + 3)
.l6:
090a : ad dc 22 LDA $22dc ; (b_t_0 + 0)
090d : 85 53 __ STA T0 + 0 
090f : ad de 22 LDA $22de ; (b_t_0 + 2)
0912 : 85 55 __ STA T0 + 2 
0914 : ad df 22 LDA $22df ; (b_t_0 + 3)
0917 : 85 56 __ STA T0 + 3 
0919 : ad dd 22 LDA $22dd ; (b_t_0 + 1)
091c : 85 54 __ STA T0 + 1 
091e : c9 e0 __ CMP #$e0
0920 : 90 37 __ BCC $0959 ; (main.s7 + 0)
.s150:
0922 : c9 ff __ CMP #$ff
0924 : d0 04 __ BNE $092a ; (main.s154 + 0)
.s153:
0926 : a5 53 __ LDA T0 + 0 
0928 : c9 40 __ CMP #$40
.s154:
092a : b0 2d __ BCS $0959 ; (main.s7 + 0)
.s151:
092c : ad 04 22 LDA $2204 ; (b_mem + 0)
092f : 85 51 __ STA T1 + 0 
0931 : ad 05 22 LDA $2205 ; (b_mem + 1)
0934 : 85 52 __ STA T1 + 1 
0936 : a0 01 __ LDY #$01
0938 : b1 51 __ LDA (T1 + 0),y 
093a : aa __ __ TAX
093b : 4a __ __ LSR
093c : 90 1b __ BCC $0959 ; (main.s7 + 0)
.s152:
093e : 8a __ __ TXA
093f : 29 fe __ AND #$fe
0941 : 91 51 __ STA (T1 + 0),y 
0943 : a5 53 __ LDA T0 + 0 
0945 : 85 5b __ STA T3 + 0 
0947 : 18 __ __ CLC
0948 : a5 52 __ LDA T1 + 1 
094a : 65 54 __ ADC T0 + 1 
094c : 85 5c __ STA T3 + 1 
094e : a9 20 __ LDA #$20
0950 : a4 51 __ LDY T1 + 0 
0952 : 91 5b __ STA (T3 + 0),y 
0954 : 8a __ __ TXA
0955 : a0 01 __ LDY #$01
0957 : d0 13 __ BNE $096c ; (main.s8 + 0)
.s7:
0959 : ad 04 22 LDA $2204 ; (b_mem + 0)
095c : 18 __ __ CLC
095d : 65 53 __ ADC T0 + 0 
095f : 85 51 __ STA T1 + 0 
0961 : ad 05 22 LDA $2205 ; (b_mem + 1)
0964 : 65 54 __ ADC T0 + 1 
0966 : 85 52 __ STA T1 + 1 
0968 : a9 20 __ LDA #$20
096a : a0 00 __ LDY #$00
.s8:
096c : 91 51 __ STA (T1 + 0),y 
096e : 18 __ __ CLC
096f : a5 53 __ LDA T0 + 0 
0971 : 69 01 __ ADC #$01
0973 : 8d dc 22 STA $22dc ; (b_t_0 + 0)
0976 : a5 54 __ LDA T0 + 1 
0978 : 69 00 __ ADC #$00
097a : 8d dd 22 STA $22dd ; (b_t_0 + 1)
097d : a5 55 __ LDA T0 + 2 
097f : 69 00 __ ADC #$00
0981 : 8d de 22 STA $22de ; (b_t_0 + 2)
0984 : a5 56 __ LDA T0 + 3 
0986 : 69 00 __ ADC #$00
0988 : 8d df 22 STA $22df ; (b_t_0 + 3)
098b : ad e0 22 LDA $22e0 ; (b_t_1 + 0)
098e : 85 53 __ STA T0 + 0 
0990 : 18 __ __ CLC
0991 : 69 01 __ ADC #$01
0993 : 8d e0 22 STA $22e0 ; (b_t_1 + 0)
0996 : ad e1 22 LDA $22e1 ; (b_t_1 + 1)
0999 : 85 54 __ STA T0 + 1 
099b : 69 00 __ ADC #$00
099d : 8d e1 22 STA $22e1 ; (b_t_1 + 1)
09a0 : 90 08 __ BCC $09aa ; (main.s159 + 0)
.s160:
09a2 : ee e2 22 INC $22e2 ; (b_t_1 + 2)
09a5 : d0 03 __ BNE $09aa ; (main.s159 + 0)
.s158:
09a7 : ee e3 22 INC $22e3 ; (b_t_1 + 3)
.s159:
09aa : ad da 22 LDA $22da ; (b_v_ci + 0)
09ad : 85 51 __ STA T1 + 0 
09af : 18 __ __ CLC
09b0 : 69 01 __ ADC #$01
09b2 : 8d da 22 STA $22da ; (b_v_ci + 0)
09b5 : ad db 22 LDA $22db ; (b_v_ci + 1)
09b8 : aa __ __ TAX
09b9 : 69 00 __ ADC #$00
09bb : 8d db 22 STA $22db ; (b_v_ci + 1)
09be : a5 54 __ LDA T0 + 1 
09c0 : c9 e0 __ CMP #$e0
09c2 : 90 36 __ BCC $09fa ; (main.s9 + 0)
.s145:
09c4 : c9 ff __ CMP #$ff
09c6 : d0 04 __ BNE $09cc ; (main.s149 + 0)
.s148:
09c8 : a5 53 __ LDA T0 + 0 
09ca : c9 40 __ CMP #$40
.s149:
09cc : b0 2c __ BCS $09fa ; (main.s9 + 0)
.s146:
09ce : ad 04 22 LDA $2204 ; (b_mem + 0)
09d1 : 85 5b __ STA T3 + 0 
09d3 : ad 05 22 LDA $2205 ; (b_mem + 1)
09d6 : 85 5c __ STA T3 + 1 
09d8 : a0 01 __ LDY #$01
09da : b1 5b __ LDA (T3 + 0),y 
09dc : 85 45 __ STA T6 + 0 
09de : 4a __ __ LSR
09df : 90 19 __ BCC $09fa ; (main.s9 + 0)
.s147:
09e1 : a5 45 __ LDA T6 + 0 
09e3 : 29 fe __ AND #$fe
09e5 : 91 5b __ STA (T3 + 0),y 
09e7 : 18 __ __ CLC
09e8 : a5 5c __ LDA T3 + 1 
09ea : 65 54 __ ADC T0 + 1 
09ec : 85 54 __ STA T0 + 1 
09ee : a9 20 __ LDA #$20
09f0 : a4 5b __ LDY T3 + 0 
09f2 : 91 53 __ STA (T0 + 0),y 
09f4 : a5 45 __ LDA T6 + 0 
09f6 : a0 01 __ LDY #$01
09f8 : d0 13 __ BNE $0a0d ; (main.s10 + 0)
.s9:
09fa : ad 04 22 LDA $2204 ; (b_mem + 0)
09fd : 18 __ __ CLC
09fe : 65 53 __ ADC T0 + 0 
0a00 : 85 5b __ STA T3 + 0 
0a02 : ad 05 22 LDA $2205 ; (b_mem + 1)
0a05 : 65 54 __ ADC T0 + 1 
0a07 : 85 5c __ STA T3 + 1 
0a09 : a9 20 __ LDA #$20
0a0b : a0 00 __ LDY #$00
.s10:
0a0d : 91 5b __ STA (T3 + 0),y 
0a0f : 8a __ __ TXA
0a10 : 10 03 __ BPL $0a15 ; (main.s144 + 0)
0a12 : 4c 0a 09 JMP $090a ; (main.l6 + 0)
.s144:
0a15 : d0 06 __ BNE $0a1d ; (main.s11 + 0)
.s143:
0a17 : a9 14 __ LDA #$14
0a19 : c5 51 __ CMP T1 + 0 
0a1b : b0 f5 __ BCS $0a12 ; (main.s10 + 5)
.s11:
0a1d : 18 __ __ CLC
0a1e : a5 57 __ LDA T2 + 0 
0a20 : 69 01 __ ADC #$01
0a22 : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
0a25 : a5 58 __ LDA T2 + 1 
0a27 : 69 00 __ ADC #$00
0a29 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
0a2c : a5 58 __ LDA T2 + 1 
0a2e : 10 03 __ BPL $0a33 ; (main.s142 + 0)
0a30 : 4c a6 08 JMP $08a6 ; (main.l5 + 0)
.s142:
0a33 : d0 06 __ BNE $0a3b ; (main.s12 + 0)
.s141:
0a35 : a9 14 __ LDA #$14
0a37 : c5 57 __ CMP T2 + 0 
0a39 : b0 f5 __ BCS $0a30 ; (main.s11 + 19)
.s12:
0a3b : a9 01 __ LDA #$01
0a3d : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
0a40 : a9 00 __ LDA #$00
0a42 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
0a45 : a9 d7 __ LDA #$d7
0a47 : 8d 8c 22 STA $228c ; (b_rndSeed + 0)
0a4a : a9 8f __ LDA #$8f
0a4c : 8d 8d 22 STA $228d ; (b_rndSeed + 1)
0a4f : a9 7d __ LDA #$7d
0a51 : 8d 8e 22 STA $228e ; (b_rndSeed + 2)
0a54 : a9 66 __ LDA #$66
0a56 : 8d 8f 22 STA $228f ; (b_rndSeed + 3)
.l13:
0a59 : ad d8 22 LDA $22d8 ; (b_v_ri + 0)
0a5c : 85 51 __ STA T1 + 0 
0a5e : 0a __ __ ASL
0a5f : 85 1b __ STA ACCU + 0 
0a61 : a9 01 __ LDA #$01
0a63 : 8d da 22 STA $22da ; (b_v_ci + 0)
0a66 : ad d9 22 LDA $22d9 ; (b_v_ri + 1)
0a69 : 85 52 __ STA T1 + 1 
0a6b : 2a __ __ ROL
0a6c : 06 1b __ ASL ACCU + 0 
0a6e : 2a __ __ ROL
0a6f : aa __ __ TAX
0a70 : 18 __ __ CLC
0a71 : a5 1b __ LDA ACCU + 0 
0a73 : 65 51 __ ADC T1 + 0 
0a75 : 85 53 __ STA T0 + 0 
0a77 : 8a __ __ TXA
0a78 : 65 52 __ ADC T1 + 1 
0a7a : 06 53 __ ASL T0 + 0 
0a7c : 2a __ __ ROL
0a7d : 06 53 __ ASL T0 + 0 
0a7f : 2a __ __ ROL
0a80 : 06 53 __ ASL T0 + 0 
0a82 : 2a __ __ ROL
0a83 : a8 __ __ TAY
0a84 : 18 __ __ CLC
0a85 : a5 53 __ LDA T0 + 0 
0a87 : 69 59 __ ADC #$59
0a89 : aa __ __ TAX
0a8a : 98 __ __ TYA
0a8b : 69 04 __ ADC #$04
0a8d : a8 __ __ TAY
0a8e : 8a __ __ TXA
0a8f : 18 __ __ CLC
0a90 : 69 01 __ ADC #$01
0a92 : 8d e4 22 STA $22e4 ; (b_t_2 + 0)
0a95 : 98 __ __ TYA
0a96 : 69 00 __ ADC #$00
0a98 : 8d e5 22 STA $22e5 ; (b_t_2 + 1)
0a9b : 0a __ __ ASL
0a9c : a9 00 __ LDA #$00
0a9e : 8d db 22 STA $22db ; (b_v_ci + 1)
0aa1 : 69 ff __ ADC #$ff
0aa3 : 49 ff __ EOR #$ff
0aa5 : 8d e6 22 STA $22e6 ; (b_t_2 + 2)
0aa8 : 8d e7 22 STA $22e7 ; (b_t_2 + 3)
.l14:
0aab : ad 8c 22 LDA $228c ; (b_rndSeed + 0)
0aae : 85 1b __ STA ACCU + 0 
0ab0 : ad 8d 22 LDA $228d ; (b_rndSeed + 1)
0ab3 : 85 1c __ STA ACCU + 1 
0ab5 : ad 8e 22 LDA $228e ; (b_rndSeed + 2)
0ab8 : 85 1d __ STA ACCU + 2 
0aba : ad 8f 22 LDA $228f ; (b_rndSeed + 3)
0abd : 85 1e __ STA ACCU + 3 
0abf : a9 cd __ LDA #$cd
0ac1 : 85 03 __ STA WORK + 0 
0ac3 : a9 00 __ LDA #$00
0ac5 : 85 06 __ STA WORK + 3 
0ac7 : a9 0d __ LDA #$0d
0ac9 : 85 04 __ STA WORK + 1 
0acb : a9 01 __ LDA #$01
0acd : 85 05 __ STA WORK + 2 
0acf : 20 32 20 JSR $2032 ; (mul32 + 0)
0ad2 : 18 __ __ CLC
0ad3 : a5 07 __ LDA WORK + 4 
0ad5 : 69 39 __ ADC #$39
0ad7 : 8d 8c 22 STA $228c ; (b_rndSeed + 0)
0ada : a5 08 __ LDA WORK + 5 
0adc : 69 30 __ ADC #$30
0ade : 8d 8d 22 STA $228d ; (b_rndSeed + 1)
0ae1 : 85 1b __ STA ACCU + 0 
0ae3 : a5 09 __ LDA WORK + 6 
0ae5 : 69 00 __ ADC #$00
0ae7 : 8d 8e 22 STA $228e ; (b_rndSeed + 2)
0aea : 85 1c __ STA ACCU + 1 
0aec : a5 0a __ LDA WORK + 7 
0aee : 69 00 __ ADC #$00
0af0 : 8d 8f 22 STA $228f ; (b_rndSeed + 3)
0af3 : 85 1d __ STA ACCU + 2 
0af5 : ad da 22 LDA $22da ; (b_v_ci + 0)
0af8 : 85 57 __ STA T2 + 0 
0afa : 18 __ __ CLC
0afb : 69 01 __ ADC #$01
0afd : 8d da 22 STA $22da ; (b_v_ci + 0)
0b00 : ad db 22 LDA $22db ; (b_v_ci + 1)
0b03 : 85 58 __ STA T2 + 1 
0b05 : 69 00 __ ADC #$00
0b07 : 8d db 22 STA $22db ; (b_v_ci + 1)
0b0a : a9 00 __ LDA #$00
0b0c : 85 1e __ STA ACCU + 3 
0b0e : 20 ee 1f JSR $1fee ; (uint32_to_float + 0)
0b11 : a9 00 __ LDA #$00
0b13 : 85 03 __ STA WORK + 0 
0b15 : 85 04 __ STA WORK + 1 
0b17 : a9 80 __ LDA #$80
0b19 : 85 05 __ STA WORK + 2 
0b1b : a9 4b __ LDA #$4b
0b1d : 85 06 __ STA WORK + 3 
0b1f : 20 e5 1b JSR $1be5 ; (freg + 20)
0b22 : 20 cb 1d JSR $1dcb ; (crt_fdiv + 0)
0b25 : a5 1e __ LDA ACCU + 3 
0b27 : 10 04 __ BPL $0b2d ; (main.s18 + 0)
.s15:
0b29 : a9 01 __ LDA #$01
0b2b : d0 1f __ BNE $0b4c ; (main.s17 + 0)
.s18:
0b2d : c9 3e __ CMP #$3e
0b2f : d0 12 __ BNE $0b43 ; (main.s22 + 0)
.s19:
0b31 : a5 1d __ LDA ACCU + 2 
0b33 : c9 99 __ CMP #$99
0b35 : d0 0c __ BNE $0b43 ; (main.s22 + 0)
.s20:
0b37 : a5 1c __ LDA ACCU + 1 
0b39 : c9 99 __ CMP #$99
0b3b : d0 06 __ BNE $0b43 ; (main.s22 + 0)
.s21:
0b3d : a5 1b __ LDA ACCU + 0 
0b3f : c9 9a __ CMP #$9a
0b41 : f0 07 __ BEQ $0b4a ; (main.s16 + 0)
.s22:
0b43 : a9 00 __ LDA #$00
0b45 : 2a __ __ ROL
0b46 : 49 01 __ EOR #$01
0b48 : 90 02 __ BCC $0b4c ; (main.s17 + 0)
.s16:
0b4a : a9 00 __ LDA #$00
.s17:
0b4c : 49 ff __ EOR #$ff
0b4e : c9 ff __ CMP #$ff
0b50 : f0 57 __ BEQ $0ba9 ; (main.s23 + 0)
.s134:
0b52 : ad e4 22 LDA $22e4 ; (b_t_2 + 0)
0b55 : 85 53 __ STA T0 + 0 
0b57 : ad e5 22 LDA $22e5 ; (b_t_2 + 1)
0b5a : c9 e0 __ CMP #$e0
0b5c : 90 35 __ BCC $0b93 ; (main.s135 + 0)
.s136:
0b5e : 85 54 __ STA T0 + 1 
0b60 : c9 ff __ CMP #$ff
0b62 : d0 04 __ BNE $0b68 ; (main.s140 + 0)
.s139:
0b64 : a5 53 __ LDA T0 + 0 
0b66 : c9 40 __ CMP #$40
.s140:
0b68 : b0 29 __ BCS $0b93 ; (main.s135 + 0)
.s137:
0b6a : ad 04 22 LDA $2204 ; (b_mem + 0)
0b6d : 85 5b __ STA T3 + 0 
0b6f : ad 05 22 LDA $2205 ; (b_mem + 1)
0b72 : 85 5c __ STA T3 + 1 
0b74 : a0 01 __ LDY #$01
0b76 : b1 5b __ LDA (T3 + 0),y 
0b78 : aa __ __ TAX
0b79 : 4a __ __ LSR
0b7a : 90 17 __ BCC $0b93 ; (main.s135 + 0)
.s138:
0b7c : 8a __ __ TXA
0b7d : 29 fe __ AND #$fe
0b7f : 91 5b __ STA (T3 + 0),y 
0b81 : 18 __ __ CLC
0b82 : a5 5c __ LDA T3 + 1 
0b84 : 65 54 __ ADC T0 + 1 
0b86 : 85 54 __ STA T0 + 1 
0b88 : a9 51 __ LDA #$51
0b8a : a4 5b __ LDY T3 + 0 
0b8c : 91 53 __ STA (T0 + 0),y 
0b8e : 8a __ __ TXA
0b8f : a0 01 __ LDY #$01
0b91 : d0 14 __ BNE $0ba7 ; (main.s156 + 0)
.s135:
0b93 : ad 04 22 LDA $2204 ; (b_mem + 0)
0b96 : 18 __ __ CLC
0b97 : 65 53 __ ADC T0 + 0 
0b99 : 85 5b __ STA T3 + 0 
0b9b : ad 05 22 LDA $2205 ; (b_mem + 1)
0b9e : 6d e5 22 ADC $22e5 ; (b_t_2 + 1)
0ba1 : 85 5c __ STA T3 + 1 
0ba3 : a9 51 __ LDA #$51
0ba5 : a0 00 __ LDY #$00
.s156:
0ba7 : 91 5b __ STA (T3 + 0),y 
.s23:
0ba9 : ee e4 22 INC $22e4 ; (b_t_2 + 0)
0bac : d0 0d __ BNE $0bbb ; (main.s162 + 0)
.s183:
0bae : ee e5 22 INC $22e5 ; (b_t_2 + 1)
0bb1 : d0 08 __ BNE $0bbb ; (main.s162 + 0)
.s163:
0bb3 : ee e6 22 INC $22e6 ; (b_t_2 + 2)
0bb6 : d0 03 __ BNE $0bbb ; (main.s162 + 0)
.s161:
0bb8 : ee e7 22 INC $22e7 ; (b_t_2 + 3)
.s162:
0bbb : a5 58 __ LDA T2 + 1 
0bbd : 10 03 __ BPL $0bc2 ; (main.s133 + 0)
0bbf : 4c ab 0a JMP $0aab ; (main.l14 + 0)
.s133:
0bc2 : d0 06 __ BNE $0bca ; (main.s24 + 0)
.s132:
0bc4 : a9 13 __ LDA #$13
0bc6 : c5 57 __ CMP T2 + 0 
0bc8 : b0 f5 __ BCS $0bbf ; (main.s162 + 4)
.s24:
0bca : 18 __ __ CLC
0bcb : a5 51 __ LDA T1 + 0 
0bcd : 69 01 __ ADC #$01
0bcf : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
0bd2 : a5 52 __ LDA T1 + 1 
0bd4 : 69 00 __ ADC #$00
0bd6 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
0bd9 : a5 52 __ LDA T1 + 1 
0bdb : 10 03 __ BPL $0be0 ; (main.s131 + 0)
0bdd : 4c 59 0a JMP $0a59 ; (main.l13 + 0)
.s131:
0be0 : d0 06 __ BNE $0be8 ; (main.s25 + 0)
.s130:
0be2 : a9 13 __ LDA #$13
0be4 : c5 51 __ CMP T1 + 0 
0be6 : b0 f5 __ BCS $0bdd ; (main.s24 + 19)
.s25:
0be8 : a9 01 __ LDA #$01
0bea : 8d e8 22 STA $22e8 ; (b_v_ki + 0)
0bed : a9 00 __ LDA #$00
0bef : 8d e9 22 STA $22e9 ; (b_v_ki + 1)
.l26:
0bf2 : 20 9f 16 JSR $169f ; (b_jiffy.s4 + 0)
0bf5 : 20 65 1f JSR $1f65 ; (f32_to_i32 + 0)
0bf8 : a5 1b __ LDA ACCU + 0 
0bfa : 85 5d __ STA T4 + 0 
0bfc : a5 1c __ LDA ACCU + 1 
0bfe : 85 5e __ STA T4 + 1 
0c00 : a5 1d __ LDA ACCU + 2 
0c02 : 85 5f __ STA T4 + 2 
0c04 : a5 1e __ LDA ACCU + 3 
0c06 : 85 60 __ STA T4 + 3 
0c08 : a9 01 __ LDA #$01
0c0a : 8d ea 22 STA $22ea ; (b_v_xi + 0)
0c0d : a9 00 __ LDA #$00
0c0f : 8d eb 22 STA $22eb ; (b_v_xi + 1)
0c12 : ad 04 22 LDA $2204 ; (b_mem + 0)
0c15 : 85 61 __ STA T9 + 0 
0c17 : ad 05 22 LDA $2205 ; (b_mem + 1)
0c1a : 85 62 __ STA T9 + 1 
.l27:
0c1c : ad ea 22 LDA $22ea ; (b_v_xi + 0)
0c1f : 85 43 __ STA T5 + 0 
0c21 : 0a __ __ ASL
0c22 : 85 1b __ STA ACCU + 0 
0c24 : a9 01 __ LDA #$01
0c26 : 8d f0 22 STA $22f0 ; (b_v_yi + 0)
0c29 : ad eb 22 LDA $22eb ; (b_v_xi + 1)
0c2c : 85 44 __ STA T5 + 1 
0c2e : 2a __ __ ROL
0c2f : 06 1b __ ASL ACCU + 0 
0c31 : 2a __ __ ROL
0c32 : aa __ __ TAX
0c33 : 18 __ __ CLC
0c34 : a5 1b __ LDA ACCU + 0 
0c36 : 65 43 __ ADC T5 + 0 
0c38 : 85 53 __ STA T0 + 0 
0c3a : 8a __ __ TXA
0c3b : 65 44 __ ADC T5 + 1 
0c3d : 06 53 __ ASL T0 + 0 
0c3f : 2a __ __ ROL
0c40 : 06 53 __ ASL T0 + 0 
0c42 : 2a __ __ ROL
0c43 : 06 53 __ ASL T0 + 0 
0c45 : 2a __ __ ROL
0c46 : aa __ __ TAX
0c47 : 18 __ __ CLC
0c48 : a5 53 __ LDA T0 + 0 
0c4a : 69 5a __ ADC #$5a
0c4c : 8d ec 22 STA $22ec ; (b_v_bbi + 0)
0c4f : 8a __ __ TXA
0c50 : 69 04 __ ADC #$04
0c52 : 8d ed 22 STA $22ed ; (b_v_bbi + 1)
0c55 : 0a __ __ ASL
0c56 : a9 00 __ LDA #$00
0c58 : 8d f1 22 STA $22f1 ; (b_v_yi + 1)
0c5b : 69 ff __ ADC #$ff
0c5d : 49 ff __ EOR #$ff
0c5f : 8d ee 22 STA $22ee ; (b_v_bbi + 2)
0c62 : 8d ef 22 STA $22ef ; (b_v_bbi + 3)
0c65 : ad ec 22 LDA $22ec ; (b_v_bbi + 0)
0c68 : 18 __ __ CLC
0c69 : 69 a7 __ ADC #$a7
0c6b : 8d f2 22 STA $22f2 ; (b_v_nbi + 0)
0c6e : ad ed 22 LDA $22ed ; (b_v_bbi + 1)
0c71 : 69 5b __ ADC #$5b
0c73 : 8d f3 22 STA $22f3 ; (b_v_nbi + 1)
0c76 : ad ee 22 LDA $22ee ; (b_v_bbi + 2)
0c79 : 69 00 __ ADC #$00
0c7b : 8d f4 22 STA $22f4 ; (b_v_nbi + 2)
0c7e : ad ef 22 LDA $22ef ; (b_v_bbi + 3)
0c81 : 69 00 __ ADC #$00
0c83 : 8d f5 22 STA $22f5 ; (b_v_nbi + 3)
.l28:
0c86 : ad ec 22 LDA $22ec ; (b_v_bbi + 0)
0c89 : 85 53 __ STA T0 + 0 
0c8b : 38 __ __ SEC
0c8c : e9 29 __ SBC #$29
0c8e : 85 51 __ STA T1 + 0 
0c90 : ad ed 22 LDA $22ed ; (b_v_bbi + 1)
0c93 : 85 54 __ STA T0 + 1 
0c95 : e9 00 __ SBC #$00
0c97 : 18 __ __ CLC
0c98 : 65 62 __ ADC T9 + 1 
0c9a : 85 52 __ STA T1 + 1 
0c9c : a4 61 __ LDY T9 + 0 
0c9e : b1 51 __ LDA (T1 + 0),y 
0ca0 : 85 57 __ STA T2 + 0 
0ca2 : 38 __ __ SEC
0ca3 : a5 53 __ LDA T0 + 0 
0ca5 : e9 28 __ SBC #$28
0ca7 : 85 51 __ STA T1 + 0 
0ca9 : a5 54 __ LDA T0 + 1 
0cab : e9 00 __ SBC #$00
0cad : 18 __ __ CLC
0cae : 65 62 __ ADC T9 + 1 
0cb0 : 85 52 __ STA T1 + 1 
0cb2 : b1 51 __ LDA (T1 + 0),y 
0cb4 : 85 5b __ STA T3 + 0 
0cb6 : 38 __ __ SEC
0cb7 : a5 53 __ LDA T0 + 0 
0cb9 : e9 27 __ SBC #$27
0cbb : 85 51 __ STA T1 + 0 
0cbd : a5 54 __ LDA T0 + 1 
0cbf : e9 00 __ SBC #$00
0cc1 : 18 __ __ CLC
0cc2 : 65 62 __ ADC T9 + 1 
0cc4 : 85 52 __ STA T1 + 1 
0cc6 : b1 51 __ LDA (T1 + 0),y 
0cc8 : 85 45 __ STA T6 + 0 
0cca : 38 __ __ SEC
0ccb : a5 53 __ LDA T0 + 0 
0ccd : e9 01 __ SBC #$01
0ccf : 85 51 __ STA T1 + 0 
0cd1 : a5 54 __ LDA T0 + 1 
0cd3 : e9 00 __ SBC #$00
0cd5 : 18 __ __ CLC
0cd6 : 65 62 __ ADC T9 + 1 
0cd8 : 85 52 __ STA T1 + 1 
0cda : b1 51 __ LDA (T1 + 0),y 
0cdc : 85 47 __ STA T7 + 0 
0cde : 98 __ __ TYA
0cdf : 18 __ __ CLC
0ce0 : 65 53 __ ADC T0 + 0 
0ce2 : 85 51 __ STA T1 + 0 
0ce4 : a5 62 __ LDA T9 + 1 
0ce6 : 65 54 __ ADC T0 + 1 
0ce8 : 85 52 __ STA T1 + 1 
0cea : a0 01 __ LDY #$01
0cec : b1 51 __ LDA (T1 + 0),y 
0cee : aa __ __ TAX
0cef : a0 27 __ LDY #$27
0cf1 : b1 51 __ LDA (T1 + 0),y 
0cf3 : 85 4b __ STA T10 + 0 
0cf5 : c8 __ __ INY
0cf6 : b1 51 __ LDA (T1 + 0),y 
0cf8 : 85 4c __ STA T11 + 0 
0cfa : c8 __ __ INY
0cfb : b1 51 __ LDA (T1 + 0),y 
0cfd : 85 4d __ STA T12 + 0 
0cff : a0 00 __ LDY #$00
0d01 : b1 51 __ LDA (T1 + 0),y 
0d03 : 85 4e __ STA T13 + 0 
0d05 : 18 __ __ CLC
0d06 : a5 53 __ LDA T0 + 0 
0d08 : 69 01 __ ADC #$01
0d0a : 85 53 __ STA T0 + 0 
0d0c : a5 54 __ LDA T0 + 1 
0d0e : 69 00 __ ADC #$00
0d10 : 85 54 __ STA T0 + 1 
0d12 : ad ee 22 LDA $22ee ; (b_v_bbi + 2)
0d15 : 69 00 __ ADC #$00
0d17 : 85 55 __ STA T0 + 2 
0d19 : ad ef 22 LDA $22ef ; (b_v_bbi + 3)
0d1c : 69 00 __ ADC #$00
0d1e : 85 56 __ STA T0 + 3 
0d20 : 18 __ __ CLC
0d21 : a5 5b __ LDA T3 + 0 
0d23 : 65 57 __ ADC T2 + 0 
0d25 : a8 __ __ TAY
0d26 : a9 00 __ LDA #$00
0d28 : 2a __ __ ROL
0d29 : 85 52 __ STA T1 + 1 
0d2b : 98 __ __ TYA
0d2c : 65 45 __ ADC T6 + 0 
0d2e : 90 03 __ BCC $0d33 ; (main.s165 + 0)
.s164:
0d30 : e6 52 __ INC T1 + 1 
0d32 : 18 __ __ CLC
.s165:
0d33 : 65 47 __ ADC T7 + 0 
0d35 : 85 51 __ STA T1 + 0 
0d37 : a4 52 __ LDY T1 + 1 
0d39 : 90 02 __ BCC $0d3d ; (main.s167 + 0)
.s166:
0d3b : c8 __ __ INY
0d3c : 18 __ __ CLC
.s167:
0d3d : 8a __ __ TXA
0d3e : 65 51 __ ADC T1 + 0 
0d40 : 90 02 __ BCC $0d44 ; (main.s169 + 0)
.s168:
0d42 : c8 __ __ INY
0d43 : 18 __ __ CLC
.s169:
0d44 : 65 4b __ ADC T10 + 0 
0d46 : 90 02 __ BCC $0d4a ; (main.s171 + 0)
.s170:
0d48 : c8 __ __ INY
0d49 : 18 __ __ CLC
.s171:
0d4a : 65 4c __ ADC T11 + 0 
0d4c : 90 02 __ BCC $0d50 ; (main.s173 + 0)
.s172:
0d4e : c8 __ __ INY
0d4f : 18 __ __ CLC
.s173:
0d50 : 65 4d __ ADC T12 + 0 
0d52 : 85 51 __ STA T1 + 0 
0d54 : 90 01 __ BCC $0d57 ; (main.s175 + 0)
.s174:
0d56 : c8 __ __ INY
.s175:
0d57 : 84 52 __ STY T1 + 1 
0d59 : ad f2 22 LDA $22f2 ; (b_v_nbi + 0)
0d5c : 85 57 __ STA T2 + 0 
0d5e : ad f4 22 LDA $22f4 ; (b_v_nbi + 2)
0d61 : 85 59 __ STA T2 + 2 
0d63 : ad f5 22 LDA $22f5 ; (b_v_nbi + 3)
0d66 : 85 5a __ STA T2 + 3 
0d68 : ad f3 22 LDA $22f3 ; (b_v_nbi + 1)
0d6b : 85 58 __ STA T2 + 1 
0d6d : c9 e0 __ CMP #$e0
0d6f : a9 00 __ LDA #$00
0d71 : 6a __ __ ROR
0d72 : 85 47 __ STA T7 + 0 
0d74 : f0 31 __ BEQ $0da7 ; (main.s29 + 0)
.s125:
0d76 : a5 58 __ LDA T2 + 1 
0d78 : c9 ff __ CMP #$ff
0d7a : d0 04 __ BNE $0d80 ; (main.s129 + 0)
.s128:
0d7c : a5 57 __ LDA T2 + 0 
0d7e : c9 40 __ CMP #$40
.s129:
0d80 : b0 25 __ BCS $0da7 ; (main.s29 + 0)
.s126:
0d82 : a0 01 __ LDY #$01
0d84 : b1 61 __ LDA (T9 + 0),y 
0d86 : aa __ __ TAX
0d87 : 4a __ __ LSR
0d88 : 90 1d __ BCC $0da7 ; (main.s29 + 0)
.s127:
0d8a : 8a __ __ TXA
0d8b : 29 fe __ AND #$fe
0d8d : 91 61 __ STA (T9 + 0),y 
0d8f : a5 57 __ LDA T2 + 0 
0d91 : 85 5b __ STA T3 + 0 
0d93 : 18 __ __ CLC
0d94 : a5 62 __ LDA T9 + 1 
0d96 : 65 58 __ ADC T2 + 1 
0d98 : 85 5c __ STA T3 + 1 
0d9a : a9 20 __ LDA #$20
0d9c : a4 61 __ LDY T9 + 0 
0d9e : 91 5b __ STA (T3 + 0),y 
0da0 : 8a __ __ TXA
0da1 : a0 01 __ LDY #$01
0da3 : 91 61 __ STA (T9 + 0),y 
0da5 : d0 11 __ BNE $0db8 ; (main.s30 + 0)
.s29:
0da7 : a5 57 __ LDA T2 + 0 
0da9 : 85 5b __ STA T3 + 0 
0dab : 18 __ __ CLC
0dac : a5 62 __ LDA T9 + 1 
0dae : 65 58 __ ADC T2 + 1 
0db0 : 85 5c __ STA T3 + 1 
0db2 : a9 20 __ LDA #$20
0db4 : a4 61 __ LDY T9 + 0 
0db6 : 91 5b __ STA (T3 + 0),y 
.s30:
0db8 : a5 53 __ LDA T0 + 0 
0dba : 8d ec 22 STA $22ec ; (b_v_bbi + 0)
0dbd : a5 54 __ LDA T0 + 1 
0dbf : 8d ed 22 STA $22ed ; (b_v_bbi + 1)
0dc2 : a5 55 __ LDA T0 + 2 
0dc4 : 8d ee 22 STA $22ee ; (b_v_bbi + 2)
0dc7 : a5 56 __ LDA T0 + 3 
0dc9 : 8d ef 22 STA $22ef ; (b_v_bbi + 3)
0dcc : 18 __ __ CLC
0dcd : a5 57 __ LDA T2 + 0 
0dcf : 69 01 __ ADC #$01
0dd1 : 8d f2 22 STA $22f2 ; (b_v_nbi + 0)
0dd4 : a5 58 __ LDA T2 + 1 
0dd6 : 69 00 __ ADC #$00
0dd8 : 8d f3 22 STA $22f3 ; (b_v_nbi + 1)
0ddb : a5 59 __ LDA T2 + 2 
0ddd : 69 00 __ ADC #$00
0ddf : 8d f4 22 STA $22f4 ; (b_v_nbi + 2)
0de2 : a5 5a __ LDA T2 + 3 
0de4 : 69 00 __ ADC #$00
0de6 : 8d f5 22 STA $22f5 ; (b_v_nbi + 3)
0de9 : ad f0 22 LDA $22f0 ; (b_v_yi + 0)
0dec : 85 45 __ STA T6 + 0 
0dee : 18 __ __ CLC
0def : 69 01 __ ADC #$01
0df1 : 8d f0 22 STA $22f0 ; (b_v_yi + 0)
0df4 : ad f1 22 LDA $22f1 ; (b_v_yi + 1)
0df7 : aa __ __ TAX
0df8 : 69 00 __ ADC #$00
0dfa : 8d f1 22 STA $22f1 ; (b_v_yi + 1)
0dfd : a5 4e __ LDA T13 + 0 
0dff : c9 51 __ CMP #$51
0e01 : d0 04 __ BNE $0e07 ; (main.s32 + 0)
.s31:
0e03 : a9 01 __ LDA #$01
0e05 : d0 02 __ BNE $0e09 ; (main.s33 + 0)
.s32:
0e07 : a9 00 __ LDA #$00
.s33:
0e09 : 49 ff __ EOR #$ff
0e0b : 18 __ __ CLC
0e0c : 69 01 __ ADC #$01
0e0e : 85 53 __ STA T0 + 0 
0e10 : a4 52 __ LDY T1 + 1 
0e12 : 88 __ __ DEY
0e13 : d0 0a __ BNE $0e1f ; (main.s35 + 0)
.s37:
0e15 : a5 51 __ LDA T1 + 0 
0e17 : c9 62 __ CMP #$62
0e19 : d0 04 __ BNE $0e1f ; (main.s35 + 0)
.s34:
0e1b : a9 01 __ LDA #$01
0e1d : d0 02 __ BNE $0e21 ; (main.s36 + 0)
.s35:
0e1f : a9 00 __ LDA #$00
.s36:
0e21 : 49 ff __ EOR #$ff
0e23 : 18 __ __ CLC
0e24 : 69 01 __ ADC #$01
0e26 : 25 53 __ AND T0 + 0 
0e28 : 85 53 __ STA T0 + 0 
0e2a : c8 __ __ INY
0e2b : 88 __ __ DEY
0e2c : d0 0a __ BNE $0e38 ; (main.s39 + 0)
.s41:
0e2e : a5 51 __ LDA T1 + 0 
0e30 : c9 93 __ CMP #$93
0e32 : d0 04 __ BNE $0e38 ; (main.s39 + 0)
.s38:
0e34 : a9 01 __ LDA #$01
0e36 : d0 02 __ BNE $0e3a ; (main.s40 + 0)
.s39:
0e38 : a9 00 __ LDA #$00
.s40:
0e3a : 49 ff __ EOR #$ff
0e3c : 18 __ __ CLC
0e3d : 69 01 __ ADC #$01
0e3f : 05 53 __ ORA T0 + 0 
0e41 : f0 49 __ BEQ $0e8c ; (main.s42 + 0)
.s118:
0e43 : 24 47 __ BIT T7 + 0 
0e45 : 10 34 __ BPL $0e7b ; (main.s119 + 0)
.s120:
0e47 : a5 58 __ LDA T2 + 1 
0e49 : c9 ff __ CMP #$ff
0e4b : d0 04 __ BNE $0e51 ; (main.s124 + 0)
.s123:
0e4d : a5 57 __ LDA T2 + 0 
0e4f : c9 40 __ CMP #$40
.s124:
0e51 : b0 28 __ BCS $0e7b ; (main.s119 + 0)
.s121:
0e53 : a0 01 __ LDY #$01
0e55 : b1 61 __ LDA (T9 + 0),y 
0e57 : 85 5b __ STA T3 + 0 
0e59 : 4a __ __ LSR
0e5a : 90 1f __ BCC $0e7b ; (main.s119 + 0)
.s122:
0e5c : a5 5b __ LDA T3 + 0 
0e5e : 29 fe __ AND #$fe
0e60 : 91 61 __ STA (T9 + 0),y 
0e62 : a5 57 __ LDA T2 + 0 
0e64 : 85 53 __ STA T0 + 0 
0e66 : 18 __ __ CLC
0e67 : a5 62 __ LDA T9 + 1 
0e69 : 65 58 __ ADC T2 + 1 
0e6b : 85 54 __ STA T0 + 1 
0e6d : a9 51 __ LDA #$51
0e6f : a4 61 __ LDY T9 + 0 
0e71 : 91 53 __ STA (T0 + 0),y 
0e73 : a5 5b __ LDA T3 + 0 
0e75 : a0 01 __ LDY #$01
0e77 : 91 61 __ STA (T9 + 0),y 
0e79 : d0 11 __ BNE $0e8c ; (main.s42 + 0)
.s119:
0e7b : a5 57 __ LDA T2 + 0 
0e7d : 85 53 __ STA T0 + 0 
0e7f : 18 __ __ CLC
0e80 : a5 62 __ LDA T9 + 1 
0e82 : 65 58 __ ADC T2 + 1 
0e84 : 85 54 __ STA T0 + 1 
0e86 : a9 51 __ LDA #$51
0e88 : a4 61 __ LDY T9 + 0 
0e8a : 91 53 __ STA (T0 + 0),y 
.s42:
0e8c : 8a __ __ TXA
0e8d : 10 03 __ BPL $0e92 ; (main.s117 + 0)
0e8f : 4c 86 0c JMP $0c86 ; (main.l28 + 0)
.s117:
0e92 : d0 06 __ BNE $0e9a ; (main.s43 + 0)
.s116:
0e94 : a9 13 __ LDA #$13
0e96 : c5 45 __ CMP T6 + 0 
0e98 : b0 f5 __ BCS $0e8f ; (main.s42 + 3)
.s43:
0e9a : 18 __ __ CLC
0e9b : a5 43 __ LDA T5 + 0 
0e9d : 69 01 __ ADC #$01
0e9f : 8d ea 22 STA $22ea ; (b_v_xi + 0)
0ea2 : a5 44 __ LDA T5 + 1 
0ea4 : 69 00 __ ADC #$00
0ea6 : 8d eb 22 STA $22eb ; (b_v_xi + 1)
0ea9 : a5 44 __ LDA T5 + 1 
0eab : 10 03 __ BPL $0eb0 ; (main.s115 + 0)
0ead : 4c 1c 0c JMP $0c1c ; (main.l27 + 0)
.s115:
0eb0 : d0 06 __ BNE $0eb8 ; (main.s44 + 0)
.s114:
0eb2 : a9 13 __ LDA #$13
0eb4 : c5 43 __ CMP T5 + 0 
0eb6 : b0 f5 __ BCS $0ead ; (main.s43 + 19)
.s44:
0eb8 : a9 01 __ LDA #$01
0eba : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
0ebd : a9 00 __ LDA #$00
0ebf : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
.l45:
0ec2 : ad d8 22 LDA $22d8 ; (b_v_ri + 0)
0ec5 : 85 51 __ STA T1 + 0 
0ec7 : 0a __ __ ASL
0ec8 : 85 1b __ STA ACCU + 0 
0eca : a9 01 __ LDA #$01
0ecc : 8d da 22 STA $22da ; (b_v_ci + 0)
0ecf : a9 00 __ LDA #$00
0ed1 : 8d db 22 STA $22db ; (b_v_ci + 1)
0ed4 : ad d9 22 LDA $22d9 ; (b_v_ri + 1)
0ed7 : 85 52 __ STA T1 + 1 
0ed9 : 2a __ __ ROL
0eda : 06 1b __ ASL ACCU + 0 
0edc : 2a __ __ ROL
0edd : aa __ __ TAX
0ede : 18 __ __ CLC
0edf : a5 1b __ LDA ACCU + 0 
0ee1 : 65 51 __ ADC T1 + 0 
0ee3 : 85 53 __ STA T0 + 0 
0ee5 : 8a __ __ TXA
0ee6 : 65 52 __ ADC T1 + 1 
0ee8 : 06 53 __ ASL T0 + 0 
0eea : 2a __ __ ROL
0eeb : 06 53 __ ASL T0 + 0 
0eed : 2a __ __ ROL
0eee : 06 53 __ ASL T0 + 0 
0ef0 : 2a __ __ ROL
0ef1 : aa __ __ TAX
0ef2 : a5 53 __ LDA T0 + 0 
0ef4 : 85 5b __ STA T3 + 0 
0ef6 : 18 __ __ CLC
0ef7 : 69 59 __ ADC #$59
0ef9 : 85 57 __ STA T2 + 0 
0efb : 8a __ __ TXA
0efc : 69 04 __ ADC #$04
0efe : 85 58 __ STA T2 + 1 
0f00 : 8a __ __ TXA
0f01 : 18 __ __ CLC
0f02 : 69 60 __ ADC #$60
0f04 : 85 5c __ STA T3 + 1 
.l46:
0f06 : ad da 22 LDA $22da ; (b_v_ci + 0)
0f09 : 85 43 __ STA T5 + 0 
0f0b : 18 __ __ CLC
0f0c : 69 01 __ ADC #$01
0f0e : 8d da 22 STA $22da ; (b_v_ci + 0)
0f11 : ad db 22 LDA $22db ; (b_v_ci + 1)
0f14 : 85 44 __ STA T5 + 1 
0f16 : 69 00 __ ADC #$00
0f18 : 8d db 22 STA $22db ; (b_v_ci + 1)
0f1b : 18 __ __ CLC
0f1c : a5 43 __ LDA T5 + 0 
0f1e : 65 5b __ ADC T3 + 0 
0f20 : 85 53 __ STA T0 + 0 
0f22 : a5 44 __ LDA T5 + 1 
0f24 : 65 5c __ ADC T3 + 1 
0f26 : 18 __ __ CLC
0f27 : 65 62 __ ADC T9 + 1 
0f29 : 85 54 __ STA T0 + 1 
0f2b : a4 61 __ LDY T9 + 0 
0f2d : b1 53 __ LDA (T0 + 0),y 
0f2f : 85 53 __ STA T0 + 0 
0f31 : 18 __ __ CLC
0f32 : a5 57 __ LDA T2 + 0 
0f34 : 65 43 __ ADC T5 + 0 
0f36 : 85 45 __ STA T6 + 0 
0f38 : a5 58 __ LDA T2 + 1 
0f3a : 65 44 __ ADC T5 + 1 
0f3c : 85 46 __ STA T6 + 1 
0f3e : c9 e0 __ CMP #$e0
0f40 : 90 2d __ BCC $0f6f ; (main.s47 + 0)
.s109:
0f42 : c9 ff __ CMP #$ff
0f44 : d0 04 __ BNE $0f4a ; (main.s113 + 0)
.s112:
0f46 : a5 45 __ LDA T6 + 0 
0f48 : c9 40 __ CMP #$40
.s113:
0f4a : b0 23 __ BCS $0f6f ; (main.s47 + 0)
.s110:
0f4c : a0 01 __ LDY #$01
0f4e : b1 61 __ LDA (T9 + 0),y 
0f50 : aa __ __ TAX
0f51 : 4a __ __ LSR
0f52 : 90 19 __ BCC $0f6d ; (main.s187 + 0)
.s111:
0f54 : 8a __ __ TXA
0f55 : 29 fe __ AND #$fe
0f57 : 91 61 __ STA (T9 + 0),y 
0f59 : 18 __ __ CLC
0f5a : a5 62 __ LDA T9 + 1 
0f5c : 65 46 __ ADC T6 + 1 
0f5e : 85 46 __ STA T6 + 1 
0f60 : a5 53 __ LDA T0 + 0 
0f62 : a4 61 __ LDY T9 + 0 
0f64 : 91 45 __ STA (T6 + 0),y 
0f66 : 8a __ __ TXA
0f67 : a0 01 __ LDY #$01
0f69 : 91 61 __ STA (T9 + 0),y 
0f6b : d0 0d __ BNE $0f7a ; (main.s48 + 0)
.s187:
0f6d : a4 61 __ LDY T9 + 0 
.s47:
0f6f : 18 __ __ CLC
0f70 : a5 62 __ LDA T9 + 1 
0f72 : 65 46 __ ADC T6 + 1 
0f74 : 85 46 __ STA T6 + 1 
0f76 : a5 53 __ LDA T0 + 0 
0f78 : 91 45 __ STA (T6 + 0),y 
.s48:
0f7a : a5 44 __ LDA T5 + 1 
0f7c : 30 88 __ BMI $0f06 ; (main.l46 + 0)
.s108:
0f7e : d0 06 __ BNE $0f86 ; (main.s49 + 0)
.s107:
0f80 : a9 13 __ LDA #$13
0f82 : c5 43 __ CMP T5 + 0 
0f84 : b0 80 __ BCS $0f06 ; (main.l46 + 0)
.s49:
0f86 : 18 __ __ CLC
0f87 : a5 51 __ LDA T1 + 0 
0f89 : 69 01 __ ADC #$01
0f8b : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
0f8e : a5 52 __ LDA T1 + 1 
0f90 : 69 00 __ ADC #$00
0f92 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
0f95 : a5 52 __ LDA T1 + 1 
0f97 : 10 03 __ BPL $0f9c ; (main.s106 + 0)
0f99 : 4c c2 0e JMP $0ec2 ; (main.l45 + 0)
.s106:
0f9c : d0 06 __ BNE $0fa4 ; (main.s50 + 0)
.s105:
0f9e : a9 13 __ LDA #$13
0fa0 : c5 51 __ CMP T1 + 0 
0fa2 : b0 f5 __ BCS $0f99 ; (main.s49 + 19)
.s50:
0fa4 : a5 61 __ LDA T9 + 0 
0fa6 : 85 1f __ STA ADDR + 0 
0fa8 : 18 __ __ CLC
0fa9 : a5 62 __ LDA T9 + 1 
0fab : 69 04 __ ADC #$04
0fad : 85 20 __ STA ADDR + 1 
0faf : a9 20 __ LDA #$20
0fb1 : a0 00 __ LDY #$00
0fb3 : 91 1f __ STA (ADDR + 0),y 
0fb5 : a9 13 __ LDA #$13
0fb7 : 85 13 __ STA P6 
0fb9 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
0fbc : 20 9f 16 JSR $169f ; (b_jiffy.s4 + 0)
0fbf : a5 1b __ LDA ACCU + 0 
0fc1 : 85 53 __ STA T0 + 0 
0fc3 : a5 1c __ LDA ACCU + 1 
0fc5 : 85 54 __ STA T0 + 1 
0fc7 : a5 1d __ LDA ACCU + 2 
0fc9 : 85 55 __ STA T0 + 2 
0fcb : a5 1e __ LDA ACCU + 3 
0fcd : 85 56 __ STA T0 + 3 
0fcf : a5 5d __ LDA T4 + 0 
0fd1 : 85 1b __ STA ACCU + 0 
0fd3 : a5 5e __ LDA T4 + 1 
0fd5 : 85 1c __ STA ACCU + 1 
0fd7 : a5 5f __ LDA T4 + 2 
0fd9 : 85 1d __ STA ACCU + 2 
0fdb : a5 60 __ LDA T4 + 3 
0fdd : 85 1e __ STA ACCU + 3 
0fdf : 20 c4 1f JSR $1fc4 ; (sint32_to_float + 0)
0fe2 : a2 53 __ LDX #$53
0fe4 : 20 d5 1b JSR $1bd5 ; (freg + 4)
0fe7 : a5 1e __ LDA ACCU + 3 
0fe9 : 49 80 __ EOR #$80
0feb : 85 1e __ STA ACCU + 3 
0fed : 20 1c 1c JSR $1c1c ; (faddsub + 6)
0ff0 : a5 1b __ LDA ACCU + 0 
0ff2 : 85 53 __ STA T0 + 0 
0ff4 : a5 1c __ LDA ACCU + 1 
0ff6 : 85 54 __ STA T0 + 1 
0ff8 : a5 1d __ LDA ACCU + 2 
0ffa : 85 55 __ STA T0 + 2 
0ffc : a5 1e __ LDA ACCU + 3 
0ffe : 85 56 __ STA T0 + 3 
1000 : 29 7f __ AND #$7f
1002 : 05 1d __ ORA ACCU + 2 
1004 : 05 1c __ ORA ACCU + 1 
1006 : 05 1b __ ORA ACCU + 0 
1008 : f0 04 __ BEQ $100e ; (main.s103 + 0)
.s104:
100a : 24 1e __ BIT ACCU + 3 
100c : 30 04 __ BMI $1012 ; (main.s51 + 0)
.s103:
100e : a9 20 __ LDA #$20
1010 : d0 08 __ BNE $101a ; (main.s52 + 0)
.s51:
1012 : a5 1e __ LDA ACCU + 3 
1014 : 49 80 __ EOR #$80
1016 : 85 56 __ STA T0 + 3 
1018 : a9 2d __ LDA #$2d
.s52:
101a : 85 13 __ STA P6 
101c : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
101f : a5 56 __ LDA T0 + 3 
1021 : 29 7f __ AND #$7f
1023 : 05 55 __ ORA T0 + 2 
1025 : 05 54 __ ORA T0 + 1 
1027 : 05 53 __ ORA T0 + 0 
1029 : d0 0a __ BNE $1035 ; (main.s53 + 0)
.s102:
102b : a9 30 __ LDA #$30
102d : 85 13 __ STA P6 
102f : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1032 : 4c a5 10 JMP $10a5 ; (main.s55 + 0)
.s53:
1035 : a5 53 __ LDA T0 + 0 
1037 : 85 0f __ STA P2 
1039 : a5 54 __ LDA T0 + 1 
103b : 85 10 __ STA P3 
103d : a5 55 __ LDA T0 + 2 
103f : 85 11 __ STA P4 
1041 : a5 56 __ LDA T0 + 3 
1043 : 85 12 __ STA P5 
1045 : a9 a8 __ LDA #$a8
1047 : 85 0d __ STA P0 
1049 : a9 9f __ LDA #$9f
104b : 85 0e __ STA P1 
104d : 20 c0 16 JSR $16c0 ; (b_ftoa.s4 + 0)
1050 : a9 2e __ LDA #$2e
1052 : 85 0f __ STA P2 
1054 : a9 00 __ LDA #$00
1056 : 85 10 __ STA P3 
1058 : 20 2a 1b JSR $1b2a ; (strchr.l4 + 0)
105b : a5 1b __ LDA ACCU + 0 
105d : 05 1c __ ORA ACCU + 1 
105f : f0 2d __ BEQ $108e ; (main.s54 + 0)
.s95:
1061 : a9 a8 __ LDA #$a8
1063 : 85 0d __ STA P0 
1065 : a9 9f __ LDA #$9f
1067 : 85 0e __ STA P1 
1069 : 20 4c 1b JSR $1b4c ; (strlen.s4 + 0)
106c : a5 1c __ LDA ACCU + 1 
106e : 30 1e __ BMI $108e ; (main.s54 + 0)
.s101:
1070 : d0 06 __ BNE $1078 ; (main.s157 + 0)
.s100:
1072 : a5 1b __ LDA ACCU + 0 
1074 : c9 02 __ CMP #$02
1076 : 90 16 __ BCC $108e ; (main.s54 + 0)
.s157:
1078 : a6 1b __ LDX ACCU + 0 
.l96:
107a : bd a7 9f LDA $9fa7,x ; (tmp[0] + 23)
107d : c9 30 __ CMP #$30
107f : f0 03 __ BEQ $1084 ; (main.s99 + 0)
1081 : 4c 23 13 JMP $1323 ; (main.s97 + 0)
.s99:
1084 : a9 00 __ LDA #$00
1086 : 9d a7 9f STA $9fa7,x ; (tmp[0] + 23)
1089 : ca __ __ DEX
108a : e0 02 __ CPX #$02
108c : b0 ec __ BCS $107a ; (main.l96 + 0)
.s54:
108e : ad a8 9f LDA $9fa8 ; (buf[0] + 0)
1091 : f0 12 __ BEQ $10a5 ; (main.s55 + 0)
.s94:
1093 : a2 00 __ LDX #$00
1095 : 86 51 __ STX T1 + 0 
.l155:
1097 : 85 13 __ STA P6 
1099 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
109c : e6 51 __ INC T1 + 0 
109e : a6 51 __ LDX T1 + 0 
10a0 : bd a8 9f LDA $9fa8,x ; (buf[0] + 0)
10a3 : d0 f2 __ BNE $1097 ; (main.l155 + 0)
.s55:
10a5 : a9 20 __ LDA #$20
10a7 : 85 13 __ STA P6 
10a9 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
10ac : a9 0d __ LDA #$0d
10ae : 85 13 __ STA P6 
10b0 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
10b3 : ad e8 22 LDA $22e8 ; (b_v_ki + 0)
10b6 : 85 53 __ STA T0 + 0 
10b8 : 18 __ __ CLC
10b9 : 69 01 __ ADC #$01
10bb : 8d e8 22 STA $22e8 ; (b_v_ki + 0)
10be : ad e9 22 LDA $22e9 ; (b_v_ki + 1)
10c1 : aa __ __ TAX
10c2 : 69 00 __ ADC #$00
10c4 : 8d e9 22 STA $22e9 ; (b_v_ki + 1)
10c7 : 8a __ __ TXA
10c8 : 10 03 __ BPL $10cd ; (main.s93 + 0)
10ca : 4c f2 0b JMP $0bf2 ; (main.l26 + 0)
.s93:
10cd : d0 06 __ BNE $10d5 ; (main.s56 + 0)
.s92:
10cf : a9 63 __ LDA #$63
10d1 : c5 53 __ CMP T0 + 0 
10d3 : b0 f5 __ BCS $10ca ; (main.s55 + 37)
.s56:
10d5 : a9 00 __ LDA #$00
10d7 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
10da : 8d f6 22 STA $22f6 ; (b_v_si + 0)
10dd : 8d f7 22 STA $22f7 ; (b_v_si + 1)
10e0 : 8d f8 22 STA $22f8 ; (b_v_si + 2)
10e3 : 8d f9 22 STA $22f9 ; (b_v_si + 3)
10e6 : a9 01 __ LDA #$01
10e8 : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
.l57:
10eb : ad d8 22 LDA $22d8 ; (b_v_ri + 0)
10ee : 85 5b __ STA T3 + 0 
10f0 : 0a __ __ ASL
10f1 : 85 1b __ STA ACCU + 0 
10f3 : ad d9 22 LDA $22d9 ; (b_v_ri + 1)
10f6 : 85 5c __ STA T3 + 1 
10f8 : 2a __ __ ROL
10f9 : 06 1b __ ASL ACCU + 0 
10fb : 2a __ __ ROL
10fc : aa __ __ TAX
10fd : 18 __ __ CLC
10fe : a5 1b __ LDA ACCU + 0 
1100 : 65 5b __ ADC T3 + 0 
1102 : 85 53 __ STA T0 + 0 
1104 : 8a __ __ TXA
1105 : 65 5c __ ADC T3 + 1 
1107 : 06 53 __ ASL T0 + 0 
1109 : 2a __ __ ROL
110a : 06 53 __ ASL T0 + 0 
110c : 2a __ __ ROL
110d : 06 53 __ ASL T0 + 0 
110f : 2a __ __ ROL
1110 : aa __ __ TAX
1111 : 18 __ __ CLC
1112 : a5 53 __ LDA T0 + 0 
1114 : 69 59 __ ADC #$59
1116 : a8 __ __ TAY
1117 : 8a __ __ TXA
1118 : 69 04 __ ADC #$04
111a : aa __ __ TAX
111b : 98 __ __ TYA
111c : 18 __ __ CLC
111d : 69 01 __ ADC #$01
111f : 90 02 __ BCC $1123 ; (main.s177 + 0)
.s176:
1121 : e8 __ __ INX
1122 : 18 __ __ CLC
.s177:
1123 : 65 61 __ ADC T9 + 0 
1125 : 85 5d __ STA T4 + 0 
1127 : 8a __ __ TXA
1128 : 65 62 __ ADC T9 + 1 
112a : 85 5e __ STA T4 + 1 
112c : ad f6 22 LDA $22f6 ; (b_v_si + 0)
112f : 85 57 __ STA T2 + 0 
1131 : ad f7 22 LDA $22f7 ; (b_v_si + 1)
1134 : 85 58 __ STA T2 + 1 
1136 : ad f8 22 LDA $22f8 ; (b_v_si + 2)
1139 : 85 59 __ STA T2 + 2 
113b : ad f9 22 LDA $22f9 ; (b_v_si + 3)
113e : 85 5a __ STA T2 + 3 
1140 : a2 01 __ LDX #$01
.l58:
1142 : a0 00 __ LDY #$00
1144 : b1 5d __ LDA (T4 + 0),y 
1146 : c9 51 __ CMP #$51
1148 : f0 05 __ BEQ $114f ; (main.s59 + 0)
.s60:
114a : a5 57 __ LDA T2 + 0 
114c : 18 __ __ CLC
114d : 90 04 __ BCC $1153 ; (main.s61 + 0)
.s59:
114f : a5 57 __ LDA T2 + 0 
1151 : 69 00 __ ADC #$00
.s61:
1153 : 85 57 __ STA T2 + 0 
1155 : 90 0a __ BCC $1161 ; (main.s179 + 0)
.s184:
1157 : e6 58 __ INC T2 + 1 
1159 : d0 06 __ BNE $1161 ; (main.s179 + 0)
.s180:
115b : e6 59 __ INC T2 + 2 
115d : d0 02 __ BNE $1161 ; (main.s179 + 0)
.s178:
115f : e6 5a __ INC T2 + 3 
.s179:
1161 : e6 5d __ INC T4 + 0 
1163 : d0 02 __ BNE $1167 ; (main.s182 + 0)
.s181:
1165 : e6 5e __ INC T4 + 1 
.s182:
1167 : e8 __ __ INX
1168 : e0 15 __ CPX #$15
116a : 90 d6 __ BCC $1142 ; (main.l58 + 0)
.s62:
116c : 8c db 22 STY $22db ; (b_v_ci + 1)
116f : 8d f6 22 STA $22f6 ; (b_v_si + 0)
1172 : a5 58 __ LDA T2 + 1 
1174 : 8d f7 22 STA $22f7 ; (b_v_si + 1)
1177 : a9 15 __ LDA #$15
1179 : 8d da 22 STA $22da ; (b_v_ci + 0)
117c : a5 59 __ LDA T2 + 2 
117e : 8d f8 22 STA $22f8 ; (b_v_si + 2)
1181 : a5 5a __ LDA T2 + 3 
1183 : 8d f9 22 STA $22f9 ; (b_v_si + 3)
1186 : a5 5b __ LDA T3 + 0 
1188 : 69 00 __ ADC #$00
118a : 8d d8 22 STA $22d8 ; (b_v_ri + 0)
118d : a5 5c __ LDA T3 + 1 
118f : 69 00 __ ADC #$00
1191 : 8d d9 22 STA $22d9 ; (b_v_ri + 1)
1194 : a5 5c __ LDA T3 + 1 
1196 : 10 03 __ BPL $119b ; (main.s91 + 0)
1198 : 4c eb 10 JMP $10eb ; (main.l57 + 0)
.s91:
119b : d0 06 __ BNE $11a3 ; (main.s63 + 0)
.s90:
119d : a9 13 __ LDA #$13
119f : c5 5b __ CMP T3 + 0 
11a1 : b0 f5 __ BCS $1198 ; (main.s62 + 44)
.s63:
11a3 : 84 17 __ STY P10 
11a5 : a9 05 __ LDA #$05
11a7 : 85 16 __ STA P9 
11a9 : a9 1b __ LDA #$1b
11ab : 85 15 __ STA P8 
11ad : a9 68 __ LDA #$68
11af : 85 14 __ STA P7 
11b1 : 20 6e 1b JSR $1b6e ; (b_str.s4 + 0)
11b4 : a9 20 __ LDA #$20
11b6 : 85 13 __ STA P6 
11b8 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
11bb : a9 00 __ LDA #$00
11bd : 85 5d __ STA T4 + 0 
11bf : 85 55 __ STA T0 + 2 
11c1 : 85 56 __ STA T0 + 3 
11c3 : a8 __ __ TAY
11c4 : a9 64 __ LDA #$64
11c6 : 85 53 __ STA T0 + 0 
.l64:
11c8 : a5 5d __ LDA T4 + 0 
11ca : c9 17 __ CMP #$17
11cc : b0 4a __ BCS $1218 ; (main.l65 + 0)
.s86:
11ce : 84 1c __ STY ACCU + 1 
11d0 : a5 53 __ LDA T0 + 0 
11d2 : 85 1b __ STA ACCU + 0 
11d4 : a5 55 __ LDA T0 + 2 
11d6 : 85 1d __ STA ACCU + 2 
11d8 : a5 56 __ LDA T0 + 3 
11da : 85 1e __ STA ACCU + 3 
11dc : a9 00 __ LDA #$00
11de : 85 04 __ STA WORK + 1 
11e0 : 85 05 __ STA WORK + 2 
11e2 : 85 06 __ STA WORK + 3 
11e4 : a9 0a __ LDA #$0a
11e6 : 85 03 __ STA WORK + 0 
11e8 : 20 ec 20 JSR $20ec ; (divmod32 + 0)
11eb : a5 1b __ LDA ACCU + 0 
11ed : 85 53 __ STA T0 + 0 
11ef : a5 1d __ LDA ACCU + 2 
11f1 : 85 55 __ STA T0 + 2 
11f3 : a5 1e __ LDA ACCU + 3 
11f5 : 85 56 __ STA T0 + 3 
11f7 : 18 __ __ CLC
11f8 : a5 07 __ LDA WORK + 4 
11fa : 69 30 __ ADC #$30
11fc : a6 5d __ LDX T4 + 0 
11fe : 9d 90 9f STA $9f90,x ; (tmp[0] + 0)
1201 : a9 00 __ LDA #$00
1203 : e6 5d __ INC T4 + 0 
1205 : a4 1c __ LDY ACCU + 1 
1207 : c5 1e __ CMP ACCU + 3 
1209 : 90 bd __ BCC $11c8 ; (main.l64 + 0)
.s185:
120b : d0 0b __ BNE $1218 ; (main.l65 + 0)
.s87:
120d : a5 1d __ LDA ACCU + 2 
120f : d0 b7 __ BNE $11c8 ; (main.l64 + 0)
.s88:
1211 : 98 __ __ TYA
1212 : d0 b4 __ BNE $11c8 ; (main.l64 + 0)
.s89:
1214 : c4 1b __ CPY ACCU + 0 
1216 : 90 b0 __ BCC $11c8 ; (main.l64 + 0)
.l65:
1218 : a6 5d __ LDX T4 + 0 
121a : bd 8f 9f LDA $9f8f,x ; (tmp[0] + 23)
121d : 85 13 __ STA P6 
121f : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1222 : c6 5d __ DEC T4 + 0 
1224 : d0 f2 __ BNE $1218 ; (main.l65 + 0)
.s66:
1226 : a9 20 __ LDA #$20
1228 : 85 13 __ STA P6 
122a : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
122d : a9 0d __ LDA #$0d
122f : 85 13 __ STA P6 
1231 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1234 : a9 00 __ LDA #$00
1236 : 85 5b __ STA T3 + 0 
1238 : 85 17 __ STA P10 
123a : a9 06 __ LDA #$06
123c : 85 16 __ STA P9 
123e : a9 94 __ LDA #$94
1240 : 85 14 __ STA P7 
1242 : a9 1b __ LDA #$1b
1244 : 85 15 __ STA P8 
1246 : 20 6e 1b JSR $1b6e ; (b_str.s4 + 0)
1249 : 24 5a __ BIT T2 + 3 
124b : 10 21 __ BPL $126e ; (main.s81 + 0)
.s67:
124d : a9 2d __ LDA #$2d
124f : 85 13 __ STA P6 
1251 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1254 : 38 __ __ SEC
1255 : a9 00 __ LDA #$00
1257 : e5 57 __ SBC T2 + 0 
1259 : aa __ __ TAX
125a : a9 00 __ LDA #$00
125c : e5 58 __ SBC T2 + 1 
125e : a8 __ __ TAY
125f : a9 00 __ LDA #$00
1261 : e5 59 __ SBC T2 + 2 
1263 : 85 55 __ STA T0 + 2 
1265 : a9 00 __ LDA #$00
1267 : e5 5a __ SBC T2 + 3 
1269 : 85 56 __ STA T0 + 3 
126b : 4c 96 12 JMP $1296 ; (main.s68 + 0)
.s81:
126e : a9 20 __ LDA #$20
1270 : 85 13 __ STA P6 
1272 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1275 : a5 59 __ LDA T2 + 2 
1277 : 85 55 __ STA T0 + 2 
1279 : a4 58 __ LDY T2 + 1 
127b : a6 57 __ LDX T2 + 0 
127d : a5 5a __ LDA T2 + 3 
127f : 85 56 __ STA T0 + 3 
1281 : d0 13 __ BNE $1296 ; (main.s68 + 0)
.s83:
1283 : a5 59 __ LDA T2 + 2 
1285 : d0 0f __ BNE $1296 ; (main.s68 + 0)
.s84:
1287 : 98 __ __ TYA
1288 : d0 0c __ BNE $1296 ; (main.s68 + 0)
.s85:
128a : 8a __ __ TXA
128b : d0 09 __ BNE $1296 ; (main.s68 + 0)
.s82:
128d : e6 5b __ INC T3 + 0 
128f : a9 30 __ LDA #$30
1291 : 8d 78 9f STA $9f78 ; (tmp[0] + 0)
1294 : d0 60 __ BNE $12f6 ; (main.l71 + 0)
.s68:
1296 : a5 56 __ LDA T0 + 3 
1298 : 30 58 __ BMI $12f2 ; (main.s69 + 0)
.s77:
129a : d0 0a __ BNE $12a6 ; (main.l72 + 0)
.s78:
129c : a5 55 __ LDA T0 + 2 
129e : d0 06 __ BNE $12a6 ; (main.l72 + 0)
.s79:
12a0 : 98 __ __ TYA
12a1 : d0 03 __ BNE $12a6 ; (main.l72 + 0)
.s80:
12a3 : 8a __ __ TXA
12a4 : f0 4c __ BEQ $12f2 ; (main.s69 + 0)
.l72:
12a6 : a5 5b __ LDA T3 + 0 
12a8 : c9 17 __ CMP #$17
12aa : b0 46 __ BCS $12f2 ; (main.s69 + 0)
.s73:
12ac : 86 1b __ STX ACCU + 0 
12ae : 84 1c __ STY ACCU + 1 
12b0 : a5 55 __ LDA T0 + 2 
12b2 : 85 1d __ STA ACCU + 2 
12b4 : a5 56 __ LDA T0 + 3 
12b6 : 85 1e __ STA ACCU + 3 
12b8 : a9 00 __ LDA #$00
12ba : 85 04 __ STA WORK + 1 
12bc : 85 05 __ STA WORK + 2 
12be : 85 06 __ STA WORK + 3 
12c0 : a9 0a __ LDA #$0a
12c2 : 85 03 __ STA WORK + 0 
12c4 : 20 ec 20 JSR $20ec ; (divmod32 + 0)
12c7 : a5 1d __ LDA ACCU + 2 
12c9 : 85 55 __ STA T0 + 2 
12cb : a5 1e __ LDA ACCU + 3 
12cd : 85 56 __ STA T0 + 3 
12cf : 18 __ __ CLC
12d0 : a5 07 __ LDA WORK + 4 
12d2 : 69 30 __ ADC #$30
12d4 : a6 5b __ LDX T3 + 0 
12d6 : 9d 78 9f STA $9f78,x ; (tmp[0] + 0)
12d9 : a9 00 __ LDA #$00
12db : e6 5b __ INC T3 + 0 
12dd : a4 1c __ LDY ACCU + 1 
12df : a6 1b __ LDX ACCU + 0 
12e1 : c5 1e __ CMP ACCU + 3 
12e3 : 90 c1 __ BCC $12a6 ; (main.l72 + 0)
.s186:
12e5 : d0 0b __ BNE $12f2 ; (main.s69 + 0)
.s74:
12e7 : a5 1d __ LDA ACCU + 2 
12e9 : d0 bb __ BNE $12a6 ; (main.l72 + 0)
.s75:
12eb : 98 __ __ TYA
12ec : d0 b8 __ BNE $12a6 ; (main.l72 + 0)
.s76:
12ee : c4 1b __ CPY ACCU + 0 
12f0 : 90 b4 __ BCC $12a6 ; (main.l72 + 0)
.s69:
12f2 : a5 5b __ LDA T3 + 0 
12f4 : f0 0e __ BEQ $1304 ; (main.s70 + 0)
.l71:
12f6 : a6 5b __ LDX T3 + 0 
12f8 : bd 77 9f LDA $9f77,x ; (main@stack + 19)
12fb : 85 13 __ STA P6 
12fd : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1300 : c6 5b __ DEC T3 + 0 
1302 : d0 f2 __ BNE $12f6 ; (main.l71 + 0)
.s70:
1304 : a9 20 __ LDA #$20
1306 : 85 13 __ STA P6 
1308 : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
130b : a9 0d __ LDA #$0d
130d : 85 13 __ STA P6 
130f : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1312 : a9 00 __ LDA #$00
1314 : 85 1b __ STA ACCU + 0 
1316 : 85 1c __ STA ACCU + 1 
.s3:
1318 : a2 0f __ LDX #$0f
131a : bd 64 9f LDA $9f64,x ; (main@stack + 0)
131d : 95 53 __ STA T0 + 0,x 
131f : ca __ __ DEX
1320 : 10 f8 __ BPL $131a ; (main.s3 + 2)
1322 : 60 __ __ RTS
.s97:
1323 : c9 2e __ CMP #$2e
1325 : f0 03 __ BEQ $132a ; (main.s98 + 0)
1327 : 4c 8e 10 JMP $108e ; (main.s54 + 0)
.s98:
132a : a9 00 __ LDA #$00
132c : 9d a7 9f STA $9fa7,x ; (tmp[0] + 23)
132f : 4c 8e 10 JMP $108e ; (main.s54 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1332 : ad 04 22 LDA $2204 ; (b_mem + 0)
1335 : 85 43 __ STA T1 + 0 
1337 : 85 45 __ STA T2 + 0 
1339 : 85 1f __ STA ADDR + 0 
133b : ad 05 22 LDA $2205 ; (b_mem + 1)
133e : 85 44 __ STA T1 + 1 
1340 : 18 __ __ CLC
1341 : 69 dd __ ADC #$dd
1343 : 85 20 __ STA ADDR + 1 
1345 : a9 03 __ LDA #$03
1347 : a0 00 __ LDY #$00
1349 : 91 1f __ STA (ADDR + 0),y 
134b : 18 __ __ CLC
134c : a5 44 __ LDA T1 + 1 
134e : 69 d0 __ ADC #$d0
1350 : 85 20 __ STA ADDR + 1 
1352 : a9 15 __ LDA #$15
1354 : a0 18 __ LDY #$18
1356 : 91 1f __ STA (ADDR + 0),y 
1358 : 18 __ __ CLC
1359 : a5 44 __ LDA T1 + 1 
135b : 69 02 __ ADC #$02
135d : 85 20 __ STA ADDR + 1 
135f : a9 0e __ LDA #$0e
1361 : a0 86 __ LDY #$86
1363 : 91 1f __ STA (ADDR + 0),y 
1365 : 18 __ __ CLC
1366 : a5 44 __ LDA T1 + 1 
1368 : 69 d8 __ ADC #$d8
136a : 85 46 __ STA T2 + 1 
136c : a9 00 __ LDA #$00
136e : 85 47 __ STA T3 + 0 
1370 : 85 48 __ STA T3 + 1 
.l5:
1372 : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
1375 : 18 __ __ CLC
1376 : a5 43 __ LDA T1 + 0 
1378 : 65 1b __ ADC ACCU + 0 
137a : 85 1b __ STA ACCU + 0 
137c : a5 44 __ LDA T1 + 1 
137e : 65 1c __ ADC ACCU + 1 
1380 : 18 __ __ CLC
1381 : 65 48 __ ADC T3 + 1 
1383 : 85 1c __ STA ACCU + 1 
1385 : a9 20 __ LDA #$20
1387 : a4 47 __ LDY T3 + 0 
1389 : 91 1b __ STA (ACCU + 0),y 
138b : a9 0e __ LDA #$0e
138d : a0 00 __ LDY #$00
138f : 91 45 __ STA (T2 + 0),y 
1391 : e6 45 __ INC T2 + 0 
1393 : d0 02 __ BNE $1397 ; (b_init.s9 + 0)
.s8:
1395 : e6 46 __ INC T2 + 1 
.s9:
1397 : e6 47 __ INC T3 + 0 
1399 : d0 02 __ BNE $139d ; (b_init.s11 + 0)
.s10:
139b : e6 48 __ INC T3 + 1 
.s11:
139d : a5 48 __ LDA T3 + 1 
139f : c9 03 __ CMP #$03
13a1 : d0 cf __ BNE $1372 ; (b_init.l5 + 0)
.s7:
13a3 : a5 47 __ LDA T3 + 0 
13a5 : c9 e8 __ CMP #$e8
13a7 : d0 c9 __ BNE $1372 ; (b_init.l5 + 0)
.s6:
13a9 : a5 43 __ LDA T1 + 0 
13ab : 85 1f __ STA ADDR + 0 
13ad : a5 44 __ LDA T1 + 1 
13af : 69 cf __ ADC #$cf
13b1 : 85 20 __ STA ADDR + 1 
13b3 : a9 0e __ LDA #$0e
13b5 : a0 20 __ LDY #$20
13b7 : 91 1f __ STA (ADDR + 0),y 
13b9 : a9 06 __ LDA #$06
13bb : c8 __ __ INY
13bc : 91 1f __ STA (ADDR + 0),y 
13be : a9 00 __ LDA #$00
13c0 : a0 c6 __ LDY #$c6
13c2 : 91 43 __ STA (T1 + 0),y 
13c4 : 8d 08 22 STA $2208 ; (b_row + 0)
13c7 : 8d 09 22 STA $2209 ; (b_row + 1)
13ca : 8d 06 22 STA $2206 ; (b_col + 0)
13cd : 8d 07 22 STA $2207 ; (b_col + 1)
.s3:
13d0 : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
13d1 : ad 04 22 LDA $2204 ; (b_mem + 0)
13d4 : 85 1f __ STA ADDR + 0 
13d6 : ad 05 22 LDA $2205 ; (b_mem + 1)
13d9 : 18 __ __ CLC
13da : 69 dd __ ADC #$dd
13dc : 85 20 __ STA ADDR + 1 
13de : a0 00 __ LDY #$00
13e0 : 84 1b __ STY ACCU + 0 
13e2 : b1 1f __ LDA (ADDR + 0),y 
13e4 : 29 03 __ AND #$03
13e6 : 49 03 __ EOR #$03
13e8 : aa __ __ TAX
13e9 : 18 __ __ CLC
13ea : a5 1f __ LDA ADDR + 0 
13ec : 69 18 __ ADC #$18
13ee : 85 1f __ STA ADDR + 0 
13f0 : ad 05 22 LDA $2205 ; (b_mem + 1)
13f3 : 69 d0 __ ADC #$d0
13f5 : 85 20 __ STA ADDR + 1 
13f7 : b1 1f __ LDA (ADDR + 0),y 
13f9 : 29 f0 __ AND #$f0
13fb : 4a __ __ LSR
13fc : 4a __ __ LSR
13fd : 1d 00 22 ORA $2200,x ; (__multab16384H + 0)
1400 : 85 1c __ STA ACCU + 1 
.s3:
1402 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1282, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1403 : ad 0a 22 LDA $220a ; (tsb_inited + 0)
1406 : 0d 0b 22 ORA $220b ; (tsb_inited + 1)
1409 : d0 18 __ BNE $1423 ; (tsb_init.s3 + 0)
.s5:
140b : 85 0d __ STA P0 
140d : 85 0e __ STA P1 
140f : 85 10 __ STA P3 
1411 : a9 01 __ LDA #$01
1413 : 85 0f __ STA P2 
1415 : 8d 0a 22 STA $220a ; (tsb_inited + 0)
1418 : a9 00 __ LDA #$00
141a : 8d 0b 22 STA $220b ; (tsb_inited + 1)
141d : 20 24 14 JSR $1424 ; (tsb_init_tables.s4 + 0)
1420 : 4c 32 14 JMP $1432 ; (tsb_rot.s4 + 0)
.s3:
1423 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1270, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1424 : a2 00 __ LDX #$00
.l5:
1426 : bd 0c 22 LDA $220c,x ; (tab[0] + 0)
1429 : 9d 90 22 STA $2290,x ; (tsb_sintab[0] + 0)
142c : e8 __ __ INX
142d : e0 40 __ CPX #$40
142f : d0 f5 __ BNE $1426 ; (tsb_init_tables.l5 + 0)
.s3:
1431 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1432 : a5 0d __ LDA P0 ; (angle + 0)
1434 : 29 07 __ AND #$07
1436 : 0a __ __ ASL
1437 : 0a __ __ ASL
1438 : 0a __ __ ASL
1439 : aa __ __ TAX
143a : a9 00 __ LDA #$00
143c : 85 1b __ STA ACCU + 0 
.l5:
143e : 8a __ __ TXA
143f : 65 1b __ ADC ACCU + 0 
1441 : a8 __ __ TAY
1442 : b9 4c 22 LDA $224c,y ; (tsb_rottab[0] + 0)
1445 : a4 1b __ LDY ACCU + 0 
1447 : c8 __ __ INY
1448 : 84 1b __ STY ACCU + 0 
144a : 99 cf 22 STA $22cf,y ; (tsb_sintab[0] + 63)
144d : c0 08 __ CPY #$08
144f : 90 ed __ BCC $143e ; (tsb_rot.l5 + 0)
.s3:
1451 : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1452 : a5 13 __ LDA P6 ; (c + 0)
1454 : c9 93 __ CMP #$93
1456 : d0 03 __ BNE $145b ; (b_putc.s5 + 0)
1458 : 4c e9 14 JMP $14e9 ; (b_putc.s14 + 0)
.s5:
145b : c9 13 __ CMP #$13
145d : d0 0d __ BNE $146c ; (b_putc.s6 + 0)
.s13:
145f : a9 00 __ LDA #$00
1461 : 8d 08 22 STA $2208 ; (b_row + 0)
1464 : 8d 09 22 STA $2209 ; (b_row + 1)
1467 : 8d 06 22 STA $2206 ; (b_col + 0)
146a : f0 76 __ BEQ $14e2 ; (b_putc.s17 + 0)
.s6:
146c : c9 0d __ CMP #$0d
146e : f0 76 __ BEQ $14e6 ; (b_putc.s12 + 0)
.s7:
1470 : ad 07 22 LDA $2207 ; (b_col + 1)
1473 : 30 0c __ BMI $1481 ; (b_putc.s8 + 0)
.s11:
1475 : d0 07 __ BNE $147e ; (b_putc.s9 + 0)
.s10:
1477 : ad 06 22 LDA $2206 ; (b_col + 0)
147a : c9 28 __ CMP #$28
147c : 90 03 __ BCC $1481 ; (b_putc.s8 + 0)
.s9:
147e : 20 2d 15 JSR $152d ; (b_newline.s4 + 0)
.s8:
1481 : a5 13 __ LDA P6 ; (c + 0)
1483 : 20 89 16 JSR $1689 ; (b_pet2scr.s4 + 0)
1486 : 85 4e __ STA T3 + 0 
1488 : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
148b : ad 04 22 LDA $2204 ; (b_mem + 0)
148e : 18 __ __ CLC
148f : 65 1b __ ADC ACCU + 0 
1491 : 85 4a __ STA T1 + 0 
1493 : ad 05 22 LDA $2205 ; (b_mem + 1)
1496 : 65 1c __ ADC ACCU + 1 
1498 : 85 4b __ STA T1 + 1 
149a : ad 08 22 LDA $2208 ; (b_row + 0)
149d : 0a __ __ ASL
149e : 85 07 __ STA WORK + 4 
14a0 : ad 09 22 LDA $2209 ; (b_row + 1)
14a3 : 2a __ __ ROL
14a4 : 06 07 __ ASL WORK + 4 
14a6 : 2a __ __ ROL
14a7 : aa __ __ TAX
14a8 : 18 __ __ CLC
14a9 : a5 07 __ LDA WORK + 4 
14ab : 6d 08 22 ADC $2208 ; (b_row + 0)
14ae : 85 1b __ STA ACCU + 0 
14b0 : 8a __ __ TXA
14b1 : 6d 09 22 ADC $2209 ; (b_row + 1)
14b4 : 06 1b __ ASL ACCU + 0 
14b6 : 2a __ __ ROL
14b7 : 06 1b __ ASL ACCU + 0 
14b9 : 2a __ __ ROL
14ba : 06 1b __ ASL ACCU + 0 
14bc : 2a __ __ ROL
14bd : 85 1c __ STA ACCU + 1 
14bf : ad 06 22 LDA $2206 ; (b_col + 0)
14c2 : aa __ __ TAX
14c3 : 18 __ __ CLC
14c4 : 65 1b __ ADC ACCU + 0 
14c6 : a8 __ __ TAY
14c7 : ad 07 22 LDA $2207 ; (b_col + 1)
14ca : 85 4d __ STA T2 + 1 
14cc : 65 1c __ ADC ACCU + 1 
14ce : 18 __ __ CLC
14cf : 65 4b __ ADC T1 + 1 
14d1 : 85 4b __ STA T1 + 1 
14d3 : a5 4e __ LDA T3 + 0 
14d5 : 91 4a __ STA (T1 + 0),y 
14d7 : 8a __ __ TXA
14d8 : 18 __ __ CLC
14d9 : 69 01 __ ADC #$01
14db : 8d 06 22 STA $2206 ; (b_col + 0)
14de : a5 4d __ LDA T2 + 1 
14e0 : 69 00 __ ADC #$00
.s17:
14e2 : 8d 07 22 STA $2207 ; (b_col + 1)
.s3:
14e5 : 60 __ __ RTS
.s12:
14e6 : 4c 2d 15 JMP $152d ; (b_newline.s4 + 0)
.s14:
14e9 : a9 00 __ LDA #$00
14eb : 8d 08 22 STA $2208 ; (b_row + 0)
14ee : 8d 09 22 STA $2209 ; (b_row + 1)
14f1 : 8d 06 22 STA $2206 ; (b_col + 0)
14f4 : 8d 07 22 STA $2207 ; (b_col + 1)
14f7 : 85 4c __ STA T2 + 0 
14f9 : 85 4d __ STA T2 + 1 
.l15:
14fb : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
14fe : ad 04 22 LDA $2204 ; (b_mem + 0)
1501 : 18 __ __ CLC
1502 : 65 1b __ ADC ACCU + 0 
1504 : 85 4a __ STA T1 + 0 
1506 : ad 05 22 LDA $2205 ; (b_mem + 1)
1509 : 65 1c __ ADC ACCU + 1 
150b : 18 __ __ CLC
150c : 65 4d __ ADC T2 + 1 
150e : 85 4b __ STA T1 + 1 
1510 : a9 20 __ LDA #$20
1512 : a4 4c __ LDY T2 + 0 
1514 : 91 4a __ STA (T1 + 0),y 
1516 : 98 __ __ TYA
1517 : 18 __ __ CLC
1518 : 69 01 __ ADC #$01
151a : 85 4c __ STA T2 + 0 
151c : a5 4d __ LDA T2 + 1 
151e : 69 00 __ ADC #$00
1520 : 85 4d __ STA T2 + 1 
1522 : c9 03 __ CMP #$03
1524 : d0 d5 __ BNE $14fb ; (b_putc.l15 + 0)
.s16:
1526 : a5 4c __ LDA T2 + 0 
1528 : c9 e8 __ CMP #$e8
152a : d0 cf __ BNE $14fb ; (b_putc.l15 + 0)
152c : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
152d : a9 00 __ LDA #$00
152f : 8d 06 22 STA $2206 ; (b_col + 0)
1532 : 8d 07 22 STA $2207 ; (b_col + 1)
1535 : ad 08 22 LDA $2208 ; (b_row + 0)
1538 : aa __ __ TAX
1539 : 18 __ __ CLC
153a : 69 01 __ ADC #$01
153c : 8d 08 22 STA $2208 ; (b_row + 0)
153f : ad 09 22 LDA $2209 ; (b_row + 1)
1542 : a8 __ __ TAY
1543 : 69 00 __ ADC #$00
1545 : 8d 09 22 STA $2209 ; (b_row + 1)
1548 : 98 __ __ TYA
1549 : 30 13 __ BMI $155e ; (b_newline.s3 + 0)
.s7:
154b : d0 04 __ BNE $1551 ; (b_newline.s5 + 0)
.s6:
154d : e0 18 __ CPX #$18
154f : 90 0d __ BCC $155e ; (b_newline.s3 + 0)
.s5:
1551 : 20 5f 15 JSR $155f ; (b_scroll.s4 + 0)
1554 : a9 18 __ LDA #$18
1556 : 8d 08 22 STA $2208 ; (b_row + 0)
1559 : a9 00 __ LDA #$00
155b : 8d 09 22 STA $2209 ; (b_row + 1)
.s3:
155e : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
155f : a9 c0 __ LDA #$c0
1561 : 85 11 __ STA P4 
1563 : a9 03 __ LDA #$03
1565 : 85 12 __ STA P5 
1567 : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
156a : ad 04 22 LDA $2204 ; (b_mem + 0)
156d : 85 45 __ STA T1 + 0 
156f : 18 __ __ CLC
1570 : 65 1b __ ADC ACCU + 0 
1572 : 85 0d __ STA P0 
1574 : ad 05 22 LDA $2205 ; (b_mem + 1)
1577 : 85 46 __ STA T1 + 1 
1579 : 65 1c __ ADC ACCU + 1 
157b : 85 0e __ STA P1 
157d : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
1580 : 18 __ __ CLC
1581 : a5 45 __ LDA T1 + 0 
1583 : 65 1b __ ADC ACCU + 0 
1585 : aa __ __ TAX
1586 : a5 46 __ LDA T1 + 1 
1588 : 65 1c __ ADC ACCU + 1 
158a : a8 __ __ TAY
158b : 8a __ __ TXA
158c : 18 __ __ CLC
158d : 69 28 __ ADC #$28
158f : 85 0f __ STA P2 
1591 : 90 01 __ BCC $1594 ; (b_scroll.s7 + 0)
.s6:
1593 : c8 __ __ INY
.s7:
1594 : 84 10 __ STY P3 
1596 : 20 f4 15 JSR $15f4 ; (memmove.s4 + 0)
1599 : a9 03 __ LDA #$03
159b : 85 12 __ STA P5 
159d : 18 __ __ CLC
159e : a5 46 __ LDA T1 + 1 
15a0 : 69 d8 __ ADC #$d8
15a2 : 85 0e __ STA P1 
15a4 : a5 45 __ LDA T1 + 0 
15a6 : 85 0d __ STA P0 
15a8 : 18 __ __ CLC
15a9 : 69 28 __ ADC #$28
15ab : 85 0f __ STA P2 
15ad : a5 46 __ LDA T1 + 1 
15af : 69 d8 __ ADC #$d8
15b1 : 85 10 __ STA P3 
15b3 : 20 f4 15 JSR $15f4 ; (memmove.s4 + 0)
15b6 : 18 __ __ CLC
15b7 : a5 45 __ LDA T1 + 0 
15b9 : 69 c0 __ ADC #$c0
15bb : 85 47 __ STA T2 + 0 
15bd : a5 46 __ LDA T1 + 1 
15bf : 69 db __ ADC #$db
15c1 : 85 48 __ STA T2 + 1 
15c3 : a9 00 __ LDA #$00
15c5 : 85 49 __ STA T3 + 0 
.l5:
15c7 : 20 d1 13 JSR $13d1 ; (b_scr_base.s4 + 0)
15ca : 18 __ __ CLC
15cb : a5 45 __ LDA T1 + 0 
15cd : 65 1b __ ADC ACCU + 0 
15cf : a8 __ __ TAY
15d0 : a5 46 __ LDA T1 + 1 
15d2 : 65 1c __ ADC ACCU + 1 
15d4 : aa __ __ TAX
15d5 : 98 __ __ TYA
15d6 : 18 __ __ CLC
15d7 : 65 49 __ ADC T3 + 0 
15d9 : 85 1f __ STA ADDR + 0 
15db : 8a __ __ TXA
15dc : 69 03 __ ADC #$03
15de : 85 20 __ STA ADDR + 1 
15e0 : a9 20 __ LDA #$20
15e2 : a0 c0 __ LDY #$c0
15e4 : 91 1f __ STA (ADDR + 0),y 
15e6 : a9 0e __ LDA #$0e
15e8 : a4 49 __ LDY T3 + 0 
15ea : 91 47 __ STA (T2 + 0),y 
15ec : c8 __ __ INY
15ed : 84 49 __ STY T3 + 0 
15ef : c0 28 __ CPY #$28
15f1 : 90 d4 __ BCC $15c7 ; (b_scroll.l5 + 0)
.s3:
15f3 : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
15f4 : a5 12 __ LDA P5 ; (size + 1)
15f6 : 30 65 __ BMI $165d ; (memmove.s5 + 0)
.s14:
15f8 : 05 11 __ ORA P4 ; (size + 0)
15fa : f0 61 __ BEQ $165d ; (memmove.s5 + 0)
.s6:
15fc : a5 0d __ LDA P0 ; (dst + 0)
15fe : 85 1b __ STA ACCU + 0 
1600 : a5 0f __ LDA P2 ; (src + 0)
1602 : 85 43 __ STA T3 + 0 
1604 : a5 0e __ LDA P1 ; (dst + 1)
1606 : 85 1c __ STA ACCU + 1 
1608 : a6 10 __ LDX P3 ; (src + 1)
160a : 86 44 __ STX T3 + 1 
160c : c5 10 __ CMP P3 ; (src + 1)
160e : d0 04 __ BNE $1614 ; (memmove.s13 + 0)
.s12:
1610 : a5 0d __ LDA P0 ; (dst + 0)
1612 : c5 0f __ CMP P2 ; (src + 0)
.s13:
1614 : 90 50 __ BCC $1666 ; (memmove.s11 + 0)
.s7:
1616 : e4 0e __ CPX P1 ; (dst + 1)
1618 : d0 04 __ BNE $161e ; (memmove.s10 + 0)
.s9:
161a : a5 0f __ LDA P2 ; (src + 0)
161c : c5 0d __ CMP P0 ; (dst + 0)
.s10:
161e : b0 3d __ BCS $165d ; (memmove.s5 + 0)
.s8:
1620 : a5 0f __ LDA P2 ; (src + 0)
1622 : 65 11 __ ADC P4 ; (size + 0)
1624 : 85 43 __ STA T3 + 0 
1626 : 8a __ __ TXA
1627 : 65 12 __ ADC P5 ; (size + 1)
1629 : 85 44 __ STA T3 + 1 
162b : 18 __ __ CLC
162c : a5 0d __ LDA P0 ; (dst + 0)
162e : 65 11 __ ADC P4 ; (size + 0)
1630 : 85 1b __ STA ACCU + 0 
1632 : a5 0e __ LDA P1 ; (dst + 1)
1634 : 65 12 __ ADC P5 ; (size + 1)
1636 : 85 1c __ STA ACCU + 1 
1638 : a0 00 __ LDY #$00
163a : a5 11 __ LDA P4 ; (size + 0)
163c : f0 02 __ BEQ $1640 ; (memmove.s30 + 0)
.s16:
163e : e6 12 __ INC P5 ; (size + 1)
.s30:
1640 : a6 11 __ LDX P4 ; (size + 0)
.l19:
1642 : a5 43 __ LDA T3 + 0 
1644 : d0 02 __ BNE $1648 ; (memmove.s26 + 0)
.s25:
1646 : c6 44 __ DEC T3 + 1 
.s26:
1648 : c6 43 __ DEC T3 + 0 
164a : a5 1b __ LDA ACCU + 0 
164c : d0 02 __ BNE $1650 ; (memmove.s28 + 0)
.s27:
164e : c6 1c __ DEC ACCU + 1 
.s28:
1650 : c6 1b __ DEC ACCU + 0 
1652 : b1 43 __ LDA (T3 + 0),y 
1654 : 91 1b __ STA (ACCU + 0),y 
1656 : ca __ __ DEX
1657 : d0 e9 __ BNE $1642 ; (memmove.l19 + 0)
.s20:
1659 : c6 12 __ DEC P5 ; (size + 1)
165b : d0 e5 __ BNE $1642 ; (memmove.l19 + 0)
.s5:
165d : a5 0d __ LDA P0 ; (dst + 0)
165f : 85 1b __ STA ACCU + 0 
1661 : a5 0e __ LDA P1 ; (dst + 1)
1663 : 85 1c __ STA ACCU + 1 
.s3:
1665 : 60 __ __ RTS
.s11:
1666 : a0 00 __ LDY #$00
1668 : a5 11 __ LDA P4 ; (size + 0)
166a : f0 02 __ BEQ $166e ; (memmove.s29 + 0)
.s15:
166c : e6 12 __ INC P5 ; (size + 1)
.s29:
166e : a6 11 __ LDX P4 ; (size + 0)
.l17:
1670 : b1 43 __ LDA (T3 + 0),y 
1672 : 91 1b __ STA (ACCU + 0),y 
1674 : e6 43 __ INC T3 + 0 
1676 : d0 02 __ BNE $167a ; (memmove.s22 + 0)
.s21:
1678 : e6 44 __ INC T3 + 1 
.s22:
167a : e6 1b __ INC ACCU + 0 
167c : d0 02 __ BNE $1680 ; (memmove.s24 + 0)
.s23:
167e : e6 1c __ INC ACCU + 1 
.s24:
1680 : ca __ __ DEX
1681 : d0 ed __ BNE $1670 ; (memmove.l17 + 0)
.s18:
1683 : c6 12 __ DEC P5 ; (size + 1)
1685 : d0 e9 __ BNE $1670 ; (memmove.l17 + 0)
1687 : f0 d4 __ BEQ $165d ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1689 : c9 41 __ CMP #$41
168b : 90 06 __ BCC $1693 ; (b_pet2scr.s3 + 0)
.s8:
168d : c9 5b __ CMP #$5b
168f : b0 03 __ BCS $1694 ; (b_pet2scr.s5 + 0)
.s9:
1691 : e9 3f __ SBC #$3f
.s3:
1693 : 60 __ __ RTS
.s5:
1694 : c9 c1 __ CMP #$c1
1696 : 90 fb __ BCC $1693 ; (b_pet2scr.s3 + 0)
.s6:
1698 : c9 db __ CMP #$db
169a : b0 f7 __ BCS $1693 ; (b_pet2scr.s3 + 0)
.s7:
169c : e9 bf __ SBC #$bf
169e : 60 __ __ RTS
--------------------------------------------------------------------
b_jiffy: ; b_jiffy()->float
; 133, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
169f : ad 04 22 LDA $2204 ; (b_mem + 0)
16a2 : 85 43 __ STA T2 + 0 
16a4 : ad 05 22 LDA $2205 ; (b_mem + 1)
16a7 : 85 44 __ STA T2 + 1 
16a9 : a0 a2 __ LDY #$a2
16ab : b1 43 __ LDA (T2 + 0),y 
16ad : 85 1b __ STA ACCU + 0 
16af : 88 __ __ DEY
16b0 : b1 43 __ LDA (T2 + 0),y 
16b2 : 85 1c __ STA ACCU + 1 
16b4 : 88 __ __ DEY
16b5 : b1 43 __ LDA (T2 + 0),y 
16b7 : 85 1d __ STA ACCU + 2 
16b9 : a9 00 __ LDA #$00
16bb : 85 1e __ STA ACCU + 3 
16bd : 4c ee 1f JMP $1fee ; (uint32_to_float + 0)
--------------------------------------------------------------------
b_ftoa: ; b_ftoa(u8*,float)->void
; 559, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16c0 : a9 00 __ LDA #$00
16c2 : 85 49 __ STA T2 + 0 
16c4 : 85 4a __ STA T2 + 1 
16c6 : a5 0f __ LDA P2 ; (v + 0)
16c8 : 85 43 __ STA T0 + 0 
16ca : a5 10 __ LDA P3 ; (v + 1)
16cc : 85 44 __ STA T0 + 1 
16ce : a5 12 __ LDA P5 ; (v + 3)
16d0 : 29 7f __ AND #$7f
16d2 : 05 11 __ ORA P4 ; (v + 2)
16d4 : 05 10 __ ORA P3 ; (v + 1)
16d6 : a6 11 __ LDX P4 ; (v + 2)
16d8 : 86 45 __ STX T0 + 2 
16da : 05 0f __ ORA P2 ; (v + 0)
16dc : d0 05 __ BNE $16e3 ; (b_ftoa.s78 + 0)
.s127:
16de : a5 12 __ LDA P5 ; (v + 3)
16e0 : 4c ea 16 JMP $16ea ; (b_ftoa.s5 + 0)
.s78:
16e3 : a5 12 __ LDA P5 ; (v + 3)
16e5 : 10 03 __ BPL $16ea ; (b_ftoa.s5 + 0)
16e7 : 4c 17 1b JMP $1b17 ; (b_ftoa.s76 + 0)
.s5:
16ea : 29 7f __ AND #$7f
16ec : 05 11 __ ORA P4 ; (v + 2)
16ee : 05 10 __ ORA P3 ; (v + 1)
16f0 : 05 0f __ ORA P2 ; (v + 0)
16f2 : d0 03 __ BNE $16f7 ; (b_ftoa.s6 + 0)
16f4 : 4c 0c 1b JMP $1b0c ; (b_ftoa.s75 + 0)
.s6:
16f7 : a9 00 __ LDA #$00
.s7:
16f9 : 85 4b __ STA T3 + 0 
16fb : a5 12 __ LDA P5 ; (v + 3)
16fd : 85 46 __ STA T0 + 3 
16ff : 30 1c __ BMI $171d ; (b_ftoa.s8 + 0)
.s70:
1701 : c9 41 __ CMP #$41
1703 : d0 0d __ BNE $1712 ; (b_ftoa.s74 + 0)
.s71:
1705 : e0 20 __ CPX #$20
1707 : d0 09 __ BNE $1712 ; (b_ftoa.s74 + 0)
.s72:
1709 : a5 10 __ LDA P3 ; (v + 1)
170b : 38 __ __ SEC
170c : d0 04 __ BNE $1712 ; (b_ftoa.s74 + 0)
.s73:
170e : a5 0f __ LDA P2 ; (v + 0)
1710 : f0 02 __ BEQ $1714 ; (b_ftoa.s61 + 0)
.s74:
1712 : 90 09 __ BCC $171d ; (b_ftoa.s8 + 0)
.s61:
1714 : a9 00 __ LDA #$00
1716 : 85 47 __ STA T1 + 0 
1718 : 85 48 __ STA T1 + 1 
171a : 4c a6 1a JMP $1aa6 ; (b_ftoa.l62 + 0)
.s8:
171d : a5 12 __ LDA P5 ; (v + 3)
171f : 30 13 __ BMI $1734 ; (b_ftoa.s47 + 0)
.s56:
1721 : c9 3f __ CMP #$3f
1723 : d0 0d __ BNE $1732 ; (b_ftoa.s60 + 0)
.s57:
1725 : e0 80 __ CPX #$80
1727 : d0 09 __ BNE $1732 ; (b_ftoa.s60 + 0)
.s58:
1729 : a5 10 __ LDA P3 ; (v + 1)
172b : 38 __ __ SEC
172c : d0 04 __ BNE $1732 ; (b_ftoa.s60 + 0)
.s59:
172e : a5 0f __ LDA P2 ; (v + 0)
1730 : f0 5c __ BEQ $178e ; (b_ftoa.s9 + 0)
.s60:
1732 : b0 5a __ BCS $178e ; (b_ftoa.s9 + 0)
.s47:
1734 : a9 00 __ LDA #$00
1736 : 85 47 __ STA T1 + 0 
1738 : 85 48 __ STA T1 + 1 
.l48:
173a : a5 49 __ LDA T2 + 0 
173c : d0 02 __ BNE $1740 ; (b_ftoa.s92 + 0)
.s91:
173e : c6 4a __ DEC T2 + 1 
.s92:
1740 : c6 49 __ DEC T2 + 0 
1742 : a9 00 __ LDA #$00
1744 : 85 1b __ STA ACCU + 0 
1746 : 85 1c __ STA ACCU + 1 
1748 : a9 20 __ LDA #$20
174a : 85 1d __ STA ACCU + 2 
174c : a9 41 __ LDA #$41
174e : 85 1e __ STA ACCU + 3 
1750 : a2 43 __ LDX #$43
1752 : 20 d5 1b JSR $1bd5 ; (freg + 4)
1755 : 20 03 1d JSR $1d03 ; (crt_fmul + 0)
1758 : a5 1b __ LDA ACCU + 0 
175a : 85 43 __ STA T0 + 0 
175c : a5 1c __ LDA ACCU + 1 
175e : 85 44 __ STA T0 + 1 
1760 : a6 1d __ LDX ACCU + 2 
1762 : 86 45 __ STX T0 + 2 
1764 : a5 1e __ LDA ACCU + 3 
1766 : 85 46 __ STA T0 + 3 
1768 : 30 13 __ BMI $177d ; (b_ftoa.s49 + 0)
.s51:
176a : c9 3f __ CMP #$3f
176c : d0 0d __ BNE $177b ; (b_ftoa.s55 + 0)
.s52:
176e : e0 80 __ CPX #$80
1770 : d0 09 __ BNE $177b ; (b_ftoa.s55 + 0)
.s53:
1772 : a5 1c __ LDA ACCU + 1 
1774 : 38 __ __ SEC
1775 : d0 04 __ BNE $177b ; (b_ftoa.s55 + 0)
.s54:
1777 : a5 1b __ LDA ACCU + 0 
1779 : f0 13 __ BEQ $178e ; (b_ftoa.s9 + 0)
.s55:
177b : b0 11 __ BCS $178e ; (b_ftoa.s9 + 0)
.s49:
177d : e6 47 __ INC T1 + 0 
177f : d0 02 __ BNE $1783 ; (b_ftoa.s94 + 0)
.s93:
1781 : e6 48 __ INC T1 + 1 
.s94:
1783 : a6 48 __ LDX T1 + 1 
1785 : ca __ __ DEX
1786 : d0 b2 __ BNE $173a ; (b_ftoa.l48 + 0)
.s50:
1788 : a5 47 __ LDA T1 + 0 
178a : c9 90 __ CMP #$90
178c : d0 ac __ BNE $173a ; (b_ftoa.l48 + 0)
.s9:
178e : a9 08 __ LDA #$08
1790 : 85 4d __ STA T4 + 0 
1792 : a9 4c __ LDA #$4c
1794 : 85 1e __ STA ACCU + 3 
1796 : a9 20 __ LDA #$20
1798 : 85 1b __ STA ACCU + 0 
179a : a9 bc __ LDA #$bc
179c : 85 1c __ STA ACCU + 1 
179e : a9 be __ LDA #$be
17a0 : 85 1d __ STA ACCU + 2 
17a2 : a2 43 __ LDX #$43
17a4 : 20 d5 1b JSR $1bd5 ; (freg + 4)
17a7 : 20 03 1d JSR $1d03 ; (crt_fmul + 0)
17aa : a9 00 __ LDA #$00
17ac : 85 03 __ STA WORK + 0 
17ae : 85 04 __ STA WORK + 1 
17b0 : 85 05 __ STA WORK + 2 
17b2 : a9 3f __ LDA #$3f
17b4 : 85 06 __ STA WORK + 3 
17b6 : 20 e5 1b JSR $1be5 ; (freg + 20)
17b9 : 20 1c 1c JSR $1c1c ; (faddsub + 6)
17bc : 20 65 1f JSR $1f65 ; (f32_to_i32 + 0)
17bf : a5 1b __ LDA ACCU + 0 
17c1 : 85 43 __ STA T0 + 0 
17c3 : a5 1c __ LDA ACCU + 1 
17c5 : 85 44 __ STA T0 + 1 
17c7 : a5 1e __ LDA ACCU + 3 
17c9 : 85 46 __ STA T0 + 3 
17cb : 49 80 __ EOR #$80
17cd : a6 1d __ LDX ACCU + 2 
17cf : 86 45 __ STX T0 + 2 
17d1 : c9 bb __ CMP #$bb
17d3 : d0 0a __ BNE $17df ; (b_ftoa.s46 + 0)
.s44:
17d5 : e0 9a __ CPX #$9a
17d7 : d0 06 __ BNE $17df ; (b_ftoa.s46 + 0)
.s45:
17d9 : a5 1c __ LDA ACCU + 1 
17db : c9 ca __ CMP #$ca
17dd : f0 02 __ BEQ $17e1 ; (b_ftoa.s43 + 0)
.s46:
17df : 90 16 __ BCC $17f7 ; (b_ftoa.s10 + 0)
.s43:
17e1 : e6 49 __ INC T2 + 0 
17e3 : d0 02 __ BNE $17e7 ; (b_ftoa.s96 + 0)
.s95:
17e5 : e6 4a __ INC T2 + 1 
.s96:
17e7 : a9 00 __ LDA #$00
17e9 : 85 43 __ STA T0 + 0 
17eb : a9 e1 __ LDA #$e1
17ed : 85 44 __ STA T0 + 1 
17ef : a9 f5 __ LDA #$f5
17f1 : 85 45 __ STA T0 + 2 
17f3 : a9 05 __ LDA #$05
17f5 : 85 46 __ STA T0 + 3 
.s10:
17f7 : a5 43 __ LDA T0 + 0 
17f9 : 85 1b __ STA ACCU + 0 
17fb : a5 44 __ LDA T0 + 1 
17fd : 85 1c __ STA ACCU + 1 
17ff : a5 45 __ LDA T0 + 2 
1801 : 85 1d __ STA ACCU + 2 
1803 : a5 46 __ LDA T0 + 3 
1805 : 85 1e __ STA ACCU + 3 
.l79:
1807 : a9 00 __ LDA #$00
1809 : 85 04 __ STA WORK + 1 
180b : 85 05 __ STA WORK + 2 
180d : 85 06 __ STA WORK + 3 
180f : a9 0a __ LDA #$0a
1811 : 85 03 __ STA WORK + 0 
1813 : 20 c3 21 JSR $21c3 ; (mods32 + 0)
1816 : 18 __ __ CLC
1817 : a5 07 __ LDA WORK + 4 
1819 : 69 30 __ ADC #$30
181b : a6 4d __ LDX T4 + 0 
181d : 9d f0 9f STA $9ff0,x ; (d[0] + 0)
1820 : a5 43 __ LDA T0 + 0 
1822 : 85 1b __ STA ACCU + 0 
1824 : a5 44 __ LDA T0 + 1 
1826 : 85 1c __ STA ACCU + 1 
1828 : a5 45 __ LDA T0 + 2 
182a : 85 1d __ STA ACCU + 2 
182c : a5 46 __ LDA T0 + 3 
182e : 85 1e __ STA ACCU + 3 
1830 : a9 00 __ LDA #$00
1832 : 85 04 __ STA WORK + 1 
1834 : 85 05 __ STA WORK + 2 
1836 : 85 06 __ STA WORK + 3 
1838 : a9 0a __ LDA #$0a
183a : 85 03 __ STA WORK + 0 
183c : 20 9a 20 JSR $209a ; (divs32 + 0)
183f : a5 1b __ LDA ACCU + 0 
1841 : 85 43 __ STA T0 + 0 
1843 : a5 1c __ LDA ACCU + 1 
1845 : 85 44 __ STA T0 + 1 
1847 : a5 1d __ LDA ACCU + 2 
1849 : 85 45 __ STA T0 + 2 
184b : a5 1e __ LDA ACCU + 3 
184d : 85 46 __ STA T0 + 3 
184f : c6 4d __ DEC T4 + 0 
1851 : 10 b4 __ BPL $1807 ; (b_ftoa.l79 + 0)
.s11:
1853 : a9 00 __ LDA #$00
1855 : 8d f9 9f STA $9ff9 ; (d[0] + 9)
1858 : a2 09 __ LDX #$09
.l12:
185a : bd ef 9f LDA $9fef,x ; (eb[0] + 7)
185d : c9 30 __ CMP #$30
185f : d0 05 __ BNE $1866 ; (b_ftoa.s87 + 0)
.s42:
1861 : ca __ __ DEX
1862 : e0 02 __ CPX #$02
1864 : b0 f4 __ BCS $185a ; (b_ftoa.l12 + 0)
.s87:
1866 : 86 43 __ STX T0 + 0 
1868 : a5 4b __ LDA T3 + 0 
186a : f0 0d __ BEQ $1879 ; (b_ftoa.s13 + 0)
.s41:
186c : a9 2d __ LDA #$2d
186e : a0 00 __ LDY #$00
1870 : 91 0d __ STA (P0),y ; (buf + 0)
1872 : a9 01 __ LDA #$01
1874 : 85 47 __ STA T1 + 0 
1876 : 98 __ __ TYA
1877 : f0 02 __ BEQ $187b ; (b_ftoa.s14 + 0)
.s13:
1879 : 85 47 __ STA T1 + 0 
.s14:
187b : 85 48 __ STA T1 + 1 
187d : a5 4a __ LDA T2 + 1 
187f : 49 80 __ EOR #$80
1881 : c9 7f __ CMP #$7f
1883 : d0 04 __ BNE $1889 ; (b_ftoa.s40 + 0)
.s39:
1885 : a5 49 __ LDA T2 + 0 
1887 : c9 fc __ CMP #$fc
.s40:
1889 : b0 03 __ BCS $188e ; (b_ftoa.s26 + 0)
188b : 4c a8 19 JMP $19a8 ; (b_ftoa.s15 + 0)
.s26:
188e : a5 4a __ LDA T2 + 1 
1890 : 30 08 __ BMI $189a ; (b_ftoa.s27 + 0)
.s38:
1892 : d0 f7 __ BNE $188b ; (b_ftoa.s40 + 2)
.s37:
1894 : a5 49 __ LDA T2 + 0 
1896 : c9 09 __ CMP #$09
1898 : b0 f1 __ BCS $188b ; (b_ftoa.s40 + 2)
.s27:
189a : 18 __ __ CLC
189b : a5 0d __ LDA P0 ; (buf + 0)
189d : 65 47 __ ADC T1 + 0 
189f : 85 4d __ STA T4 + 0 
18a1 : a5 0e __ LDA P1 ; (buf + 1)
18a3 : 69 00 __ ADC #$00
18a5 : 85 4e __ STA T4 + 1 
18a7 : a5 49 __ LDA T2 + 0 
18a9 : 10 6f __ BPL $191a ; (b_ftoa.s31 + 0)
.s28:
18ab : a9 30 __ LDA #$30
18ad : a4 47 __ LDY T1 + 0 
18af : 91 0d __ STA (P0),y ; (buf + 0)
18b1 : a9 2e __ LDA #$2e
18b3 : a0 01 __ LDY #$01
18b5 : 91 4d __ STA (T4 + 0),y 
18b7 : a5 47 __ LDA T1 + 0 
18b9 : 09 02 __ ORA #$02
18bb : 85 47 __ STA T1 + 0 
18bd : a9 00 __ LDA #$00
18bf : 38 __ __ SEC
18c0 : e5 49 __ SBC T2 + 0 
18c2 : aa __ __ TAX
18c3 : ca __ __ DEX
18c4 : f0 22 __ BEQ $18e8 ; (b_ftoa.s29 + 0)
.s30:
18c6 : 18 __ __ CLC
18c7 : a5 0d __ LDA P0 ; (buf + 0)
18c9 : 65 47 __ ADC T1 + 0 
18cb : a8 __ __ TAY
18cc : a9 00 __ LDA #$00
18ce : 85 4d __ STA T4 + 0 
18d0 : a5 0e __ LDA P1 ; (buf + 1)
18d2 : 69 00 __ ADC #$00
18d4 : 85 4e __ STA T4 + 1 
.l84:
18d6 : a9 30 __ LDA #$30
18d8 : 91 4d __ STA (T4 + 0),y 
18da : e6 47 __ INC T1 + 0 
18dc : d0 02 __ BNE $18e0 ; (b_ftoa.s120 + 0)
.s119:
18de : e6 48 __ INC T1 + 1 
.s120:
18e0 : c8 __ __ INY
18e1 : d0 02 __ BNE $18e5 ; (b_ftoa.s122 + 0)
.s121:
18e3 : e6 4e __ INC T4 + 1 
.s122:
18e5 : ca __ __ DEX
18e6 : d0 ee __ BNE $18d6 ; (b_ftoa.l84 + 0)
.s29:
18e8 : a5 0d __ LDA P0 ; (buf + 0)
.s85:
18ea : 18 __ __ CLC
18eb : 65 47 __ ADC T1 + 0 
18ed : 85 4b __ STA T3 + 0 
18ef : a5 0e __ LDA P1 ; (buf + 1)
18f1 : 65 48 __ ADC T1 + 1 
18f3 : 85 4c __ STA T3 + 1 
18f5 : a0 00 __ LDY #$00
.l89:
18f7 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
18fa : 91 4b __ STA (T3 + 0),y 
18fc : e6 47 __ INC T1 + 0 
18fe : d0 02 __ BNE $1902 ; (b_ftoa.s112 + 0)
.s111:
1900 : e6 48 __ INC T1 + 1 
.s112:
1902 : c8 __ __ INY
1903 : e8 __ __ INX
1904 : e4 43 __ CPX T0 + 0 
1906 : 90 ef __ BCC $18f7 ; (b_ftoa.l89 + 0)
.s129:
1908 : a4 0d __ LDY P0 ; (buf + 0)
.s21:
190a : a5 47 __ LDA T1 + 0 
190c : 85 43 __ STA T0 + 0 
190e : 18 __ __ CLC
190f : a5 0e __ LDA P1 ; (buf + 1)
1911 : 65 48 __ ADC T1 + 1 
1913 : 85 44 __ STA T0 + 1 
1915 : a9 00 __ LDA #$00
1917 : 91 43 __ STA (T0 + 0),y 
.s3:
1919 : 60 __ __ RTS
.s31:
191a : 18 __ __ CLC
191b : 69 01 __ ADC #$01
191d : 85 1b __ STA ACCU + 0 
191f : c5 43 __ CMP T0 + 0 
1921 : a0 00 __ LDY #$00
1923 : 84 4f __ STY T5 + 0 
1925 : 90 44 __ BCC $196b ; (b_ftoa.l82 + 0)
.s34:
1927 : a2 00 __ LDX #$00
.l90:
1929 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
192c : 91 4d __ STA (T4 + 0),y 
192e : e6 47 __ INC T1 + 0 
1930 : d0 02 __ BNE $1934 ; (b_ftoa.s114 + 0)
.s113:
1932 : e6 48 __ INC T1 + 1 
.s114:
1934 : c8 __ __ INY
1935 : e8 __ __ INX
1936 : e4 43 __ CPX T0 + 0 
1938 : 90 ef __ BCC $1929 ; (b_ftoa.l90 + 0)
.s35:
193a : a5 49 __ LDA T2 + 0 
193c : c5 43 __ CMP T0 + 0 
193e : 90 c8 __ BCC $1908 ; (b_ftoa.s129 + 0)
.s36:
1940 : 18 __ __ CLC
1941 : a5 0d __ LDA P0 ; (buf + 0)
1943 : 65 47 __ ADC T1 + 0 
1945 : 85 4b __ STA T3 + 0 
1947 : a5 0e __ LDA P1 ; (buf + 1)
1949 : 65 48 __ ADC T1 + 1 
194b : 85 4c __ STA T3 + 1 
194d : a0 00 __ LDY #$00
194f : a6 47 __ LDX T1 + 0 
.l83:
1951 : a9 30 __ LDA #$30
1953 : 91 4b __ STA (T3 + 0),y 
1955 : e8 __ __ INX
1956 : d0 02 __ BNE $195a ; (b_ftoa.s116 + 0)
.s115:
1958 : e6 48 __ INC T1 + 1 
.s116:
195a : c8 __ __ INY
195b : d0 02 __ BNE $195f ; (b_ftoa.s118 + 0)
.s117:
195d : e6 4c __ INC T3 + 1 
.s118:
195f : e6 43 __ INC T0 + 0 
1961 : a5 49 __ LDA T2 + 0 
1963 : c5 43 __ CMP T0 + 0 
1965 : b0 ea __ BCS $1951 ; (b_ftoa.l83 + 0)
.s86:
1967 : 86 47 __ STX T1 + 0 
1969 : 90 9d __ BCC $1908 ; (b_ftoa.s129 + 0)
.l82:
196b : a6 4f __ LDX T5 + 0 
196d : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1970 : 91 4d __ STA (T4 + 0),y 
1972 : e6 47 __ INC T1 + 0 
1974 : d0 02 __ BNE $1978 ; (b_ftoa.s106 + 0)
.s105:
1976 : e6 48 __ INC T1 + 1 
.s106:
1978 : c8 __ __ INY
1979 : d0 02 __ BNE $197d ; (b_ftoa.s108 + 0)
.s107:
197b : e6 4e __ INC T4 + 1 
.s108:
197d : a5 49 __ LDA T2 + 0 
197f : e6 4f __ INC T5 + 0 
1981 : c5 4f __ CMP T5 + 0 
1983 : b0 e6 __ BCS $196b ; (b_ftoa.l82 + 0)
.s32:
1985 : a5 47 __ LDA T1 + 0 
1987 : 85 49 __ STA T2 + 0 
1989 : a5 0e __ LDA P1 ; (buf + 1)
198b : 65 48 __ ADC T1 + 1 
198d : 85 4a __ STA T2 + 1 
198f : a9 2e __ LDA #$2e
1991 : a4 0d __ LDY P0 ; (buf + 0)
1993 : 91 49 __ STA (T2 + 0),y 
1995 : e6 47 __ INC T1 + 0 
1997 : d0 02 __ BNE $199b ; (b_ftoa.s110 + 0)
.s109:
1999 : e6 48 __ INC T1 + 1 
.s110:
199b : a6 1b __ LDX ACCU + 0 
199d : e4 43 __ CPX T0 + 0 
199f : 90 03 __ BCC $19a4 ; (b_ftoa.s33 + 0)
19a1 : 4c 0a 19 JMP $190a ; (b_ftoa.s21 + 0)
.s33:
19a4 : 98 __ __ TYA
19a5 : 4c ea 18 JMP $18ea ; (b_ftoa.s85 + 0)
.s15:
19a8 : ad f0 9f LDA $9ff0 ; (d[0] + 0)
19ab : a4 47 __ LDY T1 + 0 
19ad : 91 0d __ STA (P0),y ; (buf + 0)
19af : e6 47 __ INC T1 + 0 
19b1 : a5 49 __ LDA T2 + 0 
19b3 : 85 4f __ STA T5 + 0 
19b5 : a5 4a __ LDA T2 + 1 
19b7 : 85 50 __ STA T5 + 1 
19b9 : e0 02 __ CPX #$02
19bb : 90 29 __ BCC $19e6 ; (b_ftoa.s16 + 0)
.s25:
19bd : a9 2e __ LDA #$2e
19bf : c8 __ __ INY
19c0 : 91 0d __ STA (P0),y ; (buf + 0)
19c2 : e6 47 __ INC T1 + 0 
19c4 : 18 __ __ CLC
19c5 : a5 47 __ LDA T1 + 0 
19c7 : 65 0d __ ADC P0 ; (buf + 0)
19c9 : 85 4d __ STA T4 + 0 
19cb : a5 0e __ LDA P1 ; (buf + 1)
19cd : 69 00 __ ADC #$00
19cf : 85 4e __ STA T4 + 1 
19d1 : a0 00 __ LDY #$00
19d3 : a2 01 __ LDX #$01
.l88:
19d5 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
19d8 : 91 4d __ STA (T4 + 0),y 
19da : e6 47 __ INC T1 + 0 
19dc : d0 02 __ BNE $19e0 ; (b_ftoa.s98 + 0)
.s97:
19de : e6 48 __ INC T1 + 1 
.s98:
19e0 : c8 __ __ INY
19e1 : e8 __ __ INX
19e2 : e4 43 __ CPX T0 + 0 
19e4 : 90 ef __ BCC $19d5 ; (b_ftoa.l88 + 0)
.s16:
19e6 : 18 __ __ CLC
19e7 : a5 0d __ LDA P0 ; (buf + 0)
19e9 : 65 47 __ ADC T1 + 0 
19eb : 85 43 __ STA T0 + 0 
19ed : a5 0e __ LDA P1 ; (buf + 1)
19ef : 65 48 __ ADC T1 + 1 
19f1 : 85 44 __ STA T0 + 1 
19f3 : a9 45 __ LDA #$45
19f5 : a0 00 __ LDY #$00
19f7 : 84 4d __ STY T4 + 0 
19f9 : 91 43 __ STA (T0 + 0),y 
19fb : 18 __ __ CLC
19fc : a5 47 __ LDA T1 + 0 
19fe : 69 02 __ ADC #$02
1a00 : 85 47 __ STA T1 + 0 
1a02 : 90 02 __ BCC $1a06 ; (b_ftoa.s100 + 0)
.s99:
1a04 : e6 48 __ INC T1 + 1 
.s100:
1a06 : a0 01 __ LDY #$01
1a08 : 24 4a __ BIT T2 + 1 
1a0a : 10 1c __ BPL $1a28 ; (b_ftoa.s17 + 0)
.s24:
1a0c : a9 2d __ LDA #$2d
1a0e : 91 43 __ STA (T0 + 0),y 
1a10 : 38 __ __ SEC
1a11 : a9 00 __ LDA #$00
1a13 : e5 49 __ SBC T2 + 0 
1a15 : 85 4f __ STA T5 + 0 
1a17 : a9 00 __ LDA #$00
1a19 : e5 4a __ SBC T2 + 1 
1a1b : 85 50 __ STA T5 + 1 
.s18:
1a1d : a5 4f __ LDA T5 + 0 
1a1f : 85 1b __ STA ACCU + 0 
1a21 : a5 50 __ LDA T5 + 1 
1a23 : 85 1c __ STA ACCU + 1 
1a25 : 4c 66 1a JMP $1a66 ; (b_ftoa.l80 + 0)
.s17:
1a28 : a9 2b __ LDA #$2b
1a2a : 91 43 __ STA (T0 + 0),y 
1a2c : a5 49 __ LDA T2 + 0 
1a2e : 05 4a __ ORA T2 + 1 
1a30 : d0 eb __ BNE $1a1d ; (b_ftoa.s18 + 0)
.s23:
1a32 : a9 30 __ LDA #$30
1a34 : 8d e8 9f STA $9fe8 ; (eb[0] + 0)
.s22:
1a37 : 8d e9 9f STA $9fe9 ; (eb[0] + 1)
1a3a : a9 02 __ LDA #$02
1a3c : 85 4d __ STA T4 + 0 
.s20:
1a3e : 18 __ __ CLC
1a3f : a5 0d __ LDA P0 ; (buf + 0)
1a41 : 65 47 __ ADC T1 + 0 
1a43 : a8 __ __ TAY
1a44 : a5 0e __ LDA P1 ; (buf + 1)
1a46 : 65 48 __ ADC T1 + 1 
1a48 : 85 4c __ STA T3 + 1 
1a4a : a9 00 __ LDA #$00
1a4c : 85 4b __ STA T3 + 0 
1a4e : a6 4d __ LDX T4 + 0 
.l81:
1a50 : bd e7 9f LDA $9fe7,x ; (buf[0] + 63)
1a53 : 91 4b __ STA (T3 + 0),y 
1a55 : e6 47 __ INC T1 + 0 
1a57 : d0 02 __ BNE $1a5b ; (b_ftoa.s102 + 0)
.s101:
1a59 : e6 48 __ INC T1 + 1 
.s102:
1a5b : c8 __ __ INY
1a5c : d0 02 __ BNE $1a60 ; (b_ftoa.s104 + 0)
.s103:
1a5e : e6 4c __ INC T3 + 1 
.s104:
1a60 : ca __ __ DEX
1a61 : d0 ed __ BNE $1a50 ; (b_ftoa.l81 + 0)
1a63 : 4c 08 19 JMP $1908 ; (b_ftoa.s129 + 0)
.l80:
1a66 : a9 0a __ LDA #$0a
1a68 : 85 03 __ STA WORK + 0 
1a6a : a9 00 __ LDA #$00
1a6c : 85 04 __ STA WORK + 1 
1a6e : 20 38 1f JSR $1f38 ; (mods16 + 0)
1a71 : 18 __ __ CLC
1a72 : a5 05 __ LDA WORK + 2 
1a74 : 69 30 __ ADC #$30
1a76 : a6 4d __ LDX T4 + 0 
1a78 : 9d e8 9f STA $9fe8,x ; (eb[0] + 0)
1a7b : a5 4f __ LDA T5 + 0 
1a7d : e6 4d __ INC T4 + 0 
1a7f : 85 1b __ STA ACCU + 0 
1a81 : a5 50 __ LDA T5 + 1 
1a83 : 85 1c __ STA ACCU + 1 
1a85 : a9 0a __ LDA #$0a
1a87 : 85 03 __ STA WORK + 0 
1a89 : a9 00 __ LDA #$00
1a8b : 85 04 __ STA WORK + 1 
1a8d : 20 79 1e JSR $1e79 ; (divs16 + 0)
1a90 : a5 1b __ LDA ACCU + 0 
1a92 : 85 4f __ STA T5 + 0 
1a94 : a5 1c __ LDA ACCU + 1 
1a96 : 85 50 __ STA T5 + 1 
1a98 : 05 1b __ ORA ACCU + 0 
1a9a : d0 ca __ BNE $1a66 ; (b_ftoa.l80 + 0)
.s19:
1a9c : a5 4d __ LDA T4 + 0 
1a9e : c9 02 __ CMP #$02
1aa0 : b0 9c __ BCS $1a3e ; (b_ftoa.s20 + 0)
.s128:
1aa2 : a9 30 __ LDA #$30
1aa4 : 90 91 __ BCC $1a37 ; (b_ftoa.s22 + 0)
.l62:
1aa6 : e6 49 __ INC T2 + 0 
1aa8 : d0 02 __ BNE $1aac ; (b_ftoa.s124 + 0)
.s123:
1aaa : e6 4a __ INC T2 + 1 
.s124:
1aac : a5 43 __ LDA T0 + 0 
1aae : 85 1b __ STA ACCU + 0 
1ab0 : a5 44 __ LDA T0 + 1 
1ab2 : 85 1c __ STA ACCU + 1 
1ab4 : a5 45 __ LDA T0 + 2 
1ab6 : 85 1d __ STA ACCU + 2 
1ab8 : a5 46 __ LDA T0 + 3 
1aba : 85 1e __ STA ACCU + 3 
1abc : a9 00 __ LDA #$00
1abe : 85 03 __ STA WORK + 0 
1ac0 : 85 04 __ STA WORK + 1 
1ac2 : a9 20 __ LDA #$20
1ac4 : 85 05 __ STA WORK + 2 
1ac6 : a9 41 __ LDA #$41
1ac8 : 85 06 __ STA WORK + 3 
1aca : 20 e5 1b JSR $1be5 ; (freg + 20)
1acd : 20 cb 1d JSR $1dcb ; (crt_fdiv + 0)
1ad0 : a5 1b __ LDA ACCU + 0 
1ad2 : 85 43 __ STA T0 + 0 
1ad4 : a5 1c __ LDA ACCU + 1 
1ad6 : 85 44 __ STA T0 + 1 
1ad8 : a6 1d __ LDX ACCU + 2 
1ada : 86 45 __ STX T0 + 2 
1adc : a5 1e __ LDA ACCU + 3 
1ade : 85 46 __ STA T0 + 3 
1ae0 : 10 03 __ BPL $1ae5 ; (b_ftoa.s65 + 0)
1ae2 : 4c 8e 17 JMP $178e ; (b_ftoa.s9 + 0)
.s65:
1ae5 : c9 41 __ CMP #$41
1ae7 : d0 0d __ BNE $1af6 ; (b_ftoa.s69 + 0)
.s66:
1ae9 : e0 20 __ CPX #$20
1aeb : d0 09 __ BNE $1af6 ; (b_ftoa.s69 + 0)
.s67:
1aed : a5 1c __ LDA ACCU + 1 
1aef : 38 __ __ SEC
1af0 : d0 04 __ BNE $1af6 ; (b_ftoa.s69 + 0)
.s68:
1af2 : a5 1b __ LDA ACCU + 0 
1af4 : f0 02 __ BEQ $1af8 ; (b_ftoa.s63 + 0)
.s69:
1af6 : 90 ea __ BCC $1ae2 ; (b_ftoa.s124 + 54)
.s63:
1af8 : e6 47 __ INC T1 + 0 
1afa : d0 02 __ BNE $1afe ; (b_ftoa.s126 + 0)
.s125:
1afc : e6 48 __ INC T1 + 1 
.s126:
1afe : a6 48 __ LDX T1 + 1 
1b00 : ca __ __ DEX
1b01 : d0 a3 __ BNE $1aa6 ; (b_ftoa.l62 + 0)
.s64:
1b03 : a5 47 __ LDA T1 + 0 
1b05 : c9 90 __ CMP #$90
1b07 : d0 9d __ BNE $1aa6 ; (b_ftoa.l62 + 0)
1b09 : 4c 8e 17 JMP $178e ; (b_ftoa.s9 + 0)
.s75:
1b0c : a9 30 __ LDA #$30
1b0e : a0 00 __ LDY #$00
1b10 : 91 0d __ STA (P0),y ; (buf + 0)
1b12 : 98 __ __ TYA
1b13 : c8 __ __ INY
1b14 : 91 0d __ STA (P0),y ; (buf + 0)
1b16 : 60 __ __ RTS
.s76:
1b17 : 49 80 __ EOR #$80
1b19 : 85 12 __ STA P5 ; (v + 3)
1b1b : 29 7f __ AND #$7f
1b1d : 05 11 __ ORA P4 ; (v + 2)
1b1f : 05 10 __ ORA P3 ; (v + 1)
1b21 : 05 0f __ ORA P2 ; (v + 0)
1b23 : f0 e7 __ BEQ $1b0c ; (b_ftoa.s75 + 0)
.s77:
1b25 : a9 01 __ LDA #$01
1b27 : 4c f9 16 JMP $16f9 ; (b_ftoa.s7 + 0)
--------------------------------------------------------------------
strchr: ; strchr(const u8*,i16)->u8*
;  18, "C:/Users/g/claude/c64/oscar64/include/string.h"
.l4:
1b2a : a0 00 __ LDY #$00
1b2c : b1 0d __ LDA (P0),y ; (str + 0)
1b2e : c5 0f __ CMP P2 ; (ch + 0)
1b30 : d0 09 __ BNE $1b3b ; (strchr.s6 + 0)
.s5:
1b32 : a5 0d __ LDA P0 ; (str + 0)
1b34 : 85 1b __ STA ACCU + 0 
1b36 : a5 0e __ LDA P1 ; (str + 1)
.s3:
1b38 : 85 1c __ STA ACCU + 1 
1b3a : 60 __ __ RTS
.s6:
1b3b : aa __ __ TAX
1b3c : f0 09 __ BEQ $1b47 ; (strchr.s7 + 0)
.s8:
1b3e : e6 0d __ INC P0 ; (str + 0)
1b40 : d0 e8 __ BNE $1b2a ; (strchr.l4 + 0)
.s9:
1b42 : e6 0e __ INC P1 ; (str + 1)
1b44 : 4c 2a 1b JMP $1b2a ; (strchr.l4 + 0)
.s7:
1b47 : 85 1b __ STA ACCU + 0 
1b49 : 4c 38 1b JMP $1b38 ; (strchr.s3 + 0)
--------------------------------------------------------------------
strlen: ; strlen(const u8*)->i16
;  12, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1b4c : a9 00 __ LDA #$00
1b4e : 85 1b __ STA ACCU + 0 
1b50 : 85 1c __ STA ACCU + 1 
1b52 : a8 __ __ TAY
1b53 : b1 0d __ LDA (P0),y ; (str + 0)
1b55 : f0 10 __ BEQ $1b67 ; (strlen.s3 + 0)
.s6:
1b57 : a2 00 __ LDX #$00
.l7:
1b59 : c8 __ __ INY
1b5a : d0 03 __ BNE $1b5f ; (strlen.s9 + 0)
.s8:
1b5c : e6 0e __ INC P1 ; (str + 1)
1b5e : e8 __ __ INX
.s9:
1b5f : b1 0d __ LDA (P0),y ; (str + 0)
1b61 : d0 f6 __ BNE $1b59 ; (strlen.l7 + 0)
.s5:
1b63 : 86 1c __ STX ACCU + 1 
1b65 : 84 1b __ STY ACCU + 0 
.s3:
1b67 : 60 __ __ RTS
--------------------------------------------------------------------
1b68 : __ __ __ BYT 47 45 4e 53 3d 00                               : GENS=.
--------------------------------------------------------------------
b_str: ; b_str(const u8*,i16)->void
; 539, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1b6e : a5 17 __ LDA P10 ; (len + 1)
1b70 : 30 21 __ BMI $1b93 ; (b_str.s3 + 0)
.s6:
1b72 : 05 16 __ ORA P9 ; (len + 0)
1b74 : f0 1d __ BEQ $1b93 ; (b_str.s3 + 0)
.l5:
1b76 : a0 00 __ LDY #$00
1b78 : b1 14 __ LDA (P7),y ; (s + 0)
1b7a : 85 13 __ STA P6 
1b7c : 20 52 14 JSR $1452 ; (b_putc.s4 + 0)
1b7f : e6 14 __ INC P7 ; (s + 0)
1b81 : d0 02 __ BNE $1b85 ; (b_str.s11 + 0)
.s10:
1b83 : e6 15 __ INC P8 ; (s + 1)
.s11:
1b85 : a5 16 __ LDA P9 ; (len + 0)
1b87 : d0 02 __ BNE $1b8b ; (b_str.s8 + 0)
.s7:
1b89 : c6 17 __ DEC P10 ; (len + 1)
.s8:
1b8b : c6 16 __ DEC P9 ; (len + 0)
1b8d : d0 e7 __ BNE $1b76 ; (b_str.l5 + 0)
.s9:
1b8f : a5 17 __ LDA P10 ; (len + 1)
1b91 : d0 e3 __ BNE $1b76 ; (b_str.l5 + 0)
.s3:
1b93 : 60 __ __ RTS
--------------------------------------------------------------------
1b94 : __ __ __ BYT 41 4c 49 56 45 3d 00                            : ALIVE=.
--------------------------------------------------------------------
mul32by8: ; mul32by8
1b9b : a0 00 __ LDY #$00
1b9d : 84 07 __ STY WORK + 4 
1b9f : 84 08 __ STY WORK + 5 
1ba1 : 84 09 __ STY WORK + 6 
1ba3 : 4a __ __ LSR
1ba4 : b0 0d __ BCS $1bb3 ; (mul32by8 + 24)
1ba6 : f0 26 __ BEQ $1bce ; (mul32by8 + 51)
1ba8 : 06 1b __ ASL ACCU + 0 
1baa : 26 1c __ ROL ACCU + 1 
1bac : 26 1d __ ROL ACCU + 2 
1bae : 26 1e __ ROL ACCU + 3 
1bb0 : 4a __ __ LSR
1bb1 : 90 f5 __ BCC $1ba8 ; (mul32by8 + 13)
1bb3 : aa __ __ TAX
1bb4 : 18 __ __ CLC
1bb5 : a5 07 __ LDA WORK + 4 
1bb7 : 65 1b __ ADC ACCU + 0 
1bb9 : 85 07 __ STA WORK + 4 
1bbb : a5 08 __ LDA WORK + 5 
1bbd : 65 1c __ ADC ACCU + 1 
1bbf : 85 08 __ STA WORK + 5 
1bc1 : a5 09 __ LDA WORK + 6 
1bc3 : 65 1d __ ADC ACCU + 2 
1bc5 : 85 09 __ STA WORK + 6 
1bc7 : 98 __ __ TYA
1bc8 : 65 1e __ ADC ACCU + 3 
1bca : a8 __ __ TAY
1bcb : 8a __ __ TXA
1bcc : d0 da __ BNE $1ba8 ; (mul32by8 + 13)
1bce : 84 0a __ STY WORK + 7 
1bd0 : 60 __ __ RTS
--------------------------------------------------------------------
freg: ; freg
1bd1 : b1 19 __ LDA (IP + 0),y 
1bd3 : c8 __ __ INY
1bd4 : aa __ __ TAX
1bd5 : b5 00 __ LDA $00,x 
1bd7 : 85 03 __ STA WORK + 0 
1bd9 : b5 01 __ LDA $01,x 
1bdb : 85 04 __ STA WORK + 1 
1bdd : b5 02 __ LDA $02,x 
1bdf : 85 05 __ STA WORK + 2 
1be1 : b5 03 __ LDA WORK + 0,x 
1be3 : 85 06 __ STA WORK + 3 
1be5 : a5 05 __ LDA WORK + 2 
1be7 : 0a __ __ ASL
1be8 : a5 06 __ LDA WORK + 3 
1bea : 2a __ __ ROL
1beb : 85 08 __ STA WORK + 5 
1bed : f0 06 __ BEQ $1bf5 ; (freg + 36)
1bef : a5 05 __ LDA WORK + 2 
1bf1 : 09 80 __ ORA #$80
1bf3 : 85 05 __ STA WORK + 2 
1bf5 : a5 1d __ LDA ACCU + 2 
1bf7 : 0a __ __ ASL
1bf8 : a5 1e __ LDA ACCU + 3 
1bfa : 2a __ __ ROL
1bfb : 85 07 __ STA WORK + 4 
1bfd : f0 06 __ BEQ $1c05 ; (freg + 52)
1bff : a5 1d __ LDA ACCU + 2 
1c01 : 09 80 __ ORA #$80
1c03 : 85 1d __ STA ACCU + 2 
1c05 : 60 __ __ RTS
1c06 : 06 1e __ ASL ACCU + 3 
1c08 : a5 07 __ LDA WORK + 4 
1c0a : 6a __ __ ROR
1c0b : 85 1e __ STA ACCU + 3 
1c0d : b0 06 __ BCS $1c15 ; (freg + 68)
1c0f : a5 1d __ LDA ACCU + 2 
1c11 : 29 7f __ AND #$7f
1c13 : 85 1d __ STA ACCU + 2 
1c15 : 60 __ __ RTS
--------------------------------------------------------------------
faddsub: ; faddsub
1c16 : a5 06 __ LDA WORK + 3 
1c18 : 49 80 __ EOR #$80
1c1a : 85 06 __ STA WORK + 3 
1c1c : a9 ff __ LDA #$ff
1c1e : c5 07 __ CMP WORK + 4 
1c20 : f0 04 __ BEQ $1c26 ; (faddsub + 16)
1c22 : c5 08 __ CMP WORK + 5 
1c24 : d0 11 __ BNE $1c37 ; (faddsub + 33)
1c26 : a5 1e __ LDA ACCU + 3 
1c28 : 09 7f __ ORA #$7f
1c2a : 85 1e __ STA ACCU + 3 
1c2c : a9 80 __ LDA #$80
1c2e : 85 1d __ STA ACCU + 2 
1c30 : a9 00 __ LDA #$00
1c32 : 85 1b __ STA ACCU + 0 
1c34 : 85 1c __ STA ACCU + 1 
1c36 : 60 __ __ RTS
1c37 : 38 __ __ SEC
1c38 : a5 07 __ LDA WORK + 4 
1c3a : e5 08 __ SBC WORK + 5 
1c3c : f0 38 __ BEQ $1c76 ; (faddsub + 96)
1c3e : aa __ __ TAX
1c3f : b0 25 __ BCS $1c66 ; (faddsub + 80)
1c41 : e0 e9 __ CPX #$e9
1c43 : b0 0e __ BCS $1c53 ; (faddsub + 61)
1c45 : a5 08 __ LDA WORK + 5 
1c47 : 85 07 __ STA WORK + 4 
1c49 : a9 00 __ LDA #$00
1c4b : 85 1b __ STA ACCU + 0 
1c4d : 85 1c __ STA ACCU + 1 
1c4f : 85 1d __ STA ACCU + 2 
1c51 : f0 23 __ BEQ $1c76 ; (faddsub + 96)
1c53 : a5 1d __ LDA ACCU + 2 
1c55 : 4a __ __ LSR
1c56 : 66 1c __ ROR ACCU + 1 
1c58 : 66 1b __ ROR ACCU + 0 
1c5a : e8 __ __ INX
1c5b : d0 f8 __ BNE $1c55 ; (faddsub + 63)
1c5d : 85 1d __ STA ACCU + 2 
1c5f : a5 08 __ LDA WORK + 5 
1c61 : 85 07 __ STA WORK + 4 
1c63 : 4c 76 1c JMP $1c76 ; (faddsub + 96)
1c66 : e0 18 __ CPX #$18
1c68 : b0 33 __ BCS $1c9d ; (faddsub + 135)
1c6a : a5 05 __ LDA WORK + 2 
1c6c : 4a __ __ LSR
1c6d : 66 04 __ ROR WORK + 1 
1c6f : 66 03 __ ROR WORK + 0 
1c71 : ca __ __ DEX
1c72 : d0 f8 __ BNE $1c6c ; (faddsub + 86)
1c74 : 85 05 __ STA WORK + 2 
1c76 : a5 1e __ LDA ACCU + 3 
1c78 : 29 80 __ AND #$80
1c7a : 85 1e __ STA ACCU + 3 
1c7c : 45 06 __ EOR WORK + 3 
1c7e : 30 31 __ BMI $1cb1 ; (faddsub + 155)
1c80 : 18 __ __ CLC
1c81 : a5 1b __ LDA ACCU + 0 
1c83 : 65 03 __ ADC WORK + 0 
1c85 : 85 1b __ STA ACCU + 0 
1c87 : a5 1c __ LDA ACCU + 1 
1c89 : 65 04 __ ADC WORK + 1 
1c8b : 85 1c __ STA ACCU + 1 
1c8d : a5 1d __ LDA ACCU + 2 
1c8f : 65 05 __ ADC WORK + 2 
1c91 : 85 1d __ STA ACCU + 2 
1c93 : 90 08 __ BCC $1c9d ; (faddsub + 135)
1c95 : 66 1d __ ROR ACCU + 2 
1c97 : 66 1c __ ROR ACCU + 1 
1c99 : 66 1b __ ROR ACCU + 0 
1c9b : e6 07 __ INC WORK + 4 
1c9d : a5 07 __ LDA WORK + 4 
1c9f : c9 ff __ CMP #$ff
1ca1 : f0 83 __ BEQ $1c26 ; (faddsub + 16)
1ca3 : 4a __ __ LSR
1ca4 : 05 1e __ ORA ACCU + 3 
1ca6 : 85 1e __ STA ACCU + 3 
1ca8 : b0 06 __ BCS $1cb0 ; (faddsub + 154)
1caa : a5 1d __ LDA ACCU + 2 
1cac : 29 7f __ AND #$7f
1cae : 85 1d __ STA ACCU + 2 
1cb0 : 60 __ __ RTS
1cb1 : 38 __ __ SEC
1cb2 : a5 1b __ LDA ACCU + 0 
1cb4 : e5 03 __ SBC WORK + 0 
1cb6 : 85 1b __ STA ACCU + 0 
1cb8 : a5 1c __ LDA ACCU + 1 
1cba : e5 04 __ SBC WORK + 1 
1cbc : 85 1c __ STA ACCU + 1 
1cbe : a5 1d __ LDA ACCU + 2 
1cc0 : e5 05 __ SBC WORK + 2 
1cc2 : 85 1d __ STA ACCU + 2 
1cc4 : b0 19 __ BCS $1cdf ; (faddsub + 201)
1cc6 : 38 __ __ SEC
1cc7 : a9 00 __ LDA #$00
1cc9 : e5 1b __ SBC ACCU + 0 
1ccb : 85 1b __ STA ACCU + 0 
1ccd : a9 00 __ LDA #$00
1ccf : e5 1c __ SBC ACCU + 1 
1cd1 : 85 1c __ STA ACCU + 1 
1cd3 : a9 00 __ LDA #$00
1cd5 : e5 1d __ SBC ACCU + 2 
1cd7 : 85 1d __ STA ACCU + 2 
1cd9 : a5 1e __ LDA ACCU + 3 
1cdb : 49 80 __ EOR #$80
1cdd : 85 1e __ STA ACCU + 3 
1cdf : a5 1d __ LDA ACCU + 2 
1ce1 : 30 ba __ BMI $1c9d ; (faddsub + 135)
1ce3 : 05 1c __ ORA ACCU + 1 
1ce5 : 05 1b __ ORA ACCU + 0 
1ce7 : f0 0f __ BEQ $1cf8 ; (faddsub + 226)
1ce9 : c6 07 __ DEC WORK + 4 
1ceb : f0 0b __ BEQ $1cf8 ; (faddsub + 226)
1ced : 06 1b __ ASL ACCU + 0 
1cef : 26 1c __ ROL ACCU + 1 
1cf1 : 26 1d __ ROL ACCU + 2 
1cf3 : 10 f4 __ BPL $1ce9 ; (faddsub + 211)
1cf5 : 4c 9d 1c JMP $1c9d ; (faddsub + 135)
1cf8 : a9 00 __ LDA #$00
1cfa : 85 1b __ STA ACCU + 0 
1cfc : 85 1c __ STA ACCU + 1 
1cfe : 85 1d __ STA ACCU + 2 
1d00 : 85 1e __ STA ACCU + 3 
1d02 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
1d03 : a5 1b __ LDA ACCU + 0 
1d05 : 05 1c __ ORA ACCU + 1 
1d07 : 05 1d __ ORA ACCU + 2 
1d09 : f0 0e __ BEQ $1d19 ; (crt_fmul + 22)
1d0b : a5 03 __ LDA WORK + 0 
1d0d : 05 04 __ ORA WORK + 1 
1d0f : 05 05 __ ORA WORK + 2 
1d11 : d0 09 __ BNE $1d1c ; (crt_fmul + 25)
1d13 : 85 1b __ STA ACCU + 0 
1d15 : 85 1c __ STA ACCU + 1 
1d17 : 85 1d __ STA ACCU + 2 
1d19 : 85 1e __ STA ACCU + 3 
1d1b : 60 __ __ RTS
1d1c : a5 1e __ LDA ACCU + 3 
1d1e : 45 06 __ EOR WORK + 3 
1d20 : 29 80 __ AND #$80
1d22 : 85 1e __ STA ACCU + 3 
1d24 : a9 ff __ LDA #$ff
1d26 : c5 07 __ CMP WORK + 4 
1d28 : f0 42 __ BEQ $1d6c ; (crt_fmul + 105)
1d2a : c5 08 __ CMP WORK + 5 
1d2c : f0 3e __ BEQ $1d6c ; (crt_fmul + 105)
1d2e : a9 00 __ LDA #$00
1d30 : 85 09 __ STA WORK + 6 
1d32 : 85 0a __ STA WORK + 7 
1d34 : 85 0b __ STA WORK + 8 
1d36 : a4 1b __ LDY ACCU + 0 
1d38 : a5 03 __ LDA WORK + 0 
1d3a : d0 06 __ BNE $1d42 ; (crt_fmul + 63)
1d3c : a5 04 __ LDA WORK + 1 
1d3e : f0 0a __ BEQ $1d4a ; (crt_fmul + 71)
1d40 : d0 05 __ BNE $1d47 ; (crt_fmul + 68)
1d42 : 20 9d 1d JSR $1d9d ; (crt_fmul8 + 0)
1d45 : a5 04 __ LDA WORK + 1 
1d47 : 20 9d 1d JSR $1d9d ; (crt_fmul8 + 0)
1d4a : a5 05 __ LDA WORK + 2 
1d4c : 20 9d 1d JSR $1d9d ; (crt_fmul8 + 0)
1d4f : 38 __ __ SEC
1d50 : a5 0b __ LDA WORK + 8 
1d52 : 30 06 __ BMI $1d5a ; (crt_fmul + 87)
1d54 : 06 09 __ ASL WORK + 6 
1d56 : 26 0a __ ROL WORK + 7 
1d58 : 2a __ __ ROL
1d59 : 18 __ __ CLC
1d5a : 29 7f __ AND #$7f
1d5c : 85 0b __ STA WORK + 8 
1d5e : a5 07 __ LDA WORK + 4 
1d60 : 65 08 __ ADC WORK + 5 
1d62 : 90 19 __ BCC $1d7d ; (crt_fmul + 122)
1d64 : e9 7f __ SBC #$7f
1d66 : b0 04 __ BCS $1d6c ; (crt_fmul + 105)
1d68 : c9 ff __ CMP #$ff
1d6a : d0 15 __ BNE $1d81 ; (crt_fmul + 126)
1d6c : a5 1e __ LDA ACCU + 3 
1d6e : 09 7f __ ORA #$7f
1d70 : 85 1e __ STA ACCU + 3 
1d72 : a9 80 __ LDA #$80
1d74 : 85 1d __ STA ACCU + 2 
1d76 : a9 00 __ LDA #$00
1d78 : 85 1b __ STA ACCU + 0 
1d7a : 85 1c __ STA ACCU + 1 
1d7c : 60 __ __ RTS
1d7d : e9 7e __ SBC #$7e
1d7f : 90 15 __ BCC $1d96 ; (crt_fmul + 147)
1d81 : 4a __ __ LSR
1d82 : 05 1e __ ORA ACCU + 3 
1d84 : 85 1e __ STA ACCU + 3 
1d86 : a9 00 __ LDA #$00
1d88 : 6a __ __ ROR
1d89 : 05 0b __ ORA WORK + 8 
1d8b : 85 1d __ STA ACCU + 2 
1d8d : a5 0a __ LDA WORK + 7 
1d8f : 85 1c __ STA ACCU + 1 
1d91 : a5 09 __ LDA WORK + 6 
1d93 : 85 1b __ STA ACCU + 0 
1d95 : 60 __ __ RTS
1d96 : a9 00 __ LDA #$00
1d98 : 85 1e __ STA ACCU + 3 
1d9a : f0 d8 __ BEQ $1d74 ; (crt_fmul + 113)
1d9c : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
1d9d : 38 __ __ SEC
1d9e : 6a __ __ ROR
1d9f : 90 1e __ BCC $1dbf ; (crt_fmul8 + 34)
1da1 : aa __ __ TAX
1da2 : 18 __ __ CLC
1da3 : 98 __ __ TYA
1da4 : 65 09 __ ADC WORK + 6 
1da6 : 85 09 __ STA WORK + 6 
1da8 : a5 0a __ LDA WORK + 7 
1daa : 65 1c __ ADC ACCU + 1 
1dac : 85 0a __ STA WORK + 7 
1dae : a5 0b __ LDA WORK + 8 
1db0 : 65 1d __ ADC ACCU + 2 
1db2 : 6a __ __ ROR
1db3 : 85 0b __ STA WORK + 8 
1db5 : 8a __ __ TXA
1db6 : 66 0a __ ROR WORK + 7 
1db8 : 66 09 __ ROR WORK + 6 
1dba : 4a __ __ LSR
1dbb : f0 0d __ BEQ $1dca ; (crt_fmul8 + 45)
1dbd : b0 e2 __ BCS $1da1 ; (crt_fmul8 + 4)
1dbf : 66 0b __ ROR WORK + 8 
1dc1 : 66 0a __ ROR WORK + 7 
1dc3 : 66 09 __ ROR WORK + 6 
1dc5 : 4a __ __ LSR
1dc6 : 90 f7 __ BCC $1dbf ; (crt_fmul8 + 34)
1dc8 : d0 d7 __ BNE $1da1 ; (crt_fmul8 + 4)
1dca : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
1dcb : a5 1b __ LDA ACCU + 0 
1dcd : 05 1c __ ORA ACCU + 1 
1dcf : 05 1d __ ORA ACCU + 2 
1dd1 : d0 03 __ BNE $1dd6 ; (crt_fdiv + 11)
1dd3 : 85 1e __ STA ACCU + 3 
1dd5 : 60 __ __ RTS
1dd6 : a5 1e __ LDA ACCU + 3 
1dd8 : 45 06 __ EOR WORK + 3 
1dda : 29 80 __ AND #$80
1ddc : 85 1e __ STA ACCU + 3 
1dde : a5 08 __ LDA WORK + 5 
1de0 : f0 62 __ BEQ $1e44 ; (crt_fdiv + 121)
1de2 : a5 07 __ LDA WORK + 4 
1de4 : c9 ff __ CMP #$ff
1de6 : f0 5c __ BEQ $1e44 ; (crt_fdiv + 121)
1de8 : a9 00 __ LDA #$00
1dea : 85 09 __ STA WORK + 6 
1dec : 85 0a __ STA WORK + 7 
1dee : 85 0b __ STA WORK + 8 
1df0 : a2 18 __ LDX #$18
1df2 : a5 1b __ LDA ACCU + 0 
1df4 : c5 03 __ CMP WORK + 0 
1df6 : a5 1c __ LDA ACCU + 1 
1df8 : e5 04 __ SBC WORK + 1 
1dfa : a5 1d __ LDA ACCU + 2 
1dfc : e5 05 __ SBC WORK + 2 
1dfe : 90 13 __ BCC $1e13 ; (crt_fdiv + 72)
1e00 : a5 1b __ LDA ACCU + 0 
1e02 : e5 03 __ SBC WORK + 0 
1e04 : 85 1b __ STA ACCU + 0 
1e06 : a5 1c __ LDA ACCU + 1 
1e08 : e5 04 __ SBC WORK + 1 
1e0a : 85 1c __ STA ACCU + 1 
1e0c : a5 1d __ LDA ACCU + 2 
1e0e : e5 05 __ SBC WORK + 2 
1e10 : 85 1d __ STA ACCU + 2 
1e12 : 38 __ __ SEC
1e13 : 26 09 __ ROL WORK + 6 
1e15 : 26 0a __ ROL WORK + 7 
1e17 : 26 0b __ ROL WORK + 8 
1e19 : ca __ __ DEX
1e1a : f0 0a __ BEQ $1e26 ; (crt_fdiv + 91)
1e1c : 06 1b __ ASL ACCU + 0 
1e1e : 26 1c __ ROL ACCU + 1 
1e20 : 26 1d __ ROL ACCU + 2 
1e22 : b0 dc __ BCS $1e00 ; (crt_fdiv + 53)
1e24 : 90 cc __ BCC $1df2 ; (crt_fdiv + 39)
1e26 : 38 __ __ SEC
1e27 : a5 0b __ LDA WORK + 8 
1e29 : 30 06 __ BMI $1e31 ; (crt_fdiv + 102)
1e2b : 06 09 __ ASL WORK + 6 
1e2d : 26 0a __ ROL WORK + 7 
1e2f : 2a __ __ ROL
1e30 : 18 __ __ CLC
1e31 : 29 7f __ AND #$7f
1e33 : 85 0b __ STA WORK + 8 
1e35 : a5 07 __ LDA WORK + 4 
1e37 : e5 08 __ SBC WORK + 5 
1e39 : 90 1a __ BCC $1e55 ; (crt_fdiv + 138)
1e3b : 18 __ __ CLC
1e3c : 69 7f __ ADC #$7f
1e3e : b0 04 __ BCS $1e44 ; (crt_fdiv + 121)
1e40 : c9 ff __ CMP #$ff
1e42 : d0 15 __ BNE $1e59 ; (crt_fdiv + 142)
1e44 : a5 1e __ LDA ACCU + 3 
1e46 : 09 7f __ ORA #$7f
1e48 : 85 1e __ STA ACCU + 3 
1e4a : a9 80 __ LDA #$80
1e4c : 85 1d __ STA ACCU + 2 
1e4e : a9 00 __ LDA #$00
1e50 : 85 1c __ STA ACCU + 1 
1e52 : 85 1b __ STA ACCU + 0 
1e54 : 60 __ __ RTS
1e55 : 69 7f __ ADC #$7f
1e57 : 90 15 __ BCC $1e6e ; (crt_fdiv + 163)
1e59 : 4a __ __ LSR
1e5a : 05 1e __ ORA ACCU + 3 
1e5c : 85 1e __ STA ACCU + 3 
1e5e : a9 00 __ LDA #$00
1e60 : 6a __ __ ROR
1e61 : 05 0b __ ORA WORK + 8 
1e63 : 85 1d __ STA ACCU + 2 
1e65 : a5 0a __ LDA WORK + 7 
1e67 : 85 1c __ STA ACCU + 1 
1e69 : a5 09 __ LDA WORK + 6 
1e6b : 85 1b __ STA ACCU + 0 
1e6d : 60 __ __ RTS
1e6e : a9 00 __ LDA #$00
1e70 : 85 1e __ STA ACCU + 3 
1e72 : 85 1d __ STA ACCU + 2 
1e74 : 85 1c __ STA ACCU + 1 
1e76 : 85 1b __ STA ACCU + 0 
1e78 : 60 __ __ RTS
--------------------------------------------------------------------
divs16: ; divs16
1e79 : 24 1c __ BIT ACCU + 1 
1e7b : 10 0d __ BPL $1e8a ; (divs16 + 17)
1e7d : 20 97 1e JSR $1e97 ; (negaccu + 0)
1e80 : 24 04 __ BIT WORK + 1 
1e82 : 10 0d __ BPL $1e91 ; (divs16 + 24)
1e84 : 20 a5 1e JSR $1ea5 ; (negtmp + 0)
1e87 : 4c b3 1e JMP $1eb3 ; (divmod + 0)
1e8a : 24 04 __ BIT WORK + 1 
1e8c : 10 f9 __ BPL $1e87 ; (divs16 + 14)
1e8e : 20 a5 1e JSR $1ea5 ; (negtmp + 0)
1e91 : 20 b3 1e JSR $1eb3 ; (divmod + 0)
1e94 : 4c 97 1e JMP $1e97 ; (negaccu + 0)
--------------------------------------------------------------------
negaccu: ; negaccu
1e97 : 38 __ __ SEC
1e98 : a9 00 __ LDA #$00
1e9a : e5 1b __ SBC ACCU + 0 
1e9c : 85 1b __ STA ACCU + 0 
1e9e : a9 00 __ LDA #$00
1ea0 : e5 1c __ SBC ACCU + 1 
1ea2 : 85 1c __ STA ACCU + 1 
1ea4 : 60 __ __ RTS
--------------------------------------------------------------------
negtmp: ; negtmp
1ea5 : 38 __ __ SEC
1ea6 : a9 00 __ LDA #$00
1ea8 : e5 03 __ SBC WORK + 0 
1eaa : 85 03 __ STA WORK + 0 
1eac : a9 00 __ LDA #$00
1eae : e5 04 __ SBC WORK + 1 
1eb0 : 85 04 __ STA WORK + 1 
1eb2 : 60 __ __ RTS
--------------------------------------------------------------------
divmod: ; divmod
1eb3 : a5 1c __ LDA ACCU + 1 
1eb5 : d0 31 __ BNE $1ee8 ; (divmod + 53)
1eb7 : a5 04 __ LDA WORK + 1 
1eb9 : d0 1e __ BNE $1ed9 ; (divmod + 38)
1ebb : 85 06 __ STA WORK + 3 
1ebd : a2 04 __ LDX #$04
1ebf : 06 1b __ ASL ACCU + 0 
1ec1 : 2a __ __ ROL
1ec2 : c5 03 __ CMP WORK + 0 
1ec4 : 90 02 __ BCC $1ec8 ; (divmod + 21)
1ec6 : e5 03 __ SBC WORK + 0 
1ec8 : 26 1b __ ROL ACCU + 0 
1eca : 2a __ __ ROL
1ecb : c5 03 __ CMP WORK + 0 
1ecd : 90 02 __ BCC $1ed1 ; (divmod + 30)
1ecf : e5 03 __ SBC WORK + 0 
1ed1 : 26 1b __ ROL ACCU + 0 
1ed3 : ca __ __ DEX
1ed4 : d0 eb __ BNE $1ec1 ; (divmod + 14)
1ed6 : 85 05 __ STA WORK + 2 
1ed8 : 60 __ __ RTS
1ed9 : a5 1b __ LDA ACCU + 0 
1edb : 85 05 __ STA WORK + 2 
1edd : a5 1c __ LDA ACCU + 1 
1edf : 85 06 __ STA WORK + 3 
1ee1 : a9 00 __ LDA #$00
1ee3 : 85 1b __ STA ACCU + 0 
1ee5 : 85 1c __ STA ACCU + 1 
1ee7 : 60 __ __ RTS
1ee8 : a5 04 __ LDA WORK + 1 
1eea : d0 1f __ BNE $1f0b ; (divmod + 88)
1eec : a5 03 __ LDA WORK + 0 
1eee : 30 1b __ BMI $1f0b ; (divmod + 88)
1ef0 : a9 00 __ LDA #$00
1ef2 : 85 06 __ STA WORK + 3 
1ef4 : a2 10 __ LDX #$10
1ef6 : 06 1b __ ASL ACCU + 0 
1ef8 : 26 1c __ ROL ACCU + 1 
1efa : 2a __ __ ROL
1efb : c5 03 __ CMP WORK + 0 
1efd : 90 02 __ BCC $1f01 ; (divmod + 78)
1eff : e5 03 __ SBC WORK + 0 
1f01 : 26 1b __ ROL ACCU + 0 
1f03 : 26 1c __ ROL ACCU + 1 
1f05 : ca __ __ DEX
1f06 : d0 f2 __ BNE $1efa ; (divmod + 71)
1f08 : 85 05 __ STA WORK + 2 
1f0a : 60 __ __ RTS
1f0b : a9 00 __ LDA #$00
1f0d : 85 05 __ STA WORK + 2 
1f0f : 85 06 __ STA WORK + 3 
1f11 : 84 02 __ STY $02 
1f13 : a0 10 __ LDY #$10
1f15 : 18 __ __ CLC
1f16 : 26 1b __ ROL ACCU + 0 
1f18 : 26 1c __ ROL ACCU + 1 
1f1a : 26 05 __ ROL WORK + 2 
1f1c : 26 06 __ ROL WORK + 3 
1f1e : 38 __ __ SEC
1f1f : a5 05 __ LDA WORK + 2 
1f21 : e5 03 __ SBC WORK + 0 
1f23 : aa __ __ TAX
1f24 : a5 06 __ LDA WORK + 3 
1f26 : e5 04 __ SBC WORK + 1 
1f28 : 90 04 __ BCC $1f2e ; (divmod + 123)
1f2a : 86 05 __ STX WORK + 2 
1f2c : 85 06 __ STA WORK + 3 
1f2e : 88 __ __ DEY
1f2f : d0 e5 __ BNE $1f16 ; (divmod + 99)
1f31 : 26 1b __ ROL ACCU + 0 
1f33 : 26 1c __ ROL ACCU + 1 
1f35 : a4 02 __ LDY $02 
1f37 : 60 __ __ RTS
--------------------------------------------------------------------
mods16: ; mods16
1f38 : 24 1c __ BIT ACCU + 1 
1f3a : 10 10 __ BPL $1f4c ; (mods16 + 20)
1f3c : 20 97 1e JSR $1e97 ; (negaccu + 0)
1f3f : 24 04 __ BIT WORK + 1 
1f41 : 10 03 __ BPL $1f46 ; (mods16 + 14)
1f43 : 20 a5 1e JSR $1ea5 ; (negtmp + 0)
1f46 : 20 b3 1e JSR $1eb3 ; (divmod + 0)
1f49 : 4c 57 1f JMP $1f57 ; (negtmpb + 0)
1f4c : 24 04 __ BIT WORK + 1 
1f4e : 10 03 __ BPL $1f53 ; (mods16 + 27)
1f50 : 20 a5 1e JSR $1ea5 ; (negtmp + 0)
1f53 : 4c b3 1e JMP $1eb3 ; (divmod + 0)
1f56 : 60 __ __ RTS
--------------------------------------------------------------------
negtmpb: ; negtmpb
1f57 : 38 __ __ SEC
1f58 : a9 00 __ LDA #$00
1f5a : e5 05 __ SBC WORK + 2 
1f5c : 85 05 __ STA WORK + 2 
1f5e : a9 00 __ LDA #$00
1f60 : e5 06 __ SBC WORK + 3 
1f62 : 85 06 __ STA WORK + 3 
1f64 : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
1f65 : a5 1e __ LDA ACCU + 3 
1f67 : 30 03 __ BMI $1f6c ; (f32_to_i32 + 7)
1f69 : 4c 89 1f JMP $1f89 ; (f32_to_u32 + 0)
1f6c : 20 89 1f JSR $1f89 ; (f32_to_u32 + 0)
1f6f : 38 __ __ SEC
1f70 : a9 00 __ LDA #$00
1f72 : e5 1b __ SBC ACCU + 0 
1f74 : 85 1b __ STA ACCU + 0 
1f76 : a9 00 __ LDA #$00
1f78 : e5 1c __ SBC ACCU + 1 
1f7a : 85 1c __ STA ACCU + 1 
1f7c : a9 00 __ LDA #$00
1f7e : e5 1d __ SBC ACCU + 2 
1f80 : 85 1d __ STA ACCU + 2 
1f82 : a9 00 __ LDA #$00
1f84 : e5 1e __ SBC ACCU + 3 
1f86 : 85 1e __ STA ACCU + 3 
1f88 : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
1f89 : 20 f5 1b JSR $1bf5 ; (freg + 36)
1f8c : a5 07 __ LDA WORK + 4 
1f8e : c9 7f __ CMP #$7f
1f90 : b0 0b __ BCS $1f9d ; (f32_to_u32 + 20)
1f92 : a9 00 __ LDA #$00
1f94 : 85 1b __ STA ACCU + 0 
1f96 : 85 1c __ STA ACCU + 1 
1f98 : 85 1d __ STA ACCU + 2 
1f9a : 85 1e __ STA ACCU + 3 
1f9c : 60 __ __ RTS
1f9d : 38 __ __ SEC
1f9e : e9 9e __ SBC #$9e
1fa0 : f0 13 __ BEQ $1fb5 ; (f32_to_u32 + 44)
1fa2 : 90 04 __ BCC $1fa8 ; (f32_to_u32 + 31)
1fa4 : a9 ff __ LDA #$ff
1fa6 : d0 ec __ BNE $1f94 ; (f32_to_u32 + 11)
1fa8 : aa __ __ TAX
1fa9 : a9 00 __ LDA #$00
1fab : 46 1d __ LSR ACCU + 2 
1fad : 66 1c __ ROR ACCU + 1 
1faf : 66 1b __ ROR ACCU + 0 
1fb1 : 6a __ __ ROR
1fb2 : e8 __ __ INX
1fb3 : d0 f6 __ BNE $1fab ; (f32_to_u32 + 34)
1fb5 : a6 1d __ LDX ACCU + 2 
1fb7 : 86 1e __ STX ACCU + 3 
1fb9 : a6 1c __ LDX ACCU + 1 
1fbb : 86 1d __ STX ACCU + 2 
1fbd : a6 1b __ LDX ACCU + 0 
1fbf : 86 1c __ STX ACCU + 1 
1fc1 : 85 1b __ STA ACCU + 0 
1fc3 : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
1fc4 : 24 1e __ BIT ACCU + 3 
1fc6 : 30 03 __ BMI $1fcb ; (sint32_to_float + 7)
1fc8 : 4c ee 1f JMP $1fee ; (uint32_to_float + 0)
1fcb : 38 __ __ SEC
1fcc : a9 00 __ LDA #$00
1fce : e5 1b __ SBC ACCU + 0 
1fd0 : 85 1b __ STA ACCU + 0 
1fd2 : a9 00 __ LDA #$00
1fd4 : e5 1c __ SBC ACCU + 1 
1fd6 : 85 1c __ STA ACCU + 1 
1fd8 : a9 00 __ LDA #$00
1fda : e5 1d __ SBC ACCU + 2 
1fdc : 85 1d __ STA ACCU + 2 
1fde : a9 00 __ LDA #$00
1fe0 : e5 1e __ SBC ACCU + 3 
1fe2 : 85 1e __ STA ACCU + 3 
1fe4 : 20 ee 1f JSR $1fee ; (uint32_to_float + 0)
1fe7 : a5 1e __ LDA ACCU + 3 
1fe9 : 09 80 __ ORA #$80
1feb : 85 1e __ STA ACCU + 3 
1fed : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
1fee : a5 1b __ LDA ACCU + 0 
1ff0 : 05 1c __ ORA ACCU + 1 
1ff2 : 05 1d __ ORA ACCU + 2 
1ff4 : 05 1e __ ORA ACCU + 3 
1ff6 : d0 01 __ BNE $1ff9 ; (uint32_to_float + 11)
1ff8 : 60 __ __ RTS
1ff9 : a2 9e __ LDX #$9e
1ffb : a5 1e __ LDA ACCU + 3 
1ffd : 30 0a __ BMI $2009 ; (uint32_to_float + 27)
1fff : ca __ __ DEX
2000 : 06 1b __ ASL ACCU + 0 
2002 : 26 1c __ ROL ACCU + 1 
2004 : 26 1d __ ROL ACCU + 2 
2006 : 2a __ __ ROL
2007 : 10 f6 __ BPL $1fff ; (uint32_to_float + 17)
2009 : 24 1b __ BIT ACCU + 0 
200b : 10 13 __ BPL $2020 ; (uint32_to_float + 50)
200d : e6 1c __ INC ACCU + 1 
200f : d0 0f __ BNE $2020 ; (uint32_to_float + 50)
2011 : e6 1d __ INC ACCU + 2 
2013 : d0 0b __ BNE $2020 ; (uint32_to_float + 50)
2015 : 18 __ __ CLC
2016 : 69 01 __ ADC #$01
2018 : 90 06 __ BCC $2020 ; (uint32_to_float + 50)
201a : 4a __ __ LSR
201b : 66 1d __ ROR ACCU + 2 
201d : 66 1c __ ROR ACCU + 1 
201f : e8 __ __ INX
2020 : 0a __ __ ASL
2021 : a4 1c __ LDY ACCU + 1 
2023 : 84 1b __ STY ACCU + 0 
2025 : a4 1d __ LDY ACCU + 2 
2027 : 84 1c __ STY ACCU + 1 
2029 : 85 1d __ STA ACCU + 2 
202b : 8a __ __ TXA
202c : 4a __ __ LSR
202d : 85 1e __ STA ACCU + 3 
202f : 66 1d __ ROR ACCU + 2 
2031 : 60 __ __ RTS
--------------------------------------------------------------------
mul32: ; mul32
2032 : a5 04 __ LDA WORK + 1 
2034 : 05 05 __ ORA WORK + 2 
2036 : 05 06 __ ORA WORK + 3 
2038 : d0 05 __ BNE $203f ; (mul32 + 13)
203a : a5 03 __ LDA WORK + 0 
203c : 4c 9b 1b JMP $1b9b ; (mul32by8 + 0)
203f : a0 00 __ LDY #$00
2041 : 84 07 __ STY WORK + 4 
2043 : 84 08 __ STY WORK + 5 
2045 : 98 __ __ TYA
2046 : 38 __ __ SEC
2047 : 66 03 __ ROR WORK + 0 
2049 : 90 15 __ BCC $2060 ; (mul32 + 46)
204b : aa __ __ TAX
204c : 18 __ __ CLC
204d : a5 07 __ LDA WORK + 4 
204f : 65 1b __ ADC ACCU + 0 
2051 : 85 07 __ STA WORK + 4 
2053 : a5 08 __ LDA WORK + 5 
2055 : 65 1c __ ADC ACCU + 1 
2057 : 85 08 __ STA WORK + 5 
2059 : 98 __ __ TYA
205a : 65 1d __ ADC ACCU + 2 
205c : a8 __ __ TAY
205d : 8a __ __ TXA
205e : 65 1e __ ADC ACCU + 3 
2060 : 46 04 __ LSR WORK + 1 
2062 : 90 0f __ BCC $2073 ; (mul32 + 65)
2064 : aa __ __ TAX
2065 : 18 __ __ CLC
2066 : a5 08 __ LDA WORK + 5 
2068 : 65 1b __ ADC ACCU + 0 
206a : 85 08 __ STA WORK + 5 
206c : 98 __ __ TYA
206d : 65 1c __ ADC ACCU + 1 
206f : a8 __ __ TAY
2070 : 8a __ __ TXA
2071 : 65 1d __ ADC ACCU + 2 
2073 : 46 05 __ LSR WORK + 2 
2075 : 90 09 __ BCC $2080 ; (mul32 + 78)
2077 : aa __ __ TAX
2078 : 18 __ __ CLC
2079 : 98 __ __ TYA
207a : 65 1b __ ADC ACCU + 0 
207c : a8 __ __ TAY
207d : 8a __ __ TXA
207e : 65 1c __ ADC ACCU + 1 
2080 : 46 06 __ LSR WORK + 3 
2082 : 90 03 __ BCC $2087 ; (mul32 + 85)
2084 : 18 __ __ CLC
2085 : 65 1b __ ADC ACCU + 0 
2087 : 06 1b __ ASL ACCU + 0 
2089 : 26 1c __ ROL ACCU + 1 
208b : 26 1d __ ROL ACCU + 2 
208d : 26 1e __ ROL ACCU + 3 
208f : 46 03 __ LSR WORK + 0 
2091 : 90 cd __ BCC $2060 ; (mul32 + 46)
2093 : d0 b6 __ BNE $204b ; (mul32 + 25)
2095 : 84 09 __ STY WORK + 6 
2097 : 85 0a __ STA WORK + 7 
2099 : 60 __ __ RTS
--------------------------------------------------------------------
divs32: ; divs32
209a : 24 1e __ BIT ACCU + 3 
209c : 10 0d __ BPL $20ab ; (divs32 + 17)
209e : 20 b8 20 JSR $20b8 ; (negaccu32 + 0)
20a1 : 24 06 __ BIT WORK + 3 
20a3 : 10 0d __ BPL $20b2 ; (divs32 + 24)
20a5 : 20 d2 20 JSR $20d2 ; (negtmp32 + 0)
20a8 : 4c ec 20 JMP $20ec ; (divmod32 + 0)
20ab : 24 06 __ BIT WORK + 3 
20ad : 10 f9 __ BPL $20a8 ; (divs32 + 14)
20af : 20 d2 20 JSR $20d2 ; (negtmp32 + 0)
20b2 : 20 ec 20 JSR $20ec ; (divmod32 + 0)
20b5 : 4c b8 20 JMP $20b8 ; (negaccu32 + 0)
--------------------------------------------------------------------
negaccu32: ; negaccu32
20b8 : 38 __ __ SEC
20b9 : a9 00 __ LDA #$00
20bb : e5 1b __ SBC ACCU + 0 
20bd : 85 1b __ STA ACCU + 0 
20bf : a9 00 __ LDA #$00
20c1 : e5 1c __ SBC ACCU + 1 
20c3 : 85 1c __ STA ACCU + 1 
20c5 : a9 00 __ LDA #$00
20c7 : e5 1d __ SBC ACCU + 2 
20c9 : 85 1d __ STA ACCU + 2 
20cb : a9 00 __ LDA #$00
20cd : e5 1e __ SBC ACCU + 3 
20cf : 85 1e __ STA ACCU + 3 
20d1 : 60 __ __ RTS
--------------------------------------------------------------------
negtmp32: ; negtmp32
20d2 : 38 __ __ SEC
20d3 : a9 00 __ LDA #$00
20d5 : e5 03 __ SBC WORK + 0 
20d7 : 85 03 __ STA WORK + 0 
20d9 : a9 00 __ LDA #$00
20db : e5 04 __ SBC WORK + 1 
20dd : 85 04 __ STA WORK + 1 
20df : a9 00 __ LDA #$00
20e1 : e5 05 __ SBC WORK + 2 
20e3 : 85 05 __ STA WORK + 2 
20e5 : a9 00 __ LDA #$00
20e7 : e5 06 __ SBC WORK + 3 
20e9 : 85 06 __ STA WORK + 3 
20eb : 60 __ __ RTS
--------------------------------------------------------------------
divmod32: ; divmod32
20ec : 84 02 __ STY $02 
20ee : a0 20 __ LDY #$20
20f0 : a9 00 __ LDA #$00
20f2 : 85 07 __ STA WORK + 4 
20f4 : 85 08 __ STA WORK + 5 
20f6 : 85 09 __ STA WORK + 6 
20f8 : 85 0a __ STA WORK + 7 
20fa : a5 05 __ LDA WORK + 2 
20fc : 05 06 __ ORA WORK + 3 
20fe : d0 78 __ BNE $2178 ; (divmod32 + 140)
2100 : a5 04 __ LDA WORK + 1 
2102 : d0 27 __ BNE $212b ; (divmod32 + 63)
2104 : 18 __ __ CLC
2105 : 26 1b __ ROL ACCU + 0 
2107 : 26 1c __ ROL ACCU + 1 
2109 : 26 1d __ ROL ACCU + 2 
210b : 26 1e __ ROL ACCU + 3 
210d : 2a __ __ ROL
210e : 90 05 __ BCC $2115 ; (divmod32 + 41)
2110 : e5 03 __ SBC WORK + 0 
2112 : 38 __ __ SEC
2113 : b0 06 __ BCS $211b ; (divmod32 + 47)
2115 : c5 03 __ CMP WORK + 0 
2117 : 90 02 __ BCC $211b ; (divmod32 + 47)
2119 : e5 03 __ SBC WORK + 0 
211b : 88 __ __ DEY
211c : d0 e7 __ BNE $2105 ; (divmod32 + 25)
211e : 85 07 __ STA WORK + 4 
2120 : 26 1b __ ROL ACCU + 0 
2122 : 26 1c __ ROL ACCU + 1 
2124 : 26 1d __ ROL ACCU + 2 
2126 : 26 1e __ ROL ACCU + 3 
2128 : a4 02 __ LDY $02 
212a : 60 __ __ RTS
212b : a5 1e __ LDA ACCU + 3 
212d : d0 10 __ BNE $213f ; (divmod32 + 83)
212f : a6 1d __ LDX ACCU + 2 
2131 : 86 1e __ STX ACCU + 3 
2133 : a6 1c __ LDX ACCU + 1 
2135 : 86 1d __ STX ACCU + 2 
2137 : a6 1b __ LDX ACCU + 0 
2139 : 86 1c __ STX ACCU + 1 
213b : 85 1b __ STA ACCU + 0 
213d : a0 18 __ LDY #$18
213f : 18 __ __ CLC
2140 : 26 1b __ ROL ACCU + 0 
2142 : 26 1c __ ROL ACCU + 1 
2144 : 26 1d __ ROL ACCU + 2 
2146 : 26 1e __ ROL ACCU + 3 
2148 : 26 07 __ ROL WORK + 4 
214a : 26 08 __ ROL WORK + 5 
214c : 90 0c __ BCC $215a ; (divmod32 + 110)
214e : a5 07 __ LDA WORK + 4 
2150 : e5 03 __ SBC WORK + 0 
2152 : aa __ __ TAX
2153 : a5 08 __ LDA WORK + 5 
2155 : e5 04 __ SBC WORK + 1 
2157 : 38 __ __ SEC
2158 : b0 0c __ BCS $2166 ; (divmod32 + 122)
215a : 38 __ __ SEC
215b : a5 07 __ LDA WORK + 4 
215d : e5 03 __ SBC WORK + 0 
215f : aa __ __ TAX
2160 : a5 08 __ LDA WORK + 5 
2162 : e5 04 __ SBC WORK + 1 
2164 : 90 04 __ BCC $216a ; (divmod32 + 126)
2166 : 86 07 __ STX WORK + 4 
2168 : 85 08 __ STA WORK + 5 
216a : 88 __ __ DEY
216b : d0 d3 __ BNE $2140 ; (divmod32 + 84)
216d : 26 1b __ ROL ACCU + 0 
216f : 26 1c __ ROL ACCU + 1 
2171 : 26 1d __ ROL ACCU + 2 
2173 : 26 1e __ ROL ACCU + 3 
2175 : a4 02 __ LDY $02 
2177 : 60 __ __ RTS
2178 : a0 10 __ LDY #$10
217a : a5 1e __ LDA ACCU + 3 
217c : 85 08 __ STA WORK + 5 
217e : a5 1d __ LDA ACCU + 2 
2180 : 85 07 __ STA WORK + 4 
2182 : a9 00 __ LDA #$00
2184 : 85 1d __ STA ACCU + 2 
2186 : 85 1e __ STA ACCU + 3 
2188 : 18 __ __ CLC
2189 : 26 1b __ ROL ACCU + 0 
218b : 26 1c __ ROL ACCU + 1 
218d : 26 07 __ ROL WORK + 4 
218f : 26 08 __ ROL WORK + 5 
2191 : 26 09 __ ROL WORK + 6 
2193 : 26 0a __ ROL WORK + 7 
2195 : a5 07 __ LDA WORK + 4 
2197 : c5 03 __ CMP WORK + 0 
2199 : a5 08 __ LDA WORK + 5 
219b : e5 04 __ SBC WORK + 1 
219d : a5 09 __ LDA WORK + 6 
219f : e5 05 __ SBC WORK + 2 
21a1 : aa __ __ TAX
21a2 : a5 0a __ LDA WORK + 7 
21a4 : e5 06 __ SBC WORK + 3 
21a6 : 90 11 __ BCC $21b9 ; (divmod32 + 205)
21a8 : 86 09 __ STX WORK + 6 
21aa : 85 0a __ STA WORK + 7 
21ac : a5 07 __ LDA WORK + 4 
21ae : e5 03 __ SBC WORK + 0 
21b0 : 85 07 __ STA WORK + 4 
21b2 : a5 08 __ LDA WORK + 5 
21b4 : e5 04 __ SBC WORK + 1 
21b6 : 85 08 __ STA WORK + 5 
21b8 : 38 __ __ SEC
21b9 : 88 __ __ DEY
21ba : d0 cd __ BNE $2189 ; (divmod32 + 157)
21bc : 26 1b __ ROL ACCU + 0 
21be : 26 1c __ ROL ACCU + 1 
21c0 : a4 02 __ LDY $02 
21c2 : 60 __ __ RTS
--------------------------------------------------------------------
mods32: ; mods32
21c3 : 24 1e __ BIT ACCU + 3 
21c5 : 10 13 __ BPL $21da ; (mods32 + 23)
21c7 : 20 b8 20 JSR $20b8 ; (negaccu32 + 0)
21ca : 24 06 __ BIT WORK + 3 
21cc : 10 03 __ BPL $21d1 ; (mods32 + 14)
21ce : 20 d2 20 JSR $20d2 ; (negtmp32 + 0)
21d1 : 20 ec 20 JSR $20ec ; (divmod32 + 0)
21d4 : 4c e4 21 JMP $21e4 ; (negtmp32b + 0)
21d7 : 4c ec 20 JMP $20ec ; (divmod32 + 0)
21da : 24 06 __ BIT WORK + 3 
21dc : 10 f9 __ BPL $21d7 ; (mods32 + 20)
21de : 20 d2 20 JSR $20d2 ; (negtmp32 + 0)
21e1 : 4c ec 20 JMP $20ec ; (divmod32 + 0)
--------------------------------------------------------------------
negtmp32b: ; negtmp32b
21e4 : 38 __ __ SEC
21e5 : a9 00 __ LDA #$00
21e7 : e5 07 __ SBC WORK + 4 
21e9 : 85 07 __ STA WORK + 4 
21eb : a9 00 __ LDA #$00
21ed : e5 08 __ SBC WORK + 5 
21ef : 85 08 __ STA WORK + 5 
21f1 : a9 00 __ LDA #$00
21f3 : e5 09 __ SBC WORK + 6 
21f5 : 85 09 __ STA WORK + 6 
21f7 : a9 00 __ LDA #$00
21f9 : e5 0a __ SBC WORK + 7 
21fb : 85 0a __ STA WORK + 7 
21fd : 60 __ __ RTS
--------------------------------------------------------------------
spentry:
21fe : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
__multab16384H:
2200 : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
b_mem:
2204 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
2206 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
2208 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
220a : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tab:
220c : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
221c : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
222c : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
223c : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
224c : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
225c : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
226c : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
227c : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
b_rndSeed:
228c : __ __ __ BYT 78 56 34 12                                     : xV4.
--------------------------------------------------------------------
tsb_sintab:
2290 : __ __ __ BSS	64
--------------------------------------------------------------------
tsb_drawtab:
22d0 : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_ri:
22d8 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_ci:
22da : __ __ __ BSS	2
--------------------------------------------------------------------
b_t_0:
22dc : __ __ __ BSS	4
--------------------------------------------------------------------
b_t_1:
22e0 : __ __ __ BSS	4
--------------------------------------------------------------------
b_t_2:
22e4 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_ki:
22e8 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_xi:
22ea : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_bbi:
22ec : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_yi:
22f0 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_nbi:
22f2 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_si:
22f6 : __ __ __ BSS	4
