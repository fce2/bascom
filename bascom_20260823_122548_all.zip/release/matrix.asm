; -- matrix.bas
; C64 BASIC V2 -> 6502  |  3502 bytes PRG, 29 source lines
	* = $0801
	; entry  $0D23   (10 SYS -> code)
	; vars   $1400 .. $15AF   (19 vars, 431 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$33,$33,$36,$33,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- float const pool ----

fconst0:
0813 :  .byte $90,$50,$20,$00,$00

fconst1:
0818 :  .byte $90,$50,$21,$00,$00

fconst2:
081D :  .byte $90,$58,$00,$00,$00

fconst3:
0822 :  .byte $85,$48,$00,$00,$00

fconst4:
0827 :  .byte $84,$20,$00,$00,$00

fconst5:
082C :  .byte $86,$68,$00,$00,$00

fconst6:
0831 :  .byte $83,$20,$00,$00,$00

fconst7:
0836 :  .byte $91,$00,$00,$00,$00

ftemp:
083B :  .res 5	; float temp slots

sp_save:
0840 :  .res 1	; entry SP (END/STOP unwind GOSUB frames)

ti_t1:
0841 :  .res 5	; TI read 5-byte float temp (24-bit jiffy->FAC hi-byte accum)

rnd_st:
0846 :  .res 2	; RT_rnd_fast 16-bit LFSR state (lo,hi)

rnd_k:
0848 :  .res 2	; RT_rnd_int K constant (lo,hi)
; ---- mulK lookup tables (speed-mode V*K strength reduction) ----

mulK40_lo:
084A :  .byte $00,$28,$50,$78,$A0,$C8,$F0,$18,$40,$68,$90,$B8,$E0,$08,$30,$58	; mulK lo bytes (i*K & 0xFF)
	.byte $80,$A8,$D0,$F8,$20,$48,$70,$98,$C0

mulK40_hi:
0863 :  .byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02	; mulK hi bytes (i*K >> 8)
	.byte $02,$02,$02,$02,$03,$03,$03,$03,$03
; ---- runtime helpers ----

RT_zero:
087C :  LDY #0 ; $00
087E :  LDX ZP_SCR16 + 1 ; $FE
0880 :  BEQ .z_tail

.z_page:
0882 :  LDA #0 ; $00

.z_pl:
0884 :  STA (ZP_PTR),Y ; $FB
0886 :  INY
0887 :  BNE .z_pl
0889 :  INC ZP_PTR + 1 ; $FC
088B :  DEX
088C :  BNE .z_page

.z_tail:

.z_tail:
088E :  LDX ZP_SCR16 ; $FD
0890 :  BEQ .z_done_l

.z_tl:
0892 :  LDA #0 ; $00
0894 :  STA (ZP_PTR),Y ; $FB
0896 :  INY
0897 :  DEX
0898 :  BNE .z_tl

.z_done_l:

.z_done_l:
089A :  RTS

RT_fmul_align:

RT_fmul:

RT_fadd:
0B44 :  JSR $BA8C
0B47 :  LDA $61
0B49 :  JMP RT_fmul_align ; $089B

RT_fsub:
0B4C :  JSR $BA8C
0B4F :  LDA $66
0B51 :  EOR #$FF
0B53 :  STA $66
0B55 :  EOR $6E
0B57 :  STA $6F
0B59 :  LDA $61
0B5B :  JMP RT_fmul_align ; $089B

RT_rnd_fast:
0B5E :  LDA FACEXP ; $61
0B60 :  BNE +3 ; FACEXP!=0 -> skip (long BEQ .seed_ti)
0B62 :  JMP .seed_ti

0B65 :  LDA 0x66 ; $66
0B67 :  BPL +3 ; arg>0 -> skip (long BMI .seed_arg)
0B69 :  JMP .seed_arg

.do_advance:
0B6C :  LDA rnd_st + 1 ; $0847
0B6F :  BNE .adv_lfsr
0B71 :  LDA rnd_st ; $0846
0B74 :  BNE .adv_lfsr
0B76 :  LDA 0xA1 ; $A1
0B78 :  STA rnd_st ; $0846
0B7B :  LDA 0xA2 ; $A2
0B7D :  STA rnd_st + 1 ; $0847
0B80 :  BNE .adv_lfsr
0B82 :  LDA rnd_st ; $0846
0B85 :  BNE .adv_lfsr
0B87 :  LDA #0xE1 ; $E1
0B89 :  STA rnd_st ; $0846
0B8C :  LDA #0xAC ; $AC
0B8E :  STA rnd_st + 1 ; $0847

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:
0B91 :  LDA rnd_st + 1 ; $0847
0B94 :  AND #1 ; $01
0B96 :  ASL
0B97 :  ASL
0B98 :  ASL
0B99 :  ASL
0B9A :  ASL
0B9B :  ASL
0B9C :  ASL
0B9D :  EOR rnd_st + 1 ; $0847
0BA0 :  STA rnd_st + 1 ; $0847
0BA3 :  LDA rnd_st ; $0846
0BA6 :  LSR
0BA7 :  EOR rnd_st + 1 ; $0847
0BAA :  STA rnd_st + 1 ; $0847
0BAD :  LDA rnd_st ; $0846
0BB0 :  AND #1 ; $01
0BB2 :  ASL
0BB3 :  ASL
0BB4 :  ASL
0BB5 :  ASL
0BB6 :  ASL
0BB7 :  ASL
0BB8 :  ASL
0BB9 :  EOR rnd_st ; $0846
0BBC :  STA rnd_st ; $0846
0BBF :  LDA rnd_st + 1 ; $0847
0BC2 :  LSR
0BC3 :  EOR rnd_st ; $0846
0BC6 :  STA rnd_st ; $0846
0BC9 :  LDA rnd_st + 1 ; $0847
0BCC :  EOR rnd_st ; $0846
0BCF :  STA rnd_st + 1 ; $0847
0BD2 :  BNE .rf_build
0BD4 :  LDA rnd_st ; $0846
0BD7 :  BEQ .to_zero

.rf_build:

.rf_build:
0BD9 :  LDA rnd_st + 1 ; $0847
0BDC :  STA 0x62 ; $62
0BDE :  LDA rnd_st ; $0846
0BE1 :  STA 0x63 ; $63
0BE3 :  LDA #0 ; $00
0BE5 :  STA 0x64 ; $64
0BE7 :  STA 0x65 ; $65
0BE9 :  STA 0x66 ; $66
0BEB :  LDA #128 ; $80
0BED :  STA FACEXP ; $61

.cvt_loop:
0BEF :  LDA 0x62 ; $62
0BF1 :  BMI .cvt_done
0BF3 :  ASL 0x65 ; $65
0BF5 :  ROL 0x64 ; $64
0BF7 :  ROL 0x63 ; $63
0BF9 :  ROL 0x62 ; $62
0BFB :  DEC FACEXP ; $61
0BFD :  JMP .cvt_loop ; $0BEF

.cvt_done:

.cvt_done:
0C00 :  RTS

.seed_ti:

.seed_ti:
0C01 :  LDA 0xA1 ; $A1
0C03 :  STA rnd_st ; $0846
0C06 :  LDA 0xA2 ; $A2
0C08 :  STA rnd_st + 1 ; $0847
0C0B :  JMP .do_advance ; $0B6C

.seed_arg:

.seed_arg:
0C0E :  LDA 0x63 ; $63
0C10 :  STA rnd_st ; $0846
0C13 :  LDA 0x64 ; $64
0C15 :  STA rnd_st + 1 ; $0847
0C18 :  JMP .do_advance ; $0B6C

.to_zero:

.to_zero:
0C1B :  LDA #0 ; $00
0C1D :  STA FACEXP ; $61
0C1F :  STA 0x62 ; $62
0C21 :  STA 0x63 ; $63
0C23 :  STA 0x64 ; $64
0C25 :  STA 0x65 ; $65
0C27 :  STA 0x66 ; $66
0C29 :  RTS

RT_rnd_int:
0C2A :  LDA rnd_st + 1 ; $0847
0C2D :  BNE .adv_int
0C2F :  LDA rnd_st ; $0846
0C32 :  BNE .adv_int
0C34 :  LDA 0xA1 ; $A1
0C36 :  STA rnd_st ; $0846
0C39 :  LDA 0xA2 ; $A2
0C3B :  STA rnd_st + 1 ; $0847
0C3E :  BNE .adv_int
0C40 :  LDA rnd_st ; $0846
0C43 :  BNE .adv_int
0C45 :  LDA #0xE1 ; $E1
0C47 :  STA rnd_st ; $0846
0C4A :  LDA #0xAC ; $AC
0C4C :  STA rnd_st + 1 ; $0847

.adv_int:

.adv_int:

.adv_int:

.adv_int:

.adv_int:
0C4F :  LDA rnd_st + 1 ; $0847
0C52 :  AND #1 ; $01
0C54 :  ASL
0C55 :  ASL
0C56 :  ASL
0C57 :  ASL
0C58 :  ASL
0C59 :  ASL
0C5A :  ASL
0C5B :  EOR rnd_st + 1 ; $0847
0C5E :  STA rnd_st + 1 ; $0847
0C61 :  LDA rnd_st ; $0846
0C64 :  LSR
0C65 :  EOR rnd_st + 1 ; $0847
0C68 :  STA rnd_st + 1 ; $0847
0C6B :  LDA rnd_st ; $0846
0C6E :  AND #1 ; $01
0C70 :  ASL
0C71 :  ASL
0C72 :  ASL
0C73 :  ASL
0C74 :  ASL
0C75 :  ASL
0C76 :  ASL
0C77 :  EOR rnd_st ; $0846
0C7A :  STA rnd_st ; $0846
0C7D :  LDA rnd_st + 1 ; $0847
0C80 :  LSR
0C81 :  EOR rnd_st ; $0846
0C84 :  STA rnd_st ; $0846
0C87 :  LDA rnd_st + 1 ; $0847
0C8A :  EOR rnd_st ; $0846
0C8D :  STA rnd_st + 1 ; $0847
0C90 :  LDA #0 ; $00
0C92 :  STA 0xFA ; $FA
0C94 :  STA 0xFB ; $FB
0C96 :  STA 0xFC ; $FC
0C98 :  STA 0xFD ; $FD
0C9A :  LDX #16 ; $10

.mul_loop:
0C9C :  LDA rnd_k + 1 ; $0849
0C9F :  AND #0x80 ; $80
0CA1 :  ASL rnd_k ; $0848
0CA4 :  ROL rnd_k+1 ; $0849
0CA7 :  ASL 0xFA ; $FA
0CA9 :  ROL 0xFB ; $FB
0CAB :  ROL 0xFC ; $FC
0CAD :  ROL 0xFD ; $FD
0CAF :  ASL
0CB0 :  BCC .skip_add
0CB2 :  CLC
0CB3 :  LDA 0xFA ; $FA
0CB5 :  ADC rnd_st ; $0846
0CB8 :  STA 0xFA ; $FA
0CBA :  LDA 0xFB ; $FB
0CBC :  ADC rnd_st + 1 ; $0847
0CBF :  STA 0xFB ; $FB
0CC1 :  LDA 0xFC ; $FC
0CC3 :  ADC #0 ; $00
0CC5 :  STA 0xFC ; $FC
0CC7 :  LDA 0xFD ; $FD
0CC9 :  ADC #0 ; $00
0CCB :  STA 0xFD ; $FD

.skip_add:

.skip_add:
0CCD :  DEX
0CCE :  BNE .mul_loop
0CD0 :  LDA 0xFC ; $FC
0CD2 :  LDX 0xFD ; $FD
0CD4 :  RTS

RT_ti_read:
0CD5 :  LDA #0 ; $00
0CD7 :  LDY 0xA0 ; $A0
0CD9 :  JSR ROM_INT_FAC ; $B391
0CDC :  LDA FACEXP ; $61
0CDE :  BEQ .ti_r_s1
0CE0 :  CLC
0CE1 :  ADC #16 ; $10
0CE3 :  STA FACEXP ; $61

.ti_r_s1:

.ti_r_s1:
0CE5 :  LDX #<addr ; $41
0CE7 :  LDY #>addr ; $08
0CE9 :  JSR ROM_FAC_MEM ; $BBD4
0CEC :  LDA #0 ; $00
0CEE :  LDY 0xA1 ; $A1
0CF0 :  JSR ROM_INT_FAC ; $B391
0CF3 :  LDA FACEXP ; $61
0CF5 :  BEQ .ti_r_s2
0CF7 :  CLC
0CF8 :  ADC #8 ; $08
0CFA :  STA FACEXP ; $61

.ti_r_s2:

.ti_r_s2:
0CFC :  LDA #<addr ; $41
0CFE :  LDY #>addr ; $08
0D00 :  JSR ROM_MEM_ARG ; $BA8C
0D03 :  LDA FACEXP ; $61
0D05 :  JSR ROM_PLUS ; $B86A
0D08 :  LDX #<addr ; $41
0D0A :  LDY #>addr ; $08
0D0C :  JSR ROM_FAC_MEM ; $BBD4
0D0F :  LDA #0 ; $00
0D11 :  LDY 0xA2 ; $A2
0D13 :  JSR ROM_INT_FAC ; $B391
0D16 :  LDA #<addr ; $41
0D18 :  LDY #>addr ; $08
0D1A :  JSR ROM_MEM_ARG ; $BA8C
0D1D :  LDA FACEXP ; $61
0D1F :  JSR ROM_PLUS ; $B86A
0D22 :  RTS

; ---- save entry SP (END/STOP unwinds GOSUB frames to return to KERNAL, like CBM clearing the GOSUB stack) ----
0D23 :  TSX
0D24 :  STX sp_save_addr ; $0840
; ---- zero variable area (bss excluded from PRG; runtime-init via RT_zero) ----
0D27 :  LDA #0 ; $00
0D29 :  STA ZP_PTR ; $FB
0D2B :  LDA #0 ; $00
0D2D :  STA ZP_PTR + 1 ; $FC
0D2F :  LDA #0 ; $00
0D31 :  STA ZP_SCR16 ; $FD
0D33 :  LDA #0 ; $00
0D35 :  STA ZP_SCR16 + 1 ; $FE
0D37 :  JSR RT_zero ; $087C
; ---- BASIC source ----
; 10    $0D3A  REM *** matrix digital rain - c64 ***
; 1,"matrix.bas"

L10:
; 20    $0D3A  REM white head, light-green body, green tail
; 2,"matrix.bas"

L20:
; 30    $0D3A  POKE 53280,0:POKE 53281,0
; 4,"matrix.bas"

L30:
0D3A :  LDA #(u8)s->e2->ival ; $00
0D3C :  STA ; $D020
0D3F :  LDA #(u8)s->e2->ival ; $00
0D41 :  STA ; $D021
; 40    $0D44  PRINT CHR$(147)
; 5,"matrix.bas"

L40:
0D44 :  LDA #LO(e->ival) ; $93
0D46 :  LDX #LO((e->ival >> 8)) ; $00
0D48 :  JSR ROM_CHROUT ; $FFD2
0D4B :  LDA #13 ; $0D
0D4D :  JSR ROM_CHROUT ; $FFD2
; 50    $0D50  SC=1024:CR=55296
; 7,"matrix.bas"

L50:
0D50 :  LDA #LO(e->ival) ; $00
0D52 :  LDX #LO((e->ival >> 8)) ; $04
0D54 :  STA SC
0D57 :  STX SC+1
0D5A :  LDA #LO(K) ; $00
0D5C :  LDX #HI(K) ; $D8
0D5E :  STA CR
0D61 :  STX CR+1
; 60    $0D64  DIM H(39):DIM E(39):DIM T(39):DIM CH(39):DIM D(39)
; 8,"matrix.bas"

L60:
; 70    $0D64  FOR C=0 TO 39
; 10,"matrix.bas"

L70:
0D64 :  LDA #LO(e->ival) ; $00
0D66 :  LDX #LO((e->ival >> 8)) ; $00
0D68 :  STA C
0D6B :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
0D6E :  STA ZP_MULMP ; $FA
0D70 :  STX ZP_SCR_HI ; $FF
0D72 :  ASL ZP_MULMP ; $FA
0D74 :  ROL ZP_SCR_HI ; $FF
0D76 :  CLC
0D77 :  LDA #<H
0D79 :  ADC ZP_MULMP ; $FA
0D7B :  STA ZP_PTR ; $FB
0D7D :  LDA #>H+1
0D7F :  ADC ZP_SCR_HI ; $FF
0D81 :  STA ZP_PTR + 1 ; $FC
0D83 :  LDA ZP_PTR ; $FB
0D85 :  STA LOPT0
0D88 :  LDA ZP_PTR + 1 ; $FC
0D8A :  STA LOPT0+1
0D8D :  CLC
0D8E :  LDA #<T_A
0D90 :  ADC ZP_MULMP ; $FA
0D92 :  STA ZP_PTR ; $FB
0D94 :  LDA #>T_A+1
0D96 :  ADC ZP_SCR_HI ; $FF
0D98 :  STA ZP_PTR + 1 ; $FC
0D9A :  LDA ZP_PTR ; $FB
0D9C :  STA LOPT1
0D9F :  LDA ZP_PTR + 1 ; $FC
0DA1 :  STA LOPT1+1
0DA4 :  CLC
0DA5 :  LDA #<E
0DA7 :  ADC ZP_MULMP ; $FA
0DA9 :  STA ZP_PTR ; $FB
0DAB :  LDA #>E+1
0DAD :  ADC ZP_SCR_HI ; $FF
0DAF :  STA ZP_PTR + 1 ; $FC
0DB1 :  LDA ZP_PTR ; $FB
0DB3 :  STA LOPT2
0DB6 :  LDA ZP_PTR + 1 ; $FC
0DB8 :  STA LOPT2+1
0DBB :  CLC
0DBC :  LDA #<CH
0DBE :  ADC ZP_MULMP ; $FA
0DC0 :  STA ZP_PTR ; $FB
0DC2 :  LDA #>CH+1
0DC4 :  ADC ZP_SCR_HI ; $FF
0DC6 :  STA ZP_PTR + 1 ; $FC
0DC8 :  LDA ZP_PTR ; $FB
0DCA :  STA LOPT3
0DCD :  LDA ZP_PTR + 1 ; $FC
0DCF :  STA LOPT3+1
0DD2 :  CLC
0DD3 :  LDA #<D
0DD5 :  ADC ZP_MULMP ; $FA
0DD7 :  STA ZP_PTR ; $FB
0DD9 :  LDA #>D+1
0DDB :  ADC ZP_SCR_HI ; $FF
0DDD :  STA ZP_PTR + 1 ; $FC
0DDF :  LDA ZP_PTR ; $FB
0DE1 :  STA LOPT4
0DE4 :  LDA ZP_PTR + 1 ; $FC
0DE6 :  STA LOPT4+1
; opt: range-byte-loop

.for_body:
; 80    $0DE9  H(C)=INT(RND(1)*25)
; 11,"matrix.bas"

L80:
0DE9 :  LDA #LO(K) ; $19
0DEB :  STA rnd_k ; $0848
0DEE :  LDA #HI(K) ; $00
0DF0 :  STA rnd_k + 1 ; $0849
0DF3 :  JSR RT_rnd_int ; $0C2A
0DF6 :  PHA
0DF7 :  LDA LOPT0
0DFA :  STA ZP_PTR ; $FB
0DFC :  LDA LOPT0+1
0DFF :  STA ZP_PTR + 1 ; $FC
0E01 :  PLA
0E02 :  LDY #0 ; $00
0E04 :  STA (ZP_PTR),Y ; $FB
0E06 :  INY
0E07 :  TXA
0E08 :  STA (ZP_PTR),Y ; $FB
; 90    $0E0A  T(C)=5+INT(RND(1)*10)
; 12,"matrix.bas"

L90:
0E0A :  LDA #LO(e->ival) ; $05
0E0C :  LDX #LO((e->ival >> 8)) ; $00
0E0E :  STA slot+0
0E10 :  LDA #LO(K) ; $0A
0E12 :  STA rnd_k ; $0848
0E15 :  LDA #HI(K) ; $00
0E17 :  STA rnd_k + 1 ; $0849
0E1A :  JSR RT_rnd_int ; $0C2A
0E1D :  CLC
0E1E :  ADC slot+0
0E20 :  LDX #0 ; $00
0E22 :  PHA
0E23 :  LDA LOPT1
0E26 :  STA ZP_PTR ; $FB
0E28 :  LDA LOPT1+1
0E2B :  STA ZP_PTR + 1 ; $FC
0E2D :  PLA
0E2E :  LDY #0 ; $00
0E30 :  STA (ZP_PTR),Y ; $FB
0E32 :  INY
0E33 :  TXA
0E34 :  STA (ZP_PTR),Y ; $FB
; 100   $0E36  E(C)=H(C)-T(C):IF E(C)<0 THEN E(C)=E(C)+25
; 13,"matrix.bas"

L100:
0E36 :  LDA LOPT1
0E39 :  STA ZP_PTR ; $FB
0E3B :  LDA LOPT1+1
0E3E :  STA ZP_PTR + 1 ; $FC
0E40 :  LDY #0 ; $00
0E42 :  LDA (ZP_PTR),Y ; $FB
0E44 :  STA ZP_SCR16 ; $FD
0E46 :  INY
0E47 :  LAX (ZP_PTR),Y ; $FB
0E49 :  LDA ZP_SCR16 ; $FD
0E4B :  STA slot+0
0E4D :  STX slot+1
0E4F :  LDA LOPT0
0E52 :  STA ZP_PTR ; $FB
0E54 :  LDA LOPT0+1
0E57 :  STA ZP_PTR + 1 ; $FC
0E59 :  LDY #0 ; $00
0E5B :  LDA (ZP_PTR),Y ; $FB
0E5D :  STA ZP_SCR16 ; $FD
0E5F :  INY
0E60 :  LAX (ZP_PTR),Y ; $FB
0E62 :  LDA ZP_SCR16 ; $FD
0E64 :  SEC
0E65 :  SBC slot+0
0E67 :  PHA
0E68 :  TXA
0E69 :  SBC slot+1
0E6B :  TAX
0E6C :  PLA
0E6D :  PHA
0E6E :  LDA LOPT2
0E71 :  STA ZP_PTR ; $FB
0E73 :  LDA LOPT2+1
0E76 :  STA ZP_PTR + 1 ; $FC
0E78 :  PLA
0E79 :  LDY #0 ; $00
0E7B :  STA (ZP_PTR),Y ; $FB
0E7D :  INY
0E7E :  TXA
0E7F :  STA (ZP_PTR),Y ; $FB
0E81 :  LDA LOPT2
0E84 :  STA ZP_PTR ; $FB
0E86 :  LDA LOPT2+1
0E89 :  STA ZP_PTR + 1 ; $FC
0E8B :  LDY #0 ; $00
0E8D :  LDA (ZP_PTR),Y ; $FB
0E8F :  STA ZP_SCR16 ; $FD
0E91 :  INY
0E92 :  LAX (ZP_PTR),Y ; $FB
0E94 :  LDA ZP_SCR16 ; $FD
0E96 :  STX ZP_SCR16 + 1 ; $FE
0E98 :  LDA ZP_SCR16 + 1 ; $FE
0E9A :  BMI +3 ; long IF-skip (body >127B)
0E9C :  JMP .if_skip

0E9F :  LDA LOPT2
0EA2 :  STA ZP_PTR ; $FB
0EA4 :  LDA LOPT2+1
0EA7 :  STA ZP_PTR + 1 ; $FC
0EA9 :  LDY #0 ; $00
0EAB :  LDA (ZP_PTR),Y ; $FB
0EAD :  STA ZP_SCR16 ; $FD
0EAF :  INY
0EB0 :  LAX (ZP_PTR),Y ; $FB
0EB2 :  LDA ZP_SCR16 ; $FD
0EB4 :  STA slot+0
0EB6 :  LDA #LO(e->ival) ; $19
0EB8 :  LDX #LO((e->ival >> 8)) ; $00
0EBA :  CLC
0EBB :  ADC slot+0
0EBD :  PHA
0EBE :  LDA LOPT2
0EC1 :  STA ZP_PTR ; $FB
0EC3 :  LDA LOPT2+1
0EC6 :  STA ZP_PTR + 1 ; $FC
0EC8 :  PLA
0EC9 :  LDY #0 ; $00
0ECB :  STA (ZP_PTR),Y ; $FB
0ECD :  INY
0ECE :  TXA
0ECF :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 110   $0ED1  CH(C)=33+INT(RND(1)*58)
; 14,"matrix.bas"

L110:
0ED1 :  LDA #LO(e->ival) ; $21
0ED3 :  LDX #LO((e->ival >> 8)) ; $00
0ED5 :  STA slot+0
0ED7 :  LDA #LO(K) ; $3A
0ED9 :  STA rnd_k ; $0848
0EDC :  LDA #HI(K) ; $00
0EDE :  STA rnd_k + 1 ; $0849
0EE1 :  JSR RT_rnd_int ; $0C2A
0EE4 :  CLC
0EE5 :  ADC slot+0
0EE7 :  LDX #0 ; $00
0EE9 :  PHA
0EEA :  LDA LOPT3
0EED :  STA ZP_PTR ; $FB
0EEF :  LDA LOPT3+1
0EF2 :  STA ZP_PTR + 1 ; $FC
0EF4 :  PLA
0EF5 :  LDY #0 ; $00
0EF7 :  STA (ZP_PTR),Y ; $FB
0EF9 :  INY
0EFA :  TXA
0EFB :  STA (ZP_PTR),Y ; $FB
; 120   $0EFD  D(C)=1+INT(RND(1)*5)
; 15,"matrix.bas"

L120:
0EFD :  LDA #LO(e->ival) ; $01
0EFF :  LDX #LO((e->ival >> 8)) ; $00
0F01 :  STA slot+0
0F03 :  LDA #LO(K) ; $05
0F05 :  STA rnd_k ; $0848
0F08 :  LDA #HI(K) ; $00
0F0A :  STA rnd_k + 1 ; $0849
0F0D :  JSR RT_rnd_int ; $0C2A
0F10 :  CLC
0F11 :  ADC slot+0
0F13 :  LDX #0 ; $00
0F15 :  PHA
0F16 :  LDA LOPT4
0F19 :  STA ZP_PTR ; $FB
0F1B :  LDA LOPT4+1
0F1E :  STA ZP_PTR + 1 ; $FC
0F20 :  PLA
0F21 :  LDY #0 ; $00
0F23 :  STA (ZP_PTR),Y ; $FB
0F25 :  INY
0F26 :  TXA
0F27 :  STA (ZP_PTR),Y ; $FB
; 130   $0F29  NEXT C
; 16,"matrix.bas"

L130:
0F29 :  LDA LOPT0
0F2C :  CLC
0F2D :  ADC #(u8)(st & 0xFF) ; $02
0F2F :  STA LOPT0
0F32 :  LDA LOPT0+1
0F35 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F37 :  STA LOPT0+1
0F3A :  LDA LOPT1
0F3D :  CLC
0F3E :  ADC #(u8)(st & 0xFF) ; $02
0F40 :  STA LOPT1
0F43 :  LDA LOPT1+1
0F46 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F48 :  STA LOPT1+1
0F4B :  LDA LOPT2
0F4E :  CLC
0F4F :  ADC #(u8)(st & 0xFF) ; $02
0F51 :  STA LOPT2
0F54 :  LDA LOPT2+1
0F57 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F59 :  STA LOPT2+1
0F5C :  LDA LOPT3
0F5F :  CLC
0F60 :  ADC #(u8)(st & 0xFF) ; $02
0F62 :  STA LOPT3
0F65 :  LDA LOPT3+1
0F68 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F6A :  STA LOPT3+1
0F6D :  LDA LOPT4
0F70 :  CLC
0F71 :  ADC #(u8)(st & 0xFF) ; $02
0F73 :  STA LOPT4
0F76 :  LDA LOPT4+1
0F79 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F7B :  STA LOPT4+1
0F7E :  INC C
0F81 :  LDA C
0F84 :  CMP #L->lim_lo ; $27
0F86 :  BEQ .nxt_back
0F88 :  BCS .nxt_done

.nxt_back:
0F8A :  JMP .for_body ; $0DE9

.nxt_done:
; 140   $0F8D  T%=TI
; 18,"matrix.bas"

L140:
0F8D :  JSR RT_ti_read ; $0CD5
0F90 :  JSR ROM_FAC_INT ; $BC9B
0F93 :  LDA FACMO3 ; $65
0F95 :  LDX FACMO2 ; $64
0F97 :  STA T
0F9A :  STX T+1
; 141   $0F9D  FOR C=0 TO 39:GOSUB 1000:NEXT C
; 19,"matrix.bas"

L141:
0F9D :  LDA #LO(e->ival) ; $00
0F9F :  LDX #LO((e->ival >> 8)) ; $00
0FA1 :  STA C
0FA4 :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
0FA7 :  JSR L1000
0FAA :  INC C
0FAD :  LDA C
0FB0 :  CMP #L->lim_lo ; $27
0FB2 :  BEQ .nxt_back
0FB4 :  BCS .nxt_done

.nxt_back:
0FB6 :  JMP .for_body ; $0FA7

.nxt_done:
; 142   $0FB9  PRINT CHR$(19);TI-T%
; 20,"matrix.bas"

L142:
0FB9 :  LDA #LO(e->ival) ; $13
0FBB :  LDX #LO((e->ival >> 8)) ; $00
0FBD :  JSR ROM_CHROUT ; $FFD2
0FC0 :  JSR RT_ti_read ; $0CD5
0FC3 :  LDX #<addr ; $3B
0FC5 :  LDY #>addr ; $08
0FC7 :  JSR ROM_FAC_MEM ; $BBD4
0FCA :  LDA T
0FCD :  LDX T+1
0FD0 :  TAY
0FD1 :  TXA
0FD2 :  JSR ROM_INT_FAC ; $B391
0FD5 :  LDA #<addr ; $3B
0FD7 :  LDY #>addr ; $08
0FD9 :  JSR ROM_MEM_ARG ; $BA8C
0FDC :  LDA FACEXP ; $61
0FDE :  LDA #<addr ; $3B
0FE0 :  LDY #>addr ; $08
0FE2 :  JSR ROM_MINUS ; $B850
0FE5 :  JSR ROM_FOUT ; $BDDD
0FE8 :  LDY #0 ; $00

.fpl:
0FEA :  LDA ZP_GETBUF,Y ; $0100
0FED :  BEQ .fpr_done
0FEF :  JSR ROM_CHROUT ; $FFD2
0FF2 :  INY
0FF3 :  BNE .fpr

.fpr_done:
0FF5 :  LDA #0x1D ; $1D
0FF7 :  JSR ROM_CHROUT ; $FFD2
0FFA :  LDA #13 ; $0D
0FFC :  JSR ROM_CHROUT ; $FFD2
; 150   $0FFF  GOTO 140
; 21,"matrix.bas"

L150:
0FFF :  JMP L140

; 1000  $1002  REM --- advance column c by 1 row ---
; 23,"matrix.bas"

L1000:
; 1001  $1002  P=H(C)*40+C
; 24,"matrix.bas"

L1001:
1002 :  LDA C
1005 :  ASL
1006 :  TAX
1007 :  LDA H,X
100A :  STA ZP_SCR16 ; $FD
100C :  LDA H+1,X
100F :  TAX
1010 :  LDA ZP_SCR16 ; $FD
1012 :  TAY
1013 :  LDA h_mulK_hi[K],Y ; $0863
1016 :  TAX
1017 :  LDA h_mulK_lo[K],Y ; $084A
101A :  STA slot+0
101C :  STX slot+1
101E :  LDA C
1021 :  LDX #0 ; $00
1023 :  CLC
1024 :  ADC slot+0
1026 :  PHA
1027 :  TXA
1028 :  ADC slot+1
102A :  TAX
102B :  PLA
102C :  STA P
102F :  STX P+1
; 1002  $1032  POKE SC+P,CH(C):POKE CR+P,1
; 25,"matrix.bas"

L1002:
1032 :  LDA SC
1035 :  LDX SC+1
1038 :  STA slot+0
103A :  STX slot+1
103C :  LDA P
103F :  LDX P+1
1042 :  CLC
1043 :  ADC slot+0
1045 :  PHA
1046 :  TXA
1047 :  ADC slot+1
1049 :  TAX
104A :  PLA
104B :  STA ZP_PTR ; $FB
104D :  STX ZP_PTR + 1 ; $FC
104F :  PHA
1050 :  LDA ZP_PTR + 1 ; $FC
1052 :  PHA
1053 :  LDA C
1056 :  ASL
1057 :  TAX
1058 :  LDA CH,X
105B :  STA ZP_SCR16 ; $FD
105D :  LDA CH+1,X
1060 :  TAX
1061 :  LDA ZP_SCR16 ; $FD
1063 :  PLA
1064 :  STA ZP_PTR + 1 ; $FC
1066 :  PLA
1067 :  STA ZP_PTR ; $FB
1069 :  LDA ZP_SCR16 ; $FD
106B :  LDY #0 ; $00
106D :  STA (ZP_PTR),Y ; $FB
106F :  LDA CR
1072 :  LDX CR+1
1075 :  STA slot+0
1077 :  STX slot+1
1079 :  LDA P
107C :  LDX P+1
107F :  CLC
1080 :  ADC slot+0
1082 :  PHA
1083 :  TXA
1084 :  ADC slot+1
1086 :  TAX
1087 :  PLA
1088 :  STA ZP_PTR ; $FB
108A :  STX ZP_PTR + 1 ; $FC
108C :  LDA #(u8)s->e2->ival ; $01
108E :  LDY #0 ; $00
1090 :  STA (ZP_PTR),Y ; $FB
; 1003  $1092  CH(C)=CH(C)+D(C):IF CH(C)>90 THEN CH(C)=CH(C)-58
; 26,"matrix.bas"

L1003:
1092 :  LDA C
1095 :  ASL
1096 :  TAX
1097 :  LDA CH,X
109A :  STA ZP_SCR16 ; $FD
109C :  LDA CH+1,X
109F :  TAX
10A0 :  LDA ZP_SCR16 ; $FD
10A2 :  STA slot+0
10A4 :  LDA C
10A7 :  ASL
10A8 :  TAX
10A9 :  LDA D,X
10AC :  STA ZP_SCR16 ; $FD
10AE :  LDA D+1,X
10B1 :  TAX
10B2 :  LDA ZP_SCR16 ; $FD
10B4 :  CLC
10B5 :  ADC slot+0
10B7 :  LDX #0 ; $00
10B9 :  STA ZP_SCR16 ; $FD
10BB :  STX ZP_SCR16 + 1 ; $FE
10BD :  LDA C
10C0 :  ASL
10C1 :  TAX
10C2 :  LDA ZP_SCR16 ; $FD
10C4 :  STA CH,X
10C7 :  LDA ZP_SCR16 + 1 ; $FE
10C9 :  STA CH+1,X
10CC :  LDA C
10CF :  ASL
10D0 :  TAX
10D1 :  LDA CH,X
10D4 :  STA ZP_SCR16 ; $FD
10D6 :  LDA CH+1,X
10D9 :  TAX
10DA :  LDA ZP_SCR16 ; $FD
10DC :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-narrow
10DE :  CMP #klo ; $5A
10E0 :  BNE +3 ; long IF-skip (body >127B)
10E2 :  JMP .if_skip

10E5 :  BCS +3 ; long IF-skip (body >127B)
10E7 :  JMP .if_skip

10EA :  LDA #LO(e->ival) ; $3A
10EC :  LDX #LO((e->ival >> 8)) ; $00
10EE :  STA slot+0
10F0 :  STX slot+1
10F2 :  LDA C
10F5 :  ASL
10F6 :  TAX
10F7 :  LDA CH,X
10FA :  STA ZP_SCR16 ; $FD
10FC :  LDA CH+1,X
10FF :  TAX
1100 :  LDA ZP_SCR16 ; $FD
1102 :  SEC
1103 :  SBC slot+0
1105 :  PHA
1106 :  TXA
1107 :  SBC slot+1
1109 :  TAX
110A :  PLA
110B :  STA ZP_SCR16 ; $FD
110D :  STX ZP_SCR16 + 1 ; $FE
110F :  LDA C
1112 :  ASL
1113 :  TAX
1114 :  LDA ZP_SCR16 ; $FD
1116 :  STA CH,X
1119 :  LDA ZP_SCR16 + 1 ; $FE
111B :  STA CH+1,X

.if_skip:
; 1004  $111E  B=H(C)-1:IF B<0 THEN B=24
; 27,"matrix.bas"

L1004:
111E :  LDA #LO(e->ival) ; $01
1120 :  LDX #LO((e->ival >> 8)) ; $00
1122 :  STA slot+0
1124 :  STX slot+1
1126 :  LDA C
1129 :  ASL
112A :  TAX
112B :  LDA H,X
112E :  STA ZP_SCR16 ; $FD
1130 :  LDA H+1,X
1133 :  TAX
1134 :  LDA ZP_SCR16 ; $FD
1136 :  SEC
1137 :  SBC slot+0
1139 :  PHA
113A :  TXA
113B :  SBC slot+1
113D :  TAX
113E :  PLA
113F :  STA B
1142 :  STX B+1
1145 :  LDA B+1
1148 :  BMI +3 ; long IF-skip (body >127B)
114A :  JMP .if_skip

114D :  LDA #LO(e->ival) ; $18
114F :  LDX #LO((e->ival >> 8)) ; $00
1151 :  STA B
1154 :  STX B+1

.if_skip:
; 1005  $1157  POKE CR+B*40+C,13
; 28,"matrix.bas"

L1005:
1157 :  LDA CR
115A :  LDX CR+1
115D :  STA slot+0
115F :  STX slot+1
1161 :  LDA B
1164 :  LDX B+1
1167 :  TAY
1168 :  LDA h_mulK_hi[K],Y ; $0863
116B :  TAX
116C :  LDA h_mulK_lo[K],Y ; $084A
116F :  CLC
1170 :  ADC slot+0
1172 :  PHA
1173 :  TXA
1174 :  ADC slot+1
1176 :  TAX
1177 :  PLA
1178 :  STA slot+0
117A :  STX slot+1
117C :  LDA C
117F :  LDX #0 ; $00
1181 :  CLC
1182 :  ADC slot+0
1184 :  PHA
1185 :  TXA
1186 :  ADC slot+1
1188 :  TAX
1189 :  PLA
118A :  STA ZP_PTR ; $FB
118C :  STX ZP_PTR + 1 ; $FC
118E :  LDA #(u8)s->e2->ival ; $0D
1190 :  LDY #0 ; $00
1192 :  STA (ZP_PTR),Y ; $FB
; 1006  $1194  B=B-1:IF B<0 THEN B=24
; 29,"matrix.bas"

L1006:
1194 :  LDA B
1197 :  BNE .pm1_skip
1199 :  DEC B+1

.pm1_skip:
119C :  DEC B
119F :  LDA B+1
11A2 :  BMI +3 ; long IF-skip (body >127B)
11A4 :  JMP .if_skip

11A7 :  LDA #LO(e->ival) ; $18
11A9 :  LDX #LO((e->ival >> 8)) ; $00
11AB :  STA B
11AE :  STX B+1

.if_skip:
; 1007  $11B1  POKE CR+B*40+C,5
; 30,"matrix.bas"

L1007:
11B1 :  LDA CR
11B4 :  LDX CR+1
11B7 :  STA slot+0
11B9 :  STX slot+1
11BB :  LDA B
11BE :  LDX B+1
11C1 :  TAY
11C2 :  LDA h_mulK_hi[K],Y ; $0863
11C5 :  TAX
11C6 :  LDA h_mulK_lo[K],Y ; $084A
11C9 :  CLC
11CA :  ADC slot+0
11CC :  PHA
11CD :  TXA
11CE :  ADC slot+1
11D0 :  TAX
11D1 :  PLA
11D2 :  STA slot+0
11D4 :  STX slot+1
11D6 :  LDA C
11D9 :  LDX #0 ; $00
11DB :  CLC
11DC :  ADC slot+0
11DE :  PHA
11DF :  TXA
11E0 :  ADC slot+1
11E2 :  TAX
11E3 :  PLA
11E4 :  STA ZP_PTR ; $FB
11E6 :  STX ZP_PTR + 1 ; $FC
11E8 :  LDA #(u8)s->e2->ival ; $05
11EA :  LDY #0 ; $00
11EC :  STA (ZP_PTR),Y ; $FB
; 1008  $11EE  POKE SC+E(C)*40+C,32
; 31,"matrix.bas"

L1008:
11EE :  LDA SC
11F1 :  LDX SC+1
11F4 :  STA slot+0
11F6 :  STX slot+1
11F8 :  LDA C
11FB :  ASL
11FC :  TAX
11FD :  LDA E,X
1200 :  STA ZP_SCR16 ; $FD
1202 :  LDA E+1,X
1205 :  TAX
1206 :  LDA ZP_SCR16 ; $FD
1208 :  TAY
1209 :  LDA h_mulK_hi[K],Y ; $0863
120C :  TAX
120D :  LDA h_mulK_lo[K],Y ; $084A
1210 :  CLC
1211 :  ADC slot+0
1213 :  PHA
1214 :  TXA
1215 :  ADC slot+1
1217 :  TAX
1218 :  PLA
1219 :  STA slot+0
121B :  STX slot+1
121D :  LDA C
1220 :  LDX #0 ; $00
1222 :  CLC
1223 :  ADC slot+0
1225 :  PHA
1226 :  TXA
1227 :  ADC slot+1
1229 :  TAX
122A :  PLA
122B :  STA ZP_PTR ; $FB
122D :  STX ZP_PTR + 1 ; $FC
122F :  LDA #(u8)s->e2->ival ; $20
1231 :  LDY #0 ; $00
1233 :  STA (ZP_PTR),Y ; $FB
; 1009  $1235  H(C)=H(C)+1:IF H(C)>24 THEN H(C)=0:CH(C)=33+INT(RND(1)*58):D(C)=1+INT(RND(1)*5)
; 32,"matrix.bas"

L1009:
1235 :  LDA C
1238 :  ASL
1239 :  TAX
123A :  LDA H,X
123D :  STA ZP_SCR16 ; $FD
123F :  LDA H+1,X
1242 :  TAX
1243 :  LDA ZP_SCR16 ; $FD
1245 :  STA slot+0
1247 :  LDA #LO(e->ival) ; $01
1249 :  LDX #LO((e->ival >> 8)) ; $00
124B :  CLC
124C :  ADC slot+0
124E :  STA ZP_SCR16 ; $FD
1250 :  STX ZP_SCR16 + 1 ; $FE
1252 :  LDA C
1255 :  ASL
1256 :  TAX
1257 :  LDA ZP_SCR16 ; $FD
1259 :  STA H,X
125C :  LDA ZP_SCR16 + 1 ; $FE
125E :  STA H+1,X
1261 :  LDA C
1264 :  ASL
1265 :  TAX
1266 :  LDA H,X
1269 :  STA ZP_SCR16 ; $FD
126B :  LDA H+1,X
126E :  TAX
126F :  LDA ZP_SCR16 ; $FD
1271 :  STX ZP_SCR16 + 1 ; $FE
1273 :  LDA ZP_SCR16 + 1 ; $FE
1275 :  EOR #0x80 ; $80
1277 :  CMP #(u8)(cmp_uns_a ? khi : (khi ^ 0x80)) ; $80
1279 :  BEQ .cmp_lo
127B :  BCS +3 ; long IF-skip (body >127B)
127D :  JMP .if_skip

1280 :  BNE .cmp_body

.cmp_lo:
1282 :  LDA ZP_SCR16 ; $FD
1284 :  CMP #klo ; $18
1286 :  BNE +3 ; long IF-skip (body >127B)
1288 :  JMP .if_skip

128B :  BCS +3 ; long IF-skip (body >127B)
128D :  JMP .if_skip

.cmp_body:
1290 :  LDA #LO(e->ival) ; $00
1292 :  LDX #LO((e->ival >> 8)) ; $00
1294 :  STA ZP_SCR16 ; $FD
1296 :  STX ZP_SCR16 + 1 ; $FE
1298 :  LDA C
129B :  ASL
129C :  TAX
129D :  LDA ZP_SCR16 ; $FD
129F :  STA H,X
12A2 :  LDA ZP_SCR16 + 1 ; $FE
12A4 :  STA H+1,X
12A7 :  LDA #LO(e->ival) ; $21
12A9 :  LDX #LO((e->ival >> 8)) ; $00
12AB :  STA slot+0
12AD :  LDA #LO(K) ; $3A
12AF :  STA rnd_k ; $0848
12B2 :  LDA #HI(K) ; $00
12B4 :  STA rnd_k + 1 ; $0849
12B7 :  JSR RT_rnd_int ; $0C2A
12BA :  CLC
12BB :  ADC slot+0
12BD :  LDX #0 ; $00
12BF :  STA ZP_SCR16 ; $FD
12C1 :  STX ZP_SCR16 + 1 ; $FE
12C3 :  LDA C
12C6 :  ASL
12C7 :  TAX
12C8 :  LDA ZP_SCR16 ; $FD
12CA :  STA CH,X
12CD :  LDA ZP_SCR16 + 1 ; $FE
12CF :  STA CH+1,X
12D2 :  LDA #LO(e->ival) ; $01
12D4 :  LDX #LO((e->ival >> 8)) ; $00
12D6 :  STA slot+0
12D8 :  LDA #LO(K) ; $05
12DA :  STA rnd_k ; $0848
12DD :  LDA #HI(K) ; $00
12DF :  STA rnd_k + 1 ; $0849
12E2 :  JSR RT_rnd_int ; $0C2A
12E5 :  CLC
12E6 :  ADC slot+0
12E8 :  LDX #0 ; $00
12EA :  STA ZP_SCR16 ; $FD
12EC :  STX ZP_SCR16 + 1 ; $FE
12EE :  LDA C
12F1 :  ASL
12F2 :  TAX
12F3 :  LDA ZP_SCR16 ; $FD
12F5 :  STA D,X
12F8 :  LDA ZP_SCR16 + 1 ; $FE
12FA :  STA D+1,X

.if_skip:
; 1010  $12FD  E(C)=E(C)+1:IF E(C)>24 THEN E(C)=0
; 33,"matrix.bas"

L1010:
12FD :  LDA C
1300 :  ASL
1301 :  TAX
1302 :  LDA E,X
1305 :  STA ZP_SCR16 ; $FD
1307 :  LDA E+1,X
130A :  TAX
130B :  LDA ZP_SCR16 ; $FD
130D :  STA slot+0
130F :  LDA #LO(e->ival) ; $01
1311 :  LDX #LO((e->ival >> 8)) ; $00
1313 :  CLC
1314 :  ADC slot+0
1316 :  STA ZP_SCR16 ; $FD
1318 :  STX ZP_SCR16 + 1 ; $FE
131A :  LDA C
131D :  ASL
131E :  TAX
131F :  LDA ZP_SCR16 ; $FD
1321 :  STA E,X
1324 :  LDA ZP_SCR16 + 1 ; $FE
1326 :  STA E+1,X
1329 :  LDA C
132C :  ASL
132D :  TAX
132E :  LDA E,X
1331 :  STA ZP_SCR16 ; $FD
1333 :  LDA E+1,X
1336 :  TAX
1337 :  LDA ZP_SCR16 ; $FD
1339 :  STX ZP_SCR16 + 1 ; $FE
133B :  LDA ZP_SCR16 + 1 ; $FE
133D :  EOR #0x80 ; $80
133F :  CMP #(u8)(cmp_uns_a ? khi : (khi ^ 0x80)) ; $80
1341 :  BEQ .cmp_lo
1343 :  BCS +3 ; long IF-skip (body >127B)
1345 :  JMP .if_skip

1348 :  BNE .cmp_body

.cmp_lo:
134A :  LDA ZP_SCR16 ; $FD
134C :  CMP #klo ; $18
134E :  BNE +3 ; long IF-skip (body >127B)
1350 :  JMP .if_skip

1353 :  BCS +3 ; long IF-skip (body >127B)
1355 :  JMP .if_skip

.cmp_body:
1358 :  LDA #LO(e->ival) ; $00
135A :  LDX #LO((e->ival >> 8)) ; $00
135C :  STA ZP_SCR16 ; $FD
135E :  STX ZP_SCR16 + 1 ; $FE
1360 :  LDA C
1363 :  ASL
1364 :  TAX
1365 :  LDA ZP_SCR16 ; $FD
1367 :  STA E,X
136A :  LDA ZP_SCR16 + 1 ; $FE
136C :  STA E+1,X

.if_skip:
; 1011  $136F  RETURN
; 34,"matrix.bas"

L1011:
136F :  RTS

; halt
; ---- variables (zero-filled) ----
SC = $1400
; SC     $1400 (2 bytes)
CR = $1402
; CR     $1402 (2 bytes)
H = $1404
; H      $1404 (80 bytes array)
E = $1454
; E      $1454 (80 bytes array)
T_A = $14A4
; T_A    $14A4 (80 bytes array)
CH = $14F4
; CH     $14F4 (80 bytes array)
D = $1544
; D      $1544 (80 bytes array)
C = $1594
; C      $1594 (2 bytes)
T = $1596
; T      $1596 (2 bytes)
TI_F = $1598
; TI     $1598 (5 bytes)
P = $159D
; P      $159D (2 bytes)
B = $159F
; B      $159F (2 bytes)
LOPT0 = $15A1
; LOPT0  $15A1 (2 bytes)
LOPT1 = $15A3
; LOPT1  $15A3 (2 bytes)
LOPT2 = $15A5
; LOPT2  $15A5 (2 bytes)
LOPT3 = $15A7
; LOPT3  $15A7 (2 bytes)
LOPT4 = $15A9
; LOPT4  $15A9 (2 bytes)
LIMIT1 = $15AB
; LIMIT1 $15AB (2 bytes)
LIMIT2 = $15AD
; LIMIT2 $15AD (2 bytes)
1370 :  .res 575	; variable area
