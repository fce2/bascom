10 rem pi to n digits - rabinowitz/wagon spigot algorithm
20 rem

30 n=6
40 ex=2
50 l=int(10*(n+ex)/3)+1
60 dim a(l): dim o%(n+5)
70 for i=1 to l: a(i)=2: next i
80 n9=0: p0=0: oi=0

90 for j=1 to n+ex+1
100 q=0

110 for i=l to 1 step -1
120 x=10*a(i)+q*i
130 d=2*i-1
140 a(i)=x-d*int(x/d)
150 q=int(x/d)
160 next i

170 a(1)=q-10*int(q/10)
180 q=int(q/10)
190 if q=9 then n9=n9+1: goto 250
200 if q=10 goto 240
210 rem q<9: release predigit (skip j=1), held 9s are real 9s
220 if j>1 then oi=oi+1: o%(oi)=p0
230 if n9>0 then for k=1 to n9: oi=oi+1: o%(oi)=9: next k
235 p0=q: n9=0: goto 250
240 rem q=10 carry: predigit+1, held 9s become 0s
245 oi=oi+1: o%(oi)=p0+1
247 if n9>0 then for k=1 to n9: oi=oi+1: o%(oi)=0: next k
249 p0=0: n9=0
250 next j

260 oi=oi+1: o%(oi)=p0
300 print "3.";
310 for j=2 to n+1: print chr$(48+o%(j));: next j
