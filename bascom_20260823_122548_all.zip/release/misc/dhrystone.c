/* OPTIMIZE_C -- dhrystone.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static bint_t b_v_lpi;
static bint_t b_v_hzi;
static bint_t b_a_a1i[51];
static bint_t b_a_a2i[2601];
static int b_a_rpi[4];
static bint_t b_a_rdi[4];
static bint_t b_a_rii[4];
static int b_a_rxi[4];
static bstr_t b_a_rss[4];
static int b_v_igi;
static bint_t b_v_bgi;
static int b_v_pni;
static int b_v_pgi;
static breal_t b_v_t0f;
static breal_t b_v_jf;
static int b_v_ii;
static breal_t b_v_ntf;
static bstr_t b_v_s1s;
static breal_t b_v_t1f;
static breal_t b_v_btf;
static breal_t b_v_dsf;
static bint_t b_v_lai;
static bint_t b_v_lbi;
static bstr_t b_v_s2s;
static int b_v_eli;
static bstr_t b_v_gcs;
static bstr_t b_v_gds;
static bint_t b_v_fri;
static bint_t b_v_lci;
static bint_t b_v_d1i;
static bint_t b_v_d2i;
static bint_t b_v_d3i;
static bint_t b_v_r1i;
static bint_t b_v_r2i;
static int b_v_p1i;
static int b_v_cmi;
static bstr_t b_v_c2s;
static int b_v_cii;
static bstr_t b_v_gas;
static bstr_t b_v_gbs;
static int b_v_u1i;
static int b_v_u2i;
static bint_t b_v_q1i;
static bstr_t b_v_c1s;
static bint_t b_v_bli;
static bint_t b_v_r3i;
static bint_t b_v_r4i;
static int b_v_nri;
static int b_v_p3i;
static bint_t b_v_q2i;
static int b_v_q3i;
static int b_v_v3i;
static int b_v_w1i;
static bstr_t b_v_cls;
static int b_fl_0;
static int b_fl_1;
static int b_fl_2;
static bint_t b_fl_3;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_v_lpi=(1000);
		b_v_hzi=(50.0);
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		b_v_igi=(0);
		b_v_bgi=(0);
		b_v_pni=(0);
		b_v_pgi=(0);
		/* line 50 */
b_L50: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L2200;
b_ret0: ;
		b_v_t0f=b_v_jf;
		/* line 60 */
b_L60: ;
		b_v_ii=(1);
		b_fl_0=b_v_lpi;
		if(b_v_ii > b_fl_0) goto b_f0_e;
b_f0_t: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 70 */
b_L70: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L2200;
b_ret1: ;
		b_v_ntf=((b_v_jf)-(b_v_t0f));
		/* line 80 */
b_L80: ;
		b_v_pni=(1);
		b_v_pgi=(2);
		/* line 90 */
b_L90: ;
		b_a_rpi[B_INT((2))]=(1);
		b_a_rdi[B_INT((2))]=(1);
		b_a_rxi[B_INT((2))]=(3);
		b_a_rii[B_INT((2))]=(40);
		/* line 100 */
b_L100: ;
		b_a_rss[B_INT((2))]=b_keep(b_lit("DHRYSTONE PROGRAM, SOME STRING",30));
		/* line 110 */
b_L110: ;
		b_v_s1s=b_keep(b_lit("DHRYSTONE PROGRAM, 1'ST STRING",30));
		/* line 120 */
b_L120: ;
		b_a_a2i[(B_INT((8)))*51+(B_INT((7)))]=(10);
		/* line 130 */
b_L130: ;
		{ bstr_t _t=b_lit("=== DHRYSTONE ===",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 140 */
b_L140: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L2200;
b_ret2: ;
		b_v_t1f=b_v_jf;
		/* line 150 */
b_L150: ;
		b_v_ii=(1);
		b_fl_1=b_v_lpi;
		if(b_v_ii > b_fl_1) goto b_f1_e;
b_f1_t: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1000;
b_ret3: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_1)) goto b_f1_t;
b_f1_e: ;
		/* line 160 */
b_L160: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L2200;
b_ret4: ;
		b_v_btf=((((b_v_jf)-(b_v_t1f)))-(b_v_ntf));
		/* line 170 */
b_L170: ;
		if(-((b_v_btf) == ((0)))){
			{ bstr_t _t=b_lit("INCREASE LOOPS",14); b_str(_t.p,_t.len); }
			b_nl();
			goto b_L260;
		}
		/* line 180 */
b_L180: ;
		b_v_dsf=((breal_t)(((b_v_lpi)*(b_v_hzi)))/b_v_btf);
		/* line 190 */
b_L190: ;
		{ bstr_t _t=b_lit("LOOPS ..................",24); b_str(_t.p,_t.len); }
		b_putint(b_v_lpi);
		b_nl();
		/* line 200 */
b_L200: ;
		{ bstr_t _t=b_lit("BENCHTIME (JIFFIES) ....",24); b_str(_t.p,_t.len); }
		b_real(b_int(b_v_btf));
		b_nl();
		/* line 210 */
b_L210: ;
		{ bstr_t _t=b_lit("BENCHTIME (SECONDS) ....",24); b_str(_t.p,_t.len); }
		b_real((b_v_btf/(breal_t)(b_v_hzi)));
		b_nl();
		/* line 220 */
b_L220: ;
		{ bstr_t _t=b_lit("DHRYSTONES/SEC (INT) ...",24); b_str(_t.p,_t.len); }
		b_real(b_int(b_v_dsf));
		b_nl();
		/* line 230 */
b_L230: ;
		{ bstr_t _t=b_lit("DHRYSTONES/SEC (FLT) ...",24); b_str(_t.p,_t.len); }
		b_real(b_v_dsf);
		b_nl();
		/* line 240 */
b_L240: ;
		{ bstr_t _t=b_lit("DHRYSTONES/SEC (MILLI).",23); b_str(_t.p,_t.len); }
		b_real(b_int(((b_v_dsf)*((1000)))));
		b_nl();
		/* line 250 */
b_L250: ;
		{ bstr_t _t=b_lit("========================",24); b_str(_t.p,_t.len); }
		b_nl();
		/* line 260 */
b_L260: ;
		goto b_end;
		/* line 1000 */
b_L1000: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L1100;
b_ret5: ;
		b_gosubStack[b_gosubSP++]=6; goto b_L1200;
b_ret6: ;
		b_v_lai=(2);
		b_v_lbi=(3);
		/* line 1001 */
b_L1001: ;
		b_v_s2s=b_keep(b_lit("DHRYSTONE PROGRAM, 2'ND STRING",30));
		b_v_eli=(2);
		/* line 1002 */
b_L1002: ;
		b_v_gcs=b_keep(b_v_s1s);
		b_v_gds=b_keep(b_v_s2s);
		b_gosubStack[b_gosubSP++]=7; goto b_L1900;
b_ret7: ;
		b_v_bgi=(((1))-(b_v_fri));
		/* line 1003 */
b_L1003: ;
		if(-((b_v_lai) < (b_v_lbi))){
			goto b_L1005;
		}
		/* line 1004 */
b_L1004: ;
		goto b_L1007;
		/* line 1005 */
b_L1005: ;
		b_v_lci=(((((5))*(b_v_lai)))-(b_v_lbi));
		b_v_d1i=b_v_lai;
		b_v_d2i=b_v_lbi;
		b_gosubStack[b_gosubSP++]=8; goto b_L1700;
b_ret8: ;
		b_v_lci=b_v_d3i;
		b_v_lai=((b_v_lai)+((1)));
		/* line 1006 */
b_L1006: ;
		goto b_L1003;
		/* line 1007 */
b_L1007: ;
		b_v_r1i=b_v_lai;
		b_v_r2i=b_v_lci;
		b_gosubStack[b_gosubSP++]=9; goto b_L1300;
b_ret9: ;
		/* line 1008 */
b_L1008: ;
		b_v_p1i=b_v_pgi;
		b_gosubStack[b_gosubSP++]=10; goto b_L1400;
b_ret10: ;
		/* line 1009 */
b_L1009: ;
		b_v_cmi=b_asc(b_v_c2s);
		/* line 1010 */
b_L1010: ;
		b_v_cii=(65);
		b_fl_2=b_v_cmi;
		if(b_v_cii > b_fl_2) goto b_f2_e;
b_f2_t: ;
		/* line 1011 */
b_L1011: ;
		b_v_gas=b_keep(b_chr(B_INT(b_v_cii)));
		b_v_gbs=b_keep(b_lit("C",1));
		b_gosubStack[b_gosubSP++]=11; goto b_L2000;
b_ret11: ;
		/* line 1012 */
b_L1012: ;
		if(-((b_v_eli) == (b_v_fri))){
			b_v_u1i=(1);
			b_gosubStack[b_gosubSP++]=12; goto b_L1800;
b_ret12: ;
			b_v_eli=b_v_u2i;
		}
		/* line 1013 */
b_L1013: ;
		b_v_cii += 1;
		if(b_v_cii <= (b_fl_2)) goto b_f2_t;
b_f2_e: ;
		/* line 1014 */
b_L1014: ;
		b_v_lci=((b_v_lbi)*(b_v_lai));
		b_v_lbi=((breal_t)(b_v_lci)/(breal_t)(b_v_lai));
		b_v_lbi=(((((7))*(((b_v_lci)-(b_v_lbi)))))-(b_v_lai));
		/* line 1015 */
b_L1015: ;
		b_v_q1i=b_v_lai;
		b_gosubStack[b_gosubSP++]=13; goto b_L1500;
b_ret13: ;
		b_v_lai=b_v_q1i;
		/* line 1016 */
b_L1016: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		b_v_c1s=b_keep(b_lit("A",1));
		b_v_bgi=(0);
		goto b_return;
		/* line 1200 */
b_L1200: ;
		b_v_bli=(0);
		if(-(b_strcmp(b_v_c1s,b_lit("A",1)) == 0)){
			b_v_bli=(-1);
		}
		/* line 1201 */
b_L1201: ;
		b_v_bli=(B_INT(b_v_bli) | B_INT(b_v_bgi));
		b_v_c2s=b_keep(b_lit("B",1));
		goto b_return;
		/* line 1300 */
b_L1300: ;
		b_v_r3i=((b_v_r1i)+((5)));
		/* line 1301 */
b_L1301: ;
		b_a_a1i[B_INT(b_v_r3i)]=b_v_r2i;
		b_a_a1i[B_INT(((b_v_r3i)+((1))))]=b_a_a1i[B_INT(b_v_r3i)];
		b_a_a1i[B_INT(((b_v_r3i)+((30))))]=b_v_r3i;
		/* line 1302 */
b_L1302: ;
		b_v_r4i=b_v_r3i;
		b_fl_3=((b_v_r3i)+((1)));
		if(b_v_r4i > b_fl_3) goto b_f3_e;
b_f3_t: ;
		b_a_a2i[(B_INT(b_v_r3i))*51+(B_INT(b_v_r4i))]=b_v_r3i;
		b_v_r4i += 1;
		if(b_v_r4i <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 1303 */
b_L1303: ;
		b_a_a2i[(B_INT(b_v_r3i))*51+(B_INT(((b_v_r3i)-((1)))))]=((b_a_a2i[(B_INT(b_v_r3i))*51+(B_INT(((b_v_r3i)-((1)))))])+((1)));
		b_a_a2i[(B_INT(((b_v_r3i)+((20)))))*51+(B_INT(b_v_r3i))]=b_a_a1i[B_INT(b_v_r3i)];
		/* line 1304 */
b_L1304: ;
		b_v_igi=(5);
		goto b_return;
		/* line 1400 */
b_L1400: ;
		b_v_nri=b_a_rpi[B_INT(b_v_p1i)];
		/* line 1401 */
b_L1401: ;
		b_a_rpi[B_INT(b_v_nri)]=b_a_rpi[B_INT(b_v_pgi)];
		b_a_rdi[B_INT(b_v_nri)]=b_a_rdi[B_INT(b_v_pgi)];
		b_a_rxi[B_INT(b_v_nri)]=b_a_rxi[B_INT(b_v_pgi)];
		/* line 1402 */
b_L1402: ;
		b_a_rii[B_INT(b_v_nri)]=b_a_rii[B_INT(b_v_pgi)];
		b_a_rss[B_INT(b_v_nri)]=b_keep(b_a_rss[B_INT(b_v_pgi)]);
		/* line 1403 */
b_L1403: ;
		b_a_rii[B_INT(b_v_p1i)]=(5);
		/* line 1404 */
b_L1404: ;
		b_a_rii[B_INT(b_v_nri)]=b_a_rii[B_INT(b_v_p1i)];
		/* line 1405 */
b_L1405: ;
		b_a_rpi[B_INT(b_v_nri)]=b_a_rpi[B_INT(b_v_p1i)];
		/* line 1406 */
b_L1406: ;
		b_v_p3i=b_a_rpi[B_INT(b_v_nri)];
		b_gosubStack[b_gosubSP++]=14; goto b_L1600;
b_ret14: ;
		/* line 1407 */
b_L1407: ;
		if(-((b_a_rdi[B_INT(b_v_nri)]) == ((1)))){
			goto b_L1410;
		}
		/* line 1408 */
b_L1408: ;
		b_a_rpi[B_INT(b_v_p1i)]=b_a_rpi[B_INT(b_v_nri)];
		b_a_rdi[B_INT(b_v_p1i)]=b_a_rdi[B_INT(b_v_nri)];
		b_a_rxi[B_INT(b_v_p1i)]=b_a_rxi[B_INT(b_v_nri)];
		/* line 1409 */
b_L1409: ;
		b_a_rii[B_INT(b_v_p1i)]=b_a_rii[B_INT(b_v_nri)];
		b_a_rss[B_INT(b_v_p1i)]=b_keep(b_a_rss[B_INT(b_v_nri)]);
		goto b_L1412;
		/* line 1410 */
b_L1410: ;
		b_a_rii[B_INT(b_v_nri)]=(6);
		b_v_u1i=b_a_rxi[B_INT(b_v_p1i)];
		b_gosubStack[b_gosubSP++]=15; goto b_L1800;
b_ret15: ;
		b_a_rxi[B_INT(b_v_nri)]=b_v_u2i;
		/* line 1411 */
b_L1411: ;
		b_a_rpi[B_INT(b_v_nri)]=b_a_rpi[B_INT(b_v_pgi)];
		b_v_d1i=b_a_rii[B_INT(b_v_nri)];
		b_v_d2i=(10);
		b_gosubStack[b_gosubSP++]=16; goto b_L1700;
b_ret16: ;
		b_a_rii[B_INT(b_v_nri)]=b_v_d3i;
		/* line 1412 */
b_L1412: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		b_v_q2i=((b_v_q1i)+((10)));
		b_v_q3i=(0);
		/* line 1501 */
b_L1501: ;
		if(-(b_strcmp(b_v_c1s,b_lit("A",1)) == 0)){
			b_v_q2i=((b_v_q2i)-((1)));
			b_v_q1i=((b_v_q2i)-(b_v_igi));
			b_v_q3i=(1);
		}
		/* line 1502 */
b_L1502: ;
		if(-((b_v_q3i) == ((1)))){
			goto b_L1504;
		}
		/* line 1503 */
b_L1503: ;
		goto b_L1501;
		/* line 1504 */
b_L1504: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		if(-((b_v_pgi) != ((0)))){
			b_a_rpi[B_INT(b_v_p3i)]=b_a_rpi[B_INT(b_v_pgi)];
			goto b_L1602;
		}
		/* line 1601 */
b_L1601: ;
		b_v_igi=(100);
		/* line 1602 */
b_L1602: ;
		b_v_d1i=(10);
		b_v_d2i=b_v_igi;
		b_gosubStack[b_gosubSP++]=17; goto b_L1700;
b_ret17: ;
		b_a_rii[B_INT(b_v_pgi)]=b_v_d3i;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		b_v_d3i=((b_v_d2i)+(((b_v_d1i)+((2)))));
		goto b_return;
		/* line 1800 */
b_L1800: ;
		b_v_u2i=b_v_u1i;
		b_v_v3i=b_v_u1i;
		b_gosubStack[b_gosubSP++]=18; goto b_L2100;
b_ret18: ;
		if(-((b_v_fri) == ((0)))){
			b_v_u2i=(4);
		}
		/* line 1801 */
b_L1801: ;
		switch(b_v_u1i){
			case 1: goto b_L1802; break;
			case 2: goto b_L1803; break;
			case 3: goto b_L1805; break;
			case 4: goto b_L1806; break;
			case 5: goto b_L1807; break;
			default: break;}
		/* line 1802 */
b_L1802: ;
		b_v_u2i=(1);
		goto b_L1808;
		/* line 1803 */
b_L1803: ;
		if(-((b_v_igi) > ((100)))){
			b_v_u2i=(1);
			goto b_L1808;
		}
		/* line 1804 */
b_L1804: ;
		b_v_u2i=(4);
		goto b_L1808;
		/* line 1805 */
b_L1805: ;
		b_v_u2i=(2);
		goto b_L1808;
		/* line 1806 */
b_L1806: ;
		goto b_L1808;
		/* line 1807 */
b_L1807: ;
		b_v_u2i=(3);
		/* line 1808 */
b_L1808: ;
		goto b_return;
		/* line 1900 */
b_L1900: ;
		b_v_w1i=(1);
		b_v_cls=b_keep(b_lit("",0));
		/* line 1901 */
b_L1901: ;
		if(-((b_v_w1i) > ((1)))){
			goto b_L1905;
		}
		/* line 1902 */
b_L1902: ;
		b_v_gas=b_keep(b_mid(b_v_gcs,B_INT(((b_v_w1i)+((1)))),B_INT((1))));
		b_v_gbs=b_keep(b_mid(b_v_gds,B_INT(((b_v_w1i)+((2)))),B_INT((1))));
		b_gosubStack[b_gosubSP++]=19; goto b_L2000;
b_ret19: ;
		/* line 1903 */
b_L1903: ;
		if(-((b_v_fri) == ((1)))){
			b_v_cls=b_keep(b_lit("A",1));
			b_v_w1i=((b_v_w1i)+((1)));
		}
		/* line 1904 */
b_L1904: ;
		goto b_L1901;
		/* line 1905 */
b_L1905: ;
		if((B_INT(-(b_strcmp(b_v_cls,b_lit("W",1)) >= 0)) & B_INT(-(b_strcmp(b_v_cls,b_lit("Z",1)) <= 0)))){
			b_v_w1i=(7);
		}
		/* line 1906 */
b_L1906: ;
		if(-(b_strcmp(b_v_cls,b_lit("X",1)) == 0)){
			b_v_fri=(1);
			goto b_L1909;
		}
		/* line 1907 */
b_L1907: ;
		if(-(b_strcmp(b_v_gcs,b_v_gds) > 0)){
			b_v_w1i=((b_v_w1i)+((7)));
			b_v_fri=(1);
			goto b_L1909;
		}
		/* line 1908 */
b_L1908: ;
		b_v_fri=(0);
		/* line 1909 */
b_L1909: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		b_v_fri=(2);
		if(-(b_strcmp(b_v_gas,b_v_gbs) != 0)){
			b_v_fri=(1);
		}
		/* line 2001 */
b_L2001: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		b_v_fri=(0);
		if(-((b_v_v3i) == ((3)))){
			b_v_fri=(1);
		}
		/* line 2101 */
b_L2101: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		b_v_jf=((((((B_INT(b_peek((unsigned int)((160)))))*((65536.0))))+(((B_INT(b_peek((unsigned int)((161)))))*((256.0))))))+(B_INT(b_peek((unsigned int)((162))))));
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
