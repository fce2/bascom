/* OPTIMIZE_C -- charedit.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_fbi;
static int b_v_chi;
static int b_v_pxi;
static int b_v_pyi;
static int b_v_lvi;
static int b_v_rfi;
static int b_v_uci;
static int b_a_mki[8];
static int b_v_bai;
static bstr_t b_v_ks;
static int b_v_aki;
static int b_v_oyi;
static int b_v_oxi;
static int b_v_rii;
static int b_v_cii;
static int b_v_bvi;
static int b_v_bmi;
static bint_t b_v_bpi;
static bint_t b_v_adi;
static int b_v_gri;
static bint_t b_v_bti;
static bint_t b_v_sri;
static bint_t b_v_gfi;
static int b_v_sgi;
static int b_v_cxi;
static int b_v_cri;
static int b_v_nbi;
static bint_t b_v_sci;
static bint_t b_v_lpi;
static int b_v_jyi;
static bint_t b_v_jxi;
static int b_v_gii;
static int b_v_jri;
static bint_t b_v_jci;
static bint_t b_v_ofi;
static int b_v_cci;
static int b_v_M0;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;
static bint_t b_t_5;
static bint_t b_t_6;
static bint_t b_t_7;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,12,0,0},{1,0,3,0,0},{1,0,54,0,0},{1,0,52,0,0},{1,0,32,0,0},{1,0,6,0,0},{1,0,15,0,0},{1,0,14,0,0},{1,0,20,0,0},{1,0,32,0,0},{1,0,5,0,0},{1,0,4,0,0},{1,0,9,0,0},{1,0,20,0,0},{1,0,15,0,0},{1,0,18,0,0},{1,0,-1,0,0},{1,0,60,0,0},{1,0,3,0,0},{1,0,8,0,0},{1,0,1,0,0},{1,0,18,0,0},{1,0,58,0,0},{1,0,-1,0,0},{1,0,180,0,0},{1,0,2,0,0},{1,0,25,0,0},{1,0,20,0,0},{1,0,5,0,0},{1,0,19,0,0},{1,0,-1,0,0},{1,0,340,0,0},{1,0,3,0,0},{1,0,21,0,0},{1,0,18,0,0},{1,0,19,0,0},{1,0,-1,0,0},{1,0,380,0,0},{1,0,2,0,0},{1,0,9,0,0},{1,0,20,0,0},{1,0,58,0,0},{1,0,-1,0,0},{1,0,460,0,0},{1,0,12,0,0},{1,0,9,0,0},{1,0,22,0,0},{1,0,5,0,0},{1,0,58,0,0},{1,0,-1,0,0},{1,0,802,0,0},{1,0,3,0,0},{1,0,18,0,0},{1,0,19,0,0},{1,0,18,0,0},{1,0,32,0,0},{1,0,13,0,0},{1,0,15,0,0},{1,0,22,0,0},{1,0,5,0,0},{1,0,32,0,0},{1,0,19,0,0},{1,0,16,0,0},{1,0,1,0,0},{1,0,3,0,0},{1,0,5,0,0},{1,0,32,0,0},{1,0,20,0,0},{1,0,15,0,0},{1,0,7,0,0},{1,0,32,0,0},{1,0,44,0,0},{1,0,46,0,0},{1,0,32,0,0},{1,0,3,0,0},{1,0,8,0,0},{1,0,1,0,0},{1,0,18,0,0},{1,0,-1,0,0},{1,0,842,0,0},{1,0,3,0,0},{1,0,32,0,0},{1,0,3,0,0},{1,0,12,0,0},{1,0,18,0,0},{1,0,32,0,0},{1,0,9,0,0},{1,0,32,0,0},{1,0,9,0,0},{1,0,14,0,0},{1,0,22,0,0},{1,0,32,0,0},{1,0,6,0,0},{1,0,32,0,0},{1,0,6,0,0},{1,0,9,0,0},{1,0,12,0,0},{1,0,12,0,0},{1,0,32,0,0},{1,0,8,0,0},{1,0,32,0,0},{1,0,8,0,0},{1,0,6,0,0},{1,0,12,0,0},{1,0,9,0,0},{1,0,16,0,0},{1,0,32,0,0},{1,0,22,0,0},{1,0,32,0,0},{1,0,22,0,0},{1,0,6,0,0},{1,0,12,0,0},{1,0,9,0,0},{1,0,16,0,0},{1,0,-1,0,0},{1,0,882,0,0},{1,0,18,0,0},{1,0,32,0,0},{1,0,18,0,0},{1,0,5,0,0},{1,0,19,0,0},{1,0,5,0,0},{1,0,20,0,0},{1,0,32,0,0},{1,0,20,0,0},{1,0,32,0,0},{1,0,12,0,0},{1,0,9,0,0},{1,0,22,0,0},{1,0,5,0,0},{1,0,32,0,0},{1,0,12,0,0},{1,0,32,0,0},{1,0,12,0,0},{1,0,15,0,0},{1,0,1,0,0},{1,0,4,0,0},{1,0,32,0,0},{1,0,19,0,0},{1,0,32,0,0},{1,0,19,0,0},{1,0,1,0,0},{1,0,22,0,0},{1,0,5,0,0},{1,0,-1,0,0},{1,0,922,0,0},{1,0,16,0,0},{1,0,32,0,0},{1,0,16,0,0},{1,0,18,0,0},{1,0,5,0,0},{1,0,22,0,0},{1,0,32,0,0},{1,0,14,0,0},{1,0,32,0,0},{1,0,14,0,0},{1,0,1,0,0},{1,0,22,0,0},{1,0,9,0,0},{1,0,7,0,0},{1,0,32,0,0},{1,0,17,0,0},{1,0,32,0,0},{1,0,17,0,0},{1,0,21,0,0},{1,0,9,0,0},{1,0,20,0,0},{1,0,-1,0,0},{1,0,-999,0,0}};
int b_data_len = 169;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_poke((56576.0),(B_INT(B_INT(b_peek((unsigned int)((56576.0))))) & B_INT((254))));
		b_poke((648),(68));
		b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 30 */
b_L30: ;
		b_v_fbi=(20480);
		b_v_chi=(0);
		b_v_pxi=(0);
		b_v_pyi=(0);
		b_v_lvi=(1);
		b_v_rfi=(1);
		b_v_uci=(1);
		/* line 40 */
b_L40: ;
		b_a_mki[B_INT((0))]=(1);
		b_a_mki[B_INT((1))]=(2);
		b_a_mki[B_INT((2))]=(4);
		b_a_mki[B_INT((3))]=(8);
		b_a_mki[B_INT((4))]=(16);
		b_a_mki[B_INT((5))]=(32);
		b_a_mki[B_INT((6))]=(64);
		b_a_mki[B_INT((7))]=(128);
		/* line 50 */
b_L50: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L3800;
b_ret0: ;
		/* line 60 */
b_L60: ;
		b_v_bai=((b_v_fbi)+(((b_v_chi)*((8)))));
		/* line 70 */
b_L70: ;
		b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		/* line 80 */
b_L80: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L3900;
b_ret1: ;
		/* line 90 */
b_L90: ;
		b_wait((53265.0),(128),0);
		/* line 100 */
b_L100: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L310; }
		/* line 110 */
b_L110: ;
		b_v_aki=b_asc(b_v_ks);
		/* line 120 */
b_L120: ;
		if(-(b_strcmp(b_v_ks,b_lit("\021",1)) == 0)){
			b_gosubStack[b_gosubSP++]=2; goto b_L1000;
b_ret2: ;
			goto b_L320;
		}
		/* line 130 */
b_L130: ;
		if(-(b_strcmp(b_v_ks,b_lit("\221",1)) == 0)){
			b_gosubStack[b_gosubSP++]=3; goto b_L1000;
b_ret3: ;
			goto b_L320;
		}
		/* line 140 */
b_L140: ;
		if(-(b_strcmp(b_v_ks,b_lit("\035",1)) == 0)){
			b_gosubStack[b_gosubSP++]=4; goto b_L1000;
b_ret4: ;
			goto b_L320;
		}
		/* line 150 */
b_L150: ;
		if(-(b_strcmp(b_v_ks,b_lit("\235",1)) == 0)){
			b_gosubStack[b_gosubSP++]=5; goto b_L1000;
b_ret5: ;
			goto b_L320;
		}
		/* line 160 */
b_L160: ;
		if(-(b_strcmp(b_v_ks,b_lit(" ",1)) == 0)){
			b_gosubStack[b_gosubSP++]=6; goto b_L1100;
b_ret6: ;
			goto b_L320;
		}
		/* line 170 */
b_L170: ;
		if(-(b_strcmp(b_v_ks,b_lit(",",1)) == 0)){
			b_gosubStack[b_gosubSP++]=7; goto b_L1300;
b_ret7: ;
			goto b_L310;
		}
		/* line 180 */
b_L180: ;
		if(-(b_strcmp(b_v_ks,b_lit(".",1)) == 0)){
			b_gosubStack[b_gosubSP++]=8; goto b_L1200;
b_ret8: ;
			goto b_L310;
		}
		/* line 190 */
b_L190: ;
		if(-(b_strcmp(b_v_ks,b_lit("C",1)) == 0)){
			b_gosubStack[b_gosubSP++]=9; goto b_L1400;
b_ret9: ;
			goto b_L310;
		}
		/* line 200 */
b_L200: ;
		if(-(b_strcmp(b_v_ks,b_lit("I",1)) == 0)){
			b_gosubStack[b_gosubSP++]=10; goto b_L1500;
b_ret10: ;
			goto b_L310;
		}
		/* line 210 */
b_L210: ;
		if(-(b_strcmp(b_v_ks,b_lit("F",1)) == 0)){
			b_gosubStack[b_gosubSP++]=11; goto b_L1600;
b_ret11: ;
			goto b_L310;
		}
		/* line 220 */
b_L220: ;
		if(-(b_strcmp(b_v_ks,b_lit("H",1)) == 0)){
			b_gosubStack[b_gosubSP++]=12; goto b_L1700;
b_ret12: ;
			goto b_L310;
		}
		/* line 230 */
b_L230: ;
		if(-(b_strcmp(b_v_ks,b_lit("V",1)) == 0)){
			b_gosubStack[b_gosubSP++]=13; goto b_L1800;
b_ret13: ;
			goto b_L310;
		}
		/* line 240 */
b_L240: ;
		if(-(b_strcmp(b_v_ks,b_lit("R",1)) == 0)){
			b_gosubStack[b_gosubSP++]=14; goto b_L1900;
b_ret14: ;
			goto b_L310;
		}
		/* line 250 */
b_L250: ;
		if(-(b_strcmp(b_v_ks,b_lit("T",1)) == 0)){
			b_gosubStack[b_gosubSP++]=15; goto b_L2000;
b_ret15: ;
			goto b_L310;
		}
		/* line 260 */
b_L260: ;
		if(-(b_strcmp(b_v_ks,b_lit("L",1)) == 0)){
			b_gosubStack[b_gosubSP++]=16; goto b_L3400;
b_ret16: ;
			goto b_L310;
		}
		/* line 265 */
b_L265: ;
		if(-(b_strcmp(b_v_ks,b_lit("U",1)) == 0)){
			b_gosubStack[b_gosubSP++]=17; goto b_L4100;
b_ret17: ;
			goto b_L310;
		}
		/* line 270 */
b_L270: ;
		if(-(b_strcmp(b_v_ks,b_lit("S",1)) == 0)){
			b_gosubStack[b_gosubSP++]=18; goto b_L3500;
b_ret18: ;
			goto b_L310;
		}
		/* line 280 */
b_L280: ;
		if(-(b_strcmp(b_v_ks,b_lit("N",1)) == 0)){
			b_gosubStack[b_gosubSP++]=19; goto b_L3700;
b_ret19: ;
			goto b_L310;
		}
		/* line 290 */
b_L290: ;
		if(-(b_strcmp(b_v_ks,b_lit("P",1)) == 0)){
			b_gosubStack[b_gosubSP++]=20; goto b_L3600;
b_ret20: ;
			goto b_L310;
		}
		/* line 300 */
b_L300: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){ goto b_L4000; }
		/* line 310 */
b_L310: ;
		if(-((b_v_rfi) == ((1)))){
			b_gosubStack[b_gosubSP++]=21; goto b_L2100;
b_ret21: ;
			b_gosubStack[b_gosubSP++]=22; goto b_L2200;
b_ret22: ;
			b_v_rfi=(0);
		}
		/* line 320 */
b_L320: ;
		goto b_L90;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_oyi=b_v_pyi;
		b_v_oxi=b_v_pxi;
		/* line 1002 */
b_L1002: ;
		if(-((b_v_aki) == ((17)))){
			b_v_pyi=((b_v_pyi)+((1)));
			if(-((b_v_pyi) == ((8)))){
				b_v_pyi=(0);
			}
		}
		/* line 1003 */
b_L1003: ;
		if(-((b_v_aki) == ((145)))){
			b_v_pyi=((b_v_pyi)-((1)));
			if(-((b_v_pyi) == ((-1)))){
				b_v_pyi=(7);
			}
		}
		/* line 1004 */
b_L1004: ;
		if(-((b_v_aki) == ((29)))){
			b_v_pxi=((b_v_pxi)+((1)));
			if(-((b_v_pxi) == ((8)))){
				b_v_pxi=(0);
			}
		}
		/* line 1005 */
b_L1005: ;
		if(-((b_v_aki) == ((157)))){
			b_v_pxi=((b_v_pxi)-((1)));
			if(-((b_v_pxi) == ((-1)))){
				b_v_pxi=(7);
			}
		}
		/* line 1006 */
b_L1006: ;
		b_v_rii=b_v_oyi;
		b_v_cii=b_v_oxi;
		b_gosubStack[b_gosubSP++]=23; goto b_L2700;
b_ret23: ;
		/* line 1007 */
b_L1007: ;
		b_v_rii=b_v_pyi;
		b_v_cii=b_v_pxi;
		b_gosubStack[b_gosubSP++]=24; goto b_L2700;
b_ret24: ;
		/* line 1008 */
b_L1008: ;
		b_poke((17754),(((48))+(b_v_pyi)));
		b_poke((17755),(44));
		b_poke((17756),(((48))+(b_v_pxi)));
		b_gosubStack[b_gosubSP++]=25; goto b_L3000;
b_ret25: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pyi)))));
		b_v_bmi=b_a_mki[B_INT((((7))-(b_v_pxi)))];
		/* line 1102 */
b_L1102: ;
		if(-(((B_INT(b_v_bvi) & B_INT(b_v_bmi))) == ((0)))){
			b_poke(((b_v_bai)+(b_v_pyi)),((b_v_bvi)+(b_v_bmi)));
			goto b_L1104;
		}
		/* line 1103 */
b_L1103: ;
		b_poke(((b_v_bai)+(b_v_pyi)),((b_v_bvi)-(b_v_bmi)));
		/* line 1104 */
b_L1104: ;
		b_v_rii=b_v_pyi;
		b_v_cii=b_v_pxi;
		b_gosubStack[b_gosubSP++]=26; goto b_L2700;
b_ret26: ;
		/* line 1105 */
b_L1105: ;
		b_v_bpi=b_v_pyi;
		b_v_adi=(((17628))+(((b_v_bpi)*((3)))));
		if(-((b_v_bpi) >= ((4)))){
			b_v_adi=(((17668))+(((((b_v_bpi)-((4))))*((3)))));
		}
		/* line 1106 */
b_L1106: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L3300;
b_ret27: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L3000;
b_ret28: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_v_chi=((b_v_chi)+((1)));
		if(-((b_v_chi) == ((256)))){
			b_v_chi=(0);
		}
		/* line 1202 */
b_L1202: ;
		b_v_bai=((b_v_fbi)+(((b_v_chi)*((8)))));
		b_v_rfi=(1);
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_v_chi=((b_v_chi)-((1)));
		if(-((b_v_chi) == ((-1)))){
			b_v_chi=(255);
		}
		/* line 1302 */
b_L1302: ;
		b_v_bai=((b_v_fbi)+(((b_v_chi)*((8)))));
		b_v_rfi=(1);
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_v_bpi=(0);
		if(b_v_bpi > 7) goto b_f0_e;
		b_t_0=((b_v_bai)+(b_v_bpi));
b_f0_t: ;
		b_poke(b_t_0,(0));
		b_t_0 += 1;
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f0_t;
b_f0_e: ;
		/* line 1402 */
b_L1402: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_v_bpi=(0);
		if(b_v_bpi > 7) goto b_f1_e;
		b_t_1=((b_v_bai)+(b_v_bpi));
b_f1_t: ;
		b_poke(b_t_1,(((255))-(B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_bpi))))))));
		b_t_1 += 1;
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f1_t;
b_f1_e: ;
		/* line 1502 */
b_L1502: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		b_v_bpi=(0);
		if(b_v_bpi > 7) goto b_f2_e;
		b_t_2=((b_v_bai)+(b_v_bpi));
b_f2_t: ;
		b_poke(b_t_2,(255));
		b_t_2 += 1;
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f2_t;
b_f2_e: ;
		/* line 1602 */
b_L1602: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_gri=(0);
		if(b_v_gri > 7) goto b_f3_e;
		b_t_4=((b_v_bai)+(b_v_gri));
b_f3_t: ;
		/* line 1702 */
b_L1702: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(b_t_4)));
		b_v_bti=(0);
		/* line 1703 */
b_L1703: ;
		b_v_bpi=(0);
		if(b_v_bpi > 7) goto b_f4_e;
b_f4_t: ;
		/* line 1704 */
b_L1704: ;
		if(-(((B_INT(b_v_bvi) & B_INT(b_a_mki[B_INT(b_v_bpi)]))) != ((0)))){
			b_v_bti=((b_v_bti)+(b_a_mki[B_INT((((7))-(b_v_bpi)))]));
		}
		/* line 1705 */
b_L1705: ;
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f4_t;
b_f4_e: ;
		/* line 1706 */
b_L1706: ;
		b_poke(b_t_4,b_v_bti);
		/* line 1707 */
b_L1707: ;
		b_t_4 += 1;
		b_v_gri += 1;
		if(b_v_gri <= 7) goto b_f3_t;
b_f3_e: ;
		/* line 1708 */
b_L1708: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_bpi=(0);
		if(b_v_bpi > 3) goto b_f5_e;
		b_v_M0=((b_v_bai)+((7)));
		b_t_5=((b_v_bai)+(b_v_bpi));
		b_t_6=((b_v_M0)-(b_v_bpi));
b_f5_t: ;
		/* line 1802 */
b_L1802: ;
		b_v_bti=B_INT(b_peek((unsigned int)(b_t_5)));
		b_poke(b_t_5,B_INT(b_peek((unsigned int)(((b_v_M0)-(b_v_bpi))))));
		b_poke(b_t_6,b_v_bti);
		/* line 1803 */
b_L1803: ;
		b_t_5 += 1;
		b_t_6 += -1;
		b_v_bpi += 1;
		if(b_v_bpi <= 3) goto b_f5_t;
b_f5_e: ;
		/* line 1804 */
b_L1804: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_poke((56333.0),(127));
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) & B_INT((251))));
		/* line 1902 */
b_L1902: ;
		b_v_sri=(53248.0);
		if(-((b_v_uci) == ((0)))){
			b_v_sri=(55296.0);
		}
		/* line 1903 */
b_L1903: ;
		b_v_sri=((b_v_sri)+(((b_v_chi)*((8)))));
		b_v_bpi=(0);
		if(b_v_bpi > 7) goto b_f6_e;
b_f6_t: ;
		b_poke(((b_v_bai)+(b_v_bpi)),B_INT(b_peek((unsigned int)(((b_v_sri)+(b_v_bpi))))));
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f6_t;
b_f6_e: ;
		/* line 1904 */
b_L1904: ;
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) | B_INT((4))));
		b_poke((56333.0),(129));
		b_v_rfi=(1);
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_lvi=(((1))-(b_v_lvi));
		/* line 2002 */
b_L2002: ;
		if(-((b_v_lvi) == ((1)))){
			b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		}
		/* line 2003 */
b_L2003: ;
		if(-((b_v_lvi) == ((0)))){
			b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((2))));
		}
		/* line 2004 */
b_L2004: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_v_rii=(0);
		b_v_gfi=(122);
		/* line 2102 */
b_L2102: ;
		if(-((b_v_rii) == ((8)))){ goto b_L2109; }
		/* line 2103 */
b_L2103: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_rii)))));
		/* line 2104 */
b_L2104: ;
		b_v_cii=(0);
		/* line 2105 */
b_L2105: ;
		if(-((b_v_cii) == ((8)))){
			b_v_rii=((b_v_rii)+((1)));
			b_v_gfi=(((122))+(((b_v_rii)*((80)))));
			goto b_L2102;
		}
		/* line 2106 */
b_L2106: ;
		b_v_bmi=b_a_mki[B_INT((((7))-(b_v_cii)))];
		b_v_sgi=(0);
		if(-(((B_INT(b_v_bvi) & B_INT(b_v_bmi))) != ((0)))){
			b_v_sgi=(1);
		}
		/* line 2107 */
b_L2107: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L2300;
b_ret29: ;
		/* line 2108 */
b_L2108: ;
		b_v_cii=((b_v_cii)+((1)));
		b_v_gfi=((b_v_gfi)+((2)));
		goto b_L2105;
		/* line 2109 */
b_L2109: ;
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_gosubStack[b_gosubSP++]=30; goto b_L2900;
b_ret30: ;
		/* line 2202 */
b_L2202: ;
		b_poke((17515),b_v_chi);
		b_poke((55403.0),(1));
		/* line 2203 */
b_L2203: ;
		b_gosubStack[b_gosubSP++]=31; goto b_L3200;
b_ret31: ;
		/* line 2204 */
b_L2204: ;
		b_poke((17754),(((48))+(b_v_pyi)));
		b_poke((17755),(44));
		b_poke((17756),(((48))+(b_v_pxi)));
		/* line 2205 */
b_L2205: ;
		b_gosubStack[b_gosubSP++]=32; goto b_L3000;
b_ret32: ;
		/* line 2206 */
b_L2206: ;
		b_gosubStack[b_gosubSP++]=33; goto b_L3100;
b_ret33: ;
		/* line 2207 */
b_L2207: ;
		goto b_return;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		if(-((b_v_rii) == (b_v_pyi))){
			if(-((b_v_cii) == (b_v_pxi))){
				b_gosubStack[b_gosubSP++]=34; goto b_L2400;
b_ret34: ;
				goto b_return;
			}
		}
		/* line 2302 */
b_L2302: ;
		if(-((b_v_sgi) == ((1)))){
			b_v_cxi=(160);
			b_v_cri=(1);
			b_gosubStack[b_gosubSP++]=35; goto b_L2500;
b_ret35: ;
			b_gosubStack[b_gosubSP++]=36; goto b_L2600;
b_ret36: ;
			goto b_return;
		}
		/* line 2303 */
b_L2303: ;
		b_v_cxi=(32);
		b_v_cri=(0);
		b_gosubStack[b_gosubSP++]=37; goto b_L2500;
b_ret37: ;
		b_gosubStack[b_gosubSP++]=38; goto b_L2600;
b_ret38: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_v_cxi=(160);
		b_v_cri=(7);
		if(-((b_v_sgi) == ((0)))){
			b_v_cri=(8);
		}
		/* line 2402 */
b_L2402: ;
		b_gosubStack[b_gosubSP++]=39; goto b_L2500;
b_ret39: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L2600;
b_ret40: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		b_poke((((17408))+(b_v_gfi)),b_v_cxi);
		b_poke((((((17408))+(b_v_gfi)))+((1))),b_v_cxi);
		/* line 2502 */
b_L2502: ;
		b_poke((((((17408))+(b_v_gfi)))+((40))),b_v_cxi);
		b_poke((((((17408))+(b_v_gfi)))+((41))),b_v_cxi);
		goto b_return;
		/* line 2600 */
b_L2600: ;
		/* line 2601 */
b_L2601: ;
		b_poke((((55296.0))+(b_v_gfi)),b_v_cri);
		b_poke((((((55296.0))+(b_v_gfi)))+((1))),b_v_cri);
		/* line 2602 */
b_L2602: ;
		b_poke((((((55296.0))+(b_v_gfi)))+((40))),b_v_cri);
		b_poke((((((55296.0))+(b_v_gfi)))+((41))),b_v_cri);
		goto b_return;
		/* line 2700 */
b_L2700: ;
		/* line 2701 */
b_L2701: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_rii)))));
		b_v_bmi=b_a_mki[B_INT((((7))-(b_v_cii)))];
		b_v_sgi=(0);
		if(-(((B_INT(b_v_bvi) & B_INT(b_v_bmi))) != ((0)))){
			b_v_sgi=(1);
		}
		/* line 2702 */
b_L2702: ;
		b_v_gfi=((((((b_v_cii)*((2))))+(((b_v_rii)*((80))))))+((122)));
		/* line 2703 */
b_L2703: ;
		if(-((b_v_rii) == (b_v_pyi))){
			if(-((b_v_cii) == (b_v_pxi))){
				b_gosubStack[b_gosubSP++]=41; goto b_L2400;
b_ret41: ;
				goto b_return;
			}
		}
		/* line 2704 */
b_L2704: ;
		if(-((b_v_sgi) == ((1)))){
			b_v_cxi=(160);
			b_v_cri=(1);
			b_gosubStack[b_gosubSP++]=42; goto b_L2500;
b_ret42: ;
			b_gosubStack[b_gosubSP++]=43; goto b_L2600;
b_ret43: ;
			goto b_return;
		}
		/* line 2705 */
b_L2705: ;
		b_v_cxi=(32);
		b_v_cri=(0);
		b_gosubStack[b_gosubSP++]=44; goto b_L2500;
b_ret44: ;
		b_gosubStack[b_gosubSP++]=45; goto b_L2600;
b_ret45: ;
		goto b_return;
		/* line 2800 */
b_L2800: ;
		/* line 2801 */
b_L2801: ;
		b_v_nbi=b_int(((breal_t)(b_v_bvi)/(breal_t)((16))));
		/* line 2802 */
b_L2802: ;
		if(-((b_v_nbi) < ((10)))){
			b_v_sci=(((48))+(b_v_nbi));
			goto b_L2804;
		}
		/* line 2803 */
b_L2803: ;
		b_v_sci=((b_v_nbi)-((9)));
		/* line 2804 */
b_L2804: ;
		b_v_nbi=((b_v_bvi)-((((16))*(b_v_nbi))));
		/* line 2805 */
b_L2805: ;
		if(-((b_v_nbi) < ((10)))){
			b_v_bvi=(((48))+(b_v_nbi));
			goto b_L2807;
		}
		/* line 2806 */
b_L2806: ;
		b_v_bvi=((b_v_nbi)-((9)));
		/* line 2807 */
b_L2807: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		/* line 2901 */
b_L2901: ;
		b_v_bti=b_v_chi;
		b_v_sci=(((48))+(b_int(((breal_t)(b_v_bti)/(breal_t)((100))))));
		b_v_bti=((b_v_bti)-((((100))*(b_int(((breal_t)(b_v_bti)/(breal_t)((100))))))));
		/* line 2902 */
b_L2902: ;
		b_poke((17474),b_v_sci);
		b_v_sci=(((48))+(b_int(((breal_t)(b_v_bti)/(breal_t)((10))))));
		b_v_bti=((b_v_bti)-((((10))*(b_int(((breal_t)(b_v_bti)/(breal_t)((10))))))));
		/* line 2903 */
b_L2903: ;
		b_poke((17475),b_v_sci);
		b_poke((17476),(((48))+(b_v_bti)));
		/* line 2904 */
b_L2904: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3001 */
b_L3001: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pyi)))));
		b_v_bmi=b_a_mki[B_INT((((7))-(b_v_pxi)))];
		b_v_sgi=(0);
		/* line 3002 */
b_L3002: ;
		if(-(((B_INT(b_v_bvi) & B_INT(b_v_bmi))) != ((0)))){
			b_v_sgi=(1);
		}
		/* line 3003 */
b_L3003: ;
		if(-((b_v_sgi) == ((1)))){
			b_poke((17794),(15));
			b_poke((17795),(14));
			b_poke((17796),(32));
			goto b_return;
		}
		/* line 3004 */
b_L3004: ;
		b_poke((17794),(15));
		b_poke((17795),(6));
		b_poke((17796),(6));
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3101 */
b_L3101: ;
		if(-((b_v_lvi) == ((1)))){
			b_poke((17874),(15));
			b_poke((17875),(14));
			b_poke((17876),(32));
			goto b_return;
		}
		/* line 3102 */
b_L3102: ;
		b_poke((17874),(15));
		b_poke((17875),(6));
		b_poke((17876),(6));
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3201 */
b_L3201: ;
		b_v_adi=(17628);
		/* line 3202 */
b_L3202: ;
		b_v_bpi=(0);
		if(b_v_bpi > 3) goto b_f7_e;
b_f7_t: ;
		b_gosubStack[b_gosubSP++]=46; goto b_L3300;
b_ret46: ;
		b_v_adi=((b_v_adi)+((3)));
		b_v_bpi += 1;
		if(b_v_bpi <= 3) goto b_f7_t;
b_f7_e: ;
		/* line 3203 */
b_L3203: ;
		b_v_adi=(17668);
		/* line 3204 */
b_L3204: ;
		b_v_bpi=(4);
		if(b_v_bpi > 7) goto b_f8_e;
b_f8_t: ;
		b_gosubStack[b_gosubSP++]=47; goto b_L3300;
b_ret47: ;
		b_v_adi=((b_v_adi)+((3)));
		b_v_bpi += 1;
		if(b_v_bpi <= 7) goto b_f8_t;
b_f8_e: ;
		/* line 3205 */
b_L3205: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		/* line 3301 */
b_L3301: ;
		b_v_bvi=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_bpi)))));
		b_gosubStack[b_gosubSP++]=48; goto b_L2800;
b_ret48: ;
		b_poke(b_v_adi,b_v_sci);
		b_poke(((b_v_adi)+((1))),b_v_bvi);
		b_poke(((b_v_adi)+((2))),(32));
		goto b_return;
		/* line 3400 */
b_L3400: ;
		/* line 3401 */
b_L3401: ;
		b_poke((53280.0),(2));
		/* line 3402 */
b_L3402: ;
		b_loadf(b_lit("FONT,S",6),0,(8),(1));
		/* line 3403 */
b_L3403: ;
		b_poke((53280.0),(0));
		b_v_rfi=(1);
		goto b_return;
		/* line 3500 */
b_L3500: ;
		/* line 3501 */
b_L3501: ;
		b_poke((53280.0),(2));
		/* line 3502 */
b_L3502: ;
		b_open((1),(8),(1),b_lit("@0:FONT,S,W",11));
		/* line 3503 */
b_L3503: ;
		{ b_chkout((1)); b_nl();
		}
		/* line 3504 */
b_L3504: ;
		b_putc(0);
		b_putc(80);
		/* line 3505 */
b_L3505: ;
		b_v_lpi=(0);
		if(b_v_lpi > 2047) goto b_f9_e;
		b_t_7=(((20480))+(b_v_lpi));
b_f9_t: ;
		b_putc(B_INT(b_peek((unsigned int)(b_t_7))));
		b_t_7 += 1;
		b_v_lpi += 1;
		if(b_v_lpi <= 2047) goto b_f9_t;
b_f9_e: ;
		/* line 3506 */
b_L3506: ;
		{ b_chkout((1)); b_nl();
			b_clrch(); }
		/* line 3507 */
b_L3507: ;
		b_close((1));
		/* line 3508 */
b_L3508: ;
		b_poke((53280.0),(0));
		b_v_rfi=(1);
		goto b_return;
		/* line 3600 */
b_L3600: ;
		/* line 3601 */
b_L3601: ;
		b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		/* line 3602 */
b_L3602: ;
		b_putc(147);
		b_nl();
		/* line 3603 */
b_L3603: ;
		b_nl();
		{ bstr_t _t=b_lit("THE QUICK BROWN FOX JUMPS",25); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3604 */
b_L3604: ;
		{ bstr_t _t=b_lit("OVER THE LAZY DOG",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3605 */
b_L3605: ;
		b_nl();
		{ bstr_t _t=b_lit("0123456789 !?.,:;'+-*/=<>",25); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3606 */
b_L3606: ;
		b_nl();
		{ bstr_t _t=b_lit("ANY KEY TO RETURN",17); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3607 */
b_L3607: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L3607; }
		/* line 3608 */
b_L3608: ;
		b_putc(147);
		b_nl();
		/* line 3609 */
b_L3609: ;
		if(-((b_v_lvi) == ((0)))){
			b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((2))));
		}
		/* line 3610 */
b_L3610: ;
		b_gosubStack[b_gosubSP++]=49; goto b_L3900;
b_ret49: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 3700 */
b_L3700: ;
		/* line 3701 */
b_L3701: ;
		b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		/* line 3702 */
b_L3702: ;
		b_putc(147);
		b_nl();
		{ bstr_t _t=b_lit("CRSR=MOVE ENTER/SPACE=PICK Q=EXIT",33); b_str(_t.p,_t.len); }
		b_nl();
		/* line 3703 */
b_L3703: ;
		b_v_jyi=b_int(((breal_t)(b_v_chi)/(breal_t)((16))));
		b_v_jxi=((b_v_chi)-((((16))*(b_v_jyi))));
		/* line 3704 */
b_L3704: ;
		b_v_gii=(0);
		if(b_v_gii > 255) goto b_f10_e;
b_f10_t: ;
		/* line 3705 */
b_L3705: ;
		b_v_jri=b_int(((breal_t)(b_v_gii)/(breal_t)((16))));
		b_v_jci=((b_v_gii)-((((16))*(b_v_jri))));
		/* line 3706 */
b_L3706: ;
		b_poke((((((17410))+(b_v_jci)))+(((((b_v_jri)+((2))))*((40))))),b_v_gii);
		b_poke((((((((55296.0))+((2))))+(b_v_jci)))+(((((b_v_jri)+((2))))*((40))))),(14));
		/* line 3707 */
b_L3707: ;
		b_v_gii += 1;
		if(b_v_gii <= 255) goto b_f10_t;
b_f10_e: ;
		/* line 3708 */
b_L3708: ;
		b_poke((17518),(3));
		b_poke((17519),(8));
		b_poke((17520),(1));
		b_poke((17521),(18));
		b_poke((17522),(58));
		b_gosubStack[b_gosubSP++]=50; goto b_L3750;
b_ret50: ;
		b_poke((((((((55296.0))+((2))))+(b_v_jxi)))+(((((b_v_jyi)+((2))))*((40))))),(7));
		/* line 3709 */
b_L3709: ;
		{ int _g=b_getin(); if(_g<0) b_v_ks=b_lit("",0); else b_v_ks=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_ks,b_lit("",0)) == 0)){ goto b_L3709; }
		/* line 3710 */
b_L3710: ;
		b_v_aki=b_asc(b_v_ks);
		/* line 3711 */
b_L3711: ;
		b_poke((((((((55296.0))+((2))))+(b_v_jxi)))+(((((b_v_jyi)+((2))))*((40))))),(14));
		/* line 3712 */
b_L3712: ;
		if(-(b_strcmp(b_v_ks,b_lit("\021",1)) == 0)){
			b_v_jyi=((b_v_jyi)+((1)));
			if(-((b_v_jyi) == ((16)))){
				b_v_jyi=(0);
			}
		}
		/* line 3713 */
b_L3713: ;
		if(-(b_strcmp(b_v_ks,b_lit("\221",1)) == 0)){
			b_v_jyi=((b_v_jyi)-((1)));
			if(-((b_v_jyi) == ((-1)))){
				b_v_jyi=(15);
			}
		}
		/* line 3714 */
b_L3714: ;
		if(-(b_strcmp(b_v_ks,b_lit("\035",1)) == 0)){
			b_v_jxi=((b_v_jxi)+((1)));
			if(-((b_v_jxi) == ((16)))){
				b_v_jxi=(0);
			}
		}
		/* line 3715 */
b_L3715: ;
		if(-(b_strcmp(b_v_ks,b_lit("\235",1)) == 0)){
			b_v_jxi=((b_v_jxi)-((1)));
			if(-((b_v_jxi) == ((-1)))){
				b_v_jxi=(15);
			}
		}
		/* line 3716 */
b_L3716: ;
		if(-(b_strcmp(b_v_ks,b_lit("\r",1)) == 0)){
			b_v_chi=((((b_v_jyi)*((16))))+(b_v_jxi));
			b_v_bai=((b_v_fbi)+(((b_v_chi)*((8)))));
			goto b_L3721;
		}
		/* line 3717 */
b_L3717: ;
		if(-(b_strcmp(b_v_ks,b_lit(" ",1)) == 0)){
			b_v_chi=((((b_v_jyi)*((16))))+(b_v_jxi));
			b_v_bai=((b_v_fbi)+(((b_v_chi)*((8)))));
			goto b_L3721;
		}
		/* line 3718 */
b_L3718: ;
		if(-(b_strcmp(b_v_ks,b_lit("Q",1)) == 0)){
			goto b_L3721;
		}
		/* line 3719 */
b_L3719: ;
		if(-(b_strcmp(b_v_ks,b_lit("U",1)) == 0)){
			b_gosubStack[b_gosubSP++]=51; goto b_L4100;
b_ret51: ;
			goto b_L3709;
		}
		/* line 3720 */
b_L3720: ;
		b_gosubStack[b_gosubSP++]=52; goto b_L3750;
b_ret52: ;
		b_poke((((((((55296.0))+((2))))+(b_v_jxi)))+(((((b_v_jyi)+((2))))*((40))))),(7));
		goto b_L3709;
		/* line 3721 */
b_L3721: ;
		b_putc(147);
		b_nl();
		/* line 3722 */
b_L3722: ;
		if(-((b_v_lvi) == ((0)))){
			b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((2))));
		}
		/* line 3723 */
b_L3723: ;
		b_gosubStack[b_gosubSP++]=53; goto b_L3900;
b_ret53: ;
		b_v_rfi=(1);
		goto b_return;
		/* line 3750 */
b_L3750: ;
		/* line 3751 */
b_L3751: ;
		b_v_bti=((((b_v_jyi)*((16))))+(b_v_jxi));
		b_v_sci=(((48))+(b_int(((breal_t)(b_v_bti)/(breal_t)((100))))));
		b_v_bti=((b_v_bti)-((((100))*(b_int(((breal_t)(b_v_bti)/(breal_t)((100))))))));
		/* line 3752 */
b_L3752: ;
		b_poke((17523),b_v_sci);
		b_v_sci=(((48))+(b_int(((breal_t)(b_v_bti)/(breal_t)((10))))));
		b_v_bti=((b_v_bti)-((((10))*(b_int(((breal_t)(b_v_bti)/(breal_t)((10))))))));
		/* line 3753 */
b_L3753: ;
		b_poke((17524),b_v_sci);
		b_poke((17525),(((48))+(b_v_bti)));
		/* line 3754 */
b_L3754: ;
		b_poke((55411.0),(7));
		b_poke((55412.0),(7));
		b_poke((55413.0),(7));
		goto b_return;
		/* line 3800 */
b_L3800: ;
		/* line 3801 */
b_L3801: ;
		b_poke((56333.0),(127));
		/* line 3802 */
b_L3802: ;
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) & B_INT((251))));
		/* line 3803 */
b_L3803: ;
		b_v_lpi=(0);
		if(b_v_lpi > 2047) goto b_f11_e;
b_f11_t: ;
		b_poke((((20480))+(b_v_lpi)),B_INT(b_peek((unsigned int)((((53248.0))+(b_v_lpi))))));
		b_v_lpi += 1;
		if(b_v_lpi <= 2047) goto b_f11_t;
b_f11_e: ;
		/* line 3804 */
b_L3804: ;
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) | B_INT((4))));
		/* line 3805 */
b_L3805: ;
		b_poke((56333.0),(129));
		/* line 3806 */
b_L3806: ;
		goto b_return;
		/* line 3900 */
b_L3900: ;
		/* line 3901 */
b_L3901: ;
		b_dataPtr = 0;
		/* line 3902 */
b_L3902: ;
		b_v_ofi=b_read_int();
		/* line 3903 */
b_L3903: ;
		if(-((b_v_ofi) == ((-999)))){
			goto b_return;
		}
		/* line 3904 */
b_L3904: ;
		b_v_cci=b_read_int();
		if(-((b_v_cci) == ((-1)))){ goto b_L3902; }
		/* line 3905 */
b_L3905: ;
		b_poke((((17408))+(b_v_ofi)),b_v_cci);
		b_poke((((55296.0))+(b_v_ofi)),(14));
		b_v_ofi=((b_v_ofi)+((1)));
		goto b_L3904;
		/* line 3906 */
b_L3906: ;
		/* line 3907 */
b_L3907: ;
		/* line 3908 */
b_L3908: ;
		/* line 3909 */
b_L3909: ;
		/* line 3910 */
b_L3910: ;
		/* line 3911 */
b_L3911: ;
		/* line 3912 */
b_L3912: ;
		/* line 3913 */
b_L3913: ;
		/* line 3914 */
b_L3914: ;
		/* line 3915 */
b_L3915: ;
		/* line 3916 */
b_L3916: ;
		/* line 4000 */
b_L4000: ;
		b_poke((56576.0),(B_INT(B_INT(b_peek((unsigned int)((56576.0))))) | B_INT((3))));
		b_poke((648),(4));
		/* line 4001 */
b_L4001: ;
		b_poke((53272.0),(B_INT((B_INT(B_INT(b_peek((unsigned int)((53272.0))))) & B_INT((241)))) | B_INT((4))));
		/* line 4002 */
b_L4002: ;
		b_poke((53280.0),(14));
		b_poke((53281.0),(6));
		/* line 4003 */
b_L4003: ;
		b_putc(147);
		b_nl();
		/* line 4004 */
b_L4004: ;
		goto b_end;
		/* line 4100 */
b_L4100: ;
		/* line 4101 */
b_L4101: ;
		b_v_uci=(((1))-(b_v_uci));
		/* line 4102 */
b_L4102: ;
		b_poke((56333.0),(127));
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) & B_INT((251))));
		/* line 4103 */
b_L4103: ;
		if(-((b_v_uci) == ((1)))){
			b_v_lpi=(0);
			if(b_v_lpi > 2047) goto b_f12_e;
b_f12_t: ;
			b_poke((((20480))+(b_v_lpi)),B_INT(b_peek((unsigned int)((((53248.0))+(b_v_lpi))))));
			b_v_lpi += 1;
			if(b_v_lpi <= 2047) goto b_f12_t;
b_f12_e: ;
			goto b_L4105;
		}
		/* line 4104 */
b_L4104: ;
		b_v_lpi=(0);
		if(b_v_lpi > 2047) goto b_f13_e;
b_f13_t: ;
		b_poke((((20480))+(b_v_lpi)),B_INT(b_peek((unsigned int)((((55296.0))+(b_v_lpi))))));
		b_v_lpi += 1;
		if(b_v_lpi <= 2047) goto b_f13_t;
b_f13_e: ;
		/* line 4105 */
b_L4105: ;
		b_poke((1),(B_INT(B_INT(b_peek((unsigned int)((1))))) | B_INT((4))));
		b_poke((56333.0),(129));
		b_v_rfi=(1);
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
