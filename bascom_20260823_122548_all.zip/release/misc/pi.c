/* OPTIMIZE_C -- pi.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_ni;
static int b_v_exi;
static breal_t b_v_lf;
static breal_t b_a_af[28];
static int b_a_oi[12];
static int b_v_ii;
static int b_v_n9i;
static breal_t b_v_p0f;
static bint_t b_v_oii;
static int b_v_ji;
static breal_t b_v_qf;
static breal_t b_v_xf;
static int b_v_di;
static bint_t b_v_ki;
static bint_t b_t_0;
static int b_fl_0;
static int b_fl_1;
static bint_t b_fl_3;
static bint_t b_fl_4;
static int b_fl_5;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		b_v_ni=(6);
		/* line 40 */
b_L40: ;
		b_v_exi=(2);
		/* line 50 */
b_L50: ;
		b_v_lf=((b_int(((breal_t)((((10))*(((b_v_ni)+(b_v_exi)))))/(breal_t)((3)))))+((1)));
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		b_v_ii=(1);
		b_fl_0=b_v_lf;
		if(b_v_ii > b_fl_0) goto b_f0_e;
b_f0_t: ;
		b_a_af[B_INT(b_v_ii)]=(2);
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 80 */
b_L80: ;
		b_v_n9i=(0);
		b_v_p0f=(0);
		b_v_oii=(0);
		/* line 90 */
b_L90: ;
		b_v_ji=(1);
		b_fl_1=((((b_v_ni)+(b_v_exi)))+((1)));
		if(b_v_ji > b_fl_1) goto b_f1_e;
b_f1_t: ;
		/* line 100 */
b_L100: ;
		b_v_qf=(0);
		/* line 110 */
b_L110: ;
		b_v_ii=b_v_lf;
		if(b_v_ii < 1) goto b_f2_e;
b_f2_t: ;
		/* line 120 */
b_L120: ;
		b_v_xf=(((((10))*(b_a_af[B_INT(b_v_ii)])))+(((b_v_qf)*(b_v_ii))));
		/* line 130 */
b_L130: ;
		b_v_di=(((((2))*(b_v_ii)))-((1)));
		/* line 140 */
b_L140: ;
		b_a_af[B_INT(b_v_ii)]=((b_v_xf)-(((b_v_di)*(b_int((b_v_xf/(breal_t)(b_v_di)))))));
		/* line 150 */
b_L150: ;
		b_v_qf=b_int((b_v_xf/(breal_t)(b_v_di)));
		/* line 160 */
b_L160: ;
		b_v_ii += -1;
		if(b_v_ii >= 1) goto b_f2_t;
b_f2_e: ;
		/* line 170 */
b_L170: ;
		b_a_af[B_INT((1))]=((b_v_qf)-((((10))*(b_int((b_v_qf/(breal_t)((10))))))));
		/* line 180 */
b_L180: ;
		b_v_qf=b_int((b_v_qf/(breal_t)((10))));
		/* line 190 */
b_L190: ;
		if(-((b_v_qf) == ((9)))){
			b_v_n9i=((b_v_n9i)+((1)));
			goto b_L250;
		}
		/* line 200 */
b_L200: ;
		if(-((b_v_qf) == ((10)))){ goto b_L240; }
		/* line 210 */
b_L210: ;
		/* line 220 */
b_L220: ;
		if(-((b_v_ji) > ((1)))){
			b_v_oii=((b_v_oii)+((1)));
			b_a_oi[B_INT(b_v_oii)]=b_v_p0f;
		}
		/* line 230 */
b_L230: ;
		if(-((b_v_n9i) > ((0)))){
			b_v_ki=(1);
			b_fl_3=b_v_n9i;
			if(b_v_ki > b_fl_3) goto b_f3_e;
b_f3_t: ;
			b_v_oii=((b_v_oii)+((1)));
			b_a_oi[B_INT(b_v_oii)]=(9);
			b_v_ki += 1;
			if(b_v_ki <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		}
		/* line 235 */
b_L235: ;
		b_v_p0f=b_v_qf;
		b_v_n9i=(0);
		goto b_L250;
		/* line 240 */
b_L240: ;
		/* line 245 */
b_L245: ;
		b_v_oii=((b_v_oii)+((1)));
		b_a_oi[B_INT(b_v_oii)]=((b_v_p0f)+((1)));
		/* line 247 */
b_L247: ;
		if(-((b_v_n9i) > ((0)))){
			b_v_ki=(1);
			b_fl_4=b_v_n9i;
			if(b_v_ki > b_fl_4) goto b_f4_e;
b_f4_t: ;
			b_v_oii=((b_v_oii)+((1)));
			b_a_oi[B_INT(b_v_oii)]=(0);
			b_v_ki += 1;
			if(b_v_ki <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		}
		/* line 249 */
b_L249: ;
		b_v_p0f=(0);
		b_v_n9i=(0);
		/* line 250 */
b_L250: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_1)) goto b_f1_t;
b_f1_e: ;
		/* line 260 */
b_L260: ;
		b_v_oii=((b_v_oii)+((1)));
		b_a_oi[B_INT(b_v_oii)]=b_v_p0f;
		/* line 300 */
b_L300: ;
		{ bstr_t _t=b_lit("3.",2); b_str(_t.p,_t.len); }
		/* line 310 */
b_L310: ;
		b_v_ji=(2);
		b_fl_5=((b_v_ni)+((1)));
		if(b_v_ji > b_fl_5) goto b_f5_e;
b_f5_t: ;
		b_putc((((48))+(b_a_oi[B_INT(b_v_ji)])));
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_5)) goto b_f5_t;
b_f5_e: ;
b_return: ;
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
