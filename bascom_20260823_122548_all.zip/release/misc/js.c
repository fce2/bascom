/* OPTIMIZE_C -- js.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static unsigned int b_v_bai;
static bstr_t b_a_vns[64];
static breal_t b_a_vvf[64];
static bstr_t b_a_vss[64];
static bint_t b_a_vti[64];
static bint_t b_v_nvi;
static breal_t b_v_chf;
static bstr_t b_v_ids;
static bint_t b_v_bdi;
static bstr_t b_v_tgs;
static breal_t b_v_pcf;
static breal_t b_v_tvf;
static breal_t b_v_evf;
static bint_t b_v_tsi;
static bint_t b_v_eti;
static bstr_t b_v_tss;
static bstr_t b_v_ess;
static breal_t b_v_c0f;
static breal_t b_v_nmf;
static breal_t b_v_dff;
static breal_t b_v_dvf;
static breal_t b_v_lef;
static bint_t b_v_kai;
static bstr_t b_v_kbs;
static breal_t b_v_rf;
static breal_t b_v_laf;
static bint_t b_v_lti;
static bstr_t b_v_lss;
static breal_t b_v_lmf;
static bint_t b_v_kci;
static bstr_t b_v_kds;
static int b_v_fi;
static bint_t b_v_ii;
static int b_v_fii;
static bstr_t b_v_bns;
static breal_t b_v_a1f;
static breal_t b_v_a2f;
static bint_t b_v_rpi;
static bstr_t b_v_jss;
static bstr_t b_v_gcs;
static bint_t b_t_0;
static bint_t b_fl_0;
static bint_t b_fl_1;
static bint_t b_fl_2;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		{ bstr_t _t=b_lit("JS",2); b_str(_t.p,_t.len); }
		b_nl();
		/* line 20 */
b_L20: ;
		b_v_bai=(49152.0);
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		b_v_nvi=(0);
		/* line 50 */
b_L50: ;
		goto b_L3500;
		/* line 1000 */
b_L1000: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1700;
b_ret0: ;
		/* line 1005 */
b_L1005: ;
		if(-((b_v_chf) != ((123)))){
			goto b_L1030;
		}
		/* line 1010 */
b_L1010: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L1600;
b_ret1: ;
		/* line 1015 */
b_L1015: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L3300;
b_ret2: ;
		/* line 1020 */
b_L1020: ;
		if(-((b_v_chf) == ((125)))){
			b_gosubStack[b_gosubSP++]=3; goto b_L1600;
b_ret3: ;
		}
		/* line 1025 */
b_L1025: ;
		goto b_return;
		/* line 1030 */
b_L1030: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L1900;
b_ret4: ;
		/* line 1035 */
b_L1035: ;
		if(-(b_strcmp(b_v_ids,b_lit("LET",3)) == 0)){
			b_gosubStack[b_gosubSP++]=5; goto b_L1700;
b_ret5: ;
			b_gosubStack[b_gosubSP++]=6; goto b_L1900;
b_ret6: ;
			b_gosubStack[b_gosubSP++]=7; goto b_L1200;
b_ret7: ;
			goto b_return;
		}
		/* line 1040 */
b_L1040: ;
		if(-(b_strcmp(b_v_ids,b_lit("PRINT",5)) == 0)){
			b_gosubStack[b_gosubSP++]=8; goto b_L1300;
b_ret8: ;
			goto b_return;
		}
		/* line 1045 */
b_L1045: ;
		if(-(b_strcmp(b_v_ids,b_lit("IF",2)) == 0)){
			b_gosubStack[b_gosubSP++]=9; goto b_L1400;
b_ret9: ;
			goto b_return;
		}
		/* line 1050 */
b_L1050: ;
		if(-(b_strcmp(b_v_ids,b_lit("WHILE",5)) == 0)){
			b_gosubStack[b_gosubSP++]=10; goto b_L1500;
b_ret10: ;
			goto b_return;
		}
		/* line 1055 */
b_L1055: ;
		if(-(b_strcmp(b_v_ids,b_lit("",0)) == 0)){
			b_gosubStack[b_gosubSP++]=11; goto b_L3400;
b_ret11: ;
		}
		/* line 1060 */
b_L1060: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L1200;
b_ret12: ;
		/* line 1065 */
b_L1065: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		b_gosubStack[b_gosubSP++]=13; goto b_L1700;
b_ret13: ;
		/* line 1105 */
b_L1105: ;
		if(-((b_v_chf) == ((123)))){
			b_gosubStack[b_gosubSP++]=14; goto b_L1600;
b_ret14: ;
			b_v_bdi=(1);
			goto b_L1560;
		}
		/* line 1110 */
b_L1110: ;
		b_gosubStack[b_gosubSP++]=15; goto b_L1600;
b_ret15: ;
		/* line 1115 */
b_L1115: ;
		if((B_INT((B_INT((B_INT(-((b_v_chf) == ((59)))) | B_INT(-((b_v_chf) == ((10)))))) | B_INT(-((b_v_chf) == ((13)))))) | B_INT(-((b_v_chf) == ((0)))))){
			goto b_return;
		}
		/* line 1120 */
b_L1120: ;
		goto b_L1110;
		/* line 1200 */
b_L1200: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L1700;
b_ret16: ;
		/* line 1205 */
b_L1205: ;
		b_v_tgs=b_keep(b_v_ids);
		/* line 1210 */
b_L1210: ;
		if(-((b_v_chf) != ((61)))){
			b_gosubStack[b_gosubSP++]=17; goto b_L3400;
b_ret17: ;
		}
		/* line 1215 */
b_L1215: ;
		if(-((B_INT(b_peek((unsigned int)(((((b_v_bai)+(b_v_pcf)))+((1))))))) == ((61)))){
			b_gosubStack[b_gosubSP++]=18; goto b_L3400;
b_ret18: ;
		}
		/* line 1220 */
b_L1220: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L1600;
b_ret19: ;
		/* line 1225 */
b_L1225: ;
		b_gosubStack[b_gosubSP++]=20; goto b_L2000;
b_ret20: ;
		/* line 1230 */
b_L1230: ;
		b_v_tvf=b_v_evf;
		/* line 1235 */
b_L1235: ;
		b_v_tsi=b_v_eti;
		/* line 1240 */
b_L1240: ;
		b_v_tss=b_keep(b_v_ess);
		/* line 1245 */
b_L1245: ;
		b_v_ids=b_keep(b_v_tgs);
		/* line 1250 */
b_L1250: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L2900;
b_ret21: ;
		/* line 1255 */
b_L1255: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		b_gosubStack[b_gosubSP++]=22; goto b_L1700;
b_ret22: ;
		/* line 1305 */
b_L1305: ;
		if(-((b_v_chf) != ((40)))){
			goto b_L1335;
		}
		/* line 1310 */
b_L1310: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L1600;
b_ret23: ;
		/* line 1315 */
b_L1315: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L2000;
b_ret24: ;
		/* line 1320 */
b_L1320: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L1700;
b_ret25: ;
		/* line 1325 */
b_L1325: ;
		if(-((b_v_chf) == ((41)))){
			b_gosubStack[b_gosubSP++]=26; goto b_L1600;
b_ret26: ;
			goto b_L1340;
		}
		/* line 1330 */
b_L1330: ;
		b_gosubStack[b_gosubSP++]=27; goto b_L3400;
b_ret27: ;
		/* line 1335 */
b_L1335: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L2000;
b_ret28: ;
		/* line 1340 */
b_L1340: ;
		if(-((b_v_eti) == ((1)))){
			{ bstr_t _t=b_v_ess; b_str(_t.p,_t.len); }
			b_nl();
			goto b_return;
		}
		/* line 1345 */
b_L1345: ;
		b_real(b_v_evf);
		b_nl();
		/* line 1350 */
b_L1350: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L1700;
b_ret29: ;
		/* line 1405 */
b_L1405: ;
		if(-((b_v_chf) != ((40)))){
			b_gosubStack[b_gosubSP++]=30; goto b_L3400;
b_ret30: ;
		}
		/* line 1410 */
b_L1410: ;
		b_gosubStack[b_gosubSP++]=31; goto b_L1600;
b_ret31: ;
		/* line 1415 */
b_L1415: ;
		b_gosubStack[b_gosubSP++]=32; goto b_L2000;
b_ret32: ;
		/* line 1420 */
b_L1420: ;
		b_gosubStack[b_gosubSP++]=33; goto b_L1700;
b_ret33: ;
		/* line 1425 */
b_L1425: ;
		if(-((b_v_chf) != ((41)))){
			b_gosubStack[b_gosubSP++]=34; goto b_L3400;
b_ret34: ;
		}
		/* line 1430 */
b_L1430: ;
		b_gosubStack[b_gosubSP++]=35; goto b_L1600;
b_ret35: ;
		/* line 1435 */
b_L1435: ;
		if(-((b_v_evf) == ((0)))){
			b_gosubStack[b_gosubSP++]=36; goto b_L1100;
b_ret36: ;
			goto b_return;
		}
		/* line 1440 */
b_L1440: ;
		b_gosubStack[b_gosubSP++]=37; goto b_L1000;
b_ret37: ;
		/* line 1445 */
b_L1445: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		b_gosubStack[b_gosubSP++]=38; goto b_L1700;
b_ret38: ;
		/* line 1505 */
b_L1505: ;
		if(-((b_v_chf) != ((40)))){
			b_gosubStack[b_gosubSP++]=39; goto b_L3400;
b_ret39: ;
		}
		/* line 1510 */
b_L1510: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L1600;
b_ret40: ;
		/* line 1515 */
b_L1515: ;
		b_v_c0f=b_v_pcf;
		/* line 1520 */
b_L1520: ;
		b_gosubStack[b_gosubSP++]=41; goto b_L2000;
b_ret41: ;
		/* line 1525 */
b_L1525: ;
		b_gosubStack[b_gosubSP++]=42; goto b_L1700;
b_ret42: ;
		/* line 1530 */
b_L1530: ;
		if(-((b_v_chf) != ((41)))){
			b_gosubStack[b_gosubSP++]=43; goto b_L3400;
b_ret43: ;
		}
		/* line 1535 */
b_L1535: ;
		b_gosubStack[b_gosubSP++]=44; goto b_L1600;
b_ret44: ;
		/* line 1540 */
b_L1540: ;
		if(-((b_v_evf) == ((0)))){
			b_gosubStack[b_gosubSP++]=45; goto b_L1100;
b_ret45: ;
			goto b_return;
		}
		/* line 1545 */
b_L1545: ;
		b_gosubStack[b_gosubSP++]=46; goto b_L1000;
b_ret46: ;
		/* line 1550 */
b_L1550: ;
		b_v_pcf=b_v_c0f;
		/* line 1555 */
b_L1555: ;
		goto b_L1520;
		/* line 1560 */
b_L1560: ;
		b_gosubStack[b_gosubSP++]=47; goto b_L1600;
b_ret47: ;
		/* line 1565 */
b_L1565: ;
		if(-((b_v_chf) == ((0)))){
			goto b_return;
		}
		/* line 1570 */
b_L1570: ;
		if(-((b_v_chf) == ((123)))){
			b_v_bdi=((b_v_bdi)+((1)));
			goto b_L1560;
		}
		/* line 1575 */
b_L1575: ;
		if(-((b_v_chf) == ((125)))){
			b_v_bdi=((b_v_bdi)-((1)));
			if(-((b_v_bdi) == ((0)))){
				goto b_return;
			}
		}
		/* line 1580 */
b_L1580: ;
		goto b_L1560;
		/* line 1600 */
b_L1600: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1605 */
b_L1605: ;
		b_v_pcf=((b_v_pcf)+((1)));
		/* line 1610 */
b_L1610: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1705 */
b_L1705: ;
		if((B_INT((B_INT((B_INT(-((b_v_chf) == ((32)))) | B_INT(-((b_v_chf) == ((9)))))) | B_INT(-((b_v_chf) == ((10)))))) | B_INT(-((b_v_chf) == ((13)))))){
			b_v_pcf=((b_v_pcf)+((1)));
			goto b_L1700;
		}
		/* line 1710 */
b_L1710: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		b_v_nmf=(0);
		/* line 1805 */
b_L1805: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1810 */
b_L1810: ;
		if((B_INT(-((b_v_chf) < ((48)))) | B_INT(-((b_v_chf) > ((57)))))){
			goto b_L1835;
		}
		/* line 1815 */
b_L1815: ;
		b_v_nmf=((((b_v_nmf)*((10))))+(((b_v_chf)-((48)))));
		/* line 1820 */
b_L1820: ;
		b_v_pcf=((b_v_pcf)+((1)));
		/* line 1825 */
b_L1825: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1830 */
b_L1830: ;
		goto b_L1810;
		/* line 1835 */
b_L1835: ;
		if(-((b_v_chf) != ((46)))){
			goto b_return;
		}
		/* line 1840 */
b_L1840: ;
		b_v_pcf=((b_v_pcf)+((1)));
		/* line 1845 */
b_L1845: ;
		b_v_dff=(0);
		/* line 1850 */
b_L1850: ;
		b_v_dvf=(1);
		/* line 1855 */
b_L1855: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1860 */
b_L1860: ;
		if((B_INT(-((b_v_chf) < ((48)))) | B_INT(-((b_v_chf) > ((57)))))){
			b_v_nmf=((b_v_nmf)+((b_v_dff/b_v_dvf)));
			goto b_return;
		}
		/* line 1865 */
b_L1865: ;
		b_v_dff=((((b_v_dff)*((10))))+(((b_v_chf)-((48)))));
		/* line 1870 */
b_L1870: ;
		b_v_dvf=((b_v_dvf)*((10)));
		/* line 1875 */
b_L1875: ;
		b_v_pcf=((b_v_pcf)+((1)));
		/* line 1880 */
b_L1880: ;
		goto b_L1855;
		/* line 1900 */
b_L1900: ;
		b_v_ids=b_keep(b_lit("",0));
		/* line 1905 */
b_L1905: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1910 */
b_L1910: ;
		if((B_INT((B_INT((B_INT(-((b_v_chf) >= ((65)))) & B_INT(-((b_v_chf) <= ((90)))))) | B_INT((B_INT(-((b_v_chf) >= ((97)))) & B_INT(-((b_v_chf) <= ((122)))))))) | B_INT(-((b_v_chf) == ((95)))))){
			goto b_L1920;
		}
		/* line 1915 */
b_L1915: ;
		goto b_return;
		/* line 1920 */
b_L1920: ;
		if(-((b_v_chf) >= ((97)))){
			b_v_chf=((b_v_chf)-((32)));
		}
		/* line 1925 */
b_L1925: ;
		b_v_ids=b_keep(b_concat(b_v_ids,b_chr((bint_t)(b_v_chf))));
		/* line 1930 */
b_L1930: ;
		b_v_pcf=((b_v_pcf)+((1)));
		/* line 1935 */
b_L1935: ;
		b_v_chf=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_pcf)))));
		/* line 1940 */
b_L1940: ;
		if((B_INT((B_INT((B_INT((B_INT(-((b_v_chf) >= ((65)))) & B_INT(-((b_v_chf) <= ((90)))))) | B_INT((B_INT(-((b_v_chf) >= ((97)))) & B_INT(-((b_v_chf) <= ((122)))))))) | B_INT((B_INT(-((b_v_chf) >= ((48)))) & B_INT(-((b_v_chf) <= ((57)))))))) | B_INT(-((b_v_chf) == ((95)))))){
			goto b_L1920;
		}
		/* line 1945 */
b_L1945: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		b_gosubStack[b_gosubSP++]=48; goto b_L2400;
b_ret48: ;
		/* line 2005 */
b_L2005: ;
		b_v_lef=b_v_evf;
		/* line 2010 */
b_L2010: ;
		b_v_kai=b_v_eti;
		/* line 2015 */
b_L2015: ;
		b_v_kbs=b_keep(b_v_ess);
		/* line 2020 */
b_L2020: ;
		b_gosubStack[b_gosubSP++]=49; goto b_L1700;
b_ret49: ;
		/* line 2025 */
b_L2025: ;
		if(-((b_v_chf) == ((33)))){
			if(-((B_INT(b_peek((unsigned int)(((((b_v_bai)+(b_v_pcf)))+((1))))))) == ((61)))){
				goto b_L2075;
			}
		}
		/* line 2030 */
b_L2030: ;
		if(-((b_v_chf) == ((61)))){
			if(-((B_INT(b_peek((unsigned int)(((((b_v_bai)+(b_v_pcf)))+((1))))))) == ((61)))){
				goto b_L2115;
			}
		}
		/* line 2035 */
b_L2035: ;
		if(-((b_v_chf) == ((60)))){
			if(-((B_INT(b_peek((unsigned int)(((((b_v_bai)+(b_v_pcf)))+((1))))))) == ((61)))){
				goto b_L2155;
			}
		}
		/* line 2040 */
b_L2040: ;
		if(-((b_v_chf) == ((62)))){
			if(-((B_INT(b_peek((unsigned int)(((((b_v_bai)+(b_v_pcf)))+((1))))))) == ((61)))){
				goto b_L2195;
			}
		}
		/* line 2045 */
b_L2045: ;
		if(-((b_v_chf) == ((60)))){
			goto b_L2235;
		}
		/* line 2050 */
b_L2050: ;
		if(-((b_v_chf) == ((62)))){
			goto b_L2270;
		}
		/* line 2055 */
b_L2055: ;
		b_v_eti=b_v_kai;
		/* line 2060 */
b_L2060: ;
		b_v_ess=b_keep(b_v_kbs);
		/* line 2065 */
b_L2065: ;
		b_v_evf=b_v_lef;
		/* line 2070 */
b_L2070: ;
		goto b_return;
		/* line 2075 */
b_L2075: ;
		b_gosubStack[b_gosubSP++]=50; goto b_L1600;
b_ret50: ;
		/* line 2080 */
b_L2080: ;
		b_gosubStack[b_gosubSP++]=51; goto b_L1600;
b_ret51: ;
		/* line 2085 */
b_L2085: ;
		b_gosubStack[b_gosubSP++]=52; goto b_L2400;
b_ret52: ;
		/* line 2090 */
b_L2090: ;
		b_v_rf=b_v_evf;
		/* line 2095 */
b_L2095: ;
		b_v_evf=(0);
		/* line 2100 */
b_L2100: ;
		if(-((b_v_lef) != (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2105 */
b_L2105: ;
		b_v_eti=(0);
		/* line 2110 */
b_L2110: ;
		goto b_return;
		/* line 2115 */
b_L2115: ;
		b_gosubStack[b_gosubSP++]=53; goto b_L1600;
b_ret53: ;
		/* line 2120 */
b_L2120: ;
		b_gosubStack[b_gosubSP++]=54; goto b_L1600;
b_ret54: ;
		/* line 2125 */
b_L2125: ;
		b_gosubStack[b_gosubSP++]=55; goto b_L2400;
b_ret55: ;
		/* line 2130 */
b_L2130: ;
		b_v_rf=b_v_evf;
		/* line 2135 */
b_L2135: ;
		b_v_evf=(0);
		/* line 2140 */
b_L2140: ;
		if(-((b_v_lef) == (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2145 */
b_L2145: ;
		b_v_eti=(0);
		/* line 2150 */
b_L2150: ;
		goto b_return;
		/* line 2155 */
b_L2155: ;
		b_gosubStack[b_gosubSP++]=56; goto b_L1600;
b_ret56: ;
		/* line 2160 */
b_L2160: ;
		b_gosubStack[b_gosubSP++]=57; goto b_L1600;
b_ret57: ;
		/* line 2165 */
b_L2165: ;
		b_gosubStack[b_gosubSP++]=58; goto b_L2400;
b_ret58: ;
		/* line 2170 */
b_L2170: ;
		b_v_rf=b_v_evf;
		/* line 2175 */
b_L2175: ;
		b_v_evf=(0);
		/* line 2180 */
b_L2180: ;
		if(-((b_v_lef) <= (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2185 */
b_L2185: ;
		b_v_eti=(0);
		/* line 2190 */
b_L2190: ;
		goto b_return;
		/* line 2195 */
b_L2195: ;
		b_gosubStack[b_gosubSP++]=59; goto b_L1600;
b_ret59: ;
		/* line 2200 */
b_L2200: ;
		b_gosubStack[b_gosubSP++]=60; goto b_L1600;
b_ret60: ;
		/* line 2205 */
b_L2205: ;
		b_gosubStack[b_gosubSP++]=61; goto b_L2400;
b_ret61: ;
		/* line 2210 */
b_L2210: ;
		b_v_rf=b_v_evf;
		/* line 2215 */
b_L2215: ;
		b_v_evf=(0);
		/* line 2220 */
b_L2220: ;
		if(-((b_v_lef) >= (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2225 */
b_L2225: ;
		b_v_eti=(0);
		/* line 2230 */
b_L2230: ;
		goto b_return;
		/* line 2235 */
b_L2235: ;
		b_gosubStack[b_gosubSP++]=62; goto b_L1600;
b_ret62: ;
		/* line 2240 */
b_L2240: ;
		b_gosubStack[b_gosubSP++]=63; goto b_L2400;
b_ret63: ;
		/* line 2245 */
b_L2245: ;
		b_v_rf=b_v_evf;
		/* line 2250 */
b_L2250: ;
		b_v_evf=(0);
		/* line 2255 */
b_L2255: ;
		if(-((b_v_lef) < (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2260 */
b_L2260: ;
		b_v_eti=(0);
		/* line 2265 */
b_L2265: ;
		goto b_return;
		/* line 2270 */
b_L2270: ;
		b_gosubStack[b_gosubSP++]=64; goto b_L1600;
b_ret64: ;
		/* line 2275 */
b_L2275: ;
		b_gosubStack[b_gosubSP++]=65; goto b_L2400;
b_ret65: ;
		/* line 2280 */
b_L2280: ;
		b_v_rf=b_v_evf;
		/* line 2285 */
b_L2285: ;
		b_v_evf=(0);
		/* line 2290 */
b_L2290: ;
		if(-((b_v_lef) > (b_v_rf))){
			b_v_evf=(1);
		}
		/* line 2295 */
b_L2295: ;
		b_v_eti=(0);
		/* line 2300 */
b_L2300: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		b_gosubStack[b_gosubSP++]=66; goto b_L2500;
b_ret66: ;
		/* line 2405 */
b_L2405: ;
		b_v_laf=b_v_evf;
		/* line 2410 */
b_L2410: ;
		b_v_lti=b_v_eti;
		/* line 2415 */
b_L2415: ;
		b_v_lss=b_keep(b_v_ess);
		/* line 2420 */
b_L2420: ;
		b_gosubStack[b_gosubSP++]=67; goto b_L1700;
b_ret67: ;
		/* line 2425 */
b_L2425: ;
		if(-((b_v_chf) == ((43)))){
			b_gosubStack[b_gosubSP++]=68; goto b_L1600;
b_ret68: ;
			b_gosubStack[b_gosubSP++]=69; goto b_L2500;
b_ret69: ;
			goto b_L2440;
		}
		/* line 2430 */
b_L2430: ;
		if(-((b_v_chf) == ((45)))){
			b_gosubStack[b_gosubSP++]=70; goto b_L1600;
b_ret70: ;
			b_gosubStack[b_gosubSP++]=71; goto b_L2500;
b_ret71: ;
			goto b_L2455;
		}
		/* line 2435 */
b_L2435: ;
		goto b_L2470;
		/* line 2440 */
b_L2440: ;
		if((B_INT(-((b_v_lti) == ((1)))) & B_INT(-((b_v_eti) == ((1)))))){
			b_v_lss=b_keep(b_concat(b_v_lss,b_v_ess));
			goto b_L2420;
		}
		/* line 2445 */
b_L2445: ;
		if((B_INT(-((b_v_lti) == ((0)))) & B_INT(-((b_v_eti) == ((0)))))){
			b_v_laf=((b_v_laf)+(b_v_evf));
			goto b_L2420;
		}
		/* line 2450 */
b_L2450: ;
		b_gosubStack[b_gosubSP++]=72; goto b_L3400;
b_ret72: ;
		/* line 2455 */
b_L2455: ;
		if((B_INT(-((b_v_lti) == ((1)))) | B_INT(-((b_v_eti) == ((1)))))){
			b_gosubStack[b_gosubSP++]=73; goto b_L3400;
b_ret73: ;
		}
		/* line 2460 */
b_L2460: ;
		b_v_laf=((b_v_laf)-(b_v_evf));
		/* line 2465 */
b_L2465: ;
		goto b_L2420;
		/* line 2470 */
b_L2470: ;
		if(-((b_v_lti) == ((1)))){
			b_v_eti=(1);
			b_v_ess=b_keep(b_v_lss);
			goto b_return;
		}
		/* line 2475 */
b_L2475: ;
		b_v_eti=(0);
		/* line 2480 */
b_L2480: ;
		b_v_evf=b_v_laf;
		/* line 2485 */
b_L2485: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		b_gosubStack[b_gosubSP++]=74; goto b_L2700;
b_ret74: ;
		/* line 2505 */
b_L2505: ;
		b_v_lmf=b_v_evf;
		/* line 2510 */
b_L2510: ;
		b_v_kci=b_v_eti;
		/* line 2515 */
b_L2515: ;
		b_v_kds=b_keep(b_v_ess);
		/* line 2520 */
b_L2520: ;
		b_gosubStack[b_gosubSP++]=75; goto b_L1700;
b_ret75: ;
		/* line 2525 */
b_L2525: ;
		if(-((b_v_chf) == ((42)))){
			goto b_L2555;
		}
		/* line 2530 */
b_L2530: ;
		if(-((b_v_chf) == ((47)))){
			goto b_L2580;
		}
		/* line 2535 */
b_L2535: ;
		b_v_eti=b_v_kci;
		/* line 2540 */
b_L2540: ;
		b_v_ess=b_keep(b_v_kds);
		/* line 2545 */
b_L2545: ;
		b_v_evf=b_v_lmf;
		/* line 2550 */
b_L2550: ;
		goto b_return;
		/* line 2555 */
b_L2555: ;
		b_gosubStack[b_gosubSP++]=76; goto b_L1600;
b_ret76: ;
		/* line 2560 */
b_L2560: ;
		b_gosubStack[b_gosubSP++]=77; goto b_L2700;
b_ret77: ;
		/* line 2565 */
b_L2565: ;
		if((B_INT(-((b_v_kci) == ((1)))) | B_INT(-((b_v_eti) == ((1)))))){
			b_gosubStack[b_gosubSP++]=78; goto b_L3400;
b_ret78: ;
		}
		/* line 2570 */
b_L2570: ;
		b_v_lmf=((b_v_lmf)*(b_v_evf));
		/* line 2575 */
b_L2575: ;
		goto b_L2520;
		/* line 2580 */
b_L2580: ;
		b_gosubStack[b_gosubSP++]=79; goto b_L1600;
b_ret79: ;
		/* line 2585 */
b_L2585: ;
		b_gosubStack[b_gosubSP++]=80; goto b_L2700;
b_ret80: ;
		/* line 2590 */
b_L2590: ;
		if((B_INT(-((b_v_kci) == ((1)))) | B_INT(-((b_v_eti) == ((1)))))){
			b_gosubStack[b_gosubSP++]=81; goto b_L3400;
b_ret81: ;
		}
		/* line 2595 */
b_L2595: ;
		if(-((b_v_evf) == ((0)))){
			b_v_evf=(1);
		}
		/* line 2600 */
b_L2600: ;
		b_v_lmf=(b_v_lmf/b_v_evf);
		/* line 2605 */
b_L2605: ;
		goto b_L2520;
		/* line 2700 */
b_L2700: ;
		b_gosubStack[b_gosubSP++]=82; goto b_L1700;
b_ret82: ;
		/* line 2705 */
b_L2705: ;
		if(-((b_v_chf) != ((45)))){
			goto b_L2740;
		}
		/* line 2710 */
b_L2710: ;
		b_gosubStack[b_gosubSP++]=83; goto b_L1600;
b_ret83: ;
		/* line 2715 */
b_L2715: ;
		b_gosubStack[b_gosubSP++]=84; goto b_L2700;
b_ret84: ;
		/* line 2720 */
b_L2720: ;
		if(-((b_v_eti) == ((1)))){
			b_gosubStack[b_gosubSP++]=85; goto b_L3400;
b_ret85: ;
		}
		/* line 2725 */
b_L2725: ;
		b_v_evf=(-(b_v_evf));
		/* line 2730 */
b_L2730: ;
		b_v_eti=(0);
		/* line 2735 */
b_L2735: ;
		goto b_return;
		/* line 2740 */
b_L2740: ;
		if(-((b_v_chf) != ((33)))){
			goto b_L2785;
		}
		/* line 2745 */
b_L2745: ;
		b_gosubStack[b_gosubSP++]=86; goto b_L1600;
b_ret86: ;
		/* line 2750 */
b_L2750: ;
		b_gosubStack[b_gosubSP++]=87; goto b_L2700;
b_ret87: ;
		/* line 2755 */
b_L2755: ;
		if(-((b_v_eti) == ((1)))){
			b_gosubStack[b_gosubSP++]=88; goto b_L3400;
b_ret88: ;
		}
		/* line 2760 */
b_L2760: ;
		b_v_rf=b_v_evf;
		/* line 2765 */
b_L2765: ;
		b_v_evf=(0);
		/* line 2770 */
b_L2770: ;
		b_v_eti=(0);
		/* line 2775 */
b_L2775: ;
		if(-((b_v_rf) == ((0)))){
			b_v_evf=(1);
		}
		/* line 2780 */
b_L2780: ;
		goto b_return;
		/* line 2785 */
b_L2785: ;
		b_gosubStack[b_gosubSP++]=89; goto b_L2800;
b_ret89: ;
		/* line 2790 */
b_L2790: ;
		goto b_return;
		/* line 2800 */
b_L2800: ;
		b_gosubStack[b_gosubSP++]=90; goto b_L1700;
b_ret90: ;
		/* line 2805 */
b_L2805: ;
		if(-((b_v_chf) != ((40)))){
			goto b_L2835;
		}
		/* line 2810 */
b_L2810: ;
		b_gosubStack[b_gosubSP++]=91; goto b_L1600;
b_ret91: ;
		/* line 2815 */
b_L2815: ;
		b_gosubStack[b_gosubSP++]=92; goto b_L2000;
b_ret92: ;
		/* line 2820 */
b_L2820: ;
		b_gosubStack[b_gosubSP++]=93; goto b_L1700;
b_ret93: ;
		/* line 2825 */
b_L2825: ;
		if(-((b_v_chf) == ((41)))){
			b_gosubStack[b_gosubSP++]=94; goto b_L1600;
b_ret94: ;
			goto b_return;
		}
		/* line 2830 */
b_L2830: ;
		b_gosubStack[b_gosubSP++]=95; goto b_L3400;
b_ret95: ;
		/* line 2835 */
b_L2835: ;
		if(-((b_v_chf) == ((34)))){
			b_gosubStack[b_gosubSP++]=96; goto b_L3800;
b_ret96: ;
			goto b_return;
		}
		/* line 2840 */
b_L2840: ;
		if((B_INT(-((b_v_chf) >= ((48)))) & B_INT(-((b_v_chf) <= ((57)))))){
			b_gosubStack[b_gosubSP++]=97; goto b_L1800;
b_ret97: ;
			b_v_evf=b_v_nmf;
			b_v_eti=(0);
			goto b_return;
		}
		/* line 2845 */
b_L2845: ;
		b_gosubStack[b_gosubSP++]=98; goto b_L1900;
b_ret98: ;
		/* line 2850 */
b_L2850: ;
		if(-(b_strcmp(b_v_ids,b_lit("",0)) == 0)){
			b_gosubStack[b_gosubSP++]=99; goto b_L3400;
b_ret99: ;
		}
		/* line 2855 */
b_L2855: ;
		b_gosubStack[b_gosubSP++]=100; goto b_L1700;
b_ret100: ;
		/* line 2860 */
b_L2860: ;
		if(-((b_v_chf) == ((40)))){
			b_gosubStack[b_gosubSP++]=101; goto b_L3000;
b_ret101: ;
			goto b_return;
		}
		/* line 2865 */
b_L2865: ;
		b_gosubStack[b_gosubSP++]=102; goto b_L3200;
b_ret102: ;
		/* line 2870 */
b_L2870: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		b_v_fi=(0);
		/* line 2905 */
b_L2905: ;
		b_v_ii=(0);
		b_fl_0=((b_v_nvi)-((1)));
		if(b_v_ii > b_fl_0) goto b_f0_e;
b_f0_t: ;
		/* line 2910 */
b_L2910: ;
		if(-(b_strcmp(b_a_vns[B_INT(b_v_ii)],b_v_ids) == 0)){
			b_v_fi=(1);
			b_v_fii=b_v_ii;
			b_v_ii=b_v_nvi;
		}
		/* line 2915 */
b_L2915: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 2920 */
b_L2920: ;
		if(-((b_v_fi) == ((1)))){
			goto b_L2935;
		}
		/* line 2925 */
b_L2925: ;
		if(-((b_v_nvi) < ((63)))){
			goto b_L2955;
		}
		/* line 2930 */
b_L2930: ;
		goto b_return;
		/* line 2935 */
b_L2935: ;
		if(-((b_v_tsi) == ((1)))){
			b_a_vti[B_INT(b_v_fii)]=(1);
			b_a_vss[B_INT(b_v_fii)]=b_keep(b_v_tss);
			goto b_return;
		}
		/* line 2940 */
b_L2940: ;
		b_a_vti[B_INT(b_v_fii)]=(0);
		/* line 2945 */
b_L2945: ;
		b_a_vvf[B_INT(b_v_fii)]=b_v_tvf;
		/* line 2950 */
b_L2950: ;
		goto b_return;
		/* line 2955 */
b_L2955: ;
		b_a_vns[B_INT(b_v_nvi)]=b_keep(b_v_ids);
		/* line 2960 */
b_L2960: ;
		b_a_vti[B_INT(b_v_nvi)]=b_v_tsi;
		/* line 2965 */
b_L2965: ;
		if(-((b_v_tsi) == ((1)))){
			b_a_vss[B_INT(b_v_nvi)]=b_keep(b_v_tss);
		}
		/* line 2970 */
b_L2970: ;
		if(-((b_v_tsi) == ((0)))){
			b_a_vvf[B_INT(b_v_nvi)]=b_v_tvf;
		}
		/* line 2975 */
b_L2975: ;
		b_v_nvi=((b_v_nvi)+((1)));
		/* line 2980 */
b_L2980: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		b_v_bns=b_keep(b_v_ids);
		/* line 3005 */
b_L3005: ;
		b_gosubStack[b_gosubSP++]=103; goto b_L1600;
b_ret103: ;
		/* line 3010 */
b_L3010: ;
		b_v_eti=(0);
		/* line 3015 */
b_L3015: ;
		b_gosubStack[b_gosubSP++]=104; goto b_L2000;
b_ret104: ;
		/* line 3020 */
b_L3020: ;
		b_v_a1f=b_v_evf;
		/* line 3025 */
b_L3025: ;
		b_gosubStack[b_gosubSP++]=105; goto b_L1700;
b_ret105: ;
		/* line 3030 */
b_L3030: ;
		if(-((b_v_chf) == ((44)))){
			b_gosubStack[b_gosubSP++]=106; goto b_L1600;
b_ret106: ;
			b_gosubStack[b_gosubSP++]=107; goto b_L2000;
b_ret107: ;
			b_v_a2f=b_v_evf;
			b_gosubStack[b_gosubSP++]=108; goto b_L1700;
b_ret108: ;
		}
		/* line 3035 */
b_L3035: ;
		if(-((b_v_chf) != ((41)))){
			b_gosubStack[b_gosubSP++]=109; goto b_L3400;
b_ret109: ;
		}
		/* line 3040 */
b_L3040: ;
		b_gosubStack[b_gosubSP++]=110; goto b_L1600;
b_ret110: ;
		/* line 3045 */
b_L3045: ;
		if(-(b_strcmp(b_v_bns,b_lit("ABS",3)) == 0)){
			b_v_evf=b_abs(b_v_a1f);
			goto b_return;
		}
		/* line 3050 */
b_L3050: ;
		if(-(b_strcmp(b_v_bns,b_lit("INT",3)) == 0)){
			b_v_evf=b_int(b_v_a1f);
			goto b_return;
		}
		/* line 3055 */
b_L3055: ;
		if(-(b_strcmp(b_v_bns,b_lit("SQR",3)) == 0)){
			b_v_evf=b_sqr(b_v_a1f);
			goto b_return;
		}
		/* line 3060 */
b_L3060: ;
		if(-(b_strcmp(b_v_bns,b_lit("RND",3)) == 0)){
			b_v_evf=b_rnd(B_INT((0)));
			goto b_return;
		}
		/* line 3065 */
b_L3065: ;
		if(-(b_strcmp(b_v_bns,b_lit("MIN",3)) == 0)){
			b_v_evf=b_v_a2f;
		}
		/* line 3070 */
b_L3070: ;
		if(-(b_strcmp(b_v_bns,b_lit("MIN",3)) == 0)){
			if(-((b_v_a1f) < (b_v_a2f))){
				b_v_evf=b_v_a1f;
			}
		}
		/* line 3075 */
b_L3075: ;
		if(-(b_strcmp(b_v_bns,b_lit("MIN",3)) == 0)){
			goto b_return;
		}
		/* line 3080 */
b_L3080: ;
		if(-(b_strcmp(b_v_bns,b_lit("MAX",3)) == 0)){
			b_v_evf=b_v_a2f;
		}
		/* line 3085 */
b_L3085: ;
		if(-(b_strcmp(b_v_bns,b_lit("MAX",3)) == 0)){
			if(-((b_v_a1f) > (b_v_a2f))){
				b_v_evf=b_v_a1f;
			}
		}
		/* line 3090 */
b_L3090: ;
		if(-(b_strcmp(b_v_bns,b_lit("MAX",3)) == 0)){
			goto b_return;
		}
		/* line 3095 */
b_L3095: ;
		b_gosubStack[b_gosubSP++]=111; goto b_L3400;
b_ret111: ;
		/* line 3200 */
b_L3200: ;
		b_v_evf=(0);
		/* line 3205 */
b_L3205: ;
		b_v_eti=(0);
		/* line 3210 */
b_L3210: ;
		b_v_ess=b_keep(b_lit("",0));
		/* line 3215 */
b_L3215: ;
		b_v_ii=(0);
		b_fl_1=((b_v_nvi)-((1)));
		if(b_v_ii > b_fl_1) goto b_f1_e;
b_f1_t: ;
		/* line 3220 */
b_L3220: ;
		if(-(b_strcmp(b_a_vns[B_INT(b_v_ii)],b_v_ids) == 0)){
			b_v_eti=b_a_vti[B_INT(b_v_ii)];
			b_v_evf=b_a_vvf[B_INT(b_v_ii)];
			b_v_ess=b_keep(b_a_vss[B_INT(b_v_ii)]);
			b_v_ii=b_v_nvi;
		}
		/* line 3225 */
b_L3225: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_1)) goto b_f1_t;
b_f1_e: ;
		/* line 3230 */
b_L3230: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		b_gosubStack[b_gosubSP++]=112; goto b_L1700;
b_ret112: ;
		/* line 3305 */
b_L3305: ;
		if(-((b_v_chf) == ((0)))){
			goto b_return;
		}
		/* line 3310 */
b_L3310: ;
		if(-((b_v_chf) == ((125)))){
			goto b_return;
		}
		/* line 3315 */
b_L3315: ;
		b_gosubStack[b_gosubSP++]=113; goto b_L1000;
b_ret113: ;
		/* line 3320 */
b_L3320: ;
		b_gosubStack[b_gosubSP++]=114; goto b_L1700;
b_ret114: ;
		/* line 3325 */
b_L3325: ;
		if(-((b_v_chf) == ((59)))){
			b_gosubStack[b_gosubSP++]=115; goto b_L1600;
b_ret115: ;
			goto b_L3300;
		}
		/* line 3330 */
b_L3330: ;
		goto b_L3300;
		/* line 3400 */
b_L3400: ;
		{ bstr_t _t=b_lit("SYNTAX ERR @ BYTE ",18); b_str(_t.p,_t.len); }
		b_putint((bint_t)(b_v_pcf));
		b_nl();
		/* line 3405 */
b_L3405: ;
		if(-((b_v_rpi) == ((1)))){
			goto b_L3505;
		}
		/* line 3410 */
b_L3410: ;
		goto b_end;
		/* line 3500 */
b_L3500: ;
		b_v_rpi=(1);
		/* line 3505 */
b_L3505: ;
		b_nl();
		/* line 3510 */
b_L3510: ;
		{ bstr_t _t=b_lit("JS> ",4); b_str(_t.p,_t.len); }
		/* line 3515 */
b_L3515: ;
		b_gosubStack[b_gosubSP++]=116; goto b_L3600;
b_ret116: ;
		/* line 3520 */
b_L3520: ;
		if(-(b_strcmp(b_v_jss,b_lit("EXIT",4)) == 0)){
			goto b_end;
		}
		/* line 3525 */
b_L3525: ;
		if(-(b_strcmp(b_v_jss,b_lit("EXIT",4)) == 0)){
			goto b_end;
		}
		/* line 3530 */
b_L3530: ;
		if(-(b_strcmp(b_v_jss,b_lit("",0)) == 0)){
			goto b_L3505;
		}
		/* line 3535 */
b_L3535: ;
		b_v_ii=(1);
		b_fl_2=B_INT(b_len(b_v_jss));
		if(b_v_ii > b_fl_2) goto b_f2_e;
		b_t_0=((((b_v_bai)+(b_v_ii)))-((1)));
b_f2_t: ;
		/* line 3540 */
b_L3540: ;
		b_poke(b_t_0,b_asc(b_mid(b_v_jss,B_INT(b_v_ii),B_INT((1)))));
		/* line 3545 */
b_L3545: ;
		b_t_0 += 1;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_2)) goto b_f2_t;
b_f2_e: ;
		/* line 3550 */
b_L3550: ;
		b_poke(((b_v_bai)+(B_INT(b_len(b_v_jss)))),(0));
		/* line 3555 */
b_L3555: ;
		b_v_pcf=(0);
		/* line 3560 */
b_L3560: ;
		b_gosubStack[b_gosubSP++]=117; goto b_L3300;
b_ret117: ;
		/* line 3565 */
b_L3565: ;
		if(-((b_v_chf) == ((125)))){
			{ bstr_t _t=b_lit("ERR UNMATCHED }",15); b_str(_t.p,_t.len); }
			b_nl();
		}
		/* line 3570 */
b_L3570: ;
		goto b_L3505;
		/* line 3600 */
b_L3600: ;
		b_v_jss=b_keep(b_lit("",0));
		/* line 3605 */
b_L3605: ;
		{ int _g=b_getin(); if(_g<0) b_v_gcs=b_lit("",0); else b_v_gcs=b_keep(b_chr(_g)); }
		/* line 3610 */
b_L3610: ;
		if(-(b_strcmp(b_v_gcs,b_lit("",0)) == 0)){
			goto b_L3605;
		}
		/* line 3615 */
b_L3615: ;
		if(-(b_strcmp(b_v_gcs,b_lit("\r",1)) == 0)){
			b_nl();
			goto b_return;
		}
		/* line 3620 */
b_L3620: ;
		if(-(b_strcmp(b_v_gcs,b_lit("\024",1)) == 0)){
			b_gosubStack[b_gosubSP++]=118; goto b_L3700;
b_ret118: ;
			goto b_L3605;
		}
		/* line 3625 */
b_L3625: ;
		{ bstr_t _t=b_v_gcs; b_str(_t.p,_t.len); }
		/* line 3630 */
b_L3630: ;
		b_v_jss=b_keep(b_concat(b_v_jss,b_v_gcs));
		/* line 3635 */
b_L3635: ;
		goto b_L3605;
		/* line 3700 */
b_L3700: ;
		if(-((B_INT(b_len(b_v_jss))) == ((0)))){
			goto b_return;
		}
		/* line 3705 */
b_L3705: ;
		b_v_jss=b_keep(b_left(b_v_jss,B_INT(((B_INT(b_len(b_v_jss)))-((1))))));
		/* line 3710 */
b_L3710: ;
		b_putc(20);
		/* line 3715 */
b_L3715: ;
		goto b_return;
		/* line 3800 */
b_L3800: ;
		b_gosubStack[b_gosubSP++]=119; goto b_L1600;
b_ret119: ;
		/* line 3805 */
b_L3805: ;
		b_v_ess=b_keep(b_lit("",0));
		/* line 3810 */
b_L3810: ;
		b_gosubStack[b_gosubSP++]=120; goto b_L1600;
b_ret120: ;
		/* line 3815 */
b_L3815: ;
		if(-((b_v_chf) == ((34)))){
			b_v_eti=(1);
			goto b_return;
		}
		/* line 3820 */
b_L3820: ;
		if((B_INT(-((b_v_chf) == ((0)))) | B_INT(-((b_v_chf) == ((10)))))){
			b_gosubStack[b_gosubSP++]=121; goto b_L3400;
b_ret121: ;
		}
		/* line 3825 */
b_L3825: ;
		b_v_ess=b_keep(b_concat(b_v_ess,b_chr((bint_t)(b_v_chf))));
		/* line 3830 */
b_L3830: ;
		b_gosubStack[b_gosubSP++]=122; goto b_L1600;
b_ret122: ;
		/* line 3835 */
b_L3835: ;
		goto b_L3815;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			case 54: goto b_ret54;
			case 55: goto b_ret55;
			case 56: goto b_ret56;
			case 57: goto b_ret57;
			case 58: goto b_ret58;
			case 59: goto b_ret59;
			case 60: goto b_ret60;
			case 61: goto b_ret61;
			case 62: goto b_ret62;
			case 63: goto b_ret63;
			case 64: goto b_ret64;
			case 65: goto b_ret65;
			case 66: goto b_ret66;
			case 67: goto b_ret67;
			case 68: goto b_ret68;
			case 69: goto b_ret69;
			case 70: goto b_ret70;
			case 71: goto b_ret71;
			case 72: goto b_ret72;
			case 73: goto b_ret73;
			case 74: goto b_ret74;
			case 75: goto b_ret75;
			case 76: goto b_ret76;
			case 77: goto b_ret77;
			case 78: goto b_ret78;
			case 79: goto b_ret79;
			case 80: goto b_ret80;
			case 81: goto b_ret81;
			case 82: goto b_ret82;
			case 83: goto b_ret83;
			case 84: goto b_ret84;
			case 85: goto b_ret85;
			case 86: goto b_ret86;
			case 87: goto b_ret87;
			case 88: goto b_ret88;
			case 89: goto b_ret89;
			case 90: goto b_ret90;
			case 91: goto b_ret91;
			case 92: goto b_ret92;
			case 93: goto b_ret93;
			case 94: goto b_ret94;
			case 95: goto b_ret95;
			case 96: goto b_ret96;
			case 97: goto b_ret97;
			case 98: goto b_ret98;
			case 99: goto b_ret99;
			case 100: goto b_ret100;
			case 101: goto b_ret101;
			case 102: goto b_ret102;
			case 103: goto b_ret103;
			case 104: goto b_ret104;
			case 105: goto b_ret105;
			case 106: goto b_ret106;
			case 107: goto b_ret107;
			case 108: goto b_ret108;
			case 109: goto b_ret109;
			case 110: goto b_ret110;
			case 111: goto b_ret111;
			case 112: goto b_ret112;
			case 113: goto b_ret113;
			case 114: goto b_ret114;
			case 115: goto b_ret115;
			case 116: goto b_ret116;
			case 117: goto b_ret117;
			case 118: goto b_ret118;
			case 119: goto b_ret119;
			case 120: goto b_ret120;
			case 121: goto b_ret121;
			case 122: goto b_ret122;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
