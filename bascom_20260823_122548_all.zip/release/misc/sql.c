/* OPTIMIZE_C -- sql.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_dki;
static unsigned int b_v_bai;
static breal_t b_a_rvf[512];
static bstr_t b_a_rvs[512];
static breal_t b_a_vf[8];
static bstr_t b_a_vs[8];
static breal_t b_a_ff[8];
static bstr_t b_a_fs[8];
static breal_t b_a_af[8];
static bstr_t b_a_as[8];
static bstr_t b_a_cls[8];
static bstr_t b_a_cts[8];
static bstr_t b_a_ats[8];
static bstr_t b_a_pjs[8];
static bstr_t b_a_sls[8];
static bint_t b_a_ixi[64];
static bstr_t b_v_sqs;
static int b_v_lsi;
static breal_t b_v_spf;
static bstr_t b_v_wds;
static bstr_t b_v_tns;
static breal_t b_v_ccf;
static int b_v_ali;
static bint_t b_v_pji;
static bstr_t b_v_obs;
static int b_v_odi;
static bstr_t b_v_wcs;
static bstr_t b_v_sts;
static bstr_t b_v_svs;
static bstr_t b_v_lis;
static int b_v_ssi;
static breal_t b_v_svf;
static breal_t b_v_nmf;
static bint_t b_v_rci;
static bint_t b_v_cpi;
static bint_t b_v_vci;
static int b_v_ci;
static bint_t b_v_sgi;
static breal_t b_v_kf;
static bstr_t b_v_wos;
static bstr_t b_v_wvs;
static int b_v_wsi;
static breal_t b_v_wvf;
static bint_t b_v_ri;
static bint_t b_v_wmi;
static breal_t b_v_acf;
static bstr_t b_v_nas;
static breal_t b_v_cif;
static bstr_t b_v_css;
static breal_t b_v_obf;
static bint_t b_v_mci;
static bint_t b_v_gii;
static bstr_t b_v_xks;
static bint_t b_v_xai;
static bint_t b_v_xbi;
static bint_t b_v_xhi;
static bint_t b_v_xii;
static int b_v_xei;
static breal_t b_v_xcf;
static breal_t b_v_xdf;
static bstr_t b_v_yas;
static bstr_t b_v_ybs;
static bstr_t b_v_vas;
static breal_t b_v_vaf;
static int b_v_mi;
static breal_t b_v_if;
static breal_t b_v_nf;
static bstr_t b_v_nss;
static breal_t b_v_sif;
static bint_t b_v_wri;
static bint_t b_v_bci;
static bstr_t b_v_gcs;
static breal_t b_v_bpf;
static bint_t b_v_lei;
static bint_t b_v_sci;
static bint_t b_v_fci;
static breal_t b_v_lnf;
static breal_t b_v_lwf;
static breal_t b_v_jf;
static breal_t b_v_lzf;
static breal_t b_v_fkf;
static breal_t b_v_fjf;
static bstr_t b_v_zss;
static breal_t b_v_zpf;
static bstr_t b_v_aks;
static bstr_t b_v_cns;
static bstr_t b_v_nts;
static bstr_t b_v_ots;
static breal_t b_v_txf;
static bint_t b_t_0;
static bint_t b_t_1;
static breal_t b_fl_0;
static breal_t b_fl_1;
static breal_t b_fl_2;
static bint_t b_fl_3;
static bint_t b_fl_4;
static bint_t b_fl_5;
static breal_t b_fl_6;
static breal_t b_fl_7;
static breal_t b_fl_8;
static breal_t b_fl_9;
static bint_t b_fl_10;
static bint_t b_fl_11;
static breal_t b_fl_12;
static breal_t b_fl_13;
static breal_t b_fl_14;
static breal_t b_fl_15;
static breal_t b_fl_16;
static breal_t b_fl_17;
static bint_t b_fl_18;
static breal_t b_fl_19;
static breal_t b_fl_20;
static bint_t b_fl_21;
static breal_t b_fl_22;
static bint_t b_fl_23;
static breal_t b_fl_24;
static breal_t b_fl_25;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{2,0,0,"CREATE TABLE EMP (ID,SAL,DEPT)",30},{2,0,0,"INSERT INTO EMP VALUES (1,100,1)",32},{2,0,0,"INSERT INTO EMP VALUES (2,200,2)",32},{2,0,0,"INSERT INTO EMP VALUES (3,150,1)",32},{2,0,0,"INSERT INTO EMP VALUES (4,300,3)",32},{2,0,0,"SELECT SAL FROM EMP WHERE ID=1",30},{2,0,0,"SELECT ID,SAL FROM EMP WHERE SAL>150",36},{2,0,0,"UPDATE EMP SET SAL=999 WHERE ID=1",33},{2,0,0,"SELECT * FROM EMP",17},{2,0,0,"SELECT * FROM EMP ORDER BY SAL",30},{2,0,0,"SELECT * FROM EMP ORDER BY SAL DESC",35},{2,0,0,"SELECT ID,SAL FROM EMP ORDER BY DEPT",36},{2,0,0,"DELETE FROM EMP WHERE SAL>250",29},{2,0,0,"SELECT * FROM EMP",17},{2,0,0,"CREATE TABLE T2 (A,B)",21},{2,0,0,"INSERT INTO T2 VALUES (1,2)",27},{2,0,0,"ALTER TABLE T2 ADD C",20},{2,0,0,"SELECT * FROM T2",16},{2,0,0,"ALTER TABLE T2 DROP B",21},{2,0,0,"SELECT * FROM T2",16},{2,0,0,"ALTER TABLE T2 RENAME TO T3",27},{2,0,0,"SELECT * FROM T3",16},{2,0,0,"DROP TABLE T3",13},{2,0,0,"CREATE TABLE P (ID,NAME STR,AGE)",32},{2,0,0,"INSERT INTO P VALUES (1,'CARL',35)",34},{2,0,0,"INSERT INTO P VALUES (2,'ALICE',30)",35},{2,0,0,"INSERT INTO P VALUES (3,'BOBBY',25)",35},{2,0,0,"SELECT * FROM P",15},{2,0,0,"SELECT ID,NAME FROM P WHERE NAME='ALICE'",40},{2,0,0,"SELECT * FROM P ORDER BY NAME",29},{2,0,0,"UPDATE P SET NAME='ZOE' WHERE ID=1",34},{2,0,0,"SELECT * FROM P",15},{2,0,0,"DROP TABLE P",12},{2,0,0,"END",3}};
int b_data_len = 34;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 5 */
b_L5: ;
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 15 */
b_L15: ;
		b_v_dki=(1);
		/* line 20 */
b_L20: ;
		b_v_bai=(49152.0);
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		b_dataPtr = 0;
		/* line 50 */
b_L50: ;
		b_v_sqs=b_keep(b_read_str());
		/* line 60 */
b_L60: ;
		if(-(b_strcmp(b_v_sqs,b_lit("END",3)) == 0)){
			goto b_L5000;
		}
		/* line 70 */
b_L70: ;
		{ bstr_t _t=b_v_sqs; b_str(_t.p,_t.len); }
		b_nl();
		/* line 80 */
b_L80: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1000;
b_ret0: ;
		/* line 90 */
b_L90: ;
		goto b_L50;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		/* line 1002 */
b_L1002: ;
		b_v_lsi=B_INT(b_len(b_v_sqs));
		b_v_spf=(1);
		/* line 1003 */
b_L1003: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L4100;
b_ret1: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L4200;
b_ret2: ;
		/* line 1004 */
b_L1004: ;
		if(-(b_strcmp(b_v_wds,b_lit("CREATE",6)) == 0)){
			b_gosubStack[b_gosubSP++]=3; goto b_L1100;
b_ret3: ;
			goto b_return;
		}
		/* line 1005 */
b_L1005: ;
		if(-(b_strcmp(b_v_wds,b_lit("INSERT",6)) == 0)){
			b_gosubStack[b_gosubSP++]=4; goto b_L1200;
b_ret4: ;
			goto b_return;
		}
		/* line 1006 */
b_L1006: ;
		if(-(b_strcmp(b_v_wds,b_lit("SELECT",6)) == 0)){
			b_gosubStack[b_gosubSP++]=5; goto b_L1300;
b_ret5: ;
			goto b_return;
		}
		/* line 1007 */
b_L1007: ;
		if(-(b_strcmp(b_v_wds,b_lit("UPDATE",6)) == 0)){
			b_gosubStack[b_gosubSP++]=6; goto b_L1400;
b_ret6: ;
			goto b_return;
		}
		/* line 1008 */
b_L1008: ;
		if(-(b_strcmp(b_v_wds,b_lit("DELETE",6)) == 0)){
			b_gosubStack[b_gosubSP++]=7; goto b_L1500;
b_ret7: ;
			goto b_return;
		}
		/* line 1009 */
b_L1009: ;
		if(-(b_strcmp(b_v_wds,b_lit("DROP",4)) == 0)){
			b_gosubStack[b_gosubSP++]=8; goto b_L5300;
b_ret8: ;
			goto b_return;
		}
		/* line 1010 */
b_L1010: ;
		if(-(b_strcmp(b_v_wds,b_lit("ALTER",5)) == 0)){
			b_gosubStack[b_gosubSP++]=9; goto b_L5400;
b_ret9: ;
			goto b_return;
		}
		/* line 1011 */
b_L1011: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L4900;
b_ret10: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		/* line 1101 */
b_L1101: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L4100;
b_ret11: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L4200;
b_ret12: ;
		/* line 1102 */
b_L1102: ;
		if(-(b_strcmp(b_v_wds,b_lit("TABLE",5)) != 0)){
			b_gosubStack[b_gosubSP++]=13; goto b_L4900;
b_ret13: ;
			goto b_return;
		}
		/* line 1103 */
b_L1103: ;
		b_gosubStack[b_gosubSP++]=14; goto b_L4100;
b_ret14: ;
		b_gosubStack[b_gosubSP++]=15; goto b_L4200;
b_ret15: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 1104 */
b_L1104: ;
		b_gosubStack[b_gosubSP++]=16; goto b_L4100;
b_ret16: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) != ((40)))){
			b_gosubStack[b_gosubSP++]=17; goto b_L4900;
b_ret17: ;
			goto b_return;
		}
		/* line 1105 */
b_L1105: ;
		b_v_spf=((b_v_spf)+((1)));
		b_v_ccf=(0);
		/* line 1106 */
b_L1106: ;
		b_gosubStack[b_gosubSP++]=18; goto b_L4100;
b_ret18: ;
		b_gosubStack[b_gosubSP++]=19; goto b_L4200;
b_ret19: ;
		if(-(b_strcmp(b_v_wds,b_lit("",0)) == 0)){
			goto b_L1112;
		}
		/* line 1107 */
b_L1107: ;
		b_a_cls[(bint_t)(b_v_ccf)]=b_keep(b_v_wds);
		b_a_cts[(bint_t)(b_v_ccf)]=b_keep(b_lit("N",1));
		b_v_ccf=((b_v_ccf)+((1)));
		b_gosubStack[b_gosubSP++]=20; goto b_L4100;
b_ret20: ;
		/* line 1108 */
b_L1108: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((44)))){
			b_v_spf=((b_v_spf)+((1)));
			goto b_L1106;
		}
		/* line 1109 */
b_L1109: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((41)))){
			goto b_L1112;
		}
		/* line 1110 */
b_L1110: ;
		b_gosubStack[b_gosubSP++]=21; goto b_L4200;
b_ret21: ;
		if(-(b_strcmp(b_v_wds,b_lit("STR",3)) == 0)){
			b_a_cts[(bint_t)(((b_v_ccf)-((1))))]=b_keep(b_lit("S",1));
			b_gosubStack[b_gosubSP++]=22; goto b_L4100;
b_ret22: ;
			goto b_L1108;
		}
		/* line 1111 */
b_L1111: ;
		b_gosubStack[b_gosubSP++]=23; goto b_L4900;
b_ret23: ;
		goto b_return;
		/* line 1112 */
b_L1112: ;
		b_v_spf=((b_v_spf)+((1)));
		/* line 1113 */
b_L1113: ;
		b_gosubStack[b_gosubSP++]=24; goto b_L1600;
b_ret24: ;
		/* line 1114 */
b_L1114: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1201 */
b_L1201: ;
		b_gosubStack[b_gosubSP++]=25; goto b_L4100;
b_ret25: ;
		b_gosubStack[b_gosubSP++]=26; goto b_L4200;
b_ret26: ;
		/* line 1202 */
b_L1202: ;
		if(-(b_strcmp(b_v_wds,b_lit("INTO",4)) != 0)){
			b_gosubStack[b_gosubSP++]=27; goto b_L4900;
b_ret27: ;
			goto b_return;
		}
		/* line 1203 */
b_L1203: ;
		b_gosubStack[b_gosubSP++]=28; goto b_L4100;
b_ret28: ;
		b_gosubStack[b_gosubSP++]=29; goto b_L4200;
b_ret29: ;
		b_v_tns=b_keep(b_v_wds);
		b_gosubStack[b_gosubSP++]=30; goto b_L3600;
b_ret30: ;
		if(-((b_v_ccf) == ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 1204 */
b_L1204: ;
		b_gosubStack[b_gosubSP++]=31; goto b_L4100;
b_ret31: ;
		b_gosubStack[b_gosubSP++]=32; goto b_L4200;
b_ret32: ;
		if(-(b_strcmp(b_v_wds,b_lit("VALUES",6)) != 0)){
			b_gosubStack[b_gosubSP++]=33; goto b_L4900;
b_ret33: ;
			goto b_return;
		}
		/* line 1205 */
b_L1205: ;
		b_gosubStack[b_gosubSP++]=34; goto b_L4100;
b_ret34: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) != ((40)))){
			b_gosubStack[b_gosubSP++]=35; goto b_L4900;
b_ret35: ;
			goto b_return;
		}
		/* line 1206 */
b_L1206: ;
		b_v_spf=((b_v_spf)+((1)));
		b_gosubStack[b_gosubSP++]=36; goto b_L1700;
b_ret36: ;
		/* line 1207 */
b_L1207: ;
		b_gosubStack[b_gosubSP++]=37; goto b_L4100;
b_ret37: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) != ((41)))){
			b_gosubStack[b_gosubSP++]=38; goto b_L4900;
b_ret38: ;
			goto b_return;
		}
		/* line 1208 */
b_L1208: ;
		b_v_spf=((b_v_spf)+((1)));
		/* line 1209 */
b_L1209: ;
		b_gosubStack[b_gosubSP++]=39; goto b_L2000;
b_ret39: ;
		/* line 1210 */
b_L1210: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		/* line 1301 */
b_L1301: ;
		b_v_ali=(0);
		b_v_pji=(0);
		b_v_obs=b_keep(b_lit("",0));
		b_v_odi=(0);
		/* line 1302 */
b_L1302: ;
		b_gosubStack[b_gosubSP++]=40; goto b_L4100;
b_ret40: ;
		/* line 1303 */
b_L1303: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((42)))){
			b_v_ali=(1);
			b_v_spf=((b_v_spf)+((1)));
			goto b_L1307;
		}
		/* line 1304 */
b_L1304: ;
		b_gosubStack[b_gosubSP++]=41; goto b_L4200;
b_ret41: ;
		b_a_pjs[B_INT(b_v_pji)]=b_keep(b_v_wds);
		b_v_pji=((b_v_pji)+((1)));
		/* line 1305 */
b_L1305: ;
		b_gosubStack[b_gosubSP++]=42; goto b_L4100;
b_ret42: ;
		if(-((b_v_spf) > (b_v_lsi))){
			b_gosubStack[b_gosubSP++]=43; goto b_L4900;
b_ret43: ;
			goto b_return;
		}
		/* line 1306 */
b_L1306: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((44)))){
			b_v_spf=((b_v_spf)+((1)));
			goto b_L1304;
		}
		/* line 1307 */
b_L1307: ;
		b_gosubStack[b_gosubSP++]=44; goto b_L4100;
b_ret44: ;
		b_gosubStack[b_gosubSP++]=45; goto b_L4200;
b_ret45: ;
		if(-(b_strcmp(b_v_wds,b_lit("FROM",4)) != 0)){
			b_gosubStack[b_gosubSP++]=46; goto b_L4900;
b_ret46: ;
			goto b_return;
		}
		/* line 1308 */
b_L1308: ;
		b_gosubStack[b_gosubSP++]=47; goto b_L4100;
b_ret47: ;
		b_gosubStack[b_gosubSP++]=48; goto b_L4200;
b_ret48: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 1309 */
b_L1309: ;
		b_v_wcs=b_keep(b_lit("",0));
		b_gosubStack[b_gosubSP++]=49; goto b_L4100;
b_ret49: ;
		/* line 1310 */
b_L1310: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_L1319;
		}
		/* line 1311 */
b_L1311: ;
		b_gosubStack[b_gosubSP++]=50; goto b_L4200;
b_ret50: ;
		if(-(b_strcmp(b_v_wds,b_lit("WHERE",5)) == 0)){
			b_gosubStack[b_gosubSP++]=51; goto b_L2100;
b_ret51: ;
			b_gosubStack[b_gosubSP++]=52; goto b_L4100;
b_ret52: ;
			goto b_L1310;
		}
		/* line 1312 */
b_L1312: ;
		if(-(b_strcmp(b_v_wds,b_lit("ORDER",5)) == 0)){
			goto b_L1314;
		}
		/* line 1313 */
b_L1313: ;
		b_gosubStack[b_gosubSP++]=53; goto b_L4900;
b_ret53: ;
		goto b_return;
		/* line 1314 */
b_L1314: ;
		/* line 1315 */
b_L1315: ;
		b_gosubStack[b_gosubSP++]=54; goto b_L4100;
b_ret54: ;
		b_gosubStack[b_gosubSP++]=55; goto b_L4200;
b_ret55: ;
		if(-(b_strcmp(b_v_wds,b_lit("BY",2)) != 0)){
			b_gosubStack[b_gosubSP++]=56; goto b_L4900;
b_ret56: ;
			goto b_return;
		}
		/* line 1316 */
b_L1316: ;
		b_gosubStack[b_gosubSP++]=57; goto b_L4100;
b_ret57: ;
		b_gosubStack[b_gosubSP++]=58; goto b_L4200;
b_ret58: ;
		b_v_obs=b_keep(b_v_wds);
		/* line 1317 */
b_L1317: ;
		b_gosubStack[b_gosubSP++]=59; goto b_L4100;
b_ret59: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_L1319;
		}
		/* line 1318 */
b_L1318: ;
		b_gosubStack[b_gosubSP++]=60; goto b_L4200;
b_ret60: ;
		if(-(b_strcmp(b_v_wds,b_lit("DESC",4)) == 0)){
			b_v_odi=(1);
		}
		/* line 1319 */
b_L1319: ;
		if(-(b_strcmp(b_v_obs,b_lit("",0)) == 0)){
			b_gosubStack[b_gosubSP++]=61; goto b_L2200;
b_ret61: ;
			goto b_return;
		}
		/* line 1320 */
b_L1320: ;
		b_gosubStack[b_gosubSP++]=62; goto b_L2300;
b_ret62: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1401 */
b_L1401: ;
		b_gosubStack[b_gosubSP++]=63; goto b_L4100;
b_ret63: ;
		b_gosubStack[b_gosubSP++]=64; goto b_L4200;
b_ret64: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 1402 */
b_L1402: ;
		b_gosubStack[b_gosubSP++]=65; goto b_L4100;
b_ret65: ;
		b_gosubStack[b_gosubSP++]=66; goto b_L4200;
b_ret66: ;
		if(-(b_strcmp(b_v_wds,b_lit("SET",3)) != 0)){
			b_gosubStack[b_gosubSP++]=67; goto b_L4900;
b_ret67: ;
			goto b_return;
		}
		/* line 1403 */
b_L1403: ;
		b_gosubStack[b_gosubSP++]=68; goto b_L4100;
b_ret68: ;
		b_gosubStack[b_gosubSP++]=69; goto b_L4200;
b_ret69: ;
		b_v_sts=b_keep(b_v_wds);
		/* line 1404 */
b_L1404: ;
		b_gosubStack[b_gosubSP++]=70; goto b_L4100;
b_ret70: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) != ((61)))){
			b_gosubStack[b_gosubSP++]=71; goto b_L4900;
b_ret71: ;
			goto b_return;
		}
		/* line 1405 */
b_L1405: ;
		b_v_spf=((b_v_spf)+((1)));
		b_gosubStack[b_gosubSP++]=72; goto b_L4100;
b_ret72: ;
		/* line 1406 */
b_L1406: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((39)))){
			b_gosubStack[b_gosubSP++]=73; goto b_L1800;
b_ret73: ;
			b_v_svs=b_keep(b_v_lis);
			b_v_ssi=(1);
			goto b_L1408;
		}
		/* line 1407 */
b_L1407: ;
		b_gosubStack[b_gosubSP++]=74; goto b_L1900;
b_ret74: ;
		b_v_svf=b_v_nmf;
		b_v_ssi=(0);
		/* line 1408 */
b_L1408: ;
		b_v_wcs=b_keep(b_lit("",0));
		b_gosubStack[b_gosubSP++]=75; goto b_L4100;
b_ret75: ;
		/* line 1409 */
b_L1409: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_L1412;
		}
		/* line 1410 */
b_L1410: ;
		b_gosubStack[b_gosubSP++]=76; goto b_L4200;
b_ret76: ;
		if(-(b_strcmp(b_v_wds,b_lit("WHERE",5)) != 0)){
			goto b_L1412;
		}
		/* line 1411 */
b_L1411: ;
		b_gosubStack[b_gosubSP++]=77; goto b_L2100;
b_ret77: ;
		/* line 1412 */
b_L1412: ;
		b_gosubStack[b_gosubSP++]=78; goto b_L3200;
b_ret78: ;
		/* line 1413 */
b_L1413: ;
		goto b_return;
		/* line 1500 */
b_L1500: ;
		/* line 1501 */
b_L1501: ;
		b_gosubStack[b_gosubSP++]=79; goto b_L4100;
b_ret79: ;
		b_gosubStack[b_gosubSP++]=80; goto b_L4200;
b_ret80: ;
		if(-(b_strcmp(b_v_wds,b_lit("FROM",4)) != 0)){
			b_gosubStack[b_gosubSP++]=81; goto b_L4900;
b_ret81: ;
			goto b_return;
		}
		/* line 1502 */
b_L1502: ;
		b_gosubStack[b_gosubSP++]=82; goto b_L4100;
b_ret82: ;
		b_gosubStack[b_gosubSP++]=83; goto b_L4200;
b_ret83: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 1503 */
b_L1503: ;
		b_v_wcs=b_keep(b_lit("",0));
		b_gosubStack[b_gosubSP++]=84; goto b_L4100;
b_ret84: ;
		/* line 1504 */
b_L1504: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_L1507;
		}
		/* line 1505 */
b_L1505: ;
		b_gosubStack[b_gosubSP++]=85; goto b_L4200;
b_ret85: ;
		if(-(b_strcmp(b_v_wds,b_lit("WHERE",5)) != 0)){
			goto b_L1507;
		}
		/* line 1506 */
b_L1506: ;
		b_gosubStack[b_gosubSP++]=86; goto b_L2100;
b_ret86: ;
		/* line 1507 */
b_L1507: ;
		b_gosubStack[b_gosubSP++]=87; goto b_L3400;
b_ret87: ;
		/* line 1508 */
b_L1508: ;
		goto b_return;
		/* line 1600 */
b_L1600: ;
		/* line 1601 */
b_L1601: ;
		b_v_rci=(0);
		b_v_cpi=(0);
		b_gosubStack[b_gosubSP++]=88; goto b_L3700;
b_ret88: ;
		goto b_return;
		/* line 1700 */
b_L1700: ;
		/* line 1701 */
b_L1701: ;
		b_v_vci=(0);
		/* line 1702 */
b_L1702: ;
		b_gosubStack[b_gosubSP++]=89; goto b_L4100;
b_ret89: ;
		/* line 1703 */
b_L1703: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_return;
		}
		/* line 1704 */
b_L1704: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((41)))){
			goto b_return;
		}
		/* line 1705 */
b_L1705: ;
		if(-(b_strcmp(b_a_cts[B_INT(b_v_vci)],b_lit("S",1)) == 0)){
			b_gosubStack[b_gosubSP++]=90; goto b_L1800;
b_ret90: ;
			b_a_vs[B_INT(b_v_vci)]=b_keep(b_v_lis);
		}
		/* line 1706 */
b_L1706: ;
		if(-(b_strcmp(b_a_cts[B_INT(b_v_vci)],b_lit("S",1)) != 0)){
			b_gosubStack[b_gosubSP++]=91; goto b_L1900;
b_ret91: ;
			b_a_vf[B_INT(b_v_vci)]=b_v_nmf;
		}
		/* line 1707 */
b_L1707: ;
		b_v_vci=((b_v_vci)+((1)));
		b_gosubStack[b_gosubSP++]=92; goto b_L4100;
b_ret92: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((44)))){
			b_v_spf=((b_v_spf)+((1)));
			goto b_L1702;
		}
		/* line 1708 */
b_L1708: ;
		goto b_return;
		/* line 1800 */
b_L1800: ;
		/* line 1801 */
b_L1801: ;
		b_v_lis=b_keep(b_lit("",0));
		b_v_spf=((b_v_spf)+((1)));
		/* line 1802 */
b_L1802: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_return;
		}
		/* line 1803 */
b_L1803: ;
		b_v_ci=b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))));
		if(-((b_v_ci) == ((39)))){
			b_v_spf=((b_v_spf)+((1)));
			goto b_return;
		}
		/* line 1804 */
b_L1804: ;
		b_v_lis=b_keep(b_concat(b_v_lis,b_chr(B_INT(b_v_ci))));
		b_v_spf=((b_v_spf)+((1)));
		goto b_L1802;
		/* line 1900 */
b_L1900: ;
		/* line 1901 */
b_L1901: ;
		b_v_nmf=(0);
		b_v_sgi=(1);
		/* line 1902 */
b_L1902: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_return;
		}
		/* line 1903 */
b_L1903: ;
		b_v_ci=b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))));
		/* line 1904 */
b_L1904: ;
		if(-((b_v_ci) == ((45)))){
			b_v_sgi=(-1);
			b_v_spf=((b_v_spf)+((1)));
		}
		/* line 1905 */
b_L1905: ;
		if(-((b_v_spf) > (b_v_lsi))){
			b_v_nmf=(0);
			goto b_return;
		}
		/* line 1906 */
b_L1906: ;
		if(-((b_v_spf) > (b_v_lsi))){
			b_v_nmf=((b_v_nmf)*(b_v_sgi));
			goto b_return;
		}
		/* line 1907 */
b_L1907: ;
		b_v_ci=b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))));
		/* line 1908 */
b_L1908: ;
		if((B_INT(-((b_v_ci) < ((48)))) | B_INT(-((b_v_ci) > ((57)))))){
			b_v_nmf=((b_v_nmf)*(b_v_sgi));
			goto b_return;
		}
		/* line 1909 */
b_L1909: ;
		b_v_nmf=((((b_v_nmf)*((10))))+(((b_v_ci)-((48)))));
		b_v_spf=((b_v_spf)+((1)));
		goto b_L1906;
		/* line 2000 */
b_L2000: ;
		/* line 2001 */
b_L2001: ;
		b_v_kf=(0);
		b_fl_0=((b_v_vci)-((1)));
		if(b_v_kf > b_fl_0) goto b_f0_e;
b_f0_t: ;
		b_a_rvf[(B_INT(b_v_rci))*8+((bint_t)(b_v_kf))]=b_a_vf[(bint_t)(b_v_kf)];
		b_a_rvs[(B_INT(b_v_rci))*8+((bint_t)(b_v_kf))]=b_keep(b_a_vs[(bint_t)(b_v_kf)]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 2002 */
b_L2002: ;
		b_v_rci=((b_v_rci)+((1)));
		b_v_cpi=((b_v_rci)-((1)));
		b_gosubStack[b_gosubSP++]=93; goto b_L3700;
b_ret93: ;
		goto b_return;
		/* line 2100 */
b_L2100: ;
		/* line 2101 */
b_L2101: ;
		b_gosubStack[b_gosubSP++]=94; goto b_L4100;
b_ret94: ;
		b_gosubStack[b_gosubSP++]=95; goto b_L4200;
b_ret95: ;
		b_v_wcs=b_keep(b_v_wds);
		/* line 2102 */
b_L2102: ;
		b_gosubStack[b_gosubSP++]=96; goto b_L4100;
b_ret96: ;
		b_v_wos=b_keep(b_lit("",0));
		/* line 2103 */
b_L2103: ;
		b_v_ci=b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))));
		/* line 2104 */
b_L2104: ;
		if(-((b_v_ci) == ((33)))){
			if(-((b_asc(b_mid(b_v_sqs,(bint_t)(((b_v_spf)+((1)))),B_INT((1))))) == ((61)))){
				b_v_wos=b_keep(b_lit("!=",2));
				b_v_spf=((b_v_spf)+((1)));
				goto b_L2111;
			}
		}
		/* line 2105 */
b_L2105: ;
		if(-((b_v_ci) == ((60)))){
			if(-((b_asc(b_mid(b_v_sqs,(bint_t)(((b_v_spf)+((1)))),B_INT((1))))) == ((61)))){
				b_v_wos=b_keep(b_lit("<=",2));
				b_v_spf=((b_v_spf)+((1)));
				goto b_L2111;
			}
		}
		/* line 2106 */
b_L2106: ;
		if(-((b_v_ci) == ((62)))){
			if(-((b_asc(b_mid(b_v_sqs,(bint_t)(((b_v_spf)+((1)))),B_INT((1))))) == ((61)))){
				b_v_wos=b_keep(b_lit(">=",2));
				b_v_spf=((b_v_spf)+((1)));
				goto b_L2111;
			}
		}
		/* line 2107 */
b_L2107: ;
		if(-((b_v_ci) == ((60)))){
			b_v_wos=b_keep(b_lit("<",1));
			goto b_L2111;
		}
		/* line 2108 */
b_L2108: ;
		if(-((b_v_ci) == ((62)))){
			b_v_wos=b_keep(b_lit(">",1));
			goto b_L2111;
		}
		/* line 2109 */
b_L2109: ;
		if(-((b_v_ci) == ((61)))){
			b_v_wos=b_keep(b_lit("=",1));
			goto b_L2111;
		}
		/* line 2110 */
b_L2110: ;
		b_gosubStack[b_gosubSP++]=97; goto b_L4900;
b_ret97: ;
		goto b_return;
		/* line 2111 */
b_L2111: ;
		b_v_spf=((b_v_spf)+((1)));
		b_gosubStack[b_gosubSP++]=98; goto b_L4100;
b_ret98: ;
		/* line 2112 */
b_L2112: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((39)))){
			b_gosubStack[b_gosubSP++]=99; goto b_L1800;
b_ret99: ;
			b_v_wvs=b_keep(b_v_lis);
			b_v_wsi=(1);
			goto b_return;
		}
		/* line 2113 */
b_L2113: ;
		b_gosubStack[b_gosubSP++]=100; goto b_L1900;
b_ret100: ;
		b_v_wvf=b_v_nmf;
		b_v_wsi=(0);
		goto b_return;
		/* line 2200 */
b_L2200: ;
		/* line 2201 */
b_L2201: ;
		b_gosubStack[b_gosubSP++]=101; goto b_L3600;
b_ret101: ;
		if(-((b_v_ccf) == ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 2202 */
b_L2202: ;
		if(-((b_v_rci) <= ((0)))){
			goto b_return;
		}
		/* line 2203 */
b_L2203: ;
		b_v_ri=(0);
		/* line 2204 */
b_L2204: ;
		b_gosubStack[b_gosubSP++]=102; goto b_L3300;
b_ret102: ;
		/* line 2205 */
b_L2205: ;
		if(-((b_v_wmi) == ((0)))){
			goto b_L2209;
		}
		/* line 2206 */
b_L2206: ;
		if(-((b_v_ali) == ((1)))){
			goto b_L2211;
		}
		/* line 2207 */
b_L2207: ;
		b_v_acf=(0);
		b_v_kf=(0);
		b_fl_1=((b_v_pji)-((1)));
		if(b_v_kf > b_fl_1) goto b_f1_e;
b_f1_t: ;
		b_v_nas=b_keep(b_a_pjs[(bint_t)(b_v_kf)]);
		b_gosubStack[b_gosubSP++]=103; goto b_L3000;
b_ret103: ;
		if(-((b_v_cif) >= ((0)))){
			b_gosubStack[b_gosubSP++]=104; goto b_L3100;
b_ret104: ;
			b_v_acf=((b_v_acf)+((1)));
		}
		/* line 2208 */
b_L2208: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_1)) goto b_f1_t;
b_f1_e: ;
		goto b_L2212;
		/* line 2209 */
b_L2209: ;
		b_v_ri=((b_v_ri)+((1)));
		if(-((b_v_ri) < (b_v_rci))){
			goto b_L2204;
		}
		/* line 2210 */
b_L2210: ;
		goto b_return;
		/* line 2211 */
b_L2211: ;
		b_v_kf=(0);
		b_fl_2=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_2) goto b_f2_e;
b_f2_t: ;
		b_a_ats[(bint_t)(b_v_kf)]=b_keep(b_a_cts[(bint_t)(b_v_kf)]);
		b_a_as[(bint_t)(b_v_kf)]=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]);
		b_a_af[(bint_t)(b_v_kf)]=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))];
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_2)) goto b_f2_t;
b_f2_e: ;
		b_v_acf=b_v_ccf;
		/* line 2212 */
b_L2212: ;
		b_gosubStack[b_gosubSP++]=105; goto b_L2800;
b_ret105: ;
		b_putc(30);
		{ bstr_t _t=b_v_css; b_str(_t.p,_t.len); }
		b_putc(5);
		b_nl();
		goto b_L2209;
		/* line 2300 */
b_L2300: ;
		/* line 2301 */
b_L2301: ;
		b_gosubStack[b_gosubSP++]=106; goto b_L3600;
b_ret106: ;
		/* line 2302 */
b_L2302: ;
		if(-((b_v_rci) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 2303 */
b_L2303: ;
		b_v_nas=b_keep(b_v_obs);
		b_gosubStack[b_gosubSP++]=107; goto b_L3000;
b_ret107: ;
		if(-((b_v_cif) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO COL ",7); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_obs; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 2304 */
b_L2304: ;
		b_v_obf=b_v_cif;
		b_v_mci=(0);
		/* line 2305 */
b_L2305: ;
		if(-((b_v_rci) <= ((0)))){
			goto b_L2311;
		}
		/* line 2306 */
b_L2306: ;
		b_v_ri=(0);
		b_fl_3=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_3) goto b_f3_e;
b_f3_t: ;
		/* line 2307 */
b_L2307: ;
		b_gosubStack[b_gosubSP++]=108; goto b_L3300;
b_ret108: ;
		/* line 2308 */
b_L2308: ;
		if(-((b_v_wmi) == ((1)))){
			b_a_ixi[B_INT(b_v_mci)]=b_v_ri;
			b_v_mci=((b_v_mci)+((1)));
		}
		/* line 2309 */
b_L2309: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 2310 */
b_L2310: ;
		if(-((b_v_mci) > ((1)))){
			b_gosubStack[b_gosubSP++]=109; goto b_L2400;
b_ret109: ;
		}
		/* line 2311 */
b_L2311: ;
		if(-((b_v_mci) <= ((0)))){
			goto b_return;
		}
		/* line 2312 */
b_L2312: ;
		b_v_gii=(0);
		/* line 2313 */
b_L2313: ;
		b_v_ri=b_a_ixi[B_INT(b_v_gii)];
		b_gosubStack[b_gosubSP++]=110; goto b_L2500;
b_ret110: ;
		/* line 2314 */
b_L2314: ;
		b_v_gii=((b_v_gii)+((1)));
		if(-((b_v_gii) < (b_v_mci))){
			goto b_L2313;
		}
		/* line 2315 */
b_L2315: ;
		goto b_return;
		/* line 2400 */
b_L2400: ;
		/* line 2401 */
b_L2401: ;
		b_v_xks=b_keep(b_a_cts[(bint_t)(b_v_obf)]);
		/* line 2402 */
b_L2402: ;
		b_v_xai=(0);
		b_fl_4=((b_v_mci)-((2)));
		if(b_v_xai > b_fl_4) goto b_f4_e;
b_f4_t: ;
		/* line 2403 */
b_L2403: ;
		b_v_xbi=((b_v_xai)+((1)));
		b_fl_5=((b_v_mci)-((1)));
		if(b_v_xbi > b_fl_5) goto b_f5_e;
b_f5_t: ;
		/* line 2404 */
b_L2404: ;
		b_v_xhi=b_a_ixi[B_INT(b_v_xai)];
		b_v_xii=b_a_ixi[B_INT(b_v_xbi)];
		b_v_xei=(0);
		/* line 2405 */
b_L2405: ;
		if(-(b_strcmp(b_v_xks,b_lit("S",1)) == 0)){
			goto b_L2410;
		}
		/* line 2406 */
b_L2406: ;
		b_v_xcf=b_a_rvf[(B_INT(b_v_xhi))*8+((bint_t)(b_v_obf))];
		b_v_xdf=b_a_rvf[(B_INT(b_v_xii))*8+((bint_t)(b_v_obf))];
		/* line 2407 */
b_L2407: ;
		if(-((b_v_odi) == ((1)))){
			if(-((b_v_xdf) > (b_v_xcf))){
				b_v_xei=(1);
			}
		}
		/* line 2408 */
b_L2408: ;
		if(-((b_v_odi) == ((0)))){
			if(-((b_v_xdf) < (b_v_xcf))){
				b_v_xei=(1);
			}
		}
		/* line 2409 */
b_L2409: ;
		goto b_L2413;
		/* line 2410 */
b_L2410: ;
		b_v_yas=b_keep(b_a_rvs[(B_INT(b_v_xhi))*8+((bint_t)(b_v_obf))]);
		b_v_ybs=b_keep(b_a_rvs[(B_INT(b_v_xii))*8+((bint_t)(b_v_obf))]);
		/* line 2411 */
b_L2411: ;
		if(-((b_v_odi) == ((1)))){
			if(-(b_strcmp(b_v_ybs,b_v_yas) > 0)){
				b_v_xei=(1);
			}
		}
		/* line 2412 */
b_L2412: ;
		if(-((b_v_odi) == ((0)))){
			if(-(b_strcmp(b_v_ybs,b_v_yas) < 0)){
				b_v_xei=(1);
			}
		}
		/* line 2413 */
b_L2413: ;
		if(-((b_v_xei) == ((1)))){
			b_a_ixi[B_INT(b_v_xai)]=b_v_xii;
			b_a_ixi[B_INT(b_v_xbi)]=b_v_xhi;
		}
		/* line 2414 */
b_L2414: ;
		b_v_xbi += 1;
		if(b_v_xbi <= (b_fl_5)) goto b_f5_t;
b_f5_e: ;
		/* line 2415 */
b_L2415: ;
		b_v_xai += 1;
		if(b_v_xai <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 2416 */
b_L2416: ;
		goto b_return;
		/* line 2500 */
b_L2500: ;
		/* line 2501 */
b_L2501: ;
		if(-((b_v_ali) == ((1)))){
			goto b_L2504;
		}
		/* line 2502 */
b_L2502: ;
		b_v_acf=(0);
		b_v_kf=(0);
		b_fl_6=((b_v_pji)-((1)));
		if(b_v_kf > b_fl_6) goto b_f6_e;
b_f6_t: ;
		b_v_nas=b_keep(b_a_pjs[(bint_t)(b_v_kf)]);
		b_gosubStack[b_gosubSP++]=111; goto b_L3000;
b_ret111: ;
		if(-((b_v_cif) >= ((0)))){
			b_gosubStack[b_gosubSP++]=112; goto b_L3100;
b_ret112: ;
			b_v_acf=((b_v_acf)+((1)));
		}
		/* line 2503 */
b_L2503: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_6)) goto b_f6_t;
b_f6_e: ;
		goto b_L2507;
		/* line 2504 */
b_L2504: ;
		b_v_kf=(0);
		b_fl_7=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_7) goto b_f7_e;
b_f7_t: ;
		b_a_ats[(bint_t)(b_v_kf)]=b_keep(b_a_cts[(bint_t)(b_v_kf)]);
		/* line 2505 */
b_L2505: ;
		b_a_as[(bint_t)(b_v_kf)]=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]);
		b_a_af[(bint_t)(b_v_kf)]=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))];
		/* line 2506 */
b_L2506: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_7)) goto b_f7_t;
b_f7_e: ;
		b_v_acf=b_v_ccf;
		/* line 2507 */
b_L2507: ;
		b_gosubStack[b_gosubSP++]=113; goto b_L2800;
b_ret113: ;
		b_putc(30);
		{ bstr_t _t=b_v_css; b_str(_t.p,_t.len); }
		b_putc(5);
		b_nl();
		goto b_return;
		/* line 2600 */
b_L2600: ;
		if(-(b_strcmp(b_v_wcs,b_lit("",0)) == 0)){
			b_v_wmi=(1);
			goto b_return;
		}
		/* line 2601 */
b_L2601: ;
		b_v_nas=b_keep(b_v_wcs);
		b_gosubStack[b_gosubSP++]=114; goto b_L3000;
b_ret114: ;
		if(-((b_v_cif) < ((0)))){
			b_v_wmi=(0);
			goto b_return;
		}
		/* line 2602 */
b_L2602: ;
		b_v_vas=b_keep(b_a_fs[(bint_t)(b_v_cif)]);
		b_v_vaf=b_a_ff[(bint_t)(b_v_cif)];
		/* line 2603 */
b_L2603: ;
		b_gosubStack[b_gosubSP++]=115; goto b_L2700;
b_ret115: ;
		b_v_wmi=b_v_mi;
		goto b_return;
		/* line 2700 */
b_L2700: ;
		/* line 2701 */
b_L2701: ;
		b_v_mi=(0);
		/* line 2702 */
b_L2702: ;
		if(-((b_v_wsi) == ((1)))){
			goto b_L2710;
		}
		/* line 2703 */
b_L2703: ;
		if(-(b_strcmp(b_v_wos,b_lit("=",1)) == 0)){
			if(-((b_v_vaf) == (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2704 */
b_L2704: ;
		if(-(b_strcmp(b_v_wos,b_lit("<",1)) == 0)){
			if(-((b_v_vaf) < (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2705 */
b_L2705: ;
		if(-(b_strcmp(b_v_wos,b_lit(">",1)) == 0)){
			if(-((b_v_vaf) > (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2706 */
b_L2706: ;
		if(-(b_strcmp(b_v_wos,b_lit("<=",2)) == 0)){
			if(-((b_v_vaf) <= (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2707 */
b_L2707: ;
		if(-(b_strcmp(b_v_wos,b_lit(">=",2)) == 0)){
			if(-((b_v_vaf) >= (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2708 */
b_L2708: ;
		if(-(b_strcmp(b_v_wos,b_lit("!=",2)) == 0)){
			if(-((b_v_vaf) != (b_v_wvf))){
				b_v_mi=(1);
			}
		}
		/* line 2709 */
b_L2709: ;
		goto b_return;
		/* line 2710 */
b_L2710: ;
		if(-(b_strcmp(b_v_wos,b_lit("=",1)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) == 0)){
				b_v_mi=(1);
			}
		}
		/* line 2711 */
b_L2711: ;
		if(-(b_strcmp(b_v_wos,b_lit("<",1)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) < 0)){
				b_v_mi=(1);
			}
		}
		/* line 2712 */
b_L2712: ;
		if(-(b_strcmp(b_v_wos,b_lit(">",1)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) > 0)){
				b_v_mi=(1);
			}
		}
		/* line 2713 */
b_L2713: ;
		if(-(b_strcmp(b_v_wos,b_lit("<=",2)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) <= 0)){
				b_v_mi=(1);
			}
		}
		/* line 2714 */
b_L2714: ;
		if(-(b_strcmp(b_v_wos,b_lit(">=",2)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) >= 0)){
				b_v_mi=(1);
			}
		}
		/* line 2715 */
b_L2715: ;
		if(-(b_strcmp(b_v_wos,b_lit("!=",2)) == 0)){
			if(-(b_strcmp(b_v_vas,b_v_wvs) != 0)){
				b_v_mi=(1);
			}
		}
		/* line 2716 */
b_L2716: ;
		goto b_return;
		/* line 2800 */
b_L2800: ;
		/* line 2801 */
b_L2801: ;
		b_v_css=b_keep(b_lit("",0));
		/* line 2802 */
b_L2802: ;
		if(-((b_v_acf) == ((0)))){
			goto b_return;
		}
		/* line 2803 */
b_L2803: ;
		b_v_if=(0);
		b_fl_8=((b_v_acf)-((1)));
		if(b_v_if > b_fl_8) goto b_f8_e;
b_f8_t: ;
		/* line 2804 */
b_L2804: ;
		if(-((b_v_if) > ((0)))){
			b_v_css=b_keep(b_concat(b_v_css,b_lit(",",1)));
		}
		/* line 2805 */
b_L2805: ;
		if(-(b_strcmp(b_a_ats[(bint_t)(b_v_if)],b_lit("S",1)) == 0)){
			b_v_css=b_keep(b_concat(b_v_css,b_a_as[(bint_t)(b_v_if)]));
			goto b_L2807;
		}
		/* line 2806 */
b_L2806: ;
		b_v_nf=b_a_af[(bint_t)(b_v_if)];
		b_gosubStack[b_gosubSP++]=116; goto b_L2900;
b_ret116: ;
		b_v_css=b_keep(b_concat(b_v_css,b_v_nss));
		/* line 2807 */
b_L2807: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		/* line 2808 */
b_L2808: ;
		goto b_return;
		/* line 2900 */
b_L2900: ;
		/* line 2901 */
b_L2901: ;
		b_v_nss=b_keep(b_strs(b_v_nf));
		if(-((b_v_nf) >= ((0)))){
			b_v_nss=b_keep(b_mid(b_v_nss,B_INT((2)),32767));
		}
		/* line 2902 */
b_L2902: ;
		goto b_return;
		/* line 3000 */
b_L3000: ;
		/* line 3001 */
b_L3001: ;
		b_v_cif=(-1);
		/* line 3002 */
b_L3002: ;
		b_v_if=(0);
		b_fl_9=((b_v_ccf)-((1)));
		if(b_v_if > b_fl_9) goto b_f9_e;
b_f9_t: ;
		/* line 3003 */
b_L3003: ;
		if(-(b_strcmp(b_a_cls[(bint_t)(b_v_if)],b_v_nas) == 0)){
			b_v_cif=b_v_if;
			b_v_if=b_v_ccf;
		}
		/* line 3004 */
b_L3004: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_9)) goto b_f9_t;
b_f9_e: ;
		/* line 3005 */
b_L3005: ;
		goto b_return;
		/* line 3006 */
b_L3006: ;
		/* line 3007 */
b_L3007: ;
		b_a_ats[(bint_t)(b_v_acf)]=b_keep(b_a_cts[(bint_t)(b_v_cif)]);
		b_a_as[(bint_t)(b_v_acf)]=b_keep(b_a_fs[(bint_t)(b_v_cif)]);
		b_a_af[(bint_t)(b_v_acf)]=b_a_ff[(bint_t)(b_v_cif)];
		/* line 3008 */
b_L3008: ;
		goto b_return;
		/* line 3100 */
b_L3100: ;
		/* line 3101 */
b_L3101: ;
		b_a_ats[(bint_t)(b_v_acf)]=b_keep(b_a_cts[(bint_t)(b_v_cif)]);
		b_a_as[(bint_t)(b_v_acf)]=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_cif))]);
		b_a_af[(bint_t)(b_v_acf)]=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_cif))];
		/* line 3102 */
b_L3102: ;
		goto b_return;
		/* line 3200 */
b_L3200: ;
		/* line 3201 */
b_L3201: ;
		b_gosubStack[b_gosubSP++]=117; goto b_L3600;
b_ret117: ;
		/* line 3202 */
b_L3202: ;
		if(-((b_v_rci) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 3203 */
b_L3203: ;
		b_v_nas=b_keep(b_v_sts);
		b_gosubStack[b_gosubSP++]=118; goto b_L3000;
b_ret118: ;
		if(-((b_v_cif) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO COL ",7); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_sts; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 3204 */
b_L3204: ;
		b_v_sif=b_v_cif;
		/* line 3205 */
b_L3205: ;
		b_v_ri=(0);
		b_fl_10=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_10) goto b_f10_e;
b_f10_t: ;
		/* line 3206 */
b_L3206: ;
		b_gosubStack[b_gosubSP++]=119; goto b_L3300;
b_ret119: ;
		/* line 3207 */
b_L3207: ;
		if(-((b_v_wmi) == ((0)))){
			goto b_L3209;
		}
		/* line 3208 */
b_L3208: ;
		b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_sif))]=b_keep(b_v_svs);
		b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_sif))]=b_v_svf;
		/* line 3209 */
b_L3209: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_10)) goto b_f10_t;
b_f10_e: ;
		/* line 3210 */
b_L3210: ;
		b_gosubStack[b_gosubSP++]=120; goto b_L3700;
b_ret120: ;
		/* line 3211 */
b_L3211: ;
		goto b_return;
		/* line 3300 */
b_L3300: ;
		/* line 3301 */
b_L3301: ;
		if(-(b_strcmp(b_v_wcs,b_lit("",0)) == 0)){
			b_v_wmi=(1);
			goto b_return;
		}
		/* line 3302 */
b_L3302: ;
		b_v_nas=b_keep(b_v_wcs);
		b_gosubStack[b_gosubSP++]=121; goto b_L3000;
b_ret121: ;
		if(-((b_v_cif) < ((0)))){
			b_v_wmi=(0);
			goto b_return;
		}
		/* line 3303 */
b_L3303: ;
		b_v_vas=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_cif))]);
		b_v_vaf=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_cif))];
		/* line 3304 */
b_L3304: ;
		b_gosubStack[b_gosubSP++]=122; goto b_L2700;
b_ret122: ;
		b_v_wmi=b_v_mi;
		goto b_return;
		/* line 3400 */
b_L3400: ;
		/* line 3401 */
b_L3401: ;
		b_gosubStack[b_gosubSP++]=123; goto b_L3600;
b_ret123: ;
		/* line 3402 */
b_L3402: ;
		if(-((b_v_rci) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 3403 */
b_L3403: ;
		b_v_wri=(0);
		/* line 3404 */
b_L3404: ;
		b_v_ri=(0);
		b_fl_11=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_11) goto b_f11_e;
b_f11_t: ;
		/* line 3405 */
b_L3405: ;
		b_gosubStack[b_gosubSP++]=124; goto b_L3300;
b_ret124: ;
		/* line 3406 */
b_L3406: ;
		if(-((b_v_wmi) == ((1)))){
			goto b_L3408;
		}
		/* line 3407 */
b_L3407: ;
		b_v_kf=(0);
		b_fl_12=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_12) goto b_f12_e;
b_f12_t: ;
		b_a_rvf[(B_INT(b_v_wri))*8+((bint_t)(b_v_kf))]=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))];
		b_a_rvs[(B_INT(b_v_wri))*8+((bint_t)(b_v_kf))]=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_12)) goto b_f12_t;
b_f12_e: ;
		b_v_wri=((b_v_wri)+((1)));
		/* line 3408 */
b_L3408: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_11)) goto b_f11_t;
b_f11_e: ;
		/* line 3409 */
b_L3409: ;
		b_v_rci=b_v_wri;
		b_gosubStack[b_gosubSP++]=125; goto b_L3700;
b_ret125: ;
		/* line 3410 */
b_L3410: ;
		goto b_return;
		/* line 3500 */
b_L3500: ;
		/* line 3501 */
b_L3501: ;
		b_v_bci=(0);
		if(-((b_v_dki) == ((0)))){ goto b_L3508; }
		/* line 3502 */
b_L3502: ;
		b_open((1),(8),(2),b_concat(b_v_tns,b_lit(",R",2)));
		/* line 3503 */
b_L3503: ;
		if(-((B_INT(b_peek((unsigned int)((144))))) != ((0)))){
			b_close((1));
			goto b_return;
		}
		/* line 3504 */
b_L3504: ;
		b_v_gcs=b_keep(b_chr(b_geth((1))));
		/* line 3505 */
b_L3505: ;
		if(-((B_INT(b_peek((unsigned int)((144))))) != ((0)))){
			goto b_L3508;
		}
		/* line 3506 */
b_L3506: ;
		b_poke(((b_v_bai)+(b_v_bci)),b_asc(b_concat(b_v_gcs,b_lit("\000",1))));
		b_v_bci=((b_v_bci)+((1)));
		/* line 3507 */
b_L3507: ;
		goto b_L3504;
		/* line 3508 */
b_L3508: ;
		b_close((1));
		goto b_return;
		/* line 3600 */
b_L3600: ;
		/* line 3601 */
b_L3601: ;
		b_gosubStack[b_gosubSP++]=126; goto b_L3500;
b_ret126: ;
		/* line 3602 */
b_L3602: ;
		if(-((b_v_bci) > ((0)))){
			goto b_L3605;
		}
		/* line 3603 */
b_L3603: ;
		if(-((b_v_ccf) == ((0)))){
			b_v_rci=(-1);
		}
		/* line 3604 */
b_L3604: ;
		goto b_return;
		/* line 3605 */
b_L3605: ;
		b_v_bpf=(0);
		b_gosubStack[b_gosubSP++]=127; goto b_L4300;
b_ret127: ;
		if(-((b_v_lei) == ((0)))){
			b_v_ccf=(0);
			b_v_rci=(-1);
			goto b_return;
		}
		/* line 3606 */
b_L3606: ;
		b_gosubStack[b_gosubSP++]=128; goto b_L3900;
b_ret128: ;
		b_v_ccf=b_val(b_a_sls[B_INT((0))]);
		/* line 3607 */
b_L3607: ;
		b_v_kf=(0);
		b_fl_13=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_13) goto b_f13_e;
b_f13_t: ;
		b_a_cls[(bint_t)(b_v_kf)]=b_keep(b_a_sls[(bint_t)(((b_v_kf)+((1))))]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_13)) goto b_f13_t;
b_f13_e: ;
		/* line 3608 */
b_L3608: ;
		b_v_kf=(0);
		b_fl_14=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_14) goto b_f14_e;
b_f14_t: ;
		b_a_cts[(bint_t)(b_v_kf)]=b_keep(b_a_sls[(bint_t)(((((b_v_kf)+((1))))+(b_v_ccf)))]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_14)) goto b_f14_t;
b_f14_e: ;
		/* line 3609 */
b_L3609: ;
		b_v_rci=(0);
		/* line 3610 */
b_L3610: ;
		b_gosubStack[b_gosubSP++]=129; goto b_L4300;
b_ret129: ;
		if(-((b_v_lei) == ((0)))){
			goto b_return;
		}
		/* line 3611 */
b_L3611: ;
		b_gosubStack[b_gosubSP++]=130; goto b_L3900;
b_ret130: ;
		/* line 3612 */
b_L3612: ;
		b_v_kf=(0);
		b_fl_15=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_15) goto b_f15_e;
b_f15_t: ;
		/* line 3613 */
b_L3613: ;
		if(-(b_strcmp(b_a_cts[(bint_t)(b_v_kf)],b_lit("S",1)) == 0)){
			b_a_rvs[(B_INT(b_v_rci))*8+((bint_t)(b_v_kf))]=b_keep(b_a_sls[(bint_t)(b_v_kf)]);
			goto b_L3615;
		}
		/* line 3614 */
b_L3614: ;
		b_a_rvf[(B_INT(b_v_rci))*8+((bint_t)(b_v_kf))]=b_val(b_a_sls[(bint_t)(b_v_kf)]);
		/* line 3615 */
b_L3615: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_15)) goto b_f15_t;
b_f15_e: ;
		/* line 3616 */
b_L3616: ;
		b_v_rci=((b_v_rci)+((1)));
		goto b_L3610;
		/* line 3650 */
b_L3650: ;
		/* line 3651 */
b_L3651: ;
		if(-((b_v_dki) == ((0)))){
			goto b_return;
		}
		/* line 3652 */
b_L3652: ;
		b_open((15),(8),(15),b_concat(b_lit("S0:",3),b_v_tns));
		/* line 3653 */
b_L3653: ;
		b_close((15));
		goto b_return;
		/* line 3700 */
b_L3700: ;
		/* line 3701 */
b_L3701: ;
		if(-((b_v_dki) == ((0)))){
			goto b_return;
		}
		/* line 3702 */
b_L3702: ;
		b_gosubStack[b_gosubSP++]=131; goto b_L3650;
b_ret131: ;
		b_open((1),(8),(2),b_concat(b_v_tns,b_lit(",S,W",4)));
		/* line 3703 */
b_L3703: ;
		b_v_nf=b_v_ccf;
		b_gosubStack[b_gosubSP++]=132; goto b_L2900;
b_ret132: ;
		{ b_chkout((1)); { bstr_t _t=b_v_nss; b_str(_t.p,_t.len); }
			b_clrch(); }
		/* line 3704 */
b_L3704: ;
		if(-((b_v_ccf) > ((0)))){
			b_v_kf=(0);
			b_fl_16=((b_v_ccf)-((1)));
			if(b_v_kf > b_fl_16) goto b_f16_e;
b_f16_t: ;
			{ b_chkout((1)); b_putc(44);
				{ bstr_t _t=b_a_cls[(bint_t)(b_v_kf)]; b_str(_t.p,_t.len); }
				b_clrch(); }
			b_v_kf += 1;
			if(b_v_kf <= (b_fl_16)) goto b_f16_t;
b_f16_e: ;
		}
		/* line 3705 */
b_L3705: ;
		if(-((b_v_ccf) > ((0)))){
			b_v_kf=(0);
			b_fl_17=((b_v_ccf)-((1)));
			if(b_v_kf > b_fl_17) goto b_f17_e;
b_f17_t: ;
			{ b_chkout((1)); b_putc(44);
				{ bstr_t _t=b_a_cts[(bint_t)(b_v_kf)]; b_str(_t.p,_t.len); }
				b_clrch(); }
			b_v_kf += 1;
			if(b_v_kf <= (b_fl_17)) goto b_f17_t;
b_f17_e: ;
		}
		/* line 3706 */
b_L3706: ;
		{ b_chkout((1)); b_nl();
			b_clrch(); }
		/* line 3707 */
b_L3707: ;
		if(-((b_v_rci) <= ((0)))){ goto b_L3716; }
		/* line 3708 */
b_L3708: ;
		b_v_ri=(0);
		b_fl_18=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_18) goto b_f18_e;
b_f18_t: ;
		/* line 3709 */
b_L3709: ;
		b_v_kf=(0);
		b_fl_19=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_19) goto b_f19_e;
b_f19_t: ;
		/* line 3710 */
b_L3710: ;
		if(-((b_v_kf) > ((0)))){
			{ b_chkout((1)); b_putc(44);
				b_clrch(); }
		}
		/* line 3711 */
b_L3711: ;
		if(-(b_strcmp(b_a_cts[(bint_t)(b_v_kf)],b_lit("S",1)) == 0)){
			{ b_chkout((1)); { bstr_t _t=b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]; b_str(_t.p,_t.len); }
				b_clrch(); }
			goto b_L3713;
		}
		/* line 3712 */
b_L3712: ;
		b_v_nf=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))];
		b_gosubStack[b_gosubSP++]=133; goto b_L2900;
b_ret133: ;
		{ b_chkout((1)); { bstr_t _t=b_v_nss; b_str(_t.p,_t.len); }
			b_clrch(); }
		/* line 3713 */
b_L3713: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_19)) goto b_f19_t;
b_f19_e: ;
		/* line 3714 */
b_L3714: ;
		{ b_chkout((1)); b_nl();
			b_clrch(); }
		/* line 3715 */
b_L3715: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_18)) goto b_f18_t;
b_f18_e: ;
		/* line 3716 */
b_L3716: ;
		b_close((1));
		goto b_return;
		/* line 3800 */
b_L3800: ;
		/* line 3801 */
b_L3801: ;
		b_gosubStack[b_gosubSP++]=134; goto b_L3900;
b_ret134: ;
		/* line 3802 */
b_L3802: ;
		b_v_kf=(0);
		b_fl_20=((b_v_sci)-((1)));
		if(b_v_kf > b_fl_20) goto b_f20_e;
b_f20_t: ;
		b_a_fs[(bint_t)(b_v_kf)]=b_keep(b_a_sls[(bint_t)(b_v_kf)]);
		b_a_ff[(bint_t)(b_v_kf)]=b_val(b_a_sls[(bint_t)(b_v_kf)]);
		/* line 3803 */
b_L3803: ;
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_20)) goto b_f20_t;
b_f20_e: ;
		b_v_fci=b_v_sci;
		goto b_return;
		/* line 3900 */
b_L3900: ;
		/* line 3901 */
b_L3901: ;
		b_v_sci=(0);
		b_v_kf=(1);
		b_v_lnf=b_v_lwf;
		/* line 3902 */
b_L3902: ;
		if(-((b_v_kf) > (b_v_lnf))){
			goto b_return;
		}
		/* line 3903 */
b_L3903: ;
		b_v_jf=b_v_kf;
		/* line 3904 */
b_L3904: ;
		if(-((b_v_jf) > (b_v_lnf))){
			goto b_L3907;
		}
		/* line 3905 */
b_L3905: ;
		if(-((B_INT(b_peek((unsigned int)(((((((b_v_bai)+(b_v_lzf)))+(b_v_jf)))-((1))))))) != ((44)))){
			b_v_jf=((b_v_jf)+((1)));
			goto b_L3904;
		}
		/* line 3906 */
b_L3906: ;
		b_v_fkf=((((b_v_lzf)+(b_v_kf)))-((1)));
		b_v_fjf=((((b_v_lzf)+(b_v_jf)))-((1)));
		b_gosubStack[b_gosubSP++]=135; goto b_L4000;
b_ret135: ;
		b_v_sci=((b_v_sci)+((1)));
		b_v_kf=((b_v_jf)+((1)));
		goto b_L3902;
		/* line 3907 */
b_L3907: ;
		b_v_fkf=((((b_v_lzf)+(b_v_kf)))-((1)));
		b_v_fjf=((b_v_lzf)+(b_v_lnf));
		b_gosubStack[b_gosubSP++]=136; goto b_L4000;
b_ret136: ;
		b_v_sci=((b_v_sci)+((1)));
		goto b_return;
		/* line 4000 */
b_L4000: ;
		/* line 4001 */
b_L4001: ;
		b_v_zss=b_keep(b_lit("",0));
		b_v_zpf=b_v_fkf;
		/* line 4002 */
b_L4002: ;
		if(-((b_v_zpf) >= (b_v_fjf))){
			b_a_sls[B_INT(b_v_sci)]=b_keep(b_v_zss);
			goto b_return;
		}
		/* line 4003 */
b_L4003: ;
		b_v_zss=b_keep(b_concat(b_v_zss,b_chr(B_INT(B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_zpf)))))))));
		b_v_zpf=((b_v_zpf)+((1)));
		goto b_L4002;
		/* line 4100 */
b_L4100: ;
		/* line 4101 */
b_L4101: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_return;
		}
		/* line 4102 */
b_L4102: ;
		if(-((b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))))) == ((32)))){
			b_v_spf=((b_v_spf)+((1)));
			goto b_L4100;
		}
		/* line 4103 */
b_L4103: ;
		goto b_return;
		/* line 4200 */
b_L4200: ;
		/* line 4201 */
b_L4201: ;
		b_v_wds=b_keep(b_lit("",0));
		/* line 4202 */
b_L4202: ;
		if(-((b_v_spf) > (b_v_lsi))){
			goto b_return;
		}
		/* line 4203 */
b_L4203: ;
		b_v_ci=b_asc(b_mid(b_v_sqs,(bint_t)(b_v_spf),B_INT((1))));
		/* line 4204 */
b_L4204: ;
		if((B_INT((B_INT((B_INT(-((b_v_ci) >= ((65)))) & B_INT(-((b_v_ci) <= ((90)))))) | B_INT((B_INT(-((b_v_ci) >= ((48)))) & B_INT(-((b_v_ci) <= ((57)))))))) | B_INT(-((b_v_ci) == ((95)))))){
			b_v_wds=b_keep(b_concat(b_v_wds,b_chr(B_INT(b_v_ci))));
			b_v_spf=((b_v_spf)+((1)));
			goto b_L4202;
		}
		/* line 4205 */
b_L4205: ;
		if((B_INT(-((b_v_ci) >= ((97)))) & B_INT(-((b_v_ci) <= ((122)))))){
			b_v_wds=b_keep(b_concat(b_v_wds,b_chr(B_INT(((b_v_ci)-((32)))))));
			b_v_spf=((b_v_spf)+((1)));
			goto b_L4202;
		}
		/* line 4206 */
b_L4206: ;
		goto b_return;
		/* line 4300 */
b_L4300: ;
		/* line 4301 */
b_L4301: ;
		b_v_lei=(0);
		b_v_lzf=b_v_bpf;
		b_v_lwf=(0);
		/* line 4302 */
b_L4302: ;
		if(-((b_v_bpf) >= (b_v_bci))){
			goto b_L4306;
		}
		/* line 4303 */
b_L4303: ;
		b_v_ci=B_INT(b_peek((unsigned int)(((b_v_bai)+(b_v_bpf)))));
		/* line 4304 */
b_L4304: ;
		if(-((b_v_ci) == ((13)))){
			b_v_lei=(1);
			b_v_bpf=((b_v_bpf)+((1)));
			goto b_return;
		}
		/* line 4305 */
b_L4305: ;
		b_v_bpf=((b_v_bpf)+((1)));
		b_v_lwf=((b_v_lwf)+((1)));
		goto b_L4302;
		/* line 4306 */
b_L4306: ;
		if(-((b_v_lwf) > ((0)))){
			b_v_lei=(1);
		}
		/* line 4307 */
b_L4307: ;
		goto b_return;
		/* line 4400 */
b_L4400: ;
		/* line 4401 */
b_L4401: ;
		goto b_return;
		/* line 4500 */
b_L4500: ;
		/* line 4501 */
b_L4501: ;
		/* line 4502 */
b_L4502: ;
		/* line 4503 */
b_L4503: ;
		/* line 4504 */
b_L4504: ;
		/* line 4505 */
b_L4505: ;
		/* line 4506 */
b_L4506: ;
		/* line 4507 */
b_L4507: ;
		/* line 4508 */
b_L4508: ;
		/* line 4509 */
b_L4509: ;
		/* line 4510 */
b_L4510: ;
		/* line 4511 */
b_L4511: ;
		/* line 4512 */
b_L4512: ;
		/* line 4513 */
b_L4513: ;
		/* line 4600 */
b_L4600: ;
		/* line 4601 */
b_L4601: ;
		/* line 4602 */
b_L4602: ;
		/* line 4603 */
b_L4603: ;
		/* line 4604 */
b_L4604: ;
		/* line 4605 */
b_L4605: ;
		/* line 4606 */
b_L4606: ;
		/* line 4607 */
b_L4607: ;
		/* line 4608 */
b_L4608: ;
		/* line 4700 */
b_L4700: ;
		/* line 4701 */
b_L4701: ;
		/* line 4702 */
b_L4702: ;
		/* line 4703 */
b_L4703: ;
		/* line 4704 */
b_L4704: ;
		/* line 4705 */
b_L4705: ;
		/* line 4706 */
b_L4706: ;
		/* line 4707 */
b_L4707: ;
		/* line 4708 */
b_L4708: ;
		/* line 4709 */
b_L4709: ;
		/* line 4800 */
b_L4800: ;
		/* line 4900 */
b_L4900: ;
		/* line 4901 */
b_L4901: ;
		b_putc(28);
		{ bstr_t _t=b_lit("SQL ERR: ",9); b_str(_t.p,_t.len); }
		{ bstr_t _t=b_v_sqs; b_str(_t.p,_t.len); }
		b_putc(5);
		b_nl();
		/* line 4902 */
b_L4902: ;
		goto b_return;
		/* line 5000 */
b_L5000: ;
		/* line 5001 */
b_L5001: ;
		b_nl();
		{ bstr_t _t=b_lit("SQL - TYPE A QUERY; 'EXIT' TO QUIT",34); b_str(_t.p,_t.len); }
		b_nl();
		/* line 5002 */
b_L5002: ;
		{ bstr_t _t=b_lit("SQL> ",5); b_str(_t.p,_t.len); }
		/* line 5003 */
b_L5003: ;
		b_gosubStack[b_gosubSP++]=137; goto b_L5100;
b_ret137: ;
		/* line 5004 */
b_L5004: ;
		if(-(b_strcmp(b_v_sqs,b_lit("EXIT",4)) == 0)){
			goto b_end;
		}
		/* line 5005 */
b_L5005: ;
		if(-(b_strcmp(b_v_sqs,b_lit("",0)) == 0)){
			goto b_L5002;
		}
		/* line 5006 */
b_L5006: ;
		b_gosubStack[b_gosubSP++]=138; goto b_L1000;
b_ret138: ;
		/* line 5007 */
b_L5007: ;
		goto b_L5002;
		/* line 5100 */
b_L5100: ;
		/* line 5101 */
b_L5101: ;
		b_v_sqs=b_keep(b_lit("",0));
		/* line 5102 */
b_L5102: ;
		{ int _g=b_getin(); if(_g<0) b_v_gcs=b_lit("",0); else b_v_gcs=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_gcs,b_lit("",0)) == 0)){
			goto b_L5102;
		}
		/* line 5103 */
b_L5103: ;
		if(-(b_strcmp(b_v_gcs,b_lit("\r",1)) == 0)){
			b_nl();
			goto b_return;
		}
		/* line 5104 */
b_L5104: ;
		if(-(b_strcmp(b_v_gcs,b_lit("\024",1)) == 0)){
			b_gosubStack[b_gosubSP++]=139; goto b_L5200;
b_ret139: ;
			goto b_L5102;
		}
		/* line 5105 */
b_L5105: ;
		{ bstr_t _t=b_v_gcs; b_str(_t.p,_t.len); }
		b_v_sqs=b_keep(b_concat(b_v_sqs,b_v_gcs));
		goto b_L5102;
		/* line 5200 */
b_L5200: ;
		/* line 5201 */
b_L5201: ;
		if(-((B_INT(b_len(b_v_sqs))) == ((0)))){
			goto b_return;
		}
		/* line 5202 */
b_L5202: ;
		b_v_sqs=b_keep(b_left(b_v_sqs,B_INT(((B_INT(b_len(b_v_sqs)))-((1))))));
		/* line 5203 */
b_L5203: ;
		b_putc(20);
		goto b_return;
		/* line 5300 */
b_L5300: ;
		/* line 5301 */
b_L5301: ;
		b_gosubStack[b_gosubSP++]=140; goto b_L4100;
b_ret140: ;
		b_gosubStack[b_gosubSP++]=141; goto b_L4200;
b_ret141: ;
		if(-(b_strcmp(b_v_wds,b_lit("TABLE",5)) != 0)){
			b_gosubStack[b_gosubSP++]=142; goto b_L4900;
b_ret142: ;
			goto b_return;
		}
		/* line 5302 */
b_L5302: ;
		b_gosubStack[b_gosubSP++]=143; goto b_L4100;
b_ret143: ;
		b_gosubStack[b_gosubSP++]=144; goto b_L4200;
b_ret144: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 5303 */
b_L5303: ;
		b_v_rci=(0);
		b_v_ccf=(0);
		b_v_cpi=(0);
		b_gosubStack[b_gosubSP++]=145; goto b_L3700;
b_ret145: ;
		goto b_return;
		/* line 5400 */
b_L5400: ;
		/* line 5401 */
b_L5401: ;
		b_gosubStack[b_gosubSP++]=146; goto b_L4100;
b_ret146: ;
		b_gosubStack[b_gosubSP++]=147; goto b_L4200;
b_ret147: ;
		if(-(b_strcmp(b_v_wds,b_lit("TABLE",5)) != 0)){
			b_gosubStack[b_gosubSP++]=148; goto b_L4900;
b_ret148: ;
			goto b_return;
		}
		/* line 5402 */
b_L5402: ;
		b_gosubStack[b_gosubSP++]=149; goto b_L4100;
b_ret149: ;
		b_gosubStack[b_gosubSP++]=150; goto b_L4200;
b_ret150: ;
		b_v_tns=b_keep(b_v_wds);
		/* line 5403 */
b_L5403: ;
		b_gosubStack[b_gosubSP++]=151; goto b_L4100;
b_ret151: ;
		b_gosubStack[b_gosubSP++]=152; goto b_L4200;
b_ret152: ;
		b_v_aks=b_keep(b_v_wds);
		/* line 5404 */
b_L5404: ;
		if(-(b_strcmp(b_v_aks,b_lit("ADD",3)) == 0)){
			b_gosubStack[b_gosubSP++]=153; goto b_L5500;
b_ret153: ;
			goto b_return;
		}
		/* line 5405 */
b_L5405: ;
		if(-(b_strcmp(b_v_aks,b_lit("DROP",4)) == 0)){
			b_gosubStack[b_gosubSP++]=154; goto b_L5600;
b_ret154: ;
			goto b_return;
		}
		/* line 5406 */
b_L5406: ;
		if(-(b_strcmp(b_v_aks,b_lit("RENAME",6)) == 0)){
			b_gosubStack[b_gosubSP++]=155; goto b_L5700;
b_ret155: ;
			goto b_return;
		}
		/* line 5407 */
b_L5407: ;
		b_gosubStack[b_gosubSP++]=156; goto b_L4900;
b_ret156: ;
		goto b_return;
		/* line 5500 */
b_L5500: ;
		/* line 5501 */
b_L5501: ;
		b_gosubStack[b_gosubSP++]=157; goto b_L4100;
b_ret157: ;
		b_gosubStack[b_gosubSP++]=158; goto b_L4200;
b_ret158: ;
		b_v_cns=b_keep(b_v_wds);
		/* line 5502 */
b_L5502: ;
		b_gosubStack[b_gosubSP++]=159; goto b_L3600;
b_ret159: ;
		/* line 5503 */
b_L5503: ;
		if(-((b_v_rci) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 5504 */
b_L5504: ;
		b_a_cls[(bint_t)(b_v_ccf)]=b_keep(b_v_cns);
		b_a_cts[(bint_t)(b_v_ccf)]=b_keep(b_lit("N",1));
		b_v_ccf=((b_v_ccf)+((1)));
		/* line 5505 */
b_L5505: ;
		if(-((b_v_rci) <= ((0)))){
			b_gosubStack[b_gosubSP++]=160; goto b_L3700;
b_ret160: ;
			goto b_return;
		}
		/* line 5506 */
b_L5506: ;
		b_v_ri=(0);
		b_fl_21=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_21) goto b_f21_e;
b_f21_t: ;
		b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(((b_v_ccf)-((1)))))]=(0);
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_21)) goto b_f21_t;
b_f21_e: ;
		/* line 5507 */
b_L5507: ;
		b_gosubStack[b_gosubSP++]=161; goto b_L3700;
b_ret161: ;
		goto b_return;
		/* line 5600 */
b_L5600: ;
		/* line 5601 */
b_L5601: ;
		b_gosubStack[b_gosubSP++]=162; goto b_L4100;
b_ret162: ;
		b_gosubStack[b_gosubSP++]=163; goto b_L4200;
b_ret163: ;
		b_v_cns=b_keep(b_v_wds);
		/* line 5602 */
b_L5602: ;
		b_gosubStack[b_gosubSP++]=164; goto b_L3600;
b_ret164: ;
		/* line 5603 */
b_L5603: ;
		if(-((b_v_rci) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 5604 */
b_L5604: ;
		b_v_nas=b_keep(b_v_cns);
		b_gosubStack[b_gosubSP++]=165; goto b_L3000;
b_ret165: ;
		if(-((b_v_cif) < ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO COL ",7); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_cns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 5605 */
b_L5605: ;
		if(-((b_v_cif) >= (((b_v_ccf)-((1)))))){
			goto b_L5607;
		}
		/* line 5606 */
b_L5606: ;
		b_v_kf=b_v_cif;
		b_fl_22=((b_v_ccf)-((2)));
		if(b_v_kf > b_fl_22) goto b_f22_e;
b_f22_t: ;
		b_a_cls[(bint_t)(b_v_kf)]=b_keep(b_a_cls[(bint_t)(((b_v_kf)+((1))))]);
		b_a_cts[(bint_t)(b_v_kf)]=b_keep(b_a_cts[(bint_t)(((b_v_kf)+((1))))]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_22)) goto b_f22_t;
b_f22_e: ;
		/* line 5607 */
b_L5607: ;
		b_v_ccf=((b_v_ccf)-((1)));
		/* line 5608 */
b_L5608: ;
		if(-((b_v_rci) <= ((0)))){
			b_gosubStack[b_gosubSP++]=166; goto b_L3700;
b_ret166: ;
			goto b_return;
		}
		/* line 5609 */
b_L5609: ;
		if(-((b_v_cif) >= (b_v_ccf))){
			goto b_L5611;
		}
		/* line 5610 */
b_L5610: ;
		b_v_ri=(0);
		b_fl_23=((b_v_rci)-((1)));
		if(b_v_ri > b_fl_23) goto b_f23_e;
b_f23_t: ;
		b_v_kf=b_v_cif;
		b_fl_24=((b_v_ccf)-((1)));
		if(b_v_kf > b_fl_24) goto b_f24_e;
b_f24_t: ;
		b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]=b_a_rvf[(B_INT(b_v_ri))*8+((bint_t)(((b_v_kf)+((1)))))];
		b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(b_v_kf))]=b_keep(b_a_rvs[(B_INT(b_v_ri))*8+((bint_t)(((b_v_kf)+((1)))))]);
		b_v_kf += 1;
		if(b_v_kf <= (b_fl_24)) goto b_f24_t;
b_f24_e: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_23)) goto b_f23_t;
b_f23_e: ;
		/* line 5611 */
b_L5611: ;
		b_gosubStack[b_gosubSP++]=167; goto b_L3700;
b_ret167: ;
		goto b_return;
		/* line 5700 */
b_L5700: ;
		/* line 5701 */
b_L5701: ;
		b_gosubStack[b_gosubSP++]=168; goto b_L4100;
b_ret168: ;
		b_gosubStack[b_gosubSP++]=169; goto b_L4200;
b_ret169: ;
		if(-(b_strcmp(b_v_wds,b_lit("TO",2)) != 0)){
			b_gosubStack[b_gosubSP++]=170; goto b_L4900;
b_ret170: ;
			goto b_return;
		}
		/* line 5702 */
b_L5702: ;
		b_gosubStack[b_gosubSP++]=171; goto b_L4100;
b_ret171: ;
		b_gosubStack[b_gosubSP++]=172; goto b_L4200;
b_ret172: ;
		b_v_nts=b_keep(b_v_wds);
		b_gosubStack[b_gosubSP++]=173; goto b_L3600;
b_ret173: ;
		if(-((b_v_ccf) == ((0)))){
			b_putc(28);
			{ bstr_t _t=b_lit("NO TABLE ",9); b_str(_t.p,_t.len); }
			{ bstr_t _t=b_v_tns; b_str(_t.p,_t.len); }
			b_putc(5);
			b_nl();
			goto b_return;
		}
		/* line 5703 */
b_L5703: ;
		b_v_ots=b_keep(b_v_tns);
		b_v_tns=b_keep(b_v_nts);
		b_gosubStack[b_gosubSP++]=174; goto b_L3700;
b_ret174: ;
		b_v_tns=b_keep(b_v_ots);
		b_v_ccf=(0);
		b_v_rci=(0);
		b_gosubStack[b_gosubSP++]=175; goto b_L3700;
b_ret175: ;
		b_v_tns=b_keep(b_v_nts);
		goto b_return;
		/* line 5705 */
b_L5705: ;
		/* line 5706 */
b_L5706: ;
		b_v_txf=(0);
		b_v_lnf=B_INT(b_len(b_a_sls[(bint_t)(b_v_if)]));
		/* line 5707 */
b_L5707: ;
		b_v_jf=(1);
		b_fl_25=b_v_lnf;
		if(b_v_jf > b_fl_25) goto b_f25_e;
b_f25_t: ;
		if(-(b_strcmp(b_mid(b_a_sls[(bint_t)(b_v_if)],(bint_t)(b_v_jf),B_INT((1))),b_lit(":",1)) == 0)){
			b_v_txf=b_v_jf;
			b_v_jf=b_v_lnf;
		}
		/* line 5708 */
b_L5708: ;
		b_v_jf += 1;
		if(b_v_jf <= (b_fl_25)) goto b_f25_t;
b_f25_e: ;
		/* line 5709 */
b_L5709: ;
		if(-((b_v_txf) == ((0)))){
			b_a_cls[(bint_t)(b_v_if)]=b_keep(b_a_sls[(bint_t)(b_v_if)]);
			b_a_cts[(bint_t)(b_v_if)]=b_keep(b_lit("N",1));
			goto b_return;
		}
		/* line 5710 */
b_L5710: ;
		b_a_cls[(bint_t)(b_v_if)]=b_keep(b_left(b_a_sls[(bint_t)(b_v_if)],(bint_t)(((b_v_txf)-((1))))));
		b_a_cts[(bint_t)(b_v_if)]=b_keep(b_mid(b_a_sls[(bint_t)(b_v_if)],(bint_t)(((b_v_txf)+((1)))),32767));
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			case 15: goto b_ret15;
			case 16: goto b_ret16;
			case 17: goto b_ret17;
			case 18: goto b_ret18;
			case 19: goto b_ret19;
			case 20: goto b_ret20;
			case 21: goto b_ret21;
			case 22: goto b_ret22;
			case 23: goto b_ret23;
			case 24: goto b_ret24;
			case 25: goto b_ret25;
			case 26: goto b_ret26;
			case 27: goto b_ret27;
			case 28: goto b_ret28;
			case 29: goto b_ret29;
			case 30: goto b_ret30;
			case 31: goto b_ret31;
			case 32: goto b_ret32;
			case 33: goto b_ret33;
			case 34: goto b_ret34;
			case 35: goto b_ret35;
			case 36: goto b_ret36;
			case 37: goto b_ret37;
			case 38: goto b_ret38;
			case 39: goto b_ret39;
			case 40: goto b_ret40;
			case 41: goto b_ret41;
			case 42: goto b_ret42;
			case 43: goto b_ret43;
			case 44: goto b_ret44;
			case 45: goto b_ret45;
			case 46: goto b_ret46;
			case 47: goto b_ret47;
			case 48: goto b_ret48;
			case 49: goto b_ret49;
			case 50: goto b_ret50;
			case 51: goto b_ret51;
			case 52: goto b_ret52;
			case 53: goto b_ret53;
			case 54: goto b_ret54;
			case 55: goto b_ret55;
			case 56: goto b_ret56;
			case 57: goto b_ret57;
			case 58: goto b_ret58;
			case 59: goto b_ret59;
			case 60: goto b_ret60;
			case 61: goto b_ret61;
			case 62: goto b_ret62;
			case 63: goto b_ret63;
			case 64: goto b_ret64;
			case 65: goto b_ret65;
			case 66: goto b_ret66;
			case 67: goto b_ret67;
			case 68: goto b_ret68;
			case 69: goto b_ret69;
			case 70: goto b_ret70;
			case 71: goto b_ret71;
			case 72: goto b_ret72;
			case 73: goto b_ret73;
			case 74: goto b_ret74;
			case 75: goto b_ret75;
			case 76: goto b_ret76;
			case 77: goto b_ret77;
			case 78: goto b_ret78;
			case 79: goto b_ret79;
			case 80: goto b_ret80;
			case 81: goto b_ret81;
			case 82: goto b_ret82;
			case 83: goto b_ret83;
			case 84: goto b_ret84;
			case 85: goto b_ret85;
			case 86: goto b_ret86;
			case 87: goto b_ret87;
			case 88: goto b_ret88;
			case 89: goto b_ret89;
			case 90: goto b_ret90;
			case 91: goto b_ret91;
			case 92: goto b_ret92;
			case 93: goto b_ret93;
			case 94: goto b_ret94;
			case 95: goto b_ret95;
			case 96: goto b_ret96;
			case 97: goto b_ret97;
			case 98: goto b_ret98;
			case 99: goto b_ret99;
			case 100: goto b_ret100;
			case 101: goto b_ret101;
			case 102: goto b_ret102;
			case 103: goto b_ret103;
			case 104: goto b_ret104;
			case 105: goto b_ret105;
			case 106: goto b_ret106;
			case 107: goto b_ret107;
			case 108: goto b_ret108;
			case 109: goto b_ret109;
			case 110: goto b_ret110;
			case 111: goto b_ret111;
			case 112: goto b_ret112;
			case 113: goto b_ret113;
			case 114: goto b_ret114;
			case 115: goto b_ret115;
			case 116: goto b_ret116;
			case 117: goto b_ret117;
			case 118: goto b_ret118;
			case 119: goto b_ret119;
			case 120: goto b_ret120;
			case 121: goto b_ret121;
			case 122: goto b_ret122;
			case 123: goto b_ret123;
			case 124: goto b_ret124;
			case 125: goto b_ret125;
			case 126: goto b_ret126;
			case 127: goto b_ret127;
			case 128: goto b_ret128;
			case 129: goto b_ret129;
			case 130: goto b_ret130;
			case 131: goto b_ret131;
			case 132: goto b_ret132;
			case 133: goto b_ret133;
			case 134: goto b_ret134;
			case 135: goto b_ret135;
			case 136: goto b_ret136;
			case 137: goto b_ret137;
			case 138: goto b_ret138;
			case 139: goto b_ret139;
			case 140: goto b_ret140;
			case 141: goto b_ret141;
			case 142: goto b_ret142;
			case 143: goto b_ret143;
			case 144: goto b_ret144;
			case 145: goto b_ret145;
			case 146: goto b_ret146;
			case 147: goto b_ret147;
			case 148: goto b_ret148;
			case 149: goto b_ret149;
			case 150: goto b_ret150;
			case 151: goto b_ret151;
			case 152: goto b_ret152;
			case 153: goto b_ret153;
			case 154: goto b_ret154;
			case 155: goto b_ret155;
			case 156: goto b_ret156;
			case 157: goto b_ret157;
			case 158: goto b_ret158;
			case 159: goto b_ret159;
			case 160: goto b_ret160;
			case 161: goto b_ret161;
			case 162: goto b_ret162;
			case 163: goto b_ret163;
			case 164: goto b_ret164;
			case 165: goto b_ret165;
			case 166: goto b_ret166;
			case 167: goto b_ret167;
			case 168: goto b_ret168;
			case 169: goto b_ret169;
			case 170: goto b_ret170;
			case 171: goto b_ret171;
			case 172: goto b_ret172;
			case 173: goto b_ret173;
			case 174: goto b_ret174;
			case 175: goto b_ret175;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
