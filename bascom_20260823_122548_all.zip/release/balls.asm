; -- balls.bas
; C64 BASIC V2 -> 6502  |  5388 bytes PRG, 47 source lines
	* = $0801
	; entry  $0D28   (10 SYS -> code)
	; vars   $1300 .. $1D0D   (10 vars, 2573 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$33,$33,$36,$38,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- float const pool ----

fconst0:
0813 :  .byte $90,$50,$20,$00,$00

fconst1:
0818 :  .byte $90,$50,$21,$00,$00

fconst2:
081D :  .byte $90,$58,$00,$00,$00

fconst3:
0822 :  .byte $90,$5B,$E7,$00,$00

fconst4:
0827 :  .byte $86,$20,$00,$00,$00

fconst5:
082C :  .byte $85,$48,$00,$00,$00

fconst6:
0831 :  .byte $84,$60,$00,$00,$00

fconst7:
0836 :  .byte $82,$00,$00,$00,$00

fconst8:
083B :  .byte $91,$00,$00,$00,$00

ftemp:
0840 :  .res 5	; float temp slots

sp_save:
0845 :  .res 1	; entry SP (END/STOP unwind GOSUB frames)

ti_t1:
0846 :  .res 5	; TI read 5-byte float temp (24-bit jiffy->FAC hi-byte accum)

rnd_st:
084B :  .res 2	; RT_rnd_fast 16-bit LFSR state (lo,hi)

rnd_k:
084D :  .res 2	; RT_rnd_int K constant (lo,hi)
; ---- mulK lookup tables (speed-mode V*K strength reduction) ----

mulK40_lo:
084F :  .byte $00,$28,$50,$78,$A0,$C8,$F0,$18,$40,$68,$90,$B8,$E0,$08,$30,$58	; mulK lo bytes (i*K & 0xFF)
	.byte $80,$A8,$D0,$F8,$20,$48,$70,$98,$C0

mulK40_hi:
0868 :  .byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02	; mulK hi bytes (i*K >> 8)
	.byte $02,$02,$02,$02,$03,$03,$03,$03,$03
; ---- runtime helpers ----

RT_zero:
0881 :  LDY #0 ; $00
0883 :  LDX ZP_SCR16 + 1 ; $FE
0885 :  BEQ .z_tail

.z_page:
0887 :  LDA #0 ; $00

.z_pl:
0889 :  STA (ZP_PTR),Y ; $FB
088B :  INY
088C :  BNE .z_pl
088E :  INC ZP_PTR + 1 ; $FC
0890 :  DEX
0891 :  BNE .z_page

.z_tail:

.z_tail:
0893 :  LDX ZP_SCR16 ; $FD
0895 :  BEQ .z_done_l

.z_tl:
0897 :  LDA #0 ; $00
0899 :  STA (ZP_PTR),Y ; $FB
089B :  INY
089C :  DEX
089D :  BNE .z_tl

.z_done_l:

.z_done_l:
089F :  RTS

RT_fmul_align:

RT_fmul:

RT_fadd:
0B49 :  JSR $BA8C
0B4C :  LDA $61
0B4E :  JMP RT_fmul_align ; $08A0

RT_fsub:
0B51 :  JSR $BA8C
0B54 :  LDA $66
0B56 :  EOR #$FF
0B58 :  STA $66
0B5A :  EOR $6E
0B5C :  STA $6F
0B5E :  LDA $61
0B60 :  JMP RT_fmul_align ; $08A0

RT_rnd_fast:
0B63 :  LDA FACEXP ; $61
0B65 :  BNE +3 ; FACEXP!=0 -> skip (long BEQ .seed_ti)
0B67 :  JMP .seed_ti

0B6A :  LDA 0x66 ; $66
0B6C :  BPL +3 ; arg>0 -> skip (long BMI .seed_arg)
0B6E :  JMP .seed_arg

.do_advance:
0B71 :  LDA rnd_st + 1 ; $084C
0B74 :  BNE .adv_lfsr
0B76 :  LDA rnd_st ; $084B
0B79 :  BNE .adv_lfsr
0B7B :  LDA 0xA1 ; $A1
0B7D :  STA rnd_st ; $084B
0B80 :  LDA 0xA2 ; $A2
0B82 :  STA rnd_st + 1 ; $084C
0B85 :  BNE .adv_lfsr
0B87 :  LDA rnd_st ; $084B
0B8A :  BNE .adv_lfsr
0B8C :  LDA #0xE1 ; $E1
0B8E :  STA rnd_st ; $084B
0B91 :  LDA #0xAC ; $AC
0B93 :  STA rnd_st + 1 ; $084C

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:
0B96 :  LDA rnd_st + 1 ; $084C
0B99 :  AND #1 ; $01
0B9B :  ASL
0B9C :  ASL
0B9D :  ASL
0B9E :  ASL
0B9F :  ASL
0BA0 :  ASL
0BA1 :  ASL
0BA2 :  EOR rnd_st + 1 ; $084C
0BA5 :  STA rnd_st + 1 ; $084C
0BA8 :  LDA rnd_st ; $084B
0BAB :  LSR
0BAC :  EOR rnd_st + 1 ; $084C
0BAF :  STA rnd_st + 1 ; $084C
0BB2 :  LDA rnd_st ; $084B
0BB5 :  AND #1 ; $01
0BB7 :  ASL
0BB8 :  ASL
0BB9 :  ASL
0BBA :  ASL
0BBB :  ASL
0BBC :  ASL
0BBD :  ASL
0BBE :  EOR rnd_st ; $084B
0BC1 :  STA rnd_st ; $084B
0BC4 :  LDA rnd_st + 1 ; $084C
0BC7 :  LSR
0BC8 :  EOR rnd_st ; $084B
0BCB :  STA rnd_st ; $084B
0BCE :  LDA rnd_st + 1 ; $084C
0BD1 :  EOR rnd_st ; $084B
0BD4 :  STA rnd_st + 1 ; $084C
0BD7 :  BNE .rf_build
0BD9 :  LDA rnd_st ; $084B
0BDC :  BEQ .to_zero

.rf_build:

.rf_build:
0BDE :  LDA rnd_st + 1 ; $084C
0BE1 :  STA 0x62 ; $62
0BE3 :  LDA rnd_st ; $084B
0BE6 :  STA 0x63 ; $63
0BE8 :  LDA #0 ; $00
0BEA :  STA 0x64 ; $64
0BEC :  STA 0x65 ; $65
0BEE :  STA 0x66 ; $66
0BF0 :  LDA #128 ; $80
0BF2 :  STA FACEXP ; $61

.cvt_loop:
0BF4 :  LDA 0x62 ; $62
0BF6 :  BMI .cvt_done
0BF8 :  ASL 0x65 ; $65
0BFA :  ROL 0x64 ; $64
0BFC :  ROL 0x63 ; $63
0BFE :  ROL 0x62 ; $62
0C00 :  DEC FACEXP ; $61
0C02 :  JMP .cvt_loop ; $0BF4

.cvt_done:

.cvt_done:
0C05 :  RTS

.seed_ti:

.seed_ti:
0C06 :  LDA 0xA1 ; $A1
0C08 :  STA rnd_st ; $084B
0C0B :  LDA 0xA2 ; $A2
0C0D :  STA rnd_st + 1 ; $084C
0C10 :  JMP .do_advance ; $0B71

.seed_arg:

.seed_arg:
0C13 :  LDA 0x63 ; $63
0C15 :  STA rnd_st ; $084B
0C18 :  LDA 0x64 ; $64
0C1A :  STA rnd_st + 1 ; $084C
0C1D :  JMP .do_advance ; $0B71

.to_zero:

.to_zero:
0C20 :  LDA #0 ; $00
0C22 :  STA FACEXP ; $61
0C24 :  STA 0x62 ; $62
0C26 :  STA 0x63 ; $63
0C28 :  STA 0x64 ; $64
0C2A :  STA 0x65 ; $65
0C2C :  STA 0x66 ; $66
0C2E :  RTS

RT_rnd_int:
0C2F :  LDA rnd_st + 1 ; $084C
0C32 :  BNE .adv_int
0C34 :  LDA rnd_st ; $084B
0C37 :  BNE .adv_int
0C39 :  LDA 0xA1 ; $A1
0C3B :  STA rnd_st ; $084B
0C3E :  LDA 0xA2 ; $A2
0C40 :  STA rnd_st + 1 ; $084C
0C43 :  BNE .adv_int
0C45 :  LDA rnd_st ; $084B
0C48 :  BNE .adv_int
0C4A :  LDA #0xE1 ; $E1
0C4C :  STA rnd_st ; $084B
0C4F :  LDA #0xAC ; $AC
0C51 :  STA rnd_st + 1 ; $084C

.adv_int:

.adv_int:

.adv_int:

.adv_int:

.adv_int:
0C54 :  LDA rnd_st + 1 ; $084C
0C57 :  AND #1 ; $01
0C59 :  ASL
0C5A :  ASL
0C5B :  ASL
0C5C :  ASL
0C5D :  ASL
0C5E :  ASL
0C5F :  ASL
0C60 :  EOR rnd_st + 1 ; $084C
0C63 :  STA rnd_st + 1 ; $084C
0C66 :  LDA rnd_st ; $084B
0C69 :  LSR
0C6A :  EOR rnd_st + 1 ; $084C
0C6D :  STA rnd_st + 1 ; $084C
0C70 :  LDA rnd_st ; $084B
0C73 :  AND #1 ; $01
0C75 :  ASL
0C76 :  ASL
0C77 :  ASL
0C78 :  ASL
0C79 :  ASL
0C7A :  ASL
0C7B :  ASL
0C7C :  EOR rnd_st ; $084B
0C7F :  STA rnd_st ; $084B
0C82 :  LDA rnd_st + 1 ; $084C
0C85 :  LSR
0C86 :  EOR rnd_st ; $084B
0C89 :  STA rnd_st ; $084B
0C8C :  LDA rnd_st + 1 ; $084C
0C8F :  EOR rnd_st ; $084B
0C92 :  STA rnd_st + 1 ; $084C
0C95 :  LDA #0 ; $00
0C97 :  STA 0xFA ; $FA
0C99 :  STA 0xFB ; $FB
0C9B :  STA 0xFC ; $FC
0C9D :  STA 0xFD ; $FD
0C9F :  LDX #16 ; $10

.mul_loop:
0CA1 :  LDA rnd_k + 1 ; $084E
0CA4 :  AND #0x80 ; $80
0CA6 :  ASL rnd_k ; $084D
0CA9 :  ROL rnd_k+1 ; $084E
0CAC :  ASL 0xFA ; $FA
0CAE :  ROL 0xFB ; $FB
0CB0 :  ROL 0xFC ; $FC
0CB2 :  ROL 0xFD ; $FD
0CB4 :  ASL
0CB5 :  BCC .skip_add
0CB7 :  CLC
0CB8 :  LDA 0xFA ; $FA
0CBA :  ADC rnd_st ; $084B
0CBD :  STA 0xFA ; $FA
0CBF :  LDA 0xFB ; $FB
0CC1 :  ADC rnd_st + 1 ; $084C
0CC4 :  STA 0xFB ; $FB
0CC6 :  LDA 0xFC ; $FC
0CC8 :  ADC #0 ; $00
0CCA :  STA 0xFC ; $FC
0CCC :  LDA 0xFD ; $FD
0CCE :  ADC #0 ; $00
0CD0 :  STA 0xFD ; $FD

.skip_add:

.skip_add:
0CD2 :  DEX
0CD3 :  BNE .mul_loop
0CD5 :  LDA 0xFC ; $FC
0CD7 :  LDX 0xFD ; $FD
0CD9 :  RTS

RT_ti_read:
0CDA :  LDA #0 ; $00
0CDC :  LDY 0xA0 ; $A0
0CDE :  JSR ROM_INT_FAC ; $B391
0CE1 :  LDA FACEXP ; $61
0CE3 :  BEQ .ti_r_s1
0CE5 :  CLC
0CE6 :  ADC #16 ; $10
0CE8 :  STA FACEXP ; $61

.ti_r_s1:

.ti_r_s1:
0CEA :  LDX #<addr ; $46
0CEC :  LDY #>addr ; $08
0CEE :  JSR ROM_FAC_MEM ; $BBD4
0CF1 :  LDA #0 ; $00
0CF3 :  LDY 0xA1 ; $A1
0CF5 :  JSR ROM_INT_FAC ; $B391
0CF8 :  LDA FACEXP ; $61
0CFA :  BEQ .ti_r_s2
0CFC :  CLC
0CFD :  ADC #8 ; $08
0CFF :  STA FACEXP ; $61

.ti_r_s2:

.ti_r_s2:
0D01 :  LDA #<addr ; $46
0D03 :  LDY #>addr ; $08
0D05 :  JSR ROM_MEM_ARG ; $BA8C
0D08 :  LDA FACEXP ; $61
0D0A :  JSR ROM_PLUS ; $B86A
0D0D :  LDX #<addr ; $46
0D0F :  LDY #>addr ; $08
0D11 :  JSR ROM_FAC_MEM ; $BBD4
0D14 :  LDA #0 ; $00
0D16 :  LDY 0xA2 ; $A2
0D18 :  JSR ROM_INT_FAC ; $B391
0D1B :  LDA #<addr ; $46
0D1D :  LDY #>addr ; $08
0D1F :  JSR ROM_MEM_ARG ; $BA8C
0D22 :  LDA FACEXP ; $61
0D24 :  JSR ROM_PLUS ; $B86A
0D27 :  RTS

; ---- save entry SP (END/STOP unwinds GOSUB frames to return to KERNAL, like CBM clearing the GOSUB stack) ----
0D28 :  TSX
0D29 :  STX sp_save_addr ; $0845
; ---- zero variable area (bss excluded from PRG; runtime-init via RT_zero) ----
0D2C :  LDA #0 ; $00
0D2E :  STA ZP_PTR ; $FB
0D30 :  LDA #0 ; $00
0D32 :  STA ZP_PTR + 1 ; $FC
0D34 :  LDA #0 ; $00
0D36 :  STA ZP_SCR16 ; $FD
0D38 :  LDA #0 ; $00
0D3A :  STA ZP_SCR16 + 1 ; $FE
0D3C :  JSR RT_zero ; $0881
; ---- BASIC source ----
; 10    $0D3F  N%=100
; 1,"balls.bas"

L10:
0D3F :  LDA #clo ; $64
0D41 :  STA N
; 20    $0D44  POKE 53280,0
; 2,"balls.bas"

L20:
0D44 :  LDA #(u8)s->e2->ival ; $00
0D46 :  STA ; $D020
; 30    $0D49  POKE 53281,0
; 3,"balls.bas"

L30:
0D49 :  LDA #(u8)s->e2->ival ; $00
0D4B :  STA ; $D021
; 40    $0D4E  PRINT CHR$(147);
; 5,"balls.bas"

L40:
0D4E :  LDA #LO(e->ival) ; $93
0D50 :  LDX #LO((e->ival >> 8)) ; $00
0D52 :  JSR ROM_CHROUT ; $FFD2
; 50    $0D55  DIM BX%(255)
; 6,"balls.bas"

L50:
; 60    $0D55  DIM BY%(255)
; 7,"balls.bas"

L60:
; 70    $0D55  DIM BC%(255)
; 8,"balls.bas"

L70:
; 80    $0D55  DIM X%(255)
; 9,"balls.bas"

L80:
; 90    $0D55  DIM Y%(255)
; 10,"balls.bas"

L90:
; 100   $0D55  B%=1
; 11,"balls.bas"

L100:
0D55 :  LDA #LO(e->ival) ; $01
0D57 :  LDX #LO((e->ival >> 8)) ; $00
0D59 :  STA B
0D5C :  STX B+1
; 110   $0D5F  BX%(B%)=INT(RND(1)*40)
; 13,"balls.bas"

L110:
0D5F :  LDA #LO(K) ; $28
0D61 :  STA rnd_k ; $084D
0D64 :  LDA #HI(K) ; $00
0D66 :  STA rnd_k + 1 ; $084E
0D69 :  JSR RT_rnd_int ; $0C2F
0D6C :  STA ZP_SCR16 ; $FD
0D6E :  STX ZP_SCR16 + 1 ; $FE
0D70 :  LDA B
0D73 :  TAX
0D74 :  LDA ZP_SCR16 ; $FD
0D76 :  STA BX,X
0D79 :  LDA ZP_SCR16 + 1 ; $FE
0D7B :  STA BX+256,X
; 120   $0D7E  BY%(B%)=INT(RND(1)*25)
; 14,"balls.bas"

L120:
0D7E :  LDA #LO(K) ; $19
0D80 :  STA rnd_k ; $084D
0D83 :  LDA #HI(K) ; $00
0D85 :  STA rnd_k + 1 ; $084E
0D88 :  JSR RT_rnd_int ; $0C2F
0D8B :  STA ZP_SCR16 ; $FD
0D8D :  STX ZP_SCR16 + 1 ; $FE
0D8F :  LDA B
0D92 :  TAX
0D93 :  LDA ZP_SCR16 ; $FD
0D95 :  STA BY,X
0D98 :  LDA ZP_SCR16 + 1 ; $FE
0D9A :  STA BY+256,X
; 130   $0D9D  BC%(B%)=INT(RND(1)*14)+1
; 15,"balls.bas"

L130:
0D9D :  LDA #LO(K) ; $0E
0D9F :  STA rnd_k ; $084D
0DA2 :  LDA #HI(K) ; $00
0DA4 :  STA rnd_k + 1 ; $084E
0DA7 :  JSR RT_rnd_int ; $0C2F
0DAA :  STA slot+0
0DAC :  LDA #LO(e->ival) ; $01
0DAE :  LDX #LO((e->ival >> 8)) ; $00
0DB0 :  CLC
0DB1 :  ADC slot+0
0DB3 :  STA ZP_SCR16 ; $FD
0DB5 :  STX ZP_SCR16 + 1 ; $FE
0DB7 :  LDA B
0DBA :  TAX
0DBB :  LDA ZP_SCR16 ; $FD
0DBD :  STA BC,X
0DC0 :  LDA ZP_SCR16 + 1 ; $FE
0DC2 :  STA BC+256,X
; 140   $0DC5  X%(B%)=INT(RND(1)*2)
; 16,"balls.bas"

L140:
0DC5 :  LDA #LO(K) ; $02
0DC7 :  STA rnd_k ; $084D
0DCA :  LDA #HI(K) ; $00
0DCC :  STA rnd_k + 1 ; $084E
0DCF :  JSR RT_rnd_int ; $0C2F
0DD2 :  STA ZP_SCR16 ; $FD
0DD4 :  STX ZP_SCR16 + 1 ; $FE
0DD6 :  LDA B
0DD9 :  TAX
0DDA :  LDA ZP_SCR16 ; $FD
0DDC :  STA X,X
0DDF :  LDA ZP_SCR16 + 1 ; $FE
0DE1 :  STA X+256,X
; 150   $0DE4  Y%(B%)=1
; 17,"balls.bas"

L150:
0DE4 :  LDA #LO(e->ival) ; $01
0DE6 :  LDX #LO((e->ival >> 8)) ; $00
0DE8 :  STA ZP_SCR16 ; $FD
0DEA :  STX ZP_SCR16 + 1 ; $FE
0DEC :  LDA B
0DEF :  TAX
0DF0 :  LDA ZP_SCR16 ; $FD
0DF2 :  STA Y,X
0DF5 :  LDA ZP_SCR16 + 1 ; $FE
0DF7 :  STA Y+256,X
; 160   $0DFA  B%=B%+1
; 18,"balls.bas"

L160:
0DFA :  INC B
; 170   $0DFD  IF B%<=N% THEN 110
; 19,"balls.bas"

L170:
0DFD :  LDA B+1
0E00 :  EOR #0x80 ; $80
0E02 :  CMP #(u8)(cmp_uns_v ? khi : (khi ^ 0x80)) ; $80
0E04 :  BEQ .cmp_lo
0E06 :  BCC .cmp_body
0E08 :  BNE .if_skip

.cmp_lo:
0E0A :  LDA B
0E0D :  CMP #klo ; $64
0E0F :  BEQ .cmp_body
0E11 :  BCS .if_skip

.cmp_body:

.cmp_body:
0E13 :  JMP L110

.if_skip:
; 180   $0E16  FOR I=1024 TO 2023
; 21,"balls.bas"

L180:
; opt: fill
0E16 :  LDA #(u8)(base & 0xFF) ; $00
0E18 :  STA ZP_PTR ; $FB
0E1A :  LDA #(u8)((base >> 8) & 0xFF) ; $04
0E1C :  STA ZP_PTR + 1 ; $FC
0E1E :  LDA #(u8)(s->fill_val_imm & 0xFF) ; $51
0E20 :  LDX #full ; $03

.blk:
0E22 :  LDY #0 ; $00

.inn:
0E24 :  STA (ZP_PTR),Y ; $FB
0E26 :  INY
0E27 :  BNE .inn
0E29 :  INC ZP_PTR + 1 ; $FC
0E2B :  DEX
0E2C :  BNE .blk
0E2E :  LDY #0 ; $00
0E30 :  LDX #rem ; $E8

.rem:
0E32 :  STA (ZP_PTR),Y ; $FB
0E34 :  INY
0E35 :  DEX
0E36 :  BNE .rem
0E38 :  LDA #(u8)(fin & 0xFF) ; $E8
0E3A :  STA I
0E3D :  LDA #(u8)((fin >> 8) & 0xFF) ; $07
0E3F :  STA I+1
; 190   $0E42  POKE I,81
; 22,"balls.bas"

L190:
; 200   $0E42  NEXT I
; 23,"balls.bas"

L200:
; 210   $0E42  FOR I=55296 TO 56295
; 24,"balls.bas"

L210:
; opt: fill
0E42 :  LDA #(u8)(base & 0xFF) ; $00
0E44 :  STA ZP_PTR ; $FB
0E46 :  LDA #(u8)((base >> 8) & 0xFF) ; $D8
0E48 :  STA ZP_PTR + 1 ; $FC
0E4A :  LDA #(u8)(s->fill_val_imm & 0xFF) ; $00
0E4C :  LDX #full ; $03

.blk:
0E4E :  LDY #0 ; $00

.inn:
0E50 :  STA (ZP_PTR),Y ; $FB
0E52 :  INY
0E53 :  BNE .inn
0E55 :  INC ZP_PTR + 1 ; $FC
0E57 :  DEX
0E58 :  BNE .blk
0E5A :  LDY #0 ; $00
0E5C :  LDX #rem ; $E8

.rem:
0E5E :  STA (ZP_PTR),Y ; $FB
0E60 :  INY
0E61 :  DEX
0E62 :  BNE .rem
0E64 :  LDA #(u8)(fin & 0xFF) ; $E8
0E66 :  STA I
0E69 :  LDA #(u8)((fin >> 8) & 0xFF) ; $DB
0E6B :  STA I+1
; 220   $0E6E  POKE I,0
; 25,"balls.bas"

L220:
; 230   $0E6E  NEXT I
; 26,"balls.bas"

L230:
; 240   $0E6E  B%=1
; 28,"balls.bas"

L240:
0E6E :  LDA #LO(e->ival) ; $01
0E70 :  LDX #LO((e->ival >> 8)) ; $00
0E72 :  STA B
0E75 :  STX B+1
; 250   $0E78  T%=TI
; 29,"balls.bas"

L250:
0E78 :  JSR RT_ti_read ; $0CDA
0E7B :  JSR ROM_FAC_INT ; $BC9B
0E7E :  LDA FACMO3 ; $65
0E80 :  LDX FACMO2 ; $64
0E82 :  STA T
0E85 :  STX T+1
; 260   $0E88  POKE 55296+BY%(B%)*40+BX%(B%),0
; 31,"balls.bas"

L260:
0E88 :  LDA B
0E8B :  TAX
0E8C :  LDA #(u8)(base & 0xFF) ; $00
0E8E :  STA ZP_PTR ; $FB
0E90 :  LDA #(u8)((base >> 8) & 0xFF) ; $D8
0E92 :  STA ZP_PTR + 1 ; $FC
0E94 :  LDA BY,X
0E97 :  TAY
0E98 :  LDA h_mulK_lo[mul_K],Y ; $084F
0E9B :  CLC
0E9C :  ADC ZP_PTR ; $FB
0E9E :  STA ZP_PTR ; $FB
0EA0 :  LDA h_mulK_hi[mul_K],Y ; $0868
0EA3 :  ADC ZP_PTR + 1 ; $FC
0EA5 :  STA ZP_PTR + 1 ; $FC
0EA7 :  LDA BX,X
0EAA :  CLC
0EAB :  ADC ZP_PTR ; $FB
0EAD :  STA ZP_PTR ; $FB
0EAF :  LDA #0 ; $00
0EB1 :  ADC ZP_PTR + 1 ; $FC
0EB3 :  STA ZP_PTR + 1 ; $FC
0EB5 :  LDA #(u8)v_imm ; $00
0EB7 :  LDY #0 ; $00
0EB9 :  STA (ZP_PTR),Y ; $FB
; 270   $0EBB  IF X%(B%)=0 THEN GOSUB 1000
; 32,"balls.bas"

L270:
0EBB :  LDA B
0EBE :  TAX
0EBF :  LDA X,X
; opt: compare-narrow
0EC2 :  BNE .if_skip
; opt: gosub-inline (leaf body duplicated; JSR/RTS elided; slf barrier dissolved)
; opt: idxinx (LDA idx;TAX elided -- X already holds idx)
0EC4 :  LDA BX,X
; opt: compare-narrow
0EC7 :  BEQ +3 ; long IF-skip (body >127B)
0EC9 :  JMP .if_skip

0ECC :  LDA #LO(e->ival) ; $01
0ECE :  LDX #LO((e->ival >> 8)) ; $00
0ED0 :  STA ZP_SCR16 ; $FD
0ED2 :  STX ZP_SCR16 + 1 ; $FE
0ED4 :  LDA B
0ED7 :  TAX
0ED8 :  LDA ZP_SCR16 ; $FD
0EDA :  STA X,X
0EDD :  LDA ZP_SCR16 + 1 ; $FE
0EDF :  STA X+256,X
0EE2 :  JMP .gil0

.if_skip:
0EE5 :  LDA #LO(e->ival) ; $01
0EE7 :  LDX #LO((e->ival >> 8)) ; $00
0EE9 :  STA slot+0
0EEB :  STX slot+1
0EED :  LDA B
0EF0 :  TAX
0EF1 :  LDA BX,X
0EF4 :  LDX #0 ; $00
0EF6 :  SEC
0EF7 :  SBC slot+0
0EF9 :  PHA
0EFA :  TXA
0EFB :  SBC slot+1
0EFD :  TAX
0EFE :  PLA
0EFF :  STA ZP_SCR16 ; $FD
0F01 :  STX ZP_SCR16 + 1 ; $FE
0F03 :  LDA B
0F06 :  TAX
0F07 :  LDA ZP_SCR16 ; $FD
0F09 :  STA BX,X
0F0C :  LDA ZP_SCR16 + 1 ; $FE
0F0E :  STA BX+256,X

.gil0:

.if_skip:
; 280   $0F11  IF X%(B%)=1 THEN GOSUB 1100
; 33,"balls.bas"

L280:
0F11 :  LDA B
0F14 :  TAX
0F15 :  LDA X,X
; opt: compare-narrow
0F18 :  CMP #klo ; $01
0F1A :  BNE .if_skip
; opt: gosub-inline (leaf body duplicated; JSR/RTS elided; slf barrier dissolved)
0F1C :  LDA B
0F1F :  TAX
0F20 :  LDA BX,X
0F23 :  LDX #0 ; $00
0F25 :  STA ZP_SCR16 ; $FD
0F27 :  STX ZP_SCR16 + 1 ; $FE
0F29 :  CMP #klo ; $27
0F2B :  BEQ +3 ; long IF-skip (body >127B)
0F2D :  JMP .if_skip

0F30 :  LDA ZP_SCR16 + 1 ; $FE
0F32 :  CMP #khi ; $00
0F34 :  BEQ +3 ; long IF-skip (body >127B)
0F36 :  JMP .if_skip

0F39 :  LDA #LO(e->ival) ; $26
0F3B :  LDX #LO((e->ival >> 8)) ; $00
0F3D :  STA ZP_SCR16 ; $FD
0F3F :  STX ZP_SCR16 + 1 ; $FE
0F41 :  LDA B
0F44 :  TAX
0F45 :  LDA ZP_SCR16 ; $FD
0F47 :  STA BX,X
0F4A :  LDA ZP_SCR16 + 1 ; $FE
0F4C :  STA BX+256,X
0F4F :  LDA #LO(e->ival) ; $00
0F51 :  LDX #LO((e->ival >> 8)) ; $00
0F53 :  STA ZP_SCR16 ; $FD
0F55 :  STX ZP_SCR16 + 1 ; $FE
0F57 :  LDA B
0F5A :  TAX
0F5B :  LDA ZP_SCR16 ; $FD
0F5D :  STA X,X
0F60 :  LDA ZP_SCR16 + 1 ; $FE
0F62 :  STA X+256,X
0F65 :  JMP .gil1

.if_skip:
0F68 :  LDA B
0F6B :  TAX
0F6C :  LDA BX,X
0F6F :  LDX #0 ; $00
0F71 :  STA slot+0
0F73 :  LDA #LO(e->ival) ; $01
0F75 :  CLC
0F76 :  ADC slot+0
0F78 :  STA ZP_SCR16 ; $FD
0F7A :  STX ZP_SCR16 + 1 ; $FE
0F7C :  LDA B
0F7F :  TAX
0F80 :  LDA ZP_SCR16 ; $FD
0F82 :  STA BX,X
0F85 :  LDA ZP_SCR16 + 1 ; $FE
0F87 :  STA BX+256,X

.gil1:

.if_skip:
; 290   $0F8A  IF Y%(B%)=0 THEN GOSUB 1200
; 34,"balls.bas"

L290:
0F8A :  LDA B
0F8D :  TAX
0F8E :  LDA Y,X
; opt: compare-narrow
0F91 :  BNE .if_skip
; opt: gosub-inline (leaf body duplicated; JSR/RTS elided; slf barrier dissolved)
; opt: idxinx (LDA idx;TAX elided -- X already holds idx)
0F93 :  LDA BY,X
; opt: compare-narrow
0F96 :  BEQ +3 ; long IF-skip (body >127B)
0F98 :  JMP .if_skip

0F9B :  LDA #LO(e->ival) ; $01
0F9D :  LDX #LO((e->ival >> 8)) ; $00
0F9F :  STA ZP_SCR16 ; $FD
0FA1 :  STX ZP_SCR16 + 1 ; $FE
0FA3 :  LDA B
0FA6 :  TAX
0FA7 :  LDA ZP_SCR16 ; $FD
0FA9 :  STA Y,X
0FAC :  LDA ZP_SCR16 + 1 ; $FE
0FAE :  STA Y+256,X
0FB1 :  JMP .gil2

.if_skip:
0FB4 :  LDA #LO(e->ival) ; $01
0FB6 :  LDX #LO((e->ival >> 8)) ; $00
0FB8 :  STA slot+0
0FBA :  STX slot+1
0FBC :  LDA B
0FBF :  TAX
0FC0 :  LDA BY,X
0FC3 :  LDX #0 ; $00
0FC5 :  SEC
0FC6 :  SBC slot+0
0FC8 :  PHA
0FC9 :  TXA
0FCA :  SBC slot+1
0FCC :  TAX
0FCD :  PLA
0FCE :  STA ZP_SCR16 ; $FD
0FD0 :  STX ZP_SCR16 + 1 ; $FE
0FD2 :  LDA B
0FD5 :  TAX
0FD6 :  LDA ZP_SCR16 ; $FD
0FD8 :  STA BY,X
0FDB :  LDA ZP_SCR16 + 1 ; $FE
0FDD :  STA BY+256,X

.gil2:

.if_skip:
; 300   $0FE0  IF Y%(B%)=1 THEN GOSUB 1300
; 35,"balls.bas"

L300:
0FE0 :  LDA B
0FE3 :  TAX
0FE4 :  LDA Y,X
; opt: compare-narrow
0FE7 :  CMP #klo ; $01
0FE9 :  BNE .if_skip
; opt: gosub-inline (leaf body duplicated; JSR/RTS elided; slf barrier dissolved)
0FEB :  LDA B
0FEE :  TAX
0FEF :  LDA BY,X
0FF2 :  LDX #0 ; $00
0FF4 :  STA ZP_SCR16 ; $FD
0FF6 :  STX ZP_SCR16 + 1 ; $FE
0FF8 :  CMP #klo ; $18
0FFA :  BEQ +3 ; long IF-skip (body >127B)
0FFC :  JMP .if_skip

0FFF :  LDA ZP_SCR16 + 1 ; $FE
1001 :  CMP #khi ; $00
1003 :  BEQ +3 ; long IF-skip (body >127B)
1005 :  JMP .if_skip

1008 :  LDA #LO(e->ival) ; $17
100A :  LDX #LO((e->ival >> 8)) ; $00
100C :  STA ZP_SCR16 ; $FD
100E :  STX ZP_SCR16 + 1 ; $FE
1010 :  LDA B
1013 :  TAX
1014 :  LDA ZP_SCR16 ; $FD
1016 :  STA BY,X
1019 :  LDA ZP_SCR16 + 1 ; $FE
101B :  STA BY+256,X
101E :  LDA #LO(e->ival) ; $00
1020 :  LDX #LO((e->ival >> 8)) ; $00
1022 :  STA ZP_SCR16 ; $FD
1024 :  STX ZP_SCR16 + 1 ; $FE
1026 :  LDA B
1029 :  TAX
102A :  LDA ZP_SCR16 ; $FD
102C :  STA Y,X
102F :  LDA ZP_SCR16 + 1 ; $FE
1031 :  STA Y+256,X
1034 :  JMP .gil3

.if_skip:
1037 :  LDA B
103A :  TAX
103B :  LDA BY,X
103E :  LDX #0 ; $00
1040 :  STA slot+0
1042 :  LDA #LO(e->ival) ; $01
1044 :  CLC
1045 :  ADC slot+0
1047 :  STA ZP_SCR16 ; $FD
1049 :  STX ZP_SCR16 + 1 ; $FE
104B :  LDA B
104E :  TAX
104F :  LDA ZP_SCR16 ; $FD
1051 :  STA BY,X
1054 :  LDA ZP_SCR16 + 1 ; $FE
1056 :  STA BY+256,X

.gil3:

.if_skip:
; 310   $1059  POKE 55296+BY%(B%)*40+BX%(B%),BC%(B%)
; 36,"balls.bas"

L310:
1059 :  LDA B
105C :  TAX
105D :  LDA #(u8)(base & 0xFF) ; $00
105F :  STA ZP_PTR ; $FB
1061 :  LDA #(u8)((base >> 8) & 0xFF) ; $D8
1063 :  STA ZP_PTR + 1 ; $FC
1065 :  LDA BY,X
1068 :  TAY
1069 :  LDA h_mulK_lo[mul_K],Y ; $084F
106C :  CLC
106D :  ADC ZP_PTR ; $FB
106F :  STA ZP_PTR ; $FB
1071 :  LDA h_mulK_hi[mul_K],Y ; $0868
1074 :  ADC ZP_PTR + 1 ; $FC
1076 :  STA ZP_PTR + 1 ; $FC
1078 :  LDA BX,X
107B :  CLC
107C :  ADC ZP_PTR ; $FB
107E :  STA ZP_PTR ; $FB
1080 :  LDA #0 ; $00
1082 :  ADC ZP_PTR + 1 ; $FC
1084 :  STA ZP_PTR + 1 ; $FC
1086 :  LDA BC,X
1089 :  LDY #0 ; $00
108B :  STA (ZP_PTR),Y ; $FB
; 320   $108D  B%=B%+1
; 37,"balls.bas"

L320:
108D :  INC B
; 330   $1090  IF B%<=N% THEN 260
; 38,"balls.bas"

L330:
1090 :  LDA B+1
1093 :  EOR #0x80 ; $80
1095 :  CMP #(u8)(cmp_uns_v ? khi : (khi ^ 0x80)) ; $80
1097 :  BEQ .cmp_lo
1099 :  BCC .cmp_body
109B :  BNE .if_skip

.cmp_lo:
109D :  LDA B
10A0 :  CMP #klo ; $64
10A2 :  BEQ .cmp_body
10A4 :  BCS .if_skip

.cmp_body:

.cmp_body:
10A6 :  JMP L260

.if_skip:
; 340   $10A9  PRINT CHR$(19);TI-T%
; 40,"balls.bas"

L340:
10A9 :  LDA #LO(e->ival) ; $13
10AB :  LDX #LO((e->ival >> 8)) ; $00
10AD :  JSR ROM_CHROUT ; $FFD2
10B0 :  JSR RT_ti_read ; $0CDA
10B3 :  LDX #<addr ; $40
10B5 :  LDY #>addr ; $08
10B7 :  JSR ROM_FAC_MEM ; $BBD4
10BA :  LDA T
10BD :  LDX T+1
10C0 :  TAY
10C1 :  TXA
10C2 :  JSR ROM_INT_FAC ; $B391
10C5 :  LDA #<addr ; $40
10C7 :  LDY #>addr ; $08
10C9 :  JSR ROM_MEM_ARG ; $BA8C
10CC :  LDA FACEXP ; $61
10CE :  LDA #<addr ; $40
10D0 :  LDY #>addr ; $08
10D2 :  JSR ROM_MINUS ; $B850
10D5 :  JSR ROM_FOUT ; $BDDD
10D8 :  LDY #0 ; $00

.fpl:
10DA :  LDA ZP_GETBUF,Y ; $0100
10DD :  BEQ .fpr_done
10DF :  JSR ROM_CHROUT ; $FFD2
10E2 :  INY
10E3 :  BNE .fpr

.fpr_done:
10E5 :  LDA #0x1D ; $1D
10E7 :  JSR ROM_CHROUT ; $FFD2
10EA :  LDA #13 ; $0D
10EC :  JSR ROM_CHROUT ; $FFD2
; 350   $10EF  GOTO 240
; 41,"balls.bas"

L350:
10EF :  JMP L240

; 1000  $10F2  IF BX%(B%)=0 THEN X%(B%)=1:RETURN
; 43,"balls.bas"

L1000:
10F2 :  LDA B
10F5 :  TAX
10F6 :  LDA BX,X
; opt: compare-narrow
10F9 :  BEQ +3 ; long IF-skip (body >127B)
10FB :  JMP .if_skip

10FE :  LDA #LO(e->ival) ; $01
1100 :  LDX #LO((e->ival >> 8)) ; $00
1102 :  STA ZP_SCR16 ; $FD
1104 :  STX ZP_SCR16 + 1 ; $FE
1106 :  LDA B
1109 :  TAX
110A :  LDA ZP_SCR16 ; $FD
110C :  STA X,X
110F :  LDA ZP_SCR16 + 1 ; $FE
1111 :  STA X+256,X
1114 :  RTS

.if_skip:
; 1005  $1115  BX%(B%)=BX%(B%)-1
; 44,"balls.bas"

L1005:
1115 :  LDA #LO(e->ival) ; $01
1117 :  LDX #LO((e->ival >> 8)) ; $00
1119 :  STA slot+0
111B :  STX slot+1
111D :  LDA B
1120 :  TAX
1121 :  LDA BX,X
1124 :  LDX #0 ; $00
1126 :  SEC
1127 :  SBC slot+0
1129 :  PHA
112A :  TXA
112B :  SBC slot+1
112D :  TAX
112E :  PLA
112F :  STA ZP_SCR16 ; $FD
1131 :  STX ZP_SCR16 + 1 ; $FE
1133 :  LDA B
1136 :  TAX
1137 :  LDA ZP_SCR16 ; $FD
1139 :  STA BX,X
113C :  LDA ZP_SCR16 + 1 ; $FE
113E :  STA BX+256,X
; 1010  $1141  RETURN
; 45,"balls.bas"

L1010:
1141 :  RTS

; 1100  $1142  IF BX%(B%)=39 THEN BX%(B%)=38:X%(B%)=0:RETURN
; 47,"balls.bas"

L1100:
1142 :  LDA B
1145 :  TAX
1146 :  LDA BX,X
1149 :  LDX #0 ; $00
114B :  STA ZP_SCR16 ; $FD
114D :  STX ZP_SCR16 + 1 ; $FE
114F :  CMP #klo ; $27
1151 :  BEQ +3 ; long IF-skip (body >127B)
1153 :  JMP .if_skip

1156 :  LDA ZP_SCR16 + 1 ; $FE
1158 :  CMP #khi ; $00
115A :  BEQ +3 ; long IF-skip (body >127B)
115C :  JMP .if_skip

115F :  LDA #LO(e->ival) ; $26
1161 :  LDX #LO((e->ival >> 8)) ; $00
1163 :  STA ZP_SCR16 ; $FD
1165 :  STX ZP_SCR16 + 1 ; $FE
1167 :  LDA B
116A :  TAX
116B :  LDA ZP_SCR16 ; $FD
116D :  STA BX,X
1170 :  LDA ZP_SCR16 + 1 ; $FE
1172 :  STA BX+256,X
1175 :  LDA #LO(e->ival) ; $00
1177 :  LDX #LO((e->ival >> 8)) ; $00
1179 :  STA ZP_SCR16 ; $FD
117B :  STX ZP_SCR16 + 1 ; $FE
117D :  LDA B
1180 :  TAX
1181 :  LDA ZP_SCR16 ; $FD
1183 :  STA X,X
1186 :  LDA ZP_SCR16 + 1 ; $FE
1188 :  STA X+256,X
118B :  RTS

.if_skip:
; 1105  $118C  BX%(B%)=BX%(B%)+1
; 48,"balls.bas"

L1105:
118C :  LDA B
118F :  TAX
1190 :  LDA BX,X
1193 :  LDX #0 ; $00
1195 :  STA slot+0
1197 :  LDA #LO(e->ival) ; $01
1199 :  CLC
119A :  ADC slot+0
119C :  STA ZP_SCR16 ; $FD
119E :  STX ZP_SCR16 + 1 ; $FE
11A0 :  LDA B
11A3 :  TAX
11A4 :  LDA ZP_SCR16 ; $FD
11A6 :  STA BX,X
11A9 :  LDA ZP_SCR16 + 1 ; $FE
11AB :  STA BX+256,X
; 1110  $11AE  RETURN
; 49,"balls.bas"

L1110:
11AE :  RTS

; 1200  $11AF  IF BY%(B%)=0 THEN Y%(B%)=1:RETURN
; 51,"balls.bas"

L1200:
11AF :  LDA B
11B2 :  TAX
11B3 :  LDA BY,X
; opt: compare-narrow
11B6 :  BEQ +3 ; long IF-skip (body >127B)
11B8 :  JMP .if_skip

11BB :  LDA #LO(e->ival) ; $01
11BD :  LDX #LO((e->ival >> 8)) ; $00
11BF :  STA ZP_SCR16 ; $FD
11C1 :  STX ZP_SCR16 + 1 ; $FE
11C3 :  LDA B
11C6 :  TAX
11C7 :  LDA ZP_SCR16 ; $FD
11C9 :  STA Y,X
11CC :  LDA ZP_SCR16 + 1 ; $FE
11CE :  STA Y+256,X
11D1 :  RTS

.if_skip:
; 1205  $11D2  BY%(B%)=BY%(B%)-1
; 52,"balls.bas"

L1205:
11D2 :  LDA #LO(e->ival) ; $01
11D4 :  LDX #LO((e->ival >> 8)) ; $00
11D6 :  STA slot+0
11D8 :  STX slot+1
11DA :  LDA B
11DD :  TAX
11DE :  LDA BY,X
11E1 :  LDX #0 ; $00
11E3 :  SEC
11E4 :  SBC slot+0
11E6 :  PHA
11E7 :  TXA
11E8 :  SBC slot+1
11EA :  TAX
11EB :  PLA
11EC :  STA ZP_SCR16 ; $FD
11EE :  STX ZP_SCR16 + 1 ; $FE
11F0 :  LDA B
11F3 :  TAX
11F4 :  LDA ZP_SCR16 ; $FD
11F6 :  STA BY,X
11F9 :  LDA ZP_SCR16 + 1 ; $FE
11FB :  STA BY+256,X
; 1210  $11FE  RETURN
; 53,"balls.bas"

L1210:
11FE :  RTS

; 1300  $11FF  IF BY%(B%)=24 THEN BY%(B%)=23:Y%(B%)=0:RETURN
; 55,"balls.bas"

L1300:
11FF :  LDA B
1202 :  TAX
1203 :  LDA BY,X
1206 :  LDX #0 ; $00
1208 :  STA ZP_SCR16 ; $FD
120A :  STX ZP_SCR16 + 1 ; $FE
120C :  CMP #klo ; $18
120E :  BEQ +3 ; long IF-skip (body >127B)
1210 :  JMP .if_skip

1213 :  LDA ZP_SCR16 + 1 ; $FE
1215 :  CMP #khi ; $00
1217 :  BEQ +3 ; long IF-skip (body >127B)
1219 :  JMP .if_skip

121C :  LDA #LO(e->ival) ; $17
121E :  LDX #LO((e->ival >> 8)) ; $00
1220 :  STA ZP_SCR16 ; $FD
1222 :  STX ZP_SCR16 + 1 ; $FE
1224 :  LDA B
1227 :  TAX
1228 :  LDA ZP_SCR16 ; $FD
122A :  STA BY,X
122D :  LDA ZP_SCR16 + 1 ; $FE
122F :  STA BY+256,X
1232 :  LDA #LO(e->ival) ; $00
1234 :  LDX #LO((e->ival >> 8)) ; $00
1236 :  STA ZP_SCR16 ; $FD
1238 :  STX ZP_SCR16 + 1 ; $FE
123A :  LDA B
123D :  TAX
123E :  LDA ZP_SCR16 ; $FD
1240 :  STA Y,X
1243 :  LDA ZP_SCR16 + 1 ; $FE
1245 :  STA Y+256,X
1248 :  RTS

.if_skip:
; 1305  $1249  BY%(B%)=BY%(B%)+1
; 56,"balls.bas"

L1305:
1249 :  LDA B
124C :  TAX
124D :  LDA BY,X
1250 :  LDX #0 ; $00
1252 :  STA slot+0
1254 :  LDA #LO(e->ival) ; $01
1256 :  CLC
1257 :  ADC slot+0
1259 :  STA ZP_SCR16 ; $FD
125B :  STX ZP_SCR16 + 1 ; $FE
125D :  LDA B
1260 :  TAX
1261 :  LDA ZP_SCR16 ; $FD
1263 :  STA BY,X
1266 :  LDA ZP_SCR16 + 1 ; $FE
1268 :  STA BY+256,X
; 1310  $126B  RETURN
; 57,"balls.bas"

L1310:
126B :  RTS

; halt
; ---- variables (zero-filled) ----
N = $1300
; N      $1300 (2 bytes)
BX = $1302
; BX     $1302 (512 bytes array)
BY = $1502
; BY     $1502 (512 bytes array)
BC = $1702
; BC     $1702 (512 bytes array)
X = $1902
; X      $1902 (512 bytes array)
Y = $1B02
; Y      $1B02 (512 bytes array)
B = $1D02
; B      $1D02 (2 bytes)
I = $1D04
; I      $1D04 (2 bytes)
T = $1D06
; T      $1D06 (2 bytes)
TI_F = $1D08
; TI     $1D08 (5 bytes)
126C :  .res 2721	; variable area
