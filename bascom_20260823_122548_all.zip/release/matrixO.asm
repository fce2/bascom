; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e 48 22 STX $2248 ; (spentry + 0)
0811 : a2 22 __ LDX #$22
0813 : a0 d7 __ LDY #$d7
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 26 __ CPX #$26
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 f0 __ CPY #$f0
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 8f __ LDA #$8f
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  31, "C:/Users/g/claude/cpus/6502/examples/compiler/release/matrix.c"
.s1:
0880 : a2 13 __ LDX #$13
0882 : b5 53 __ LDA T0 + 0,x 
0884 : 9d 91 9f STA $9f91,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 56 13 JSR $1356 ; (b_init.s4 + 0)
088d : 20 2d 14 JSR $142d ; (tsb_init.s4 + 0)
0890 : ad 49 22 LDA $2249 ; (b_mem + 0)
0893 : 85 65 __ STA T12 + 0 
0895 : 85 1f __ STA ADDR + 0 
0897 : a9 93 __ LDA #$93
0899 : 85 13 __ STA P6 
089b : ad 4a 22 LDA $224a ; (b_mem + 1)
089e : 85 66 __ STA T12 + 1 
08a0 : 18 __ __ CLC
08a1 : 69 d0 __ ADC #$d0
08a3 : 85 20 __ STA ADDR + 1 
08a5 : a9 00 __ LDA #$00
08a7 : a0 20 __ LDY #$20
08a9 : 91 1f __ STA (ADDR + 0),y 
08ab : c8 __ __ INY
08ac : 91 1f __ STA (ADDR + 0),y 
08ae : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
08b1 : a9 0d __ LDA #$0d
08b3 : 85 13 __ STA P6 
08b5 : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
08b8 : a9 00 __ LDA #$00
08ba : 8d df 22 STA $22df ; (b_v_ci + 0)
08bd : 8d e0 22 STA $22e0 ; (b_v_ci + 1)
08c0 : 8d e1 22 STA $22e1 ; (b_v_ci + 2)
08c3 : 8d e2 22 STA $22e2 ; (b_v_ci + 3)
.l5:
08c6 : ad d3 22 LDA $22d3 ; (b_rndSeed + 0)
08c9 : 85 1b __ STA ACCU + 0 
08cb : ad d4 22 LDA $22d4 ; (b_rndSeed + 1)
08ce : 85 1c __ STA ACCU + 1 
08d0 : ad d5 22 LDA $22d5 ; (b_rndSeed + 2)
08d3 : 85 1d __ STA ACCU + 2 
08d5 : ad d6 22 LDA $22d6 ; (b_rndSeed + 3)
08d8 : 85 1e __ STA ACCU + 3 
08da : a9 cd __ LDA #$cd
08dc : 85 03 __ STA WORK + 0 
08de : a9 00 __ LDA #$00
08e0 : 85 06 __ STA WORK + 3 
08e2 : a9 0d __ LDA #$0d
08e4 : 85 04 __ STA WORK + 1 
08e6 : a9 01 __ LDA #$01
08e8 : 85 05 __ STA WORK + 2 
08ea : 20 78 20 JSR $2078 ; (mul32 + 0)
08ed : 18 __ __ CLC
08ee : a5 07 __ LDA WORK + 4 
08f0 : 69 39 __ ADC #$39
08f2 : 85 53 __ STA T0 + 0 
08f4 : a5 08 __ LDA WORK + 5 
08f6 : 69 30 __ ADC #$30
08f8 : 85 54 __ STA T0 + 1 
08fa : 85 1b __ STA ACCU + 0 
08fc : a5 09 __ LDA WORK + 6 
08fe : 69 00 __ ADC #$00
0900 : 85 55 __ STA T0 + 2 
0902 : 85 1c __ STA ACCU + 1 
0904 : a5 0a __ LDA WORK + 7 
0906 : 69 00 __ ADC #$00
0908 : 85 56 __ STA T0 + 3 
090a : 85 1d __ STA ACCU + 2 
090c : a9 00 __ LDA #$00
090e : 85 1e __ STA ACCU + 3 
0910 : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
0913 : a9 00 __ LDA #$00
0915 : 85 03 __ STA WORK + 0 
0917 : 85 04 __ STA WORK + 1 
0919 : a9 80 __ LDA #$80
091b : 85 05 __ STA WORK + 2 
091d : a9 4b __ LDA #$4b
091f : 85 06 __ STA WORK + 3 
0921 : 20 dc 1b JSR $1bdc ; (freg + 20)
0924 : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
0927 : a9 00 __ LDA #$00
0929 : 85 03 __ STA WORK + 0 
092b : 85 04 __ STA WORK + 1 
092d : a9 c8 __ LDA #$c8
092f : 85 05 __ STA WORK + 2 
0931 : a9 41 __ LDA #$41
0933 : 85 06 __ STA WORK + 3 
0935 : 20 dc 1b JSR $1bdc ; (freg + 20)
0938 : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
093b : a5 1b __ LDA ACCU + 0 
093d : 85 57 __ STA T1 + 0 
093f : a5 1c __ LDA ACCU + 1 
0941 : 85 58 __ STA T1 + 1 
0943 : a5 1d __ LDA ACCU + 2 
0945 : 85 59 __ STA T1 + 2 
0947 : a5 1e __ LDA ACCU + 3 
0949 : 85 5a __ STA T1 + 3 
094b : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
094e : a5 1b __ LDA ACCU + 0 
0950 : 85 43 __ STA T2 + 0 
0952 : a5 1c __ LDA ACCU + 1 
0954 : 85 44 __ STA T2 + 1 
0956 : a5 5a __ LDA T1 + 3 
0958 : 29 7f __ AND #$7f
095a : 05 59 __ ORA T1 + 2 
095c : 05 58 __ ORA T1 + 1 
095e : 05 57 __ ORA T1 + 0 
0960 : f0 3a __ BEQ $099c ; (main.s6 + 0)
.s131:
0962 : 24 5a __ BIT T1 + 3 
0964 : 10 36 __ BPL $099c ; (main.s6 + 0)
.s129:
0966 : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
0969 : a5 1b __ LDA ACCU + 0 
096b : 85 03 __ STA WORK + 0 
096d : a5 1c __ LDA ACCU + 1 
096f : 85 04 __ STA WORK + 1 
0971 : a5 1d __ LDA ACCU + 2 
0973 : 85 05 __ STA WORK + 2 
0975 : a5 1e __ LDA ACCU + 3 
0977 : 85 06 __ STA WORK + 3 
0979 : a5 57 __ LDA T1 + 0 
097b : 85 1b __ STA ACCU + 0 
097d : a5 58 __ LDA T1 + 1 
097f : 85 1c __ STA ACCU + 1 
0981 : a5 59 __ LDA T1 + 2 
0983 : 85 1d __ STA ACCU + 2 
0985 : a5 5a __ LDA T1 + 3 
0987 : 85 1e __ STA ACCU + 3 
0989 : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
098c : f0 0e __ BEQ $099c ; (main.s6 + 0)
.s130:
098e : 18 __ __ CLC
098f : a5 43 __ LDA T2 + 0 
0991 : 69 ff __ ADC #$ff
0993 : 85 57 __ STA T1 + 0 
0995 : a5 44 __ LDA T2 + 1 
0997 : 69 ff __ ADC #$ff
0999 : 4c a2 09 JMP $09a2 ; (main.s7 + 0)
.s6:
099c : a5 43 __ LDA T2 + 0 
099e : 85 57 __ STA T1 + 0 
09a0 : a5 44 __ LDA T2 + 1 
.s7:
09a2 : 85 58 __ STA T1 + 1 
09a4 : ad df 22 LDA $22df ; (b_v_ci + 0)
09a7 : 0a __ __ ASL
09a8 : 85 4f __ STA T6 + 0 
09aa : aa __ __ TAX
09ab : a5 57 __ LDA T1 + 0 
09ad : 9d 40 23 STA $2340,x ; (b_a_hi[0] + 0)
09b0 : a5 58 __ LDA T1 + 1 
09b2 : 9d 41 23 STA $2341,x ; (b_a_hi[0] + 1)
09b5 : a5 53 __ LDA T0 + 0 
09b7 : 85 1b __ STA ACCU + 0 
09b9 : a5 54 __ LDA T0 + 1 
09bb : 85 1c __ STA ACCU + 1 
09bd : a5 55 __ LDA T0 + 2 
09bf : 85 1d __ STA ACCU + 2 
09c1 : a5 56 __ LDA T0 + 3 
09c3 : 85 1e __ STA ACCU + 3 
09c5 : a9 cd __ LDA #$cd
09c7 : 85 03 __ STA WORK + 0 
09c9 : a9 00 __ LDA #$00
09cb : 85 06 __ STA WORK + 3 
09cd : a9 0d __ LDA #$0d
09cf : 85 04 __ STA WORK + 1 
09d1 : a9 01 __ LDA #$01
09d3 : 85 05 __ STA WORK + 2 
09d5 : 20 78 20 JSR $2078 ; (mul32 + 0)
09d8 : 18 __ __ CLC
09d9 : a5 07 __ LDA WORK + 4 
09db : 69 39 __ ADC #$39
09dd : 85 53 __ STA T0 + 0 
09df : a5 08 __ LDA WORK + 5 
09e1 : 69 30 __ ADC #$30
09e3 : 85 54 __ STA T0 + 1 
09e5 : 85 1b __ STA ACCU + 0 
09e7 : a5 09 __ LDA WORK + 6 
09e9 : 69 00 __ ADC #$00
09eb : 85 55 __ STA T0 + 2 
09ed : 85 1c __ STA ACCU + 1 
09ef : a5 0a __ LDA WORK + 7 
09f1 : 69 00 __ ADC #$00
09f3 : 85 56 __ STA T0 + 3 
09f5 : 85 1d __ STA ACCU + 2 
09f7 : a9 00 __ LDA #$00
09f9 : 85 1e __ STA ACCU + 3 
09fb : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
09fe : a9 00 __ LDA #$00
0a00 : 85 03 __ STA WORK + 0 
0a02 : 85 04 __ STA WORK + 1 
0a04 : a9 80 __ LDA #$80
0a06 : 85 05 __ STA WORK + 2 
0a08 : a9 4b __ LDA #$4b
0a0a : 85 06 __ STA WORK + 3 
0a0c : 20 dc 1b JSR $1bdc ; (freg + 20)
0a0f : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
0a12 : a9 00 __ LDA #$00
0a14 : 85 03 __ STA WORK + 0 
0a16 : 85 04 __ STA WORK + 1 
0a18 : a9 20 __ LDA #$20
0a1a : 85 05 __ STA WORK + 2 
0a1c : a9 41 __ LDA #$41
0a1e : 85 06 __ STA WORK + 3 
0a20 : 20 dc 1b JSR $1bdc ; (freg + 20)
0a23 : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
0a26 : a5 1b __ LDA ACCU + 0 
0a28 : 85 47 __ STA T3 + 0 
0a2a : a5 1c __ LDA ACCU + 1 
0a2c : 85 48 __ STA T3 + 1 
0a2e : a5 1d __ LDA ACCU + 2 
0a30 : 85 49 __ STA T3 + 2 
0a32 : a5 1e __ LDA ACCU + 3 
0a34 : 85 4a __ STA T3 + 3 
0a36 : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
0a39 : a5 1b __ LDA ACCU + 0 
0a3b : 85 4b __ STA T4 + 0 
0a3d : a5 1c __ LDA ACCU + 1 
0a3f : 85 4c __ STA T4 + 1 
0a41 : a5 4a __ LDA T3 + 3 
0a43 : 29 7f __ AND #$7f
0a45 : 05 49 __ ORA T3 + 2 
0a47 : 05 48 __ ORA T3 + 1 
0a49 : 05 47 __ ORA T3 + 0 
0a4b : f0 39 __ BEQ $0a86 ; (main.s8 + 0)
.s128:
0a4d : 24 4a __ BIT T3 + 3 
0a4f : 10 35 __ BPL $0a86 ; (main.s8 + 0)
.s126:
0a51 : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
0a54 : a5 1b __ LDA ACCU + 0 
0a56 : 85 03 __ STA WORK + 0 
0a58 : a5 1c __ LDA ACCU + 1 
0a5a : 85 04 __ STA WORK + 1 
0a5c : a5 1d __ LDA ACCU + 2 
0a5e : 85 05 __ STA WORK + 2 
0a60 : a5 1e __ LDA ACCU + 3 
0a62 : 85 06 __ STA WORK + 3 
0a64 : a5 47 __ LDA T3 + 0 
0a66 : 85 1b __ STA ACCU + 0 
0a68 : a5 48 __ LDA T3 + 1 
0a6a : 85 1c __ STA ACCU + 1 
0a6c : a5 49 __ LDA T3 + 2 
0a6e : 85 1d __ STA ACCU + 2 
0a70 : a5 4a __ LDA T3 + 3 
0a72 : 85 1e __ STA ACCU + 3 
0a74 : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
0a77 : f0 0d __ BEQ $0a86 ; (main.s8 + 0)
.s127:
0a79 : 18 __ __ CLC
0a7a : a5 4b __ LDA T4 + 0 
0a7c : 69 ff __ ADC #$ff
0a7e : a8 __ __ TAY
0a7f : a5 4c __ LDA T4 + 1 
0a81 : 69 ff __ ADC #$ff
0a83 : 4c 8a 0a JMP $0a8a ; (main.s9 + 0)
.s8:
0a86 : a5 4c __ LDA T4 + 1 
0a88 : a4 4b __ LDY T4 + 0 
.s9:
0a8a : aa __ __ TAX
0a8b : 98 __ __ TYA
0a8c : 18 __ __ CLC
0a8d : 69 05 __ ADC #$05
0a8f : 85 47 __ STA T3 + 0 
0a91 : a4 4f __ LDY T6 + 0 
0a93 : 99 90 23 STA $2390,y ; (b_a_ti[0] + 0)
0a96 : 8a __ __ TXA
0a97 : 69 00 __ ADC #$00
0a99 : 85 48 __ STA T3 + 1 
0a9b : 99 91 23 STA $2391,y ; (b_a_ti[0] + 1)
0a9e : 38 __ __ SEC
0a9f : a5 57 __ LDA T1 + 0 
0aa1 : e5 47 __ SBC T3 + 0 
0aa3 : 99 00 24 STA $2400,y ; (b_a_ei[0] + 0)
0aa6 : aa __ __ TAX
0aa7 : a5 58 __ LDA T1 + 1 
0aa9 : e5 48 __ SBC T3 + 1 
0aab : 85 58 __ STA T1 + 1 
0aad : 99 01 24 STA $2401,y ; (b_a_ei[0] + 1)
0ab0 : 10 04 __ BPL $0ab6 ; (main.s11 + 0)
.s10:
0ab2 : a9 01 __ LDA #$01
0ab4 : d0 02 __ BNE $0ab8 ; (main.s12 + 0)
.s11:
0ab6 : a9 00 __ LDA #$00
.s12:
0ab8 : 49 ff __ EOR #$ff
0aba : c9 ff __ CMP #$ff
0abc : f0 0e __ BEQ $0acc ; (main.s13 + 0)
.s125:
0abe : 8a __ __ TXA
0abf : 18 __ __ CLC
0ac0 : 69 19 __ ADC #$19
0ac2 : 99 00 24 STA $2400,y ; (b_a_ei[0] + 0)
0ac5 : a5 58 __ LDA T1 + 1 
0ac7 : 69 00 __ ADC #$00
0ac9 : 99 01 24 STA $2401,y ; (b_a_ei[0] + 1)
.s13:
0acc : a5 53 __ LDA T0 + 0 
0ace : 85 1b __ STA ACCU + 0 
0ad0 : a5 54 __ LDA T0 + 1 
0ad2 : 85 1c __ STA ACCU + 1 
0ad4 : a5 55 __ LDA T0 + 2 
0ad6 : 85 1d __ STA ACCU + 2 
0ad8 : a5 56 __ LDA T0 + 3 
0ada : 85 1e __ STA ACCU + 3 
0adc : a9 cd __ LDA #$cd
0ade : 85 03 __ STA WORK + 0 
0ae0 : a9 00 __ LDA #$00
0ae2 : 85 06 __ STA WORK + 3 
0ae4 : a9 0d __ LDA #$0d
0ae6 : 85 04 __ STA WORK + 1 
0ae8 : a9 01 __ LDA #$01
0aea : 85 05 __ STA WORK + 2 
0aec : 20 78 20 JSR $2078 ; (mul32 + 0)
0aef : 18 __ __ CLC
0af0 : a5 07 __ LDA WORK + 4 
0af2 : 69 39 __ ADC #$39
0af4 : 85 53 __ STA T0 + 0 
0af6 : a5 08 __ LDA WORK + 5 
0af8 : 69 30 __ ADC #$30
0afa : 85 54 __ STA T0 + 1 
0afc : 85 1b __ STA ACCU + 0 
0afe : a5 09 __ LDA WORK + 6 
0b00 : 69 00 __ ADC #$00
0b02 : 85 55 __ STA T0 + 2 
0b04 : 85 1c __ STA ACCU + 1 
0b06 : a5 0a __ LDA WORK + 7 
0b08 : 69 00 __ ADC #$00
0b0a : 85 56 __ STA T0 + 3 
0b0c : 85 1d __ STA ACCU + 2 
0b0e : a9 00 __ LDA #$00
0b10 : 85 1e __ STA ACCU + 3 
0b12 : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
0b15 : a9 00 __ LDA #$00
0b17 : 85 03 __ STA WORK + 0 
0b19 : 85 04 __ STA WORK + 1 
0b1b : a9 80 __ LDA #$80
0b1d : 85 05 __ STA WORK + 2 
0b1f : a9 4b __ LDA #$4b
0b21 : 85 06 __ STA WORK + 3 
0b23 : 20 dc 1b JSR $1bdc ; (freg + 20)
0b26 : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
0b29 : a9 00 __ LDA #$00
0b2b : 85 03 __ STA WORK + 0 
0b2d : 85 04 __ STA WORK + 1 
0b2f : a9 68 __ LDA #$68
0b31 : 85 05 __ STA WORK + 2 
0b33 : a9 42 __ LDA #$42
0b35 : 85 06 __ STA WORK + 3 
0b37 : 20 dc 1b JSR $1bdc ; (freg + 20)
0b3a : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
0b3d : a5 1b __ LDA ACCU + 0 
0b3f : 85 57 __ STA T1 + 0 
0b41 : a5 1c __ LDA ACCU + 1 
0b43 : 85 58 __ STA T1 + 1 
0b45 : a5 1d __ LDA ACCU + 2 
0b47 : 85 59 __ STA T1 + 2 
0b49 : a5 1e __ LDA ACCU + 3 
0b4b : 85 5a __ STA T1 + 3 
0b4d : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
0b50 : a5 1b __ LDA ACCU + 0 
0b52 : 85 47 __ STA T3 + 0 
0b54 : a5 1c __ LDA ACCU + 1 
0b56 : 85 48 __ STA T3 + 1 
0b58 : a5 5a __ LDA T1 + 3 
0b5a : 29 7f __ AND #$7f
0b5c : 05 59 __ ORA T1 + 2 
0b5e : 05 58 __ ORA T1 + 1 
0b60 : 05 57 __ ORA T1 + 0 
0b62 : f0 39 __ BEQ $0b9d ; (main.s14 + 0)
.s124:
0b64 : 24 5a __ BIT T1 + 3 
0b66 : 10 35 __ BPL $0b9d ; (main.s14 + 0)
.s122:
0b68 : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
0b6b : a5 1b __ LDA ACCU + 0 
0b6d : 85 03 __ STA WORK + 0 
0b6f : a5 1c __ LDA ACCU + 1 
0b71 : 85 04 __ STA WORK + 1 
0b73 : a5 1d __ LDA ACCU + 2 
0b75 : 85 05 __ STA WORK + 2 
0b77 : a5 1e __ LDA ACCU + 3 
0b79 : 85 06 __ STA WORK + 3 
0b7b : a5 57 __ LDA T1 + 0 
0b7d : 85 1b __ STA ACCU + 0 
0b7f : a5 58 __ LDA T1 + 1 
0b81 : 85 1c __ STA ACCU + 1 
0b83 : a5 59 __ LDA T1 + 2 
0b85 : 85 1d __ STA ACCU + 2 
0b87 : a5 5a __ LDA T1 + 3 
0b89 : 85 1e __ STA ACCU + 3 
0b8b : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
0b8e : f0 0d __ BEQ $0b9d ; (main.s14 + 0)
.s123:
0b90 : 18 __ __ CLC
0b91 : a5 47 __ LDA T3 + 0 
0b93 : 69 ff __ ADC #$ff
0b95 : a8 __ __ TAY
0b96 : a5 48 __ LDA T3 + 1 
0b98 : 69 ff __ ADC #$ff
0b9a : 4c a1 0b JMP $0ba1 ; (main.s15 + 0)
.s14:
0b9d : a5 48 __ LDA T3 + 1 
0b9f : a4 47 __ LDY T3 + 0 
.s15:
0ba1 : aa __ __ TAX
0ba2 : 98 __ __ TYA
0ba3 : 18 __ __ CLC
0ba4 : 69 21 __ ADC #$21
0ba6 : a4 4f __ LDY T6 + 0 
0ba8 : 99 50 24 STA $2450,y ; (b_a_chi[0] + 0)
0bab : 8a __ __ TXA
0bac : 69 00 __ ADC #$00
0bae : 99 51 24 STA $2451,y ; (b_a_chi[0] + 1)
0bb1 : a5 53 __ LDA T0 + 0 
0bb3 : 85 1b __ STA ACCU + 0 
0bb5 : a5 54 __ LDA T0 + 1 
0bb7 : 85 1c __ STA ACCU + 1 
0bb9 : a5 55 __ LDA T0 + 2 
0bbb : 85 1d __ STA ACCU + 2 
0bbd : a5 56 __ LDA T0 + 3 
0bbf : 85 1e __ STA ACCU + 3 
0bc1 : a9 cd __ LDA #$cd
0bc3 : 85 03 __ STA WORK + 0 
0bc5 : a9 00 __ LDA #$00
0bc7 : 85 06 __ STA WORK + 3 
0bc9 : a9 0d __ LDA #$0d
0bcb : 85 04 __ STA WORK + 1 
0bcd : a9 01 __ LDA #$01
0bcf : 85 05 __ STA WORK + 2 
0bd1 : 20 78 20 JSR $2078 ; (mul32 + 0)
0bd4 : 18 __ __ CLC
0bd5 : a5 07 __ LDA WORK + 4 
0bd7 : 69 39 __ ADC #$39
0bd9 : 8d d3 22 STA $22d3 ; (b_rndSeed + 0)
0bdc : a5 08 __ LDA WORK + 5 
0bde : 69 30 __ ADC #$30
0be0 : 8d d4 22 STA $22d4 ; (b_rndSeed + 1)
0be3 : 85 1b __ STA ACCU + 0 
0be5 : a5 09 __ LDA WORK + 6 
0be7 : 69 00 __ ADC #$00
0be9 : 8d d5 22 STA $22d5 ; (b_rndSeed + 2)
0bec : 85 1c __ STA ACCU + 1 
0bee : a5 0a __ LDA WORK + 7 
0bf0 : 69 00 __ ADC #$00
0bf2 : 8d d6 22 STA $22d6 ; (b_rndSeed + 3)
0bf5 : 85 1d __ STA ACCU + 2 
0bf7 : a9 00 __ LDA #$00
0bf9 : 85 1e __ STA ACCU + 3 
0bfb : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
0bfe : a9 00 __ LDA #$00
0c00 : 85 03 __ STA WORK + 0 
0c02 : 85 04 __ STA WORK + 1 
0c04 : a9 80 __ LDA #$80
0c06 : 85 05 __ STA WORK + 2 
0c08 : a9 4b __ LDA #$4b
0c0a : 85 06 __ STA WORK + 3 
0c0c : 20 dc 1b JSR $1bdc ; (freg + 20)
0c0f : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
0c12 : a9 00 __ LDA #$00
0c14 : 85 03 __ STA WORK + 0 
0c16 : 85 04 __ STA WORK + 1 
0c18 : a9 a0 __ LDA #$a0
0c1a : 85 05 __ STA WORK + 2 
0c1c : a9 40 __ LDA #$40
0c1e : 85 06 __ STA WORK + 3 
0c20 : 20 dc 1b JSR $1bdc ; (freg + 20)
0c23 : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
0c26 : a5 1b __ LDA ACCU + 0 
0c28 : 85 53 __ STA T0 + 0 
0c2a : a5 1c __ LDA ACCU + 1 
0c2c : 85 54 __ STA T0 + 1 
0c2e : a5 1d __ LDA ACCU + 2 
0c30 : 85 55 __ STA T0 + 2 
0c32 : a5 1e __ LDA ACCU + 3 
0c34 : 85 56 __ STA T0 + 3 
0c36 : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
0c39 : a5 1b __ LDA ACCU + 0 
0c3b : 85 57 __ STA T1 + 0 
0c3d : a5 1c __ LDA ACCU + 1 
0c3f : 85 58 __ STA T1 + 1 
0c41 : a5 56 __ LDA T0 + 3 
0c43 : 29 7f __ AND #$7f
0c45 : 05 55 __ ORA T0 + 2 
0c47 : 05 54 __ ORA T0 + 1 
0c49 : 05 53 __ ORA T0 + 0 
0c4b : f0 39 __ BEQ $0c86 ; (main.s16 + 0)
.s121:
0c4d : 24 56 __ BIT T0 + 3 
0c4f : 10 35 __ BPL $0c86 ; (main.s16 + 0)
.s119:
0c51 : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
0c54 : a5 1b __ LDA ACCU + 0 
0c56 : 85 03 __ STA WORK + 0 
0c58 : a5 1c __ LDA ACCU + 1 
0c5a : 85 04 __ STA WORK + 1 
0c5c : a5 1d __ LDA ACCU + 2 
0c5e : 85 05 __ STA WORK + 2 
0c60 : a5 1e __ LDA ACCU + 3 
0c62 : 85 06 __ STA WORK + 3 
0c64 : a5 53 __ LDA T0 + 0 
0c66 : 85 1b __ STA ACCU + 0 
0c68 : a5 54 __ LDA T0 + 1 
0c6a : 85 1c __ STA ACCU + 1 
0c6c : a5 55 __ LDA T0 + 2 
0c6e : 85 1d __ STA ACCU + 2 
0c70 : a5 56 __ LDA T0 + 3 
0c72 : 85 1e __ STA ACCU + 3 
0c74 : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
0c77 : f0 0d __ BEQ $0c86 ; (main.s16 + 0)
.s120:
0c79 : 18 __ __ CLC
0c7a : a5 57 __ LDA T1 + 0 
0c7c : 69 ff __ ADC #$ff
0c7e : a8 __ __ TAY
0c7f : a5 58 __ LDA T1 + 1 
0c81 : 69 ff __ ADC #$ff
0c83 : 4c 8a 0c JMP $0c8a ; (main.s17 + 0)
.s16:
0c86 : a5 58 __ LDA T1 + 1 
0c88 : a4 57 __ LDY T1 + 0 
.s17:
0c8a : aa __ __ TAX
0c8b : 98 __ __ TYA
0c8c : 18 __ __ CLC
0c8d : 69 01 __ ADC #$01
0c8f : a4 4f __ LDY T6 + 0 
0c91 : 99 a0 24 STA $24a0,y ; (b_a_di[0] + 0)
0c94 : 8a __ __ TXA
0c95 : 69 00 __ ADC #$00
0c97 : 99 a1 24 STA $24a1,y ; (b_a_di[0] + 1)
0c9a : ad df 22 LDA $22df ; (b_v_ci + 0)
0c9d : 18 __ __ CLC
0c9e : 69 01 __ ADC #$01
0ca0 : 8d df 22 STA $22df ; (b_v_ci + 0)
0ca3 : ad e0 22 LDA $22e0 ; (b_v_ci + 1)
0ca6 : 69 00 __ ADC #$00
0ca8 : 8d e0 22 STA $22e0 ; (b_v_ci + 1)
0cab : ad e1 22 LDA $22e1 ; (b_v_ci + 2)
0cae : 69 00 __ ADC #$00
0cb0 : 8d e1 22 STA $22e1 ; (b_v_ci + 2)
0cb3 : ad e2 22 LDA $22e2 ; (b_v_ci + 3)
0cb6 : 69 00 __ ADC #$00
0cb8 : 8d e2 22 STA $22e2 ; (b_v_ci + 3)
0cbb : d0 14 __ BNE $0cd1 ; (main.l18 + 0)
.s116:
0cbd : ad e1 22 LDA $22e1 ; (b_v_ci + 2)
0cc0 : d0 0f __ BNE $0cd1 ; (main.l18 + 0)
.s117:
0cc2 : ad e0 22 LDA $22e0 ; (b_v_ci + 1)
0cc5 : d0 0a __ BNE $0cd1 ; (main.l18 + 0)
.s118:
0cc7 : a9 27 __ LDA #$27
0cc9 : cd df 22 CMP $22df ; (b_v_ci + 0)
0ccc : 90 03 __ BCC $0cd1 ; (main.l18 + 0)
0cce : 4c c6 08 JMP $08c6 ; (main.l5 + 0)
.l18:
0cd1 : 20 c9 16 JSR $16c9 ; (b_jiffy.s4 + 0)
0cd4 : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
0cd7 : a5 1b __ LDA ACCU + 0 
0cd9 : 85 5b __ STA T5 + 0 
0cdb : a5 1c __ LDA ACCU + 1 
0cdd : 85 5c __ STA T5 + 1 
0cdf : a5 1d __ LDA ACCU + 2 
0ce1 : 85 5d __ STA T5 + 2 
0ce3 : a5 1e __ LDA ACCU + 3 
0ce5 : 85 5e __ STA T5 + 3 
0ce7 : a9 00 __ LDA #$00
0ce9 : 8d df 22 STA $22df ; (b_v_ci + 0)
0cec : 8d e0 22 STA $22e0 ; (b_v_ci + 1)
0cef : 8d e1 22 STA $22e1 ; (b_v_ci + 2)
0cf2 : 8d e2 22 STA $22e2 ; (b_v_ci + 3)
0cf5 : ad 4f 22 LDA $224f ; (b_gosubSP + 0)
0cf8 : 0a __ __ ASL
0cf9 : a8 __ __ TAY
0cfa : ad 50 22 LDA $2250 ; (b_gosubSP + 1)
0cfd : 2a __ __ ROL
0cfe : aa __ __ TAX
0cff : 98 __ __ TYA
0d00 : 18 __ __ CLC
0d01 : 69 f0 __ ADC #$f0
0d03 : 85 4f __ STA T6 + 0 
0d05 : 8a __ __ TXA
0d06 : 69 24 __ ADC #$24
0d08 : 85 50 __ STA T6 + 1 
.l19:
0d0a : a9 00 __ LDA #$00
0d0c : a8 __ __ TAY
0d0d : 91 4f __ STA (T6 + 0),y 
0d0f : c8 __ __ INY
0d10 : 91 4f __ STA (T6 + 0),y 
0d12 : ad e1 22 LDA $22e1 ; (b_v_ci + 2)
0d15 : 85 55 __ STA T0 + 2 
0d17 : ad e2 22 LDA $22e2 ; (b_v_ci + 3)
0d1a : 85 56 __ STA T0 + 3 
0d1c : ad df 22 LDA $22df ; (b_v_ci + 0)
0d1f : 85 53 __ STA T0 + 0 
0d21 : 0a __ __ ASL
0d22 : 85 47 __ STA T3 + 0 
0d24 : 85 5f __ STA T8 + 0 
0d26 : aa __ __ TAX
0d27 : bd 40 23 LDA $2340,x ; (b_a_hi[0] + 0)
0d2a : 85 51 __ STA T7 + 0 
0d2c : 0a __ __ ASL
0d2d : 85 1b __ STA ACCU + 0 
0d2f : bd 41 23 LDA $2341,x ; (b_a_hi[0] + 1)
0d32 : 85 52 __ STA T7 + 1 
0d34 : 2a __ __ ROL
0d35 : 06 1b __ ASL ACCU + 0 
0d37 : 2a __ __ ROL
0d38 : 85 1c __ STA ACCU + 1 
0d3a : 18 __ __ CLC
0d3b : a5 1b __ LDA ACCU + 0 
0d3d : 65 51 __ ADC T7 + 0 
0d3f : 85 57 __ STA T1 + 0 
0d41 : a5 1c __ LDA ACCU + 1 
0d43 : 65 52 __ ADC T7 + 1 
0d45 : 06 57 __ ASL T1 + 0 
0d47 : 2a __ __ ROL
0d48 : 06 57 __ ASL T1 + 0 
0d4a : 2a __ __ ROL
0d4b : 06 57 __ ASL T1 + 0 
0d4d : 2a __ __ ROL
0d4e : 85 58 __ STA T1 + 1 
0d50 : 18 __ __ CLC
0d51 : a5 57 __ LDA T1 + 0 
0d53 : 65 53 __ ADC T0 + 0 
0d55 : 85 57 __ STA T1 + 0 
0d57 : 85 43 __ STA T2 + 0 
0d59 : bd 50 24 LDA $2450,x ; (b_a_chi[0] + 0)
0d5c : 85 60 __ STA T9 + 0 
0d5e : bd 51 24 LDA $2451,x ; (b_a_chi[0] + 1)
0d61 : 85 61 __ STA T9 + 1 
0d63 : ad e0 22 LDA $22e0 ; (b_v_ci + 1)
0d66 : 85 54 __ STA T0 + 1 
0d68 : 65 58 __ ADC T1 + 1 
0d6a : 85 58 __ STA T1 + 1 
0d6c : 18 __ __ CLC
0d6d : 69 04 __ ADC #$04
0d6f : 85 44 __ STA T2 + 1 
0d71 : c9 e0 __ CMP #$e0
0d73 : 90 2c __ BCC $0da1 ; (main.s20 + 0)
.s111:
0d75 : c9 ff __ CMP #$ff
0d77 : d0 04 __ BNE $0d7d ; (main.s115 + 0)
.s114:
0d79 : a5 57 __ LDA T1 + 0 
0d7b : c9 40 __ CMP #$40
.s115:
0d7d : b0 22 __ BCS $0da1 ; (main.s20 + 0)
.s112:
0d7f : b1 65 __ LDA (T12 + 0),y 
0d81 : 85 1b __ STA ACCU + 0 
0d83 : 4a __ __ LSR
0d84 : 90 1b __ BCC $0da1 ; (main.s20 + 0)
.s113:
0d86 : a5 1b __ LDA ACCU + 0 
0d88 : 29 fe __ AND #$fe
0d8a : 91 65 __ STA (T12 + 0),y 
0d8c : 18 __ __ CLC
0d8d : a5 66 __ LDA T12 + 1 
0d8f : 65 44 __ ADC T2 + 1 
0d91 : 85 44 __ STA T2 + 1 
0d93 : a5 60 __ LDA T9 + 0 
0d95 : a4 65 __ LDY T12 + 0 
0d97 : 91 43 __ STA (T2 + 0),y 
0d99 : a5 1b __ LDA ACCU + 0 
0d9b : a0 01 __ LDY #$01
0d9d : 91 65 __ STA (T12 + 0),y 
0d9f : d0 0d __ BNE $0dae ; (main.s21 + 0)
.s20:
0da1 : 18 __ __ CLC
0da2 : a5 66 __ LDA T12 + 1 
0da4 : 65 44 __ ADC T2 + 1 
0da6 : 85 44 __ STA T2 + 1 
0da8 : a5 60 __ LDA T9 + 0 
0daa : a4 65 __ LDY T12 + 0 
0dac : 91 43 __ STA (T2 + 0),y 
.s21:
0dae : 18 __ __ CLC
0daf : a5 58 __ LDA T1 + 1 
0db1 : 69 d8 __ ADC #$d8
0db3 : 85 58 __ STA T1 + 1 
0db5 : c9 e0 __ CMP #$e0
0db7 : 90 2d __ BCC $0de6 ; (main.s22 + 0)
.s106:
0db9 : c9 ff __ CMP #$ff
0dbb : d0 04 __ BNE $0dc1 ; (main.s110 + 0)
.s109:
0dbd : a5 57 __ LDA T1 + 0 
0dbf : c9 40 __ CMP #$40
.s110:
0dc1 : b0 23 __ BCS $0de6 ; (main.s22 + 0)
.s107:
0dc3 : a0 01 __ LDY #$01
0dc5 : b1 65 __ LDA (T12 + 0),y 
0dc7 : 85 63 __ STA T11 + 0 
0dc9 : 4a __ __ LSR
0dca : 90 1a __ BCC $0de6 ; (main.s22 + 0)
.s108:
0dcc : a5 63 __ LDA T11 + 0 
0dce : 29 fe __ AND #$fe
0dd0 : 91 65 __ STA (T12 + 0),y 
0dd2 : 18 __ __ CLC
0dd3 : a5 66 __ LDA T12 + 1 
0dd5 : 65 58 __ ADC T1 + 1 
0dd7 : 85 58 __ STA T1 + 1 
0dd9 : 98 __ __ TYA
0dda : a4 65 __ LDY T12 + 0 
0ddc : 91 57 __ STA (T1 + 0),y 
0dde : a5 63 __ LDA T11 + 0 
0de0 : a0 01 __ LDY #$01
0de2 : 91 65 __ STA (T12 + 0),y 
0de4 : d0 0d __ BNE $0df3 ; (main.s23 + 0)
.s22:
0de6 : 18 __ __ CLC
0de7 : a5 66 __ LDA T12 + 1 
0de9 : 65 58 __ ADC T1 + 1 
0deb : 85 58 __ STA T1 + 1 
0ded : a9 01 __ LDA #$01
0def : a4 65 __ LDY T12 + 0 
0df1 : 91 57 __ STA (T1 + 0),y 
.s23:
0df3 : 86 62 __ STX T10 + 0 
0df5 : bd a0 24 LDA $24a0,x ; (b_a_di[0] + 0)
0df8 : 18 __ __ CLC
0df9 : 65 60 __ ADC T9 + 0 
0dfb : 85 57 __ STA T1 + 0 
0dfd : 9d 50 24 STA $2450,x ; (b_a_chi[0] + 0)
0e00 : bd a1 24 LDA $24a1,x ; (b_a_di[0] + 1)
0e03 : 65 61 __ ADC T9 + 1 
0e05 : 9d 51 24 STA $2451,x ; (b_a_chi[0] + 1)
0e08 : a8 __ __ TAY
0e09 : 10 04 __ BPL $0e0f ; (main.s28 + 0)
.s25:
0e0b : a9 00 __ LDA #$00
0e0d : f0 0f __ BEQ $0e1e ; (main.s26 + 0)
.s28:
0e0f : d0 0b __ BNE $0e1c ; (main.s24 + 0)
.s27:
0e11 : a9 5a __ LDA #$5a
0e13 : c5 57 __ CMP T1 + 0 
0e15 : a9 00 __ LDA #$00
0e17 : 2a __ __ ROL
0e18 : 49 01 __ EOR #$01
0e1a : 90 02 __ BCC $0e1e ; (main.s26 + 0)
.s24:
0e1c : a9 01 __ LDA #$01
.s26:
0e1e : 49 ff __ EOR #$ff
0e20 : c9 ff __ CMP #$ff
0e22 : f0 0e __ BEQ $0e32 ; (main.s29 + 0)
.s105:
0e24 : 38 __ __ SEC
0e25 : a5 57 __ LDA T1 + 0 
0e27 : e9 3a __ SBC #$3a
0e29 : 9d 50 24 STA $2450,x ; (b_a_chi[0] + 0)
0e2c : 98 __ __ TYA
0e2d : e9 00 __ SBC #$00
0e2f : 9d 51 24 STA $2451,x ; (b_a_chi[0] + 1)
.s29:
0e32 : 38 __ __ SEC
0e33 : a5 51 __ LDA T7 + 0 
0e35 : e9 01 __ SBC #$01
0e37 : 8d e3 22 STA $22e3 ; (b_v_bi + 0)
0e3a : a5 52 __ LDA T7 + 1 
0e3c : e9 00 __ SBC #$00
0e3e : 8d e4 22 STA $22e4 ; (b_v_bi + 1)
0e41 : 10 04 __ BPL $0e47 ; (main.s31 + 0)
.s30:
0e43 : a9 01 __ LDA #$01
0e45 : d0 02 __ BNE $0e49 ; (main.s32 + 0)
.s31:
0e47 : a9 00 __ LDA #$00
.s32:
0e49 : 49 ff __ EOR #$ff
0e4b : c9 ff __ CMP #$ff
0e4d : f0 0a __ BEQ $0e59 ; (main.s33 + 0)
.s104:
0e4f : a9 18 __ LDA #$18
0e51 : 8d e3 22 STA $22e3 ; (b_v_bi + 0)
0e54 : a9 00 __ LDA #$00
0e56 : 8d e4 22 STA $22e4 ; (b_v_bi + 1)
.s33:
0e59 : ad e3 22 LDA $22e3 ; (b_v_bi + 0)
0e5c : 85 43 __ STA T2 + 0 
0e5e : 0a __ __ ASL
0e5f : 85 1b __ STA ACCU + 0 
0e61 : ad e4 22 LDA $22e4 ; (b_v_bi + 1)
0e64 : 85 44 __ STA T2 + 1 
0e66 : 2a __ __ ROL
0e67 : 06 1b __ ASL ACCU + 0 
0e69 : 2a __ __ ROL
0e6a : a8 __ __ TAY
0e6b : 18 __ __ CLC
0e6c : a5 1b __ LDA ACCU + 0 
0e6e : 65 43 __ ADC T2 + 0 
0e70 : 85 57 __ STA T1 + 0 
0e72 : 98 __ __ TYA
0e73 : 65 44 __ ADC T2 + 1 
0e75 : 06 57 __ ASL T1 + 0 
0e77 : 2a __ __ ROL
0e78 : 06 57 __ ASL T1 + 0 
0e7a : 2a __ __ ROL
0e7b : 06 57 __ ASL T1 + 0 
0e7d : 2a __ __ ROL
0e7e : 18 __ __ CLC
0e7f : 69 d8 __ ADC #$d8
0e81 : a8 __ __ TAY
0e82 : 18 __ __ CLC
0e83 : a5 57 __ LDA T1 + 0 
0e85 : 65 53 __ ADC T0 + 0 
0e87 : 85 57 __ STA T1 + 0 
0e89 : 98 __ __ TYA
0e8a : 65 54 __ ADC T0 + 1 
0e8c : 85 58 __ STA T1 + 1 
0e8e : c9 e0 __ CMP #$e0
0e90 : 90 2e __ BCC $0ec0 ; (main.s34 + 0)
.s99:
0e92 : c9 ff __ CMP #$ff
0e94 : d0 04 __ BNE $0e9a ; (main.s103 + 0)
.s102:
0e96 : a5 57 __ LDA T1 + 0 
0e98 : c9 40 __ CMP #$40
.s103:
0e9a : b0 24 __ BCS $0ec0 ; (main.s34 + 0)
.s100:
0e9c : a0 01 __ LDY #$01
0e9e : b1 65 __ LDA (T12 + 0),y 
0ea0 : 85 1b __ STA ACCU + 0 
0ea2 : 4a __ __ LSR
0ea3 : 90 1b __ BCC $0ec0 ; (main.s34 + 0)
.s101:
0ea5 : a5 1b __ LDA ACCU + 0 
0ea7 : 29 fe __ AND #$fe
0ea9 : 91 65 __ STA (T12 + 0),y 
0eab : 18 __ __ CLC
0eac : a5 66 __ LDA T12 + 1 
0eae : 65 58 __ ADC T1 + 1 
0eb0 : 85 58 __ STA T1 + 1 
0eb2 : a9 0d __ LDA #$0d
0eb4 : a4 65 __ LDY T12 + 0 
0eb6 : 91 57 __ STA (T1 + 0),y 
0eb8 : a5 1b __ LDA ACCU + 0 
0eba : a0 01 __ LDY #$01
0ebc : 91 65 __ STA (T12 + 0),y 
0ebe : d0 0d __ BNE $0ecd ; (main.s35 + 0)
.s34:
0ec0 : 18 __ __ CLC
0ec1 : a5 66 __ LDA T12 + 1 
0ec3 : 65 58 __ ADC T1 + 1 
0ec5 : 85 58 __ STA T1 + 1 
0ec7 : a9 0d __ LDA #$0d
0ec9 : a4 65 __ LDY T12 + 0 
0ecb : 91 57 __ STA (T1 + 0),y 
.s35:
0ecd : 38 __ __ SEC
0ece : a5 43 __ LDA T2 + 0 
0ed0 : e9 01 __ SBC #$01
0ed2 : 8d e3 22 STA $22e3 ; (b_v_bi + 0)
0ed5 : a5 44 __ LDA T2 + 1 
0ed7 : e9 00 __ SBC #$00
0ed9 : 8d e4 22 STA $22e4 ; (b_v_bi + 1)
0edc : 10 04 __ BPL $0ee2 ; (main.s37 + 0)
.s36:
0ede : a9 01 __ LDA #$01
0ee0 : d0 02 __ BNE $0ee4 ; (main.s38 + 0)
.s37:
0ee2 : a9 00 __ LDA #$00
.s38:
0ee4 : 49 ff __ EOR #$ff
0ee6 : c9 ff __ CMP #$ff
0ee8 : f0 0a __ BEQ $0ef4 ; (main.s39 + 0)
.s98:
0eea : a9 18 __ LDA #$18
0eec : 8d e3 22 STA $22e3 ; (b_v_bi + 0)
0eef : a9 00 __ LDA #$00
0ef1 : 8d e4 22 STA $22e4 ; (b_v_bi + 1)
.s39:
0ef4 : ad e3 22 LDA $22e3 ; (b_v_bi + 0)
0ef7 : 0a __ __ ASL
0ef8 : 85 07 __ STA WORK + 4 
0efa : ad e4 22 LDA $22e4 ; (b_v_bi + 1)
0efd : 2a __ __ ROL
0efe : 06 07 __ ASL WORK + 4 
0f00 : 2a __ __ ROL
0f01 : a8 __ __ TAY
0f02 : 18 __ __ CLC
0f03 : a5 07 __ LDA WORK + 4 
0f05 : 6d e3 22 ADC $22e3 ; (b_v_bi + 0)
0f08 : 85 1b __ STA ACCU + 0 
0f0a : 98 __ __ TYA
0f0b : 6d e4 22 ADC $22e4 ; (b_v_bi + 1)
0f0e : 06 1b __ ASL ACCU + 0 
0f10 : 2a __ __ ROL
0f11 : 06 1b __ ASL ACCU + 0 
0f13 : 2a __ __ ROL
0f14 : 06 1b __ ASL ACCU + 0 
0f16 : 2a __ __ ROL
0f17 : 18 __ __ CLC
0f18 : 69 d8 __ ADC #$d8
0f1a : a8 __ __ TAY
0f1b : 18 __ __ CLC
0f1c : a5 1b __ LDA ACCU + 0 
0f1e : 65 53 __ ADC T0 + 0 
0f20 : 85 57 __ STA T1 + 0 
0f22 : 98 __ __ TYA
0f23 : 65 54 __ ADC T0 + 1 
0f25 : 85 58 __ STA T1 + 1 
0f27 : c9 e0 __ CMP #$e0
0f29 : 90 2e __ BCC $0f59 ; (main.s40 + 0)
.s93:
0f2b : c9 ff __ CMP #$ff
0f2d : d0 04 __ BNE $0f33 ; (main.s97 + 0)
.s96:
0f2f : a5 57 __ LDA T1 + 0 
0f31 : c9 40 __ CMP #$40
.s97:
0f33 : b0 24 __ BCS $0f59 ; (main.s40 + 0)
.s94:
0f35 : a0 01 __ LDY #$01
0f37 : b1 65 __ LDA (T12 + 0),y 
0f39 : 85 63 __ STA T11 + 0 
0f3b : 4a __ __ LSR
0f3c : 90 1b __ BCC $0f59 ; (main.s40 + 0)
.s95:
0f3e : a5 63 __ LDA T11 + 0 
0f40 : 29 fe __ AND #$fe
0f42 : 91 65 __ STA (T12 + 0),y 
0f44 : 18 __ __ CLC
0f45 : a5 66 __ LDA T12 + 1 
0f47 : 65 58 __ ADC T1 + 1 
0f49 : 85 58 __ STA T1 + 1 
0f4b : a9 05 __ LDA #$05
0f4d : a4 65 __ LDY T12 + 0 
0f4f : 91 57 __ STA (T1 + 0),y 
0f51 : a5 63 __ LDA T11 + 0 
0f53 : a0 01 __ LDY #$01
0f55 : 91 65 __ STA (T12 + 0),y 
0f57 : d0 0d __ BNE $0f66 ; (main.s41 + 0)
.s40:
0f59 : 18 __ __ CLC
0f5a : a5 66 __ LDA T12 + 1 
0f5c : 65 58 __ ADC T1 + 1 
0f5e : 85 58 __ STA T1 + 1 
0f60 : a9 05 __ LDA #$05
0f62 : a4 65 __ LDY T12 + 0 
0f64 : 91 57 __ STA (T1 + 0),y 
.s41:
0f66 : 86 60 __ STX T9 + 0 
0f68 : 18 __ __ CLC
0f69 : a5 51 __ LDA T7 + 0 
0f6b : 69 01 __ ADC #$01
0f6d : 9d 40 23 STA $2340,x ; (b_a_hi[0] + 0)
0f70 : a5 52 __ LDA T7 + 1 
0f72 : 69 00 __ ADC #$00
0f74 : 9d 41 23 STA $2341,x ; (b_a_hi[0] + 1)
0f77 : bd 00 24 LDA $2400,x ; (b_a_ei[0] + 0)
0f7a : 85 63 __ STA T11 + 0 
0f7c : 0a __ __ ASL
0f7d : 85 1b __ STA ACCU + 0 
0f7f : bd 01 24 LDA $2401,x ; (b_a_ei[0] + 1)
0f82 : 85 64 __ STA T11 + 1 
0f84 : 2a __ __ ROL
0f85 : 06 1b __ ASL ACCU + 0 
0f87 : 2a __ __ ROL
0f88 : aa __ __ TAX
0f89 : 18 __ __ CLC
0f8a : a5 1b __ LDA ACCU + 0 
0f8c : 65 63 __ ADC T11 + 0 
0f8e : 85 57 __ STA T1 + 0 
0f90 : 8a __ __ TXA
0f91 : 65 64 __ ADC T11 + 1 
0f93 : 06 57 __ ASL T1 + 0 
0f95 : 2a __ __ ROL
0f96 : 06 57 __ ASL T1 + 0 
0f98 : 2a __ __ ROL
0f99 : 06 57 __ ASL T1 + 0 
0f9b : 2a __ __ ROL
0f9c : 18 __ __ CLC
0f9d : 69 04 __ ADC #$04
0f9f : aa __ __ TAX
0fa0 : 18 __ __ CLC
0fa1 : a5 57 __ LDA T1 + 0 
0fa3 : 65 53 __ ADC T0 + 0 
0fa5 : 85 57 __ STA T1 + 0 
0fa7 : 8a __ __ TXA
0fa8 : 65 54 __ ADC T0 + 1 
0faa : 85 58 __ STA T1 + 1 
0fac : c9 e0 __ CMP #$e0
0fae : 90 2b __ BCC $0fdb ; (main.s42 + 0)
.s88:
0fb0 : c9 ff __ CMP #$ff
0fb2 : d0 04 __ BNE $0fb8 ; (main.s92 + 0)
.s91:
0fb4 : a5 57 __ LDA T1 + 0 
0fb6 : c9 40 __ CMP #$40
.s92:
0fb8 : b0 21 __ BCS $0fdb ; (main.s42 + 0)
.s89:
0fba : a0 01 __ LDY #$01
0fbc : b1 65 __ LDA (T12 + 0),y 
0fbe : aa __ __ TAX
0fbf : 4a __ __ LSR
0fc0 : 90 19 __ BCC $0fdb ; (main.s42 + 0)
.s90:
0fc2 : 8a __ __ TXA
0fc3 : 29 fe __ AND #$fe
0fc5 : 91 65 __ STA (T12 + 0),y 
0fc7 : 18 __ __ CLC
0fc8 : a5 66 __ LDA T12 + 1 
0fca : 65 58 __ ADC T1 + 1 
0fcc : 85 58 __ STA T1 + 1 
0fce : a9 20 __ LDA #$20
0fd0 : a4 65 __ LDY T12 + 0 
0fd2 : 91 57 __ STA (T1 + 0),y 
0fd4 : 8a __ __ TXA
0fd5 : a0 01 __ LDY #$01
0fd7 : 91 65 __ STA (T12 + 0),y 
0fd9 : d0 0d __ BNE $0fe8 ; (main.s43 + 0)
.s42:
0fdb : 18 __ __ CLC
0fdc : a5 66 __ LDA T12 + 1 
0fde : 65 58 __ ADC T1 + 1 
0fe0 : 85 58 __ STA T1 + 1 
0fe2 : a9 20 __ LDA #$20
0fe4 : a4 65 __ LDY T12 + 0 
0fe6 : 91 57 __ STA (T1 + 0),y 
.s43:
0fe8 : 18 __ __ CLC
0fe9 : a5 63 __ LDA T11 + 0 
0feb : 69 01 __ ADC #$01
0fed : a6 47 __ LDX T3 + 0 
0fef : 9d 00 24 STA $2400,x ; (b_a_ei[0] + 0)
0ff2 : a5 64 __ LDA T11 + 1 
0ff4 : 69 00 __ ADC #$00
0ff6 : 9d 01 24 STA $2401,x ; (b_a_ei[0] + 1)
0ff9 : a5 52 __ LDA T7 + 1 
0ffb : 10 04 __ BPL $1001 ; (main.s48 + 0)
.s45:
0ffd : a9 00 __ LDA #$00
0fff : f0 0f __ BEQ $1010 ; (main.s46 + 0)
.s48:
1001 : d0 0b __ BNE $100e ; (main.s44 + 0)
.s47:
1003 : a9 17 __ LDA #$17
1005 : c5 51 __ CMP T7 + 0 
1007 : a9 00 __ LDA #$00
1009 : 2a __ __ ROL
100a : 49 01 __ EOR #$01
100c : 90 02 __ BCC $1010 ; (main.s46 + 0)
.s44:
100e : a9 01 __ LDA #$01
.s46:
1010 : 49 ff __ EOR #$ff
1012 : c9 ff __ CMP #$ff
1014 : f0 03 __ BEQ $1019 ; (main.s49 + 0)
1016 : 4c 7b 11 JMP $117b ; (main.s77 + 0)
.s49:
1019 : a5 64 __ LDA T11 + 1 
101b : 10 04 __ BPL $1021 ; (main.s54 + 0)
.s51:
101d : a9 00 __ LDA #$00
101f : f0 0f __ BEQ $1030 ; (main.s52 + 0)
.s54:
1021 : d0 0b __ BNE $102e ; (main.s50 + 0)
.s53:
1023 : a9 17 __ LDA #$17
1025 : c5 63 __ CMP T11 + 0 
1027 : a9 00 __ LDA #$00
1029 : 2a __ __ ROL
102a : 49 01 __ EOR #$01
102c : 90 02 __ BCC $1030 ; (main.s52 + 0)
.s50:
102e : a9 01 __ LDA #$01
.s52:
1030 : 49 ff __ EOR #$ff
1032 : c9 ff __ CMP #$ff
1034 : f0 0a __ BEQ $1040 ; (main.s55 + 0)
.s76:
1036 : a9 00 __ LDA #$00
1038 : a6 60 __ LDX T9 + 0 
103a : 9d 00 24 STA $2400,x ; (b_a_ei[0] + 0)
103d : 9d 01 24 STA $2401,x ; (b_a_ei[0] + 1)
.s55:
1040 : 18 __ __ CLC
1041 : a5 53 __ LDA T0 + 0 
1043 : 69 01 __ ADC #$01
1045 : 8d df 22 STA $22df ; (b_v_ci + 0)
1048 : a5 54 __ LDA T0 + 1 
104a : 69 00 __ ADC #$00
104c : 8d e0 22 STA $22e0 ; (b_v_ci + 1)
104f : a5 55 __ LDA T0 + 2 
1051 : 69 00 __ ADC #$00
1053 : 8d e1 22 STA $22e1 ; (b_v_ci + 2)
1056 : a5 56 __ LDA T0 + 3 
1058 : 69 00 __ ADC #$00
105a : 8d e2 22 STA $22e2 ; (b_v_ci + 3)
105d : d0 14 __ BNE $1073 ; (main.s56 + 0)
.s73:
105f : ad e1 22 LDA $22e1 ; (b_v_ci + 2)
1062 : d0 0f __ BNE $1073 ; (main.s56 + 0)
.s74:
1064 : ad e0 22 LDA $22e0 ; (b_v_ci + 1)
1067 : d0 0a __ BNE $1073 ; (main.s56 + 0)
.s75:
1069 : a9 27 __ LDA #$27
106b : cd df 22 CMP $22df ; (b_v_ci + 0)
106e : 90 03 __ BCC $1073 ; (main.s56 + 0)
1070 : 4c 0a 0d JMP $0d0a ; (main.l19 + 0)
.s56:
1073 : a9 13 __ LDA #$13
1075 : 85 13 __ STA P6 
1077 : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
107a : 20 c9 16 JSR $16c9 ; (b_jiffy.s4 + 0)
107d : a5 1b __ LDA ACCU + 0 
107f : 85 53 __ STA T0 + 0 
1081 : a5 1c __ LDA ACCU + 1 
1083 : 85 54 __ STA T0 + 1 
1085 : a5 1d __ LDA ACCU + 2 
1087 : 85 55 __ STA T0 + 2 
1089 : a5 1e __ LDA ACCU + 3 
108b : 85 56 __ STA T0 + 3 
108d : a5 5b __ LDA T5 + 0 
108f : 85 1b __ STA ACCU + 0 
1091 : a5 5c __ LDA T5 + 1 
1093 : 85 1c __ STA ACCU + 1 
1095 : a5 5d __ LDA T5 + 2 
1097 : 85 1d __ STA ACCU + 2 
1099 : a5 5e __ LDA T5 + 3 
109b : 85 1e __ STA ACCU + 3 
109d : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
10a0 : a2 53 __ LDX #$53
10a2 : 20 cc 1b JSR $1bcc ; (freg + 4)
10a5 : a5 1e __ LDA ACCU + 3 
10a7 : 49 80 __ EOR #$80
10a9 : 85 1e __ STA ACCU + 3 
10ab : 20 13 1c JSR $1c13 ; (faddsub + 6)
10ae : a5 1b __ LDA ACCU + 0 
10b0 : 85 53 __ STA T0 + 0 
10b2 : a5 1c __ LDA ACCU + 1 
10b4 : 85 54 __ STA T0 + 1 
10b6 : a5 1d __ LDA ACCU + 2 
10b8 : 85 55 __ STA T0 + 2 
10ba : a5 1e __ LDA ACCU + 3 
10bc : 85 56 __ STA T0 + 3 
10be : 29 7f __ AND #$7f
10c0 : 05 1d __ ORA ACCU + 2 
10c2 : 05 1c __ ORA ACCU + 1 
10c4 : 05 1b __ ORA ACCU + 0 
10c6 : f0 04 __ BEQ $10cc ; (main.s71 + 0)
.s72:
10c8 : 24 1e __ BIT ACCU + 3 
10ca : 30 04 __ BMI $10d0 ; (main.s57 + 0)
.s71:
10cc : a9 20 __ LDA #$20
10ce : d0 08 __ BNE $10d8 ; (main.s58 + 0)
.s57:
10d0 : a5 1e __ LDA ACCU + 3 
10d2 : 49 80 __ EOR #$80
10d4 : 85 56 __ STA T0 + 3 
10d6 : a9 2d __ LDA #$2d
.s58:
10d8 : 85 13 __ STA P6 
10da : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
10dd : a5 56 __ LDA T0 + 3 
10df : 29 7f __ AND #$7f
10e1 : 05 55 __ ORA T0 + 2 
10e3 : 05 54 __ ORA T0 + 1 
10e5 : 05 53 __ ORA T0 + 0 
10e7 : d0 18 __ BNE $1101 ; (main.s59 + 0)
.s70:
10e9 : a9 30 __ LDA #$30
10eb : 85 13 __ STA P6 
10ed : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
.s61:
10f0 : a9 20 __ LDA #$20
10f2 : 85 13 __ STA P6 
10f4 : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
10f7 : a9 0d __ LDA #$0d
10f9 : 85 13 __ STA P6 
10fb : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
10fe : 4c d1 0c JMP $0cd1 ; (main.l18 + 0)
.s59:
1101 : a5 53 __ LDA T0 + 0 
1103 : 85 0f __ STA P2 
1105 : a5 54 __ LDA T0 + 1 
1107 : 85 10 __ STA P3 
1109 : a5 55 __ LDA T0 + 2 
110b : 85 11 __ STA P4 
110d : a5 56 __ LDA T0 + 3 
110f : 85 12 __ STA P5 
1111 : a9 a8 __ LDA #$a8
1113 : 85 0d __ STA P0 
1115 : a9 9f __ LDA #$9f
1117 : 85 0e __ STA P1 
1119 : 20 ea 16 JSR $16ea ; (b_ftoa.s4 + 0)
111c : a9 2e __ LDA #$2e
111e : 85 0f __ STA P2 
1120 : a9 00 __ LDA #$00
1122 : 85 10 __ STA P3 
1124 : 20 54 1b JSR $1b54 ; (strchr.l4 + 0)
1127 : a5 1b __ LDA ACCU + 0 
1129 : 05 1c __ ORA ACCU + 1 
112b : f0 2a __ BEQ $1157 ; (main.s60 + 0)
.s63:
112d : a9 a8 __ LDA #$a8
112f : 85 0d __ STA P0 
1131 : a9 9f __ LDA #$9f
1133 : 85 0e __ STA P1 
1135 : 20 76 1b JSR $1b76 ; (strlen.s4 + 0)
1138 : a5 1c __ LDA ACCU + 1 
113a : 30 1b __ BMI $1157 ; (main.s60 + 0)
.s69:
113c : d0 06 __ BNE $1144 ; (main.s133 + 0)
.s68:
113e : a5 1b __ LDA ACCU + 0 
1140 : c9 02 __ CMP #$02
1142 : 90 13 __ BCC $1157 ; (main.s60 + 0)
.s133:
1144 : a6 1b __ LDX ACCU + 0 
.l64:
1146 : bd a7 9f LDA $9fa7,x ; (main@stack + 22)
1149 : c9 30 __ CMP #$30
114b : d0 23 __ BNE $1170 ; (main.s65 + 0)
.s67:
114d : a9 00 __ LDA #$00
114f : 9d a7 9f STA $9fa7,x ; (main@stack + 22)
1152 : ca __ __ DEX
1153 : e0 02 __ CPX #$02
1155 : b0 ef __ BCS $1146 ; (main.l64 + 0)
.s60:
1157 : ad a8 9f LDA $9fa8 ; (buf[0] + 0)
115a : f0 94 __ BEQ $10f0 ; (main.s61 + 0)
.s62:
115c : a2 00 __ LDX #$00
115e : 86 57 __ STX T1 + 0 
.l132:
1160 : 85 13 __ STA P6 
1162 : 20 7c 14 JSR $147c ; (b_putc.s4 + 0)
1165 : e6 57 __ INC T1 + 0 
1167 : a6 57 __ LDX T1 + 0 
1169 : bd a8 9f LDA $9fa8,x ; (buf[0] + 0)
116c : d0 f2 __ BNE $1160 ; (main.l132 + 0)
116e : f0 80 __ BEQ $10f0 ; (main.s61 + 0)
.s65:
1170 : c9 2e __ CMP #$2e
1172 : d0 e3 __ BNE $1157 ; (main.s60 + 0)
.s66:
1174 : a9 00 __ LDA #$00
1176 : 9d a7 9f STA $9fa7,x ; (main@stack + 22)
1179 : f0 dc __ BEQ $1157 ; (main.s60 + 0)
.s77:
117b : a9 00 __ LDA #$00
117d : 85 06 __ STA WORK + 3 
117f : 9d 40 23 STA $2340,x ; (b_a_hi[0] + 0)
1182 : 9d 41 23 STA $2341,x ; (b_a_hi[0] + 1)
1185 : ad d3 22 LDA $22d3 ; (b_rndSeed + 0)
1188 : 85 1b __ STA ACCU + 0 
118a : ad d4 22 LDA $22d4 ; (b_rndSeed + 1)
118d : 85 1c __ STA ACCU + 1 
118f : ad d5 22 LDA $22d5 ; (b_rndSeed + 2)
1192 : 85 1d __ STA ACCU + 2 
1194 : ad d6 22 LDA $22d6 ; (b_rndSeed + 3)
1197 : 85 1e __ STA ACCU + 3 
1199 : a9 cd __ LDA #$cd
119b : 85 03 __ STA WORK + 0 
119d : a9 01 __ LDA #$01
119f : 85 05 __ STA WORK + 2 
11a1 : a9 0d __ LDA #$0d
11a3 : 85 04 __ STA WORK + 1 
11a5 : 20 78 20 JSR $2078 ; (mul32 + 0)
11a8 : 18 __ __ CLC
11a9 : a5 07 __ LDA WORK + 4 
11ab : 69 39 __ ADC #$39
11ad : 85 57 __ STA T1 + 0 
11af : a5 08 __ LDA WORK + 5 
11b1 : 69 30 __ ADC #$30
11b3 : 85 58 __ STA T1 + 1 
11b5 : 85 1b __ STA ACCU + 0 
11b7 : a5 09 __ LDA WORK + 6 
11b9 : 69 00 __ ADC #$00
11bb : 85 59 __ STA T1 + 2 
11bd : 85 1c __ STA ACCU + 1 
11bf : a5 0a __ LDA WORK + 7 
11c1 : 69 00 __ ADC #$00
11c3 : 85 5a __ STA T1 + 3 
11c5 : 85 1d __ STA ACCU + 2 
11c7 : a9 00 __ LDA #$00
11c9 : 85 1e __ STA ACCU + 3 
11cb : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
11ce : a9 00 __ LDA #$00
11d0 : 85 03 __ STA WORK + 0 
11d2 : 85 04 __ STA WORK + 1 
11d4 : a9 80 __ LDA #$80
11d6 : 85 05 __ STA WORK + 2 
11d8 : a9 4b __ LDA #$4b
11da : 85 06 __ STA WORK + 3 
11dc : 20 dc 1b JSR $1bdc ; (freg + 20)
11df : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
11e2 : a9 00 __ LDA #$00
11e4 : 85 03 __ STA WORK + 0 
11e6 : 85 04 __ STA WORK + 1 
11e8 : a9 68 __ LDA #$68
11ea : 85 05 __ STA WORK + 2 
11ec : a9 42 __ LDA #$42
11ee : 85 06 __ STA WORK + 3 
11f0 : 20 dc 1b JSR $1bdc ; (freg + 20)
11f3 : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
11f6 : a5 1b __ LDA ACCU + 0 
11f8 : 85 43 __ STA T2 + 0 
11fa : a5 1c __ LDA ACCU + 1 
11fc : 85 44 __ STA T2 + 1 
11fe : a5 1d __ LDA ACCU + 2 
1200 : 85 45 __ STA T2 + 2 
1202 : a5 1e __ LDA ACCU + 3 
1204 : 85 46 __ STA T2 + 3 
1206 : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
1209 : a5 1b __ LDA ACCU + 0 
120b : 85 47 __ STA T3 + 0 
120d : a5 1c __ LDA ACCU + 1 
120f : 85 48 __ STA T3 + 1 
1211 : a5 46 __ LDA T2 + 3 
1213 : 29 7f __ AND #$7f
1215 : 05 45 __ ORA T2 + 2 
1217 : 05 44 __ ORA T2 + 1 
1219 : 05 43 __ ORA T2 + 0 
121b : f0 39 __ BEQ $1256 ; (main.s78 + 0)
.s87:
121d : 24 46 __ BIT T2 + 3 
121f : 10 35 __ BPL $1256 ; (main.s78 + 0)
.s85:
1221 : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
1224 : a5 1b __ LDA ACCU + 0 
1226 : 85 03 __ STA WORK + 0 
1228 : a5 1c __ LDA ACCU + 1 
122a : 85 04 __ STA WORK + 1 
122c : a5 1d __ LDA ACCU + 2 
122e : 85 05 __ STA WORK + 2 
1230 : a5 1e __ LDA ACCU + 3 
1232 : 85 06 __ STA WORK + 3 
1234 : a5 43 __ LDA T2 + 0 
1236 : 85 1b __ STA ACCU + 0 
1238 : a5 44 __ LDA T2 + 1 
123a : 85 1c __ STA ACCU + 1 
123c : a5 45 __ LDA T2 + 2 
123e : 85 1d __ STA ACCU + 2 
1240 : a5 46 __ LDA T2 + 3 
1242 : 85 1e __ STA ACCU + 3 
1244 : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
1247 : f0 0d __ BEQ $1256 ; (main.s78 + 0)
.s86:
1249 : 18 __ __ CLC
124a : a5 47 __ LDA T3 + 0 
124c : 69 ff __ ADC #$ff
124e : a8 __ __ TAY
124f : a5 48 __ LDA T3 + 1 
1251 : 69 ff __ ADC #$ff
1253 : 4c 5a 12 JMP $125a ; (main.s79 + 0)
.s78:
1256 : a5 48 __ LDA T3 + 1 
1258 : a4 47 __ LDY T3 + 0 
.s79:
125a : aa __ __ TAX
125b : 98 __ __ TYA
125c : 18 __ __ CLC
125d : 69 21 __ ADC #$21
125f : a4 5f __ LDY T8 + 0 
1261 : 99 50 24 STA $2450,y ; (b_a_chi[0] + 0)
1264 : 8a __ __ TXA
1265 : 69 00 __ ADC #$00
1267 : 99 51 24 STA $2451,y ; (b_a_chi[0] + 1)
126a : a5 57 __ LDA T1 + 0 
126c : 85 1b __ STA ACCU + 0 
126e : a5 58 __ LDA T1 + 1 
1270 : 85 1c __ STA ACCU + 1 
1272 : a5 59 __ LDA T1 + 2 
1274 : 85 1d __ STA ACCU + 2 
1276 : a5 5a __ LDA T1 + 3 
1278 : 85 1e __ STA ACCU + 3 
127a : a9 cd __ LDA #$cd
127c : 85 03 __ STA WORK + 0 
127e : a9 00 __ LDA #$00
1280 : 85 06 __ STA WORK + 3 
1282 : a9 0d __ LDA #$0d
1284 : 85 04 __ STA WORK + 1 
1286 : a9 01 __ LDA #$01
1288 : 85 05 __ STA WORK + 2 
128a : 20 78 20 JSR $2078 ; (mul32 + 0)
128d : 18 __ __ CLC
128e : a5 07 __ LDA WORK + 4 
1290 : 69 39 __ ADC #$39
1292 : 8d d3 22 STA $22d3 ; (b_rndSeed + 0)
1295 : a5 08 __ LDA WORK + 5 
1297 : 69 30 __ ADC #$30
1299 : 8d d4 22 STA $22d4 ; (b_rndSeed + 1)
129c : 85 1b __ STA ACCU + 0 
129e : a5 09 __ LDA WORK + 6 
12a0 : 69 00 __ ADC #$00
12a2 : 8d d5 22 STA $22d5 ; (b_rndSeed + 2)
12a5 : 85 1c __ STA ACCU + 1 
12a7 : a5 0a __ LDA WORK + 7 
12a9 : 69 00 __ ADC #$00
12ab : 8d d6 22 STA $22d6 ; (b_rndSeed + 3)
12ae : 85 1d __ STA ACCU + 2 
12b0 : a9 00 __ LDA #$00
12b2 : 85 1e __ STA ACCU + 3 
12b4 : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
12b7 : a9 00 __ LDA #$00
12b9 : 85 03 __ STA WORK + 0 
12bb : 85 04 __ STA WORK + 1 
12bd : a9 80 __ LDA #$80
12bf : 85 05 __ STA WORK + 2 
12c1 : a9 4b __ LDA #$4b
12c3 : 85 06 __ STA WORK + 3 
12c5 : 20 dc 1b JSR $1bdc ; (freg + 20)
12c8 : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
12cb : a9 00 __ LDA #$00
12cd : 85 03 __ STA WORK + 0 
12cf : 85 04 __ STA WORK + 1 
12d1 : a9 a0 __ LDA #$a0
12d3 : 85 05 __ STA WORK + 2 
12d5 : a9 40 __ LDA #$40
12d7 : 85 06 __ STA WORK + 3 
12d9 : 20 dc 1b JSR $1bdc ; (freg + 20)
12dc : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
12df : a5 1b __ LDA ACCU + 0 
12e1 : 85 57 __ STA T1 + 0 
12e3 : a5 1c __ LDA ACCU + 1 
12e5 : 85 58 __ STA T1 + 1 
12e7 : a5 1d __ LDA ACCU + 2 
12e9 : 85 59 __ STA T1 + 2 
12eb : a5 1e __ LDA ACCU + 3 
12ed : 85 5a __ STA T1 + 3 
12ef : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
12f2 : a5 1b __ LDA ACCU + 0 
12f4 : 85 43 __ STA T2 + 0 
12f6 : a5 1c __ LDA ACCU + 1 
12f8 : 85 44 __ STA T2 + 1 
12fa : a5 5a __ LDA T1 + 3 
12fc : 29 7f __ AND #$7f
12fe : 05 59 __ ORA T1 + 2 
1300 : 05 58 __ ORA T1 + 1 
1302 : 05 57 __ ORA T1 + 0 
1304 : f0 39 __ BEQ $133f ; (main.s80 + 0)
.s84:
1306 : 24 5a __ BIT T1 + 3 
1308 : 10 35 __ BPL $133f ; (main.s80 + 0)
.s82:
130a : 20 bb 1f JSR $1fbb ; (sint32_to_float + 0)
130d : a5 1b __ LDA ACCU + 0 
130f : 85 03 __ STA WORK + 0 
1311 : a5 1c __ LDA ACCU + 1 
1313 : 85 04 __ STA WORK + 1 
1315 : a5 1d __ LDA ACCU + 2 
1317 : 85 05 __ STA WORK + 2 
1319 : a5 1e __ LDA ACCU + 3 
131b : 85 06 __ STA WORK + 3 
131d : a5 57 __ LDA T1 + 0 
131f : 85 1b __ STA ACCU + 0 
1321 : a5 58 __ LDA T1 + 1 
1323 : 85 1c __ STA ACCU + 1 
1325 : a5 59 __ LDA T1 + 2 
1327 : 85 1d __ STA ACCU + 2 
1329 : a5 5a __ LDA T1 + 3 
132b : 85 1e __ STA ACCU + 3 
132d : 20 29 20 JSR $2029 ; (crt_fcmp + 0)
1330 : f0 0d __ BEQ $133f ; (main.s80 + 0)
.s83:
1332 : 18 __ __ CLC
1333 : a5 43 __ LDA T2 + 0 
1335 : 69 ff __ ADC #$ff
1337 : a8 __ __ TAY
1338 : a5 44 __ LDA T2 + 1 
133a : 69 ff __ ADC #$ff
133c : 4c 43 13 JMP $1343 ; (main.s81 + 0)
.s80:
133f : a5 44 __ LDA T2 + 1 
1341 : a4 43 __ LDY T2 + 0 
.s81:
1343 : aa __ __ TAX
1344 : 98 __ __ TYA
1345 : 18 __ __ CLC
1346 : 69 01 __ ADC #$01
1348 : a4 62 __ LDY T10 + 0 
134a : 99 a0 24 STA $24a0,y ; (b_a_di[0] + 0)
134d : 8a __ __ TXA
134e : 69 00 __ ADC #$00
1350 : 99 a1 24 STA $24a1,y ; (b_a_di[0] + 1)
1353 : 4c 19 10 JMP $1019 ; (main.s49 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1356 : ad 49 22 LDA $2249 ; (b_mem + 0)
1359 : 85 43 __ STA T1 + 0 
135b : 85 45 __ STA T2 + 0 
135d : 85 1f __ STA ADDR + 0 
135f : ad 4a 22 LDA $224a ; (b_mem + 1)
1362 : 85 44 __ STA T1 + 1 
1364 : 18 __ __ CLC
1365 : 69 dd __ ADC #$dd
1367 : 85 20 __ STA ADDR + 1 
1369 : a9 03 __ LDA #$03
136b : a0 00 __ LDY #$00
136d : 91 1f __ STA (ADDR + 0),y 
136f : 18 __ __ CLC
1370 : a5 44 __ LDA T1 + 1 
1372 : 69 d0 __ ADC #$d0
1374 : 85 20 __ STA ADDR + 1 
1376 : a9 15 __ LDA #$15
1378 : a0 18 __ LDY #$18
137a : 91 1f __ STA (ADDR + 0),y 
137c : 18 __ __ CLC
137d : a5 44 __ LDA T1 + 1 
137f : 69 02 __ ADC #$02
1381 : 85 20 __ STA ADDR + 1 
1383 : a9 0e __ LDA #$0e
1385 : a0 86 __ LDY #$86
1387 : 91 1f __ STA (ADDR + 0),y 
1389 : 18 __ __ CLC
138a : a5 44 __ LDA T1 + 1 
138c : 69 d8 __ ADC #$d8
138e : 85 46 __ STA T2 + 1 
1390 : a9 00 __ LDA #$00
1392 : 85 47 __ STA T3 + 0 
1394 : 85 48 __ STA T3 + 1 
.l5:
1396 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
1399 : 18 __ __ CLC
139a : a5 43 __ LDA T1 + 0 
139c : 65 1b __ ADC ACCU + 0 
139e : 85 1b __ STA ACCU + 0 
13a0 : a5 44 __ LDA T1 + 1 
13a2 : 65 1c __ ADC ACCU + 1 
13a4 : 18 __ __ CLC
13a5 : 65 48 __ ADC T3 + 1 
13a7 : 85 1c __ STA ACCU + 1 
13a9 : a9 20 __ LDA #$20
13ab : a4 47 __ LDY T3 + 0 
13ad : 91 1b __ STA (ACCU + 0),y 
13af : a9 0e __ LDA #$0e
13b1 : a0 00 __ LDY #$00
13b3 : 91 45 __ STA (T2 + 0),y 
13b5 : e6 45 __ INC T2 + 0 
13b7 : d0 02 __ BNE $13bb ; (b_init.s9 + 0)
.s8:
13b9 : e6 46 __ INC T2 + 1 
.s9:
13bb : e6 47 __ INC T3 + 0 
13bd : d0 02 __ BNE $13c1 ; (b_init.s11 + 0)
.s10:
13bf : e6 48 __ INC T3 + 1 
.s11:
13c1 : a5 48 __ LDA T3 + 1 
13c3 : c9 03 __ CMP #$03
13c5 : d0 cf __ BNE $1396 ; (b_init.l5 + 0)
.s7:
13c7 : a5 47 __ LDA T3 + 0 
13c9 : c9 e8 __ CMP #$e8
13cb : d0 c9 __ BNE $1396 ; (b_init.l5 + 0)
.s6:
13cd : a5 43 __ LDA T1 + 0 
13cf : 85 1f __ STA ADDR + 0 
13d1 : a5 44 __ LDA T1 + 1 
13d3 : 69 cf __ ADC #$cf
13d5 : 85 20 __ STA ADDR + 1 
13d7 : a9 0e __ LDA #$0e
13d9 : a0 20 __ LDY #$20
13db : 91 1f __ STA (ADDR + 0),y 
13dd : a9 06 __ LDA #$06
13df : c8 __ __ INY
13e0 : 91 1f __ STA (ADDR + 0),y 
13e2 : a9 00 __ LDA #$00
13e4 : a0 c6 __ LDY #$c6
13e6 : 91 43 __ STA (T1 + 0),y 
13e8 : 8d 4f 22 STA $224f ; (b_gosubSP + 0)
13eb : 8d 50 22 STA $2250 ; (b_gosubSP + 1)
13ee : 8d 4d 22 STA $224d ; (b_row + 0)
13f1 : 8d 4e 22 STA $224e ; (b_row + 1)
13f4 : 8d 4b 22 STA $224b ; (b_col + 0)
13f7 : 8d 4c 22 STA $224c ; (b_col + 1)
.s3:
13fa : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
13fb : ad 49 22 LDA $2249 ; (b_mem + 0)
13fe : 85 1f __ STA ADDR + 0 
1400 : ad 4a 22 LDA $224a ; (b_mem + 1)
1403 : 18 __ __ CLC
1404 : 69 dd __ ADC #$dd
1406 : 85 20 __ STA ADDR + 1 
1408 : a0 00 __ LDY #$00
140a : 84 1b __ STY ACCU + 0 
140c : b1 1f __ LDA (ADDR + 0),y 
140e : 29 03 __ AND #$03
1410 : 49 03 __ EOR #$03
1412 : aa __ __ TAX
1413 : 18 __ __ CLC
1414 : a5 1f __ LDA ADDR + 0 
1416 : 69 18 __ ADC #$18
1418 : 85 1f __ STA ADDR + 0 
141a : ad 4a 22 LDA $224a ; (b_mem + 1)
141d : 69 d0 __ ADC #$d0
141f : 85 20 __ STA ADDR + 1 
1421 : b1 1f __ LDA (ADDR + 0),y 
1423 : 29 f0 __ AND #$f0
1425 : 4a __ __ LSR
1426 : 4a __ __ LSR
1427 : 1d 44 22 ORA $2244,x ; (__multab16384H + 0)
142a : 85 1c __ STA ACCU + 1 
.s3:
142c : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1282, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
142d : ad 51 22 LDA $2251 ; (tsb_inited + 0)
1430 : 0d 52 22 ORA $2252 ; (tsb_inited + 1)
1433 : d0 18 __ BNE $144d ; (tsb_init.s3 + 0)
.s5:
1435 : 85 0d __ STA P0 
1437 : 85 0e __ STA P1 
1439 : 85 10 __ STA P3 
143b : a9 01 __ LDA #$01
143d : 85 0f __ STA P2 
143f : 8d 51 22 STA $2251 ; (tsb_inited + 0)
1442 : a9 00 __ LDA #$00
1444 : 8d 52 22 STA $2252 ; (tsb_inited + 1)
1447 : 20 4e 14 JSR $144e ; (tsb_init_tables.s4 + 0)
144a : 4c 5c 14 JMP $145c ; (tsb_rot.s4 + 0)
.s3:
144d : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1270, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
144e : a2 00 __ LDX #$00
.l5:
1450 : bd 53 22 LDA $2253,x ; (tab[0] + 0)
1453 : 9d 00 23 STA $2300,x ; (tsb_sintab[0] + 0)
1456 : e8 __ __ INX
1457 : e0 40 __ CPX #$40
1459 : d0 f5 __ BNE $1450 ; (tsb_init_tables.l5 + 0)
.s3:
145b : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
145c : a5 0d __ LDA P0 ; (angle + 0)
145e : 29 07 __ AND #$07
1460 : 0a __ __ ASL
1461 : 0a __ __ ASL
1462 : 0a __ __ ASL
1463 : aa __ __ TAX
1464 : a9 00 __ LDA #$00
1466 : 85 1b __ STA ACCU + 0 
.l5:
1468 : 8a __ __ TXA
1469 : 65 1b __ ADC ACCU + 0 
146b : a8 __ __ TAY
146c : b9 93 22 LDA $2293,y ; (tsb_rottab[0] + 0)
146f : a4 1b __ LDY ACCU + 0 
1471 : c8 __ __ INY
1472 : 84 1b __ STY ACCU + 0 
1474 : 99 d6 22 STA $22d6,y ; (b_rndSeed + 3)
1477 : c0 08 __ CPY #$08
1479 : 90 ed __ BCC $1468 ; (tsb_rot.l5 + 0)
.s3:
147b : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
147c : a5 13 __ LDA P6 ; (c + 0)
147e : c9 93 __ CMP #$93
1480 : d0 03 __ BNE $1485 ; (b_putc.s5 + 0)
1482 : 4c 13 15 JMP $1513 ; (b_putc.s14 + 0)
.s5:
1485 : c9 13 __ CMP #$13
1487 : d0 0d __ BNE $1496 ; (b_putc.s6 + 0)
.s13:
1489 : a9 00 __ LDA #$00
148b : 8d 4d 22 STA $224d ; (b_row + 0)
148e : 8d 4e 22 STA $224e ; (b_row + 1)
1491 : 8d 4b 22 STA $224b ; (b_col + 0)
1494 : f0 76 __ BEQ $150c ; (b_putc.s17 + 0)
.s6:
1496 : c9 0d __ CMP #$0d
1498 : f0 76 __ BEQ $1510 ; (b_putc.s12 + 0)
.s7:
149a : ad 4c 22 LDA $224c ; (b_col + 1)
149d : 30 0c __ BMI $14ab ; (b_putc.s8 + 0)
.s11:
149f : d0 07 __ BNE $14a8 ; (b_putc.s9 + 0)
.s10:
14a1 : ad 4b 22 LDA $224b ; (b_col + 0)
14a4 : c9 28 __ CMP #$28
14a6 : 90 03 __ BCC $14ab ; (b_putc.s8 + 0)
.s9:
14a8 : 20 57 15 JSR $1557 ; (b_newline.s4 + 0)
.s8:
14ab : a5 13 __ LDA P6 ; (c + 0)
14ad : 20 b3 16 JSR $16b3 ; (b_pet2scr.s4 + 0)
14b0 : 85 4e __ STA T3 + 0 
14b2 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
14b5 : ad 49 22 LDA $2249 ; (b_mem + 0)
14b8 : 18 __ __ CLC
14b9 : 65 1b __ ADC ACCU + 0 
14bb : 85 4a __ STA T1 + 0 
14bd : ad 4a 22 LDA $224a ; (b_mem + 1)
14c0 : 65 1c __ ADC ACCU + 1 
14c2 : 85 4b __ STA T1 + 1 
14c4 : ad 4d 22 LDA $224d ; (b_row + 0)
14c7 : 0a __ __ ASL
14c8 : 85 07 __ STA WORK + 4 
14ca : ad 4e 22 LDA $224e ; (b_row + 1)
14cd : 2a __ __ ROL
14ce : 06 07 __ ASL WORK + 4 
14d0 : 2a __ __ ROL
14d1 : aa __ __ TAX
14d2 : 18 __ __ CLC
14d3 : a5 07 __ LDA WORK + 4 
14d5 : 6d 4d 22 ADC $224d ; (b_row + 0)
14d8 : 85 1b __ STA ACCU + 0 
14da : 8a __ __ TXA
14db : 6d 4e 22 ADC $224e ; (b_row + 1)
14de : 06 1b __ ASL ACCU + 0 
14e0 : 2a __ __ ROL
14e1 : 06 1b __ ASL ACCU + 0 
14e3 : 2a __ __ ROL
14e4 : 06 1b __ ASL ACCU + 0 
14e6 : 2a __ __ ROL
14e7 : 85 1c __ STA ACCU + 1 
14e9 : ad 4b 22 LDA $224b ; (b_col + 0)
14ec : aa __ __ TAX
14ed : 18 __ __ CLC
14ee : 65 1b __ ADC ACCU + 0 
14f0 : a8 __ __ TAY
14f1 : ad 4c 22 LDA $224c ; (b_col + 1)
14f4 : 85 4d __ STA T2 + 1 
14f6 : 65 1c __ ADC ACCU + 1 
14f8 : 18 __ __ CLC
14f9 : 65 4b __ ADC T1 + 1 
14fb : 85 4b __ STA T1 + 1 
14fd : a5 4e __ LDA T3 + 0 
14ff : 91 4a __ STA (T1 + 0),y 
1501 : 8a __ __ TXA
1502 : 18 __ __ CLC
1503 : 69 01 __ ADC #$01
1505 : 8d 4b 22 STA $224b ; (b_col + 0)
1508 : a5 4d __ LDA T2 + 1 
150a : 69 00 __ ADC #$00
.s17:
150c : 8d 4c 22 STA $224c ; (b_col + 1)
.s3:
150f : 60 __ __ RTS
.s12:
1510 : 4c 57 15 JMP $1557 ; (b_newline.s4 + 0)
.s14:
1513 : a9 00 __ LDA #$00
1515 : 8d 4d 22 STA $224d ; (b_row + 0)
1518 : 8d 4e 22 STA $224e ; (b_row + 1)
151b : 8d 4b 22 STA $224b ; (b_col + 0)
151e : 8d 4c 22 STA $224c ; (b_col + 1)
1521 : 85 4c __ STA T2 + 0 
1523 : 85 4d __ STA T2 + 1 
.l15:
1525 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
1528 : ad 49 22 LDA $2249 ; (b_mem + 0)
152b : 18 __ __ CLC
152c : 65 1b __ ADC ACCU + 0 
152e : 85 4a __ STA T1 + 0 
1530 : ad 4a 22 LDA $224a ; (b_mem + 1)
1533 : 65 1c __ ADC ACCU + 1 
1535 : 18 __ __ CLC
1536 : 65 4d __ ADC T2 + 1 
1538 : 85 4b __ STA T1 + 1 
153a : a9 20 __ LDA #$20
153c : a4 4c __ LDY T2 + 0 
153e : 91 4a __ STA (T1 + 0),y 
1540 : 98 __ __ TYA
1541 : 18 __ __ CLC
1542 : 69 01 __ ADC #$01
1544 : 85 4c __ STA T2 + 0 
1546 : a5 4d __ LDA T2 + 1 
1548 : 69 00 __ ADC #$00
154a : 85 4d __ STA T2 + 1 
154c : c9 03 __ CMP #$03
154e : d0 d5 __ BNE $1525 ; (b_putc.l15 + 0)
.s16:
1550 : a5 4c __ LDA T2 + 0 
1552 : c9 e8 __ CMP #$e8
1554 : d0 cf __ BNE $1525 ; (b_putc.l15 + 0)
1556 : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1557 : a9 00 __ LDA #$00
1559 : 8d 4b 22 STA $224b ; (b_col + 0)
155c : 8d 4c 22 STA $224c ; (b_col + 1)
155f : ad 4d 22 LDA $224d ; (b_row + 0)
1562 : aa __ __ TAX
1563 : 18 __ __ CLC
1564 : 69 01 __ ADC #$01
1566 : 8d 4d 22 STA $224d ; (b_row + 0)
1569 : ad 4e 22 LDA $224e ; (b_row + 1)
156c : a8 __ __ TAY
156d : 69 00 __ ADC #$00
156f : 8d 4e 22 STA $224e ; (b_row + 1)
1572 : 98 __ __ TYA
1573 : 30 13 __ BMI $1588 ; (b_newline.s3 + 0)
.s7:
1575 : d0 04 __ BNE $157b ; (b_newline.s5 + 0)
.s6:
1577 : e0 18 __ CPX #$18
1579 : 90 0d __ BCC $1588 ; (b_newline.s3 + 0)
.s5:
157b : 20 89 15 JSR $1589 ; (b_scroll.s4 + 0)
157e : a9 18 __ LDA #$18
1580 : 8d 4d 22 STA $224d ; (b_row + 0)
1583 : a9 00 __ LDA #$00
1585 : 8d 4e 22 STA $224e ; (b_row + 1)
.s3:
1588 : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1589 : a9 c0 __ LDA #$c0
158b : 85 11 __ STA P4 
158d : a9 03 __ LDA #$03
158f : 85 12 __ STA P5 
1591 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
1594 : ad 49 22 LDA $2249 ; (b_mem + 0)
1597 : 85 45 __ STA T1 + 0 
1599 : 18 __ __ CLC
159a : 65 1b __ ADC ACCU + 0 
159c : 85 0d __ STA P0 
159e : ad 4a 22 LDA $224a ; (b_mem + 1)
15a1 : 85 46 __ STA T1 + 1 
15a3 : 65 1c __ ADC ACCU + 1 
15a5 : 85 0e __ STA P1 
15a7 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
15aa : 18 __ __ CLC
15ab : a5 45 __ LDA T1 + 0 
15ad : 65 1b __ ADC ACCU + 0 
15af : aa __ __ TAX
15b0 : a5 46 __ LDA T1 + 1 
15b2 : 65 1c __ ADC ACCU + 1 
15b4 : a8 __ __ TAY
15b5 : 8a __ __ TXA
15b6 : 18 __ __ CLC
15b7 : 69 28 __ ADC #$28
15b9 : 85 0f __ STA P2 
15bb : 90 01 __ BCC $15be ; (b_scroll.s7 + 0)
.s6:
15bd : c8 __ __ INY
.s7:
15be : 84 10 __ STY P3 
15c0 : 20 1e 16 JSR $161e ; (memmove.s4 + 0)
15c3 : a9 03 __ LDA #$03
15c5 : 85 12 __ STA P5 
15c7 : 18 __ __ CLC
15c8 : a5 46 __ LDA T1 + 1 
15ca : 69 d8 __ ADC #$d8
15cc : 85 0e __ STA P1 
15ce : a5 45 __ LDA T1 + 0 
15d0 : 85 0d __ STA P0 
15d2 : 18 __ __ CLC
15d3 : 69 28 __ ADC #$28
15d5 : 85 0f __ STA P2 
15d7 : a5 46 __ LDA T1 + 1 
15d9 : 69 d8 __ ADC #$d8
15db : 85 10 __ STA P3 
15dd : 20 1e 16 JSR $161e ; (memmove.s4 + 0)
15e0 : 18 __ __ CLC
15e1 : a5 45 __ LDA T1 + 0 
15e3 : 69 c0 __ ADC #$c0
15e5 : 85 47 __ STA T2 + 0 
15e7 : a5 46 __ LDA T1 + 1 
15e9 : 69 db __ ADC #$db
15eb : 85 48 __ STA T2 + 1 
15ed : a9 00 __ LDA #$00
15ef : 85 49 __ STA T3 + 0 
.l5:
15f1 : 20 fb 13 JSR $13fb ; (b_scr_base.s4 + 0)
15f4 : 18 __ __ CLC
15f5 : a5 45 __ LDA T1 + 0 
15f7 : 65 1b __ ADC ACCU + 0 
15f9 : a8 __ __ TAY
15fa : a5 46 __ LDA T1 + 1 
15fc : 65 1c __ ADC ACCU + 1 
15fe : aa __ __ TAX
15ff : 98 __ __ TYA
1600 : 18 __ __ CLC
1601 : 65 49 __ ADC T3 + 0 
1603 : 85 1f __ STA ADDR + 0 
1605 : 8a __ __ TXA
1606 : 69 03 __ ADC #$03
1608 : 85 20 __ STA ADDR + 1 
160a : a9 20 __ LDA #$20
160c : a0 c0 __ LDY #$c0
160e : 91 1f __ STA (ADDR + 0),y 
1610 : a9 0e __ LDA #$0e
1612 : a4 49 __ LDY T3 + 0 
1614 : 91 47 __ STA (T2 + 0),y 
1616 : c8 __ __ INY
1617 : 84 49 __ STY T3 + 0 
1619 : c0 28 __ CPY #$28
161b : 90 d4 __ BCC $15f1 ; (b_scroll.l5 + 0)
.s3:
161d : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
161e : a5 12 __ LDA P5 ; (size + 1)
1620 : 30 65 __ BMI $1687 ; (memmove.s5 + 0)
.s14:
1622 : 05 11 __ ORA P4 ; (size + 0)
1624 : f0 61 __ BEQ $1687 ; (memmove.s5 + 0)
.s6:
1626 : a5 0d __ LDA P0 ; (dst + 0)
1628 : 85 1b __ STA ACCU + 0 
162a : a5 0f __ LDA P2 ; (src + 0)
162c : 85 43 __ STA T3 + 0 
162e : a5 0e __ LDA P1 ; (dst + 1)
1630 : 85 1c __ STA ACCU + 1 
1632 : a6 10 __ LDX P3 ; (src + 1)
1634 : 86 44 __ STX T3 + 1 
1636 : c5 10 __ CMP P3 ; (src + 1)
1638 : d0 04 __ BNE $163e ; (memmove.s13 + 0)
.s12:
163a : a5 0d __ LDA P0 ; (dst + 0)
163c : c5 0f __ CMP P2 ; (src + 0)
.s13:
163e : 90 50 __ BCC $1690 ; (memmove.s11 + 0)
.s7:
1640 : e4 0e __ CPX P1 ; (dst + 1)
1642 : d0 04 __ BNE $1648 ; (memmove.s10 + 0)
.s9:
1644 : a5 0f __ LDA P2 ; (src + 0)
1646 : c5 0d __ CMP P0 ; (dst + 0)
.s10:
1648 : b0 3d __ BCS $1687 ; (memmove.s5 + 0)
.s8:
164a : a5 0f __ LDA P2 ; (src + 0)
164c : 65 11 __ ADC P4 ; (size + 0)
164e : 85 43 __ STA T3 + 0 
1650 : 8a __ __ TXA
1651 : 65 12 __ ADC P5 ; (size + 1)
1653 : 85 44 __ STA T3 + 1 
1655 : 18 __ __ CLC
1656 : a5 0d __ LDA P0 ; (dst + 0)
1658 : 65 11 __ ADC P4 ; (size + 0)
165a : 85 1b __ STA ACCU + 0 
165c : a5 0e __ LDA P1 ; (dst + 1)
165e : 65 12 __ ADC P5 ; (size + 1)
1660 : 85 1c __ STA ACCU + 1 
1662 : a0 00 __ LDY #$00
1664 : a5 11 __ LDA P4 ; (size + 0)
1666 : f0 02 __ BEQ $166a ; (memmove.s30 + 0)
.s16:
1668 : e6 12 __ INC P5 ; (size + 1)
.s30:
166a : a6 11 __ LDX P4 ; (size + 0)
.l19:
166c : a5 43 __ LDA T3 + 0 
166e : d0 02 __ BNE $1672 ; (memmove.s26 + 0)
.s25:
1670 : c6 44 __ DEC T3 + 1 
.s26:
1672 : c6 43 __ DEC T3 + 0 
1674 : a5 1b __ LDA ACCU + 0 
1676 : d0 02 __ BNE $167a ; (memmove.s28 + 0)
.s27:
1678 : c6 1c __ DEC ACCU + 1 
.s28:
167a : c6 1b __ DEC ACCU + 0 
167c : b1 43 __ LDA (T3 + 0),y 
167e : 91 1b __ STA (ACCU + 0),y 
1680 : ca __ __ DEX
1681 : d0 e9 __ BNE $166c ; (memmove.l19 + 0)
.s20:
1683 : c6 12 __ DEC P5 ; (size + 1)
1685 : d0 e5 __ BNE $166c ; (memmove.l19 + 0)
.s5:
1687 : a5 0d __ LDA P0 ; (dst + 0)
1689 : 85 1b __ STA ACCU + 0 
168b : a5 0e __ LDA P1 ; (dst + 1)
168d : 85 1c __ STA ACCU + 1 
.s3:
168f : 60 __ __ RTS
.s11:
1690 : a0 00 __ LDY #$00
1692 : a5 11 __ LDA P4 ; (size + 0)
1694 : f0 02 __ BEQ $1698 ; (memmove.s29 + 0)
.s15:
1696 : e6 12 __ INC P5 ; (size + 1)
.s29:
1698 : a6 11 __ LDX P4 ; (size + 0)
.l17:
169a : b1 43 __ LDA (T3 + 0),y 
169c : 91 1b __ STA (ACCU + 0),y 
169e : e6 43 __ INC T3 + 0 
16a0 : d0 02 __ BNE $16a4 ; (memmove.s22 + 0)
.s21:
16a2 : e6 44 __ INC T3 + 1 
.s22:
16a4 : e6 1b __ INC ACCU + 0 
16a6 : d0 02 __ BNE $16aa ; (memmove.s24 + 0)
.s23:
16a8 : e6 1c __ INC ACCU + 1 
.s24:
16aa : ca __ __ DEX
16ab : d0 ed __ BNE $169a ; (memmove.l17 + 0)
.s18:
16ad : c6 12 __ DEC P5 ; (size + 1)
16af : d0 e9 __ BNE $169a ; (memmove.l17 + 0)
16b1 : f0 d4 __ BEQ $1687 ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16b3 : c9 41 __ CMP #$41
16b5 : 90 06 __ BCC $16bd ; (b_pet2scr.s3 + 0)
.s8:
16b7 : c9 5b __ CMP #$5b
16b9 : b0 03 __ BCS $16be ; (b_pet2scr.s5 + 0)
.s9:
16bb : e9 3f __ SBC #$3f
.s3:
16bd : 60 __ __ RTS
.s5:
16be : c9 c1 __ CMP #$c1
16c0 : 90 fb __ BCC $16bd ; (b_pet2scr.s3 + 0)
.s6:
16c2 : c9 db __ CMP #$db
16c4 : b0 f7 __ BCS $16bd ; (b_pet2scr.s3 + 0)
.s7:
16c6 : e9 bf __ SBC #$bf
16c8 : 60 __ __ RTS
--------------------------------------------------------------------
b_jiffy: ; b_jiffy()->float
; 133, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16c9 : ad 49 22 LDA $2249 ; (b_mem + 0)
16cc : 85 43 __ STA T2 + 0 
16ce : ad 4a 22 LDA $224a ; (b_mem + 1)
16d1 : 85 44 __ STA T2 + 1 
16d3 : a0 a2 __ LDY #$a2
16d5 : b1 43 __ LDA (T2 + 0),y 
16d7 : 85 1b __ STA ACCU + 0 
16d9 : 88 __ __ DEY
16da : b1 43 __ LDA (T2 + 0),y 
16dc : 85 1c __ STA ACCU + 1 
16de : 88 __ __ DEY
16df : b1 43 __ LDA (T2 + 0),y 
16e1 : 85 1d __ STA ACCU + 2 
16e3 : a9 00 __ LDA #$00
16e5 : 85 1e __ STA ACCU + 3 
16e7 : 4c e5 1f JMP $1fe5 ; (uint32_to_float + 0)
--------------------------------------------------------------------
b_ftoa: ; b_ftoa(u8*,float)->void
; 559, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16ea : a9 00 __ LDA #$00
16ec : 85 49 __ STA T2 + 0 
16ee : 85 4a __ STA T2 + 1 
16f0 : a5 0f __ LDA P2 ; (v + 0)
16f2 : 85 43 __ STA T0 + 0 
16f4 : a5 10 __ LDA P3 ; (v + 1)
16f6 : 85 44 __ STA T0 + 1 
16f8 : a5 12 __ LDA P5 ; (v + 3)
16fa : 29 7f __ AND #$7f
16fc : 05 11 __ ORA P4 ; (v + 2)
16fe : 05 10 __ ORA P3 ; (v + 1)
1700 : a6 11 __ LDX P4 ; (v + 2)
1702 : 86 45 __ STX T0 + 2 
1704 : 05 0f __ ORA P2 ; (v + 0)
1706 : d0 05 __ BNE $170d ; (b_ftoa.s78 + 0)
.s127:
1708 : a5 12 __ LDA P5 ; (v + 3)
170a : 4c 14 17 JMP $1714 ; (b_ftoa.s5 + 0)
.s78:
170d : a5 12 __ LDA P5 ; (v + 3)
170f : 10 03 __ BPL $1714 ; (b_ftoa.s5 + 0)
1711 : 4c 41 1b JMP $1b41 ; (b_ftoa.s76 + 0)
.s5:
1714 : 29 7f __ AND #$7f
1716 : 05 11 __ ORA P4 ; (v + 2)
1718 : 05 10 __ ORA P3 ; (v + 1)
171a : 05 0f __ ORA P2 ; (v + 0)
171c : d0 03 __ BNE $1721 ; (b_ftoa.s6 + 0)
171e : 4c 36 1b JMP $1b36 ; (b_ftoa.s75 + 0)
.s6:
1721 : a9 00 __ LDA #$00
.s7:
1723 : 85 4b __ STA T3 + 0 
1725 : a5 12 __ LDA P5 ; (v + 3)
1727 : 85 46 __ STA T0 + 3 
1729 : 30 1c __ BMI $1747 ; (b_ftoa.s8 + 0)
.s70:
172b : c9 41 __ CMP #$41
172d : d0 0d __ BNE $173c ; (b_ftoa.s74 + 0)
.s71:
172f : e0 20 __ CPX #$20
1731 : d0 09 __ BNE $173c ; (b_ftoa.s74 + 0)
.s72:
1733 : a5 10 __ LDA P3 ; (v + 1)
1735 : 38 __ __ SEC
1736 : d0 04 __ BNE $173c ; (b_ftoa.s74 + 0)
.s73:
1738 : a5 0f __ LDA P2 ; (v + 0)
173a : f0 02 __ BEQ $173e ; (b_ftoa.s61 + 0)
.s74:
173c : 90 09 __ BCC $1747 ; (b_ftoa.s8 + 0)
.s61:
173e : a9 00 __ LDA #$00
1740 : 85 47 __ STA T1 + 0 
1742 : 85 48 __ STA T1 + 1 
1744 : 4c d0 1a JMP $1ad0 ; (b_ftoa.l62 + 0)
.s8:
1747 : a5 12 __ LDA P5 ; (v + 3)
1749 : 30 13 __ BMI $175e ; (b_ftoa.s47 + 0)
.s56:
174b : c9 3f __ CMP #$3f
174d : d0 0d __ BNE $175c ; (b_ftoa.s60 + 0)
.s57:
174f : e0 80 __ CPX #$80
1751 : d0 09 __ BNE $175c ; (b_ftoa.s60 + 0)
.s58:
1753 : a5 10 __ LDA P3 ; (v + 1)
1755 : 38 __ __ SEC
1756 : d0 04 __ BNE $175c ; (b_ftoa.s60 + 0)
.s59:
1758 : a5 0f __ LDA P2 ; (v + 0)
175a : f0 5c __ BEQ $17b8 ; (b_ftoa.s9 + 0)
.s60:
175c : b0 5a __ BCS $17b8 ; (b_ftoa.s9 + 0)
.s47:
175e : a9 00 __ LDA #$00
1760 : 85 47 __ STA T1 + 0 
1762 : 85 48 __ STA T1 + 1 
.l48:
1764 : a5 49 __ LDA T2 + 0 
1766 : d0 02 __ BNE $176a ; (b_ftoa.s92 + 0)
.s91:
1768 : c6 4a __ DEC T2 + 1 
.s92:
176a : c6 49 __ DEC T2 + 0 
176c : a9 00 __ LDA #$00
176e : 85 1b __ STA ACCU + 0 
1770 : 85 1c __ STA ACCU + 1 
1772 : a9 20 __ LDA #$20
1774 : 85 1d __ STA ACCU + 2 
1776 : a9 41 __ LDA #$41
1778 : 85 1e __ STA ACCU + 3 
177a : a2 43 __ LDX #$43
177c : 20 cc 1b JSR $1bcc ; (freg + 4)
177f : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
1782 : a5 1b __ LDA ACCU + 0 
1784 : 85 43 __ STA T0 + 0 
1786 : a5 1c __ LDA ACCU + 1 
1788 : 85 44 __ STA T0 + 1 
178a : a6 1d __ LDX ACCU + 2 
178c : 86 45 __ STX T0 + 2 
178e : a5 1e __ LDA ACCU + 3 
1790 : 85 46 __ STA T0 + 3 
1792 : 30 13 __ BMI $17a7 ; (b_ftoa.s49 + 0)
.s51:
1794 : c9 3f __ CMP #$3f
1796 : d0 0d __ BNE $17a5 ; (b_ftoa.s55 + 0)
.s52:
1798 : e0 80 __ CPX #$80
179a : d0 09 __ BNE $17a5 ; (b_ftoa.s55 + 0)
.s53:
179c : a5 1c __ LDA ACCU + 1 
179e : 38 __ __ SEC
179f : d0 04 __ BNE $17a5 ; (b_ftoa.s55 + 0)
.s54:
17a1 : a5 1b __ LDA ACCU + 0 
17a3 : f0 13 __ BEQ $17b8 ; (b_ftoa.s9 + 0)
.s55:
17a5 : b0 11 __ BCS $17b8 ; (b_ftoa.s9 + 0)
.s49:
17a7 : e6 47 __ INC T1 + 0 
17a9 : d0 02 __ BNE $17ad ; (b_ftoa.s94 + 0)
.s93:
17ab : e6 48 __ INC T1 + 1 
.s94:
17ad : a6 48 __ LDX T1 + 1 
17af : ca __ __ DEX
17b0 : d0 b2 __ BNE $1764 ; (b_ftoa.l48 + 0)
.s50:
17b2 : a5 47 __ LDA T1 + 0 
17b4 : c9 90 __ CMP #$90
17b6 : d0 ac __ BNE $1764 ; (b_ftoa.l48 + 0)
.s9:
17b8 : a9 08 __ LDA #$08
17ba : 85 4d __ STA T4 + 0 
17bc : a9 4c __ LDA #$4c
17be : 85 1e __ STA ACCU + 3 
17c0 : a9 20 __ LDA #$20
17c2 : 85 1b __ STA ACCU + 0 
17c4 : a9 bc __ LDA #$bc
17c6 : 85 1c __ STA ACCU + 1 
17c8 : a9 be __ LDA #$be
17ca : 85 1d __ STA ACCU + 2 
17cc : a2 43 __ LDX #$43
17ce : 20 cc 1b JSR $1bcc ; (freg + 4)
17d1 : 20 fa 1c JSR $1cfa ; (crt_fmul + 0)
17d4 : a9 00 __ LDA #$00
17d6 : 85 03 __ STA WORK + 0 
17d8 : 85 04 __ STA WORK + 1 
17da : 85 05 __ STA WORK + 2 
17dc : a9 3f __ LDA #$3f
17de : 85 06 __ STA WORK + 3 
17e0 : 20 dc 1b JSR $1bdc ; (freg + 20)
17e3 : 20 13 1c JSR $1c13 ; (faddsub + 6)
17e6 : 20 5c 1f JSR $1f5c ; (f32_to_i32 + 0)
17e9 : a5 1b __ LDA ACCU + 0 
17eb : 85 43 __ STA T0 + 0 
17ed : a5 1c __ LDA ACCU + 1 
17ef : 85 44 __ STA T0 + 1 
17f1 : a5 1e __ LDA ACCU + 3 
17f3 : 85 46 __ STA T0 + 3 
17f5 : 49 80 __ EOR #$80
17f7 : a6 1d __ LDX ACCU + 2 
17f9 : 86 45 __ STX T0 + 2 
17fb : c9 bb __ CMP #$bb
17fd : d0 0a __ BNE $1809 ; (b_ftoa.s46 + 0)
.s44:
17ff : e0 9a __ CPX #$9a
1801 : d0 06 __ BNE $1809 ; (b_ftoa.s46 + 0)
.s45:
1803 : a5 1c __ LDA ACCU + 1 
1805 : c9 ca __ CMP #$ca
1807 : f0 02 __ BEQ $180b ; (b_ftoa.s43 + 0)
.s46:
1809 : 90 16 __ BCC $1821 ; (b_ftoa.s10 + 0)
.s43:
180b : e6 49 __ INC T2 + 0 
180d : d0 02 __ BNE $1811 ; (b_ftoa.s96 + 0)
.s95:
180f : e6 4a __ INC T2 + 1 
.s96:
1811 : a9 00 __ LDA #$00
1813 : 85 43 __ STA T0 + 0 
1815 : a9 e1 __ LDA #$e1
1817 : 85 44 __ STA T0 + 1 
1819 : a9 f5 __ LDA #$f5
181b : 85 45 __ STA T0 + 2 
181d : a9 05 __ LDA #$05
181f : 85 46 __ STA T0 + 3 
.s10:
1821 : a5 43 __ LDA T0 + 0 
1823 : 85 1b __ STA ACCU + 0 
1825 : a5 44 __ LDA T0 + 1 
1827 : 85 1c __ STA ACCU + 1 
1829 : a5 45 __ LDA T0 + 2 
182b : 85 1d __ STA ACCU + 2 
182d : a5 46 __ LDA T0 + 3 
182f : 85 1e __ STA ACCU + 3 
.l79:
1831 : a9 00 __ LDA #$00
1833 : 85 04 __ STA WORK + 1 
1835 : 85 05 __ STA WORK + 2 
1837 : 85 06 __ STA WORK + 3 
1839 : a9 0a __ LDA #$0a
183b : 85 03 __ STA WORK + 0 
183d : 20 09 22 JSR $2209 ; (mods32 + 0)
1840 : 18 __ __ CLC
1841 : a5 07 __ LDA WORK + 4 
1843 : 69 30 __ ADC #$30
1845 : a6 4d __ LDX T4 + 0 
1847 : 9d f0 9f STA $9ff0,x ; (d[0] + 0)
184a : a5 43 __ LDA T0 + 0 
184c : 85 1b __ STA ACCU + 0 
184e : a5 44 __ LDA T0 + 1 
1850 : 85 1c __ STA ACCU + 1 
1852 : a5 45 __ LDA T0 + 2 
1854 : 85 1d __ STA ACCU + 2 
1856 : a5 46 __ LDA T0 + 3 
1858 : 85 1e __ STA ACCU + 3 
185a : a9 00 __ LDA #$00
185c : 85 04 __ STA WORK + 1 
185e : 85 05 __ STA WORK + 2 
1860 : 85 06 __ STA WORK + 3 
1862 : a9 0a __ LDA #$0a
1864 : 85 03 __ STA WORK + 0 
1866 : 20 e0 20 JSR $20e0 ; (divs32 + 0)
1869 : a5 1b __ LDA ACCU + 0 
186b : 85 43 __ STA T0 + 0 
186d : a5 1c __ LDA ACCU + 1 
186f : 85 44 __ STA T0 + 1 
1871 : a5 1d __ LDA ACCU + 2 
1873 : 85 45 __ STA T0 + 2 
1875 : a5 1e __ LDA ACCU + 3 
1877 : 85 46 __ STA T0 + 3 
1879 : c6 4d __ DEC T4 + 0 
187b : 10 b4 __ BPL $1831 ; (b_ftoa.l79 + 0)
.s11:
187d : a9 00 __ LDA #$00
187f : 8d f9 9f STA $9ff9 ; (d[0] + 9)
1882 : a2 09 __ LDX #$09
.l12:
1884 : bd ef 9f LDA $9fef,x ; (eb[0] + 7)
1887 : c9 30 __ CMP #$30
1889 : d0 05 __ BNE $1890 ; (b_ftoa.s87 + 0)
.s42:
188b : ca __ __ DEX
188c : e0 02 __ CPX #$02
188e : b0 f4 __ BCS $1884 ; (b_ftoa.l12 + 0)
.s87:
1890 : 86 43 __ STX T0 + 0 
1892 : a5 4b __ LDA T3 + 0 
1894 : f0 0d __ BEQ $18a3 ; (b_ftoa.s13 + 0)
.s41:
1896 : a9 2d __ LDA #$2d
1898 : a0 00 __ LDY #$00
189a : 91 0d __ STA (P0),y ; (buf + 0)
189c : a9 01 __ LDA #$01
189e : 85 47 __ STA T1 + 0 
18a0 : 98 __ __ TYA
18a1 : f0 02 __ BEQ $18a5 ; (b_ftoa.s14 + 0)
.s13:
18a3 : 85 47 __ STA T1 + 0 
.s14:
18a5 : 85 48 __ STA T1 + 1 
18a7 : a5 4a __ LDA T2 + 1 
18a9 : 49 80 __ EOR #$80
18ab : c9 7f __ CMP #$7f
18ad : d0 04 __ BNE $18b3 ; (b_ftoa.s40 + 0)
.s39:
18af : a5 49 __ LDA T2 + 0 
18b1 : c9 fc __ CMP #$fc
.s40:
18b3 : b0 03 __ BCS $18b8 ; (b_ftoa.s26 + 0)
18b5 : 4c d2 19 JMP $19d2 ; (b_ftoa.s15 + 0)
.s26:
18b8 : a5 4a __ LDA T2 + 1 
18ba : 30 08 __ BMI $18c4 ; (b_ftoa.s27 + 0)
.s38:
18bc : d0 f7 __ BNE $18b5 ; (b_ftoa.s40 + 2)
.s37:
18be : a5 49 __ LDA T2 + 0 
18c0 : c9 09 __ CMP #$09
18c2 : b0 f1 __ BCS $18b5 ; (b_ftoa.s40 + 2)
.s27:
18c4 : 18 __ __ CLC
18c5 : a5 0d __ LDA P0 ; (buf + 0)
18c7 : 65 47 __ ADC T1 + 0 
18c9 : 85 4d __ STA T4 + 0 
18cb : a5 0e __ LDA P1 ; (buf + 1)
18cd : 69 00 __ ADC #$00
18cf : 85 4e __ STA T4 + 1 
18d1 : a5 49 __ LDA T2 + 0 
18d3 : 10 6f __ BPL $1944 ; (b_ftoa.s31 + 0)
.s28:
18d5 : a9 30 __ LDA #$30
18d7 : a4 47 __ LDY T1 + 0 
18d9 : 91 0d __ STA (P0),y ; (buf + 0)
18db : a9 2e __ LDA #$2e
18dd : a0 01 __ LDY #$01
18df : 91 4d __ STA (T4 + 0),y 
18e1 : a5 47 __ LDA T1 + 0 
18e3 : 09 02 __ ORA #$02
18e5 : 85 47 __ STA T1 + 0 
18e7 : a9 00 __ LDA #$00
18e9 : 38 __ __ SEC
18ea : e5 49 __ SBC T2 + 0 
18ec : aa __ __ TAX
18ed : ca __ __ DEX
18ee : f0 22 __ BEQ $1912 ; (b_ftoa.s29 + 0)
.s30:
18f0 : 18 __ __ CLC
18f1 : a5 0d __ LDA P0 ; (buf + 0)
18f3 : 65 47 __ ADC T1 + 0 
18f5 : a8 __ __ TAY
18f6 : a9 00 __ LDA #$00
18f8 : 85 4d __ STA T4 + 0 
18fa : a5 0e __ LDA P1 ; (buf + 1)
18fc : 69 00 __ ADC #$00
18fe : 85 4e __ STA T4 + 1 
.l84:
1900 : a9 30 __ LDA #$30
1902 : 91 4d __ STA (T4 + 0),y 
1904 : e6 47 __ INC T1 + 0 
1906 : d0 02 __ BNE $190a ; (b_ftoa.s120 + 0)
.s119:
1908 : e6 48 __ INC T1 + 1 
.s120:
190a : c8 __ __ INY
190b : d0 02 __ BNE $190f ; (b_ftoa.s122 + 0)
.s121:
190d : e6 4e __ INC T4 + 1 
.s122:
190f : ca __ __ DEX
1910 : d0 ee __ BNE $1900 ; (b_ftoa.l84 + 0)
.s29:
1912 : a5 0d __ LDA P0 ; (buf + 0)
.s85:
1914 : 18 __ __ CLC
1915 : 65 47 __ ADC T1 + 0 
1917 : 85 4b __ STA T3 + 0 
1919 : a5 0e __ LDA P1 ; (buf + 1)
191b : 65 48 __ ADC T1 + 1 
191d : 85 4c __ STA T3 + 1 
191f : a0 00 __ LDY #$00
.l89:
1921 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1924 : 91 4b __ STA (T3 + 0),y 
1926 : e6 47 __ INC T1 + 0 
1928 : d0 02 __ BNE $192c ; (b_ftoa.s112 + 0)
.s111:
192a : e6 48 __ INC T1 + 1 
.s112:
192c : c8 __ __ INY
192d : e8 __ __ INX
192e : e4 43 __ CPX T0 + 0 
1930 : 90 ef __ BCC $1921 ; (b_ftoa.l89 + 0)
.s129:
1932 : a4 0d __ LDY P0 ; (buf + 0)
.s21:
1934 : a5 47 __ LDA T1 + 0 
1936 : 85 43 __ STA T0 + 0 
1938 : 18 __ __ CLC
1939 : a5 0e __ LDA P1 ; (buf + 1)
193b : 65 48 __ ADC T1 + 1 
193d : 85 44 __ STA T0 + 1 
193f : a9 00 __ LDA #$00
1941 : 91 43 __ STA (T0 + 0),y 
.s3:
1943 : 60 __ __ RTS
.s31:
1944 : 18 __ __ CLC
1945 : 69 01 __ ADC #$01
1947 : 85 1b __ STA ACCU + 0 
1949 : c5 43 __ CMP T0 + 0 
194b : a0 00 __ LDY #$00
194d : 84 4f __ STY T5 + 0 
194f : 90 44 __ BCC $1995 ; (b_ftoa.l82 + 0)
.s34:
1951 : a2 00 __ LDX #$00
.l90:
1953 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1956 : 91 4d __ STA (T4 + 0),y 
1958 : e6 47 __ INC T1 + 0 
195a : d0 02 __ BNE $195e ; (b_ftoa.s114 + 0)
.s113:
195c : e6 48 __ INC T1 + 1 
.s114:
195e : c8 __ __ INY
195f : e8 __ __ INX
1960 : e4 43 __ CPX T0 + 0 
1962 : 90 ef __ BCC $1953 ; (b_ftoa.l90 + 0)
.s35:
1964 : a5 49 __ LDA T2 + 0 
1966 : c5 43 __ CMP T0 + 0 
1968 : 90 c8 __ BCC $1932 ; (b_ftoa.s129 + 0)
.s36:
196a : 18 __ __ CLC
196b : a5 0d __ LDA P0 ; (buf + 0)
196d : 65 47 __ ADC T1 + 0 
196f : 85 4b __ STA T3 + 0 
1971 : a5 0e __ LDA P1 ; (buf + 1)
1973 : 65 48 __ ADC T1 + 1 
1975 : 85 4c __ STA T3 + 1 
1977 : a0 00 __ LDY #$00
1979 : a6 47 __ LDX T1 + 0 
.l83:
197b : a9 30 __ LDA #$30
197d : 91 4b __ STA (T3 + 0),y 
197f : e8 __ __ INX
1980 : d0 02 __ BNE $1984 ; (b_ftoa.s116 + 0)
.s115:
1982 : e6 48 __ INC T1 + 1 
.s116:
1984 : c8 __ __ INY
1985 : d0 02 __ BNE $1989 ; (b_ftoa.s118 + 0)
.s117:
1987 : e6 4c __ INC T3 + 1 
.s118:
1989 : e6 43 __ INC T0 + 0 
198b : a5 49 __ LDA T2 + 0 
198d : c5 43 __ CMP T0 + 0 
198f : b0 ea __ BCS $197b ; (b_ftoa.l83 + 0)
.s86:
1991 : 86 47 __ STX T1 + 0 
1993 : 90 9d __ BCC $1932 ; (b_ftoa.s129 + 0)
.l82:
1995 : a6 4f __ LDX T5 + 0 
1997 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
199a : 91 4d __ STA (T4 + 0),y 
199c : e6 47 __ INC T1 + 0 
199e : d0 02 __ BNE $19a2 ; (b_ftoa.s106 + 0)
.s105:
19a0 : e6 48 __ INC T1 + 1 
.s106:
19a2 : c8 __ __ INY
19a3 : d0 02 __ BNE $19a7 ; (b_ftoa.s108 + 0)
.s107:
19a5 : e6 4e __ INC T4 + 1 
.s108:
19a7 : a5 49 __ LDA T2 + 0 
19a9 : e6 4f __ INC T5 + 0 
19ab : c5 4f __ CMP T5 + 0 
19ad : b0 e6 __ BCS $1995 ; (b_ftoa.l82 + 0)
.s32:
19af : a5 47 __ LDA T1 + 0 
19b1 : 85 49 __ STA T2 + 0 
19b3 : a5 0e __ LDA P1 ; (buf + 1)
19b5 : 65 48 __ ADC T1 + 1 
19b7 : 85 4a __ STA T2 + 1 
19b9 : a9 2e __ LDA #$2e
19bb : a4 0d __ LDY P0 ; (buf + 0)
19bd : 91 49 __ STA (T2 + 0),y 
19bf : e6 47 __ INC T1 + 0 
19c1 : d0 02 __ BNE $19c5 ; (b_ftoa.s110 + 0)
.s109:
19c3 : e6 48 __ INC T1 + 1 
.s110:
19c5 : a6 1b __ LDX ACCU + 0 
19c7 : e4 43 __ CPX T0 + 0 
19c9 : 90 03 __ BCC $19ce ; (b_ftoa.s33 + 0)
19cb : 4c 34 19 JMP $1934 ; (b_ftoa.s21 + 0)
.s33:
19ce : 98 __ __ TYA
19cf : 4c 14 19 JMP $1914 ; (b_ftoa.s85 + 0)
.s15:
19d2 : ad f0 9f LDA $9ff0 ; (d[0] + 0)
19d5 : a4 47 __ LDY T1 + 0 
19d7 : 91 0d __ STA (P0),y ; (buf + 0)
19d9 : e6 47 __ INC T1 + 0 
19db : a5 49 __ LDA T2 + 0 
19dd : 85 4f __ STA T5 + 0 
19df : a5 4a __ LDA T2 + 1 
19e1 : 85 50 __ STA T5 + 1 
19e3 : e0 02 __ CPX #$02
19e5 : 90 29 __ BCC $1a10 ; (b_ftoa.s16 + 0)
.s25:
19e7 : a9 2e __ LDA #$2e
19e9 : c8 __ __ INY
19ea : 91 0d __ STA (P0),y ; (buf + 0)
19ec : e6 47 __ INC T1 + 0 
19ee : 18 __ __ CLC
19ef : a5 47 __ LDA T1 + 0 
19f1 : 65 0d __ ADC P0 ; (buf + 0)
19f3 : 85 4d __ STA T4 + 0 
19f5 : a5 0e __ LDA P1 ; (buf + 1)
19f7 : 69 00 __ ADC #$00
19f9 : 85 4e __ STA T4 + 1 
19fb : a0 00 __ LDY #$00
19fd : a2 01 __ LDX #$01
.l88:
19ff : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1a02 : 91 4d __ STA (T4 + 0),y 
1a04 : e6 47 __ INC T1 + 0 
1a06 : d0 02 __ BNE $1a0a ; (b_ftoa.s98 + 0)
.s97:
1a08 : e6 48 __ INC T1 + 1 
.s98:
1a0a : c8 __ __ INY
1a0b : e8 __ __ INX
1a0c : e4 43 __ CPX T0 + 0 
1a0e : 90 ef __ BCC $19ff ; (b_ftoa.l88 + 0)
.s16:
1a10 : 18 __ __ CLC
1a11 : a5 0d __ LDA P0 ; (buf + 0)
1a13 : 65 47 __ ADC T1 + 0 
1a15 : 85 43 __ STA T0 + 0 
1a17 : a5 0e __ LDA P1 ; (buf + 1)
1a19 : 65 48 __ ADC T1 + 1 
1a1b : 85 44 __ STA T0 + 1 
1a1d : a9 45 __ LDA #$45
1a1f : a0 00 __ LDY #$00
1a21 : 84 4d __ STY T4 + 0 
1a23 : 91 43 __ STA (T0 + 0),y 
1a25 : 18 __ __ CLC
1a26 : a5 47 __ LDA T1 + 0 
1a28 : 69 02 __ ADC #$02
1a2a : 85 47 __ STA T1 + 0 
1a2c : 90 02 __ BCC $1a30 ; (b_ftoa.s100 + 0)
.s99:
1a2e : e6 48 __ INC T1 + 1 
.s100:
1a30 : a0 01 __ LDY #$01
1a32 : 24 4a __ BIT T2 + 1 
1a34 : 10 1c __ BPL $1a52 ; (b_ftoa.s17 + 0)
.s24:
1a36 : a9 2d __ LDA #$2d
1a38 : 91 43 __ STA (T0 + 0),y 
1a3a : 38 __ __ SEC
1a3b : a9 00 __ LDA #$00
1a3d : e5 49 __ SBC T2 + 0 
1a3f : 85 4f __ STA T5 + 0 
1a41 : a9 00 __ LDA #$00
1a43 : e5 4a __ SBC T2 + 1 
1a45 : 85 50 __ STA T5 + 1 
.s18:
1a47 : a5 4f __ LDA T5 + 0 
1a49 : 85 1b __ STA ACCU + 0 
1a4b : a5 50 __ LDA T5 + 1 
1a4d : 85 1c __ STA ACCU + 1 
1a4f : 4c 90 1a JMP $1a90 ; (b_ftoa.l80 + 0)
.s17:
1a52 : a9 2b __ LDA #$2b
1a54 : 91 43 __ STA (T0 + 0),y 
1a56 : a5 49 __ LDA T2 + 0 
1a58 : 05 4a __ ORA T2 + 1 
1a5a : d0 eb __ BNE $1a47 ; (b_ftoa.s18 + 0)
.s23:
1a5c : a9 30 __ LDA #$30
1a5e : 8d e8 9f STA $9fe8 ; (eb[0] + 0)
.s22:
1a61 : 8d e9 9f STA $9fe9 ; (eb[0] + 1)
1a64 : a9 02 __ LDA #$02
1a66 : 85 4d __ STA T4 + 0 
.s20:
1a68 : 18 __ __ CLC
1a69 : a5 0d __ LDA P0 ; (buf + 0)
1a6b : 65 47 __ ADC T1 + 0 
1a6d : a8 __ __ TAY
1a6e : a5 0e __ LDA P1 ; (buf + 1)
1a70 : 65 48 __ ADC T1 + 1 
1a72 : 85 4c __ STA T3 + 1 
1a74 : a9 00 __ LDA #$00
1a76 : 85 4b __ STA T3 + 0 
1a78 : a6 4d __ LDX T4 + 0 
.l81:
1a7a : bd e7 9f LDA $9fe7,x ; (buf[0] + 63)
1a7d : 91 4b __ STA (T3 + 0),y 
1a7f : e6 47 __ INC T1 + 0 
1a81 : d0 02 __ BNE $1a85 ; (b_ftoa.s102 + 0)
.s101:
1a83 : e6 48 __ INC T1 + 1 
.s102:
1a85 : c8 __ __ INY
1a86 : d0 02 __ BNE $1a8a ; (b_ftoa.s104 + 0)
.s103:
1a88 : e6 4c __ INC T3 + 1 
.s104:
1a8a : ca __ __ DEX
1a8b : d0 ed __ BNE $1a7a ; (b_ftoa.l81 + 0)
1a8d : 4c 32 19 JMP $1932 ; (b_ftoa.s129 + 0)
.l80:
1a90 : a9 0a __ LDA #$0a
1a92 : 85 03 __ STA WORK + 0 
1a94 : a9 00 __ LDA #$00
1a96 : 85 04 __ STA WORK + 1 
1a98 : 20 2f 1f JSR $1f2f ; (mods16 + 0)
1a9b : 18 __ __ CLC
1a9c : a5 05 __ LDA WORK + 2 
1a9e : 69 30 __ ADC #$30
1aa0 : a6 4d __ LDX T4 + 0 
1aa2 : 9d e8 9f STA $9fe8,x ; (eb[0] + 0)
1aa5 : a5 4f __ LDA T5 + 0 
1aa7 : e6 4d __ INC T4 + 0 
1aa9 : 85 1b __ STA ACCU + 0 
1aab : a5 50 __ LDA T5 + 1 
1aad : 85 1c __ STA ACCU + 1 
1aaf : a9 0a __ LDA #$0a
1ab1 : 85 03 __ STA WORK + 0 
1ab3 : a9 00 __ LDA #$00
1ab5 : 85 04 __ STA WORK + 1 
1ab7 : 20 70 1e JSR $1e70 ; (divs16 + 0)
1aba : a5 1b __ LDA ACCU + 0 
1abc : 85 4f __ STA T5 + 0 
1abe : a5 1c __ LDA ACCU + 1 
1ac0 : 85 50 __ STA T5 + 1 
1ac2 : 05 1b __ ORA ACCU + 0 
1ac4 : d0 ca __ BNE $1a90 ; (b_ftoa.l80 + 0)
.s19:
1ac6 : a5 4d __ LDA T4 + 0 
1ac8 : c9 02 __ CMP #$02
1aca : b0 9c __ BCS $1a68 ; (b_ftoa.s20 + 0)
.s128:
1acc : a9 30 __ LDA #$30
1ace : 90 91 __ BCC $1a61 ; (b_ftoa.s22 + 0)
.l62:
1ad0 : e6 49 __ INC T2 + 0 
1ad2 : d0 02 __ BNE $1ad6 ; (b_ftoa.s124 + 0)
.s123:
1ad4 : e6 4a __ INC T2 + 1 
.s124:
1ad6 : a5 43 __ LDA T0 + 0 
1ad8 : 85 1b __ STA ACCU + 0 
1ada : a5 44 __ LDA T0 + 1 
1adc : 85 1c __ STA ACCU + 1 
1ade : a5 45 __ LDA T0 + 2 
1ae0 : 85 1d __ STA ACCU + 2 
1ae2 : a5 46 __ LDA T0 + 3 
1ae4 : 85 1e __ STA ACCU + 3 
1ae6 : a9 00 __ LDA #$00
1ae8 : 85 03 __ STA WORK + 0 
1aea : 85 04 __ STA WORK + 1 
1aec : a9 20 __ LDA #$20
1aee : 85 05 __ STA WORK + 2 
1af0 : a9 41 __ LDA #$41
1af2 : 85 06 __ STA WORK + 3 
1af4 : 20 dc 1b JSR $1bdc ; (freg + 20)
1af7 : 20 c2 1d JSR $1dc2 ; (crt_fdiv + 0)
1afa : a5 1b __ LDA ACCU + 0 
1afc : 85 43 __ STA T0 + 0 
1afe : a5 1c __ LDA ACCU + 1 
1b00 : 85 44 __ STA T0 + 1 
1b02 : a6 1d __ LDX ACCU + 2 
1b04 : 86 45 __ STX T0 + 2 
1b06 : a5 1e __ LDA ACCU + 3 
1b08 : 85 46 __ STA T0 + 3 
1b0a : 10 03 __ BPL $1b0f ; (b_ftoa.s65 + 0)
1b0c : 4c b8 17 JMP $17b8 ; (b_ftoa.s9 + 0)
.s65:
1b0f : c9 41 __ CMP #$41
1b11 : d0 0d __ BNE $1b20 ; (b_ftoa.s69 + 0)
.s66:
1b13 : e0 20 __ CPX #$20
1b15 : d0 09 __ BNE $1b20 ; (b_ftoa.s69 + 0)
.s67:
1b17 : a5 1c __ LDA ACCU + 1 
1b19 : 38 __ __ SEC
1b1a : d0 04 __ BNE $1b20 ; (b_ftoa.s69 + 0)
.s68:
1b1c : a5 1b __ LDA ACCU + 0 
1b1e : f0 02 __ BEQ $1b22 ; (b_ftoa.s63 + 0)
.s69:
1b20 : 90 ea __ BCC $1b0c ; (b_ftoa.s124 + 54)
.s63:
1b22 : e6 47 __ INC T1 + 0 
1b24 : d0 02 __ BNE $1b28 ; (b_ftoa.s126 + 0)
.s125:
1b26 : e6 48 __ INC T1 + 1 
.s126:
1b28 : a6 48 __ LDX T1 + 1 
1b2a : ca __ __ DEX
1b2b : d0 a3 __ BNE $1ad0 ; (b_ftoa.l62 + 0)
.s64:
1b2d : a5 47 __ LDA T1 + 0 
1b2f : c9 90 __ CMP #$90
1b31 : d0 9d __ BNE $1ad0 ; (b_ftoa.l62 + 0)
1b33 : 4c b8 17 JMP $17b8 ; (b_ftoa.s9 + 0)
.s75:
1b36 : a9 30 __ LDA #$30
1b38 : a0 00 __ LDY #$00
1b3a : 91 0d __ STA (P0),y ; (buf + 0)
1b3c : 98 __ __ TYA
1b3d : c8 __ __ INY
1b3e : 91 0d __ STA (P0),y ; (buf + 0)
1b40 : 60 __ __ RTS
.s76:
1b41 : 49 80 __ EOR #$80
1b43 : 85 12 __ STA P5 ; (v + 3)
1b45 : 29 7f __ AND #$7f
1b47 : 05 11 __ ORA P4 ; (v + 2)
1b49 : 05 10 __ ORA P3 ; (v + 1)
1b4b : 05 0f __ ORA P2 ; (v + 0)
1b4d : f0 e7 __ BEQ $1b36 ; (b_ftoa.s75 + 0)
.s77:
1b4f : a9 01 __ LDA #$01
1b51 : 4c 23 17 JMP $1723 ; (b_ftoa.s7 + 0)
--------------------------------------------------------------------
strchr: ; strchr(const u8*,i16)->u8*
;  18, "C:/Users/g/claude/c64/oscar64/include/string.h"
.l4:
1b54 : a0 00 __ LDY #$00
1b56 : b1 0d __ LDA (P0),y ; (str + 0)
1b58 : c5 0f __ CMP P2 ; (ch + 0)
1b5a : d0 09 __ BNE $1b65 ; (strchr.s6 + 0)
.s5:
1b5c : a5 0d __ LDA P0 ; (str + 0)
1b5e : 85 1b __ STA ACCU + 0 
1b60 : a5 0e __ LDA P1 ; (str + 1)
.s3:
1b62 : 85 1c __ STA ACCU + 1 
1b64 : 60 __ __ RTS
.s6:
1b65 : aa __ __ TAX
1b66 : f0 09 __ BEQ $1b71 ; (strchr.s7 + 0)
.s8:
1b68 : e6 0d __ INC P0 ; (str + 0)
1b6a : d0 e8 __ BNE $1b54 ; (strchr.l4 + 0)
.s9:
1b6c : e6 0e __ INC P1 ; (str + 1)
1b6e : 4c 54 1b JMP $1b54 ; (strchr.l4 + 0)
.s7:
1b71 : 85 1b __ STA ACCU + 0 
1b73 : 4c 62 1b JMP $1b62 ; (strchr.s3 + 0)
--------------------------------------------------------------------
strlen: ; strlen(const u8*)->i16
;  12, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1b76 : a9 00 __ LDA #$00
1b78 : 85 1b __ STA ACCU + 0 
1b7a : 85 1c __ STA ACCU + 1 
1b7c : a8 __ __ TAY
1b7d : b1 0d __ LDA (P0),y ; (str + 0)
1b7f : f0 10 __ BEQ $1b91 ; (strlen.s3 + 0)
.s6:
1b81 : a2 00 __ LDX #$00
.l7:
1b83 : c8 __ __ INY
1b84 : d0 03 __ BNE $1b89 ; (strlen.s9 + 0)
.s8:
1b86 : e6 0e __ INC P1 ; (str + 1)
1b88 : e8 __ __ INX
.s9:
1b89 : b1 0d __ LDA (P0),y ; (str + 0)
1b8b : d0 f6 __ BNE $1b83 ; (strlen.l7 + 0)
.s5:
1b8d : 86 1c __ STX ACCU + 1 
1b8f : 84 1b __ STY ACCU + 0 
.s3:
1b91 : 60 __ __ RTS
--------------------------------------------------------------------
mul32by8: ; mul32by8
1b92 : a0 00 __ LDY #$00
1b94 : 84 07 __ STY WORK + 4 
1b96 : 84 08 __ STY WORK + 5 
1b98 : 84 09 __ STY WORK + 6 
1b9a : 4a __ __ LSR
1b9b : b0 0d __ BCS $1baa ; (mul32by8 + 24)
1b9d : f0 26 __ BEQ $1bc5 ; (mul32by8 + 51)
1b9f : 06 1b __ ASL ACCU + 0 
1ba1 : 26 1c __ ROL ACCU + 1 
1ba3 : 26 1d __ ROL ACCU + 2 
1ba5 : 26 1e __ ROL ACCU + 3 
1ba7 : 4a __ __ LSR
1ba8 : 90 f5 __ BCC $1b9f ; (mul32by8 + 13)
1baa : aa __ __ TAX
1bab : 18 __ __ CLC
1bac : a5 07 __ LDA WORK + 4 
1bae : 65 1b __ ADC ACCU + 0 
1bb0 : 85 07 __ STA WORK + 4 
1bb2 : a5 08 __ LDA WORK + 5 
1bb4 : 65 1c __ ADC ACCU + 1 
1bb6 : 85 08 __ STA WORK + 5 
1bb8 : a5 09 __ LDA WORK + 6 
1bba : 65 1d __ ADC ACCU + 2 
1bbc : 85 09 __ STA WORK + 6 
1bbe : 98 __ __ TYA
1bbf : 65 1e __ ADC ACCU + 3 
1bc1 : a8 __ __ TAY
1bc2 : 8a __ __ TXA
1bc3 : d0 da __ BNE $1b9f ; (mul32by8 + 13)
1bc5 : 84 0a __ STY WORK + 7 
1bc7 : 60 __ __ RTS
--------------------------------------------------------------------
freg: ; freg
1bc8 : b1 19 __ LDA (IP + 0),y 
1bca : c8 __ __ INY
1bcb : aa __ __ TAX
1bcc : b5 00 __ LDA $00,x 
1bce : 85 03 __ STA WORK + 0 
1bd0 : b5 01 __ LDA $01,x 
1bd2 : 85 04 __ STA WORK + 1 
1bd4 : b5 02 __ LDA $02,x 
1bd6 : 85 05 __ STA WORK + 2 
1bd8 : b5 03 __ LDA WORK + 0,x 
1bda : 85 06 __ STA WORK + 3 
1bdc : a5 05 __ LDA WORK + 2 
1bde : 0a __ __ ASL
1bdf : a5 06 __ LDA WORK + 3 
1be1 : 2a __ __ ROL
1be2 : 85 08 __ STA WORK + 5 
1be4 : f0 06 __ BEQ $1bec ; (freg + 36)
1be6 : a5 05 __ LDA WORK + 2 
1be8 : 09 80 __ ORA #$80
1bea : 85 05 __ STA WORK + 2 
1bec : a5 1d __ LDA ACCU + 2 
1bee : 0a __ __ ASL
1bef : a5 1e __ LDA ACCU + 3 
1bf1 : 2a __ __ ROL
1bf2 : 85 07 __ STA WORK + 4 
1bf4 : f0 06 __ BEQ $1bfc ; (freg + 52)
1bf6 : a5 1d __ LDA ACCU + 2 
1bf8 : 09 80 __ ORA #$80
1bfa : 85 1d __ STA ACCU + 2 
1bfc : 60 __ __ RTS
1bfd : 06 1e __ ASL ACCU + 3 
1bff : a5 07 __ LDA WORK + 4 
1c01 : 6a __ __ ROR
1c02 : 85 1e __ STA ACCU + 3 
1c04 : b0 06 __ BCS $1c0c ; (freg + 68)
1c06 : a5 1d __ LDA ACCU + 2 
1c08 : 29 7f __ AND #$7f
1c0a : 85 1d __ STA ACCU + 2 
1c0c : 60 __ __ RTS
--------------------------------------------------------------------
faddsub: ; faddsub
1c0d : a5 06 __ LDA WORK + 3 
1c0f : 49 80 __ EOR #$80
1c11 : 85 06 __ STA WORK + 3 
1c13 : a9 ff __ LDA #$ff
1c15 : c5 07 __ CMP WORK + 4 
1c17 : f0 04 __ BEQ $1c1d ; (faddsub + 16)
1c19 : c5 08 __ CMP WORK + 5 
1c1b : d0 11 __ BNE $1c2e ; (faddsub + 33)
1c1d : a5 1e __ LDA ACCU + 3 
1c1f : 09 7f __ ORA #$7f
1c21 : 85 1e __ STA ACCU + 3 
1c23 : a9 80 __ LDA #$80
1c25 : 85 1d __ STA ACCU + 2 
1c27 : a9 00 __ LDA #$00
1c29 : 85 1b __ STA ACCU + 0 
1c2b : 85 1c __ STA ACCU + 1 
1c2d : 60 __ __ RTS
1c2e : 38 __ __ SEC
1c2f : a5 07 __ LDA WORK + 4 
1c31 : e5 08 __ SBC WORK + 5 
1c33 : f0 38 __ BEQ $1c6d ; (faddsub + 96)
1c35 : aa __ __ TAX
1c36 : b0 25 __ BCS $1c5d ; (faddsub + 80)
1c38 : e0 e9 __ CPX #$e9
1c3a : b0 0e __ BCS $1c4a ; (faddsub + 61)
1c3c : a5 08 __ LDA WORK + 5 
1c3e : 85 07 __ STA WORK + 4 
1c40 : a9 00 __ LDA #$00
1c42 : 85 1b __ STA ACCU + 0 
1c44 : 85 1c __ STA ACCU + 1 
1c46 : 85 1d __ STA ACCU + 2 
1c48 : f0 23 __ BEQ $1c6d ; (faddsub + 96)
1c4a : a5 1d __ LDA ACCU + 2 
1c4c : 4a __ __ LSR
1c4d : 66 1c __ ROR ACCU + 1 
1c4f : 66 1b __ ROR ACCU + 0 
1c51 : e8 __ __ INX
1c52 : d0 f8 __ BNE $1c4c ; (faddsub + 63)
1c54 : 85 1d __ STA ACCU + 2 
1c56 : a5 08 __ LDA WORK + 5 
1c58 : 85 07 __ STA WORK + 4 
1c5a : 4c 6d 1c JMP $1c6d ; (faddsub + 96)
1c5d : e0 18 __ CPX #$18
1c5f : b0 33 __ BCS $1c94 ; (faddsub + 135)
1c61 : a5 05 __ LDA WORK + 2 
1c63 : 4a __ __ LSR
1c64 : 66 04 __ ROR WORK + 1 
1c66 : 66 03 __ ROR WORK + 0 
1c68 : ca __ __ DEX
1c69 : d0 f8 __ BNE $1c63 ; (faddsub + 86)
1c6b : 85 05 __ STA WORK + 2 
1c6d : a5 1e __ LDA ACCU + 3 
1c6f : 29 80 __ AND #$80
1c71 : 85 1e __ STA ACCU + 3 
1c73 : 45 06 __ EOR WORK + 3 
1c75 : 30 31 __ BMI $1ca8 ; (faddsub + 155)
1c77 : 18 __ __ CLC
1c78 : a5 1b __ LDA ACCU + 0 
1c7a : 65 03 __ ADC WORK + 0 
1c7c : 85 1b __ STA ACCU + 0 
1c7e : a5 1c __ LDA ACCU + 1 
1c80 : 65 04 __ ADC WORK + 1 
1c82 : 85 1c __ STA ACCU + 1 
1c84 : a5 1d __ LDA ACCU + 2 
1c86 : 65 05 __ ADC WORK + 2 
1c88 : 85 1d __ STA ACCU + 2 
1c8a : 90 08 __ BCC $1c94 ; (faddsub + 135)
1c8c : 66 1d __ ROR ACCU + 2 
1c8e : 66 1c __ ROR ACCU + 1 
1c90 : 66 1b __ ROR ACCU + 0 
1c92 : e6 07 __ INC WORK + 4 
1c94 : a5 07 __ LDA WORK + 4 
1c96 : c9 ff __ CMP #$ff
1c98 : f0 83 __ BEQ $1c1d ; (faddsub + 16)
1c9a : 4a __ __ LSR
1c9b : 05 1e __ ORA ACCU + 3 
1c9d : 85 1e __ STA ACCU + 3 
1c9f : b0 06 __ BCS $1ca7 ; (faddsub + 154)
1ca1 : a5 1d __ LDA ACCU + 2 
1ca3 : 29 7f __ AND #$7f
1ca5 : 85 1d __ STA ACCU + 2 
1ca7 : 60 __ __ RTS
1ca8 : 38 __ __ SEC
1ca9 : a5 1b __ LDA ACCU + 0 
1cab : e5 03 __ SBC WORK + 0 
1cad : 85 1b __ STA ACCU + 0 
1caf : a5 1c __ LDA ACCU + 1 
1cb1 : e5 04 __ SBC WORK + 1 
1cb3 : 85 1c __ STA ACCU + 1 
1cb5 : a5 1d __ LDA ACCU + 2 
1cb7 : e5 05 __ SBC WORK + 2 
1cb9 : 85 1d __ STA ACCU + 2 
1cbb : b0 19 __ BCS $1cd6 ; (faddsub + 201)
1cbd : 38 __ __ SEC
1cbe : a9 00 __ LDA #$00
1cc0 : e5 1b __ SBC ACCU + 0 
1cc2 : 85 1b __ STA ACCU + 0 
1cc4 : a9 00 __ LDA #$00
1cc6 : e5 1c __ SBC ACCU + 1 
1cc8 : 85 1c __ STA ACCU + 1 
1cca : a9 00 __ LDA #$00
1ccc : e5 1d __ SBC ACCU + 2 
1cce : 85 1d __ STA ACCU + 2 
1cd0 : a5 1e __ LDA ACCU + 3 
1cd2 : 49 80 __ EOR #$80
1cd4 : 85 1e __ STA ACCU + 3 
1cd6 : a5 1d __ LDA ACCU + 2 
1cd8 : 30 ba __ BMI $1c94 ; (faddsub + 135)
1cda : 05 1c __ ORA ACCU + 1 
1cdc : 05 1b __ ORA ACCU + 0 
1cde : f0 0f __ BEQ $1cef ; (faddsub + 226)
1ce0 : c6 07 __ DEC WORK + 4 
1ce2 : f0 0b __ BEQ $1cef ; (faddsub + 226)
1ce4 : 06 1b __ ASL ACCU + 0 
1ce6 : 26 1c __ ROL ACCU + 1 
1ce8 : 26 1d __ ROL ACCU + 2 
1cea : 10 f4 __ BPL $1ce0 ; (faddsub + 211)
1cec : 4c 94 1c JMP $1c94 ; (faddsub + 135)
1cef : a9 00 __ LDA #$00
1cf1 : 85 1b __ STA ACCU + 0 
1cf3 : 85 1c __ STA ACCU + 1 
1cf5 : 85 1d __ STA ACCU + 2 
1cf7 : 85 1e __ STA ACCU + 3 
1cf9 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
1cfa : a5 1b __ LDA ACCU + 0 
1cfc : 05 1c __ ORA ACCU + 1 
1cfe : 05 1d __ ORA ACCU + 2 
1d00 : f0 0e __ BEQ $1d10 ; (crt_fmul + 22)
1d02 : a5 03 __ LDA WORK + 0 
1d04 : 05 04 __ ORA WORK + 1 
1d06 : 05 05 __ ORA WORK + 2 
1d08 : d0 09 __ BNE $1d13 ; (crt_fmul + 25)
1d0a : 85 1b __ STA ACCU + 0 
1d0c : 85 1c __ STA ACCU + 1 
1d0e : 85 1d __ STA ACCU + 2 
1d10 : 85 1e __ STA ACCU + 3 
1d12 : 60 __ __ RTS
1d13 : a5 1e __ LDA ACCU + 3 
1d15 : 45 06 __ EOR WORK + 3 
1d17 : 29 80 __ AND #$80
1d19 : 85 1e __ STA ACCU + 3 
1d1b : a9 ff __ LDA #$ff
1d1d : c5 07 __ CMP WORK + 4 
1d1f : f0 42 __ BEQ $1d63 ; (crt_fmul + 105)
1d21 : c5 08 __ CMP WORK + 5 
1d23 : f0 3e __ BEQ $1d63 ; (crt_fmul + 105)
1d25 : a9 00 __ LDA #$00
1d27 : 85 09 __ STA WORK + 6 
1d29 : 85 0a __ STA WORK + 7 
1d2b : 85 0b __ STA WORK + 8 
1d2d : a4 1b __ LDY ACCU + 0 
1d2f : a5 03 __ LDA WORK + 0 
1d31 : d0 06 __ BNE $1d39 ; (crt_fmul + 63)
1d33 : a5 04 __ LDA WORK + 1 
1d35 : f0 0a __ BEQ $1d41 ; (crt_fmul + 71)
1d37 : d0 05 __ BNE $1d3e ; (crt_fmul + 68)
1d39 : 20 94 1d JSR $1d94 ; (crt_fmul8 + 0)
1d3c : a5 04 __ LDA WORK + 1 
1d3e : 20 94 1d JSR $1d94 ; (crt_fmul8 + 0)
1d41 : a5 05 __ LDA WORK + 2 
1d43 : 20 94 1d JSR $1d94 ; (crt_fmul8 + 0)
1d46 : 38 __ __ SEC
1d47 : a5 0b __ LDA WORK + 8 
1d49 : 30 06 __ BMI $1d51 ; (crt_fmul + 87)
1d4b : 06 09 __ ASL WORK + 6 
1d4d : 26 0a __ ROL WORK + 7 
1d4f : 2a __ __ ROL
1d50 : 18 __ __ CLC
1d51 : 29 7f __ AND #$7f
1d53 : 85 0b __ STA WORK + 8 
1d55 : a5 07 __ LDA WORK + 4 
1d57 : 65 08 __ ADC WORK + 5 
1d59 : 90 19 __ BCC $1d74 ; (crt_fmul + 122)
1d5b : e9 7f __ SBC #$7f
1d5d : b0 04 __ BCS $1d63 ; (crt_fmul + 105)
1d5f : c9 ff __ CMP #$ff
1d61 : d0 15 __ BNE $1d78 ; (crt_fmul + 126)
1d63 : a5 1e __ LDA ACCU + 3 
1d65 : 09 7f __ ORA #$7f
1d67 : 85 1e __ STA ACCU + 3 
1d69 : a9 80 __ LDA #$80
1d6b : 85 1d __ STA ACCU + 2 
1d6d : a9 00 __ LDA #$00
1d6f : 85 1b __ STA ACCU + 0 
1d71 : 85 1c __ STA ACCU + 1 
1d73 : 60 __ __ RTS
1d74 : e9 7e __ SBC #$7e
1d76 : 90 15 __ BCC $1d8d ; (crt_fmul + 147)
1d78 : 4a __ __ LSR
1d79 : 05 1e __ ORA ACCU + 3 
1d7b : 85 1e __ STA ACCU + 3 
1d7d : a9 00 __ LDA #$00
1d7f : 6a __ __ ROR
1d80 : 05 0b __ ORA WORK + 8 
1d82 : 85 1d __ STA ACCU + 2 
1d84 : a5 0a __ LDA WORK + 7 
1d86 : 85 1c __ STA ACCU + 1 
1d88 : a5 09 __ LDA WORK + 6 
1d8a : 85 1b __ STA ACCU + 0 
1d8c : 60 __ __ RTS
1d8d : a9 00 __ LDA #$00
1d8f : 85 1e __ STA ACCU + 3 
1d91 : f0 d8 __ BEQ $1d6b ; (crt_fmul + 113)
1d93 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
1d94 : 38 __ __ SEC
1d95 : 6a __ __ ROR
1d96 : 90 1e __ BCC $1db6 ; (crt_fmul8 + 34)
1d98 : aa __ __ TAX
1d99 : 18 __ __ CLC
1d9a : 98 __ __ TYA
1d9b : 65 09 __ ADC WORK + 6 
1d9d : 85 09 __ STA WORK + 6 
1d9f : a5 0a __ LDA WORK + 7 
1da1 : 65 1c __ ADC ACCU + 1 
1da3 : 85 0a __ STA WORK + 7 
1da5 : a5 0b __ LDA WORK + 8 
1da7 : 65 1d __ ADC ACCU + 2 
1da9 : 6a __ __ ROR
1daa : 85 0b __ STA WORK + 8 
1dac : 8a __ __ TXA
1dad : 66 0a __ ROR WORK + 7 
1daf : 66 09 __ ROR WORK + 6 
1db1 : 4a __ __ LSR
1db2 : f0 0d __ BEQ $1dc1 ; (crt_fmul8 + 45)
1db4 : b0 e2 __ BCS $1d98 ; (crt_fmul8 + 4)
1db6 : 66 0b __ ROR WORK + 8 
1db8 : 66 0a __ ROR WORK + 7 
1dba : 66 09 __ ROR WORK + 6 
1dbc : 4a __ __ LSR
1dbd : 90 f7 __ BCC $1db6 ; (crt_fmul8 + 34)
1dbf : d0 d7 __ BNE $1d98 ; (crt_fmul8 + 4)
1dc1 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
1dc2 : a5 1b __ LDA ACCU + 0 
1dc4 : 05 1c __ ORA ACCU + 1 
1dc6 : 05 1d __ ORA ACCU + 2 
1dc8 : d0 03 __ BNE $1dcd ; (crt_fdiv + 11)
1dca : 85 1e __ STA ACCU + 3 
1dcc : 60 __ __ RTS
1dcd : a5 1e __ LDA ACCU + 3 
1dcf : 45 06 __ EOR WORK + 3 
1dd1 : 29 80 __ AND #$80
1dd3 : 85 1e __ STA ACCU + 3 
1dd5 : a5 08 __ LDA WORK + 5 
1dd7 : f0 62 __ BEQ $1e3b ; (crt_fdiv + 121)
1dd9 : a5 07 __ LDA WORK + 4 
1ddb : c9 ff __ CMP #$ff
1ddd : f0 5c __ BEQ $1e3b ; (crt_fdiv + 121)
1ddf : a9 00 __ LDA #$00
1de1 : 85 09 __ STA WORK + 6 
1de3 : 85 0a __ STA WORK + 7 
1de5 : 85 0b __ STA WORK + 8 
1de7 : a2 18 __ LDX #$18
1de9 : a5 1b __ LDA ACCU + 0 
1deb : c5 03 __ CMP WORK + 0 
1ded : a5 1c __ LDA ACCU + 1 
1def : e5 04 __ SBC WORK + 1 
1df1 : a5 1d __ LDA ACCU + 2 
1df3 : e5 05 __ SBC WORK + 2 
1df5 : 90 13 __ BCC $1e0a ; (crt_fdiv + 72)
1df7 : a5 1b __ LDA ACCU + 0 
1df9 : e5 03 __ SBC WORK + 0 
1dfb : 85 1b __ STA ACCU + 0 
1dfd : a5 1c __ LDA ACCU + 1 
1dff : e5 04 __ SBC WORK + 1 
1e01 : 85 1c __ STA ACCU + 1 
1e03 : a5 1d __ LDA ACCU + 2 
1e05 : e5 05 __ SBC WORK + 2 
1e07 : 85 1d __ STA ACCU + 2 
1e09 : 38 __ __ SEC
1e0a : 26 09 __ ROL WORK + 6 
1e0c : 26 0a __ ROL WORK + 7 
1e0e : 26 0b __ ROL WORK + 8 
1e10 : ca __ __ DEX
1e11 : f0 0a __ BEQ $1e1d ; (crt_fdiv + 91)
1e13 : 06 1b __ ASL ACCU + 0 
1e15 : 26 1c __ ROL ACCU + 1 
1e17 : 26 1d __ ROL ACCU + 2 
1e19 : b0 dc __ BCS $1df7 ; (crt_fdiv + 53)
1e1b : 90 cc __ BCC $1de9 ; (crt_fdiv + 39)
1e1d : 38 __ __ SEC
1e1e : a5 0b __ LDA WORK + 8 
1e20 : 30 06 __ BMI $1e28 ; (crt_fdiv + 102)
1e22 : 06 09 __ ASL WORK + 6 
1e24 : 26 0a __ ROL WORK + 7 
1e26 : 2a __ __ ROL
1e27 : 18 __ __ CLC
1e28 : 29 7f __ AND #$7f
1e2a : 85 0b __ STA WORK + 8 
1e2c : a5 07 __ LDA WORK + 4 
1e2e : e5 08 __ SBC WORK + 5 
1e30 : 90 1a __ BCC $1e4c ; (crt_fdiv + 138)
1e32 : 18 __ __ CLC
1e33 : 69 7f __ ADC #$7f
1e35 : b0 04 __ BCS $1e3b ; (crt_fdiv + 121)
1e37 : c9 ff __ CMP #$ff
1e39 : d0 15 __ BNE $1e50 ; (crt_fdiv + 142)
1e3b : a5 1e __ LDA ACCU + 3 
1e3d : 09 7f __ ORA #$7f
1e3f : 85 1e __ STA ACCU + 3 
1e41 : a9 80 __ LDA #$80
1e43 : 85 1d __ STA ACCU + 2 
1e45 : a9 00 __ LDA #$00
1e47 : 85 1c __ STA ACCU + 1 
1e49 : 85 1b __ STA ACCU + 0 
1e4b : 60 __ __ RTS
1e4c : 69 7f __ ADC #$7f
1e4e : 90 15 __ BCC $1e65 ; (crt_fdiv + 163)
1e50 : 4a __ __ LSR
1e51 : 05 1e __ ORA ACCU + 3 
1e53 : 85 1e __ STA ACCU + 3 
1e55 : a9 00 __ LDA #$00
1e57 : 6a __ __ ROR
1e58 : 05 0b __ ORA WORK + 8 
1e5a : 85 1d __ STA ACCU + 2 
1e5c : a5 0a __ LDA WORK + 7 
1e5e : 85 1c __ STA ACCU + 1 
1e60 : a5 09 __ LDA WORK + 6 
1e62 : 85 1b __ STA ACCU + 0 
1e64 : 60 __ __ RTS
1e65 : a9 00 __ LDA #$00
1e67 : 85 1e __ STA ACCU + 3 
1e69 : 85 1d __ STA ACCU + 2 
1e6b : 85 1c __ STA ACCU + 1 
1e6d : 85 1b __ STA ACCU + 0 
1e6f : 60 __ __ RTS
--------------------------------------------------------------------
divs16: ; divs16
1e70 : 24 1c __ BIT ACCU + 1 
1e72 : 10 0d __ BPL $1e81 ; (divs16 + 17)
1e74 : 20 8e 1e JSR $1e8e ; (negaccu + 0)
1e77 : 24 04 __ BIT WORK + 1 
1e79 : 10 0d __ BPL $1e88 ; (divs16 + 24)
1e7b : 20 9c 1e JSR $1e9c ; (negtmp + 0)
1e7e : 4c aa 1e JMP $1eaa ; (divmod + 0)
1e81 : 24 04 __ BIT WORK + 1 
1e83 : 10 f9 __ BPL $1e7e ; (divs16 + 14)
1e85 : 20 9c 1e JSR $1e9c ; (negtmp + 0)
1e88 : 20 aa 1e JSR $1eaa ; (divmod + 0)
1e8b : 4c 8e 1e JMP $1e8e ; (negaccu + 0)
--------------------------------------------------------------------
negaccu: ; negaccu
1e8e : 38 __ __ SEC
1e8f : a9 00 __ LDA #$00
1e91 : e5 1b __ SBC ACCU + 0 
1e93 : 85 1b __ STA ACCU + 0 
1e95 : a9 00 __ LDA #$00
1e97 : e5 1c __ SBC ACCU + 1 
1e99 : 85 1c __ STA ACCU + 1 
1e9b : 60 __ __ RTS
--------------------------------------------------------------------
negtmp: ; negtmp
1e9c : 38 __ __ SEC
1e9d : a9 00 __ LDA #$00
1e9f : e5 03 __ SBC WORK + 0 
1ea1 : 85 03 __ STA WORK + 0 
1ea3 : a9 00 __ LDA #$00
1ea5 : e5 04 __ SBC WORK + 1 
1ea7 : 85 04 __ STA WORK + 1 
1ea9 : 60 __ __ RTS
--------------------------------------------------------------------
divmod: ; divmod
1eaa : a5 1c __ LDA ACCU + 1 
1eac : d0 31 __ BNE $1edf ; (divmod + 53)
1eae : a5 04 __ LDA WORK + 1 
1eb0 : d0 1e __ BNE $1ed0 ; (divmod + 38)
1eb2 : 85 06 __ STA WORK + 3 
1eb4 : a2 04 __ LDX #$04
1eb6 : 06 1b __ ASL ACCU + 0 
1eb8 : 2a __ __ ROL
1eb9 : c5 03 __ CMP WORK + 0 
1ebb : 90 02 __ BCC $1ebf ; (divmod + 21)
1ebd : e5 03 __ SBC WORK + 0 
1ebf : 26 1b __ ROL ACCU + 0 
1ec1 : 2a __ __ ROL
1ec2 : c5 03 __ CMP WORK + 0 
1ec4 : 90 02 __ BCC $1ec8 ; (divmod + 30)
1ec6 : e5 03 __ SBC WORK + 0 
1ec8 : 26 1b __ ROL ACCU + 0 
1eca : ca __ __ DEX
1ecb : d0 eb __ BNE $1eb8 ; (divmod + 14)
1ecd : 85 05 __ STA WORK + 2 
1ecf : 60 __ __ RTS
1ed0 : a5 1b __ LDA ACCU + 0 
1ed2 : 85 05 __ STA WORK + 2 
1ed4 : a5 1c __ LDA ACCU + 1 
1ed6 : 85 06 __ STA WORK + 3 
1ed8 : a9 00 __ LDA #$00
1eda : 85 1b __ STA ACCU + 0 
1edc : 85 1c __ STA ACCU + 1 
1ede : 60 __ __ RTS
1edf : a5 04 __ LDA WORK + 1 
1ee1 : d0 1f __ BNE $1f02 ; (divmod + 88)
1ee3 : a5 03 __ LDA WORK + 0 
1ee5 : 30 1b __ BMI $1f02 ; (divmod + 88)
1ee7 : a9 00 __ LDA #$00
1ee9 : 85 06 __ STA WORK + 3 
1eeb : a2 10 __ LDX #$10
1eed : 06 1b __ ASL ACCU + 0 
1eef : 26 1c __ ROL ACCU + 1 
1ef1 : 2a __ __ ROL
1ef2 : c5 03 __ CMP WORK + 0 
1ef4 : 90 02 __ BCC $1ef8 ; (divmod + 78)
1ef6 : e5 03 __ SBC WORK + 0 
1ef8 : 26 1b __ ROL ACCU + 0 
1efa : 26 1c __ ROL ACCU + 1 
1efc : ca __ __ DEX
1efd : d0 f2 __ BNE $1ef1 ; (divmod + 71)
1eff : 85 05 __ STA WORK + 2 
1f01 : 60 __ __ RTS
1f02 : a9 00 __ LDA #$00
1f04 : 85 05 __ STA WORK + 2 
1f06 : 85 06 __ STA WORK + 3 
1f08 : 84 02 __ STY $02 
1f0a : a0 10 __ LDY #$10
1f0c : 18 __ __ CLC
1f0d : 26 1b __ ROL ACCU + 0 
1f0f : 26 1c __ ROL ACCU + 1 
1f11 : 26 05 __ ROL WORK + 2 
1f13 : 26 06 __ ROL WORK + 3 
1f15 : 38 __ __ SEC
1f16 : a5 05 __ LDA WORK + 2 
1f18 : e5 03 __ SBC WORK + 0 
1f1a : aa __ __ TAX
1f1b : a5 06 __ LDA WORK + 3 
1f1d : e5 04 __ SBC WORK + 1 
1f1f : 90 04 __ BCC $1f25 ; (divmod + 123)
1f21 : 86 05 __ STX WORK + 2 
1f23 : 85 06 __ STA WORK + 3 
1f25 : 88 __ __ DEY
1f26 : d0 e5 __ BNE $1f0d ; (divmod + 99)
1f28 : 26 1b __ ROL ACCU + 0 
1f2a : 26 1c __ ROL ACCU + 1 
1f2c : a4 02 __ LDY $02 
1f2e : 60 __ __ RTS
--------------------------------------------------------------------
mods16: ; mods16
1f2f : 24 1c __ BIT ACCU + 1 
1f31 : 10 10 __ BPL $1f43 ; (mods16 + 20)
1f33 : 20 8e 1e JSR $1e8e ; (negaccu + 0)
1f36 : 24 04 __ BIT WORK + 1 
1f38 : 10 03 __ BPL $1f3d ; (mods16 + 14)
1f3a : 20 9c 1e JSR $1e9c ; (negtmp + 0)
1f3d : 20 aa 1e JSR $1eaa ; (divmod + 0)
1f40 : 4c 4e 1f JMP $1f4e ; (negtmpb + 0)
1f43 : 24 04 __ BIT WORK + 1 
1f45 : 10 03 __ BPL $1f4a ; (mods16 + 27)
1f47 : 20 9c 1e JSR $1e9c ; (negtmp + 0)
1f4a : 4c aa 1e JMP $1eaa ; (divmod + 0)
1f4d : 60 __ __ RTS
--------------------------------------------------------------------
negtmpb: ; negtmpb
1f4e : 38 __ __ SEC
1f4f : a9 00 __ LDA #$00
1f51 : e5 05 __ SBC WORK + 2 
1f53 : 85 05 __ STA WORK + 2 
1f55 : a9 00 __ LDA #$00
1f57 : e5 06 __ SBC WORK + 3 
1f59 : 85 06 __ STA WORK + 3 
1f5b : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
1f5c : a5 1e __ LDA ACCU + 3 
1f5e : 30 03 __ BMI $1f63 ; (f32_to_i32 + 7)
1f60 : 4c 80 1f JMP $1f80 ; (f32_to_u32 + 0)
1f63 : 20 80 1f JSR $1f80 ; (f32_to_u32 + 0)
1f66 : 38 __ __ SEC
1f67 : a9 00 __ LDA #$00
1f69 : e5 1b __ SBC ACCU + 0 
1f6b : 85 1b __ STA ACCU + 0 
1f6d : a9 00 __ LDA #$00
1f6f : e5 1c __ SBC ACCU + 1 
1f71 : 85 1c __ STA ACCU + 1 
1f73 : a9 00 __ LDA #$00
1f75 : e5 1d __ SBC ACCU + 2 
1f77 : 85 1d __ STA ACCU + 2 
1f79 : a9 00 __ LDA #$00
1f7b : e5 1e __ SBC ACCU + 3 
1f7d : 85 1e __ STA ACCU + 3 
1f7f : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
1f80 : 20 ec 1b JSR $1bec ; (freg + 36)
1f83 : a5 07 __ LDA WORK + 4 
1f85 : c9 7f __ CMP #$7f
1f87 : b0 0b __ BCS $1f94 ; (f32_to_u32 + 20)
1f89 : a9 00 __ LDA #$00
1f8b : 85 1b __ STA ACCU + 0 
1f8d : 85 1c __ STA ACCU + 1 
1f8f : 85 1d __ STA ACCU + 2 
1f91 : 85 1e __ STA ACCU + 3 
1f93 : 60 __ __ RTS
1f94 : 38 __ __ SEC
1f95 : e9 9e __ SBC #$9e
1f97 : f0 13 __ BEQ $1fac ; (f32_to_u32 + 44)
1f99 : 90 04 __ BCC $1f9f ; (f32_to_u32 + 31)
1f9b : a9 ff __ LDA #$ff
1f9d : d0 ec __ BNE $1f8b ; (f32_to_u32 + 11)
1f9f : aa __ __ TAX
1fa0 : a9 00 __ LDA #$00
1fa2 : 46 1d __ LSR ACCU + 2 
1fa4 : 66 1c __ ROR ACCU + 1 
1fa6 : 66 1b __ ROR ACCU + 0 
1fa8 : 6a __ __ ROR
1fa9 : e8 __ __ INX
1faa : d0 f6 __ BNE $1fa2 ; (f32_to_u32 + 34)
1fac : a6 1d __ LDX ACCU + 2 
1fae : 86 1e __ STX ACCU + 3 
1fb0 : a6 1c __ LDX ACCU + 1 
1fb2 : 86 1d __ STX ACCU + 2 
1fb4 : a6 1b __ LDX ACCU + 0 
1fb6 : 86 1c __ STX ACCU + 1 
1fb8 : 85 1b __ STA ACCU + 0 
1fba : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
1fbb : 24 1e __ BIT ACCU + 3 
1fbd : 30 03 __ BMI $1fc2 ; (sint32_to_float + 7)
1fbf : 4c e5 1f JMP $1fe5 ; (uint32_to_float + 0)
1fc2 : 38 __ __ SEC
1fc3 : a9 00 __ LDA #$00
1fc5 : e5 1b __ SBC ACCU + 0 
1fc7 : 85 1b __ STA ACCU + 0 
1fc9 : a9 00 __ LDA #$00
1fcb : e5 1c __ SBC ACCU + 1 
1fcd : 85 1c __ STA ACCU + 1 
1fcf : a9 00 __ LDA #$00
1fd1 : e5 1d __ SBC ACCU + 2 
1fd3 : 85 1d __ STA ACCU + 2 
1fd5 : a9 00 __ LDA #$00
1fd7 : e5 1e __ SBC ACCU + 3 
1fd9 : 85 1e __ STA ACCU + 3 
1fdb : 20 e5 1f JSR $1fe5 ; (uint32_to_float + 0)
1fde : a5 1e __ LDA ACCU + 3 
1fe0 : 09 80 __ ORA #$80
1fe2 : 85 1e __ STA ACCU + 3 
1fe4 : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
1fe5 : a5 1b __ LDA ACCU + 0 
1fe7 : 05 1c __ ORA ACCU + 1 
1fe9 : 05 1d __ ORA ACCU + 2 
1feb : 05 1e __ ORA ACCU + 3 
1fed : d0 01 __ BNE $1ff0 ; (uint32_to_float + 11)
1fef : 60 __ __ RTS
1ff0 : a2 9e __ LDX #$9e
1ff2 : a5 1e __ LDA ACCU + 3 
1ff4 : 30 0a __ BMI $2000 ; (uint32_to_float + 27)
1ff6 : ca __ __ DEX
1ff7 : 06 1b __ ASL ACCU + 0 
1ff9 : 26 1c __ ROL ACCU + 1 
1ffb : 26 1d __ ROL ACCU + 2 
1ffd : 2a __ __ ROL
1ffe : 10 f6 __ BPL $1ff6 ; (uint32_to_float + 17)
2000 : 24 1b __ BIT ACCU + 0 
2002 : 10 13 __ BPL $2017 ; (uint32_to_float + 50)
2004 : e6 1c __ INC ACCU + 1 
2006 : d0 0f __ BNE $2017 ; (uint32_to_float + 50)
2008 : e6 1d __ INC ACCU + 2 
200a : d0 0b __ BNE $2017 ; (uint32_to_float + 50)
200c : 18 __ __ CLC
200d : 69 01 __ ADC #$01
200f : 90 06 __ BCC $2017 ; (uint32_to_float + 50)
2011 : 4a __ __ LSR
2012 : 66 1d __ ROR ACCU + 2 
2014 : 66 1c __ ROR ACCU + 1 
2016 : e8 __ __ INX
2017 : 0a __ __ ASL
2018 : a4 1c __ LDY ACCU + 1 
201a : 84 1b __ STY ACCU + 0 
201c : a4 1d __ LDY ACCU + 2 
201e : 84 1c __ STY ACCU + 1 
2020 : 85 1d __ STA ACCU + 2 
2022 : 8a __ __ TXA
2023 : 4a __ __ LSR
2024 : 85 1e __ STA ACCU + 3 
2026 : 66 1d __ ROR ACCU + 2 
2028 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fcmp: ; crt_fcmp
2029 : a5 1e __ LDA ACCU + 3 
202b : 45 06 __ EOR WORK + 3 
202d : 10 1e __ BPL $204d ; (crt_fcmp + 36)
202f : a5 1e __ LDA ACCU + 3 
2031 : 29 7f __ AND #$7f
2033 : 05 1d __ ORA ACCU + 2 
2035 : 05 1c __ ORA ACCU + 1 
2037 : 05 1b __ ORA ACCU + 0 
2039 : d0 0c __ BNE $2047 ; (crt_fcmp + 30)
203b : a5 06 __ LDA WORK + 3 
203d : 29 7f __ AND #$7f
203f : 05 05 __ ORA WORK + 2 
2041 : 05 04 __ ORA WORK + 1 
2043 : 05 03 __ ORA WORK + 0 
2045 : f0 1e __ BEQ $2065 ; (crt_fcmp + 60)
2047 : a5 1e __ LDA ACCU + 3 
2049 : 30 23 __ BMI $206e ; (crt_fcmp + 69)
204b : 10 28 __ BPL $2075 ; (crt_fcmp + 76)
204d : a5 1e __ LDA ACCU + 3 
204f : c5 06 __ CMP WORK + 3 
2051 : d0 15 __ BNE $2068 ; (crt_fcmp + 63)
2053 : a5 1d __ LDA ACCU + 2 
2055 : c5 05 __ CMP WORK + 2 
2057 : d0 0f __ BNE $2068 ; (crt_fcmp + 63)
2059 : a5 1c __ LDA ACCU + 1 
205b : c5 04 __ CMP WORK + 1 
205d : d0 09 __ BNE $2068 ; (crt_fcmp + 63)
205f : a5 1b __ LDA ACCU + 0 
2061 : c5 03 __ CMP WORK + 0 
2063 : d0 03 __ BNE $2068 ; (crt_fcmp + 63)
2065 : a9 00 __ LDA #$00
2067 : 60 __ __ RTS
2068 : b0 07 __ BCS $2071 ; (crt_fcmp + 72)
206a : 24 1e __ BIT ACCU + 3 
206c : 30 07 __ BMI $2075 ; (crt_fcmp + 76)
206e : a9 01 __ LDA #$01
2070 : 60 __ __ RTS
2071 : 24 1e __ BIT ACCU + 3 
2073 : 30 f9 __ BMI $206e ; (crt_fcmp + 69)
2075 : a9 ff __ LDA #$ff
2077 : 60 __ __ RTS
--------------------------------------------------------------------
mul32: ; mul32
2078 : a5 04 __ LDA WORK + 1 
207a : 05 05 __ ORA WORK + 2 
207c : 05 06 __ ORA WORK + 3 
207e : d0 05 __ BNE $2085 ; (mul32 + 13)
2080 : a5 03 __ LDA WORK + 0 
2082 : 4c 92 1b JMP $1b92 ; (mul32by8 + 0)
2085 : a0 00 __ LDY #$00
2087 : 84 07 __ STY WORK + 4 
2089 : 84 08 __ STY WORK + 5 
208b : 98 __ __ TYA
208c : 38 __ __ SEC
208d : 66 03 __ ROR WORK + 0 
208f : 90 15 __ BCC $20a6 ; (mul32 + 46)
2091 : aa __ __ TAX
2092 : 18 __ __ CLC
2093 : a5 07 __ LDA WORK + 4 
2095 : 65 1b __ ADC ACCU + 0 
2097 : 85 07 __ STA WORK + 4 
2099 : a5 08 __ LDA WORK + 5 
209b : 65 1c __ ADC ACCU + 1 
209d : 85 08 __ STA WORK + 5 
209f : 98 __ __ TYA
20a0 : 65 1d __ ADC ACCU + 2 
20a2 : a8 __ __ TAY
20a3 : 8a __ __ TXA
20a4 : 65 1e __ ADC ACCU + 3 
20a6 : 46 04 __ LSR WORK + 1 
20a8 : 90 0f __ BCC $20b9 ; (mul32 + 65)
20aa : aa __ __ TAX
20ab : 18 __ __ CLC
20ac : a5 08 __ LDA WORK + 5 
20ae : 65 1b __ ADC ACCU + 0 
20b0 : 85 08 __ STA WORK + 5 
20b2 : 98 __ __ TYA
20b3 : 65 1c __ ADC ACCU + 1 
20b5 : a8 __ __ TAY
20b6 : 8a __ __ TXA
20b7 : 65 1d __ ADC ACCU + 2 
20b9 : 46 05 __ LSR WORK + 2 
20bb : 90 09 __ BCC $20c6 ; (mul32 + 78)
20bd : aa __ __ TAX
20be : 18 __ __ CLC
20bf : 98 __ __ TYA
20c0 : 65 1b __ ADC ACCU + 0 
20c2 : a8 __ __ TAY
20c3 : 8a __ __ TXA
20c4 : 65 1c __ ADC ACCU + 1 
20c6 : 46 06 __ LSR WORK + 3 
20c8 : 90 03 __ BCC $20cd ; (mul32 + 85)
20ca : 18 __ __ CLC
20cb : 65 1b __ ADC ACCU + 0 
20cd : 06 1b __ ASL ACCU + 0 
20cf : 26 1c __ ROL ACCU + 1 
20d1 : 26 1d __ ROL ACCU + 2 
20d3 : 26 1e __ ROL ACCU + 3 
20d5 : 46 03 __ LSR WORK + 0 
20d7 : 90 cd __ BCC $20a6 ; (mul32 + 46)
20d9 : d0 b6 __ BNE $2091 ; (mul32 + 25)
20db : 84 09 __ STY WORK + 6 
20dd : 85 0a __ STA WORK + 7 
20df : 60 __ __ RTS
--------------------------------------------------------------------
divs32: ; divs32
20e0 : 24 1e __ BIT ACCU + 3 
20e2 : 10 0d __ BPL $20f1 ; (divs32 + 17)
20e4 : 20 fe 20 JSR $20fe ; (negaccu32 + 0)
20e7 : 24 06 __ BIT WORK + 3 
20e9 : 10 0d __ BPL $20f8 ; (divs32 + 24)
20eb : 20 18 21 JSR $2118 ; (negtmp32 + 0)
20ee : 4c 32 21 JMP $2132 ; (divmod32 + 0)
20f1 : 24 06 __ BIT WORK + 3 
20f3 : 10 f9 __ BPL $20ee ; (divs32 + 14)
20f5 : 20 18 21 JSR $2118 ; (negtmp32 + 0)
20f8 : 20 32 21 JSR $2132 ; (divmod32 + 0)
20fb : 4c fe 20 JMP $20fe ; (negaccu32 + 0)
--------------------------------------------------------------------
negaccu32: ; negaccu32
20fe : 38 __ __ SEC
20ff : a9 00 __ LDA #$00
2101 : e5 1b __ SBC ACCU + 0 
2103 : 85 1b __ STA ACCU + 0 
2105 : a9 00 __ LDA #$00
2107 : e5 1c __ SBC ACCU + 1 
2109 : 85 1c __ STA ACCU + 1 
210b : a9 00 __ LDA #$00
210d : e5 1d __ SBC ACCU + 2 
210f : 85 1d __ STA ACCU + 2 
2111 : a9 00 __ LDA #$00
2113 : e5 1e __ SBC ACCU + 3 
2115 : 85 1e __ STA ACCU + 3 
2117 : 60 __ __ RTS
--------------------------------------------------------------------
negtmp32: ; negtmp32
2118 : 38 __ __ SEC
2119 : a9 00 __ LDA #$00
211b : e5 03 __ SBC WORK + 0 
211d : 85 03 __ STA WORK + 0 
211f : a9 00 __ LDA #$00
2121 : e5 04 __ SBC WORK + 1 
2123 : 85 04 __ STA WORK + 1 
2125 : a9 00 __ LDA #$00
2127 : e5 05 __ SBC WORK + 2 
2129 : 85 05 __ STA WORK + 2 
212b : a9 00 __ LDA #$00
212d : e5 06 __ SBC WORK + 3 
212f : 85 06 __ STA WORK + 3 
2131 : 60 __ __ RTS
--------------------------------------------------------------------
divmod32: ; divmod32
2132 : 84 02 __ STY $02 
2134 : a0 20 __ LDY #$20
2136 : a9 00 __ LDA #$00
2138 : 85 07 __ STA WORK + 4 
213a : 85 08 __ STA WORK + 5 
213c : 85 09 __ STA WORK + 6 
213e : 85 0a __ STA WORK + 7 
2140 : a5 05 __ LDA WORK + 2 
2142 : 05 06 __ ORA WORK + 3 
2144 : d0 78 __ BNE $21be ; (divmod32 + 140)
2146 : a5 04 __ LDA WORK + 1 
2148 : d0 27 __ BNE $2171 ; (divmod32 + 63)
214a : 18 __ __ CLC
214b : 26 1b __ ROL ACCU + 0 
214d : 26 1c __ ROL ACCU + 1 
214f : 26 1d __ ROL ACCU + 2 
2151 : 26 1e __ ROL ACCU + 3 
2153 : 2a __ __ ROL
2154 : 90 05 __ BCC $215b ; (divmod32 + 41)
2156 : e5 03 __ SBC WORK + 0 
2158 : 38 __ __ SEC
2159 : b0 06 __ BCS $2161 ; (divmod32 + 47)
215b : c5 03 __ CMP WORK + 0 
215d : 90 02 __ BCC $2161 ; (divmod32 + 47)
215f : e5 03 __ SBC WORK + 0 
2161 : 88 __ __ DEY
2162 : d0 e7 __ BNE $214b ; (divmod32 + 25)
2164 : 85 07 __ STA WORK + 4 
2166 : 26 1b __ ROL ACCU + 0 
2168 : 26 1c __ ROL ACCU + 1 
216a : 26 1d __ ROL ACCU + 2 
216c : 26 1e __ ROL ACCU + 3 
216e : a4 02 __ LDY $02 
2170 : 60 __ __ RTS
2171 : a5 1e __ LDA ACCU + 3 
2173 : d0 10 __ BNE $2185 ; (divmod32 + 83)
2175 : a6 1d __ LDX ACCU + 2 
2177 : 86 1e __ STX ACCU + 3 
2179 : a6 1c __ LDX ACCU + 1 
217b : 86 1d __ STX ACCU + 2 
217d : a6 1b __ LDX ACCU + 0 
217f : 86 1c __ STX ACCU + 1 
2181 : 85 1b __ STA ACCU + 0 
2183 : a0 18 __ LDY #$18
2185 : 18 __ __ CLC
2186 : 26 1b __ ROL ACCU + 0 
2188 : 26 1c __ ROL ACCU + 1 
218a : 26 1d __ ROL ACCU + 2 
218c : 26 1e __ ROL ACCU + 3 
218e : 26 07 __ ROL WORK + 4 
2190 : 26 08 __ ROL WORK + 5 
2192 : 90 0c __ BCC $21a0 ; (divmod32 + 110)
2194 : a5 07 __ LDA WORK + 4 
2196 : e5 03 __ SBC WORK + 0 
2198 : aa __ __ TAX
2199 : a5 08 __ LDA WORK + 5 
219b : e5 04 __ SBC WORK + 1 
219d : 38 __ __ SEC
219e : b0 0c __ BCS $21ac ; (divmod32 + 122)
21a0 : 38 __ __ SEC
21a1 : a5 07 __ LDA WORK + 4 
21a3 : e5 03 __ SBC WORK + 0 
21a5 : aa __ __ TAX
21a6 : a5 08 __ LDA WORK + 5 
21a8 : e5 04 __ SBC WORK + 1 
21aa : 90 04 __ BCC $21b0 ; (divmod32 + 126)
21ac : 86 07 __ STX WORK + 4 
21ae : 85 08 __ STA WORK + 5 
21b0 : 88 __ __ DEY
21b1 : d0 d3 __ BNE $2186 ; (divmod32 + 84)
21b3 : 26 1b __ ROL ACCU + 0 
21b5 : 26 1c __ ROL ACCU + 1 
21b7 : 26 1d __ ROL ACCU + 2 
21b9 : 26 1e __ ROL ACCU + 3 
21bb : a4 02 __ LDY $02 
21bd : 60 __ __ RTS
21be : a0 10 __ LDY #$10
21c0 : a5 1e __ LDA ACCU + 3 
21c2 : 85 08 __ STA WORK + 5 
21c4 : a5 1d __ LDA ACCU + 2 
21c6 : 85 07 __ STA WORK + 4 
21c8 : a9 00 __ LDA #$00
21ca : 85 1d __ STA ACCU + 2 
21cc : 85 1e __ STA ACCU + 3 
21ce : 18 __ __ CLC
21cf : 26 1b __ ROL ACCU + 0 
21d1 : 26 1c __ ROL ACCU + 1 
21d3 : 26 07 __ ROL WORK + 4 
21d5 : 26 08 __ ROL WORK + 5 
21d7 : 26 09 __ ROL WORK + 6 
21d9 : 26 0a __ ROL WORK + 7 
21db : a5 07 __ LDA WORK + 4 
21dd : c5 03 __ CMP WORK + 0 
21df : a5 08 __ LDA WORK + 5 
21e1 : e5 04 __ SBC WORK + 1 
21e3 : a5 09 __ LDA WORK + 6 
21e5 : e5 05 __ SBC WORK + 2 
21e7 : aa __ __ TAX
21e8 : a5 0a __ LDA WORK + 7 
21ea : e5 06 __ SBC WORK + 3 
21ec : 90 11 __ BCC $21ff ; (divmod32 + 205)
21ee : 86 09 __ STX WORK + 6 
21f0 : 85 0a __ STA WORK + 7 
21f2 : a5 07 __ LDA WORK + 4 
21f4 : e5 03 __ SBC WORK + 0 
21f6 : 85 07 __ STA WORK + 4 
21f8 : a5 08 __ LDA WORK + 5 
21fa : e5 04 __ SBC WORK + 1 
21fc : 85 08 __ STA WORK + 5 
21fe : 38 __ __ SEC
21ff : 88 __ __ DEY
2200 : d0 cd __ BNE $21cf ; (divmod32 + 157)
2202 : 26 1b __ ROL ACCU + 0 
2204 : 26 1c __ ROL ACCU + 1 
2206 : a4 02 __ LDY $02 
2208 : 60 __ __ RTS
--------------------------------------------------------------------
mods32: ; mods32
2209 : 24 1e __ BIT ACCU + 3 
220b : 10 13 __ BPL $2220 ; (mods32 + 23)
220d : 20 fe 20 JSR $20fe ; (negaccu32 + 0)
2210 : 24 06 __ BIT WORK + 3 
2212 : 10 03 __ BPL $2217 ; (mods32 + 14)
2214 : 20 18 21 JSR $2118 ; (negtmp32 + 0)
2217 : 20 32 21 JSR $2132 ; (divmod32 + 0)
221a : 4c 2a 22 JMP $222a ; (negtmp32b + 0)
221d : 4c 32 21 JMP $2132 ; (divmod32 + 0)
2220 : 24 06 __ BIT WORK + 3 
2222 : 10 f9 __ BPL $221d ; (mods32 + 20)
2224 : 20 18 21 JSR $2118 ; (negtmp32 + 0)
2227 : 4c 32 21 JMP $2132 ; (divmod32 + 0)
--------------------------------------------------------------------
negtmp32b: ; negtmp32b
222a : 38 __ __ SEC
222b : a9 00 __ LDA #$00
222d : e5 07 __ SBC WORK + 4 
222f : 85 07 __ STA WORK + 4 
2231 : a9 00 __ LDA #$00
2233 : e5 08 __ SBC WORK + 5 
2235 : 85 08 __ STA WORK + 5 
2237 : a9 00 __ LDA #$00
2239 : e5 09 __ SBC WORK + 6 
223b : 85 09 __ STA WORK + 6 
223d : a9 00 __ LDA #$00
223f : e5 0a __ SBC WORK + 7 
2241 : 85 0a __ STA WORK + 7 
2243 : 60 __ __ RTS
--------------------------------------------------------------------
__multab16384H:
2244 : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
spentry:
2248 : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
b_mem:
2249 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
224b : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
224d : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_gosubSP:
224f : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
2251 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tab:
2253 : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
2263 : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
2273 : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
2283 : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
2293 : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
22a3 : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
22b3 : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
22c3 : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
b_rndSeed:
22d3 : __ __ __ BYT 78 56 34 12                                     : xV4.
--------------------------------------------------------------------
tsb_drawtab:
22d7 : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_ci:
22df : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_bi:
22e3 : __ __ __ BSS	2
--------------------------------------------------------------------
tsb_sintab:
2300 : __ __ __ BSS	64
--------------------------------------------------------------------
b_a_hi:
2340 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_ti:
2390 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_ei:
2400 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_chi:
2450 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_di:
24a0 : __ __ __ BSS	80
--------------------------------------------------------------------
b_gosubStack:
24f0 : __ __ __ BSS	512
