/* OPTIMIZE_C -- povray.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_bei;
static int b_v_gbi;
static breal_t b_a_sxf[48];
static breal_t b_a_syf[48];
static breal_t b_a_szf[48];
static breal_t b_a_srf[48];
static breal_t b_a_smf[48];
static breal_t b_a_kxf[64];
static breal_t b_a_kyf[64];
static breal_t b_a_kzf[64];
static bstr_t b_a_sns[16];
static breal_t b_a_uxf[200];
static breal_t b_a_uyf[200];
static breal_t b_a_uzf[200];
static breal_t b_a_vxf[200];
static breal_t b_a_vyf[200];
static breal_t b_a_vzf[200];
static bint_t b_v_nsi;
static bint_t b_v_nbi;
static breal_t b_v_kcf;
static bint_t b_v_nki;
static bint_t b_v_ami;
static breal_t b_v_apf;
static breal_t b_v_spf;
static int b_v_sci;
static bint_t b_v_fri;
static int b_v_cfi;
static breal_t b_v_ccf;
static breal_t b_v_caf;
static breal_t b_v_ssf;
static int b_v_ii;
static bint_t b_v_pbi;
static breal_t b_v_zwf;
static breal_t b_v_yf;
static breal_t b_v_zxf;
static breal_t b_v_pwf;
static int b_v_pxi;
static breal_t b_v_xf;
static breal_t b_v_rxf;
static breal_t b_v_ryf;
static breal_t b_v_rzf;
static breal_t b_v_rwf;
static breal_t b_v_oxf;
static breal_t b_v_exf;
static breal_t b_v_oyf;
static breal_t b_v_eyf;
static breal_t b_v_ozf;
static breal_t b_v_ezf;
static int b_v_rdi;
static breal_t b_v_tff;
static breal_t b_v_gyf;
static breal_t b_v_htf;
static int b_v_hmi;
static breal_t b_v_tf;
static breal_t b_v_btf;
static bint_t b_v_fai;
static breal_t b_v_fxf;
static breal_t b_v_fzf;
static breal_t b_v_csf;
static bint_t b_v_shi;
static breal_t b_v_hxf;
static breal_t b_v_hyf;
static breal_t b_v_hzf;
static breal_t b_v_nxf;
static breal_t b_v_kf;
static breal_t b_v_nyf;
static breal_t b_v_nzf;
static breal_t b_v_x1f;
static breal_t b_v_x2f;
static breal_t b_v_x3f;
static breal_t b_v_laf;
static breal_t b_v_f1f;
static breal_t b_v_f2f;
static breal_t b_v_f3f;
static breal_t b_v_df;
static breal_t b_v_lxf;
static breal_t b_v_lyf;
static breal_t b_v_lzf;
static breal_t b_v_nlf;
static bstr_t b_v_as;
static breal_t b_v_pf;
static breal_t b_v_qf;
static breal_t b_v_z1f;
static breal_t b_v_z2f;
static breal_t b_v_wuf;
static breal_t b_v_z0f;
static int b_v_bki;
static breal_t b_v_tmf;
static breal_t b_v_txf;
static breal_t b_v_a1f;
static breal_t b_v_a2f;
static breal_t b_v_b1f;
static breal_t b_v_b2f;
static breal_t b_v_c1f;
static breal_t b_v_c2f;
static bstr_t b_v_obs;
static breal_t b_v_dxf;
static breal_t b_v_dzf;
static breal_t b_v_daf;
static breal_t b_v_dbf;
static breal_t b_v_dcf;
static breal_t b_v_ddf;
static breal_t b_v_def;
static breal_t b_v_dff;
static int b_v_bni;
static int b_v_bsi;
static bstr_t b_v_nms;
static breal_t b_v_sgf;
static breal_t b_v_p1f;
static breal_t b_v_p2f;
static breal_t b_v_ftf;
static breal_t b_v_axf;
static breal_t b_v_azf;
static bint_t b_t_0;
static bint_t b_t_1;
typedef struct { int vtype; void* pI; union { bint_t i; breal_t f; } lim; union { bint_t i; breal_t f; } step; int top_id; } b_rtfor_t;
static b_rtfor_t b_rtfor_stack[3];
static int b_rtfor_sp=0;
static int b_fl_3;
static int b_fl_4;
static int b_fl_5;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{2,0,0,"SCENE",5},{2,0,0,"CITY",4},{2,0,0,"CAMERA",6},{1,0,-7,0,0},{1,0,2.7999999999999998,0,0},{1,0,-28,0,0},{1,0,-7,0,0},{1,0,3,0,0},{2,0,0,"LIGHT",5},{1,0,-20,0,0},{1,0,40,0,0},{1,0,-20,0,0},{2,0,0,"PLANE",5},{1,0,-0.20000000000000001,0,0},{1,0,2,0,0},{2,0,0,"BOX",3},{1,0,-20,0,0},{1,0,0,0,0},{1,0,-20,0,0},{1,0,-10,0,0},{1,0,7,0,0},{1,0,-10,0,0},{2,0,0,"BOX",3},{1,0,-4,0,0},{1,0,0,0,0},{1,0,-20,0,0},{1,0,6,0,0},{1,0,10,0,0},{1,0,-10,0,0},{2,0,0,"BOX",3},{1,0,10,0,0},{1,0,0,0,0},{1,0,-20,0,0},{1,0,20,0,0},{1,0,8,0,0},{1,0,-10,0,0},{2,0,0,"BOX",3},{1,0,-20,0,0},{1,0,0,0,0},{1,0,-4,0,0},{1,0,-10,0,0},{1,0,6,0,0},{1,0,4,0,0},{2,0,0,"BOX",3},{1,0,-4,0,0},{1,0,0,0,0},{1,0,-4,0,0},{1,0,6,0,0},{1,0,12,0,0},{1,0,4,0,0},{2,0,0,"BOX",3},{1,0,10,0,0},{1,0,0,0,0},{1,0,-4,0,0},{1,0,20,0,0},{1,0,9,0,0},{1,0,4,0,0},{2,0,0,"BOX",3},{1,0,-20,0,0},{1,0,0,0,0},{1,0,10,0,0},{1,0,-10,0,0},{1,0,5,0,0},{1,0,20,0,0},{2,0,0,"BOX",3},{1,0,-4,0,0},{1,0,0,0,0},{1,0,10,0,0},{1,0,6,0,0},{1,0,8,0,0},{1,0,20,0,0},{2,0,0,"BOX",3},{1,0,10,0,0},{1,0,0,0,0},{1,0,10,0,0},{1,0,20,0,0},{1,0,7,0,0},{1,0,20,0,0},{2,0,0,"BOX",3},{1,0,-8,0,0},{1,0,0,0,0},{1,0,-16,0,0},{1,0,-6,0,0},{1,0,0.69999999999999996,0,0},{1,0,-14,0,0},{2,0,0,"BOX",3},{1,0,-1,0,0},{1,0,0,0,0},{1,0,-8,0,0},{1,0,1,0,0},{1,0,0.69999999999999996,0,0},{1,0,-6,0,0},{2,0,0,"BOX",3},{1,0,7,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,9,0,0},{1,0,0.69999999999999996,0,0},{1,0,4,0,0},{2,0,0,"BOX",3},{1,0,-3,0,0},{1,0,0,0,0},{1,0,6,0,0},{1,0,-1,0,0},{1,0,0.69999999999999996,0,0},{1,0,8,0,0},{2,0,0,"ANIMATE",7},{1,0,10,0,0},{1,0,0.040000000000000001,0,0},{2,0,0,"KF",2},{1,0,-7,0,0},{1,0,2.7999999999999998,0,0},{1,0,-28,0,0},{2,0,0,"KF",2},{1,0,-7,0,0},{1,0,2.7999999999999998,0,0},{1,0,-11,0,0},{2,0,0,"KF",2},{1,0,-3,0,0},{1,0,2.7999999999999998,0,0},{1,0,-7,0,0},{2,0,0,"KF",2},{1,0,4,0,0},{1,0,2.7999999999999998,0,0},{1,0,-7,0,0},{2,0,0,"KF",2},{1,0,8,0,0},{1,0,2.7999999999999998,0,0},{1,0,-3,0,0},{2,0,0,"KF",2},{1,0,8,0,0},{1,0,2.7999999999999998,0,0},{1,0,3,0,0},{2,0,0,"KF",2},{1,0,4,0,0},{1,0,2.7999999999999998,0,0},{1,0,7,0,0},{2,0,0,"KF",2},{1,0,-3,0,0},{1,0,2.7999999999999998,0,0},{1,0,7,0,0},{2,0,0,"KF",2},{1,0,-7,0,0},{1,0,2.7999999999999998,0,0},{1,0,3,0,0},{2,0,0,"KF",2},{1,0,-7,0,0},{1,0,2.7999999999999998,0,0},{1,0,-20,0,0},{2,0,0,"END",3},{2,0,0,"SCENE",5},{2,0,0,"STILL",5},{2,0,0,"CAMERA",6},{1,0,0,0,0},{1,0,2.5,0,0},{1,0,-8,0,0},{1,0,0,0,0},{1,0,2,0,0},{2,0,0,"LIGHT",5},{1,0,-20,0,0},{1,0,30,0,0},{1,0,-20,0,0},{2,0,0,"PLANE",5},{1,0,-1,0,0},{1,0,4,0,0},{2,0,0,"SPHERE",6},{1,0,-2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,1,0,0},{1,0,0,0,0},{2,0,0,"SPHERE",6},{1,0,0,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,1.5,0,0},{1,0,1,0,0},{2,0,0,"SPHERE",6},{1,0,2,0,0},{1,0,0,0,0},{1,0,2,0,0},{1,0,0.5,0,0},{1,0,1,0,0},{2,0,0,"BOX",3},{1,0,4,0,0},{1,0,-1,0,0},{1,0,1,0,0},{1,0,6,0,0},{1,0,2,0,0},{1,0,3,0,0},{2,0,0,"END",3},{2,0,0,"STOP",4}};
int b_data_len = 192;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		/* line 40 */
b_L40: ;
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		/* line 80 */
b_L80: ;
		/* line 85 */
b_L85: ;
		/* line 90 */
b_L90: ;
		/* line 100 */
b_L100: ;
		/* line 110 */
b_L110: ;
		/* line 120 */
b_L120: ;
		b_v_bei=(25);
		/* line 130 */
b_L130: ;
		b_v_gbi=(26);
		/* line 140 */
b_L140: ;
		/* line 145 */
b_L145: ;
		/* line 146 */
b_L146: ;
		/* line 150 */
b_L150: ;
		/* line 160 */
b_L160: ;
		b_v_nsi=(-1);
		/* line 170 */
b_L170: ;
		b_v_nbi=(-1);
		/* line 175 */
b_L175: ;
		b_v_kcf=(0);
		b_v_nki=(-1);
		b_v_ami=(0);
		b_v_apf=(0);
		b_v_spf=(0);
		b_v_sci=(0);
		/* line 180 */
b_L180: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L10900;
b_ret0: ;
		/* line 190 */
b_L190: ;
		b_poke((53272.0),(11));
		/* line 200 */
b_L200: ;
		b_poke((53265.0),(59));
		/* line 210 */
b_L210: ;
		b_poke((56576.0),(148));
		/* line 220 */
b_L220: ;
		b_v_fri=(0);
		/* line 230 */
b_L230: ;
		b_v_cfi=(0);
		/* line 240 */
b_L240: ;
		if(-((b_v_ami) == ((0)))){ goto b_L250; }
		/* line 242 */
b_L242: ;
		b_v_apf=((b_v_apf)+(b_v_spf));
		if(-((b_v_apf) >= (b_v_kcf))){
			b_v_apf=((b_v_apf)-(b_v_kcf));
		}
		/* line 244 */
b_L244: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L10940;
b_ret1: ;
		/* line 250 */
b_L250: ;
		b_v_ccf=b_cos(b_v_caf);
		b_v_ssf=b_sin(b_v_caf);
		/* line 260 */
b_L260: ;
		if(-((b_v_cfi) == ((0)))){ goto b_L280; }
		/* line 270 */
b_L270: ;
		goto b_L330;
		/* line 280 */
b_L280: ;
		b_v_ii=(1024);
		if(b_v_ii > 2023) goto b_f0_e;
		b_t_0=(((48128.0))+(b_v_ii));
		b_t_1=(((54272.0))+(b_v_ii));
b_f0_t: ;
		/* line 290 */
b_L290: ;
		b_poke(b_t_0,(15));
		/* line 300 */
b_L300: ;
		b_poke(b_t_1,(0));
		/* line 310 */
b_L310: ;
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 2023) goto b_f0_t;
b_f0_e: ;
		/* line 320 */
b_L320: ;
		b_v_cfi=(1);
		/* line 330 */
b_L330: ;
		b_v_pbi=(0);
		if(b_v_pbi > 8000) goto b_f1_e;
		{ b_rtfor_t _f; _f.top_id=1; _f.pI=&b_v_pbi; _f.vtype=0; _f.lim.i=8000; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f1_t: ;
		/* line 340 */
b_L340: ;
		b_v_zwf=(B_INT(b_v_pbi) & B_INT((7)));
		/* line 350 */
b_L350: ;
		b_v_yf=((((b_int(((breal_t)(b_v_pbi)/(breal_t)((320)))))*((8))))+(b_v_zwf));
		/* line 360 */
b_L360: ;
		b_v_zwf=b_int(((breal_t)(b_v_pbi)/(breal_t)((8))));
		/* line 370 */
b_L370: ;
		b_v_zxf=((((b_v_zwf)-(((b_int((b_v_zwf/(breal_t)((40)))))*((40))))))*((8)));
		/* line 380 */
b_L380: ;
		b_v_pwf=(0);
		/* line 390 */
b_L390: ;
		b_v_pxi=(0);
		if(b_v_pxi > 7) goto b_f2_e;
		{ b_rtfor_t _f; _f.top_id=2; _f.pI=&b_v_pxi; _f.vtype=1; _f.lim.i=7; _f.step.i=1; b_rtfor_stack[b_rtfor_sp++]=_f; }
b_f2_t: ;
		/* line 400 */
b_L400: ;
		b_v_xf=((b_v_zxf)+(b_v_pxi));
		/* line 410 */
b_L410: ;
		b_v_zwf=((breal_t)(b_v_gbi)/(breal_t)((320)));
		/* line 420 */
b_L420: ;
		b_v_rxf=((((b_v_xf)*(b_v_zwf)))-(((breal_t)(b_v_gbi)/(breal_t)((2)))));
		/* line 430 */
b_L430: ;
		b_v_ryf=(((((-(b_v_yf)))*(b_v_zwf)))+(((((breal_t)((200))/(breal_t)((2))))*(b_v_zwf))));
		/* line 440 */
b_L440: ;
		b_v_rzf=b_v_bei;
		/* line 450 */
b_L450: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 460 */
b_L460: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 470 */
b_L470: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 480 */
b_L480: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 490 */
b_L490: ;
		b_v_rwf=((((b_v_rxf)*(b_v_ccf)))+(((b_v_rzf)*(b_v_ssf))));
		/* line 500 */
b_L500: ;
		b_v_rzf=(((((-(b_v_rxf)))*(b_v_ssf)))+(((b_v_rzf)*(b_v_ccf))));
		/* line 510 */
b_L510: ;
		b_v_rxf=b_v_rwf;
		/* line 520 */
b_L520: ;
		b_v_oxf=b_v_exf;
		/* line 530 */
b_L530: ;
		b_v_oyf=b_v_eyf;
		/* line 540 */
b_L540: ;
		b_v_ozf=b_v_ezf;
		/* line 550 */
b_L550: ;
		b_v_rdi=(0);
		/* line 560 */
b_L560: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L10000;
b_ret2: ;
		/* line 570 */
b_L570: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L10200;
b_ret3: ;
		/* line 580 */
b_L580: ;
		b_v_tff=(99999.0);
		/* line 590 */
b_L590: ;
		if(-((b_v_ryf) < ((0)))){
			b_v_tff=(((b_v_gyf)-(b_v_oyf))/b_v_ryf);
		}
		/* line 600 */
b_L600: ;
		b_v_htf=b_v_tff;
		/* line 610 */
b_L610: ;
		b_v_hmi=(0);
		/* line 620 */
b_L620: ;
		if(-((b_v_tf) < (b_v_htf))){
			b_v_htf=b_v_tf;
			b_v_hmi=(1);
		}
		/* line 630 */
b_L630: ;
		if(-((b_v_btf) < (b_v_htf))){
			b_v_htf=b_v_btf;
			b_v_hmi=(2);
		}
		/* line 640 */
b_L640: ;
		if(-((b_v_htf) >= ((99999.0)))){
			b_v_fai=(0);
			goto b_L1280;
		}
		/* line 650 */
b_L650: ;
		if(-((b_v_hmi) == ((0)))){ goto b_L680; }
		/* line 660 */
b_L660: ;
		if(-((b_v_hmi) == ((1)))){ goto b_L790; }
		/* line 670 */
b_L670: ;
		goto b_L10720;
		/* line 680 */
b_L680: ;
		/* line 690 */
b_L690: ;
		b_v_fxf=((b_v_oxf)+(((b_v_tff)*(b_v_rxf))));
		/* line 700 */
b_L700: ;
		b_v_fzf=((b_v_ozf)+(((b_v_tff)*(b_v_rzf))));
		/* line 710 */
b_L710: ;
		b_v_zwf=((((bint_t)(b_int((b_v_fxf/b_v_csf))) & B_INT((1))))+(((bint_t)(b_int((b_v_fzf/b_v_csf))) & B_INT((1)))));
		/* line 720 */
b_L720: ;
		b_v_fai=((-((b_v_zwf) == ((1))))+((1)));
		/* line 730 */
b_L730: ;
		b_v_oxf=b_v_fxf;
		/* line 740 */
b_L740: ;
		b_v_oyf=b_v_gyf;
		/* line 750 */
b_L750: ;
		b_v_ozf=b_v_fzf;
		/* line 760 */
b_L760: ;
		b_gosubStack[b_gosubSP++]=4; goto b_L10500;
b_ret4: ;
		/* line 770 */
b_L770: ;
		if(-((b_v_shi) == ((1)))){
			b_v_fai=(0);
		}
		/* line 780 */
b_L780: ;
		goto b_L1280;
		/* line 790 */
b_L790: ;
		/* line 800 */
b_L800: ;
		b_v_hxf=((b_v_oxf)+(((b_v_tf)*(b_v_rxf))));
		/* line 810 */
b_L810: ;
		b_v_hyf=((b_v_oyf)+(((b_v_tf)*(b_v_ryf))));
		/* line 820 */
b_L820: ;
		b_v_hzf=((b_v_ozf)+(((b_v_tf)*(b_v_rzf))));
		/* line 830 */
b_L830: ;
		b_v_nxf=(((b_v_hxf)-(b_a_sxf[(bint_t)(b_v_kf)]))/b_a_srf[(bint_t)(b_v_kf)]);
		/* line 840 */
b_L840: ;
		b_v_nyf=(((b_v_hyf)-(b_a_syf[(bint_t)(b_v_kf)]))/b_a_srf[(bint_t)(b_v_kf)]);
		/* line 850 */
b_L850: ;
		b_v_nzf=(((b_v_hzf)-(b_a_szf[(bint_t)(b_v_kf)]))/b_a_srf[(bint_t)(b_v_kf)]);
		/* line 860 */
b_L860: ;
		if(-((b_a_smf[(bint_t)(b_v_kf)]) == ((0)))){ goto b_L1110; }
		/* line 870 */
b_L870: ;
		/* line 880 */
b_L880: ;
		b_v_x1f=((((((b_a_sxf[(bint_t)(b_v_kf)])*(b_v_rxf)))+(((b_a_syf[(bint_t)(b_v_kf)])*(b_v_ryf)))))+(((b_a_szf[(bint_t)(b_v_kf)])*(b_v_rzf))));
		/* line 890 */
b_L890: ;
		b_v_x2f=((((((b_v_oxf)*(b_v_rxf)))+(((b_v_oyf)*(b_v_ryf)))))+(((b_v_ozf)*(b_v_rzf))));
		/* line 900 */
b_L900: ;
		b_v_x3f=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 910 */
b_L910: ;
		b_v_laf=(((b_v_x1f)-(b_v_x2f))/b_v_x3f);
		/* line 920 */
b_L920: ;
		b_v_f1f=((((b_v_oxf)+(((b_v_laf)*(b_v_rxf)))))-(b_a_sxf[(bint_t)(b_v_kf)]));
		/* line 930 */
b_L930: ;
		b_v_f2f=((((b_v_oyf)+(((b_v_laf)*(b_v_ryf)))))-(b_a_syf[(bint_t)(b_v_kf)]));
		/* line 940 */
b_L940: ;
		b_v_f3f=((((b_v_ozf)+(((b_v_laf)*(b_v_rzf)))))-(b_a_szf[(bint_t)(b_v_kf)]));
		/* line 950 */
b_L950: ;
		b_v_df=b_sqr(((((((b_v_f1f)*(b_v_f1f)))+(((b_v_f2f)*(b_v_f2f)))))+(((b_v_f3f)*(b_v_f3f)))));
		/* line 960 */
b_L960: ;
		if(-((((b_a_srf[(bint_t)(b_v_kf)])*((0.94999999995343387)))) < (b_v_df))){
			b_v_fai=(1);
			goto b_L1280;
		}
		/* line 970 */
b_L970: ;
		b_v_rdi=((b_v_rdi)+((1)));
		/* line 980 */
b_L980: ;
		if(-((b_v_rdi) > ((3)))){
			b_v_fai=(1);
			goto b_L1280;
		}
		/* line 990 */
b_L990: ;
		b_v_zwf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 1000 */
b_L1000: ;
		b_v_rxf=((b_v_rxf)-((((((2))*(b_v_zwf)))*(b_v_nxf))));
		/* line 1010 */
b_L1010: ;
		b_v_ryf=((b_v_ryf)-((((((2))*(b_v_zwf)))*(b_v_nyf))));
		/* line 1020 */
b_L1020: ;
		b_v_rzf=((b_v_rzf)-((((((2))*(b_v_zwf)))*(b_v_nzf))));
		/* line 1030 */
b_L1030: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 1040 */
b_L1040: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 1050 */
b_L1050: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 1060 */
b_L1060: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 1070 */
b_L1070: ;
		b_v_oxf=b_v_hxf;
		/* line 1080 */
b_L1080: ;
		b_v_oyf=b_v_hyf;
		/* line 1090 */
b_L1090: ;
		b_v_ozf=b_v_hzf;
		/* line 1100 */
b_L1100: ;
		goto b_L560;
		/* line 1110 */
b_L1110: ;
		/* line 1120 */
b_L1120: ;
		b_v_rxf=((b_v_lxf)-(b_v_hxf));
		/* line 1130 */
b_L1130: ;
		b_v_ryf=((b_v_lyf)-(b_v_hyf));
		/* line 1140 */
b_L1140: ;
		b_v_rzf=((b_v_lzf)-(b_v_hzf));
		/* line 1150 */
b_L1150: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 1160 */
b_L1160: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 1170 */
b_L1170: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 1180 */
b_L1180: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 1190 */
b_L1190: ;
		b_v_nlf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 1200 */
b_L1200: ;
		if(-((b_v_nlf) <= ((0)))){
			b_v_fai=(0);
			goto b_L1280;
		}
		/* line 1210 */
b_L1210: ;
		b_v_oxf=b_v_hxf;
		/* line 1220 */
b_L1220: ;
		b_v_oyf=b_v_hyf;
		/* line 1230 */
b_L1230: ;
		b_v_ozf=b_v_hzf;
		/* line 1240 */
b_L1240: ;
		b_gosubStack[b_gosubSP++]=5; goto b_L10500;
b_ret5: ;
		/* line 1250 */
b_L1250: ;
		if(-((b_v_shi) == ((1)))){
			b_v_fai=(0);
			goto b_L1280;
		}
		/* line 1260 */
b_L1260: ;
		b_v_fai=(1);
		/* line 1270 */
b_L1270: ;
		goto b_L1280;
		/* line 1280 */
b_L1280: ;
		b_v_pwf=((((b_v_pwf)*((2))))+(b_v_fai));
		/* line 1290 */
b_L1290: ;
		b_v_pxi += 1;
		if(b_v_pxi <= 7) goto b_f2_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f2_e: ;
		/* line 1300 */
b_L1300: ;
		b_poke((((57344.0))+(b_v_pbi)),b_v_pwf);
		/* line 1310 */
b_L1310: ;
		b_v_pbi += 1;
		if(b_v_pbi <= 8000) goto b_f1_t;
		if(b_rtfor_sp>0) --b_rtfor_sp;
b_f1_e: ;
		/* line 1320 */
b_L1320: ;
		b_v_fri=((b_v_fri)+((1)));
		/* line 1330 */
b_L1330: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		/* line 1332 */
b_L1332: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)))){ goto b_L1440; }
		/* line 1334 */
b_L1334: ;
		if(-((b_v_ami) == ((1)))){ goto b_L240; }
		/* line 1340 */
b_L1340: ;
		if(-(b_strcmp(b_v_as,b_lit("\035",1)) == 0)){
			b_v_caf=((b_v_caf)+((0.10000000000582077)));
			goto b_L240;
		}
		/* line 1350 */
b_L1350: ;
		if(-(b_strcmp(b_v_as,b_lit("\235",1)) == 0)){
			b_v_caf=((b_v_caf)-((0.10000000000582077)));
			goto b_L240;
		}
		/* line 1360 */
b_L1360: ;
		if(-(b_strcmp(b_v_as,b_lit("\221",1)) == 0)){
			b_v_eyf=((b_v_eyf)+((1)));
			goto b_L240;
		}
		/* line 1370 */
b_L1370: ;
		if(-(b_strcmp(b_v_as,b_lit("\021",1)) == 0)){
			b_v_eyf=((b_v_eyf)-((1)));
			goto b_L240;
		}
		/* line 1380 */
b_L1380: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)))){
			b_v_exf=((b_v_exf)+(b_v_ssf));
			b_v_ezf=((b_v_ezf)+(b_v_ccf));
			goto b_L240;
		}
		/* line 1390 */
b_L1390: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)))){
			b_v_exf=((b_v_exf)-(b_v_ssf));
			b_v_ezf=((b_v_ezf)-(b_v_ccf));
			goto b_L240;
		}
		/* line 1400 */
b_L1400: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)))){
			b_v_exf=((b_v_exf)-(b_v_ccf));
			b_v_ezf=((b_v_ezf)+(b_v_ssf));
			goto b_L240;
		}
		/* line 1410 */
b_L1410: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)))){
			b_v_exf=((b_v_exf)+(b_v_ccf));
			b_v_ezf=((b_v_ezf)-(b_v_ssf));
			goto b_L240;
		}
		/* line 1420 */
b_L1420: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)))){ goto b_L1440; }
		/* line 1430 */
b_L1430: ;
		goto b_L240;
		/* line 1440 */
b_L1440: ;
		goto b_end;
		/* line 10000 */
b_L10000: ;
		/* line 10005 */
b_L10005: ;
		b_v_kf=(-1);
		/* line 10010 */
b_L10010: ;
		b_v_tf=(99999.0);
		/* line 10015 */
b_L10015: ;
		b_v_ii=(0);
		b_fl_3=b_v_nsi;
		if(b_v_ii > b_fl_3) goto b_f3_e;
b_f3_t: ;
		/* line 10020 */
b_L10020: ;
		b_v_zwf=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 10025 */
b_L10025: ;
		b_v_pf=((((2))*(((((((b_v_rxf)*(((b_v_oxf)-(b_a_sxf[B_INT(b_v_ii)])))))+(((b_v_ryf)*(((b_v_oyf)-(b_a_syf[B_INT(b_v_ii)])))))))+(((b_v_rzf)*(((b_v_ozf)-(b_a_szf[B_INT(b_v_ii)]))))))))/b_v_zwf);
		/* line 10030 */
b_L10030: ;
		b_v_qf=(((((((((((b_v_oxf)-(b_a_sxf[B_INT(b_v_ii)])))*(((b_v_oxf)-(b_a_sxf[B_INT(b_v_ii)])))))+(((((b_v_oyf)-(b_a_syf[B_INT(b_v_ii)])))*(((b_v_oyf)-(b_a_syf[B_INT(b_v_ii)])))))))+(((((b_v_ozf)-(b_a_szf[B_INT(b_v_ii)])))*(((b_v_ozf)-(b_a_szf[B_INT(b_v_ii)])))))))-(((b_a_srf[B_INT(b_v_ii)])*(b_a_srf[B_INT(b_v_ii)]))))/b_v_zwf);
		/* line 10035 */
b_L10035: ;
		b_v_z1f=((-(b_v_pf))/(breal_t)((2)));
		/* line 10040 */
b_L10040: ;
		b_v_z2f=(((((b_v_pf)*(b_v_pf))/(breal_t)((4))))-(b_v_qf));
		/* line 10045 */
b_L10045: ;
		if(-((b_v_z2f) < ((0)))){
			b_v_ii += 1;
			if(b_v_ii <= (b_fl_3)) goto b_f3_t;
			goto b_return;
		}
		/* line 10050 */
b_L10050: ;
		b_v_wuf=b_sqr(b_v_z2f);
		/* line 10055 */
b_L10055: ;
		b_v_x1f=((b_v_z1f)+(b_v_wuf));
		/* line 10060 */
b_L10060: ;
		b_v_x2f=((b_v_z1f)-(b_v_wuf));
		/* line 10065 */
b_L10065: ;
		b_v_z0f=(-((B_INT(-((b_v_x1f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x1f) < (b_v_tf))))));
		/* line 10070 */
b_L10070: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 10075 */
b_L10075: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 10080 */
b_L10080: ;
		b_v_tf=((((b_v_z0f)*(b_v_x1f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 10085 */
b_L10085: ;
		b_v_z0f=(-((B_INT(-((b_v_x2f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x2f) < (b_v_tf))))));
		/* line 10090 */
b_L10090: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 10095 */
b_L10095: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 10100 */
b_L10100: ;
		b_v_tf=((((b_v_z0f)*(b_v_x2f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 10105 */
b_L10105: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 10110 */
b_L10110: ;
		goto b_return;
		/* line 10200 */
b_L10200: ;
		/* line 10205 */
b_L10205: ;
		b_v_bki=(-1);
		/* line 10210 */
b_L10210: ;
		b_v_btf=(99999.0);
		/* line 10215 */
b_L10215: ;
		b_v_ii=(0);
		b_fl_4=b_v_nbi;
		if(b_v_ii > b_fl_4) goto b_f4_e;
b_f4_t: ;
		/* line 10220 */
b_L10220: ;
		b_v_tmf=(-((99999.0)));
		/* line 10225 */
b_L10225: ;
		b_v_txf=(99999.0);
		/* line 10230 */
b_L10230: ;
		/* line 10235 */
b_L10235: ;
		if(-((b_abs(b_v_rxf)) >= ((0.00010000000000331966)))){ goto b_L10250; }
		/* line 10240 */
b_L10240: ;
		if((B_INT(-((b_v_oxf) < (b_a_uxf[B_INT(b_v_ii)]))) | B_INT(-((b_v_oxf) > (b_a_vxf[B_INT(b_v_ii)]))))){ goto b_L10380; }
		/* line 10245 */
b_L10245: ;
		goto b_L10275;
		/* line 10250 */
b_L10250: ;
		b_v_a1f=(((b_a_uxf[B_INT(b_v_ii)])-(b_v_oxf))/b_v_rxf);
		/* line 10255 */
b_L10255: ;
		b_v_a2f=(((b_a_vxf[B_INT(b_v_ii)])-(b_v_oxf))/b_v_rxf);
		/* line 10260 */
b_L10260: ;
		if(-((b_v_a1f) > (b_v_a2f))){
			b_v_zwf=b_v_a1f;
			b_v_a1f=b_v_a2f;
			b_v_a2f=b_v_zwf;
		}
		/* line 10265 */
b_L10265: ;
		if(-((b_v_a1f) > (b_v_tmf))){
			b_v_tmf=b_v_a1f;
		}
		/* line 10270 */
b_L10270: ;
		if(-((b_v_a2f) < (b_v_txf))){
			b_v_txf=b_v_a2f;
		}
		/* line 10275 */
b_L10275: ;
		/* line 10280 */
b_L10280: ;
		if(-((b_abs(b_v_ryf)) >= ((0.00010000000000331966)))){ goto b_L10295; }
		/* line 10285 */
b_L10285: ;
		if((B_INT(-((b_v_oyf) < (b_a_uyf[B_INT(b_v_ii)]))) | B_INT(-((b_v_oyf) > (b_a_vyf[B_INT(b_v_ii)]))))){ goto b_L10380; }
		/* line 10290 */
b_L10290: ;
		goto b_L10320;
		/* line 10295 */
b_L10295: ;
		b_v_b1f=(((b_a_uyf[B_INT(b_v_ii)])-(b_v_oyf))/b_v_ryf);
		/* line 10300 */
b_L10300: ;
		b_v_b2f=(((b_a_vyf[B_INT(b_v_ii)])-(b_v_oyf))/b_v_ryf);
		/* line 10305 */
b_L10305: ;
		if(-((b_v_b1f) > (b_v_b2f))){
			b_v_zwf=b_v_b1f;
			b_v_b1f=b_v_b2f;
			b_v_b2f=b_v_zwf;
		}
		/* line 10310 */
b_L10310: ;
		if(-((b_v_b1f) > (b_v_tmf))){
			b_v_tmf=b_v_b1f;
		}
		/* line 10315 */
b_L10315: ;
		if(-((b_v_b2f) < (b_v_txf))){
			b_v_txf=b_v_b2f;
		}
		/* line 10320 */
b_L10320: ;
		/* line 10325 */
b_L10325: ;
		if(-((b_abs(b_v_rzf)) >= ((0.00010000000000331966)))){ goto b_L10340; }
		/* line 10330 */
b_L10330: ;
		if((B_INT(-((b_v_ozf) < (b_a_uzf[B_INT(b_v_ii)]))) | B_INT(-((b_v_ozf) > (b_a_vzf[B_INT(b_v_ii)]))))){ goto b_L10380; }
		/* line 10335 */
b_L10335: ;
		goto b_L10365;
		/* line 10340 */
b_L10340: ;
		b_v_c1f=(((b_a_uzf[B_INT(b_v_ii)])-(b_v_ozf))/b_v_rzf);
		/* line 10345 */
b_L10345: ;
		b_v_c2f=(((b_a_vzf[B_INT(b_v_ii)])-(b_v_ozf))/b_v_rzf);
		/* line 10350 */
b_L10350: ;
		if(-((b_v_c1f) > (b_v_c2f))){
			b_v_zwf=b_v_c1f;
			b_v_c1f=b_v_c2f;
			b_v_c2f=b_v_zwf;
		}
		/* line 10355 */
b_L10355: ;
		if(-((b_v_c1f) > (b_v_tmf))){
			b_v_tmf=b_v_c1f;
		}
		/* line 10360 */
b_L10360: ;
		if(-((b_v_c2f) < (b_v_txf))){
			b_v_txf=b_v_c2f;
		}
		/* line 10365 */
b_L10365: ;
		if((B_INT(-((b_v_tmf) > (b_v_txf))) | B_INT(-((b_v_txf) < ((0.0010000000002037268)))))){ goto b_L10380; }
		/* line 10370 */
b_L10370: ;
		if(-((b_v_tmf) < ((0.0010000000002037268)))){
			b_v_tmf=b_v_txf;
		}
		/* line 10375 */
b_L10375: ;
		if(-((b_v_tmf) < (b_v_btf))){
			b_v_btf=b_v_tmf;
			b_v_bki=b_v_ii;
		}
		/* line 10380 */
b_L10380: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 10385 */
b_L10385: ;
		goto b_return;
		/* line 10400 */
b_L10400: ;
		/* line 10405 */
b_L10405: ;
		b_v_obs=b_keep(b_read_str());
		/* line 10410 */
b_L10410: ;
		if(-(b_strcmp(b_v_obs,b_lit("END",3)) == 0)){
			goto b_return;
		}
		/* line 10415 */
b_L10415: ;
		if(-(b_strcmp(b_v_obs,b_lit("CAMERA",6)) == 0)){
			b_v_exf=b_read_real();
			b_v_eyf=b_read_real();
			b_v_ezf=b_read_real();
			b_v_dxf=b_read_real();
			b_v_dzf=b_read_real();
			b_v_caf=b_atn((((b_v_dxf)-(b_v_exf))/((((b_v_dzf)-(b_v_ezf)))+((0.00010000000000331966)))));
			goto b_L10405;
		}
		/* line 10420 */
b_L10420: ;
		if(-(b_strcmp(b_v_obs,b_lit("LIGHT",5)) == 0)){
			b_v_lxf=b_read_real();
			b_v_lyf=b_read_real();
			b_v_lzf=b_read_real();
			goto b_L10405;
		}
		/* line 10425 */
b_L10425: ;
		if(-(b_strcmp(b_v_obs,b_lit("PLANE",5)) == 0)){
			b_v_gyf=b_read_real();
			b_v_csf=b_read_real();
			goto b_L10405;
		}
		/* line 10430 */
b_L10430: ;
		if(-(b_strcmp(b_v_obs,b_lit("SPHERE",6)) == 0)){
			b_gosubStack[b_gosubSP++]=6; goto b_L10600;
b_ret6: ;
			goto b_L10405;
		}
		/* line 10435 */
b_L10435: ;
		if(-(b_strcmp(b_v_obs,b_lit("BOX",3)) == 0)){
			b_gosubStack[b_gosubSP++]=7; goto b_L10700;
b_ret7: ;
			goto b_L10405;
		}
		/* line 10436 */
b_L10436: ;
		if(-(b_strcmp(b_v_obs,b_lit("ANIMATE",7)) == 0)){
			b_v_kcf=b_read_real();
			b_v_spf=b_read_real();
			b_v_ami=(1);
			b_v_nki=(-1);
			goto b_L10405;
		}
		/* line 10437 */
b_L10437: ;
		if(-(b_strcmp(b_v_obs,b_lit("KF",2)) == 0)){
			b_gosubStack[b_gosubSP++]=8; goto b_L10895;
b_ret8: ;
			goto b_L10405;
		}
		/* line 10440 */
b_L10440: ;
		goto b_L10405;
		/* line 10450 */
b_L10450: ;
		/* line 10455 */
b_L10455: ;
		if(-(b_strcmp(b_v_obs,b_lit("CAMERA",6)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			b_v_dcf=b_read_real();
			b_v_ddf=b_read_real();
			b_v_def=b_read_real();
			goto b_return;
		}
		/* line 10460 */
b_L10460: ;
		if(-(b_strcmp(b_v_obs,b_lit("LIGHT",5)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			b_v_dcf=b_read_real();
			goto b_return;
		}
		/* line 10465 */
b_L10465: ;
		if(-(b_strcmp(b_v_obs,b_lit("PLANE",5)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			goto b_return;
		}
		/* line 10470 */
b_L10470: ;
		if(-(b_strcmp(b_v_obs,b_lit("SPHERE",6)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			b_v_dcf=b_read_real();
			b_v_ddf=b_read_real();
			b_v_def=b_read_real();
			goto b_return;
		}
		/* line 10475 */
b_L10475: ;
		if(-(b_strcmp(b_v_obs,b_lit("BOX",3)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			b_v_dcf=b_read_real();
			b_v_ddf=b_read_real();
			b_v_def=b_read_real();
			b_v_dff=b_read_real();
			goto b_return;
		}
		/* line 10480 */
b_L10480: ;
		if(-(b_strcmp(b_v_obs,b_lit("ANIMATE",7)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			goto b_return;
		}
		/* line 10485 */
b_L10485: ;
		if(-(b_strcmp(b_v_obs,b_lit("KF",2)) == 0)){
			b_v_daf=b_read_real();
			b_v_dbf=b_read_real();
			b_v_dcf=b_read_real();
			goto b_return;
		}
		/* line 10490 */
b_L10490: ;
		goto b_return;
		/* line 10500 */
b_L10500: ;
		/* line 10505 */
b_L10505: ;
		b_v_shi=(0);
		/* line 10510 */
b_L10510: ;
		b_v_rxf=((b_v_lxf)-(b_v_oxf));
		/* line 10515 */
b_L10515: ;
		b_v_ryf=((b_v_lyf)-(b_v_oyf));
		/* line 10520 */
b_L10520: ;
		b_v_rzf=((b_v_lzf)-(b_v_ozf));
		/* line 10525 */
b_L10525: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 10530 */
b_L10530: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 10535 */
b_L10535: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 10540 */
b_L10540: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 10545 */
b_L10545: ;
		b_gosubStack[b_gosubSP++]=9; goto b_L10000;
b_ret9: ;
		/* line 10550 */
b_L10550: ;
		if((B_INT(-((b_v_kf) >= ((0)))) & B_INT(-((b_v_tf) < (b_v_zwf))))){
			b_v_shi=(1);
		}
		/* line 10555 */
b_L10555: ;
		b_gosubStack[b_gosubSP++]=10; goto b_L10200;
b_ret10: ;
		/* line 10560 */
b_L10560: ;
		if((B_INT(-((b_v_bki) >= ((0)))) & B_INT(-((b_v_btf) < (b_v_zwf))))){
			b_v_shi=(1);
		}
		/* line 10565 */
b_L10565: ;
		goto b_return;
		/* line 10600 */
b_L10600: ;
		/* line 10605 */
b_L10605: ;
		b_v_nsi=((b_v_nsi)+((1)));
		/* line 10610 */
b_L10610: ;
		b_a_sxf[B_INT(b_v_nsi)]=b_read_real();
		b_a_syf[B_INT(b_v_nsi)]=b_read_real();
		b_a_szf[B_INT(b_v_nsi)]=b_read_real();
		b_a_srf[B_INT(b_v_nsi)]=b_read_real();
		b_a_smf[B_INT(b_v_nsi)]=b_read_real();
		/* line 10615 */
b_L10615: ;
		goto b_return;
		/* line 10700 */
b_L10700: ;
		/* line 10705 */
b_L10705: ;
		b_v_nbi=((b_v_nbi)+((1)));
		/* line 10710 */
b_L10710: ;
		b_a_uxf[B_INT(b_v_nbi)]=b_read_real();
		b_a_uyf[B_INT(b_v_nbi)]=b_read_real();
		b_a_uzf[B_INT(b_v_nbi)]=b_read_real();
		b_a_vxf[B_INT(b_v_nbi)]=b_read_real();
		b_a_vyf[B_INT(b_v_nbi)]=b_read_real();
		b_a_vzf[B_INT(b_v_nbi)]=b_read_real();
		/* line 10715 */
b_L10715: ;
		goto b_return;
		/* line 10720 */
b_L10720: ;
		/* line 10725 */
b_L10725: ;
		b_v_hxf=((b_v_oxf)+(((b_v_btf)*(b_v_rxf))));
		/* line 10730 */
b_L10730: ;
		b_v_hyf=((b_v_oyf)+(((b_v_btf)*(b_v_ryf))));
		/* line 10735 */
b_L10735: ;
		b_v_hzf=((b_v_ozf)+(((b_v_btf)*(b_v_rzf))));
		/* line 10740 */
b_L10740: ;
		b_v_nxf=(0);
		/* line 10745 */
b_L10745: ;
		b_v_nyf=(0);
		/* line 10750 */
b_L10750: ;
		b_v_nzf=(0);
		/* line 10755 */
b_L10755: ;
		b_v_bni=(1);
		/* line 10760 */
b_L10760: ;
		b_v_bsi=(-1);
		/* line 10765 */
b_L10765: ;
		b_v_zwf=b_abs(((b_v_hxf)-(b_a_uxf[B_INT(b_v_bki)])));
		/* line 10770 */
b_L10770: ;
		if(-((b_abs(((b_v_hxf)-(b_a_vxf[B_INT(b_v_bki)])))) < (b_v_zwf))){
			b_v_zwf=b_abs(((b_v_hxf)-(b_a_vxf[B_INT(b_v_bki)])));
			b_v_bni=(1);
			b_v_bsi=(1);
		}
		/* line 10775 */
b_L10775: ;
		if(-((b_abs(((b_v_hyf)-(b_a_uyf[B_INT(b_v_bki)])))) < (b_v_zwf))){
			b_v_zwf=b_abs(((b_v_hyf)-(b_a_uyf[B_INT(b_v_bki)])));
			b_v_bni=(2);
			b_v_bsi=(-1);
		}
		/* line 10780 */
b_L10780: ;
		if(-((b_abs(((b_v_hyf)-(b_a_vyf[B_INT(b_v_bki)])))) < (b_v_zwf))){
			b_v_zwf=b_abs(((b_v_hyf)-(b_a_vyf[B_INT(b_v_bki)])));
			b_v_bni=(2);
			b_v_bsi=(1);
		}
		/* line 10785 */
b_L10785: ;
		if(-((b_abs(((b_v_hzf)-(b_a_uzf[B_INT(b_v_bki)])))) < (b_v_zwf))){
			b_v_zwf=b_abs(((b_v_hzf)-(b_a_uzf[B_INT(b_v_bki)])));
			b_v_bni=(3);
			b_v_bsi=(-1);
		}
		/* line 10790 */
b_L10790: ;
		if(-((b_abs(((b_v_hzf)-(b_a_vzf[B_INT(b_v_bki)])))) < (b_v_zwf))){
			b_v_bni=(3);
			b_v_bsi=(1);
		}
		/* line 10795 */
b_L10795: ;
		if(-((b_v_bni) == ((1)))){
			b_v_nxf=b_v_bsi;
			goto b_L10810;
		}
		/* line 10800 */
b_L10800: ;
		if(-((b_v_bni) == ((2)))){
			b_v_nyf=b_v_bsi;
			goto b_L10810;
		}
		/* line 10805 */
b_L10805: ;
		b_v_nzf=b_v_bsi;
		/* line 10810 */
b_L10810: ;
		/* line 10815 */
b_L10815: ;
		b_v_rxf=((b_v_lxf)-(b_v_hxf));
		/* line 10820 */
b_L10820: ;
		b_v_ryf=((b_v_lyf)-(b_v_hyf));
		/* line 10825 */
b_L10825: ;
		b_v_rzf=((b_v_lzf)-(b_v_hzf));
		/* line 10830 */
b_L10830: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 10835 */
b_L10835: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 10840 */
b_L10840: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 10845 */
b_L10845: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 10850 */
b_L10850: ;
		b_v_nlf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 10855 */
b_L10855: ;
		if(-((b_v_nlf) <= ((0)))){
			b_v_fai=(0);
			goto b_L1280;
		}
		/* line 10860 */
b_L10860: ;
		b_v_oxf=b_v_hxf;
		/* line 10865 */
b_L10865: ;
		b_v_oyf=b_v_hyf;
		/* line 10870 */
b_L10870: ;
		b_v_ozf=b_v_hzf;
		/* line 10875 */
b_L10875: ;
		b_gosubStack[b_gosubSP++]=11; goto b_L10500;
b_ret11: ;
		/* line 10880 */
b_L10880: ;
		if(-((b_v_shi) == ((1)))){
			b_v_fai=(0);
			goto b_L1280;
		}
		/* line 10885 */
b_L10885: ;
		b_v_fai=(1);
		/* line 10890 */
b_L10890: ;
		goto b_L1280;
		/* line 10895 */
b_L10895: ;
		/* line 10896 */
b_L10896: ;
		b_v_nki=((b_v_nki)+((1)));
		b_a_kxf[B_INT(b_v_nki)]=b_read_real();
		b_a_kyf[B_INT(b_v_nki)]=b_read_real();
		b_a_kzf[B_INT(b_v_nki)]=b_read_real();
		goto b_return;
		/* line 10900 */
b_L10900: ;
		/* line 10901 */
b_L10901: ;
		b_v_sci=(0);
		b_dataPtr = 0;
		/* line 10903 */
b_L10903: ;
		b_v_obs=b_keep(b_read_str());
		/* line 10904 */
b_L10904: ;
		if(-(b_strcmp(b_v_obs,b_lit("STOP",4)) == 0)){ goto b_L10915; }
		/* line 10905 */
b_L10905: ;
		if(-(b_strcmp(b_v_obs,b_lit("SCENE",5)) == 0)){
			b_v_sci=((b_v_sci)+((1)));
			b_v_nms=b_keep(b_read_str());
			b_a_sns[B_INT(b_v_sci)]=b_keep(b_v_nms);
			goto b_L10903;
		}
		/* line 10906 */
b_L10906: ;
		b_gosubStack[b_gosubSP++]=12; goto b_L10450;
b_ret12: ;
		goto b_L10903;
		/* line 10915 */
b_L10915: ;
		b_putc(147);
		b_nl();
		/* line 10916 */
b_L10916: ;
		{ bstr_t _t=b_lit("POV-RAY SCENES:",15); b_str(_t.p,_t.len); }
		b_nl();
		/* line 10917 */
b_L10917: ;
		b_v_ii=(1);
		b_fl_5=b_v_sci;
		if(b_v_ii > b_fl_5) goto b_f5_e;
b_f5_t: ;
		b_putint(b_v_ii);
		b_putc(32);
		{ bstr_t _t=b_a_sns[B_INT(b_v_ii)]; b_str(_t.p,_t.len); }
		b_nl();
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_5)) goto b_f5_t;
b_f5_e: ;
		/* line 10918 */
b_L10918: ;
		{ bstr_t _t=b_lit("PRESS 1-",8); b_str(_t.p,_t.len); }
		b_putint(b_v_sci);
		{ bstr_t _t=b_lit(" :",2); b_str(_t.p,_t.len); }
		b_nl();
		/* line 10919 */
b_L10919: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		if(-(b_strcmp(b_v_as,b_lit("",0)) == 0)){ goto b_L10919; }
		/* line 10920 */
b_L10920: ;
		b_v_sgf=b_val(b_v_as);
		/* line 10921 */
b_L10921: ;
		if((B_INT(-((b_v_sgf) < ((1)))) | B_INT(-((b_v_sgf) > (b_v_sci))))){ goto b_L10919; }
		/* line 10922 */
b_L10922: ;
		b_v_sgf=((b_v_sgf)-((1)));
		b_dataPtr = 0;
		/* line 10923 */
b_L10923: ;
		b_v_obs=b_keep(b_read_str());
		/* line 10924 */
b_L10924: ;
		if(-(b_strcmp(b_v_obs,b_lit("SCENE",5)) == 0)){ goto b_L10928; }
		/* line 10925 */
b_L10925: ;
		b_gosubStack[b_gosubSP++]=13; goto b_L10450;
b_ret13: ;
		goto b_L10923;
		/* line 10928 */
b_L10928: ;
		if(-((b_v_sgf) == ((0)))){
			b_v_nms=b_keep(b_read_str());
			b_gosubStack[b_gosubSP++]=14; goto b_L10400;
b_ret14: ;
			goto b_L10937;
		}
		/* line 10930 */
b_L10930: ;
		b_v_sgf=((b_v_sgf)-((1)));
		b_v_nms=b_keep(b_read_str());
		goto b_L10923;
		/* line 10937 */
b_L10937: ;
		goto b_return;
		/* line 10940 */
b_L10940: ;
		/* line 10941 */
b_L10941: ;
		b_v_p1f=b_int(b_v_apf);
		/* line 10942 */
b_L10942: ;
		b_v_p2f=((b_v_p1f)+((1)));
		/* line 10943 */
b_L10943: ;
		if(-((b_v_p2f) >= (b_v_kcf))){
			b_v_p2f=(0);
		}
		/* line 10944 */
b_L10944: ;
		b_v_ftf=((b_v_apf)-(b_v_p1f));
		/* line 10945 */
b_L10945: ;
		b_v_exf=((b_a_kxf[(bint_t)(b_v_p1f)])+(((b_v_ftf)*(((b_a_kxf[(bint_t)(b_v_p2f)])-(b_a_kxf[(bint_t)(b_v_p1f)]))))));
		/* line 10946 */
b_L10946: ;
		b_v_eyf=((b_a_kyf[(bint_t)(b_v_p1f)])+(((b_v_ftf)*(((b_a_kyf[(bint_t)(b_v_p2f)])-(b_a_kyf[(bint_t)(b_v_p1f)]))))));
		/* line 10947 */
b_L10947: ;
		b_v_ezf=((b_a_kzf[(bint_t)(b_v_p1f)])+(((b_v_ftf)*(((b_a_kzf[(bint_t)(b_v_p2f)])-(b_a_kzf[(bint_t)(b_v_p1f)]))))));
		/* line 10948 */
b_L10948: ;
		b_v_axf=((b_a_kxf[(bint_t)(b_v_p2f)])-(b_v_exf));
		b_v_azf=((((b_a_kzf[(bint_t)(b_v_p2f)])-(b_v_ezf)))+((0.00010000000000331966)));
		/* line 10949 */
b_L10949: ;
		b_v_caf=b_atn((b_v_axf/b_v_azf));
		/* line 10950 */
b_L10950: ;
		if(-((b_v_azf) < ((0)))){
			b_v_caf=((b_v_caf)+((3.141592999920249)));
		}
		/* line 10951 */
b_L10951: ;
		goto b_return;
		/* line 11000 */
b_L11000: ;
		/* line 11001 */
b_L11001: ;
		/* line 11002 */
b_L11002: ;
		/* line 11003 */
b_L11003: ;
		/* line 11004 */
b_L11004: ;
		/* line 11010 */
b_L11010: ;
		/* line 11020 */
b_L11020: ;
		/* line 11030 */
b_L11030: ;
		/* line 11040 */
b_L11040: ;
		/* line 11050 */
b_L11050: ;
		/* line 11060 */
b_L11060: ;
		/* line 11061 */
b_L11061: ;
		/* line 11062 */
b_L11062: ;
		/* line 11063 */
b_L11063: ;
		/* line 11064 */
b_L11064: ;
		/* line 11065 */
b_L11065: ;
		/* line 11066 */
b_L11066: ;
		/* line 11067 */
b_L11067: ;
		/* line 11068 */
b_L11068: ;
		/* line 11070 */
b_L11070: ;
		/* line 11071 */
b_L11071: ;
		/* line 11072 */
b_L11072: ;
		/* line 11073 */
b_L11073: ;
		/* line 11074 */
b_L11074: ;
		/* line 11100 */
b_L11100: ;
		/* line 11110 */
b_L11110: ;
		/* line 11120 */
b_L11120: ;
		/* line 11121 */
b_L11121: ;
		/* line 11122 */
b_L11122: ;
		/* line 11123 */
b_L11123: ;
		/* line 11124 */
b_L11124: ;
		/* line 11125 */
b_L11125: ;
		/* line 11126 */
b_L11126: ;
		/* line 11127 */
b_L11127: ;
		/* line 11128 */
b_L11128: ;
		/* line 11129 */
b_L11129: ;
		/* line 11130 */
b_L11130: ;
		/* line 11200 */
b_L11200: ;
		/* line 11201 */
b_L11201: ;
		/* line 11210 */
b_L11210: ;
		/* line 11220 */
b_L11220: ;
		/* line 11230 */
b_L11230: ;
		/* line 11240 */
b_L11240: ;
		/* line 11250 */
b_L11250: ;
		/* line 11251 */
b_L11251: ;
		/* line 11252 */
b_L11252: ;
		/* line 11260 */
b_L11260: ;
		/* line 11270 */
b_L11270: ;
		/* line 11300 */
b_L11300: ;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			case 6: goto b_ret6;
			case 7: goto b_ret7;
			case 8: goto b_ret8;
			case 9: goto b_ret9;
			case 10: goto b_ret10;
			case 11: goto b_ret11;
			case 12: goto b_ret12;
			case 13: goto b_ret13;
			case 14: goto b_ret14;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
