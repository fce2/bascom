 10 PRINT chr$(147)

 20 w=20
 30 g=100
 40 l=1113
 50 n=24576
 60 d=23463

 70 FOR r=0 TO 21
 80   FOR c=0 TO 21
 90     POKE l+r*40+c,32
100     POKE n+r*40+c,32
110   NEXT c
120 NEXT r
130 z=RND(-246)
140 FOR r=1 TO w
150   FOR c=1 TO w
160     IF RND(1)<0.3 THEN POKE l+r*40+c,81
170   NEXT c
180 NEXT r

190 FOR k=1 TO g
200   t%=ti
210   FOR x=1 TO w
220     bb=l+x*40+1
230     FOR y=1 TO w
240       c=PEEK(bb-41)+PEEK(bb-40)+PEEK(bb-39)+PEEK(bb-1)+PEEK(bb+1)+PEEK(bb+39)+PEEK(bb+40)+PEEK(bb+41)
250       p=PEEK(bb)
260       nb=bb+d
270       POKE nb,32
280       IF c=403 OR (p=81 AND c=354) THEN POKE nb,81
290       bb=bb+1
300     NEXT y
310   NEXT x
320   FOR r=1 TO w
330     FOR c=1 TO w
340       POKE l+r*40+c,PEEK(n+r*40+c)
350     NEXT c
360   NEXT r
370   POKE 1024,32
380   PRINT chr$(19);ti-t%
390 NEXT k

400 s=0
410 FOR r=1 TO w
420   FOR c=1 TO w
430     s=s-(PEEK(l+r*40+c)=81)
440   NEXT c
450 NEXT r

460 PRINT "GENS=";g
470 PRINT "ALIVE=";s
