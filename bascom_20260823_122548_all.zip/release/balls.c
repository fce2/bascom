/* OPTIMIZE_C -- balls.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_ni;
static int b_a_bxi[256];
static int b_a_byi[256];
static int b_a_bci[256];
static int b_a_xi[256];
static int b_a_yi[256];
static bint_t b_v_bi;
static unsigned int b_v_ii;
static bint_t b_v_ti;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_v_ni=(100);
		/* line 20 */
b_L20: ;
		b_poke((53280.0),(0));
		/* line 30 */
b_L30: ;
		b_poke((53281.0),(0));
		/* line 40 */
b_L40: ;
		b_putc(147);
		/* line 50 */
b_L50: ;
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		/* line 80 */
b_L80: ;
		/* line 90 */
b_L90: ;
		/* line 100 */
b_L100: ;
		b_v_bi=(1);
		/* line 110 */
b_L110: ;
		b_a_bxi[B_INT(b_v_bi)]=b_int(((b_rnd(B_INT((1))))*((40))));
		/* line 120 */
b_L120: ;
		b_a_byi[B_INT(b_v_bi)]=b_int(((b_rnd(B_INT((1))))*((25))));
		/* line 130 */
b_L130: ;
		b_a_bci[B_INT(b_v_bi)]=((b_int(((b_rnd(B_INT((1))))*((14)))))+((1)));
		/* line 140 */
b_L140: ;
		b_a_xi[B_INT(b_v_bi)]=b_int(((b_rnd(B_INT((1))))*((2))));
		/* line 150 */
b_L150: ;
		b_a_yi[B_INT(b_v_bi)]=(1);
		/* line 160 */
b_L160: ;
		b_v_bi=((b_v_bi)+((1)));
		/* line 170 */
b_L170: ;
		if(-((b_v_bi) <= (b_v_ni))){ goto b_L110; }
		/* line 180 */
b_L180: ;
		b_v_ii=(1024);
		if(b_v_ii > 2023) goto b_f0_e;
b_f0_t: ;
		/* line 190 */
b_L190: ;
		b_poke(b_v_ii,(81));
		/* line 200 */
b_L200: ;
		b_v_ii += 1;
		if(b_v_ii <= 2023) goto b_f0_t;
b_f0_e: ;
		/* line 210 */
b_L210: ;
		b_v_ii=(55296.0);
		if(b_v_ii > 56295) goto b_f1_e;
b_f1_t: ;
		/* line 220 */
b_L220: ;
		b_poke(b_v_ii,(0));
		/* line 230 */
b_L230: ;
		b_v_ii += 1;
		if(b_v_ii <= 56295) goto b_f1_t;
b_f1_e: ;
		/* line 240 */
b_L240: ;
		b_v_bi=(1);
		/* line 250 */
b_L250: ;
		b_v_ti=b_jiffy();
		/* line 260 */
b_L260: ;
		b_poke((((((55296.0))+(((b_a_byi[B_INT(b_v_bi)])*((40))))))+(b_a_bxi[B_INT(b_v_bi)])),(0));
		/* line 270 */
b_L270: ;
		if(-((b_a_xi[B_INT(b_v_bi)]) == ((0)))){
			b_gosubStack[b_gosubSP++]=0; goto b_L1000;
b_ret0: ;
		}
		/* line 280 */
b_L280: ;
		if(-((b_a_xi[B_INT(b_v_bi)]) == ((1)))){
			b_gosubStack[b_gosubSP++]=1; goto b_L1100;
b_ret1: ;
		}
		/* line 290 */
b_L290: ;
		if(-((b_a_yi[B_INT(b_v_bi)]) == ((0)))){
			b_gosubStack[b_gosubSP++]=2; goto b_L1200;
b_ret2: ;
		}
		/* line 300 */
b_L300: ;
		if(-((b_a_yi[B_INT(b_v_bi)]) == ((1)))){
			b_gosubStack[b_gosubSP++]=3; goto b_L1300;
b_ret3: ;
		}
		/* line 310 */
b_L310: ;
		b_poke((((((55296.0))+(((b_a_byi[B_INT(b_v_bi)])*((40))))))+(b_a_bxi[B_INT(b_v_bi)])),b_a_bci[B_INT(b_v_bi)]);
		/* line 320 */
b_L320: ;
		b_v_bi=((b_v_bi)+((1)));
		/* line 330 */
b_L330: ;
		if(-((b_v_bi) <= (b_v_ni))){ goto b_L260; }
		/* line 340 */
b_L340: ;
		b_putc(19);
		b_real(((b_jiffy())-(b_v_ti)));
		b_nl();
		/* line 350 */
b_L350: ;
		goto b_L240;
		/* line 1000 */
b_L1000: ;
		if(-((b_a_bxi[B_INT(b_v_bi)]) == ((0)))){
			b_a_xi[B_INT(b_v_bi)]=(1);
			goto b_return;
		}
		/* line 1005 */
b_L1005: ;
		b_a_bxi[B_INT(b_v_bi)]=((b_a_bxi[B_INT(b_v_bi)])-((1)));
		/* line 1010 */
b_L1010: ;
		goto b_return;
		/* line 1100 */
b_L1100: ;
		if(-((b_a_bxi[B_INT(b_v_bi)]) == ((39)))){
			b_a_bxi[B_INT(b_v_bi)]=(38);
			b_a_xi[B_INT(b_v_bi)]=(0);
			goto b_return;
		}
		/* line 1105 */
b_L1105: ;
		b_a_bxi[B_INT(b_v_bi)]=((b_a_bxi[B_INT(b_v_bi)])+((1)));
		/* line 1110 */
b_L1110: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		if(-((b_a_byi[B_INT(b_v_bi)]) == ((0)))){
			b_a_yi[B_INT(b_v_bi)]=(1);
			goto b_return;
		}
		/* line 1205 */
b_L1205: ;
		b_a_byi[B_INT(b_v_bi)]=((b_a_byi[B_INT(b_v_bi)])-((1)));
		/* line 1210 */
b_L1210: ;
		goto b_return;
		/* line 1300 */
b_L1300: ;
		if(-((b_a_byi[B_INT(b_v_bi)]) == ((24)))){
			b_a_byi[B_INT(b_v_bi)]=(23);
			b_a_yi[B_INT(b_v_bi)]=(0);
			goto b_return;
		}
		/* line 1305 */
b_L1305: ;
		b_a_byi[B_INT(b_v_bi)]=((b_a_byi[B_INT(b_v_bi)])+((1)));
		/* line 1310 */
b_L1310: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
