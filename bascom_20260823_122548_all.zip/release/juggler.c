/* OPTIMIZE_C -- juggler.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static breal_t b_a_kxf[14];
static breal_t b_a_kyf[14];
static breal_t b_a_kzf[14];
static breal_t b_a_krf[14];
static int b_v_aki;
static int b_v_bxi;
static int b_v_byi;
static int b_v_bzi;
static int b_v_bei;
static bint_t b_v_lxi;
static bint_t b_v_lyi;
static bint_t b_v_lzi;
static int b_v_gbi;
static breal_t b_v_frf;
static breal_t b_v_pf;
static breal_t b_v_trf;
static breal_t b_v_tlf;
static breal_t b_v_srf;
static breal_t b_v_crf;
static breal_t b_v_slf;
static breal_t b_v_clf;
static breal_t b_v_b0f;
static breal_t b_v_b1f;
static breal_t b_v_b2f;
static bint_t b_v_cfi;
static int b_v_ii;
static bint_t b_v_pbi;
static breal_t b_v_zwf;
static breal_t b_v_yf;
static breal_t b_v_zxf;
static breal_t b_v_pwf;
static int b_v_pxi;
static breal_t b_v_xf;
static breal_t b_v_rxf;
static breal_t b_v_ryf;
static breal_t b_v_rzf;
static breal_t b_v_oxf;
static breal_t b_v_oyf;
static breal_t b_v_ozf;
static int b_v_rdi;
static breal_t b_v_tf;
static breal_t b_v_laf;
static breal_t b_v_sxf;
static int b_v_syi;
static breal_t b_v_szf;
static breal_t b_v_faf;
static breal_t b_v_kf;
static breal_t b_v_x1f;
static breal_t b_v_x2f;
static breal_t b_v_x3f;
static breal_t b_v_f1f;
static breal_t b_v_f2f;
static breal_t b_v_f3f;
static breal_t b_v_df;
static breal_t b_v_nxf;
static breal_t b_v_nyf;
static breal_t b_v_nzf;
static bstr_t b_v_as;
static breal_t b_v_qf;
static breal_t b_v_z1f;
static breal_t b_v_z2f;
static breal_t b_v_wuf;
static breal_t b_v_z0f;
static bint_t b_t_0;
static bint_t b_t_1;
static int b_fl_3;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		b_v_aki=(13);
		/* line 30 */
b_L30: ;
		b_a_kxf[B_INT((0))]=(0);
		/* line 40 */
b_L40: ;
		b_a_kyf[B_INT((0))]=(19);
		/* line 50 */
b_L50: ;
		b_a_kzf[B_INT((0))]=(100);
		/* line 60 */
b_L60: ;
		b_a_krf[B_INT((0))]=(3.2000000001862645);
		/* line 70 */
b_L70: ;
		b_a_kxf[B_INT((1))]=(0);
		/* line 80 */
b_L80: ;
		b_a_kyf[B_INT((1))]=(12);
		/* line 90 */
b_L90: ;
		b_a_kzf[B_INT((1))]=(100);
		/* line 100 */
b_L100: ;
		b_a_krf[B_INT((1))]=(5.5);
		/* line 110 */
b_L110: ;
		b_a_kxf[B_INT((2))]=(0);
		/* line 120 */
b_L120: ;
		b_a_kyf[B_INT((2))]=(4);
		/* line 130 */
b_L130: ;
		b_a_kzf[B_INT((2))]=(100);
		/* line 140 */
b_L140: ;
		b_a_krf[B_INT((2))]=(4.5);
		/* line 150 */
b_L150: ;
		b_a_kxf[B_INT((3))]=(-((3.5)));
		/* line 160 */
b_L160: ;
		b_a_kyf[B_INT((3))]=(-2);
		/* line 170 */
b_L170: ;
		b_a_kzf[B_INT((3))]=(100);
		/* line 180 */
b_L180: ;
		b_a_krf[B_INT((3))]=(3);
		/* line 190 */
b_L190: ;
		b_a_kxf[B_INT((4))]=(3.5);
		/* line 200 */
b_L200: ;
		b_a_kyf[B_INT((4))]=(-2);
		/* line 210 */
b_L210: ;
		b_a_kzf[B_INT((4))]=(100);
		/* line 220 */
b_L220: ;
		b_a_krf[B_INT((4))]=(3);
		/* line 230 */
b_L230: ;
		b_v_bxi=(0);
		/* line 240 */
b_L240: ;
		b_v_byi=(8);
		/* line 250 */
b_L250: ;
		b_v_bzi=(-17);
		/* line 260 */
b_L260: ;
		b_v_bei=(25);
		/* line 270 */
b_L270: ;
		b_v_lxi=(-50);
		/* line 280 */
b_L280: ;
		b_v_lyi=(300);
		/* line 290 */
b_L290: ;
		b_v_lzi=(50);
		/* line 300 */
b_L300: ;
		b_v_gbi=(10);
		/* line 310 */
b_L310: ;
		b_poke((53272.0),(11));
		/* line 320 */
b_L320: ;
		b_poke((53265.0),(59));
		/* line 330 */
b_L330: ;
		b_poke((56576.0),(148));
		/* line 340 */
b_L340: ;
		b_v_frf=(0);
		/* line 350 */
b_L350: ;
		b_v_pf=((b_v_frf)*((0.15000000002328306)));
		/* line 360 */
b_L360: ;
		b_v_trf=(((0.5))+((((0.5))*(b_sin(b_v_pf)))));
		/* line 370 */
b_L370: ;
		b_v_tlf=(((0.5))+((((0.5))*(b_sin(((b_v_pf)+((3.1415900001302361))))))));
		/* line 380 */
b_L380: ;
		b_v_srf=b_sin(b_v_trf);
		/* line 390 */
b_L390: ;
		b_v_crf=b_cos(b_v_trf);
		/* line 400 */
b_L400: ;
		b_v_slf=b_sin(b_v_tlf);
		/* line 410 */
b_L410: ;
		b_v_clf=b_cos(b_v_tlf);
		/* line 420 */
b_L420: ;
		b_a_kxf[B_INT((8))]=(((5))+((((4))*(b_v_srf))));
		/* line 430 */
b_L430: ;
		b_a_kyf[B_INT((8))]=(((16))-((((4))*(b_v_crf))));
		/* line 440 */
b_L440: ;
		b_a_kzf[B_INT((8))]=(((100))-((((0.60000000009313226))*(b_v_srf))));
		/* line 450 */
b_L450: ;
		b_a_krf[B_INT((8))]=(2.5);
		/* line 460 */
b_L460: ;
		b_a_kxf[B_INT((9))]=(((5))+((((12))*(b_v_srf))));
		/* line 470 */
b_L470: ;
		b_a_kyf[B_INT((9))]=(((16))-((((12))*(b_v_crf))));
		/* line 480 */
b_L480: ;
		b_a_kzf[B_INT((9))]=(((100))-((((1.7999999998137355))*(b_v_srf))));
		/* line 490 */
b_L490: ;
		b_a_krf[B_INT((9))]=(2.2000000001862645);
		/* line 500 */
b_L500: ;
		b_a_kxf[B_INT((10))]=(((5))+((((16))*(b_v_srf))));
		/* line 510 */
b_L510: ;
		b_a_kyf[B_INT((10))]=(((16))-((((16))*(b_v_crf))));
		/* line 520 */
b_L520: ;
		b_a_kzf[B_INT((10))]=(((100))-((((2.400000000372529))*(b_v_srf))));
		/* line 530 */
b_L530: ;
		b_a_krf[B_INT((10))]=(2);
		/* line 540 */
b_L540: ;
		b_a_kxf[B_INT((5))]=(((-5))-((((4))*(b_v_slf))));
		/* line 550 */
b_L550: ;
		b_a_kyf[B_INT((5))]=(((16))-((((4))*(b_v_clf))));
		/* line 560 */
b_L560: ;
		b_a_kzf[B_INT((5))]=(((100))-((((0.60000000009313226))*(b_v_slf))));
		/* line 570 */
b_L570: ;
		b_a_krf[B_INT((5))]=(2.5);
		/* line 580 */
b_L580: ;
		b_a_kxf[B_INT((6))]=(((-5))-((((12))*(b_v_slf))));
		/* line 590 */
b_L590: ;
		b_a_kyf[B_INT((6))]=(((16))-((((12))*(b_v_clf))));
		/* line 600 */
b_L600: ;
		b_a_kzf[B_INT((6))]=(((100))-((((1.7999999998137355))*(b_v_slf))));
		/* line 610 */
b_L610: ;
		b_a_krf[B_INT((6))]=(2.2000000001862645);
		/* line 620 */
b_L620: ;
		b_a_kxf[B_INT((7))]=(((-5))-((((16))*(b_v_slf))));
		/* line 630 */
b_L630: ;
		b_a_kyf[B_INT((7))]=(((16))-((((16))*(b_v_clf))));
		/* line 640 */
b_L640: ;
		b_a_kzf[B_INT((7))]=(((100))-((((2.400000000372529))*(b_v_slf))));
		/* line 650 */
b_L650: ;
		b_a_krf[B_INT((7))]=(2);
		/* line 660 */
b_L660: ;
		b_v_b0f=b_v_pf;
		/* line 670 */
b_L670: ;
		b_v_b1f=((b_v_pf)+((2.0943999998271465)));
		/* line 680 */
b_L680: ;
		b_v_b2f=((b_v_pf)+((4.1887999996542931)));
		/* line 690 */
b_L690: ;
		b_a_kxf[B_INT((11))]=(((-7))*(b_cos(b_v_b0f)));
		/* line 700 */
b_L700: ;
		b_a_kyf[B_INT((11))]=(((6))+((((10))*(b_sin(b_v_b0f)))));
		/* line 710 */
b_L710: ;
		b_a_kzf[B_INT((11))]=(((96))-((((2))*(b_sin(b_v_b0f)))));
		/* line 720 */
b_L720: ;
		b_a_krf[B_INT((11))]=(2);
		/* line 730 */
b_L730: ;
		b_a_kxf[B_INT((12))]=(((-7))*(b_cos(b_v_b1f)));
		/* line 740 */
b_L740: ;
		b_a_kyf[B_INT((12))]=(((6))+((((10))*(b_sin(b_v_b1f)))));
		/* line 750 */
b_L750: ;
		b_a_kzf[B_INT((12))]=(((96))-((((2))*(b_sin(b_v_b1f)))));
		/* line 760 */
b_L760: ;
		b_a_krf[B_INT((12))]=(2);
		/* line 770 */
b_L770: ;
		b_a_kxf[B_INT((13))]=(((-7))*(b_cos(b_v_b2f)));
		/* line 780 */
b_L780: ;
		b_a_kyf[B_INT((13))]=(((6))+((((10))*(b_sin(b_v_b2f)))));
		/* line 790 */
b_L790: ;
		b_a_kzf[B_INT((13))]=(((96))-((((2))*(b_sin(b_v_b2f)))));
		/* line 800 */
b_L800: ;
		b_a_krf[B_INT((13))]=(2);
		/* line 810 */
b_L810: ;
		if(-((b_v_cfi) == ((0)))){ goto b_L830; }
		/* line 820 */
b_L820: ;
		goto b_L880;
		/* line 830 */
b_L830: ;
		b_v_ii=(1024);
		if(b_v_ii > 2023) goto b_f0_e;
		b_t_0=(((48128.0))+(b_v_ii));
		b_t_1=(((54272.0))+(b_v_ii));
b_f0_t: ;
		/* line 840 */
b_L840: ;
		b_poke(b_t_0,(15));
		/* line 850 */
b_L850: ;
		b_poke(b_t_1,(0));
		/* line 860 */
b_L860: ;
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_ii += 1;
		if(b_v_ii <= 2023) goto b_f0_t;
b_f0_e: ;
		/* line 870 */
b_L870: ;
		b_v_cfi=(1);
		/* line 880 */
b_L880: ;
		b_v_pbi=(0);
		if(b_v_pbi > 8000) goto b_f1_e;
b_f1_t: ;
		/* line 890 */
b_L890: ;
		b_v_zwf=(B_INT(b_v_pbi) & B_INT((7)));
		/* line 900 */
b_L900: ;
		b_v_yf=((((b_int(((breal_t)(b_v_pbi)/(breal_t)((320)))))*((8))))+(b_v_zwf));
		/* line 910 */
b_L910: ;
		b_v_zwf=b_int(((breal_t)(b_v_pbi)/(breal_t)((8))));
		/* line 920 */
b_L920: ;
		b_v_zxf=((((b_v_zwf)-(((b_int((b_v_zwf/(breal_t)((40)))))*((40))))))*((8)));
		/* line 930 */
b_L930: ;
		b_v_pwf=(0);
		/* line 940 */
b_L940: ;
		b_v_pxi=(0);
		if(b_v_pxi > 7) goto b_f2_e;
b_f2_t: ;
		/* line 950 */
b_L950: ;
		b_v_xf=((b_v_zxf)+(b_v_pxi));
		/* line 960 */
b_L960: ;
		b_v_zwf=((breal_t)(b_v_gbi)/(breal_t)((320)));
		/* line 970 */
b_L970: ;
		b_v_rxf=((((b_v_xf)*(b_v_zwf)))-(((breal_t)(b_v_gbi)/(breal_t)((2)))));
		/* line 980 */
b_L980: ;
		b_v_ryf=(((((-(b_v_yf)))*(b_v_zwf)))+(((((breal_t)((200))/(breal_t)((2))))*(b_v_zwf))));
		/* line 990 */
b_L990: ;
		b_v_rzf=b_v_bei;
		/* line 1000 */
b_L1000: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 1010 */
b_L1010: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 1020 */
b_L1020: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 1030 */
b_L1030: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 1040 */
b_L1040: ;
		b_v_oxf=b_v_bxi;
		/* line 1050 */
b_L1050: ;
		b_v_oyf=b_v_byi;
		/* line 1060 */
b_L1060: ;
		b_v_ozf=b_v_bzi;
		/* line 1070 */
b_L1070: ;
		b_v_rdi=(0);
		/* line 1080 */
b_L1080: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L10000;
b_ret0: ;
		/* line 1090 */
b_L1090: ;
		switch((-(-((((b_v_oyf)+(((b_v_tf)*(b_v_ryf))))) > ((0)))))){
			case 1: goto b_L1260; break;
			default: break;}
		/* line 1100 */
b_L1100: ;
		b_v_laf=((-(b_v_oyf))/b_v_ryf);
		/* line 1110 */
b_L1110: ;
		b_v_sxf=((b_v_oxf)+(((b_v_laf)*(b_v_rxf))));
		/* line 1120 */
b_L1120: ;
		b_v_syi=(0);
		/* line 1130 */
b_L1130: ;
		b_v_szf=((b_v_ozf)+(((b_v_laf)*(b_v_rzf))));
		/* line 1140 */
b_L1140: ;
		b_v_zwf=(((B_INT(b_int((b_v_sxf/(breal_t)((5))))) & B_INT((1))))+((B_INT(b_int((b_v_szf/(breal_t)((5))))) & B_INT((1)))));
		/* line 1150 */
b_L1150: ;
		b_v_faf=((-((b_v_zwf) == ((1))))+((1)));
		/* line 1160 */
b_L1160: ;
		b_v_oxf=b_v_sxf;
		/* line 1170 */
b_L1170: ;
		b_v_oyf=b_v_syi;
		/* line 1180 */
b_L1180: ;
		b_v_ozf=b_v_szf;
		/* line 1190 */
b_L1190: ;
		b_v_rxf=((b_v_oxf)+(b_v_lxi));
		/* line 1200 */
b_L1200: ;
		b_v_ryf=((b_v_oyf)+(b_v_lyi));
		/* line 1210 */
b_L1210: ;
		b_v_rzf=((b_v_ozf)+(b_v_lzi));
		/* line 1220 */
b_L1220: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L10000;
b_ret1: ;
		/* line 1230 */
b_L1230: ;
		switch((-(-((b_v_kf) == ((-1)))))){
			case 1: goto b_L1530; break;
			default: break;}
		/* line 1240 */
b_L1240: ;
		b_v_faf=((-((((bint_t)(b_v_xf) & B_INT((1)))) != (((bint_t)(b_v_yf) & B_INT((1))))))+((1)));
		/* line 1250 */
b_L1250: ;
		goto b_L1530;
		/* line 1260 */
b_L1260: ;
		if(-((b_v_kf) == ((-1)))){
			b_v_faf=(0);
			goto b_L1530;
		}
		/* line 1270 */
b_L1270: ;
		b_v_x1f=((((((b_a_kxf[(bint_t)(b_v_kf)])*(b_v_rxf)))+(((b_a_kyf[(bint_t)(b_v_kf)])*(b_v_ryf)))))+(((b_a_kzf[(bint_t)(b_v_kf)])*(b_v_rzf))));
		/* line 1280 */
b_L1280: ;
		b_v_x2f=((((((b_v_oxf)*(b_v_rxf)))+(((b_v_oyf)*(b_v_ryf)))))+(((b_v_ozf)*(b_v_rzf))));
		/* line 1290 */
b_L1290: ;
		b_v_x3f=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 1300 */
b_L1300: ;
		b_v_laf=(((b_v_x1f)-(b_v_x2f))/b_v_x3f);
		/* line 1310 */
b_L1310: ;
		b_v_f1f=((((b_v_oxf)+(((b_v_laf)*(b_v_rxf)))))-(b_a_kxf[(bint_t)(b_v_kf)]));
		/* line 1320 */
b_L1320: ;
		b_v_f2f=((((b_v_oyf)+(((b_v_laf)*(b_v_ryf)))))-(b_a_kyf[(bint_t)(b_v_kf)]));
		/* line 1330 */
b_L1330: ;
		b_v_f3f=((((b_v_ozf)+(((b_v_laf)*(b_v_rzf)))))-(b_a_kzf[(bint_t)(b_v_kf)]));
		/* line 1340 */
b_L1340: ;
		b_v_df=b_sqr(((((((b_v_f1f)*(b_v_f1f)))+(((b_v_f2f)*(b_v_f2f)))))+(((b_v_f3f)*(b_v_f3f)))));
		/* line 1350 */
b_L1350: ;
		if(-((((b_a_krf[(bint_t)(b_v_kf)])*((0.94999999995343387)))) < (b_v_df))){
			b_v_faf=(1);
			goto b_L1530;
		}
		/* line 1360 */
b_L1360: ;
		b_v_rdi=((b_v_rdi)+((1)));
		/* line 1370 */
b_L1370: ;
		if(-((b_v_rdi) > ((3)))){
			b_v_faf=(1);
			goto b_L1530;
		}
		/* line 1380 */
b_L1380: ;
		b_v_oxf=((b_v_oxf)+(((b_v_tf)*(b_v_rxf))));
		/* line 1390 */
b_L1390: ;
		b_v_oyf=((b_v_oyf)+(((b_v_tf)*(b_v_ryf))));
		/* line 1400 */
b_L1400: ;
		b_v_ozf=((b_v_ozf)+(((b_v_tf)*(b_v_rzf))));
		/* line 1410 */
b_L1410: ;
		b_v_nxf=((b_a_kxf[(bint_t)(b_v_kf)])-(b_v_oxf));
		/* line 1420 */
b_L1420: ;
		b_v_nyf=((b_a_kyf[(bint_t)(b_v_kf)])-(b_v_oyf));
		/* line 1430 */
b_L1430: ;
		b_v_nzf=((b_a_kzf[(bint_t)(b_v_kf)])-(b_v_ozf));
		/* line 1440 */
b_L1440: ;
		b_v_zwf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 1450 */
b_L1450: ;
		b_v_rxf=((b_v_rxf)-((((((2))*(b_v_zwf)))*(b_v_nxf))));
		/* line 1460 */
b_L1460: ;
		b_v_ryf=((b_v_ryf)-((((((2))*(b_v_zwf)))*(b_v_nyf))));
		/* line 1470 */
b_L1470: ;
		b_v_rzf=((b_v_rzf)-((((((2))*(b_v_zwf)))*(b_v_nzf))));
		/* line 1480 */
b_L1480: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 1490 */
b_L1490: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 1500 */
b_L1500: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 1510 */
b_L1510: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 1520 */
b_L1520: ;
		goto b_L1080;
		/* line 1530 */
b_L1530: ;
		b_v_pwf=((((b_v_pwf)*((2))))+(b_v_faf));
		/* line 1540 */
b_L1540: ;
		b_v_pxi += 1;
		if(b_v_pxi <= 7) goto b_f2_t;
b_f2_e: ;
		/* line 1550 */
b_L1550: ;
		b_poke((((57344.0))+(b_v_pbi)),b_v_pwf);
		/* line 1560 */
b_L1560: ;
		b_v_pbi += 1;
		if(b_v_pbi <= 8000) goto b_f1_t;
b_f1_e: ;
		/* line 1570 */
b_L1570: ;
		b_v_frf=((b_v_frf)+((1)));
		/* line 1580 */
b_L1580: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		/* line 1590 */
b_L1590: ;
		if(-(b_strcmp(b_v_as,b_lit("",0)) != 0)){ goto b_L1610; }
		/* line 1600 */
b_L1600: ;
		goto b_L350;
		/* line 1610 */
b_L1610: ;
		goto b_end;
		/* line 10000 */
b_L10000: ;
		b_v_kf=(-1);
		/* line 10005 */
b_L10005: ;
		b_v_tf=(99999.0);
		/* line 10010 */
b_L10010: ;
		b_v_ii=(0);
		b_fl_3=b_v_aki;
		if(b_v_ii > b_fl_3) goto b_f3_e;
b_f3_t: ;
		/* line 10015 */
b_L10015: ;
		b_v_zwf=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 10020 */
b_L10020: ;
		b_v_pf=((((2))*(((((((b_v_rxf)*(((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))))+(((b_v_ryf)*(((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))))))+(((b_v_rzf)*(((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)]))))))))/b_v_zwf);
		/* line 10025 */
b_L10025: ;
		b_v_qf=(((((((((((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))*(((b_v_oxf)-(b_a_kxf[B_INT(b_v_ii)])))))+(((((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))*(((b_v_oyf)-(b_a_kyf[B_INT(b_v_ii)])))))))+(((((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)])))*(((b_v_ozf)-(b_a_kzf[B_INT(b_v_ii)])))))))-(((b_a_krf[B_INT(b_v_ii)])*(b_a_krf[B_INT(b_v_ii)]))))/b_v_zwf);
		/* line 10030 */
b_L10030: ;
		b_v_z1f=((-(b_v_pf))/(breal_t)((2)));
		/* line 10035 */
b_L10035: ;
		b_v_z2f=(((((b_v_pf)*(b_v_pf))/(breal_t)((4))))-(b_v_qf));
		/* line 10040 */
b_L10040: ;
		if(-((b_v_z2f) < ((0)))){
			b_v_ii += 1;
			if(b_v_ii <= (b_fl_3)) goto b_f3_t;
			goto b_return;
		}
		/* line 10045 */
b_L10045: ;
		b_v_wuf=b_sqr(b_v_z2f);
		/* line 10050 */
b_L10050: ;
		b_v_x1f=((b_v_z1f)+(b_v_wuf));
		/* line 10055 */
b_L10055: ;
		b_v_x2f=((b_v_z1f)-(b_v_wuf));
		/* line 10060 */
b_L10060: ;
		b_v_z0f=(-((B_INT(-((b_v_x1f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x1f) < (b_v_tf))))));
		/* line 10065 */
b_L10065: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 10070 */
b_L10070: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 10075 */
b_L10075: ;
		b_v_tf=((((b_v_z0f)*(b_v_x1f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 10080 */
b_L10080: ;
		b_v_z0f=(-((B_INT(-((b_v_x2f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x2f) < (b_v_tf))))));
		/* line 10085 */
b_L10085: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 10090 */
b_L10090: ;
		b_v_kf=((((b_v_z0f)*(b_v_ii)))+(((b_v_z1f)*(b_v_kf))));
		/* line 10095 */
b_L10095: ;
		b_v_tf=((((b_v_z0f)*(b_v_x2f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 10100 */
b_L10100: ;
		b_v_ii += 1;
		if(b_v_ii <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 10105 */
b_L10105: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
