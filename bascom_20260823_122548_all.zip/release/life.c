/* OPTIMIZE_C -- life.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_wi;
static int b_v_gi;
static int b_v_li;
static int b_v_ni;
static int b_v_di;
static int b_v_ri;
static int b_v_ci;
static breal_t b_v_zf;
static int b_v_ki;
static bint_t b_v_ti;
static int b_v_xi;
static bint_t b_v_bbi;
static int b_v_yi;
static int b_v_pi;
static bint_t b_v_nbi;
static bint_t b_v_si;
static int b_v_M0;
static int b_v_M1;
static int b_v_M2;
static int b_v_M3;
static int b_v_M4;
static int b_v_M5;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static int b_fl_2;
static int b_fl_3;
static int b_fl_4;
static int b_fl_5;
static int b_fl_6;
static int b_fl_7;
static int b_fl_8;
static int b_fl_9;
static int b_fl_10;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		b_putc(147);
		b_nl();
		/* line 20 */
b_L20: ;
		b_v_wi=(20);
		/* line 30 */
b_L30: ;
		b_v_gi=(100);
		/* line 40 */
b_L40: ;
		b_v_li=(1113);
		/* line 50 */
b_L50: ;
		b_v_ni=(24576);
		/* line 60 */
b_L60: ;
		b_v_di=(23463);
		/* line 70 */
b_L70: ;
		b_v_ri=(0);
		if(b_v_ri > 21) goto b_f0_e;
b_f0_t: ;
		/* line 80 */
b_L80: ;
		b_v_ci=(0);
		if(b_v_ci > 21) goto b_f1_e;
		b_v_M0=((b_v_li)+(((b_v_ri)*((40)))));
		b_v_M1=((b_v_ni)+(((b_v_ri)*((40)))));
		b_t_0=((b_v_M0)+(b_v_ci));
		b_t_1=((b_v_M1)+(b_v_ci));
b_f1_t: ;
		/* line 90 */
b_L90: ;
		b_poke(b_t_0,(32));
		/* line 100 */
b_L100: ;
		b_poke(b_t_1,(32));
		/* line 110 */
b_L110: ;
		b_t_0 += 1;
		b_t_1 += 1;
		b_v_ci += 1;
		if(b_v_ci <= 21) goto b_f1_t;
b_f1_e: ;
		/* line 120 */
b_L120: ;
		b_v_ri += 1;
		if(b_v_ri <= 21) goto b_f0_t;
b_f0_e: ;
		/* line 130 */
b_L130: ;
		b_v_zf=b_rnd(B_INT((-246)));
		/* line 140 */
b_L140: ;
		b_v_ri=(1);
		b_fl_2=b_v_wi;
		if(b_v_ri > b_fl_2) goto b_f2_e;
b_f2_t: ;
		/* line 150 */
b_L150: ;
		b_v_ci=(1);
		b_fl_3=b_v_wi;
		if(b_v_ci > b_fl_3) goto b_f3_e;
		b_v_M2=((b_v_li)+(((b_v_ri)*((40)))));
		b_t_2=((b_v_M2)+(b_v_ci));
b_f3_t: ;
		/* line 160 */
b_L160: ;
		if(-((b_rnd(B_INT((1)))) < ((0.30000000004656613)))){
			b_poke(b_t_2,(81));
		}
		/* line 170 */
b_L170: ;
		b_t_2 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_3)) goto b_f3_t;
b_f3_e: ;
		/* line 180 */
b_L180: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_2)) goto b_f2_t;
b_f2_e: ;
		/* line 190 */
b_L190: ;
		b_v_ki=(1);
		b_fl_4=b_v_gi;
		if(b_v_ki > b_fl_4) goto b_f4_e;
b_f4_t: ;
		/* line 200 */
b_L200: ;
		b_v_ti=b_jiffy();
		/* line 210 */
b_L210: ;
		b_v_xi=(1);
		b_fl_5=b_v_wi;
		if(b_v_xi > b_fl_5) goto b_f5_e;
b_f5_t: ;
		/* line 220 */
b_L220: ;
		b_v_bbi=((((b_v_li)+(((b_v_xi)*((40))))))+((1)));
		/* line 230 */
b_L230: ;
		b_v_yi=(1);
		b_fl_6=b_v_wi;
		if(b_v_yi > b_fl_6) goto b_f6_e;
		b_v_nbi=((b_v_bbi)+(b_v_di));
b_f6_t: ;
		/* line 240 */
b_L240: ;
		b_v_ci=((((((((((((((B_INT(b_peek((unsigned int)(((b_v_bbi)-((41)))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)-((40)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)-((39)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)-((1)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)+((1)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)+((39)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)+((40)))))))))+(B_INT(b_peek((unsigned int)(((b_v_bbi)+((41))))))));
		/* line 250 */
b_L250: ;
		b_v_pi=B_INT(b_peek((unsigned int)(b_v_bbi)));
		/* line 260 */
b_L260: ;
		/* line 270 */
b_L270: ;
		b_poke(b_v_nbi,(32));
		/* line 280 */
b_L280: ;
		if((B_INT(-((b_v_ci) == ((403)))) | B_INT((B_INT(-((b_v_pi) == ((81)))) & B_INT(-((b_v_ci) == ((354)))))))){
			b_poke(b_v_nbi,(81));
		}
		/* line 290 */
b_L290: ;
		b_v_bbi=((b_v_bbi)+((1)));
		/* line 300 */
b_L300: ;
		b_v_nbi += 1;
		b_v_yi += 1;
		if(b_v_yi <= (b_fl_6)) goto b_f6_t;
b_f6_e: ;
		/* line 310 */
b_L310: ;
		b_v_xi += 1;
		if(b_v_xi <= (b_fl_5)) goto b_f5_t;
b_f5_e: ;
		/* line 320 */
b_L320: ;
		b_v_ri=(1);
		b_fl_7=b_v_wi;
		if(b_v_ri > b_fl_7) goto b_f7_e;
b_f7_t: ;
		/* line 330 */
b_L330: ;
		b_v_ci=(1);
		b_fl_8=b_v_wi;
		if(b_v_ci > b_fl_8) goto b_f8_e;
		b_v_M3=((b_v_li)+(((b_v_ri)*((40)))));
		b_v_M4=((b_v_ni)+(((b_v_ri)*((40)))));
b_f8_t: ;
		/* line 340 */
b_L340: ;
		b_poke(((b_v_M3)+(b_v_ci)),B_INT(b_peek((unsigned int)(((b_v_M4)+(b_v_ci))))));
		/* line 350 */
b_L350: ;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		/* line 360 */
b_L360: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_7)) goto b_f7_t;
b_f7_e: ;
		/* line 370 */
b_L370: ;
		b_poke((1024),(32));
		/* line 380 */
b_L380: ;
		b_putc(19);
		b_real(((b_jiffy())-(b_v_ti)));
		b_nl();
		/* line 390 */
b_L390: ;
		b_v_ki += 1;
		if(b_v_ki <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 400 */
b_L400: ;
		b_v_si=(0);
		/* line 410 */
b_L410: ;
		b_v_ri=(1);
		b_fl_9=b_v_wi;
		if(b_v_ri > b_fl_9) goto b_f9_e;
b_f9_t: ;
		/* line 420 */
b_L420: ;
		b_v_ci=(1);
		b_fl_10=b_v_wi;
		if(b_v_ci > b_fl_10) goto b_f10_e;
		b_v_M5=((b_v_li)+(((b_v_ri)*((40)))));
		b_t_3=((b_v_M5)+(b_v_ci));
b_f10_t: ;
		/* line 430 */
b_L430: ;
		b_v_si=(((b_v_si))+(((B_INT(b_peek((unsigned int)(b_t_3)))) == ((81)))));
		/* line 440 */
b_L440: ;
		b_t_3 += 1;
		b_v_ci += 1;
		if(b_v_ci <= (b_fl_10)) goto b_f10_t;
b_f10_e: ;
		/* line 450 */
b_L450: ;
		b_v_ri += 1;
		if(b_v_ri <= (b_fl_9)) goto b_f9_t;
b_f9_e: ;
		/* line 460 */
b_L460: ;
		{ bstr_t _t=b_lit("GENS=",5); b_str(_t.p,_t.len); }
		b_putint(b_v_gi);
		b_nl();
		/* line 470 */
b_L470: ;
		{ bstr_t _t=b_lit("ALIVE=",6); b_str(_t.p,_t.len); }
		b_putint(b_v_si);
		b_nl();
b_return: ;
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
