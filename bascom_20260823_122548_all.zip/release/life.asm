; -- life.bas
; C64 BASIC V2 -> 6502  |  2965 bytes PRG, 47 source lines
	* = $0801
	; entry  $0C35   (10 SYS -> code)
	; vars   $1342 .. $1396   (39 vars, 84 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$33,$31,$32,$35,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- string pool ----

str0:
0813 :  .byte $47,$45,$4E,$53,$3D	; "GENS="

str1:
0818 :  .byte $41,$4C,$49,$56,$45,$3D	; "ALIVE="
; ---- float const pool ----

fconst0:
081E :  .byte $7F,$19,$99,$99,$9A

fconst1:
0823 :  .byte $91,$00,$00,$00,$00

ftemp:
0828 :  .res 5	; float temp slots

ti_t1:
082D :  .res 5	; TI read 5-byte float temp (24-bit jiffy->FAC hi-byte accum)

rnd_st:
0832 :  .res 2	; RT_rnd_fast 16-bit LFSR state (lo,hi)
; ---- mulK lookup tables (speed-mode V*K strength reduction) ----

mulK40_lo:
0834 :  .byte $00,$28,$50,$78,$A0,$C8,$F0,$18,$40,$68,$90,$B8,$E0,$08,$30,$58	; mulK lo bytes (i*K & 0xFF)
	.byte $80,$A8,$D0,$F8,$20,$48

mulK40_hi:
084A :  .byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02	; mulK hi bytes (i*K >> 8)
	.byte $02,$02,$02,$02,$03,$03
; ---- runtime helpers ----

RT_print_str:
0860 :  TAX
0861 :  LDY #0 ; $00

.ps_loop:
0863 :  TXA
0864 :  BEQ ps_skip
0866 :  LDA (ZP_PTR),Y ; $FB
0868 :  JSR ROM_CHROUT ; $FFD2
086B :  INY
086C :  DEX
086D :  JMP .ps_loop ; $0863

0870 :  RTS

uword2dec_shiftedbcd:
0871 :  .byte $00,$01,$02,$03,$04,$08,$09,$0A,$0B,$0C,$10,$11,$12,$13,$14,$18	; ShiftedBcdTab (Omegamatrix HexToDec65535)
	.byte $19,$1A,$1B,$1C,$20,$21,$22,$23,$24,$28,$29,$2A,$2B,$2C,$30,$31
	.byte $32,$33,$34,$38,$39,$3A,$3B,$3C,$40,$41,$42,$43,$44,$48,$49,$4A
	.byte $4B,$4C

uword2dec_mod100:
08A3 :  .byte $00,$38,$0C,$44	; Mod100Tab

uword2dec_decbuf:
08A7 :  .res 6	; decbuf: 5 ASCII digits + 0 terminator

RT_uword2dec:
08AD :  STY ZP_SCR16 + 1 ; $FE
08AF :  STA ZP_SCR16 ; $FD
08B1 :  TYA
08B2 :  TAX
08B3 :  LSR
08B4 :  LSR
08B5 :  CPX #0xA7 ; $A7
08B7 :  ADC #1 ; $01
08B9 :  STA ZP_MULMP ; $FA
08BB :  ASL
08BC :  ADC ZP_MULMP ; $FA
08BE :  TAY
08BF :  LSR
08C0 :  LSR
08C1 :  LSR
08C2 :  LSR
08C3 :  LSR
08C4 :  TAX
08C5 :  TYA
08C6 :  ASL
08C7 :  ASL
08C8 :  ASL
08C9 :  CLC
08CA :  ADC ZP_SCR16 ; $FD
08CC :  STA ZP_SCR16 ; $FD
08CE :  TXA
08CF :  ADC ZP_SCR16 + 1 ; $FE
08D1 :  STA ZP_SCR16 + 1 ; $FE
08D3 :  ROR
08D4 :  LSR
08D5 :  TAY
08D6 :  LSR
08D7 :  TAX
08D8 :  LDA ShiftedBcdTab,X ; $0871
08DB :  TAX
08DC :  ROL
08DD :  AND #0x0F ; $0F
08DF :  ORA #0x30 ; $30
08E1 :  STA uword2dec_decbuf + 1 ; $08A8
08E4 :  TXA
08E5 :  LSR
08E6 :  LSR
08E7 :  LSR
08E8 :  ORA #0x30 ; $30
08EA :  STA uword2dec_decbuf + 0 ; $08A7
08ED :  LDA ZP_SCR16 ; $FD
08EF :  CPY ZP_MULMP ; $FA
08F1 :  BMI .uw_doSub
08F3 :  BEQ .uw_useZero
08F5 :  ADC #23 + 24 ; $2F

.uw_doSub:
08F7 :  SBC #23 ; $17
08F9 :  STA ZP_SCR16 ; $FD

.uw_useZero:
08FB :  LDA ZP_SCR16 + 1 ; $FE
08FD :  SBC #0 ; $00
08FF :  AND #0x03 ; $03
0901 :  TAX
0902 :  CMP #2 ; $02
0904 :  ROL
0905 :  ORA #0x30 ; $30
0907 :  TAY
0908 :  LDA ZP_SCR16 ; $FD
090A :  ADC uword2dec_mod100,X ; $08A3
090D :  BCS .uw_doSub200
090F :  CMP #200 ; $C8
0911 :  BCC .uw_try100

.uw_doSub200:
0913 :  INY
0914 :  INY
0915 :  SBC #200 ; $C8

.uw_try100:
0917 :  CMP #100 ; $64
0919 :  BCC .uw_h2d99
091B :  INY
091C :  SBC #100 ; $64

.uw_h2d99:
091E :  LSR
091F :  TAX
0920 :  LDA ShiftedBcdTab,X ; $0871
0923 :  TAX
0924 :  ROL
0925 :  AND #0x0F ; $0F
0927 :  ORA #0x30 ; $30
0929 :  STA uword2dec_decbuf + 4 ; $08AB
092C :  TXA
092D :  LSR
092E :  LSR
092F :  LSR
0930 :  ORA #0x30 ; $30
0932 :  STY uword2dec_decbuf + 2 ; $08A9
0935 :  STA uword2dec_decbuf + 3 ; $08AA
0938 :  LDX uword2dec_decbuf + 4 ; $08AB
093B :  RTS

RT_print_int:
093C :  STA ZP_SCR16 ; $FD
093E :  STX ZP_SCR16 + 1 ; $FE
0940 :  LDA #0x20 ; $20
0942 :  BIT ZP_SCR16 + 1 ; $FE
0944 :  BPL .pos
0946 :  SEC
0947 :  LDA #0 ; $00
0949 :  SBC ZP_SCR16 ; $FD
094B :  STA ZP_SCR16 ; $FD
094D :  LDA #0 ; $00
094F :  SBC ZP_SCR16 + 1 ; $FE
0951 :  STA ZP_SCR16 + 1 ; $FE
0953 :  LDA #0x2D ; $2D

.pos:
0955 :  JSR ROM_CHROUT ; $FFD2
0958 :  LDY ZP_SCR16 + 1 ; $FE
095A :  LDA ZP_SCR16 ; $FD
095C :  JSR RT_uword2dec ; $08AD
095F :  LDY #0 ; $00

.uw_skip:
0961 :  LDA uword2dec_decbuf,Y ; $08A7
0964 :  BEQ .uw_allzero_l
0966 :  CMP #0x30 ; $30
0968 :  BNE .uw_got_l
096A :  INY
096B :  BNE .uw_skip

.uw_got:
096D :  JSR ROM_CHROUT ; $FFD2
0970 :  INY
0971 :  LDA uword2dec_decbuf,Y ; $08A7
0974 :  BNE .uw_got

.uw_trail:
0976 :  LDA #0x1D ; $1D
0978 :  JSR ROM_CHROUT ; $FFD2
097B :  RTS

.uw_allzero_l:
097C :  LDA #0x30 ; $30
097E :  JSR ROM_CHROUT ; $FFD2
0981 :  JMP .uw_trail ; $0976

RT_fmul_align:

RT_fadd:
0B01 :  JSR $BA8C
0B04 :  LDA $61
0B06 :  JMP RT_fmul_align ; $0984

RT_fsub:
0B09 :  JSR $BA8C
0B0C :  LDA $66
0B0E :  EOR #$FF
0B10 :  STA $66
0B12 :  EOR $6E
0B14 :  STA $6F
0B16 :  LDA $61
0B18 :  JMP RT_fmul_align ; $0984

RT_rnd_fast:
0B1B :  LDA FACEXP ; $61
0B1D :  BNE +3 ; FACEXP!=0 -> skip (long BEQ .seed_ti)
0B1F :  JMP .seed_ti

0B22 :  LDA 0x66 ; $66
0B24 :  BPL +3 ; arg>0 -> skip (long BMI .seed_arg)
0B26 :  JMP .seed_arg

.do_advance:
0B29 :  LDA rnd_st + 1 ; $0833
0B2C :  BNE .adv_lfsr
0B2E :  LDA rnd_st ; $0832
0B31 :  BNE .adv_lfsr
0B33 :  LDA 0xA1 ; $A1
0B35 :  STA rnd_st ; $0832
0B38 :  LDA 0xA2 ; $A2
0B3A :  STA rnd_st + 1 ; $0833
0B3D :  BNE .adv_lfsr
0B3F :  LDA rnd_st ; $0832
0B42 :  BNE .adv_lfsr
0B44 :  LDA #0xE1 ; $E1
0B46 :  STA rnd_st ; $0832
0B49 :  LDA #0xAC ; $AC
0B4B :  STA rnd_st + 1 ; $0833

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:
0B4E :  LDA rnd_st + 1 ; $0833
0B51 :  AND #1 ; $01
0B53 :  ASL
0B54 :  ASL
0B55 :  ASL
0B56 :  ASL
0B57 :  ASL
0B58 :  ASL
0B59 :  ASL
0B5A :  EOR rnd_st + 1 ; $0833
0B5D :  STA rnd_st + 1 ; $0833
0B60 :  LDA rnd_st ; $0832
0B63 :  LSR
0B64 :  EOR rnd_st + 1 ; $0833
0B67 :  STA rnd_st + 1 ; $0833
0B6A :  LDA rnd_st ; $0832
0B6D :  AND #1 ; $01
0B6F :  ASL
0B70 :  ASL
0B71 :  ASL
0B72 :  ASL
0B73 :  ASL
0B74 :  ASL
0B75 :  ASL
0B76 :  EOR rnd_st ; $0832
0B79 :  STA rnd_st ; $0832
0B7C :  LDA rnd_st + 1 ; $0833
0B7F :  LSR
0B80 :  EOR rnd_st ; $0832
0B83 :  STA rnd_st ; $0832
0B86 :  LDA rnd_st + 1 ; $0833
0B89 :  EOR rnd_st ; $0832
0B8C :  STA rnd_st + 1 ; $0833
0B8F :  BNE .rf_build
0B91 :  LDA rnd_st ; $0832
0B94 :  BEQ .to_zero

.rf_build:

.rf_build:
0B96 :  LDA rnd_st + 1 ; $0833
0B99 :  STA 0x62 ; $62
0B9B :  LDA rnd_st ; $0832
0B9E :  STA 0x63 ; $63
0BA0 :  LDA #0 ; $00
0BA2 :  STA 0x64 ; $64
0BA4 :  STA 0x65 ; $65
0BA6 :  STA 0x66 ; $66
0BA8 :  LDA #128 ; $80
0BAA :  STA FACEXP ; $61

.cvt_loop:
0BAC :  LDA 0x62 ; $62
0BAE :  BMI .cvt_done
0BB0 :  ASL 0x65 ; $65
0BB2 :  ROL 0x64 ; $64
0BB4 :  ROL 0x63 ; $63
0BB6 :  ROL 0x62 ; $62
0BB8 :  DEC FACEXP ; $61
0BBA :  JMP .cvt_loop ; $0BAC

.cvt_done:

.cvt_done:
0BBD :  RTS

.seed_ti:

.seed_ti:
0BBE :  LDA 0xA1 ; $A1
0BC0 :  STA rnd_st ; $0832
0BC3 :  LDA 0xA2 ; $A2
0BC5 :  STA rnd_st + 1 ; $0833
0BC8 :  JMP .do_advance ; $0B29

.seed_arg:

.seed_arg:
0BCB :  LDA 0x63 ; $63
0BCD :  STA rnd_st ; $0832
0BD0 :  LDA 0x64 ; $64
0BD2 :  STA rnd_st + 1 ; $0833
0BD5 :  JMP .do_advance ; $0B29

.to_zero:

.to_zero:
0BD8 :  LDA #0 ; $00
0BDA :  STA FACEXP ; $61
0BDC :  STA 0x62 ; $62
0BDE :  STA 0x63 ; $63
0BE0 :  STA 0x64 ; $64
0BE2 :  STA 0x65 ; $65
0BE4 :  STA 0x66 ; $66
0BE6 :  RTS

RT_ti_read:
0BE7 :  LDA #0 ; $00
0BE9 :  LDY 0xA0 ; $A0
0BEB :  JSR ROM_INT_FAC ; $B391
0BEE :  LDA FACEXP ; $61
0BF0 :  BEQ .ti_r_s1
0BF2 :  CLC
0BF3 :  ADC #16 ; $10
0BF5 :  STA FACEXP ; $61

.ti_r_s1:

.ti_r_s1:
0BF7 :  LDX #<addr ; $2D
0BF9 :  LDY #>addr ; $08
0BFB :  JSR ROM_FAC_MEM ; $BBD4
0BFE :  LDA #0 ; $00
0C00 :  LDY 0xA1 ; $A1
0C02 :  JSR ROM_INT_FAC ; $B391
0C05 :  LDA FACEXP ; $61
0C07 :  BEQ .ti_r_s2
0C09 :  CLC
0C0A :  ADC #8 ; $08
0C0C :  STA FACEXP ; $61

.ti_r_s2:

.ti_r_s2:
0C0E :  LDA #<addr ; $2D
0C10 :  LDY #>addr ; $08
0C12 :  JSR ROM_MEM_ARG ; $BA8C
0C15 :  LDA FACEXP ; $61
0C17 :  JSR ROM_PLUS ; $B86A
0C1A :  LDX #<addr ; $2D
0C1C :  LDY #>addr ; $08
0C1E :  JSR ROM_FAC_MEM ; $BBD4
0C21 :  LDA #0 ; $00
0C23 :  LDY 0xA2 ; $A2
0C25 :  JSR ROM_INT_FAC ; $B391
0C28 :  LDA #<addr ; $2D
0C2A :  LDY #>addr ; $08
0C2C :  JSR ROM_MEM_ARG ; $BA8C
0C2F :  LDA FACEXP ; $61
0C31 :  JSR ROM_PLUS ; $B86A
0C34 :  RTS

; ---- BASIC source ----
; 10    $0C35  PRINT CHR$(147)
; 1,"life.bas"

L10:
0C35 :  LDA #LO(e->ival) ; $93
0C37 :  LDX #LO((e->ival >> 8)) ; $00
0C39 :  JSR ROM_CHROUT ; $FFD2
0C3C :  LDA #13 ; $0D
0C3E :  JSR ROM_CHROUT ; $FFD2
; 20    $0C41  W=20
; 3,"life.bas"

L20:
0C41 :  LDA #clo ; $14
0C43 :  STA W
; 30    $0C46  G=100
; 4,"life.bas"

L30:
0C46 :  LDA #clo ; $64
0C48 :  STA G
; 40    $0C4B  L=1113
; 5,"life.bas"

L40:
0C4B :  LDA #LO(e->ival) ; $59
0C4D :  LDX #LO((e->ival >> 8)) ; $04
0C4F :  STA L
0C52 :  STX L+1
; 50    $0C55  N=24576
; 6,"life.bas"

L50:
0C55 :  LDA #LO(e->ival) ; $00
0C57 :  LDX #LO((e->ival >> 8)) ; $60
0C59 :  STA N
0C5C :  STX N+1
; 60    $0C5F  D=23463
; 7,"life.bas"

L60:
0C5F :  LDA #LO(e->ival) ; $A7
0C61 :  LDX #LO((e->ival >> 8)) ; $5B
0C63 :  STA D
0C66 :  STX D+1
; 70    $0C69  FOR R=0 TO 21
; 9,"life.bas"

L70:
0C69 :  LDA #LO(e->ival) ; $00
0C6B :  LDX #LO((e->ival >> 8)) ; $00
0C6D :  STA R
0C70 :  STX R+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 80    $0C73  FOR C=0 TO 21
; 10,"life.bas"

L80:
0C73 :  LDA #LO(e->ival) ; $00
0C75 :  LDX #LO((e->ival >> 8)) ; $00
0C77 :  STA C
0C7A :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
0C7D :  LDA L
0C80 :  LDX L+1
0C83 :  STA slot+0
0C85 :  STX slot+1
0C87 :  LDA R
0C8A :  LDX #0 ; $00
0C8C :  TAY
0C8D :  LDA h_mulK_hi[K],Y ; $084A
0C90 :  TAX
0C91 :  LDA h_mulK_lo[K],Y ; $0834
0C94 :  CLC
0C95 :  ADC slot+0
0C97 :  PHA
0C98 :  TXA
0C99 :  ADC slot+1
0C9B :  TAX
0C9C :  PLA
0C9D :  STA LICM0
0CA0 :  STX LICM0+1
0CA3 :  LDA N
0CA6 :  LDX N+1
0CA9 :  STA slot+0
0CAB :  STX slot+1
0CAD :  LDA R
0CB0 :  LDX #0 ; $00
0CB2 :  TAY
0CB3 :  LDA h_mulK_hi[K],Y ; $084A
0CB6 :  TAX
0CB7 :  LDA h_mulK_lo[K],Y ; $0834
0CBA :  CLC
0CBB :  ADC slot+0
0CBD :  PHA
0CBE :  TXA
0CBF :  ADC slot+1
0CC1 :  TAX
0CC2 :  PLA
0CC3 :  STA LICM1
0CC6 :  STX LICM1+1
0CC9 :  LDA LICM0
0CCC :  LDX LICM0+1
0CCF :  STA slot+0
0CD1 :  STX slot+1
0CD3 :  LDA C
0CD6 :  LDX C+1
0CD9 :  CLC
0CDA :  ADC slot+0
0CDC :  PHA
0CDD :  TXA
0CDE :  ADC slot+1
0CE0 :  TAX
0CE1 :  PLA
0CE2 :  STA LOPT0
0CE5 :  STX LOPT0+1
0CE8 :  LDA LICM1
0CEB :  LDX LICM1+1
0CEE :  STA slot+0
0CF0 :  STX slot+1
0CF2 :  LDA C
0CF5 :  LDX C+1
0CF8 :  CLC
0CF9 :  ADC slot+0
0CFB :  PHA
0CFC :  TXA
0CFD :  ADC slot+1
0CFF :  TAX
0D00 :  PLA
0D01 :  STA LOPT1
0D04 :  STX LOPT1+1
; opt: licm-subexpr range-byte-loop

.for_body:
; 90    $0D07  POKE L+R*40+C,32
; 11,"life.bas"

L90:
0D07 :  LDA LOPT0
0D0A :  LDX LOPT0+1
0D0D :  STA ZP_PTR ; $FB
0D0F :  STX ZP_PTR + 1 ; $FC
0D11 :  LDA #(u8)s->e2->ival ; $20
0D13 :  LDY #0 ; $00
0D15 :  STA (ZP_PTR),Y ; $FB
; 100   $0D17  POKE N+R*40+C,32
; 12,"life.bas"

L100:
0D17 :  LDA LOPT1
0D1A :  LDX LOPT1+1
0D1D :  STA ZP_PTR ; $FB
0D1F :  STX ZP_PTR + 1 ; $FC
0D21 :  LDA #(u8)s->e2->ival ; $20
0D23 :  LDY #0 ; $00
0D25 :  STA (ZP_PTR),Y ; $FB
; 110   $0D27  NEXT C
; 13,"life.bas"

L110:
0D27 :  LDA LOPT0
0D2A :  CLC
0D2B :  ADC #(u8)(st & 0xFF) ; $01
0D2D :  STA LOPT0
0D30 :  LDA LOPT0+1
0D33 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0D35 :  STA LOPT0+1
0D38 :  LDA LOPT1
0D3B :  CLC
0D3C :  ADC #(u8)(st & 0xFF) ; $01
0D3E :  STA LOPT1
0D41 :  LDA LOPT1+1
0D44 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0D46 :  STA LOPT1+1
0D49 :  INC C
0D4C :  LDA C
0D4F :  CMP #L->lim_lo ; $15
0D51 :  BEQ .nxt_back
0D53 :  BCS .nxt_done

.nxt_back:
0D55 :  JMP .for_body ; $0D07

.nxt_done:
; 120   $0D58  NEXT R
; 14,"life.bas"

L120:
0D58 :  INC R
0D5B :  LDA R
0D5E :  CMP #L->lim_lo ; $15
0D60 :  BEQ .nxt_back
0D62 :  BCS .nxt_done

.nxt_back:
0D64 :  JMP .for_body ; $0C73

.nxt_done:
; 130   $0D67  Z=RND(-246)
; 15,"life.bas"

L130:
0D67 :  LDA #LO(e->ival) ; $0A
0D69 :  LDX #LO((e->ival >> 8)) ; $FF
0D6B :  TAY
0D6C :  TXA
0D6D :  JSR ROM_INT_FAC ; $B391
0D70 :  JSR RT_rnd_fast ; $0B1B
0D73 :  LDX #<Z_F
0D75 :  LDY #>Z_F+1
0D77 :  JSR ROM_FAC_MEM ; $BBD4
; 140   $0D7A  FOR R=1 TO W
; 16,"life.bas"

L140:
0D7A :  LDA #LO(e->ival) ; $01
0D7C :  LDX #LO((e->ival >> 8)) ; $00
0D7E :  STA R
0D81 :  STX R+1
0D84 :  LDA W
0D87 :  STA LIMIT3
0D8A :  STX LIMIT3+1

.for_body:
; 150   $0D8D  FOR C=1 TO W
; 17,"life.bas"

L150:
0D8D :  LDA #LO(e->ival) ; $01
0D8F :  LDX #LO((e->ival >> 8)) ; $00
0D91 :  STA C
0D94 :  STX C+1
0D97 :  LDA W
0D9A :  STA LIMIT4
0D9D :  STX LIMIT4+1
0DA0 :  LDA L
0DA3 :  LDX L+1
0DA6 :  STA slot+0
0DA8 :  STX slot+1
0DAA :  LDA R
0DAD :  LDX #0 ; $00
0DAF :  TAY
0DB0 :  LDA h_mulK_hi[K],Y ; $084A
0DB3 :  TAX
0DB4 :  LDA h_mulK_lo[K],Y ; $0834
0DB7 :  CLC
0DB8 :  ADC slot+0
0DBA :  PHA
0DBB :  TXA
0DBC :  ADC slot+1
0DBE :  TAX
0DBF :  PLA
0DC0 :  STA LICM2
0DC3 :  STX LICM2+1
0DC6 :  STA slot+0
0DC8 :  STX slot+1
0DCA :  LDA C
0DCD :  LDX C+1
0DD0 :  CLC
0DD1 :  ADC slot+0
0DD3 :  PHA
0DD4 :  TXA
0DD5 :  ADC slot+1
0DD7 :  TAX
0DD8 :  PLA
0DD9 :  STA LOPT2
0DDC :  STX LOPT2+1
; opt: licm-subexpr

.for_body:
; 160   $0DDF  IF RND(1)<0.3 THEN POKE L+R*40+C,81
; 18,"life.bas"

L160:
0DDF :  LDA #LO(e->ival) ; $01
0DE1 :  LDX #LO((e->ival >> 8)) ; $00
0DE3 :  TAY
0DE4 :  TXA
0DE5 :  JSR ROM_INT_FAC ; $B391
0DE8 :  JSR RT_rnd_fast ; $0B1B
0DEB :  LDA #<addr ; $1E
0DED :  LDY #>addr ; $08
0DEF :  JSR ROM_FCOMP ; $BC5B
0DF2 :  BMI .true
0DF4 :  LDA #0x00 ; $00
0DF6 :  BEQ .cmp_tail
0DF8 :  LDA #0xFF ; $FF

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0DFA :  BNE +3 ; long IF-skip (body >127B)
0DFC :  JMP .if_skip

0DFF :  LDA LOPT2
0E02 :  LDX LOPT2+1
0E05 :  STA ZP_PTR ; $FB
0E07 :  STX ZP_PTR + 1 ; $FC
0E09 :  LDA #(u8)s->e2->ival ; $51
0E0B :  LDY #0 ; $00
0E0D :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 170   $0E0F  NEXT C
; 19,"life.bas"

L170:
0E0F :  LDA LOPT2
0E12 :  CLC
0E13 :  ADC #(u8)(st & 0xFF) ; $01
0E15 :  STA LOPT2
0E18 :  LDA LOPT2+1
0E1B :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0E1D :  STA LOPT2+1
0E20 :  INC C
0E23 :  BNE .inc_skip
0E25 :  INC C+1

.inc_skip:
0E28 :  LDA C+1
0E2B :  CMP LIMIT4+1
0E2E :  BCC .nxt_back
0E30 :  BNE .nxt_done
0E32 :  LDA C
0E35 :  CMP LIMIT4
0E38 :  BCC .nxt_back
0E3A :  BNE .nxt_done
0E3C :  BEQ .nxt_back

.nxt_back:
0E3E :  JMP .for_body ; $0DDF

.nxt_done:
; 180   $0E41  NEXT R
; 20,"life.bas"

L180:
0E41 :  INC R
0E44 :  BNE .inc_skip
0E46 :  INC R+1

.inc_skip:
0E49 :  LDA R+1
0E4C :  CMP LIMIT3+1
0E4F :  BCC .nxt_back
0E51 :  BNE .nxt_done
0E53 :  LDA R
0E56 :  CMP LIMIT3
0E59 :  BCC .nxt_back
0E5B :  BNE .nxt_done
0E5D :  BEQ .nxt_back

.nxt_back:
0E5F :  JMP .for_body ; $0D8D

.nxt_done:
; 190   $0E62  FOR K=1 TO G
; 22,"life.bas"

L190:
0E62 :  LDA #LO(e->ival) ; $01
0E64 :  LDX #LO((e->ival >> 8)) ; $00
0E66 :  STA K
0E69 :  STX K+1
0E6C :  LDA G
0E6F :  STA LIMIT5
0E72 :  STX LIMIT5+1

.for_body:
; 200   $0E75  T%=TI
; 23,"life.bas"

L200:
0E75 :  JSR RT_ti_read ; $0BE7
0E78 :  JSR ROM_FAC_INT ; $BC9B
0E7B :  LDA FACMO3 ; $65
0E7D :  LDX FACMO2 ; $64
0E7F :  STA T
0E82 :  STX T+1
; 210   $0E85  FOR X=1 TO W
; 24,"life.bas"

L210:
0E85 :  LDA #LO(e->ival) ; $01
0E87 :  LDX #LO((e->ival >> 8)) ; $00
0E89 :  STA X
0E8C :  STX X+1
0E8F :  LDA W
0E92 :  STA LIMIT6
0E95 :  STX LIMIT6+1

.for_body:
; 220   $0E98  BB=L+X*40+1
; 25,"life.bas"

L220:
0E98 :  LDA L
0E9B :  LDX L+1
0E9E :  STA slot+0
0EA0 :  STX slot+1
0EA2 :  LDA X
0EA5 :  LDX #0 ; $00
0EA7 :  TAY
0EA8 :  LDA h_mulK_hi[K],Y ; $084A
0EAB :  TAX
0EAC :  LDA h_mulK_lo[K],Y ; $0834
0EAF :  CLC
0EB0 :  ADC slot+0
0EB2 :  PHA
0EB3 :  TXA
0EB4 :  ADC slot+1
0EB6 :  TAX
0EB7 :  PLA
0EB8 :  STA slot+0
0EBA :  STX slot+1
0EBC :  LDA #LO(e->ival) ; $01
0EBE :  LDX #LO((e->ival >> 8)) ; $00
0EC0 :  CLC
0EC1 :  ADC slot+0
0EC3 :  PHA
0EC4 :  TXA
0EC5 :  ADC slot+1
0EC7 :  TAX
0EC8 :  PLA
0EC9 :  STA BB
0ECC :  STX BB+1
; 230   $0ECF  FOR Y=1 TO W
; 26,"life.bas"

L230:
0ECF :  LDA #LO(e->ival) ; $01
0ED1 :  LDX #LO((e->ival >> 8)) ; $00
0ED3 :  STA Y
0ED6 :  STX Y+1
0ED9 :  LDA W
0EDC :  STA LIMIT7
0EDF :  STX LIMIT7+1
0EE2 :  LDA BB
0EE5 :  LDX BB+1
0EE8 :  STA slot+0
0EEA :  STX slot+1
0EEC :  LDA D
0EEF :  LDX D+1
0EF2 :  CLC
0EF3 :  ADC slot+0
0EF5 :  PHA
0EF6 :  TXA
0EF7 :  ADC slot+1
0EF9 :  TAX
0EFA :  PLA
0EFB :  STA NB
0EFE :  STX NB+1
; opt: user-iv-let peek-cluster-reuse

.for_body:
; 240   $0F01  C=PEEK(BB-41)+PEEK(BB-40)+PEEK(BB-39)+PEEK(BB-1)+PEEK(BB+1)+PEEK(BB+39)+PEEK(BB+40)+PEEK(BB+41)
; 27,"life.bas"

L240:
0F01 :  LDA BB
0F04 :  STA ZP_PTR ; $FB
0F06 :  LDA BB+1
0F09 :  STA ZP_PTR + 1 ; $FC
0F0B :  LDA ZP_PTR ; $FB
0F0D :  SEC
0F0E :  SBC #(u8)(-min & 0xFF) ; $29
0F10 :  STA ZP_PTR ; $FB
0F12 :  LDA ZP_PTR + 1 ; $FC
0F14 :  SBC #(u8)(((-min) >> 8) & 0xFF) ; $00
0F16 :  STA ZP_PTR + 1 ; $FC
; opt: peek-cluster
0F18 :  LDY #(u8)(off - g_peek_cluster_min) ; $00
0F1A :  LDA (ZP_PTR),Y ; $FB
0F1C :  STA slot+0
0F1E :  LDX #0 ; $00
0F20 :  LDY #(u8)(off - g_peek_cluster_min) ; $01
0F22 :  LDA (ZP_PTR),Y ; $FB
0F24 :  CLC
0F25 :  ADC slot+0
0F27 :  STA slot+0
0F29 :  TXA
0F2A :  ADC #0 ; $00
0F2C :  TAX
0F2D :  LDY #(u8)(off - g_peek_cluster_min) ; $02
0F2F :  LDA (ZP_PTR),Y ; $FB
0F31 :  CLC
0F32 :  ADC slot+0
0F34 :  STA slot+0
0F36 :  TXA
0F37 :  ADC #0 ; $00
0F39 :  TAX
0F3A :  LDY #(u8)(off - g_peek_cluster_min) ; $28
0F3C :  LDA (ZP_PTR),Y ; $FB
0F3E :  CLC
0F3F :  ADC slot+0
0F41 :  STA slot+0
0F43 :  TXA
0F44 :  ADC #0 ; $00
0F46 :  TAX
0F47 :  LDY #(u8)(off - g_peek_cluster_min) ; $2A
0F49 :  LDA (ZP_PTR),Y ; $FB
0F4B :  CLC
0F4C :  ADC slot+0
0F4E :  STA slot+0
0F50 :  TXA
0F51 :  ADC #0 ; $00
0F53 :  TAX
0F54 :  LDY #(u8)(off - g_peek_cluster_min) ; $50
0F56 :  LDA (ZP_PTR),Y ; $FB
0F58 :  CLC
0F59 :  ADC slot+0
0F5B :  STA slot+0
0F5D :  TXA
0F5E :  ADC #0 ; $00
0F60 :  TAX
0F61 :  LDY #(u8)(off - g_peek_cluster_min) ; $51
0F63 :  LDA (ZP_PTR),Y ; $FB
0F65 :  CLC
0F66 :  ADC slot+0
0F68 :  STA slot+0
0F6A :  TXA
0F6B :  ADC #0 ; $00
0F6D :  TAX
0F6E :  LDY #(u8)(off - g_peek_cluster_min) ; $52
0F70 :  LDA (ZP_PTR),Y ; $FB
0F72 :  CLC
0F73 :  ADC slot+0
0F75 :  STA slot+0
0F77 :  TXA
0F78 :  ADC #0 ; $00
0F7A :  TAX
0F7B :  LDA slot+0
0F7D :  STA C
0F80 :  STX C+1
; 250   $0F83  P=PEEK(BB)
; 28,"life.bas"

L250:
0F83 :  LDY #(u8)e->peek_reuse_y ; $29
0F85 :  LDA (ZP_PTR),Y ; $FB
0F87 :  STA P
; 260   $0F8A  NB=BB+D
; 29,"life.bas"

L260:
; 270   $0F8A  POKE NB,32
; 30,"life.bas"

L270:
0F8A :  LDA NB
0F8D :  LDX NB+1
0F90 :  STA ZP_PTR ; $FB
0F92 :  STX ZP_PTR + 1 ; $FC
0F94 :  LDA #(u8)s->e2->ival ; $20
0F96 :  LDY #0 ; $00
0F98 :  STA (ZP_PTR),Y ; $FB
; 280   $0F9A  IF C=403 OR (P=81 AND C=354) THEN POKE NB,81
; 31,"life.bas"

L280:
; opt: mixed AND/OR-of-cmp short-circuit
0F9A :  LDA C
0F9D :  LDX C+1
0FA0 :  STA slot+0
0FA2 :  STX slot+1
0FA4 :  LDA #LO(e->ival) ; $93
0FA6 :  LDX #LO((e->ival >> 8)) ; $01
0FA8 :  STA ZP_SCR16 ; $FD
0FAA :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-nonneg (EOR #$80 elided)
0FAC :  LDA slot+1
0FAE :  CMP ZP_SCR16 + 1 ; $FE
0FB0 :  BNE .cmp_done
0FB2 :  LDA slot+0
0FB4 :  CMP ZP_SCR16 ; $FD

.cmp_done:
0FB6 :  BEQ .true
0FB8 :  LDA #0x00 ; $00
0FBA :  BEQ .cmp_tail
0FBC :  LDA #0xFF ; $FF

.cmp_tail:
0FBE :  TAX
0FBF :  BEQ +3 ; long branch
0FC1 :  JMP .sc_t

0FC4 :  JMP .sc_f

.sc_mid:
0FC7 :  LDA P
0FCA :  LDX #0 ; $00
0FCC :  STA slot+0
0FCE :  STX slot+1
0FD0 :  LDA #LO(e->ival) ; $51
0FD2 :  STA ZP_SCR16 ; $FD
0FD4 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-hielide (hi bytes known equal; lo-only compare, EOR elided)
0FD6 :  LDA slot+0
0FD8 :  CMP ZP_SCR16 ; $FD
0FDA :  BEQ .true
0FDC :  LDA #0x00 ; $00
0FDE :  BEQ .cmp_tail
0FE0 :  LDA #0xFF ; $FF

.cmp_tail:
0FE2 :  TAX
0FE3 :  BEQ +3 ; long branch
0FE5 :  JMP .sc_t

0FE8 :  JMP .sc_f

.sc_mid:
0FEB :  LDA C
0FEE :  LDX C+1
0FF1 :  STA slot+0
0FF3 :  STX slot+1
0FF5 :  LDA #LO(e->ival) ; $62
0FF7 :  LDX #LO((e->ival >> 8)) ; $01
0FF9 :  STA ZP_SCR16 ; $FD
0FFB :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-nonneg (EOR #$80 elided)
0FFD :  LDA slot+1
0FFF :  CMP ZP_SCR16 + 1 ; $FE
1001 :  BNE .cmp_done
1003 :  LDA slot+0
1005 :  CMP ZP_SCR16 ; $FD

.cmp_done:
1007 :  BEQ .true
1009 :  LDA #0x00 ; $00
100B :  BEQ .cmp_tail
100D :  LDA #0xFF ; $FF

.cmp_tail:
100F :  TAX
1010 :  BEQ +3 ; long branch
1012 :  JMP .sc_t

1015 :  JMP .sc_f

.if_true:
1018 :  LDA NB
101B :  LDX NB+1
101E :  STA ZP_PTR ; $FB
1020 :  STX ZP_PTR + 1 ; $FC
1022 :  LDA #(u8)s->e2->ival ; $51
1024 :  LDY #0 ; $00
1026 :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 290   $1028  BB=BB+1
; 32,"life.bas"

L290:
1028 :  INC BB
102B :  BNE .pm1_skip
102D :  INC BB+1

.pm1_skip:
; 300   $1030  NEXT Y
; 33,"life.bas"

L300:
1030 :  LDA NB
1033 :  CLC
1034 :  ADC #(u8)(st & 0xFF) ; $01
1036 :  STA NB
1039 :  LDA NB+1
103C :  ADC #(u8)((st >> 8) & 0xFF) ; $00
103E :  STA NB+1
1041 :  INC Y
1044 :  BNE .inc_skip
1046 :  INC Y+1

.inc_skip:
1049 :  LDA Y+1
104C :  CMP LIMIT7+1
104F :  BCC .nxt_back
1051 :  BNE .nxt_done
1053 :  LDA Y
1056 :  CMP LIMIT7
1059 :  BCC .nxt_back
105B :  BNE .nxt_done
105D :  BEQ .nxt_back

.nxt_back:
105F :  JMP .for_body ; $0F01

.nxt_done:
; 310   $1062  NEXT X
; 34,"life.bas"

L310:
1062 :  INC X
1065 :  BNE .inc_skip
1067 :  INC X+1

.inc_skip:
106A :  LDA X+1
106D :  CMP LIMIT6+1
1070 :  BCC .nxt_back
1072 :  BNE .nxt_done
1074 :  LDA X
1077 :  CMP LIMIT6
107A :  BCC .nxt_back
107C :  BNE .nxt_done
107E :  BEQ .nxt_back

.nxt_back:
1080 :  JMP .for_body ; $0E98

.nxt_done:
; 320   $1083  FOR R=1 TO W
; 35,"life.bas"

L320:
1083 :  LDA #LO(e->ival) ; $01
1085 :  LDX #LO((e->ival >> 8)) ; $00
1087 :  STA R
108A :  STX R+1
108D :  LDA W
1090 :  STA LIMIT8
1093 :  STX LIMIT8+1

.for_body:
; 330   $1096  FOR C=1 TO W
; 36,"life.bas"

L330:
; opt: licm-subexpr memmove-2base
1096 :  LDA L
1099 :  LDX L+1
109C :  STA slot+0
109E :  STX slot+1
10A0 :  LDA R
10A3 :  LDX #0 ; $00
10A5 :  TAY
10A6 :  LDA h_mulK_hi[K],Y ; $084A
10A9 :  TAX
10AA :  LDA h_mulK_lo[K],Y ; $0834
10AD :  CLC
10AE :  ADC slot+0
10B0 :  PHA
10B1 :  TXA
10B2 :  ADC slot+1
10B4 :  TAX
10B5 :  PLA
10B6 :  STA LICM3
10B9 :  STX LICM3+1
10BC :  LDA N
10BF :  LDX N+1
10C2 :  STA slot+0
10C4 :  STX slot+1
10C6 :  LDA R
10C9 :  LDX #0 ; $00
10CB :  TAY
10CC :  LDA h_mulK_hi[K],Y ; $084A
10CF :  TAX
10D0 :  LDA h_mulK_lo[K],Y ; $0834
10D3 :  CLC
10D4 :  ADC slot+0
10D6 :  PHA
10D7 :  TXA
10D8 :  ADC slot+1
10DA :  TAX
10DB :  PLA
10DC :  STA LICM4
10DF :  STX LICM4+1
; #6 inc-3v: runtime count = limit - start + 1 (forward)
10E2 :  LDA W
10E5 :  LDX #0 ; $00
10E7 :  STA VLMT9
10EA :  STX VLMT9+1
10ED :  SEC
10EE :  SBC #(u8)(vc_start & 0xFF) ; $01
10F0 :  PHA
10F1 :  TXA
10F2 :  SBC #(u8)((vc_start >> 8) & 0xFF) ; $00
10F4 :  TAX
10F5 :  PLA
10F6 :  CLC
10F7 :  ADC #1 ; $01
10F9 :  PHA
10FA :  TXA
10FB :  ADC #0 ; $00
10FD :  TAX
10FE :  PLA
10FF :  STA VCNT9
1102 :  STX VCNT9+1
1105 :  LDA VCNT9+1
1108 :  BMI .vc_set1
110A :  BNE .vc_keep
110C :  LDA VCNT9
110F :  BNE .vc_keep

.vc_set1:
1111 :  LDA #1 ; $01
1113 :  STA VCNT9
1116 :  LDA #0 ; $00
1118 :  STA VCNT9+1

.vc_keep:
111B :  LDA VLMT9
111E :  CLC
111F :  ADC #1 ; $01
1121 :  STA C
1124 :  LDA VLMT9+1
1127 :  ADC #0 ; $00
1129 :  STA C+1
112C :  LDA LICM3
112F :  STA zplo ; $FB
1131 :  LDA LICM3+1
1134 :  STA zplo + 1 ; $FC
1136 :  CLC
1137 :  LDA zplo ; $FB
1139 :  ADC #(u8)(off & 0xFF) ; $01
113B :  STA zplo ; $FB
113D :  LDA zplo + 1 ; $FC
113F :  ADC #(u8)((off >> 8) & 0xFF) ; $00
1141 :  STA zplo + 1 ; $FC
1143 :  LDA LICM4
1146 :  STA zplo ; $FE
1148 :  LDA LICM4+1
114B :  STA zplo + 1 ; $FF
114D :  CLC
114E :  LDA zplo ; $FE
1150 :  ADC #(u8)(off & 0xFF) ; $01
1152 :  STA zplo ; $FE
1154 :  LDA zplo + 1 ; $FF
1156 :  ADC #(u8)((off >> 8) & 0xFF) ; $00
1158 :  STA zplo + 1 ; $FF
115A :  LDA VCNT9+1
115D :  BEQ .vcrem
115F :  TAX

.vcblk:
1160 :  LDY #0 ; $00

.vcinn:
1162 :  LDA (ZP_SRC),Y ; $FE
1164 :  STA (ZP_PTR),Y ; $FB
1166 :  INY
1167 :  BNE .vcinn
1169 :  INC ZP_PTR + 1 ; $FC
116B :  INC ZP_SRC + 1 ; $FF
116D :  DEX
116E :  BNE .vcblk

.vcrem:
1170 :  LDY #0 ; $00
1172 :  LDA VCNT9
1175 :  BEQ .vcdone
1177 :  TAX

.vcrlp:
1178 :  LDA (ZP_SRC),Y ; $FE
117A :  STA (ZP_PTR),Y ; $FB
117C :  INY
117D :  DEX
117E :  BNE .vcrlp

.vcdone:
; 340   $1180  POKE L+R*40+C,PEEK(N+R*40+C)
; 37,"life.bas"

L340:
; 350   $1180  NEXT C
; 38,"life.bas"

L350:
; 360   $1180  NEXT R
; 39,"life.bas"

L360:
1180 :  INC R
1183 :  BNE .inc_skip
1185 :  INC R+1

.inc_skip:
1188 :  LDA R+1
118B :  CMP LIMIT8+1
118E :  BCC .nxt_back
1190 :  BNE .nxt_done
1192 :  LDA R
1195 :  CMP LIMIT8
1198 :  BCC .nxt_back
119A :  BNE .nxt_done
119C :  BEQ .nxt_back

.nxt_back:
119E :  JMP .for_body ; $1096

.nxt_done:
; 370   $11A1  POKE 1024,32
; 40,"life.bas"

L370:
11A1 :  LDA #(u8)s->e2->ival ; $20
11A3 :  STA ; $0400
; 380   $11A6  PRINT CHR$(19);TI-T%
; 41,"life.bas"

L380:
11A6 :  LDA #LO(e->ival) ; $13
11A8 :  LDX #LO((e->ival >> 8)) ; $00
11AA :  JSR ROM_CHROUT ; $FFD2
11AD :  JSR RT_ti_read ; $0BE7
11B0 :  LDX #<addr ; $28
11B2 :  LDY #>addr ; $08
11B4 :  JSR ROM_FAC_MEM ; $BBD4
11B7 :  LDA T
11BA :  LDX T+1
11BD :  TAY
11BE :  TXA
11BF :  JSR ROM_INT_FAC ; $B391
11C2 :  LDA #<addr ; $28
11C4 :  LDY #>addr ; $08
11C6 :  JSR ROM_MEM_ARG ; $BA8C
11C9 :  LDA FACEXP ; $61
11CB :  LDA #<addr ; $28
11CD :  LDY #>addr ; $08
11CF :  JSR ROM_MINUS ; $B850
11D2 :  JSR ROM_FOUT ; $BDDD
11D5 :  LDY #0 ; $00

.fpl:
11D7 :  LDA ZP_GETBUF,Y ; $0100
11DA :  BEQ .fpr_done
11DC :  JSR ROM_CHROUT ; $FFD2
11DF :  INY
11E0 :  BNE .fpr

.fpr_done:
11E2 :  LDA #0x1D ; $1D
11E4 :  JSR ROM_CHROUT ; $FFD2
11E7 :  LDA #13 ; $0D
11E9 :  JSR ROM_CHROUT ; $FFD2
; 390   $11EC  NEXT K
; 42,"life.bas"

L390:
11EC :  INC K
11EF :  BNE .inc_skip
11F1 :  INC K+1

.inc_skip:
11F4 :  LDA K+1
11F7 :  CMP LIMIT5+1
11FA :  BCC .nxt_back
11FC :  BNE .nxt_done
11FE :  LDA K
1201 :  CMP LIMIT5
1204 :  BCC .nxt_back
1206 :  BNE .nxt_done
1208 :  BEQ .nxt_back

.nxt_back:
120A :  JMP .for_body ; $0E75

.nxt_done:
; 400   $120D  S=0
; 44,"life.bas"

L400:
120D :  LDA #clo ; $00
120F :  STA S
1212 :  STA S+1
; 410   $1215  FOR R=1 TO W
; 45,"life.bas"

L410:
1215 :  LDA #LO(e->ival) ; $01
1217 :  LDX #LO((e->ival >> 8)) ; $00
1219 :  STA R
121C :  STX R+1
121F :  LDA W
1222 :  STA LIMIT10
1225 :  STX LIMIT10+1

.for_body:
; 420   $1228  FOR C=1 TO W
; 46,"life.bas"

L420:
1228 :  LDA #LO(e->ival) ; $01
122A :  LDX #LO((e->ival >> 8)) ; $00
122C :  STA C
122F :  STX C+1
1232 :  LDA W
1235 :  STA LIMIT11
1238 :  STX LIMIT11+1
123B :  LDA L
123E :  LDX L+1
1241 :  STA slot+0
1243 :  STX slot+1
1245 :  LDA R
1248 :  LDX #0 ; $00
124A :  TAY
124B :  LDA h_mulK_hi[K],Y ; $084A
124E :  TAX
124F :  LDA h_mulK_lo[K],Y ; $0834
1252 :  CLC
1253 :  ADC slot+0
1255 :  PHA
1256 :  TXA
1257 :  ADC slot+1
1259 :  TAX
125A :  PLA
125B :  STA LICM5
125E :  STX LICM5+1
1261 :  STA slot+0
1263 :  STX slot+1
1265 :  LDA C
1268 :  LDX C+1
126B :  CLC
126C :  ADC slot+0
126E :  PHA
126F :  TXA
1270 :  ADC slot+1
1272 :  TAX
1273 :  PLA
1274 :  STA LOPT3
1277 :  STX LOPT3+1
; opt: licm-subexpr

.for_body:
; 430   $127A  S=S-(PEEK(L+R*40+C)=81)
; 47,"life.bas"

L430:
127A :  LDA LOPT3
127D :  LDX LOPT3+1
1280 :  STA ZP_PTR ; $FB
1282 :  STX ZP_PTR + 1 ; $FC
1284 :  LDY #0 ; $00
1286 :  LDA (ZP_PTR),Y ; $FB
1288 :  LDX #0 ; $00
128A :  STA slot+0
128C :  STX slot+1
128E :  LDA #LO(e->ival) ; $51
1290 :  STA ZP_SCR16 ; $FD
1292 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-hielide (hi bytes known equal; lo-only compare, EOR elided)
1294 :  LDA slot+0
1296 :  CMP ZP_SCR16 ; $FD
1298 :  BEQ .true
129A :  LDA #0x00 ; $00
129C :  BEQ .cmp_tail
129E :  LDA #0xFF ; $FF

.cmp_tail:
12A0 :  TAX
12A1 :  STA slot+0
12A3 :  STX slot+1
12A5 :  LDA S
12A8 :  LDX #0 ; $00
12AA :  SEC
12AB :  SBC slot+0
12AD :  PHA
12AE :  TXA
12AF :  SBC slot+1
12B1 :  TAX
12B2 :  PLA
12B3 :  STA S
12B6 :  STX S+1
; 440   $12B9  NEXT C
; 48,"life.bas"

L440:
12B9 :  LDA LOPT3
12BC :  CLC
12BD :  ADC #(u8)(st & 0xFF) ; $01
12BF :  STA LOPT3
12C2 :  LDA LOPT3+1
12C5 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
12C7 :  STA LOPT3+1
12CA :  INC C
12CD :  BNE .inc_skip
12CF :  INC C+1

.inc_skip:
12D2 :  LDA C+1
12D5 :  CMP LIMIT11+1
12D8 :  BCC .nxt_back
12DA :  BNE .nxt_done
12DC :  LDA C
12DF :  CMP LIMIT11
12E2 :  BCC .nxt_back
12E4 :  BNE .nxt_done
12E6 :  BEQ .nxt_back

.nxt_back:
12E8 :  JMP .for_body ; $127A

.nxt_done:
; 450   $12EB  NEXT R
; 49,"life.bas"

L450:
12EB :  INC R
12EE :  BNE .inc_skip
12F0 :  INC R+1

.inc_skip:
12F3 :  LDA R+1
12F6 :  CMP LIMIT10+1
12F9 :  BCC .nxt_back
12FB :  BNE .nxt_done
12FD :  LDA R
1300 :  CMP LIMIT10
1303 :  BCC .nxt_back
1305 :  BNE .nxt_done
1307 :  BEQ .nxt_back

.nxt_back:
1309 :  JMP .for_body ; $1228

.nxt_done:
; 460   $130C  PRINT "GENS=";G
; 51,"life.bas"

L460:
130C :  LDA #<addr ; $13
130E :  STA ZP_PTR ; $FB
1310 :  LDA #>addr ; $08
1312 :  STA ZP_PTR + 1 ; $FC
1314 :  LDA #(u8)str_lits[idx].bytes.size() ; $05
1316 :  JSR RT_print_str ; $0860
1319 :  LDA G
131C :  LDX #0 ; $00
131E :  JSR RT_print_int ; $093C
1321 :  LDA #13 ; $0D
1323 :  JSR ROM_CHROUT ; $FFD2
; 470   $1326  PRINT "ALIVE=";S
; 52,"life.bas"

L470:
1326 :  LDA #<addr ; $18
1328 :  STA ZP_PTR ; $FB
132A :  LDA #>addr ; $08
132C :  STA ZP_PTR + 1 ; $FC
132E :  LDA #(u8)str_lits[idx].bytes.size() ; $06
1330 :  JSR RT_print_str ; $0860
1333 :  LDA S
1336 :  LDX S+1
1339 :  JSR RT_print_int ; $093C
133C :  LDA #13 ; $0D
133E :  JSR ROM_CHROUT ; $FFD2
; halt
1341 :  RTS

; ---- variables (zero-filled) ----
W = $1342
; W      $1342 (2 bytes)
G = $1344
; G      $1344 (2 bytes)
L = $1346
; L      $1346 (2 bytes)
N = $1348
; N      $1348 (2 bytes)
D = $134A
; D      $134A (2 bytes)
R = $134C
; R      $134C (2 bytes)
C = $134E
; C      $134E (2 bytes)
Z_F = $1350
; Z      $1350 (5 bytes)
K = $1355
; K      $1355 (2 bytes)
T = $1357
; T      $1357 (2 bytes)
TI_F = $1359
; TI     $1359 (5 bytes)
X = $135E
; X      $135E (2 bytes)
BB = $1360
; BB     $1360 (2 bytes)
Y = $1362
; Y      $1362 (2 bytes)
P = $1364
; P      $1364 (2 bytes)
NB = $1366
; NB     $1366 (2 bytes)
S = $1368
; S      $1368 (2 bytes)
LICM0 = $136A
; LICM0  $136A (2 bytes)
LICM1 = $136C
; LICM1  $136C (2 bytes)
LICM2 = $136E
; LICM2  $136E (2 bytes)
LICM3 = $1370
; LICM3  $1370 (2 bytes)
LICM4 = $1372
; LICM4  $1372 (2 bytes)
LICM5 = $1374
; LICM5  $1374 (2 bytes)
LOPT0 = $1376
; LOPT0  $1376 (2 bytes)
LOPT1 = $1378
; LOPT1  $1378 (2 bytes)
LOPT2 = $137A
; LOPT2  $137A (2 bytes)
LOPT3 = $137C
; LOPT3  $137C (2 bytes)
LIMIT1 = $137E
; LIMIT1 $137E (2 bytes)
LIMIT2 = $1380
; LIMIT2 $1380 (2 bytes)
LIMIT3 = $1382
; LIMIT3 $1382 (2 bytes)
LIMIT4 = $1384
; LIMIT4 $1384 (2 bytes)
LIMIT5 = $1386
; LIMIT5 $1386 (2 bytes)
LIMIT6 = $1388
; LIMIT6 $1388 (2 bytes)
LIMIT7 = $138A
; LIMIT7 $138A (2 bytes)
LIMIT8 = $138C
; LIMIT8 $138C (2 bytes)
VCNT9 = $138E
; VCNT9  $138E (2 bytes)
VLMT9 = $1390
; VLMT9  $1390 (2 bytes)
LIMIT10 = $1392
; LIMIT10 $1392 (2 bytes)
LIMIT11 = $1394
; LIMIT11 $1394 (2 bytes)
1342 :  .res 84	; variable area
