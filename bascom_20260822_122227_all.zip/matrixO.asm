; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e 24 19 STX $1924 ; (spentry + 0)
0811 : a2 19 __ LDX #$19
0813 : a0 b3 __ LDY #$b3
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 1d __ CPX #$1d
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 a0 __ CPY #$a0
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 e8 __ LDA #$e8
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  30, "C:/Users/g/claude/cpus/6502/examples/compiler/release/matrix.c"
.s1:
0880 : a2 0c __ LDX #$0c
0882 : b5 53 __ LDA T4 + 0,x 
0884 : 9d ea 9f STA $9fea,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 38 12 JSR $1238 ; (b_init.s4 + 0)
088d : 20 0f 13 JSR $130f ; (tsb_init.s4 + 0)
0890 : ad 25 19 LDA $1925 ; (b_mem + 0)
0893 : 85 5e __ STA T12 + 0 
0895 : 85 1f __ STA ADDR + 0 
0897 : a9 93 __ LDA #$93
0899 : 85 13 __ STA P6 
089b : ad 26 19 LDA $1926 ; (b_mem + 1)
089e : 85 5f __ STA T12 + 1 
08a0 : 18 __ __ CLC
08a1 : 69 d0 __ ADC #$d0
08a3 : 85 20 __ STA ADDR + 1 
08a5 : a9 00 __ LDA #$00
08a7 : a0 20 __ LDY #$20
08a9 : 91 1f __ STA (ADDR + 0),y 
08ab : c8 __ __ INY
08ac : 91 1f __ STA (ADDR + 0),y 
08ae : 20 5e 13 JSR $135e ; (b_putc.s4 + 0)
08b1 : a9 0d __ LDA #$0d
08b3 : 85 13 __ STA P6 
08b5 : 20 5e 13 JSR $135e ; (b_putc.s4 + 0)
08b8 : a9 00 __ LDA #$00
08ba : 8d fb 19 STA $19fb ; (b_v_ci + 0)
08bd : 8d fc 19 STA $19fc ; (b_v_ci + 1)
08c0 : 8d fd 19 STA $19fd ; (b_v_ci + 2)
08c3 : 8d fe 19 STA $19fe ; (b_v_ci + 3)
.l5:
08c6 : ad af 19 LDA $19af ; (b_rndSeed + 0)
08c9 : 85 1b __ STA ACCU + 0 
08cb : ad b0 19 LDA $19b0 ; (b_rndSeed + 1)
08ce : 85 1c __ STA ACCU + 1 
08d0 : ad b1 19 LDA $19b1 ; (b_rndSeed + 2)
08d3 : 85 1d __ STA ACCU + 2 
08d5 : ad b2 19 LDA $19b2 ; (b_rndSeed + 3)
08d8 : 85 1e __ STA ACCU + 3 
08da : a9 cd __ LDA #$cd
08dc : 85 03 __ STA WORK + 0 
08de : a9 00 __ LDA #$00
08e0 : 85 06 __ STA WORK + 3 
08e2 : a9 0d __ LDA #$0d
08e4 : 85 04 __ STA WORK + 1 
08e6 : a9 01 __ LDA #$01
08e8 : 85 05 __ STA WORK + 2 
08ea : 20 b8 18 JSR $18b8 ; (mul32 + 0)
08ed : 18 __ __ CLC
08ee : a5 07 __ LDA WORK + 4 
08f0 : 69 39 __ ADC #$39
08f2 : 85 43 __ STA T0 + 0 
08f4 : a5 08 __ LDA WORK + 5 
08f6 : 69 30 __ ADC #$30
08f8 : 85 44 __ STA T0 + 1 
08fa : 85 1b __ STA ACCU + 0 
08fc : a5 09 __ LDA WORK + 6 
08fe : 69 00 __ ADC #$00
0900 : 85 45 __ STA T0 + 2 
0902 : 85 1c __ STA ACCU + 1 
0904 : a5 0a __ LDA WORK + 7 
0906 : 69 00 __ ADC #$00
0908 : 85 46 __ STA T0 + 3 
090a : 85 1d __ STA ACCU + 2 
090c : a9 00 __ LDA #$00
090e : 85 1e __ STA ACCU + 3 
0910 : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
0913 : a9 00 __ LDA #$00
0915 : 85 03 __ STA WORK + 0 
0917 : 85 04 __ STA WORK + 1 
0919 : a9 80 __ LDA #$80
091b : 85 05 __ STA WORK + 2 
091d : a9 4b __ LDA #$4b
091f : 85 06 __ STA WORK + 3 
0921 : 20 f5 15 JSR $15f5 ; (freg + 20)
0924 : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
0927 : a9 00 __ LDA #$00
0929 : 85 03 __ STA WORK + 0 
092b : 85 04 __ STA WORK + 1 
092d : a9 c8 __ LDA #$c8
092f : 85 05 __ STA WORK + 2 
0931 : a9 41 __ LDA #$41
0933 : 85 06 __ STA WORK + 3 
0935 : 20 f5 15 JSR $15f5 ; (freg + 20)
0938 : 20 26 16 JSR $1626 ; (crt_fmul + 0)
093b : a5 1b __ LDA ACCU + 0 
093d : 85 47 __ STA T1 + 0 
093f : a5 1c __ LDA ACCU + 1 
0941 : 85 48 __ STA T1 + 1 
0943 : a5 1d __ LDA ACCU + 2 
0945 : 85 49 __ STA T1 + 2 
0947 : a5 1e __ LDA ACCU + 3 
0949 : 85 4a __ STA T1 + 3 
094b : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
094e : a5 1b __ LDA ACCU + 0 
0950 : 85 4b __ STA T2 + 0 
0952 : a5 1c __ LDA ACCU + 1 
0954 : 85 4c __ STA T2 + 1 
0956 : a5 4a __ LDA T1 + 3 
0958 : 29 7f __ AND #$7f
095a : 05 49 __ ORA T1 + 2 
095c : 05 48 __ ORA T1 + 1 
095e : 05 47 __ ORA T1 + 0 
0960 : f0 3a __ BEQ $099c ; (main.s6 + 0)
.s114:
0962 : 24 4a __ BIT T1 + 3 
0964 : 10 36 __ BPL $099c ; (main.s6 + 0)
.s112:
0966 : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
0969 : a5 1b __ LDA ACCU + 0 
096b : 85 03 __ STA WORK + 0 
096d : a5 1c __ LDA ACCU + 1 
096f : 85 04 __ STA WORK + 1 
0971 : a5 1d __ LDA ACCU + 2 
0973 : 85 05 __ STA WORK + 2 
0975 : a5 1e __ LDA ACCU + 3 
0977 : 85 06 __ STA WORK + 3 
0979 : a5 47 __ LDA T1 + 0 
097b : 85 1b __ STA ACCU + 0 
097d : a5 48 __ LDA T1 + 1 
097f : 85 1c __ STA ACCU + 1 
0981 : a5 49 __ LDA T1 + 2 
0983 : 85 1d __ STA ACCU + 2 
0985 : a5 4a __ LDA T1 + 3 
0987 : 85 1e __ STA ACCU + 3 
0989 : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
098c : f0 0e __ BEQ $099c ; (main.s6 + 0)
.s113:
098e : 18 __ __ CLC
098f : a5 4b __ LDA T2 + 0 
0991 : 69 ff __ ADC #$ff
0993 : 85 47 __ STA T1 + 0 
0995 : a5 4c __ LDA T2 + 1 
0997 : 69 ff __ ADC #$ff
0999 : 4c a2 09 JMP $09a2 ; (main.s7 + 0)
.s6:
099c : a5 4b __ LDA T2 + 0 
099e : 85 47 __ STA T1 + 0 
09a0 : a5 4c __ LDA T2 + 1 
.s7:
09a2 : 85 48 __ STA T1 + 1 
09a4 : ad fb 19 LDA $19fb ; (b_v_ci + 0)
09a7 : 0a __ __ ASL
09a8 : 85 57 __ STA T6 + 0 
09aa : aa __ __ TAX
09ab : a5 47 __ LDA T1 + 0 
09ad : 9d 00 1a STA $1a00,x ; (b_a_hi[0] + 0)
09b0 : a5 48 __ LDA T1 + 1 
09b2 : 9d 01 1a STA $1a01,x ; (b_a_hi[0] + 1)
09b5 : a5 43 __ LDA T0 + 0 
09b7 : 85 1b __ STA ACCU + 0 
09b9 : a5 44 __ LDA T0 + 1 
09bb : 85 1c __ STA ACCU + 1 
09bd : a5 45 __ LDA T0 + 2 
09bf : 85 1d __ STA ACCU + 2 
09c1 : a5 46 __ LDA T0 + 3 
09c3 : 85 1e __ STA ACCU + 3 
09c5 : a9 cd __ LDA #$cd
09c7 : 85 03 __ STA WORK + 0 
09c9 : a9 00 __ LDA #$00
09cb : 85 06 __ STA WORK + 3 
09cd : a9 0d __ LDA #$0d
09cf : 85 04 __ STA WORK + 1 
09d1 : a9 01 __ LDA #$01
09d3 : 85 05 __ STA WORK + 2 
09d5 : 20 b8 18 JSR $18b8 ; (mul32 + 0)
09d8 : 18 __ __ CLC
09d9 : a5 07 __ LDA WORK + 4 
09db : 69 39 __ ADC #$39
09dd : 85 43 __ STA T0 + 0 
09df : a5 08 __ LDA WORK + 5 
09e1 : 69 30 __ ADC #$30
09e3 : 85 44 __ STA T0 + 1 
09e5 : 85 1b __ STA ACCU + 0 
09e7 : a5 09 __ LDA WORK + 6 
09e9 : 69 00 __ ADC #$00
09eb : 85 45 __ STA T0 + 2 
09ed : 85 1c __ STA ACCU + 1 
09ef : a5 0a __ LDA WORK + 7 
09f1 : 69 00 __ ADC #$00
09f3 : 85 46 __ STA T0 + 3 
09f5 : 85 1d __ STA ACCU + 2 
09f7 : a9 00 __ LDA #$00
09f9 : 85 1e __ STA ACCU + 3 
09fb : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
09fe : a9 00 __ LDA #$00
0a00 : 85 03 __ STA WORK + 0 
0a02 : 85 04 __ STA WORK + 1 
0a04 : a9 80 __ LDA #$80
0a06 : 85 05 __ STA WORK + 2 
0a08 : a9 4b __ LDA #$4b
0a0a : 85 06 __ STA WORK + 3 
0a0c : 20 f5 15 JSR $15f5 ; (freg + 20)
0a0f : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
0a12 : a9 00 __ LDA #$00
0a14 : 85 03 __ STA WORK + 0 
0a16 : 85 04 __ STA WORK + 1 
0a18 : a9 20 __ LDA #$20
0a1a : 85 05 __ STA WORK + 2 
0a1c : a9 41 __ LDA #$41
0a1e : 85 06 __ STA WORK + 3 
0a20 : 20 f5 15 JSR $15f5 ; (freg + 20)
0a23 : 20 26 16 JSR $1626 ; (crt_fmul + 0)
0a26 : a5 1b __ LDA ACCU + 0 
0a28 : 85 4f __ STA T3 + 0 
0a2a : a5 1c __ LDA ACCU + 1 
0a2c : 85 50 __ STA T3 + 1 
0a2e : a5 1d __ LDA ACCU + 2 
0a30 : 85 51 __ STA T3 + 2 
0a32 : a5 1e __ LDA ACCU + 3 
0a34 : 85 52 __ STA T3 + 3 
0a36 : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
0a39 : a5 1b __ LDA ACCU + 0 
0a3b : 85 53 __ STA T4 + 0 
0a3d : a5 1c __ LDA ACCU + 1 
0a3f : 85 54 __ STA T4 + 1 
0a41 : a5 52 __ LDA T3 + 3 
0a43 : 29 7f __ AND #$7f
0a45 : 05 51 __ ORA T3 + 2 
0a47 : 05 50 __ ORA T3 + 1 
0a49 : 05 4f __ ORA T3 + 0 
0a4b : f0 39 __ BEQ $0a86 ; (main.s8 + 0)
.s111:
0a4d : 24 52 __ BIT T3 + 3 
0a4f : 10 35 __ BPL $0a86 ; (main.s8 + 0)
.s109:
0a51 : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
0a54 : a5 1b __ LDA ACCU + 0 
0a56 : 85 03 __ STA WORK + 0 
0a58 : a5 1c __ LDA ACCU + 1 
0a5a : 85 04 __ STA WORK + 1 
0a5c : a5 1d __ LDA ACCU + 2 
0a5e : 85 05 __ STA WORK + 2 
0a60 : a5 1e __ LDA ACCU + 3 
0a62 : 85 06 __ STA WORK + 3 
0a64 : a5 4f __ LDA T3 + 0 
0a66 : 85 1b __ STA ACCU + 0 
0a68 : a5 50 __ LDA T3 + 1 
0a6a : 85 1c __ STA ACCU + 1 
0a6c : a5 51 __ LDA T3 + 2 
0a6e : 85 1d __ STA ACCU + 2 
0a70 : a5 52 __ LDA T3 + 3 
0a72 : 85 1e __ STA ACCU + 3 
0a74 : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
0a77 : f0 0d __ BEQ $0a86 ; (main.s8 + 0)
.s110:
0a79 : 18 __ __ CLC
0a7a : a5 53 __ LDA T4 + 0 
0a7c : 69 ff __ ADC #$ff
0a7e : a8 __ __ TAY
0a7f : a5 54 __ LDA T4 + 1 
0a81 : 69 ff __ ADC #$ff
0a83 : 4c 8a 0a JMP $0a8a ; (main.s9 + 0)
.s8:
0a86 : a5 54 __ LDA T4 + 1 
0a88 : a4 53 __ LDY T4 + 0 
.s9:
0a8a : aa __ __ TAX
0a8b : 98 __ __ TYA
0a8c : 18 __ __ CLC
0a8d : 69 05 __ ADC #$05
0a8f : 85 4f __ STA T3 + 0 
0a91 : a4 57 __ LDY T6 + 0 
0a93 : 99 50 1a STA $1a50,y ; (b_a_ti[0] + 0)
0a96 : 8a __ __ TXA
0a97 : 69 00 __ ADC #$00
0a99 : 85 50 __ STA T3 + 1 
0a9b : 99 51 1a STA $1a51,y ; (b_a_ti[0] + 1)
0a9e : 38 __ __ SEC
0a9f : a5 47 __ LDA T1 + 0 
0aa1 : e5 4f __ SBC T3 + 0 
0aa3 : 99 a0 1a STA $1aa0,y ; (b_a_ei[0] + 0)
0aa6 : aa __ __ TAX
0aa7 : a5 48 __ LDA T1 + 1 
0aa9 : e5 50 __ SBC T3 + 1 
0aab : 85 48 __ STA T1 + 1 
0aad : 99 a1 1a STA $1aa1,y ; (b_a_ei[0] + 1)
0ab0 : 10 04 __ BPL $0ab6 ; (main.s11 + 0)
.s10:
0ab2 : a9 01 __ LDA #$01
0ab4 : d0 02 __ BNE $0ab8 ; (main.s12 + 0)
.s11:
0ab6 : a9 00 __ LDA #$00
.s12:
0ab8 : 49 ff __ EOR #$ff
0aba : c9 ff __ CMP #$ff
0abc : f0 0e __ BEQ $0acc ; (main.s13 + 0)
.s108:
0abe : 8a __ __ TXA
0abf : 18 __ __ CLC
0ac0 : 69 19 __ ADC #$19
0ac2 : 99 a0 1a STA $1aa0,y ; (b_a_ei[0] + 0)
0ac5 : a5 48 __ LDA T1 + 1 
0ac7 : 69 00 __ ADC #$00
0ac9 : 99 a1 1a STA $1aa1,y ; (b_a_ei[0] + 1)
.s13:
0acc : a5 43 __ LDA T0 + 0 
0ace : 85 1b __ STA ACCU + 0 
0ad0 : a5 44 __ LDA T0 + 1 
0ad2 : 85 1c __ STA ACCU + 1 
0ad4 : a5 45 __ LDA T0 + 2 
0ad6 : 85 1d __ STA ACCU + 2 
0ad8 : a5 46 __ LDA T0 + 3 
0ada : 85 1e __ STA ACCU + 3 
0adc : a9 cd __ LDA #$cd
0ade : 85 03 __ STA WORK + 0 
0ae0 : a9 00 __ LDA #$00
0ae2 : 85 06 __ STA WORK + 3 
0ae4 : a9 0d __ LDA #$0d
0ae6 : 85 04 __ STA WORK + 1 
0ae8 : a9 01 __ LDA #$01
0aea : 85 05 __ STA WORK + 2 
0aec : 20 b8 18 JSR $18b8 ; (mul32 + 0)
0aef : 18 __ __ CLC
0af0 : a5 07 __ LDA WORK + 4 
0af2 : 69 39 __ ADC #$39
0af4 : 85 43 __ STA T0 + 0 
0af6 : a5 08 __ LDA WORK + 5 
0af8 : 69 30 __ ADC #$30
0afa : 85 44 __ STA T0 + 1 
0afc : 85 1b __ STA ACCU + 0 
0afe : a5 09 __ LDA WORK + 6 
0b00 : 69 00 __ ADC #$00
0b02 : 85 45 __ STA T0 + 2 
0b04 : 85 1c __ STA ACCU + 1 
0b06 : a5 0a __ LDA WORK + 7 
0b08 : 69 00 __ ADC #$00
0b0a : 85 46 __ STA T0 + 3 
0b0c : 85 1d __ STA ACCU + 2 
0b0e : a9 00 __ LDA #$00
0b10 : 85 1e __ STA ACCU + 3 
0b12 : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
0b15 : a9 00 __ LDA #$00
0b17 : 85 03 __ STA WORK + 0 
0b19 : 85 04 __ STA WORK + 1 
0b1b : a9 80 __ LDA #$80
0b1d : 85 05 __ STA WORK + 2 
0b1f : a9 4b __ LDA #$4b
0b21 : 85 06 __ STA WORK + 3 
0b23 : 20 f5 15 JSR $15f5 ; (freg + 20)
0b26 : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
0b29 : a9 00 __ LDA #$00
0b2b : 85 03 __ STA WORK + 0 
0b2d : 85 04 __ STA WORK + 1 
0b2f : a9 68 __ LDA #$68
0b31 : 85 05 __ STA WORK + 2 
0b33 : a9 42 __ LDA #$42
0b35 : 85 06 __ STA WORK + 3 
0b37 : 20 f5 15 JSR $15f5 ; (freg + 20)
0b3a : 20 26 16 JSR $1626 ; (crt_fmul + 0)
0b3d : a5 1b __ LDA ACCU + 0 
0b3f : 85 47 __ STA T1 + 0 
0b41 : a5 1c __ LDA ACCU + 1 
0b43 : 85 48 __ STA T1 + 1 
0b45 : a5 1d __ LDA ACCU + 2 
0b47 : 85 49 __ STA T1 + 2 
0b49 : a5 1e __ LDA ACCU + 3 
0b4b : 85 4a __ STA T1 + 3 
0b4d : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
0b50 : a5 1b __ LDA ACCU + 0 
0b52 : 85 4f __ STA T3 + 0 
0b54 : a5 1c __ LDA ACCU + 1 
0b56 : 85 50 __ STA T3 + 1 
0b58 : a5 4a __ LDA T1 + 3 
0b5a : 29 7f __ AND #$7f
0b5c : 05 49 __ ORA T1 + 2 
0b5e : 05 48 __ ORA T1 + 1 
0b60 : 05 47 __ ORA T1 + 0 
0b62 : f0 39 __ BEQ $0b9d ; (main.s14 + 0)
.s107:
0b64 : 24 4a __ BIT T1 + 3 
0b66 : 10 35 __ BPL $0b9d ; (main.s14 + 0)
.s105:
0b68 : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
0b6b : a5 1b __ LDA ACCU + 0 
0b6d : 85 03 __ STA WORK + 0 
0b6f : a5 1c __ LDA ACCU + 1 
0b71 : 85 04 __ STA WORK + 1 
0b73 : a5 1d __ LDA ACCU + 2 
0b75 : 85 05 __ STA WORK + 2 
0b77 : a5 1e __ LDA ACCU + 3 
0b79 : 85 06 __ STA WORK + 3 
0b7b : a5 47 __ LDA T1 + 0 
0b7d : 85 1b __ STA ACCU + 0 
0b7f : a5 48 __ LDA T1 + 1 
0b81 : 85 1c __ STA ACCU + 1 
0b83 : a5 49 __ LDA T1 + 2 
0b85 : 85 1d __ STA ACCU + 2 
0b87 : a5 4a __ LDA T1 + 3 
0b89 : 85 1e __ STA ACCU + 3 
0b8b : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
0b8e : f0 0d __ BEQ $0b9d ; (main.s14 + 0)
.s106:
0b90 : 18 __ __ CLC
0b91 : a5 4f __ LDA T3 + 0 
0b93 : 69 ff __ ADC #$ff
0b95 : a8 __ __ TAY
0b96 : a5 50 __ LDA T3 + 1 
0b98 : 69 ff __ ADC #$ff
0b9a : 4c a1 0b JMP $0ba1 ; (main.s15 + 0)
.s14:
0b9d : a5 50 __ LDA T3 + 1 
0b9f : a4 4f __ LDY T3 + 0 
.s15:
0ba1 : aa __ __ TAX
0ba2 : 98 __ __ TYA
0ba3 : 18 __ __ CLC
0ba4 : 69 21 __ ADC #$21
0ba6 : a4 57 __ LDY T6 + 0 
0ba8 : 99 00 1b STA $1b00,y ; (b_a_chi[0] + 0)
0bab : 8a __ __ TXA
0bac : 69 00 __ ADC #$00
0bae : 99 01 1b STA $1b01,y ; (b_a_chi[0] + 1)
0bb1 : a5 43 __ LDA T0 + 0 
0bb3 : 85 1b __ STA ACCU + 0 
0bb5 : a5 44 __ LDA T0 + 1 
0bb7 : 85 1c __ STA ACCU + 1 
0bb9 : a5 45 __ LDA T0 + 2 
0bbb : 85 1d __ STA ACCU + 2 
0bbd : a5 46 __ LDA T0 + 3 
0bbf : 85 1e __ STA ACCU + 3 
0bc1 : a9 cd __ LDA #$cd
0bc3 : 85 03 __ STA WORK + 0 
0bc5 : a9 00 __ LDA #$00
0bc7 : 85 06 __ STA WORK + 3 
0bc9 : a9 0d __ LDA #$0d
0bcb : 85 04 __ STA WORK + 1 
0bcd : a9 01 __ LDA #$01
0bcf : 85 05 __ STA WORK + 2 
0bd1 : 20 b8 18 JSR $18b8 ; (mul32 + 0)
0bd4 : 18 __ __ CLC
0bd5 : a5 07 __ LDA WORK + 4 
0bd7 : 69 39 __ ADC #$39
0bd9 : 8d af 19 STA $19af ; (b_rndSeed + 0)
0bdc : a5 08 __ LDA WORK + 5 
0bde : 69 30 __ ADC #$30
0be0 : 8d b0 19 STA $19b0 ; (b_rndSeed + 1)
0be3 : 85 1b __ STA ACCU + 0 
0be5 : a5 09 __ LDA WORK + 6 
0be7 : 69 00 __ ADC #$00
0be9 : 8d b1 19 STA $19b1 ; (b_rndSeed + 2)
0bec : 85 1c __ STA ACCU + 1 
0bee : a5 0a __ LDA WORK + 7 
0bf0 : 69 00 __ ADC #$00
0bf2 : 8d b2 19 STA $19b2 ; (b_rndSeed + 3)
0bf5 : 85 1d __ STA ACCU + 2 
0bf7 : a9 00 __ LDA #$00
0bf9 : 85 1e __ STA ACCU + 3 
0bfb : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
0bfe : a9 00 __ LDA #$00
0c00 : 85 03 __ STA WORK + 0 
0c02 : 85 04 __ STA WORK + 1 
0c04 : a9 80 __ LDA #$80
0c06 : 85 05 __ STA WORK + 2 
0c08 : a9 4b __ LDA #$4b
0c0a : 85 06 __ STA WORK + 3 
0c0c : 20 f5 15 JSR $15f5 ; (freg + 20)
0c0f : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
0c12 : a9 00 __ LDA #$00
0c14 : 85 03 __ STA WORK + 0 
0c16 : 85 04 __ STA WORK + 1 
0c18 : a9 a0 __ LDA #$a0
0c1a : 85 05 __ STA WORK + 2 
0c1c : a9 40 __ LDA #$40
0c1e : 85 06 __ STA WORK + 3 
0c20 : 20 f5 15 JSR $15f5 ; (freg + 20)
0c23 : 20 26 16 JSR $1626 ; (crt_fmul + 0)
0c26 : a5 1b __ LDA ACCU + 0 
0c28 : 85 43 __ STA T0 + 0 
0c2a : a5 1c __ LDA ACCU + 1 
0c2c : 85 44 __ STA T0 + 1 
0c2e : a5 1d __ LDA ACCU + 2 
0c30 : 85 45 __ STA T0 + 2 
0c32 : a5 1e __ LDA ACCU + 3 
0c34 : 85 46 __ STA T0 + 3 
0c36 : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
0c39 : a5 1b __ LDA ACCU + 0 
0c3b : 85 47 __ STA T1 + 0 
0c3d : a5 1c __ LDA ACCU + 1 
0c3f : 85 48 __ STA T1 + 1 
0c41 : a5 46 __ LDA T0 + 3 
0c43 : 29 7f __ AND #$7f
0c45 : 05 45 __ ORA T0 + 2 
0c47 : 05 44 __ ORA T0 + 1 
0c49 : 05 43 __ ORA T0 + 0 
0c4b : f0 39 __ BEQ $0c86 ; (main.s16 + 0)
.s104:
0c4d : 24 46 __ BIT T0 + 3 
0c4f : 10 35 __ BPL $0c86 ; (main.s16 + 0)
.s102:
0c51 : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
0c54 : a5 1b __ LDA ACCU + 0 
0c56 : 85 03 __ STA WORK + 0 
0c58 : a5 1c __ LDA ACCU + 1 
0c5a : 85 04 __ STA WORK + 1 
0c5c : a5 1d __ LDA ACCU + 2 
0c5e : 85 05 __ STA WORK + 2 
0c60 : a5 1e __ LDA ACCU + 3 
0c62 : 85 06 __ STA WORK + 3 
0c64 : a5 43 __ LDA T0 + 0 
0c66 : 85 1b __ STA ACCU + 0 
0c68 : a5 44 __ LDA T0 + 1 
0c6a : 85 1c __ STA ACCU + 1 
0c6c : a5 45 __ LDA T0 + 2 
0c6e : 85 1d __ STA ACCU + 2 
0c70 : a5 46 __ LDA T0 + 3 
0c72 : 85 1e __ STA ACCU + 3 
0c74 : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
0c77 : f0 0d __ BEQ $0c86 ; (main.s16 + 0)
.s103:
0c79 : 18 __ __ CLC
0c7a : a5 47 __ LDA T1 + 0 
0c7c : 69 ff __ ADC #$ff
0c7e : a8 __ __ TAY
0c7f : a5 48 __ LDA T1 + 1 
0c81 : 69 ff __ ADC #$ff
0c83 : 4c 8a 0c JMP $0c8a ; (main.s17 + 0)
.s16:
0c86 : a5 48 __ LDA T1 + 1 
0c88 : a4 47 __ LDY T1 + 0 
.s17:
0c8a : aa __ __ TAX
0c8b : 98 __ __ TYA
0c8c : 18 __ __ CLC
0c8d : 69 01 __ ADC #$01
0c8f : a4 57 __ LDY T6 + 0 
0c91 : 99 50 1b STA $1b50,y ; (b_a_di[0] + 0)
0c94 : 8a __ __ TXA
0c95 : 69 00 __ ADC #$00
0c97 : 99 51 1b STA $1b51,y ; (b_a_di[0] + 1)
0c9a : ad fb 19 LDA $19fb ; (b_v_ci + 0)
0c9d : 18 __ __ CLC
0c9e : 69 01 __ ADC #$01
0ca0 : 8d fb 19 STA $19fb ; (b_v_ci + 0)
0ca3 : ad fc 19 LDA $19fc ; (b_v_ci + 1)
0ca6 : 69 00 __ ADC #$00
0ca8 : 8d fc 19 STA $19fc ; (b_v_ci + 1)
0cab : ad fd 19 LDA $19fd ; (b_v_ci + 2)
0cae : 69 00 __ ADC #$00
0cb0 : 8d fd 19 STA $19fd ; (b_v_ci + 2)
0cb3 : ad fe 19 LDA $19fe ; (b_v_ci + 3)
0cb6 : 69 00 __ ADC #$00
0cb8 : 8d fe 19 STA $19fe ; (b_v_ci + 3)
0cbb : d0 14 __ BNE $0cd1 ; (main.l18 + 0)
.s99:
0cbd : ad fd 19 LDA $19fd ; (b_v_ci + 2)
0cc0 : d0 0f __ BNE $0cd1 ; (main.l18 + 0)
.s100:
0cc2 : ad fc 19 LDA $19fc ; (b_v_ci + 1)
0cc5 : d0 0a __ BNE $0cd1 ; (main.l18 + 0)
.s101:
0cc7 : a9 27 __ LDA #$27
0cc9 : cd fb 19 CMP $19fb ; (b_v_ci + 0)
0ccc : 90 03 __ BCC $0cd1 ; (main.l18 + 0)
0cce : 4c c6 08 JMP $08c6 ; (main.l5 + 0)
.l18:
0cd1 : a9 00 __ LDA #$00
0cd3 : 8d fb 19 STA $19fb ; (b_v_ci + 0)
0cd6 : 8d fc 19 STA $19fc ; (b_v_ci + 1)
0cd9 : 8d fd 19 STA $19fd ; (b_v_ci + 2)
0cdc : 8d fe 19 STA $19fe ; (b_v_ci + 3)
0cdf : ad 2b 19 LDA $192b ; (b_gosubSP + 0)
0ce2 : 0a __ __ ASL
0ce3 : a8 __ __ TAY
0ce4 : ad 2c 19 LDA $192c ; (b_gosubSP + 1)
0ce7 : 2a __ __ ROL
0ce8 : aa __ __ TAX
0ce9 : 98 __ __ TYA
0cea : 18 __ __ CLC
0ceb : 69 a0 __ ADC #$a0
0ced : 85 55 __ STA T5 + 0 
0cef : 8a __ __ TXA
0cf0 : 69 1b __ ADC #$1b
0cf2 : 85 56 __ STA T5 + 1 
.l19:
0cf4 : a9 00 __ LDA #$00
0cf6 : a8 __ __ TAY
0cf7 : 91 55 __ STA (T5 + 0),y 
0cf9 : c8 __ __ INY
0cfa : 91 55 __ STA (T5 + 0),y 
0cfc : ad fd 19 LDA $19fd ; (b_v_ci + 2)
0cff : 85 45 __ STA T0 + 2 
0d01 : ad fe 19 LDA $19fe ; (b_v_ci + 3)
0d04 : 85 46 __ STA T0 + 3 
0d06 : ad fb 19 LDA $19fb ; (b_v_ci + 0)
0d09 : 85 43 __ STA T0 + 0 
0d0b : 0a __ __ ASL
0d0c : 85 4f __ STA T3 + 0 
0d0e : 85 57 __ STA T6 + 0 
0d10 : aa __ __ TAX
0d11 : bd 00 1b LDA $1b00,x ; (b_a_chi[0] + 0)
0d14 : 85 53 __ STA T4 + 0 
0d16 : bd 01 1b LDA $1b01,x ; (b_a_chi[0] + 1)
0d19 : 85 54 __ STA T4 + 1 
0d1b : bd 00 1a LDA $1a00,x ; (b_a_hi[0] + 0)
0d1e : 85 58 __ STA T8 + 0 
0d20 : 0a __ __ ASL
0d21 : 85 1b __ STA ACCU + 0 
0d23 : bd 01 1a LDA $1a01,x ; (b_a_hi[0] + 1)
0d26 : 85 59 __ STA T8 + 1 
0d28 : 2a __ __ ROL
0d29 : 06 1b __ ASL ACCU + 0 
0d2b : 2a __ __ ROL
0d2c : 85 1c __ STA ACCU + 1 
0d2e : 18 __ __ CLC
0d2f : a5 1b __ LDA ACCU + 0 
0d31 : 65 58 __ ADC T8 + 0 
0d33 : 85 47 __ STA T1 + 0 
0d35 : a5 1c __ LDA ACCU + 1 
0d37 : 65 59 __ ADC T8 + 1 
0d39 : 06 47 __ ASL T1 + 0 
0d3b : 2a __ __ ROL
0d3c : 06 47 __ ASL T1 + 0 
0d3e : 2a __ __ ROL
0d3f : 06 47 __ ASL T1 + 0 
0d41 : 2a __ __ ROL
0d42 : 85 48 __ STA T1 + 1 
0d44 : 18 __ __ CLC
0d45 : a5 47 __ LDA T1 + 0 
0d47 : 65 43 __ ADC T0 + 0 
0d49 : 85 47 __ STA T1 + 0 
0d4b : 85 4b __ STA T2 + 0 
0d4d : ad fc 19 LDA $19fc ; (b_v_ci + 1)
0d50 : 85 44 __ STA T0 + 1 
0d52 : 65 48 __ ADC T1 + 1 
0d54 : 85 48 __ STA T1 + 1 
0d56 : 18 __ __ CLC
0d57 : 69 04 __ ADC #$04
0d59 : 85 4c __ STA T2 + 1 
0d5b : c9 e0 __ CMP #$e0
0d5d : 90 2c __ BCC $0d8b ; (main.s20 + 0)
.s94:
0d5f : c9 ff __ CMP #$ff
0d61 : d0 04 __ BNE $0d67 ; (main.s98 + 0)
.s97:
0d63 : a5 47 __ LDA T1 + 0 
0d65 : c9 40 __ CMP #$40
.s98:
0d67 : b0 22 __ BCS $0d8b ; (main.s20 + 0)
.s95:
0d69 : b1 5e __ LDA (T12 + 0),y 
0d6b : 85 5c __ STA T11 + 0 
0d6d : 4a __ __ LSR
0d6e : 90 1b __ BCC $0d8b ; (main.s20 + 0)
.s96:
0d70 : a5 5c __ LDA T11 + 0 
0d72 : 29 fe __ AND #$fe
0d74 : 91 5e __ STA (T12 + 0),y 
0d76 : 18 __ __ CLC
0d77 : a5 5f __ LDA T12 + 1 
0d79 : 65 4c __ ADC T2 + 1 
0d7b : 85 4c __ STA T2 + 1 
0d7d : a5 53 __ LDA T4 + 0 
0d7f : a4 5e __ LDY T12 + 0 
0d81 : 91 4b __ STA (T2 + 0),y 
0d83 : a5 5c __ LDA T11 + 0 
0d85 : a0 01 __ LDY #$01
0d87 : 91 5e __ STA (T12 + 0),y 
0d89 : d0 0d __ BNE $0d98 ; (main.s21 + 0)
.s20:
0d8b : 18 __ __ CLC
0d8c : a5 5f __ LDA T12 + 1 
0d8e : 65 4c __ ADC T2 + 1 
0d90 : 85 4c __ STA T2 + 1 
0d92 : a5 53 __ LDA T4 + 0 
0d94 : a4 5e __ LDY T12 + 0 
0d96 : 91 4b __ STA (T2 + 0),y 
.s21:
0d98 : 18 __ __ CLC
0d99 : a5 48 __ LDA T1 + 1 
0d9b : 69 d8 __ ADC #$d8
0d9d : 85 48 __ STA T1 + 1 
0d9f : c9 e0 __ CMP #$e0
0da1 : 90 2d __ BCC $0dd0 ; (main.s22 + 0)
.s89:
0da3 : c9 ff __ CMP #$ff
0da5 : d0 04 __ BNE $0dab ; (main.s93 + 0)
.s92:
0da7 : a5 47 __ LDA T1 + 0 
0da9 : c9 40 __ CMP #$40
.s93:
0dab : b0 23 __ BCS $0dd0 ; (main.s22 + 0)
.s90:
0dad : a0 01 __ LDY #$01
0daf : b1 5e __ LDA (T12 + 0),y 
0db1 : 85 5b __ STA T10 + 0 
0db3 : 4a __ __ LSR
0db4 : 90 1a __ BCC $0dd0 ; (main.s22 + 0)
.s91:
0db6 : a5 5b __ LDA T10 + 0 
0db8 : 29 fe __ AND #$fe
0dba : 91 5e __ STA (T12 + 0),y 
0dbc : 18 __ __ CLC
0dbd : a5 5f __ LDA T12 + 1 
0dbf : 65 48 __ ADC T1 + 1 
0dc1 : 85 48 __ STA T1 + 1 
0dc3 : 98 __ __ TYA
0dc4 : a4 5e __ LDY T12 + 0 
0dc6 : 91 47 __ STA (T1 + 0),y 
0dc8 : a5 5b __ LDA T10 + 0 
0dca : a0 01 __ LDY #$01
0dcc : 91 5e __ STA (T12 + 0),y 
0dce : d0 0d __ BNE $0ddd ; (main.s23 + 0)
.s22:
0dd0 : 18 __ __ CLC
0dd1 : a5 5f __ LDA T12 + 1 
0dd3 : 65 48 __ ADC T1 + 1 
0dd5 : 85 48 __ STA T1 + 1 
0dd7 : a9 01 __ LDA #$01
0dd9 : a4 5e __ LDY T12 + 0 
0ddb : 91 47 __ STA (T1 + 0),y 
.s23:
0ddd : 86 5a __ STX T9 + 0 
0ddf : bd 50 1b LDA $1b50,x ; (b_a_di[0] + 0)
0de2 : 18 __ __ CLC
0de3 : 65 53 __ ADC T4 + 0 
0de5 : 85 47 __ STA T1 + 0 
0de7 : 9d 00 1b STA $1b00,x ; (b_a_chi[0] + 0)
0dea : bd 51 1b LDA $1b51,x ; (b_a_di[0] + 1)
0ded : 65 54 __ ADC T4 + 1 
0def : 9d 01 1b STA $1b01,x ; (b_a_chi[0] + 1)
0df2 : a8 __ __ TAY
0df3 : 10 04 __ BPL $0df9 ; (main.s28 + 0)
.s25:
0df5 : a9 00 __ LDA #$00
0df7 : f0 0f __ BEQ $0e08 ; (main.s26 + 0)
.s28:
0df9 : d0 0b __ BNE $0e06 ; (main.s24 + 0)
.s27:
0dfb : a9 5a __ LDA #$5a
0dfd : c5 47 __ CMP T1 + 0 
0dff : a9 00 __ LDA #$00
0e01 : 2a __ __ ROL
0e02 : 49 01 __ EOR #$01
0e04 : 90 02 __ BCC $0e08 ; (main.s26 + 0)
.s24:
0e06 : a9 01 __ LDA #$01
.s26:
0e08 : 49 ff __ EOR #$ff
0e0a : c9 ff __ CMP #$ff
0e0c : f0 0e __ BEQ $0e1c ; (main.s29 + 0)
.s88:
0e0e : 38 __ __ SEC
0e0f : a5 47 __ LDA T1 + 0 
0e11 : e9 3a __ SBC #$3a
0e13 : 9d 00 1b STA $1b00,x ; (b_a_chi[0] + 0)
0e16 : 98 __ __ TYA
0e17 : e9 00 __ SBC #$00
0e19 : 9d 01 1b STA $1b01,x ; (b_a_chi[0] + 1)
.s29:
0e1c : 38 __ __ SEC
0e1d : a5 58 __ LDA T8 + 0 
0e1f : e9 01 __ SBC #$01
0e21 : 8d f0 1a STA $1af0 ; (b_v_bi + 0)
0e24 : a5 59 __ LDA T8 + 1 
0e26 : e9 00 __ SBC #$00
0e28 : 8d f1 1a STA $1af1 ; (b_v_bi + 1)
0e2b : 10 04 __ BPL $0e31 ; (main.s31 + 0)
.s30:
0e2d : a9 01 __ LDA #$01
0e2f : d0 02 __ BNE $0e33 ; (main.s32 + 0)
.s31:
0e31 : a9 00 __ LDA #$00
.s32:
0e33 : 49 ff __ EOR #$ff
0e35 : c9 ff __ CMP #$ff
0e37 : f0 0a __ BEQ $0e43 ; (main.s33 + 0)
.s87:
0e39 : a9 18 __ LDA #$18
0e3b : 8d f0 1a STA $1af0 ; (b_v_bi + 0)
0e3e : a9 00 __ LDA #$00
0e40 : 8d f1 1a STA $1af1 ; (b_v_bi + 1)
.s33:
0e43 : ad f0 1a LDA $1af0 ; (b_v_bi + 0)
0e46 : 85 4b __ STA T2 + 0 
0e48 : 0a __ __ ASL
0e49 : 85 1b __ STA ACCU + 0 
0e4b : ad f1 1a LDA $1af1 ; (b_v_bi + 1)
0e4e : 85 4c __ STA T2 + 1 
0e50 : 2a __ __ ROL
0e51 : 06 1b __ ASL ACCU + 0 
0e53 : 2a __ __ ROL
0e54 : a8 __ __ TAY
0e55 : 18 __ __ CLC
0e56 : a5 1b __ LDA ACCU + 0 
0e58 : 65 4b __ ADC T2 + 0 
0e5a : 85 47 __ STA T1 + 0 
0e5c : 98 __ __ TYA
0e5d : 65 4c __ ADC T2 + 1 
0e5f : 06 47 __ ASL T1 + 0 
0e61 : 2a __ __ ROL
0e62 : 06 47 __ ASL T1 + 0 
0e64 : 2a __ __ ROL
0e65 : 06 47 __ ASL T1 + 0 
0e67 : 2a __ __ ROL
0e68 : 18 __ __ CLC
0e69 : 69 d8 __ ADC #$d8
0e6b : a8 __ __ TAY
0e6c : 18 __ __ CLC
0e6d : a5 47 __ LDA T1 + 0 
0e6f : 65 43 __ ADC T0 + 0 
0e71 : 85 47 __ STA T1 + 0 
0e73 : 98 __ __ TYA
0e74 : 65 44 __ ADC T0 + 1 
0e76 : 85 48 __ STA T1 + 1 
0e78 : c9 e0 __ CMP #$e0
0e7a : 90 2e __ BCC $0eaa ; (main.s34 + 0)
.s82:
0e7c : c9 ff __ CMP #$ff
0e7e : d0 04 __ BNE $0e84 ; (main.s86 + 0)
.s85:
0e80 : a5 47 __ LDA T1 + 0 
0e82 : c9 40 __ CMP #$40
.s86:
0e84 : b0 24 __ BCS $0eaa ; (main.s34 + 0)
.s83:
0e86 : a0 01 __ LDY #$01
0e88 : b1 5e __ LDA (T12 + 0),y 
0e8a : 85 5c __ STA T11 + 0 
0e8c : 4a __ __ LSR
0e8d : 90 1b __ BCC $0eaa ; (main.s34 + 0)
.s84:
0e8f : a5 5c __ LDA T11 + 0 
0e91 : 29 fe __ AND #$fe
0e93 : 91 5e __ STA (T12 + 0),y 
0e95 : 18 __ __ CLC
0e96 : a5 5f __ LDA T12 + 1 
0e98 : 65 48 __ ADC T1 + 1 
0e9a : 85 48 __ STA T1 + 1 
0e9c : a9 0d __ LDA #$0d
0e9e : a4 5e __ LDY T12 + 0 
0ea0 : 91 47 __ STA (T1 + 0),y 
0ea2 : a5 5c __ LDA T11 + 0 
0ea4 : a0 01 __ LDY #$01
0ea6 : 91 5e __ STA (T12 + 0),y 
0ea8 : d0 0d __ BNE $0eb7 ; (main.s35 + 0)
.s34:
0eaa : 18 __ __ CLC
0eab : a5 5f __ LDA T12 + 1 
0ead : 65 48 __ ADC T1 + 1 
0eaf : 85 48 __ STA T1 + 1 
0eb1 : a9 0d __ LDA #$0d
0eb3 : a4 5e __ LDY T12 + 0 
0eb5 : 91 47 __ STA (T1 + 0),y 
.s35:
0eb7 : 38 __ __ SEC
0eb8 : a5 4b __ LDA T2 + 0 
0eba : e9 01 __ SBC #$01
0ebc : 8d f0 1a STA $1af0 ; (b_v_bi + 0)
0ebf : a5 4c __ LDA T2 + 1 
0ec1 : e9 00 __ SBC #$00
0ec3 : 8d f1 1a STA $1af1 ; (b_v_bi + 1)
0ec6 : 10 04 __ BPL $0ecc ; (main.s37 + 0)
.s36:
0ec8 : a9 01 __ LDA #$01
0eca : d0 02 __ BNE $0ece ; (main.s38 + 0)
.s37:
0ecc : a9 00 __ LDA #$00
.s38:
0ece : 49 ff __ EOR #$ff
0ed0 : c9 ff __ CMP #$ff
0ed2 : f0 0a __ BEQ $0ede ; (main.s39 + 0)
.s81:
0ed4 : a9 18 __ LDA #$18
0ed6 : 8d f0 1a STA $1af0 ; (b_v_bi + 0)
0ed9 : a9 00 __ LDA #$00
0edb : 8d f1 1a STA $1af1 ; (b_v_bi + 1)
.s39:
0ede : ad f0 1a LDA $1af0 ; (b_v_bi + 0)
0ee1 : 0a __ __ ASL
0ee2 : 85 07 __ STA WORK + 4 
0ee4 : ad f1 1a LDA $1af1 ; (b_v_bi + 1)
0ee7 : 2a __ __ ROL
0ee8 : 06 07 __ ASL WORK + 4 
0eea : 2a __ __ ROL
0eeb : a8 __ __ TAY
0eec : 18 __ __ CLC
0eed : a5 07 __ LDA WORK + 4 
0eef : 6d f0 1a ADC $1af0 ; (b_v_bi + 0)
0ef2 : 85 1b __ STA ACCU + 0 
0ef4 : 98 __ __ TYA
0ef5 : 6d f1 1a ADC $1af1 ; (b_v_bi + 1)
0ef8 : 06 1b __ ASL ACCU + 0 
0efa : 2a __ __ ROL
0efb : 06 1b __ ASL ACCU + 0 
0efd : 2a __ __ ROL
0efe : 06 1b __ ASL ACCU + 0 
0f00 : 2a __ __ ROL
0f01 : 18 __ __ CLC
0f02 : 69 d8 __ ADC #$d8
0f04 : a8 __ __ TAY
0f05 : 18 __ __ CLC
0f06 : a5 1b __ LDA ACCU + 0 
0f08 : 65 43 __ ADC T0 + 0 
0f0a : 85 47 __ STA T1 + 0 
0f0c : 98 __ __ TYA
0f0d : 65 44 __ ADC T0 + 1 
0f0f : 85 48 __ STA T1 + 1 
0f11 : c9 e0 __ CMP #$e0
0f13 : 90 2e __ BCC $0f43 ; (main.s40 + 0)
.s76:
0f15 : c9 ff __ CMP #$ff
0f17 : d0 04 __ BNE $0f1d ; (main.s80 + 0)
.s79:
0f19 : a5 47 __ LDA T1 + 0 
0f1b : c9 40 __ CMP #$40
.s80:
0f1d : b0 24 __ BCS $0f43 ; (main.s40 + 0)
.s77:
0f1f : a0 01 __ LDY #$01
0f21 : b1 5e __ LDA (T12 + 0),y 
0f23 : 85 5b __ STA T10 + 0 
0f25 : 4a __ __ LSR
0f26 : 90 1b __ BCC $0f43 ; (main.s40 + 0)
.s78:
0f28 : a5 5b __ LDA T10 + 0 
0f2a : 29 fe __ AND #$fe
0f2c : 91 5e __ STA (T12 + 0),y 
0f2e : 18 __ __ CLC
0f2f : a5 5f __ LDA T12 + 1 
0f31 : 65 48 __ ADC T1 + 1 
0f33 : 85 48 __ STA T1 + 1 
0f35 : a9 05 __ LDA #$05
0f37 : a4 5e __ LDY T12 + 0 
0f39 : 91 47 __ STA (T1 + 0),y 
0f3b : a5 5b __ LDA T10 + 0 
0f3d : a0 01 __ LDY #$01
0f3f : 91 5e __ STA (T12 + 0),y 
0f41 : d0 0d __ BNE $0f50 ; (main.s41 + 0)
.s40:
0f43 : 18 __ __ CLC
0f44 : a5 5f __ LDA T12 + 1 
0f46 : 65 48 __ ADC T1 + 1 
0f48 : 85 48 __ STA T1 + 1 
0f4a : a9 05 __ LDA #$05
0f4c : a4 5e __ LDY T12 + 0 
0f4e : 91 47 __ STA (T1 + 0),y 
.s41:
0f50 : 86 5b __ STX T10 + 0 
0f52 : 18 __ __ CLC
0f53 : a5 58 __ LDA T8 + 0 
0f55 : 69 01 __ ADC #$01
0f57 : 9d 00 1a STA $1a00,x ; (b_a_hi[0] + 0)
0f5a : a5 59 __ LDA T8 + 1 
0f5c : 69 00 __ ADC #$00
0f5e : 9d 01 1a STA $1a01,x ; (b_a_hi[0] + 1)
0f61 : bd a0 1a LDA $1aa0,x ; (b_a_ei[0] + 0)
0f64 : 85 5c __ STA T11 + 0 
0f66 : 0a __ __ ASL
0f67 : 85 1b __ STA ACCU + 0 
0f69 : bd a1 1a LDA $1aa1,x ; (b_a_ei[0] + 1)
0f6c : 85 5d __ STA T11 + 1 
0f6e : 2a __ __ ROL
0f6f : 06 1b __ ASL ACCU + 0 
0f71 : 2a __ __ ROL
0f72 : aa __ __ TAX
0f73 : 18 __ __ CLC
0f74 : a5 1b __ LDA ACCU + 0 
0f76 : 65 5c __ ADC T11 + 0 
0f78 : 85 47 __ STA T1 + 0 
0f7a : 8a __ __ TXA
0f7b : 65 5d __ ADC T11 + 1 
0f7d : 06 47 __ ASL T1 + 0 
0f7f : 2a __ __ ROL
0f80 : 06 47 __ ASL T1 + 0 
0f82 : 2a __ __ ROL
0f83 : 06 47 __ ASL T1 + 0 
0f85 : 2a __ __ ROL
0f86 : 18 __ __ CLC
0f87 : 69 04 __ ADC #$04
0f89 : aa __ __ TAX
0f8a : 18 __ __ CLC
0f8b : a5 47 __ LDA T1 + 0 
0f8d : 65 43 __ ADC T0 + 0 
0f8f : 85 47 __ STA T1 + 0 
0f91 : 8a __ __ TXA
0f92 : 65 44 __ ADC T0 + 1 
0f94 : 85 48 __ STA T1 + 1 
0f96 : c9 e0 __ CMP #$e0
0f98 : 90 2b __ BCC $0fc5 ; (main.s42 + 0)
.s71:
0f9a : c9 ff __ CMP #$ff
0f9c : d0 04 __ BNE $0fa2 ; (main.s75 + 0)
.s74:
0f9e : a5 47 __ LDA T1 + 0 
0fa0 : c9 40 __ CMP #$40
.s75:
0fa2 : b0 21 __ BCS $0fc5 ; (main.s42 + 0)
.s72:
0fa4 : a0 01 __ LDY #$01
0fa6 : b1 5e __ LDA (T12 + 0),y 
0fa8 : aa __ __ TAX
0fa9 : 4a __ __ LSR
0faa : 90 19 __ BCC $0fc5 ; (main.s42 + 0)
.s73:
0fac : 8a __ __ TXA
0fad : 29 fe __ AND #$fe
0faf : 91 5e __ STA (T12 + 0),y 
0fb1 : 18 __ __ CLC
0fb2 : a5 5f __ LDA T12 + 1 
0fb4 : 65 48 __ ADC T1 + 1 
0fb6 : 85 48 __ STA T1 + 1 
0fb8 : a9 20 __ LDA #$20
0fba : a4 5e __ LDY T12 + 0 
0fbc : 91 47 __ STA (T1 + 0),y 
0fbe : 8a __ __ TXA
0fbf : a0 01 __ LDY #$01
0fc1 : 91 5e __ STA (T12 + 0),y 
0fc3 : d0 0d __ BNE $0fd2 ; (main.s43 + 0)
.s42:
0fc5 : 18 __ __ CLC
0fc6 : a5 5f __ LDA T12 + 1 
0fc8 : 65 48 __ ADC T1 + 1 
0fca : 85 48 __ STA T1 + 1 
0fcc : a9 20 __ LDA #$20
0fce : a4 5e __ LDY T12 + 0 
0fd0 : 91 47 __ STA (T1 + 0),y 
.s43:
0fd2 : 18 __ __ CLC
0fd3 : a5 5c __ LDA T11 + 0 
0fd5 : 69 01 __ ADC #$01
0fd7 : a6 4f __ LDX T3 + 0 
0fd9 : 9d a0 1a STA $1aa0,x ; (b_a_ei[0] + 0)
0fdc : a5 5d __ LDA T11 + 1 
0fde : 69 00 __ ADC #$00
0fe0 : 9d a1 1a STA $1aa1,x ; (b_a_ei[0] + 1)
0fe3 : a5 59 __ LDA T8 + 1 
0fe5 : 10 04 __ BPL $0feb ; (main.s48 + 0)
.s45:
0fe7 : a9 00 __ LDA #$00
0fe9 : f0 0f __ BEQ $0ffa ; (main.s46 + 0)
.s48:
0feb : d0 0b __ BNE $0ff8 ; (main.s44 + 0)
.s47:
0fed : a9 17 __ LDA #$17
0fef : c5 58 __ CMP T8 + 0 
0ff1 : a9 00 __ LDA #$00
0ff3 : 2a __ __ ROL
0ff4 : 49 01 __ EOR #$01
0ff6 : 90 02 __ BCC $0ffa ; (main.s46 + 0)
.s44:
0ff8 : a9 01 __ LDA #$01
.s46:
0ffa : 49 ff __ EOR #$ff
0ffc : c9 ff __ CMP #$ff
0ffe : d0 5d __ BNE $105d ; (main.s60 + 0)
.s49:
1000 : a5 5d __ LDA T11 + 1 
1002 : 10 04 __ BPL $1008 ; (main.s54 + 0)
.s51:
1004 : a9 00 __ LDA #$00
1006 : f0 0f __ BEQ $1017 ; (main.s52 + 0)
.s54:
1008 : d0 0b __ BNE $1015 ; (main.s50 + 0)
.s53:
100a : a9 17 __ LDA #$17
100c : c5 5c __ CMP T11 + 0 
100e : a9 00 __ LDA #$00
1010 : 2a __ __ ROL
1011 : 49 01 __ EOR #$01
1013 : 90 02 __ BCC $1017 ; (main.s52 + 0)
.s50:
1015 : a9 01 __ LDA #$01
.s52:
1017 : 49 ff __ EOR #$ff
1019 : c9 ff __ CMP #$ff
101b : f0 0a __ BEQ $1027 ; (main.s55 + 0)
.s59:
101d : a9 00 __ LDA #$00
101f : a6 5b __ LDX T10 + 0 
1021 : 9d a0 1a STA $1aa0,x ; (b_a_ei[0] + 0)
1024 : 9d a1 1a STA $1aa1,x ; (b_a_ei[0] + 1)
.s55:
1027 : 18 __ __ CLC
1028 : a5 43 __ LDA T0 + 0 
102a : 69 01 __ ADC #$01
102c : 8d fb 19 STA $19fb ; (b_v_ci + 0)
102f : a5 44 __ LDA T0 + 1 
1031 : 69 00 __ ADC #$00
1033 : 8d fc 19 STA $19fc ; (b_v_ci + 1)
1036 : a5 45 __ LDA T0 + 2 
1038 : 69 00 __ ADC #$00
103a : 8d fd 19 STA $19fd ; (b_v_ci + 2)
103d : a5 46 __ LDA T0 + 3 
103f : 69 00 __ ADC #$00
1041 : 8d fe 19 STA $19fe ; (b_v_ci + 3)
1044 : f0 03 __ BEQ $1049 ; (main.s56 + 0)
1046 : 4c d1 0c JMP $0cd1 ; (main.l18 + 0)
.s56:
1049 : ad fd 19 LDA $19fd ; (b_v_ci + 2)
104c : d0 f8 __ BNE $1046 ; (main.s55 + 31)
.s57:
104e : ad fc 19 LDA $19fc ; (b_v_ci + 1)
1051 : d0 f3 __ BNE $1046 ; (main.s55 + 31)
.s58:
1053 : a9 27 __ LDA #$27
1055 : cd fb 19 CMP $19fb ; (b_v_ci + 0)
1058 : 90 ec __ BCC $1046 ; (main.s55 + 31)
105a : 4c f4 0c JMP $0cf4 ; (main.l19 + 0)
.s60:
105d : a9 00 __ LDA #$00
105f : 85 06 __ STA WORK + 3 
1061 : 9d 00 1a STA $1a00,x ; (b_a_hi[0] + 0)
1064 : 9d 01 1a STA $1a01,x ; (b_a_hi[0] + 1)
1067 : ad af 19 LDA $19af ; (b_rndSeed + 0)
106a : 85 1b __ STA ACCU + 0 
106c : ad b0 19 LDA $19b0 ; (b_rndSeed + 1)
106f : 85 1c __ STA ACCU + 1 
1071 : ad b1 19 LDA $19b1 ; (b_rndSeed + 2)
1074 : 85 1d __ STA ACCU + 2 
1076 : ad b2 19 LDA $19b2 ; (b_rndSeed + 3)
1079 : 85 1e __ STA ACCU + 3 
107b : a9 cd __ LDA #$cd
107d : 85 03 __ STA WORK + 0 
107f : a9 01 __ LDA #$01
1081 : 85 05 __ STA WORK + 2 
1083 : a9 0d __ LDA #$0d
1085 : 85 04 __ STA WORK + 1 
1087 : 20 b8 18 JSR $18b8 ; (mul32 + 0)
108a : 18 __ __ CLC
108b : a5 07 __ LDA WORK + 4 
108d : 69 39 __ ADC #$39
108f : 85 47 __ STA T1 + 0 
1091 : a5 08 __ LDA WORK + 5 
1093 : 69 30 __ ADC #$30
1095 : 85 48 __ STA T1 + 1 
1097 : 85 1b __ STA ACCU + 0 
1099 : a5 09 __ LDA WORK + 6 
109b : 69 00 __ ADC #$00
109d : 85 49 __ STA T1 + 2 
109f : 85 1c __ STA ACCU + 1 
10a1 : a5 0a __ LDA WORK + 7 
10a3 : 69 00 __ ADC #$00
10a5 : 85 4a __ STA T1 + 3 
10a7 : 85 1d __ STA ACCU + 2 
10a9 : a9 00 __ LDA #$00
10ab : 85 1e __ STA ACCU + 3 
10ad : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
10b0 : a9 00 __ LDA #$00
10b2 : 85 03 __ STA WORK + 0 
10b4 : 85 04 __ STA WORK + 1 
10b6 : a9 80 __ LDA #$80
10b8 : 85 05 __ STA WORK + 2 
10ba : a9 4b __ LDA #$4b
10bc : 85 06 __ STA WORK + 3 
10be : 20 f5 15 JSR $15f5 ; (freg + 20)
10c1 : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
10c4 : a9 00 __ LDA #$00
10c6 : 85 03 __ STA WORK + 0 
10c8 : 85 04 __ STA WORK + 1 
10ca : a9 68 __ LDA #$68
10cc : 85 05 __ STA WORK + 2 
10ce : a9 42 __ LDA #$42
10d0 : 85 06 __ STA WORK + 3 
10d2 : 20 f5 15 JSR $15f5 ; (freg + 20)
10d5 : 20 26 16 JSR $1626 ; (crt_fmul + 0)
10d8 : a5 1b __ LDA ACCU + 0 
10da : 85 4b __ STA T2 + 0 
10dc : a5 1c __ LDA ACCU + 1 
10de : 85 4c __ STA T2 + 1 
10e0 : a5 1d __ LDA ACCU + 2 
10e2 : 85 4d __ STA T2 + 2 
10e4 : a5 1e __ LDA ACCU + 3 
10e6 : 85 4e __ STA T2 + 3 
10e8 : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
10eb : a5 1b __ LDA ACCU + 0 
10ed : 85 4f __ STA T3 + 0 
10ef : a5 1c __ LDA ACCU + 1 
10f1 : 85 50 __ STA T3 + 1 
10f3 : a5 4e __ LDA T2 + 3 
10f5 : 29 7f __ AND #$7f
10f7 : 05 4d __ ORA T2 + 2 
10f9 : 05 4c __ ORA T2 + 1 
10fb : 05 4b __ ORA T2 + 0 
10fd : f0 39 __ BEQ $1138 ; (main.s61 + 0)
.s70:
10ff : 24 4e __ BIT T2 + 3 
1101 : 10 35 __ BPL $1138 ; (main.s61 + 0)
.s68:
1103 : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
1106 : a5 1b __ LDA ACCU + 0 
1108 : 85 03 __ STA WORK + 0 
110a : a5 1c __ LDA ACCU + 1 
110c : 85 04 __ STA WORK + 1 
110e : a5 1d __ LDA ACCU + 2 
1110 : 85 05 __ STA WORK + 2 
1112 : a5 1e __ LDA ACCU + 3 
1114 : 85 06 __ STA WORK + 3 
1116 : a5 4b __ LDA T2 + 0 
1118 : 85 1b __ STA ACCU + 0 
111a : a5 4c __ LDA T2 + 1 
111c : 85 1c __ STA ACCU + 1 
111e : a5 4d __ LDA T2 + 2 
1120 : 85 1d __ STA ACCU + 2 
1122 : a5 4e __ LDA T2 + 3 
1124 : 85 1e __ STA ACCU + 3 
1126 : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
1129 : f0 0d __ BEQ $1138 ; (main.s61 + 0)
.s69:
112b : 18 __ __ CLC
112c : a5 4f __ LDA T3 + 0 
112e : 69 ff __ ADC #$ff
1130 : a8 __ __ TAY
1131 : a5 50 __ LDA T3 + 1 
1133 : 69 ff __ ADC #$ff
1135 : 4c 3c 11 JMP $113c ; (main.s62 + 0)
.s61:
1138 : a5 50 __ LDA T3 + 1 
113a : a4 4f __ LDY T3 + 0 
.s62:
113c : aa __ __ TAX
113d : 98 __ __ TYA
113e : 18 __ __ CLC
113f : 69 21 __ ADC #$21
1141 : a4 57 __ LDY T6 + 0 
1143 : 99 00 1b STA $1b00,y ; (b_a_chi[0] + 0)
1146 : 8a __ __ TXA
1147 : 69 00 __ ADC #$00
1149 : 99 01 1b STA $1b01,y ; (b_a_chi[0] + 1)
114c : a5 47 __ LDA T1 + 0 
114e : 85 1b __ STA ACCU + 0 
1150 : a5 48 __ LDA T1 + 1 
1152 : 85 1c __ STA ACCU + 1 
1154 : a5 49 __ LDA T1 + 2 
1156 : 85 1d __ STA ACCU + 2 
1158 : a5 4a __ LDA T1 + 3 
115a : 85 1e __ STA ACCU + 3 
115c : a9 cd __ LDA #$cd
115e : 85 03 __ STA WORK + 0 
1160 : a9 00 __ LDA #$00
1162 : 85 06 __ STA WORK + 3 
1164 : a9 0d __ LDA #$0d
1166 : 85 04 __ STA WORK + 1 
1168 : a9 01 __ LDA #$01
116a : 85 05 __ STA WORK + 2 
116c : 20 b8 18 JSR $18b8 ; (mul32 + 0)
116f : 18 __ __ CLC
1170 : a5 07 __ LDA WORK + 4 
1172 : 69 39 __ ADC #$39
1174 : 8d af 19 STA $19af ; (b_rndSeed + 0)
1177 : a5 08 __ LDA WORK + 5 
1179 : 69 30 __ ADC #$30
117b : 8d b0 19 STA $19b0 ; (b_rndSeed + 1)
117e : 85 1b __ STA ACCU + 0 
1180 : a5 09 __ LDA WORK + 6 
1182 : 69 00 __ ADC #$00
1184 : 8d b1 19 STA $19b1 ; (b_rndSeed + 2)
1187 : 85 1c __ STA ACCU + 1 
1189 : a5 0a __ LDA WORK + 7 
118b : 69 00 __ ADC #$00
118d : 8d b2 19 STA $19b2 ; (b_rndSeed + 3)
1190 : 85 1d __ STA ACCU + 2 
1192 : a9 00 __ LDA #$00
1194 : 85 1e __ STA ACCU + 3 
1196 : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
1199 : a9 00 __ LDA #$00
119b : 85 03 __ STA WORK + 0 
119d : 85 04 __ STA WORK + 1 
119f : a9 80 __ LDA #$80
11a1 : 85 05 __ STA WORK + 2 
11a3 : a9 4b __ LDA #$4b
11a5 : 85 06 __ STA WORK + 3 
11a7 : 20 f5 15 JSR $15f5 ; (freg + 20)
11aa : 20 ee 16 JSR $16ee ; (crt_fdiv + 0)
11ad : a9 00 __ LDA #$00
11af : 85 03 __ STA WORK + 0 
11b1 : 85 04 __ STA WORK + 1 
11b3 : a9 a0 __ LDA #$a0
11b5 : 85 05 __ STA WORK + 2 
11b7 : a9 40 __ LDA #$40
11b9 : 85 06 __ STA WORK + 3 
11bb : 20 f5 15 JSR $15f5 ; (freg + 20)
11be : 20 26 16 JSR $1626 ; (crt_fmul + 0)
11c1 : a5 1b __ LDA ACCU + 0 
11c3 : 85 47 __ STA T1 + 0 
11c5 : a5 1c __ LDA ACCU + 1 
11c7 : 85 48 __ STA T1 + 1 
11c9 : a5 1d __ LDA ACCU + 2 
11cb : 85 49 __ STA T1 + 2 
11cd : a5 1e __ LDA ACCU + 3 
11cf : 85 4a __ STA T1 + 3 
11d1 : 20 9c 17 JSR $179c ; (f32_to_i32 + 0)
11d4 : a5 1b __ LDA ACCU + 0 
11d6 : 85 4b __ STA T2 + 0 
11d8 : a5 1c __ LDA ACCU + 1 
11da : 85 4c __ STA T2 + 1 
11dc : a5 4a __ LDA T1 + 3 
11de : 29 7f __ AND #$7f
11e0 : 05 49 __ ORA T1 + 2 
11e2 : 05 48 __ ORA T1 + 1 
11e4 : 05 47 __ ORA T1 + 0 
11e6 : f0 39 __ BEQ $1221 ; (main.s63 + 0)
.s67:
11e8 : 24 4a __ BIT T1 + 3 
11ea : 10 35 __ BPL $1221 ; (main.s63 + 0)
.s65:
11ec : 20 fb 17 JSR $17fb ; (sint32_to_float + 0)
11ef : a5 1b __ LDA ACCU + 0 
11f1 : 85 03 __ STA WORK + 0 
11f3 : a5 1c __ LDA ACCU + 1 
11f5 : 85 04 __ STA WORK + 1 
11f7 : a5 1d __ LDA ACCU + 2 
11f9 : 85 05 __ STA WORK + 2 
11fb : a5 1e __ LDA ACCU + 3 
11fd : 85 06 __ STA WORK + 3 
11ff : a5 47 __ LDA T1 + 0 
1201 : 85 1b __ STA ACCU + 0 
1203 : a5 48 __ LDA T1 + 1 
1205 : 85 1c __ STA ACCU + 1 
1207 : a5 49 __ LDA T1 + 2 
1209 : 85 1d __ STA ACCU + 2 
120b : a5 4a __ LDA T1 + 3 
120d : 85 1e __ STA ACCU + 3 
120f : 20 69 18 JSR $1869 ; (crt_fcmp + 0)
1212 : f0 0d __ BEQ $1221 ; (main.s63 + 0)
.s66:
1214 : 18 __ __ CLC
1215 : a5 4b __ LDA T2 + 0 
1217 : 69 ff __ ADC #$ff
1219 : a8 __ __ TAY
121a : a5 4c __ LDA T2 + 1 
121c : 69 ff __ ADC #$ff
121e : 4c 25 12 JMP $1225 ; (main.s64 + 0)
.s63:
1221 : a5 4c __ LDA T2 + 1 
1223 : a4 4b __ LDY T2 + 0 
.s64:
1225 : aa __ __ TAX
1226 : 98 __ __ TYA
1227 : 18 __ __ CLC
1228 : 69 01 __ ADC #$01
122a : a4 5a __ LDY T9 + 0 
122c : 99 50 1b STA $1b50,y ; (b_a_di[0] + 0)
122f : 8a __ __ TXA
1230 : 69 00 __ ADC #$00
1232 : 99 51 1b STA $1b51,y ; (b_a_di[0] + 1)
1235 : 4c 00 10 JMP $1000 ; (main.s49 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1238 : ad 25 19 LDA $1925 ; (b_mem + 0)
123b : 85 43 __ STA T1 + 0 
123d : 85 45 __ STA T2 + 0 
123f : 85 1f __ STA ADDR + 0 
1241 : ad 26 19 LDA $1926 ; (b_mem + 1)
1244 : 85 44 __ STA T1 + 1 
1246 : 18 __ __ CLC
1247 : 69 dd __ ADC #$dd
1249 : 85 20 __ STA ADDR + 1 
124b : a9 03 __ LDA #$03
124d : a0 00 __ LDY #$00
124f : 91 1f __ STA (ADDR + 0),y 
1251 : 18 __ __ CLC
1252 : a5 44 __ LDA T1 + 1 
1254 : 69 d0 __ ADC #$d0
1256 : 85 20 __ STA ADDR + 1 
1258 : a9 15 __ LDA #$15
125a : a0 18 __ LDY #$18
125c : 91 1f __ STA (ADDR + 0),y 
125e : 18 __ __ CLC
125f : a5 44 __ LDA T1 + 1 
1261 : 69 02 __ ADC #$02
1263 : 85 20 __ STA ADDR + 1 
1265 : a9 0e __ LDA #$0e
1267 : a0 86 __ LDY #$86
1269 : 91 1f __ STA (ADDR + 0),y 
126b : 18 __ __ CLC
126c : a5 44 __ LDA T1 + 1 
126e : 69 d8 __ ADC #$d8
1270 : 85 46 __ STA T2 + 1 
1272 : a9 00 __ LDA #$00
1274 : 85 47 __ STA T3 + 0 
1276 : 85 48 __ STA T3 + 1 
.l5:
1278 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
127b : 18 __ __ CLC
127c : a5 43 __ LDA T1 + 0 
127e : 65 1b __ ADC ACCU + 0 
1280 : 85 1b __ STA ACCU + 0 
1282 : a5 44 __ LDA T1 + 1 
1284 : 65 1c __ ADC ACCU + 1 
1286 : 18 __ __ CLC
1287 : 65 48 __ ADC T3 + 1 
1289 : 85 1c __ STA ACCU + 1 
128b : a9 20 __ LDA #$20
128d : a4 47 __ LDY T3 + 0 
128f : 91 1b __ STA (ACCU + 0),y 
1291 : a9 0e __ LDA #$0e
1293 : a0 00 __ LDY #$00
1295 : 91 45 __ STA (T2 + 0),y 
1297 : e6 45 __ INC T2 + 0 
1299 : d0 02 __ BNE $129d ; (b_init.s9 + 0)
.s8:
129b : e6 46 __ INC T2 + 1 
.s9:
129d : e6 47 __ INC T3 + 0 
129f : d0 02 __ BNE $12a3 ; (b_init.s11 + 0)
.s10:
12a1 : e6 48 __ INC T3 + 1 
.s11:
12a3 : a5 48 __ LDA T3 + 1 
12a5 : c9 03 __ CMP #$03
12a7 : d0 cf __ BNE $1278 ; (b_init.l5 + 0)
.s7:
12a9 : a5 47 __ LDA T3 + 0 
12ab : c9 e8 __ CMP #$e8
12ad : d0 c9 __ BNE $1278 ; (b_init.l5 + 0)
.s6:
12af : a5 43 __ LDA T1 + 0 
12b1 : 85 1f __ STA ADDR + 0 
12b3 : a5 44 __ LDA T1 + 1 
12b5 : 69 cf __ ADC #$cf
12b7 : 85 20 __ STA ADDR + 1 
12b9 : a9 0e __ LDA #$0e
12bb : a0 20 __ LDY #$20
12bd : 91 1f __ STA (ADDR + 0),y 
12bf : a9 06 __ LDA #$06
12c1 : c8 __ __ INY
12c2 : 91 1f __ STA (ADDR + 0),y 
12c4 : a9 00 __ LDA #$00
12c6 : a0 c6 __ LDY #$c6
12c8 : 91 43 __ STA (T1 + 0),y 
12ca : 8d 2b 19 STA $192b ; (b_gosubSP + 0)
12cd : 8d 2c 19 STA $192c ; (b_gosubSP + 1)
12d0 : 8d 29 19 STA $1929 ; (b_row + 0)
12d3 : 8d 2a 19 STA $192a ; (b_row + 1)
12d6 : 8d 27 19 STA $1927 ; (b_col + 0)
12d9 : 8d 28 19 STA $1928 ; (b_col + 1)
.s3:
12dc : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
12dd : ad 25 19 LDA $1925 ; (b_mem + 0)
12e0 : 85 1f __ STA ADDR + 0 
12e2 : ad 26 19 LDA $1926 ; (b_mem + 1)
12e5 : 18 __ __ CLC
12e6 : 69 dd __ ADC #$dd
12e8 : 85 20 __ STA ADDR + 1 
12ea : a0 00 __ LDY #$00
12ec : 84 1b __ STY ACCU + 0 
12ee : b1 1f __ LDA (ADDR + 0),y 
12f0 : 29 03 __ AND #$03
12f2 : 49 03 __ EOR #$03
12f4 : aa __ __ TAX
12f5 : 18 __ __ CLC
12f6 : a5 1f __ LDA ADDR + 0 
12f8 : 69 18 __ ADC #$18
12fa : 85 1f __ STA ADDR + 0 
12fc : ad 26 19 LDA $1926 ; (b_mem + 1)
12ff : 69 d0 __ ADC #$d0
1301 : 85 20 __ STA ADDR + 1 
1303 : b1 1f __ LDA (ADDR + 0),y 
1305 : 29 f0 __ AND #$f0
1307 : 4a __ __ LSR
1308 : 4a __ __ LSR
1309 : 1d 20 19 ORA $1920,x ; (__multab16384H + 0)
130c : 85 1c __ STA ACCU + 1 
.s3:
130e : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1273, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
130f : ad 2d 19 LDA $192d ; (tsb_inited + 0)
1312 : 0d 2e 19 ORA $192e ; (tsb_inited + 1)
1315 : d0 18 __ BNE $132f ; (tsb_init.s3 + 0)
.s5:
1317 : 85 0d __ STA P0 
1319 : 85 0e __ STA P1 
131b : 85 10 __ STA P3 
131d : a9 01 __ LDA #$01
131f : 85 0f __ STA P2 
1321 : 8d 2d 19 STA $192d ; (tsb_inited + 0)
1324 : a9 00 __ LDA #$00
1326 : 8d 2e 19 STA $192e ; (tsb_inited + 1)
1329 : 20 30 13 JSR $1330 ; (tsb_init_tables.s4 + 0)
132c : 4c 3e 13 JMP $133e ; (tsb_rot.s4 + 0)
.s3:
132f : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1261, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1330 : a2 00 __ LDX #$00
.l5:
1332 : bd 2f 19 LDA $192f,x ; (tab[0] + 0)
1335 : 9d b3 19 STA $19b3,x ; (tsb_sintab[0] + 0)
1338 : e8 __ __ INX
1339 : e0 40 __ CPX #$40
133b : d0 f5 __ BNE $1332 ; (tsb_init_tables.l5 + 0)
.s3:
133d : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
133e : a5 0d __ LDA P0 ; (angle + 0)
1340 : 29 07 __ AND #$07
1342 : 0a __ __ ASL
1343 : 0a __ __ ASL
1344 : 0a __ __ ASL
1345 : aa __ __ TAX
1346 : a9 00 __ LDA #$00
1348 : 85 1b __ STA ACCU + 0 
.l5:
134a : 8a __ __ TXA
134b : 65 1b __ ADC ACCU + 0 
134d : a8 __ __ TAY
134e : b9 6f 19 LDA $196f,y ; (tsb_rottab[0] + 0)
1351 : a4 1b __ LDY ACCU + 0 
1353 : c8 __ __ INY
1354 : 84 1b __ STY ACCU + 0 
1356 : 99 f2 19 STA $19f2,y ; (tsb_sintab[0] + 63)
1359 : c0 08 __ CPY #$08
135b : 90 ed __ BCC $134a ; (tsb_rot.l5 + 0)
.s3:
135d : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
135e : a5 13 __ LDA P6 ; (c + 0)
1360 : c9 93 __ CMP #$93
1362 : d0 03 __ BNE $1367 ; (b_putc.s5 + 0)
1364 : 4c f5 13 JMP $13f5 ; (b_putc.s14 + 0)
.s5:
1367 : c9 13 __ CMP #$13
1369 : d0 0d __ BNE $1378 ; (b_putc.s6 + 0)
.s13:
136b : a9 00 __ LDA #$00
136d : 8d 29 19 STA $1929 ; (b_row + 0)
1370 : 8d 2a 19 STA $192a ; (b_row + 1)
1373 : 8d 27 19 STA $1927 ; (b_col + 0)
1376 : f0 76 __ BEQ $13ee ; (b_putc.s17 + 0)
.s6:
1378 : c9 0d __ CMP #$0d
137a : f0 76 __ BEQ $13f2 ; (b_putc.s12 + 0)
.s7:
137c : ad 28 19 LDA $1928 ; (b_col + 1)
137f : 30 0c __ BMI $138d ; (b_putc.s8 + 0)
.s11:
1381 : d0 07 __ BNE $138a ; (b_putc.s9 + 0)
.s10:
1383 : ad 27 19 LDA $1927 ; (b_col + 0)
1386 : c9 28 __ CMP #$28
1388 : 90 03 __ BCC $138d ; (b_putc.s8 + 0)
.s9:
138a : 20 39 14 JSR $1439 ; (b_newline.s4 + 0)
.s8:
138d : a5 13 __ LDA P6 ; (c + 0)
138f : 20 95 15 JSR $1595 ; (b_pet2scr.s4 + 0)
1392 : 85 4e __ STA T3 + 0 
1394 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
1397 : ad 25 19 LDA $1925 ; (b_mem + 0)
139a : 18 __ __ CLC
139b : 65 1b __ ADC ACCU + 0 
139d : 85 4a __ STA T1 + 0 
139f : ad 26 19 LDA $1926 ; (b_mem + 1)
13a2 : 65 1c __ ADC ACCU + 1 
13a4 : 85 4b __ STA T1 + 1 
13a6 : ad 29 19 LDA $1929 ; (b_row + 0)
13a9 : 0a __ __ ASL
13aa : 85 07 __ STA WORK + 4 
13ac : ad 2a 19 LDA $192a ; (b_row + 1)
13af : 2a __ __ ROL
13b0 : 06 07 __ ASL WORK + 4 
13b2 : 2a __ __ ROL
13b3 : aa __ __ TAX
13b4 : 18 __ __ CLC
13b5 : a5 07 __ LDA WORK + 4 
13b7 : 6d 29 19 ADC $1929 ; (b_row + 0)
13ba : 85 1b __ STA ACCU + 0 
13bc : 8a __ __ TXA
13bd : 6d 2a 19 ADC $192a ; (b_row + 1)
13c0 : 06 1b __ ASL ACCU + 0 
13c2 : 2a __ __ ROL
13c3 : 06 1b __ ASL ACCU + 0 
13c5 : 2a __ __ ROL
13c6 : 06 1b __ ASL ACCU + 0 
13c8 : 2a __ __ ROL
13c9 : 85 1c __ STA ACCU + 1 
13cb : ad 27 19 LDA $1927 ; (b_col + 0)
13ce : aa __ __ TAX
13cf : 18 __ __ CLC
13d0 : 65 1b __ ADC ACCU + 0 
13d2 : a8 __ __ TAY
13d3 : ad 28 19 LDA $1928 ; (b_col + 1)
13d6 : 85 4d __ STA T2 + 1 
13d8 : 65 1c __ ADC ACCU + 1 
13da : 18 __ __ CLC
13db : 65 4b __ ADC T1 + 1 
13dd : 85 4b __ STA T1 + 1 
13df : a5 4e __ LDA T3 + 0 
13e1 : 91 4a __ STA (T1 + 0),y 
13e3 : 8a __ __ TXA
13e4 : 18 __ __ CLC
13e5 : 69 01 __ ADC #$01
13e7 : 8d 27 19 STA $1927 ; (b_col + 0)
13ea : a5 4d __ LDA T2 + 1 
13ec : 69 00 __ ADC #$00
.s17:
13ee : 8d 28 19 STA $1928 ; (b_col + 1)
.s3:
13f1 : 60 __ __ RTS
.s12:
13f2 : 4c 39 14 JMP $1439 ; (b_newline.s4 + 0)
.s14:
13f5 : a9 00 __ LDA #$00
13f7 : 8d 29 19 STA $1929 ; (b_row + 0)
13fa : 8d 2a 19 STA $192a ; (b_row + 1)
13fd : 8d 27 19 STA $1927 ; (b_col + 0)
1400 : 8d 28 19 STA $1928 ; (b_col + 1)
1403 : 85 4c __ STA T2 + 0 
1405 : 85 4d __ STA T2 + 1 
.l15:
1407 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
140a : ad 25 19 LDA $1925 ; (b_mem + 0)
140d : 18 __ __ CLC
140e : 65 1b __ ADC ACCU + 0 
1410 : 85 4a __ STA T1 + 0 
1412 : ad 26 19 LDA $1926 ; (b_mem + 1)
1415 : 65 1c __ ADC ACCU + 1 
1417 : 18 __ __ CLC
1418 : 65 4d __ ADC T2 + 1 
141a : 85 4b __ STA T1 + 1 
141c : a9 20 __ LDA #$20
141e : a4 4c __ LDY T2 + 0 
1420 : 91 4a __ STA (T1 + 0),y 
1422 : 98 __ __ TYA
1423 : 18 __ __ CLC
1424 : 69 01 __ ADC #$01
1426 : 85 4c __ STA T2 + 0 
1428 : a5 4d __ LDA T2 + 1 
142a : 69 00 __ ADC #$00
142c : 85 4d __ STA T2 + 1 
142e : c9 03 __ CMP #$03
1430 : d0 d5 __ BNE $1407 ; (b_putc.l15 + 0)
.s16:
1432 : a5 4c __ LDA T2 + 0 
1434 : c9 e8 __ CMP #$e8
1436 : d0 cf __ BNE $1407 ; (b_putc.l15 + 0)
1438 : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1439 : a9 00 __ LDA #$00
143b : 8d 27 19 STA $1927 ; (b_col + 0)
143e : 8d 28 19 STA $1928 ; (b_col + 1)
1441 : ad 29 19 LDA $1929 ; (b_row + 0)
1444 : aa __ __ TAX
1445 : 18 __ __ CLC
1446 : 69 01 __ ADC #$01
1448 : 8d 29 19 STA $1929 ; (b_row + 0)
144b : ad 2a 19 LDA $192a ; (b_row + 1)
144e : a8 __ __ TAY
144f : 69 00 __ ADC #$00
1451 : 8d 2a 19 STA $192a ; (b_row + 1)
1454 : 98 __ __ TYA
1455 : 30 13 __ BMI $146a ; (b_newline.s3 + 0)
.s7:
1457 : d0 04 __ BNE $145d ; (b_newline.s5 + 0)
.s6:
1459 : e0 18 __ CPX #$18
145b : 90 0d __ BCC $146a ; (b_newline.s3 + 0)
.s5:
145d : 20 6b 14 JSR $146b ; (b_scroll.s4 + 0)
1460 : a9 18 __ LDA #$18
1462 : 8d 29 19 STA $1929 ; (b_row + 0)
1465 : a9 00 __ LDA #$00
1467 : 8d 2a 19 STA $192a ; (b_row + 1)
.s3:
146a : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
146b : a9 c0 __ LDA #$c0
146d : 85 11 __ STA P4 
146f : a9 03 __ LDA #$03
1471 : 85 12 __ STA P5 
1473 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
1476 : ad 25 19 LDA $1925 ; (b_mem + 0)
1479 : 85 45 __ STA T1 + 0 
147b : 18 __ __ CLC
147c : 65 1b __ ADC ACCU + 0 
147e : 85 0d __ STA P0 
1480 : ad 26 19 LDA $1926 ; (b_mem + 1)
1483 : 85 46 __ STA T1 + 1 
1485 : 65 1c __ ADC ACCU + 1 
1487 : 85 0e __ STA P1 
1489 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
148c : 18 __ __ CLC
148d : a5 45 __ LDA T1 + 0 
148f : 65 1b __ ADC ACCU + 0 
1491 : aa __ __ TAX
1492 : a5 46 __ LDA T1 + 1 
1494 : 65 1c __ ADC ACCU + 1 
1496 : a8 __ __ TAY
1497 : 8a __ __ TXA
1498 : 18 __ __ CLC
1499 : 69 28 __ ADC #$28
149b : 85 0f __ STA P2 
149d : 90 01 __ BCC $14a0 ; (b_scroll.s7 + 0)
.s6:
149f : c8 __ __ INY
.s7:
14a0 : 84 10 __ STY P3 
14a2 : 20 00 15 JSR $1500 ; (memmove.s4 + 0)
14a5 : a9 03 __ LDA #$03
14a7 : 85 12 __ STA P5 
14a9 : 18 __ __ CLC
14aa : a5 46 __ LDA T1 + 1 
14ac : 69 d8 __ ADC #$d8
14ae : 85 0e __ STA P1 
14b0 : a5 45 __ LDA T1 + 0 
14b2 : 85 0d __ STA P0 
14b4 : 18 __ __ CLC
14b5 : 69 28 __ ADC #$28
14b7 : 85 0f __ STA P2 
14b9 : a5 46 __ LDA T1 + 1 
14bb : 69 d8 __ ADC #$d8
14bd : 85 10 __ STA P3 
14bf : 20 00 15 JSR $1500 ; (memmove.s4 + 0)
14c2 : 18 __ __ CLC
14c3 : a5 45 __ LDA T1 + 0 
14c5 : 69 c0 __ ADC #$c0
14c7 : 85 47 __ STA T2 + 0 
14c9 : a5 46 __ LDA T1 + 1 
14cb : 69 db __ ADC #$db
14cd : 85 48 __ STA T2 + 1 
14cf : a9 00 __ LDA #$00
14d1 : 85 49 __ STA T3 + 0 
.l5:
14d3 : 20 dd 12 JSR $12dd ; (b_scr_base.s4 + 0)
14d6 : 18 __ __ CLC
14d7 : a5 45 __ LDA T1 + 0 
14d9 : 65 1b __ ADC ACCU + 0 
14db : a8 __ __ TAY
14dc : a5 46 __ LDA T1 + 1 
14de : 65 1c __ ADC ACCU + 1 
14e0 : aa __ __ TAX
14e1 : 98 __ __ TYA
14e2 : 18 __ __ CLC
14e3 : 65 49 __ ADC T3 + 0 
14e5 : 85 1f __ STA ADDR + 0 
14e7 : 8a __ __ TXA
14e8 : 69 03 __ ADC #$03
14ea : 85 20 __ STA ADDR + 1 
14ec : a9 20 __ LDA #$20
14ee : a0 c0 __ LDY #$c0
14f0 : 91 1f __ STA (ADDR + 0),y 
14f2 : a9 0e __ LDA #$0e
14f4 : a4 49 __ LDY T3 + 0 
14f6 : 91 47 __ STA (T2 + 0),y 
14f8 : c8 __ __ INY
14f9 : 84 49 __ STY T3 + 0 
14fb : c0 28 __ CPY #$28
14fd : 90 d4 __ BCC $14d3 ; (b_scroll.l5 + 0)
.s3:
14ff : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1500 : a5 12 __ LDA P5 ; (size + 1)
1502 : 30 65 __ BMI $1569 ; (memmove.s5 + 0)
.s14:
1504 : 05 11 __ ORA P4 ; (size + 0)
1506 : f0 61 __ BEQ $1569 ; (memmove.s5 + 0)
.s6:
1508 : a5 0d __ LDA P0 ; (dst + 0)
150a : 85 1b __ STA ACCU + 0 
150c : a5 0f __ LDA P2 ; (src + 0)
150e : 85 43 __ STA T3 + 0 
1510 : a5 0e __ LDA P1 ; (dst + 1)
1512 : 85 1c __ STA ACCU + 1 
1514 : a6 10 __ LDX P3 ; (src + 1)
1516 : 86 44 __ STX T3 + 1 
1518 : c5 10 __ CMP P3 ; (src + 1)
151a : d0 04 __ BNE $1520 ; (memmove.s13 + 0)
.s12:
151c : a5 0d __ LDA P0 ; (dst + 0)
151e : c5 0f __ CMP P2 ; (src + 0)
.s13:
1520 : 90 50 __ BCC $1572 ; (memmove.s11 + 0)
.s7:
1522 : e4 0e __ CPX P1 ; (dst + 1)
1524 : d0 04 __ BNE $152a ; (memmove.s10 + 0)
.s9:
1526 : a5 0f __ LDA P2 ; (src + 0)
1528 : c5 0d __ CMP P0 ; (dst + 0)
.s10:
152a : b0 3d __ BCS $1569 ; (memmove.s5 + 0)
.s8:
152c : a5 0f __ LDA P2 ; (src + 0)
152e : 65 11 __ ADC P4 ; (size + 0)
1530 : 85 43 __ STA T3 + 0 
1532 : 8a __ __ TXA
1533 : 65 12 __ ADC P5 ; (size + 1)
1535 : 85 44 __ STA T3 + 1 
1537 : 18 __ __ CLC
1538 : a5 0d __ LDA P0 ; (dst + 0)
153a : 65 11 __ ADC P4 ; (size + 0)
153c : 85 1b __ STA ACCU + 0 
153e : a5 0e __ LDA P1 ; (dst + 1)
1540 : 65 12 __ ADC P5 ; (size + 1)
1542 : 85 1c __ STA ACCU + 1 
1544 : a0 00 __ LDY #$00
1546 : a5 11 __ LDA P4 ; (size + 0)
1548 : f0 02 __ BEQ $154c ; (memmove.s30 + 0)
.s16:
154a : e6 12 __ INC P5 ; (size + 1)
.s30:
154c : a6 11 __ LDX P4 ; (size + 0)
.l19:
154e : a5 43 __ LDA T3 + 0 
1550 : d0 02 __ BNE $1554 ; (memmove.s26 + 0)
.s25:
1552 : c6 44 __ DEC T3 + 1 
.s26:
1554 : c6 43 __ DEC T3 + 0 
1556 : a5 1b __ LDA ACCU + 0 
1558 : d0 02 __ BNE $155c ; (memmove.s28 + 0)
.s27:
155a : c6 1c __ DEC ACCU + 1 
.s28:
155c : c6 1b __ DEC ACCU + 0 
155e : b1 43 __ LDA (T3 + 0),y 
1560 : 91 1b __ STA (ACCU + 0),y 
1562 : ca __ __ DEX
1563 : d0 e9 __ BNE $154e ; (memmove.l19 + 0)
.s20:
1565 : c6 12 __ DEC P5 ; (size + 1)
1567 : d0 e5 __ BNE $154e ; (memmove.l19 + 0)
.s5:
1569 : a5 0d __ LDA P0 ; (dst + 0)
156b : 85 1b __ STA ACCU + 0 
156d : a5 0e __ LDA P1 ; (dst + 1)
156f : 85 1c __ STA ACCU + 1 
.s3:
1571 : 60 __ __ RTS
.s11:
1572 : a0 00 __ LDY #$00
1574 : a5 11 __ LDA P4 ; (size + 0)
1576 : f0 02 __ BEQ $157a ; (memmove.s29 + 0)
.s15:
1578 : e6 12 __ INC P5 ; (size + 1)
.s29:
157a : a6 11 __ LDX P4 ; (size + 0)
.l17:
157c : b1 43 __ LDA (T3 + 0),y 
157e : 91 1b __ STA (ACCU + 0),y 
1580 : e6 43 __ INC T3 + 0 
1582 : d0 02 __ BNE $1586 ; (memmove.s22 + 0)
.s21:
1584 : e6 44 __ INC T3 + 1 
.s22:
1586 : e6 1b __ INC ACCU + 0 
1588 : d0 02 __ BNE $158c ; (memmove.s24 + 0)
.s23:
158a : e6 1c __ INC ACCU + 1 
.s24:
158c : ca __ __ DEX
158d : d0 ed __ BNE $157c ; (memmove.l17 + 0)
.s18:
158f : c6 12 __ DEC P5 ; (size + 1)
1591 : d0 e9 __ BNE $157c ; (memmove.l17 + 0)
1593 : f0 d4 __ BEQ $1569 ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1595 : c9 41 __ CMP #$41
1597 : 90 06 __ BCC $159f ; (b_pet2scr.s3 + 0)
.s8:
1599 : c9 5b __ CMP #$5b
159b : b0 03 __ BCS $15a0 ; (b_pet2scr.s5 + 0)
.s9:
159d : e9 3f __ SBC #$3f
.s3:
159f : 60 __ __ RTS
.s5:
15a0 : c9 c1 __ CMP #$c1
15a2 : 90 fb __ BCC $159f ; (b_pet2scr.s3 + 0)
.s6:
15a4 : c9 db __ CMP #$db
15a6 : b0 f7 __ BCS $159f ; (b_pet2scr.s3 + 0)
.s7:
15a8 : e9 bf __ SBC #$bf
15aa : 60 __ __ RTS
--------------------------------------------------------------------
mul32by8: ; mul32by8
15ab : a0 00 __ LDY #$00
15ad : 84 07 __ STY WORK + 4 
15af : 84 08 __ STY WORK + 5 
15b1 : 84 09 __ STY WORK + 6 
15b3 : 4a __ __ LSR
15b4 : b0 0d __ BCS $15c3 ; (mul32by8 + 24)
15b6 : f0 26 __ BEQ $15de ; (mul32by8 + 51)
15b8 : 06 1b __ ASL ACCU + 0 
15ba : 26 1c __ ROL ACCU + 1 
15bc : 26 1d __ ROL ACCU + 2 
15be : 26 1e __ ROL ACCU + 3 
15c0 : 4a __ __ LSR
15c1 : 90 f5 __ BCC $15b8 ; (mul32by8 + 13)
15c3 : aa __ __ TAX
15c4 : 18 __ __ CLC
15c5 : a5 07 __ LDA WORK + 4 
15c7 : 65 1b __ ADC ACCU + 0 
15c9 : 85 07 __ STA WORK + 4 
15cb : a5 08 __ LDA WORK + 5 
15cd : 65 1c __ ADC ACCU + 1 
15cf : 85 08 __ STA WORK + 5 
15d1 : a5 09 __ LDA WORK + 6 
15d3 : 65 1d __ ADC ACCU + 2 
15d5 : 85 09 __ STA WORK + 6 
15d7 : 98 __ __ TYA
15d8 : 65 1e __ ADC ACCU + 3 
15da : a8 __ __ TAY
15db : 8a __ __ TXA
15dc : d0 da __ BNE $15b8 ; (mul32by8 + 13)
15de : 84 0a __ STY WORK + 7 
15e0 : 60 __ __ RTS
--------------------------------------------------------------------
freg: ; freg
15e1 : b1 19 __ LDA (IP + 0),y 
15e3 : c8 __ __ INY
15e4 : aa __ __ TAX
15e5 : b5 00 __ LDA $00,x 
15e7 : 85 03 __ STA WORK + 0 
15e9 : b5 01 __ LDA $01,x 
15eb : 85 04 __ STA WORK + 1 
15ed : b5 02 __ LDA $02,x 
15ef : 85 05 __ STA WORK + 2 
15f1 : b5 03 __ LDA WORK + 0,x 
15f3 : 85 06 __ STA WORK + 3 
15f5 : a5 05 __ LDA WORK + 2 
15f7 : 0a __ __ ASL
15f8 : a5 06 __ LDA WORK + 3 
15fa : 2a __ __ ROL
15fb : 85 08 __ STA WORK + 5 
15fd : f0 06 __ BEQ $1605 ; (freg + 36)
15ff : a5 05 __ LDA WORK + 2 
1601 : 09 80 __ ORA #$80
1603 : 85 05 __ STA WORK + 2 
1605 : a5 1d __ LDA ACCU + 2 
1607 : 0a __ __ ASL
1608 : a5 1e __ LDA ACCU + 3 
160a : 2a __ __ ROL
160b : 85 07 __ STA WORK + 4 
160d : f0 06 __ BEQ $1615 ; (freg + 52)
160f : a5 1d __ LDA ACCU + 2 
1611 : 09 80 __ ORA #$80
1613 : 85 1d __ STA ACCU + 2 
1615 : 60 __ __ RTS
1616 : 06 1e __ ASL ACCU + 3 
1618 : a5 07 __ LDA WORK + 4 
161a : 6a __ __ ROR
161b : 85 1e __ STA ACCU + 3 
161d : b0 06 __ BCS $1625 ; (freg + 68)
161f : a5 1d __ LDA ACCU + 2 
1621 : 29 7f __ AND #$7f
1623 : 85 1d __ STA ACCU + 2 
1625 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
1626 : a5 1b __ LDA ACCU + 0 
1628 : 05 1c __ ORA ACCU + 1 
162a : 05 1d __ ORA ACCU + 2 
162c : f0 0e __ BEQ $163c ; (crt_fmul + 22)
162e : a5 03 __ LDA WORK + 0 
1630 : 05 04 __ ORA WORK + 1 
1632 : 05 05 __ ORA WORK + 2 
1634 : d0 09 __ BNE $163f ; (crt_fmul + 25)
1636 : 85 1b __ STA ACCU + 0 
1638 : 85 1c __ STA ACCU + 1 
163a : 85 1d __ STA ACCU + 2 
163c : 85 1e __ STA ACCU + 3 
163e : 60 __ __ RTS
163f : a5 1e __ LDA ACCU + 3 
1641 : 45 06 __ EOR WORK + 3 
1643 : 29 80 __ AND #$80
1645 : 85 1e __ STA ACCU + 3 
1647 : a9 ff __ LDA #$ff
1649 : c5 07 __ CMP WORK + 4 
164b : f0 42 __ BEQ $168f ; (crt_fmul + 105)
164d : c5 08 __ CMP WORK + 5 
164f : f0 3e __ BEQ $168f ; (crt_fmul + 105)
1651 : a9 00 __ LDA #$00
1653 : 85 09 __ STA WORK + 6 
1655 : 85 0a __ STA WORK + 7 
1657 : 85 0b __ STA WORK + 8 
1659 : a4 1b __ LDY ACCU + 0 
165b : a5 03 __ LDA WORK + 0 
165d : d0 06 __ BNE $1665 ; (crt_fmul + 63)
165f : a5 04 __ LDA WORK + 1 
1661 : f0 0a __ BEQ $166d ; (crt_fmul + 71)
1663 : d0 05 __ BNE $166a ; (crt_fmul + 68)
1665 : 20 c0 16 JSR $16c0 ; (crt_fmul8 + 0)
1668 : a5 04 __ LDA WORK + 1 
166a : 20 c0 16 JSR $16c0 ; (crt_fmul8 + 0)
166d : a5 05 __ LDA WORK + 2 
166f : 20 c0 16 JSR $16c0 ; (crt_fmul8 + 0)
1672 : 38 __ __ SEC
1673 : a5 0b __ LDA WORK + 8 
1675 : 30 06 __ BMI $167d ; (crt_fmul + 87)
1677 : 06 09 __ ASL WORK + 6 
1679 : 26 0a __ ROL WORK + 7 
167b : 2a __ __ ROL
167c : 18 __ __ CLC
167d : 29 7f __ AND #$7f
167f : 85 0b __ STA WORK + 8 
1681 : a5 07 __ LDA WORK + 4 
1683 : 65 08 __ ADC WORK + 5 
1685 : 90 19 __ BCC $16a0 ; (crt_fmul + 122)
1687 : e9 7f __ SBC #$7f
1689 : b0 04 __ BCS $168f ; (crt_fmul + 105)
168b : c9 ff __ CMP #$ff
168d : d0 15 __ BNE $16a4 ; (crt_fmul + 126)
168f : a5 1e __ LDA ACCU + 3 
1691 : 09 7f __ ORA #$7f
1693 : 85 1e __ STA ACCU + 3 
1695 : a9 80 __ LDA #$80
1697 : 85 1d __ STA ACCU + 2 
1699 : a9 00 __ LDA #$00
169b : 85 1b __ STA ACCU + 0 
169d : 85 1c __ STA ACCU + 1 
169f : 60 __ __ RTS
16a0 : e9 7e __ SBC #$7e
16a2 : 90 15 __ BCC $16b9 ; (crt_fmul + 147)
16a4 : 4a __ __ LSR
16a5 : 05 1e __ ORA ACCU + 3 
16a7 : 85 1e __ STA ACCU + 3 
16a9 : a9 00 __ LDA #$00
16ab : 6a __ __ ROR
16ac : 05 0b __ ORA WORK + 8 
16ae : 85 1d __ STA ACCU + 2 
16b0 : a5 0a __ LDA WORK + 7 
16b2 : 85 1c __ STA ACCU + 1 
16b4 : a5 09 __ LDA WORK + 6 
16b6 : 85 1b __ STA ACCU + 0 
16b8 : 60 __ __ RTS
16b9 : a9 00 __ LDA #$00
16bb : 85 1e __ STA ACCU + 3 
16bd : f0 d8 __ BEQ $1697 ; (crt_fmul + 113)
16bf : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
16c0 : 38 __ __ SEC
16c1 : 6a __ __ ROR
16c2 : 90 1e __ BCC $16e2 ; (crt_fmul8 + 34)
16c4 : aa __ __ TAX
16c5 : 18 __ __ CLC
16c6 : 98 __ __ TYA
16c7 : 65 09 __ ADC WORK + 6 
16c9 : 85 09 __ STA WORK + 6 
16cb : a5 0a __ LDA WORK + 7 
16cd : 65 1c __ ADC ACCU + 1 
16cf : 85 0a __ STA WORK + 7 
16d1 : a5 0b __ LDA WORK + 8 
16d3 : 65 1d __ ADC ACCU + 2 
16d5 : 6a __ __ ROR
16d6 : 85 0b __ STA WORK + 8 
16d8 : 8a __ __ TXA
16d9 : 66 0a __ ROR WORK + 7 
16db : 66 09 __ ROR WORK + 6 
16dd : 4a __ __ LSR
16de : f0 0d __ BEQ $16ed ; (crt_fmul8 + 45)
16e0 : b0 e2 __ BCS $16c4 ; (crt_fmul8 + 4)
16e2 : 66 0b __ ROR WORK + 8 
16e4 : 66 0a __ ROR WORK + 7 
16e6 : 66 09 __ ROR WORK + 6 
16e8 : 4a __ __ LSR
16e9 : 90 f7 __ BCC $16e2 ; (crt_fmul8 + 34)
16eb : d0 d7 __ BNE $16c4 ; (crt_fmul8 + 4)
16ed : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
16ee : a5 1b __ LDA ACCU + 0 
16f0 : 05 1c __ ORA ACCU + 1 
16f2 : 05 1d __ ORA ACCU + 2 
16f4 : d0 03 __ BNE $16f9 ; (crt_fdiv + 11)
16f6 : 85 1e __ STA ACCU + 3 
16f8 : 60 __ __ RTS
16f9 : a5 1e __ LDA ACCU + 3 
16fb : 45 06 __ EOR WORK + 3 
16fd : 29 80 __ AND #$80
16ff : 85 1e __ STA ACCU + 3 
1701 : a5 08 __ LDA WORK + 5 
1703 : f0 62 __ BEQ $1767 ; (crt_fdiv + 121)
1705 : a5 07 __ LDA WORK + 4 
1707 : c9 ff __ CMP #$ff
1709 : f0 5c __ BEQ $1767 ; (crt_fdiv + 121)
170b : a9 00 __ LDA #$00
170d : 85 09 __ STA WORK + 6 
170f : 85 0a __ STA WORK + 7 
1711 : 85 0b __ STA WORK + 8 
1713 : a2 18 __ LDX #$18
1715 : a5 1b __ LDA ACCU + 0 
1717 : c5 03 __ CMP WORK + 0 
1719 : a5 1c __ LDA ACCU + 1 
171b : e5 04 __ SBC WORK + 1 
171d : a5 1d __ LDA ACCU + 2 
171f : e5 05 __ SBC WORK + 2 
1721 : 90 13 __ BCC $1736 ; (crt_fdiv + 72)
1723 : a5 1b __ LDA ACCU + 0 
1725 : e5 03 __ SBC WORK + 0 
1727 : 85 1b __ STA ACCU + 0 
1729 : a5 1c __ LDA ACCU + 1 
172b : e5 04 __ SBC WORK + 1 
172d : 85 1c __ STA ACCU + 1 
172f : a5 1d __ LDA ACCU + 2 
1731 : e5 05 __ SBC WORK + 2 
1733 : 85 1d __ STA ACCU + 2 
1735 : 38 __ __ SEC
1736 : 26 09 __ ROL WORK + 6 
1738 : 26 0a __ ROL WORK + 7 
173a : 26 0b __ ROL WORK + 8 
173c : ca __ __ DEX
173d : f0 0a __ BEQ $1749 ; (crt_fdiv + 91)
173f : 06 1b __ ASL ACCU + 0 
1741 : 26 1c __ ROL ACCU + 1 
1743 : 26 1d __ ROL ACCU + 2 
1745 : b0 dc __ BCS $1723 ; (crt_fdiv + 53)
1747 : 90 cc __ BCC $1715 ; (crt_fdiv + 39)
1749 : 38 __ __ SEC
174a : a5 0b __ LDA WORK + 8 
174c : 30 06 __ BMI $1754 ; (crt_fdiv + 102)
174e : 06 09 __ ASL WORK + 6 
1750 : 26 0a __ ROL WORK + 7 
1752 : 2a __ __ ROL
1753 : 18 __ __ CLC
1754 : 29 7f __ AND #$7f
1756 : 85 0b __ STA WORK + 8 
1758 : a5 07 __ LDA WORK + 4 
175a : e5 08 __ SBC WORK + 5 
175c : 90 1a __ BCC $1778 ; (crt_fdiv + 138)
175e : 18 __ __ CLC
175f : 69 7f __ ADC #$7f
1761 : b0 04 __ BCS $1767 ; (crt_fdiv + 121)
1763 : c9 ff __ CMP #$ff
1765 : d0 15 __ BNE $177c ; (crt_fdiv + 142)
1767 : a5 1e __ LDA ACCU + 3 
1769 : 09 7f __ ORA #$7f
176b : 85 1e __ STA ACCU + 3 
176d : a9 80 __ LDA #$80
176f : 85 1d __ STA ACCU + 2 
1771 : a9 00 __ LDA #$00
1773 : 85 1c __ STA ACCU + 1 
1775 : 85 1b __ STA ACCU + 0 
1777 : 60 __ __ RTS
1778 : 69 7f __ ADC #$7f
177a : 90 15 __ BCC $1791 ; (crt_fdiv + 163)
177c : 4a __ __ LSR
177d : 05 1e __ ORA ACCU + 3 
177f : 85 1e __ STA ACCU + 3 
1781 : a9 00 __ LDA #$00
1783 : 6a __ __ ROR
1784 : 05 0b __ ORA WORK + 8 
1786 : 85 1d __ STA ACCU + 2 
1788 : a5 0a __ LDA WORK + 7 
178a : 85 1c __ STA ACCU + 1 
178c : a5 09 __ LDA WORK + 6 
178e : 85 1b __ STA ACCU + 0 
1790 : 60 __ __ RTS
1791 : a9 00 __ LDA #$00
1793 : 85 1e __ STA ACCU + 3 
1795 : 85 1d __ STA ACCU + 2 
1797 : 85 1c __ STA ACCU + 1 
1799 : 85 1b __ STA ACCU + 0 
179b : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
179c : a5 1e __ LDA ACCU + 3 
179e : 30 03 __ BMI $17a3 ; (f32_to_i32 + 7)
17a0 : 4c c0 17 JMP $17c0 ; (f32_to_u32 + 0)
17a3 : 20 c0 17 JSR $17c0 ; (f32_to_u32 + 0)
17a6 : 38 __ __ SEC
17a7 : a9 00 __ LDA #$00
17a9 : e5 1b __ SBC ACCU + 0 
17ab : 85 1b __ STA ACCU + 0 
17ad : a9 00 __ LDA #$00
17af : e5 1c __ SBC ACCU + 1 
17b1 : 85 1c __ STA ACCU + 1 
17b3 : a9 00 __ LDA #$00
17b5 : e5 1d __ SBC ACCU + 2 
17b7 : 85 1d __ STA ACCU + 2 
17b9 : a9 00 __ LDA #$00
17bb : e5 1e __ SBC ACCU + 3 
17bd : 85 1e __ STA ACCU + 3 
17bf : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
17c0 : 20 05 16 JSR $1605 ; (freg + 36)
17c3 : a5 07 __ LDA WORK + 4 
17c5 : c9 7f __ CMP #$7f
17c7 : b0 0b __ BCS $17d4 ; (f32_to_u32 + 20)
17c9 : a9 00 __ LDA #$00
17cb : 85 1b __ STA ACCU + 0 
17cd : 85 1c __ STA ACCU + 1 
17cf : 85 1d __ STA ACCU + 2 
17d1 : 85 1e __ STA ACCU + 3 
17d3 : 60 __ __ RTS
17d4 : 38 __ __ SEC
17d5 : e9 9e __ SBC #$9e
17d7 : f0 13 __ BEQ $17ec ; (f32_to_u32 + 44)
17d9 : 90 04 __ BCC $17df ; (f32_to_u32 + 31)
17db : a9 ff __ LDA #$ff
17dd : d0 ec __ BNE $17cb ; (f32_to_u32 + 11)
17df : aa __ __ TAX
17e0 : a9 00 __ LDA #$00
17e2 : 46 1d __ LSR ACCU + 2 
17e4 : 66 1c __ ROR ACCU + 1 
17e6 : 66 1b __ ROR ACCU + 0 
17e8 : 6a __ __ ROR
17e9 : e8 __ __ INX
17ea : d0 f6 __ BNE $17e2 ; (f32_to_u32 + 34)
17ec : a6 1d __ LDX ACCU + 2 
17ee : 86 1e __ STX ACCU + 3 
17f0 : a6 1c __ LDX ACCU + 1 
17f2 : 86 1d __ STX ACCU + 2 
17f4 : a6 1b __ LDX ACCU + 0 
17f6 : 86 1c __ STX ACCU + 1 
17f8 : 85 1b __ STA ACCU + 0 
17fa : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
17fb : 24 1e __ BIT ACCU + 3 
17fd : 30 03 __ BMI $1802 ; (sint32_to_float + 7)
17ff : 4c 25 18 JMP $1825 ; (uint32_to_float + 0)
1802 : 38 __ __ SEC
1803 : a9 00 __ LDA #$00
1805 : e5 1b __ SBC ACCU + 0 
1807 : 85 1b __ STA ACCU + 0 
1809 : a9 00 __ LDA #$00
180b : e5 1c __ SBC ACCU + 1 
180d : 85 1c __ STA ACCU + 1 
180f : a9 00 __ LDA #$00
1811 : e5 1d __ SBC ACCU + 2 
1813 : 85 1d __ STA ACCU + 2 
1815 : a9 00 __ LDA #$00
1817 : e5 1e __ SBC ACCU + 3 
1819 : 85 1e __ STA ACCU + 3 
181b : 20 25 18 JSR $1825 ; (uint32_to_float + 0)
181e : a5 1e __ LDA ACCU + 3 
1820 : 09 80 __ ORA #$80
1822 : 85 1e __ STA ACCU + 3 
1824 : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
1825 : a5 1b __ LDA ACCU + 0 
1827 : 05 1c __ ORA ACCU + 1 
1829 : 05 1d __ ORA ACCU + 2 
182b : 05 1e __ ORA ACCU + 3 
182d : d0 01 __ BNE $1830 ; (uint32_to_float + 11)
182f : 60 __ __ RTS
1830 : a2 9e __ LDX #$9e
1832 : a5 1e __ LDA ACCU + 3 
1834 : 30 0a __ BMI $1840 ; (uint32_to_float + 27)
1836 : ca __ __ DEX
1837 : 06 1b __ ASL ACCU + 0 
1839 : 26 1c __ ROL ACCU + 1 
183b : 26 1d __ ROL ACCU + 2 
183d : 2a __ __ ROL
183e : 10 f6 __ BPL $1836 ; (uint32_to_float + 17)
1840 : 24 1b __ BIT ACCU + 0 
1842 : 10 13 __ BPL $1857 ; (uint32_to_float + 50)
1844 : e6 1c __ INC ACCU + 1 
1846 : d0 0f __ BNE $1857 ; (uint32_to_float + 50)
1848 : e6 1d __ INC ACCU + 2 
184a : d0 0b __ BNE $1857 ; (uint32_to_float + 50)
184c : 18 __ __ CLC
184d : 69 01 __ ADC #$01
184f : 90 06 __ BCC $1857 ; (uint32_to_float + 50)
1851 : 4a __ __ LSR
1852 : 66 1d __ ROR ACCU + 2 
1854 : 66 1c __ ROR ACCU + 1 
1856 : e8 __ __ INX
1857 : 0a __ __ ASL
1858 : a4 1c __ LDY ACCU + 1 
185a : 84 1b __ STY ACCU + 0 
185c : a4 1d __ LDY ACCU + 2 
185e : 84 1c __ STY ACCU + 1 
1860 : 85 1d __ STA ACCU + 2 
1862 : 8a __ __ TXA
1863 : 4a __ __ LSR
1864 : 85 1e __ STA ACCU + 3 
1866 : 66 1d __ ROR ACCU + 2 
1868 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fcmp: ; crt_fcmp
1869 : a5 1e __ LDA ACCU + 3 
186b : 45 06 __ EOR WORK + 3 
186d : 10 1e __ BPL $188d ; (crt_fcmp + 36)
186f : a5 1e __ LDA ACCU + 3 
1871 : 29 7f __ AND #$7f
1873 : 05 1d __ ORA ACCU + 2 
1875 : 05 1c __ ORA ACCU + 1 
1877 : 05 1b __ ORA ACCU + 0 
1879 : d0 0c __ BNE $1887 ; (crt_fcmp + 30)
187b : a5 06 __ LDA WORK + 3 
187d : 29 7f __ AND #$7f
187f : 05 05 __ ORA WORK + 2 
1881 : 05 04 __ ORA WORK + 1 
1883 : 05 03 __ ORA WORK + 0 
1885 : f0 1e __ BEQ $18a5 ; (crt_fcmp + 60)
1887 : a5 1e __ LDA ACCU + 3 
1889 : 30 23 __ BMI $18ae ; (crt_fcmp + 69)
188b : 10 28 __ BPL $18b5 ; (crt_fcmp + 76)
188d : a5 1e __ LDA ACCU + 3 
188f : c5 06 __ CMP WORK + 3 
1891 : d0 15 __ BNE $18a8 ; (crt_fcmp + 63)
1893 : a5 1d __ LDA ACCU + 2 
1895 : c5 05 __ CMP WORK + 2 
1897 : d0 0f __ BNE $18a8 ; (crt_fcmp + 63)
1899 : a5 1c __ LDA ACCU + 1 
189b : c5 04 __ CMP WORK + 1 
189d : d0 09 __ BNE $18a8 ; (crt_fcmp + 63)
189f : a5 1b __ LDA ACCU + 0 
18a1 : c5 03 __ CMP WORK + 0 
18a3 : d0 03 __ BNE $18a8 ; (crt_fcmp + 63)
18a5 : a9 00 __ LDA #$00
18a7 : 60 __ __ RTS
18a8 : b0 07 __ BCS $18b1 ; (crt_fcmp + 72)
18aa : 24 1e __ BIT ACCU + 3 
18ac : 30 07 __ BMI $18b5 ; (crt_fcmp + 76)
18ae : a9 01 __ LDA #$01
18b0 : 60 __ __ RTS
18b1 : 24 1e __ BIT ACCU + 3 
18b3 : 30 f9 __ BMI $18ae ; (crt_fcmp + 69)
18b5 : a9 ff __ LDA #$ff
18b7 : 60 __ __ RTS
--------------------------------------------------------------------
mul32: ; mul32
18b8 : a5 04 __ LDA WORK + 1 
18ba : 05 05 __ ORA WORK + 2 
18bc : 05 06 __ ORA WORK + 3 
18be : d0 05 __ BNE $18c5 ; (mul32 + 13)
18c0 : a5 03 __ LDA WORK + 0 
18c2 : 4c ab 15 JMP $15ab ; (mul32by8 + 0)
18c5 : a0 00 __ LDY #$00
18c7 : 84 07 __ STY WORK + 4 
18c9 : 84 08 __ STY WORK + 5 
18cb : 98 __ __ TYA
18cc : 38 __ __ SEC
18cd : 66 03 __ ROR WORK + 0 
18cf : 90 15 __ BCC $18e6 ; (mul32 + 46)
18d1 : aa __ __ TAX
18d2 : 18 __ __ CLC
18d3 : a5 07 __ LDA WORK + 4 
18d5 : 65 1b __ ADC ACCU + 0 
18d7 : 85 07 __ STA WORK + 4 
18d9 : a5 08 __ LDA WORK + 5 
18db : 65 1c __ ADC ACCU + 1 
18dd : 85 08 __ STA WORK + 5 
18df : 98 __ __ TYA
18e0 : 65 1d __ ADC ACCU + 2 
18e2 : a8 __ __ TAY
18e3 : 8a __ __ TXA
18e4 : 65 1e __ ADC ACCU + 3 
18e6 : 46 04 __ LSR WORK + 1 
18e8 : 90 0f __ BCC $18f9 ; (mul32 + 65)
18ea : aa __ __ TAX
18eb : 18 __ __ CLC
18ec : a5 08 __ LDA WORK + 5 
18ee : 65 1b __ ADC ACCU + 0 
18f0 : 85 08 __ STA WORK + 5 
18f2 : 98 __ __ TYA
18f3 : 65 1c __ ADC ACCU + 1 
18f5 : a8 __ __ TAY
18f6 : 8a __ __ TXA
18f7 : 65 1d __ ADC ACCU + 2 
18f9 : 46 05 __ LSR WORK + 2 
18fb : 90 09 __ BCC $1906 ; (mul32 + 78)
18fd : aa __ __ TAX
18fe : 18 __ __ CLC
18ff : 98 __ __ TYA
1900 : 65 1b __ ADC ACCU + 0 
1902 : a8 __ __ TAY
1903 : 8a __ __ TXA
1904 : 65 1c __ ADC ACCU + 1 
1906 : 46 06 __ LSR WORK + 3 
1908 : 90 03 __ BCC $190d ; (mul32 + 85)
190a : 18 __ __ CLC
190b : 65 1b __ ADC ACCU + 0 
190d : 06 1b __ ASL ACCU + 0 
190f : 26 1c __ ROL ACCU + 1 
1911 : 26 1d __ ROL ACCU + 2 
1913 : 26 1e __ ROL ACCU + 3 
1915 : 46 03 __ LSR WORK + 0 
1917 : 90 cd __ BCC $18e6 ; (mul32 + 46)
1919 : d0 b6 __ BNE $18d1 ; (mul32 + 25)
191b : 84 09 __ STY WORK + 6 
191d : 85 0a __ STA WORK + 7 
191f : 60 __ __ RTS
--------------------------------------------------------------------
__multab16384H:
1920 : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
spentry:
1924 : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
b_mem:
1925 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
1927 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
1929 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_gosubSP:
192b : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
192d : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tab:
192f : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
193f : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
194f : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
195f : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
196f : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
197f : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
198f : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
199f : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
b_rndSeed:
19af : __ __ __ BYT 78 56 34 12                                     : xV4.
--------------------------------------------------------------------
tsb_sintab:
19b3 : __ __ __ BSS	64
--------------------------------------------------------------------
tsb_drawtab:
19f3 : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_ci:
19fb : __ __ __ BSS	4
--------------------------------------------------------------------
b_a_hi:
1a00 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_ti:
1a50 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_ei:
1aa0 : __ __ __ BSS	80
--------------------------------------------------------------------
b_v_bi:
1af0 : __ __ __ BSS	2
--------------------------------------------------------------------
b_a_chi:
1b00 : __ __ __ BSS	80
--------------------------------------------------------------------
b_a_di:
1b50 : __ __ __ BSS	80
--------------------------------------------------------------------
b_gosubStack:
1ba0 : __ __ __ BSS	512
