; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e 1d 22 STX $221d ; (spentry + 0)
0811 : a2 22 __ LDX #$22
0813 : a0 aa __ LDY #$aa
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 23 __ CPX #$23
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 14 __ CPY #$14
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 62 __ LDA #$62
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  50, "C:/Users/g/claude/cpus/6502/examples/compiler/release/life.c"
.s1:
0880 : a2 0f __ LDX #$0f
0882 : b5 53 __ LDA T0 + 0,x 
0884 : 9d 64 9f STA $9f64,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 47 13 JSR $1347 ; (b_init.s4 + 0)
088d : 20 18 14 JSR $1418 ; (tsb_init.s4 + 0)
0890 : a9 93 __ LDA #$93
0892 : 85 13 __ STA P6 
0894 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
0897 : a9 0d __ LDA #$0d
0899 : 85 13 __ STA P6 
089b : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
089e : a9 00 __ LDA #$00
08a0 : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
08a3 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
.l5:
08a6 : a9 00 __ LDA #$00
08a8 : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
08ab : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
08ae : ad f2 22 LDA $22f2 ; (b_v_ri + 0)
08b1 : 85 57 __ STA T2 + 0 
08b3 : 0a __ __ ASL
08b4 : 85 1b __ STA ACCU + 0 
08b6 : ad f3 22 LDA $22f3 ; (b_v_ri + 1)
08b9 : 85 58 __ STA T2 + 1 
08bb : 2a __ __ ROL
08bc : 06 1b __ ASL ACCU + 0 
08be : 2a __ __ ROL
08bf : aa __ __ TAX
08c0 : 18 __ __ CLC
08c1 : a5 1b __ LDA ACCU + 0 
08c3 : 65 57 __ ADC T2 + 0 
08c5 : 85 53 __ STA T0 + 0 
08c7 : 8a __ __ TXA
08c8 : 65 58 __ ADC T2 + 1 
08ca : 06 53 __ ASL T0 + 0 
08cc : 2a __ __ ROL
08cd : 06 53 __ ASL T0 + 0 
08cf : 2a __ __ ROL
08d0 : 06 53 __ ASL T0 + 0 
08d2 : 2a __ __ ROL
08d3 : aa __ __ TAX
08d4 : a5 53 __ LDA T0 + 0 
08d6 : 8d fa 22 STA $22fa ; (b_t_1 + 0)
08d9 : 18 __ __ CLC
08da : 69 59 __ ADC #$59
08dc : 8d f6 22 STA $22f6 ; (b_t_0 + 0)
08df : 8a __ __ TXA
08e0 : 69 04 __ ADC #$04
08e2 : 8d f7 22 STA $22f7 ; (b_t_0 + 1)
08e5 : 8a __ __ TXA
08e6 : 18 __ __ CLC
08e7 : 69 60 __ ADC #$60
08e9 : 8d fb 22 STA $22fb ; (b_t_1 + 1)
08ec : ad f7 22 LDA $22f7 ; (b_t_0 + 1)
08ef : 29 80 __ AND #$80
08f1 : 10 02 __ BPL $08f5 ; (main.l5 + 79)
08f3 : a9 ff __ LDA #$ff
08f5 : 8d f8 22 STA $22f8 ; (b_t_0 + 2)
08f8 : 8d f9 22 STA $22f9 ; (b_t_0 + 3)
08fb : ad fb 22 LDA $22fb ; (b_t_1 + 1)
08fe : 29 80 __ AND #$80
0900 : 10 02 __ BPL $0904 ; (main.l5 + 94)
0902 : a9 ff __ LDA #$ff
0904 : 8d fc 22 STA $22fc ; (b_t_1 + 2)
0907 : 8d fd 22 STA $22fd ; (b_t_1 + 3)
.l6:
090a : ad f6 22 LDA $22f6 ; (b_t_0 + 0)
090d : 85 53 __ STA T0 + 0 
090f : ad f8 22 LDA $22f8 ; (b_t_0 + 2)
0912 : 85 55 __ STA T0 + 2 
0914 : ad f9 22 LDA $22f9 ; (b_t_0 + 3)
0917 : 85 56 __ STA T0 + 3 
0919 : ad f7 22 LDA $22f7 ; (b_t_0 + 1)
091c : 85 54 __ STA T0 + 1 
091e : c9 e0 __ CMP #$e0
0920 : 90 37 __ BCC $0959 ; (main.s7 + 0)
.s150:
0922 : c9 ff __ CMP #$ff
0924 : d0 04 __ BNE $092a ; (main.s154 + 0)
.s153:
0926 : a5 53 __ LDA T0 + 0 
0928 : c9 40 __ CMP #$40
.s154:
092a : b0 2d __ BCS $0959 ; (main.s7 + 0)
.s151:
092c : ad 1e 22 LDA $221e ; (b_mem + 0)
092f : 85 51 __ STA T1 + 0 
0931 : ad 1f 22 LDA $221f ; (b_mem + 1)
0934 : 85 52 __ STA T1 + 1 
0936 : a0 01 __ LDY #$01
0938 : b1 51 __ LDA (T1 + 0),y 
093a : aa __ __ TAX
093b : 4a __ __ LSR
093c : 90 1b __ BCC $0959 ; (main.s7 + 0)
.s152:
093e : 8a __ __ TXA
093f : 29 fe __ AND #$fe
0941 : 91 51 __ STA (T1 + 0),y 
0943 : a5 53 __ LDA T0 + 0 
0945 : 85 5b __ STA T3 + 0 
0947 : 18 __ __ CLC
0948 : a5 52 __ LDA T1 + 1 
094a : 65 54 __ ADC T0 + 1 
094c : 85 5c __ STA T3 + 1 
094e : a9 20 __ LDA #$20
0950 : a4 51 __ LDY T1 + 0 
0952 : 91 5b __ STA (T3 + 0),y 
0954 : 8a __ __ TXA
0955 : a0 01 __ LDY #$01
0957 : d0 13 __ BNE $096c ; (main.s8 + 0)
.s7:
0959 : ad 1e 22 LDA $221e ; (b_mem + 0)
095c : 18 __ __ CLC
095d : 65 53 __ ADC T0 + 0 
095f : 85 51 __ STA T1 + 0 
0961 : ad 1f 22 LDA $221f ; (b_mem + 1)
0964 : 65 54 __ ADC T0 + 1 
0966 : 85 52 __ STA T1 + 1 
0968 : a9 20 __ LDA #$20
096a : a0 00 __ LDY #$00
.s8:
096c : 91 51 __ STA (T1 + 0),y 
096e : 18 __ __ CLC
096f : a5 53 __ LDA T0 + 0 
0971 : 69 01 __ ADC #$01
0973 : 8d f6 22 STA $22f6 ; (b_t_0 + 0)
0976 : a5 54 __ LDA T0 + 1 
0978 : 69 00 __ ADC #$00
097a : 8d f7 22 STA $22f7 ; (b_t_0 + 1)
097d : a5 55 __ LDA T0 + 2 
097f : 69 00 __ ADC #$00
0981 : 8d f8 22 STA $22f8 ; (b_t_0 + 2)
0984 : a5 56 __ LDA T0 + 3 
0986 : 69 00 __ ADC #$00
0988 : 8d f9 22 STA $22f9 ; (b_t_0 + 3)
098b : ad fa 22 LDA $22fa ; (b_t_1 + 0)
098e : 85 53 __ STA T0 + 0 
0990 : 18 __ __ CLC
0991 : 69 01 __ ADC #$01
0993 : 8d fa 22 STA $22fa ; (b_t_1 + 0)
0996 : ad fb 22 LDA $22fb ; (b_t_1 + 1)
0999 : 85 54 __ STA T0 + 1 
099b : 69 00 __ ADC #$00
099d : 8d fb 22 STA $22fb ; (b_t_1 + 1)
09a0 : 90 08 __ BCC $09aa ; (main.s159 + 0)
.s160:
09a2 : ee fc 22 INC $22fc ; (b_t_1 + 2)
09a5 : d0 03 __ BNE $09aa ; (main.s159 + 0)
.s158:
09a7 : ee fd 22 INC $22fd ; (b_t_1 + 3)
.s159:
09aa : ad f4 22 LDA $22f4 ; (b_v_ci + 0)
09ad : 85 51 __ STA T1 + 0 
09af : 18 __ __ CLC
09b0 : 69 01 __ ADC #$01
09b2 : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
09b5 : ad f5 22 LDA $22f5 ; (b_v_ci + 1)
09b8 : aa __ __ TAX
09b9 : 69 00 __ ADC #$00
09bb : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
09be : a5 54 __ LDA T0 + 1 
09c0 : c9 e0 __ CMP #$e0
09c2 : 90 36 __ BCC $09fa ; (main.s9 + 0)
.s145:
09c4 : c9 ff __ CMP #$ff
09c6 : d0 04 __ BNE $09cc ; (main.s149 + 0)
.s148:
09c8 : a5 53 __ LDA T0 + 0 
09ca : c9 40 __ CMP #$40
.s149:
09cc : b0 2c __ BCS $09fa ; (main.s9 + 0)
.s146:
09ce : ad 1e 22 LDA $221e ; (b_mem + 0)
09d1 : 85 5b __ STA T3 + 0 
09d3 : ad 1f 22 LDA $221f ; (b_mem + 1)
09d6 : 85 5c __ STA T3 + 1 
09d8 : a0 01 __ LDY #$01
09da : b1 5b __ LDA (T3 + 0),y 
09dc : 85 45 __ STA T6 + 0 
09de : 4a __ __ LSR
09df : 90 19 __ BCC $09fa ; (main.s9 + 0)
.s147:
09e1 : a5 45 __ LDA T6 + 0 
09e3 : 29 fe __ AND #$fe
09e5 : 91 5b __ STA (T3 + 0),y 
09e7 : 18 __ __ CLC
09e8 : a5 5c __ LDA T3 + 1 
09ea : 65 54 __ ADC T0 + 1 
09ec : 85 54 __ STA T0 + 1 
09ee : a9 20 __ LDA #$20
09f0 : a4 5b __ LDY T3 + 0 
09f2 : 91 53 __ STA (T0 + 0),y 
09f4 : a5 45 __ LDA T6 + 0 
09f6 : a0 01 __ LDY #$01
09f8 : d0 13 __ BNE $0a0d ; (main.s10 + 0)
.s9:
09fa : ad 1e 22 LDA $221e ; (b_mem + 0)
09fd : 18 __ __ CLC
09fe : 65 53 __ ADC T0 + 0 
0a00 : 85 5b __ STA T3 + 0 
0a02 : ad 1f 22 LDA $221f ; (b_mem + 1)
0a05 : 65 54 __ ADC T0 + 1 
0a07 : 85 5c __ STA T3 + 1 
0a09 : a9 20 __ LDA #$20
0a0b : a0 00 __ LDY #$00
.s10:
0a0d : 91 5b __ STA (T3 + 0),y 
0a0f : 8a __ __ TXA
0a10 : 10 03 __ BPL $0a15 ; (main.s144 + 0)
0a12 : 4c 0a 09 JMP $090a ; (main.l6 + 0)
.s144:
0a15 : d0 06 __ BNE $0a1d ; (main.s11 + 0)
.s143:
0a17 : a9 14 __ LDA #$14
0a19 : c5 51 __ CMP T1 + 0 
0a1b : b0 f5 __ BCS $0a12 ; (main.s10 + 5)
.s11:
0a1d : 18 __ __ CLC
0a1e : a5 57 __ LDA T2 + 0 
0a20 : 69 01 __ ADC #$01
0a22 : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
0a25 : a5 58 __ LDA T2 + 1 
0a27 : 69 00 __ ADC #$00
0a29 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
0a2c : a5 58 __ LDA T2 + 1 
0a2e : 10 03 __ BPL $0a33 ; (main.s142 + 0)
0a30 : 4c a6 08 JMP $08a6 ; (main.l5 + 0)
.s142:
0a33 : d0 06 __ BNE $0a3b ; (main.s12 + 0)
.s141:
0a35 : a9 14 __ LDA #$14
0a37 : c5 57 __ CMP T2 + 0 
0a39 : b0 f5 __ BCS $0a30 ; (main.s11 + 19)
.s12:
0a3b : a9 01 __ LDA #$01
0a3d : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
0a40 : a9 00 __ LDA #$00
0a42 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
0a45 : a9 d7 __ LDA #$d7
0a47 : 8d a6 22 STA $22a6 ; (b_rndSeed + 0)
0a4a : a9 8f __ LDA #$8f
0a4c : 8d a7 22 STA $22a7 ; (b_rndSeed + 1)
0a4f : a9 7d __ LDA #$7d
0a51 : 8d a8 22 STA $22a8 ; (b_rndSeed + 2)
0a54 : a9 66 __ LDA #$66
0a56 : 8d a9 22 STA $22a9 ; (b_rndSeed + 3)
.l13:
0a59 : ad f2 22 LDA $22f2 ; (b_v_ri + 0)
0a5c : 85 51 __ STA T1 + 0 
0a5e : 0a __ __ ASL
0a5f : 85 1b __ STA ACCU + 0 
0a61 : a9 01 __ LDA #$01
0a63 : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
0a66 : ad f3 22 LDA $22f3 ; (b_v_ri + 1)
0a69 : 85 52 __ STA T1 + 1 
0a6b : 2a __ __ ROL
0a6c : 06 1b __ ASL ACCU + 0 
0a6e : 2a __ __ ROL
0a6f : aa __ __ TAX
0a70 : 18 __ __ CLC
0a71 : a5 1b __ LDA ACCU + 0 
0a73 : 65 51 __ ADC T1 + 0 
0a75 : 85 53 __ STA T0 + 0 
0a77 : 8a __ __ TXA
0a78 : 65 52 __ ADC T1 + 1 
0a7a : 06 53 __ ASL T0 + 0 
0a7c : 2a __ __ ROL
0a7d : 06 53 __ ASL T0 + 0 
0a7f : 2a __ __ ROL
0a80 : 06 53 __ ASL T0 + 0 
0a82 : 2a __ __ ROL
0a83 : a8 __ __ TAY
0a84 : 18 __ __ CLC
0a85 : a5 53 __ LDA T0 + 0 
0a87 : 69 59 __ ADC #$59
0a89 : aa __ __ TAX
0a8a : 98 __ __ TYA
0a8b : 69 04 __ ADC #$04
0a8d : a8 __ __ TAY
0a8e : 8a __ __ TXA
0a8f : 18 __ __ CLC
0a90 : 69 01 __ ADC #$01
0a92 : 8d fe 22 STA $22fe ; (b_t_2 + 0)
0a95 : 98 __ __ TYA
0a96 : 69 00 __ ADC #$00
0a98 : 8d ff 22 STA $22ff ; (b_t_2 + 1)
0a9b : 0a __ __ ASL
0a9c : a9 00 __ LDA #$00
0a9e : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
0aa1 : 69 ff __ ADC #$ff
0aa3 : 49 ff __ EOR #$ff
0aa5 : 8d 00 23 STA $2300 ; (b_t_2 + 2)
0aa8 : 8d 01 23 STA $2301 ; (b_t_2 + 3)
.l14:
0aab : ad a6 22 LDA $22a6 ; (b_rndSeed + 0)
0aae : 85 1b __ STA ACCU + 0 
0ab0 : ad a7 22 LDA $22a7 ; (b_rndSeed + 1)
0ab3 : 85 1c __ STA ACCU + 1 
0ab5 : ad a8 22 LDA $22a8 ; (b_rndSeed + 2)
0ab8 : 85 1d __ STA ACCU + 2 
0aba : ad a9 22 LDA $22a9 ; (b_rndSeed + 3)
0abd : 85 1e __ STA ACCU + 3 
0abf : a9 cd __ LDA #$cd
0ac1 : 85 03 __ STA WORK + 0 
0ac3 : a9 00 __ LDA #$00
0ac5 : 85 06 __ STA WORK + 3 
0ac7 : a9 0d __ LDA #$0d
0ac9 : 85 04 __ STA WORK + 1 
0acb : a9 01 __ LDA #$01
0acd : 85 05 __ STA WORK + 2 
0acf : 20 4d 20 JSR $204d ; (mul32 + 0)
0ad2 : 18 __ __ CLC
0ad3 : a5 07 __ LDA WORK + 4 
0ad5 : 69 39 __ ADC #$39
0ad7 : 8d a6 22 STA $22a6 ; (b_rndSeed + 0)
0ada : a5 08 __ LDA WORK + 5 
0adc : 69 30 __ ADC #$30
0ade : 8d a7 22 STA $22a7 ; (b_rndSeed + 1)
0ae1 : 85 1b __ STA ACCU + 0 
0ae3 : a5 09 __ LDA WORK + 6 
0ae5 : 69 00 __ ADC #$00
0ae7 : 8d a8 22 STA $22a8 ; (b_rndSeed + 2)
0aea : 85 1c __ STA ACCU + 1 
0aec : a5 0a __ LDA WORK + 7 
0aee : 69 00 __ ADC #$00
0af0 : 8d a9 22 STA $22a9 ; (b_rndSeed + 3)
0af3 : 85 1d __ STA ACCU + 2 
0af5 : ad f4 22 LDA $22f4 ; (b_v_ci + 0)
0af8 : 85 57 __ STA T2 + 0 
0afa : 18 __ __ CLC
0afb : 69 01 __ ADC #$01
0afd : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
0b00 : ad f5 22 LDA $22f5 ; (b_v_ci + 1)
0b03 : 85 58 __ STA T2 + 1 
0b05 : 69 00 __ ADC #$00
0b07 : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
0b0a : a9 00 __ LDA #$00
0b0c : 85 1e __ STA ACCU + 3 
0b0e : 20 09 20 JSR $2009 ; (uint32_to_float + 0)
0b11 : a9 00 __ LDA #$00
0b13 : 85 03 __ STA WORK + 0 
0b15 : 85 04 __ STA WORK + 1 
0b17 : a9 80 __ LDA #$80
0b19 : 85 05 __ STA WORK + 2 
0b1b : a9 4b __ LDA #$4b
0b1d : 85 06 __ STA WORK + 3 
0b1f : 20 00 1c JSR $1c00 ; (freg + 20)
0b22 : 20 e6 1d JSR $1de6 ; (crt_fdiv + 0)
0b25 : a5 1e __ LDA ACCU + 3 
0b27 : 10 04 __ BPL $0b2d ; (main.s18 + 0)
.s15:
0b29 : a9 01 __ LDA #$01
0b2b : d0 1f __ BNE $0b4c ; (main.s17 + 0)
.s18:
0b2d : c9 3e __ CMP #$3e
0b2f : d0 12 __ BNE $0b43 ; (main.s22 + 0)
.s19:
0b31 : a5 1d __ LDA ACCU + 2 
0b33 : c9 99 __ CMP #$99
0b35 : d0 0c __ BNE $0b43 ; (main.s22 + 0)
.s20:
0b37 : a5 1c __ LDA ACCU + 1 
0b39 : c9 99 __ CMP #$99
0b3b : d0 06 __ BNE $0b43 ; (main.s22 + 0)
.s21:
0b3d : a5 1b __ LDA ACCU + 0 
0b3f : c9 9a __ CMP #$9a
0b41 : f0 07 __ BEQ $0b4a ; (main.s16 + 0)
.s22:
0b43 : a9 00 __ LDA #$00
0b45 : 2a __ __ ROL
0b46 : 49 01 __ EOR #$01
0b48 : 90 02 __ BCC $0b4c ; (main.s17 + 0)
.s16:
0b4a : a9 00 __ LDA #$00
.s17:
0b4c : 49 ff __ EOR #$ff
0b4e : c9 ff __ CMP #$ff
0b50 : f0 57 __ BEQ $0ba9 ; (main.s23 + 0)
.s134:
0b52 : ad fe 22 LDA $22fe ; (b_t_2 + 0)
0b55 : 85 53 __ STA T0 + 0 
0b57 : ad ff 22 LDA $22ff ; (b_t_2 + 1)
0b5a : c9 e0 __ CMP #$e0
0b5c : 90 35 __ BCC $0b93 ; (main.s135 + 0)
.s136:
0b5e : 85 54 __ STA T0 + 1 
0b60 : c9 ff __ CMP #$ff
0b62 : d0 04 __ BNE $0b68 ; (main.s140 + 0)
.s139:
0b64 : a5 53 __ LDA T0 + 0 
0b66 : c9 40 __ CMP #$40
.s140:
0b68 : b0 29 __ BCS $0b93 ; (main.s135 + 0)
.s137:
0b6a : ad 1e 22 LDA $221e ; (b_mem + 0)
0b6d : 85 5b __ STA T3 + 0 
0b6f : ad 1f 22 LDA $221f ; (b_mem + 1)
0b72 : 85 5c __ STA T3 + 1 
0b74 : a0 01 __ LDY #$01
0b76 : b1 5b __ LDA (T3 + 0),y 
0b78 : aa __ __ TAX
0b79 : 4a __ __ LSR
0b7a : 90 17 __ BCC $0b93 ; (main.s135 + 0)
.s138:
0b7c : 8a __ __ TXA
0b7d : 29 fe __ AND #$fe
0b7f : 91 5b __ STA (T3 + 0),y 
0b81 : 18 __ __ CLC
0b82 : a5 5c __ LDA T3 + 1 
0b84 : 65 54 __ ADC T0 + 1 
0b86 : 85 54 __ STA T0 + 1 
0b88 : a9 51 __ LDA #$51
0b8a : a4 5b __ LDY T3 + 0 
0b8c : 91 53 __ STA (T0 + 0),y 
0b8e : 8a __ __ TXA
0b8f : a0 01 __ LDY #$01
0b91 : d0 14 __ BNE $0ba7 ; (main.s156 + 0)
.s135:
0b93 : ad 1e 22 LDA $221e ; (b_mem + 0)
0b96 : 18 __ __ CLC
0b97 : 65 53 __ ADC T0 + 0 
0b99 : 85 5b __ STA T3 + 0 
0b9b : ad 1f 22 LDA $221f ; (b_mem + 1)
0b9e : 6d ff 22 ADC $22ff ; (b_t_2 + 1)
0ba1 : 85 5c __ STA T3 + 1 
0ba3 : a9 51 __ LDA #$51
0ba5 : a0 00 __ LDY #$00
.s156:
0ba7 : 91 5b __ STA (T3 + 0),y 
.s23:
0ba9 : ee fe 22 INC $22fe ; (b_t_2 + 0)
0bac : d0 0d __ BNE $0bbb ; (main.s162 + 0)
.s183:
0bae : ee ff 22 INC $22ff ; (b_t_2 + 1)
0bb1 : d0 08 __ BNE $0bbb ; (main.s162 + 0)
.s163:
0bb3 : ee 00 23 INC $2300 ; (b_t_2 + 2)
0bb6 : d0 03 __ BNE $0bbb ; (main.s162 + 0)
.s161:
0bb8 : ee 01 23 INC $2301 ; (b_t_2 + 3)
.s162:
0bbb : a5 58 __ LDA T2 + 1 
0bbd : 10 03 __ BPL $0bc2 ; (main.s133 + 0)
0bbf : 4c ab 0a JMP $0aab ; (main.l14 + 0)
.s133:
0bc2 : d0 06 __ BNE $0bca ; (main.s24 + 0)
.s132:
0bc4 : a9 13 __ LDA #$13
0bc6 : c5 57 __ CMP T2 + 0 
0bc8 : b0 f5 __ BCS $0bbf ; (main.s162 + 4)
.s24:
0bca : 18 __ __ CLC
0bcb : a5 51 __ LDA T1 + 0 
0bcd : 69 01 __ ADC #$01
0bcf : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
0bd2 : a5 52 __ LDA T1 + 1 
0bd4 : 69 00 __ ADC #$00
0bd6 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
0bd9 : a5 52 __ LDA T1 + 1 
0bdb : 10 03 __ BPL $0be0 ; (main.s131 + 0)
0bdd : 4c 59 0a JMP $0a59 ; (main.l13 + 0)
.s131:
0be0 : d0 06 __ BNE $0be8 ; (main.s25 + 0)
.s130:
0be2 : a9 13 __ LDA #$13
0be4 : c5 51 __ CMP T1 + 0 
0be6 : b0 f5 __ BCS $0bdd ; (main.s24 + 19)
.s25:
0be8 : 20 b4 16 JSR $16b4 ; (b_jiffy.s4 + 0)
0beb : 20 80 1f JSR $1f80 ; (f32_to_i32 + 0)
0bee : a5 1b __ LDA ACCU + 0 
0bf0 : 85 5d __ STA T4 + 0 
0bf2 : a5 1c __ LDA ACCU + 1 
0bf4 : 85 5e __ STA T4 + 1 
0bf6 : a5 1d __ LDA ACCU + 2 
0bf8 : 85 5f __ STA T4 + 2 
0bfa : a5 1e __ LDA ACCU + 3 
0bfc : 85 60 __ STA T4 + 3 
0bfe : a9 01 __ LDA #$01
0c00 : 8d 02 23 STA $2302 ; (b_v_ki + 0)
0c03 : a9 00 __ LDA #$00
0c05 : 8d 03 23 STA $2303 ; (b_v_ki + 1)
0c08 : ad 1e 22 LDA $221e ; (b_mem + 0)
0c0b : 85 61 __ STA T9 + 0 
0c0d : ad 1f 22 LDA $221f ; (b_mem + 1)
0c10 : 85 62 __ STA T9 + 1 
.l26:
0c12 : a9 01 __ LDA #$01
0c14 : 8d 04 23 STA $2304 ; (b_v_xi + 0)
0c17 : a9 00 __ LDA #$00
0c19 : 8d 05 23 STA $2305 ; (b_v_xi + 1)
.l27:
0c1c : ad 04 23 LDA $2304 ; (b_v_xi + 0)
0c1f : 85 43 __ STA T5 + 0 
0c21 : 0a __ __ ASL
0c22 : 85 1b __ STA ACCU + 0 
0c24 : a9 01 __ LDA #$01
0c26 : 8d 0a 23 STA $230a ; (b_v_yi + 0)
0c29 : ad 05 23 LDA $2305 ; (b_v_xi + 1)
0c2c : 85 44 __ STA T5 + 1 
0c2e : 2a __ __ ROL
0c2f : 06 1b __ ASL ACCU + 0 
0c31 : 2a __ __ ROL
0c32 : aa __ __ TAX
0c33 : 18 __ __ CLC
0c34 : a5 1b __ LDA ACCU + 0 
0c36 : 65 43 __ ADC T5 + 0 
0c38 : 85 53 __ STA T0 + 0 
0c3a : 8a __ __ TXA
0c3b : 65 44 __ ADC T5 + 1 
0c3d : 06 53 __ ASL T0 + 0 
0c3f : 2a __ __ ROL
0c40 : 06 53 __ ASL T0 + 0 
0c42 : 2a __ __ ROL
0c43 : 06 53 __ ASL T0 + 0 
0c45 : 2a __ __ ROL
0c46 : aa __ __ TAX
0c47 : 18 __ __ CLC
0c48 : a5 53 __ LDA T0 + 0 
0c4a : 69 5a __ ADC #$5a
0c4c : 8d 06 23 STA $2306 ; (b_v_bbi + 0)
0c4f : 8a __ __ TXA
0c50 : 69 04 __ ADC #$04
0c52 : 8d 07 23 STA $2307 ; (b_v_bbi + 1)
0c55 : 0a __ __ ASL
0c56 : a9 00 __ LDA #$00
0c58 : 8d 0b 23 STA $230b ; (b_v_yi + 1)
0c5b : 69 ff __ ADC #$ff
0c5d : 49 ff __ EOR #$ff
0c5f : 8d 08 23 STA $2308 ; (b_v_bbi + 2)
0c62 : 8d 09 23 STA $2309 ; (b_v_bbi + 3)
0c65 : ad 06 23 LDA $2306 ; (b_v_bbi + 0)
0c68 : 18 __ __ CLC
0c69 : 69 a7 __ ADC #$a7
0c6b : 8d 0c 23 STA $230c ; (b_v_nbi + 0)
0c6e : ad 07 23 LDA $2307 ; (b_v_bbi + 1)
0c71 : 69 5b __ ADC #$5b
0c73 : 8d 0d 23 STA $230d ; (b_v_nbi + 1)
0c76 : ad 08 23 LDA $2308 ; (b_v_bbi + 2)
0c79 : 69 00 __ ADC #$00
0c7b : 8d 0e 23 STA $230e ; (b_v_nbi + 2)
0c7e : ad 09 23 LDA $2309 ; (b_v_bbi + 3)
0c81 : 69 00 __ ADC #$00
0c83 : 8d 0f 23 STA $230f ; (b_v_nbi + 3)
.l28:
0c86 : ad 06 23 LDA $2306 ; (b_v_bbi + 0)
0c89 : 85 53 __ STA T0 + 0 
0c8b : 38 __ __ SEC
0c8c : e9 29 __ SBC #$29
0c8e : 85 51 __ STA T1 + 0 
0c90 : ad 07 23 LDA $2307 ; (b_v_bbi + 1)
0c93 : 85 54 __ STA T0 + 1 
0c95 : e9 00 __ SBC #$00
0c97 : 18 __ __ CLC
0c98 : 65 62 __ ADC T9 + 1 
0c9a : 85 52 __ STA T1 + 1 
0c9c : a4 61 __ LDY T9 + 0 
0c9e : b1 51 __ LDA (T1 + 0),y 
0ca0 : 85 57 __ STA T2 + 0 
0ca2 : 38 __ __ SEC
0ca3 : a5 53 __ LDA T0 + 0 
0ca5 : e9 28 __ SBC #$28
0ca7 : 85 51 __ STA T1 + 0 
0ca9 : a5 54 __ LDA T0 + 1 
0cab : e9 00 __ SBC #$00
0cad : 18 __ __ CLC
0cae : 65 62 __ ADC T9 + 1 
0cb0 : 85 52 __ STA T1 + 1 
0cb2 : b1 51 __ LDA (T1 + 0),y 
0cb4 : 85 5b __ STA T3 + 0 
0cb6 : 38 __ __ SEC
0cb7 : a5 53 __ LDA T0 + 0 
0cb9 : e9 27 __ SBC #$27
0cbb : 85 51 __ STA T1 + 0 
0cbd : a5 54 __ LDA T0 + 1 
0cbf : e9 00 __ SBC #$00
0cc1 : 18 __ __ CLC
0cc2 : 65 62 __ ADC T9 + 1 
0cc4 : 85 52 __ STA T1 + 1 
0cc6 : b1 51 __ LDA (T1 + 0),y 
0cc8 : 85 45 __ STA T6 + 0 
0cca : 38 __ __ SEC
0ccb : a5 53 __ LDA T0 + 0 
0ccd : e9 01 __ SBC #$01
0ccf : 85 51 __ STA T1 + 0 
0cd1 : a5 54 __ LDA T0 + 1 
0cd3 : e9 00 __ SBC #$00
0cd5 : 18 __ __ CLC
0cd6 : 65 62 __ ADC T9 + 1 
0cd8 : 85 52 __ STA T1 + 1 
0cda : b1 51 __ LDA (T1 + 0),y 
0cdc : 85 47 __ STA T7 + 0 
0cde : 98 __ __ TYA
0cdf : 18 __ __ CLC
0ce0 : 65 53 __ ADC T0 + 0 
0ce2 : 85 51 __ STA T1 + 0 
0ce4 : a5 62 __ LDA T9 + 1 
0ce6 : 65 54 __ ADC T0 + 1 
0ce8 : 85 52 __ STA T1 + 1 
0cea : a0 01 __ LDY #$01
0cec : b1 51 __ LDA (T1 + 0),y 
0cee : aa __ __ TAX
0cef : a0 27 __ LDY #$27
0cf1 : b1 51 __ LDA (T1 + 0),y 
0cf3 : 85 4b __ STA T10 + 0 
0cf5 : c8 __ __ INY
0cf6 : b1 51 __ LDA (T1 + 0),y 
0cf8 : 85 4c __ STA T11 + 0 
0cfa : c8 __ __ INY
0cfb : b1 51 __ LDA (T1 + 0),y 
0cfd : 85 4d __ STA T12 + 0 
0cff : a0 00 __ LDY #$00
0d01 : b1 51 __ LDA (T1 + 0),y 
0d03 : 85 4e __ STA T13 + 0 
0d05 : 18 __ __ CLC
0d06 : a5 53 __ LDA T0 + 0 
0d08 : 69 01 __ ADC #$01
0d0a : 85 53 __ STA T0 + 0 
0d0c : a5 54 __ LDA T0 + 1 
0d0e : 69 00 __ ADC #$00
0d10 : 85 54 __ STA T0 + 1 
0d12 : ad 08 23 LDA $2308 ; (b_v_bbi + 2)
0d15 : 69 00 __ ADC #$00
0d17 : 85 55 __ STA T0 + 2 
0d19 : ad 09 23 LDA $2309 ; (b_v_bbi + 3)
0d1c : 69 00 __ ADC #$00
0d1e : 85 56 __ STA T0 + 3 
0d20 : 18 __ __ CLC
0d21 : a5 5b __ LDA T3 + 0 
0d23 : 65 57 __ ADC T2 + 0 
0d25 : a8 __ __ TAY
0d26 : a9 00 __ LDA #$00
0d28 : 2a __ __ ROL
0d29 : 85 52 __ STA T1 + 1 
0d2b : 98 __ __ TYA
0d2c : 65 45 __ ADC T6 + 0 
0d2e : 90 03 __ BCC $0d33 ; (main.s165 + 0)
.s164:
0d30 : e6 52 __ INC T1 + 1 
0d32 : 18 __ __ CLC
.s165:
0d33 : 65 47 __ ADC T7 + 0 
0d35 : 85 51 __ STA T1 + 0 
0d37 : a4 52 __ LDY T1 + 1 
0d39 : 90 02 __ BCC $0d3d ; (main.s167 + 0)
.s166:
0d3b : c8 __ __ INY
0d3c : 18 __ __ CLC
.s167:
0d3d : 8a __ __ TXA
0d3e : 65 51 __ ADC T1 + 0 
0d40 : 90 02 __ BCC $0d44 ; (main.s169 + 0)
.s168:
0d42 : c8 __ __ INY
0d43 : 18 __ __ CLC
.s169:
0d44 : 65 4b __ ADC T10 + 0 
0d46 : 90 02 __ BCC $0d4a ; (main.s171 + 0)
.s170:
0d48 : c8 __ __ INY
0d49 : 18 __ __ CLC
.s171:
0d4a : 65 4c __ ADC T11 + 0 
0d4c : 90 02 __ BCC $0d50 ; (main.s173 + 0)
.s172:
0d4e : c8 __ __ INY
0d4f : 18 __ __ CLC
.s173:
0d50 : 65 4d __ ADC T12 + 0 
0d52 : 85 51 __ STA T1 + 0 
0d54 : 90 01 __ BCC $0d57 ; (main.s175 + 0)
.s174:
0d56 : c8 __ __ INY
.s175:
0d57 : 84 52 __ STY T1 + 1 
0d59 : ad 0c 23 LDA $230c ; (b_v_nbi + 0)
0d5c : 85 57 __ STA T2 + 0 
0d5e : ad 0e 23 LDA $230e ; (b_v_nbi + 2)
0d61 : 85 59 __ STA T2 + 2 
0d63 : ad 0f 23 LDA $230f ; (b_v_nbi + 3)
0d66 : 85 5a __ STA T2 + 3 
0d68 : ad 0d 23 LDA $230d ; (b_v_nbi + 1)
0d6b : 85 58 __ STA T2 + 1 
0d6d : c9 e0 __ CMP #$e0
0d6f : a9 00 __ LDA #$00
0d71 : 6a __ __ ROR
0d72 : 85 47 __ STA T7 + 0 
0d74 : f0 31 __ BEQ $0da7 ; (main.s29 + 0)
.s125:
0d76 : a5 58 __ LDA T2 + 1 
0d78 : c9 ff __ CMP #$ff
0d7a : d0 04 __ BNE $0d80 ; (main.s129 + 0)
.s128:
0d7c : a5 57 __ LDA T2 + 0 
0d7e : c9 40 __ CMP #$40
.s129:
0d80 : b0 25 __ BCS $0da7 ; (main.s29 + 0)
.s126:
0d82 : a0 01 __ LDY #$01
0d84 : b1 61 __ LDA (T9 + 0),y 
0d86 : aa __ __ TAX
0d87 : 4a __ __ LSR
0d88 : 90 1d __ BCC $0da7 ; (main.s29 + 0)
.s127:
0d8a : 8a __ __ TXA
0d8b : 29 fe __ AND #$fe
0d8d : 91 61 __ STA (T9 + 0),y 
0d8f : a5 57 __ LDA T2 + 0 
0d91 : 85 5b __ STA T3 + 0 
0d93 : 18 __ __ CLC
0d94 : a5 62 __ LDA T9 + 1 
0d96 : 65 58 __ ADC T2 + 1 
0d98 : 85 5c __ STA T3 + 1 
0d9a : a9 20 __ LDA #$20
0d9c : a4 61 __ LDY T9 + 0 
0d9e : 91 5b __ STA (T3 + 0),y 
0da0 : 8a __ __ TXA
0da1 : a0 01 __ LDY #$01
0da3 : 91 61 __ STA (T9 + 0),y 
0da5 : d0 11 __ BNE $0db8 ; (main.s30 + 0)
.s29:
0da7 : a5 57 __ LDA T2 + 0 
0da9 : 85 5b __ STA T3 + 0 
0dab : 18 __ __ CLC
0dac : a5 62 __ LDA T9 + 1 
0dae : 65 58 __ ADC T2 + 1 
0db0 : 85 5c __ STA T3 + 1 
0db2 : a9 20 __ LDA #$20
0db4 : a4 61 __ LDY T9 + 0 
0db6 : 91 5b __ STA (T3 + 0),y 
.s30:
0db8 : a5 53 __ LDA T0 + 0 
0dba : 8d 06 23 STA $2306 ; (b_v_bbi + 0)
0dbd : a5 54 __ LDA T0 + 1 
0dbf : 8d 07 23 STA $2307 ; (b_v_bbi + 1)
0dc2 : a5 55 __ LDA T0 + 2 
0dc4 : 8d 08 23 STA $2308 ; (b_v_bbi + 2)
0dc7 : a5 56 __ LDA T0 + 3 
0dc9 : 8d 09 23 STA $2309 ; (b_v_bbi + 3)
0dcc : 18 __ __ CLC
0dcd : a5 57 __ LDA T2 + 0 
0dcf : 69 01 __ ADC #$01
0dd1 : 8d 0c 23 STA $230c ; (b_v_nbi + 0)
0dd4 : a5 58 __ LDA T2 + 1 
0dd6 : 69 00 __ ADC #$00
0dd8 : 8d 0d 23 STA $230d ; (b_v_nbi + 1)
0ddb : a5 59 __ LDA T2 + 2 
0ddd : 69 00 __ ADC #$00
0ddf : 8d 0e 23 STA $230e ; (b_v_nbi + 2)
0de2 : a5 5a __ LDA T2 + 3 
0de4 : 69 00 __ ADC #$00
0de6 : 8d 0f 23 STA $230f ; (b_v_nbi + 3)
0de9 : ad 0a 23 LDA $230a ; (b_v_yi + 0)
0dec : 85 45 __ STA T6 + 0 
0dee : 18 __ __ CLC
0def : 69 01 __ ADC #$01
0df1 : 8d 0a 23 STA $230a ; (b_v_yi + 0)
0df4 : ad 0b 23 LDA $230b ; (b_v_yi + 1)
0df7 : aa __ __ TAX
0df8 : 69 00 __ ADC #$00
0dfa : 8d 0b 23 STA $230b ; (b_v_yi + 1)
0dfd : a5 4e __ LDA T13 + 0 
0dff : c9 51 __ CMP #$51
0e01 : d0 04 __ BNE $0e07 ; (main.s32 + 0)
.s31:
0e03 : a9 01 __ LDA #$01
0e05 : d0 02 __ BNE $0e09 ; (main.s33 + 0)
.s32:
0e07 : a9 00 __ LDA #$00
.s33:
0e09 : 49 ff __ EOR #$ff
0e0b : 18 __ __ CLC
0e0c : 69 01 __ ADC #$01
0e0e : 85 53 __ STA T0 + 0 
0e10 : a4 52 __ LDY T1 + 1 
0e12 : 88 __ __ DEY
0e13 : d0 0a __ BNE $0e1f ; (main.s35 + 0)
.s37:
0e15 : a5 51 __ LDA T1 + 0 
0e17 : c9 62 __ CMP #$62
0e19 : d0 04 __ BNE $0e1f ; (main.s35 + 0)
.s34:
0e1b : a9 01 __ LDA #$01
0e1d : d0 02 __ BNE $0e21 ; (main.s36 + 0)
.s35:
0e1f : a9 00 __ LDA #$00
.s36:
0e21 : 49 ff __ EOR #$ff
0e23 : 18 __ __ CLC
0e24 : 69 01 __ ADC #$01
0e26 : 25 53 __ AND T0 + 0 
0e28 : 85 53 __ STA T0 + 0 
0e2a : c8 __ __ INY
0e2b : 88 __ __ DEY
0e2c : d0 0a __ BNE $0e38 ; (main.s39 + 0)
.s41:
0e2e : a5 51 __ LDA T1 + 0 
0e30 : c9 93 __ CMP #$93
0e32 : d0 04 __ BNE $0e38 ; (main.s39 + 0)
.s38:
0e34 : a9 01 __ LDA #$01
0e36 : d0 02 __ BNE $0e3a ; (main.s40 + 0)
.s39:
0e38 : a9 00 __ LDA #$00
.s40:
0e3a : 49 ff __ EOR #$ff
0e3c : 18 __ __ CLC
0e3d : 69 01 __ ADC #$01
0e3f : 05 53 __ ORA T0 + 0 
0e41 : f0 49 __ BEQ $0e8c ; (main.s42 + 0)
.s118:
0e43 : 24 47 __ BIT T7 + 0 
0e45 : 10 34 __ BPL $0e7b ; (main.s119 + 0)
.s120:
0e47 : a5 58 __ LDA T2 + 1 
0e49 : c9 ff __ CMP #$ff
0e4b : d0 04 __ BNE $0e51 ; (main.s124 + 0)
.s123:
0e4d : a5 57 __ LDA T2 + 0 
0e4f : c9 40 __ CMP #$40
.s124:
0e51 : b0 28 __ BCS $0e7b ; (main.s119 + 0)
.s121:
0e53 : a0 01 __ LDY #$01
0e55 : b1 61 __ LDA (T9 + 0),y 
0e57 : 85 5b __ STA T3 + 0 
0e59 : 4a __ __ LSR
0e5a : 90 1f __ BCC $0e7b ; (main.s119 + 0)
.s122:
0e5c : a5 5b __ LDA T3 + 0 
0e5e : 29 fe __ AND #$fe
0e60 : 91 61 __ STA (T9 + 0),y 
0e62 : a5 57 __ LDA T2 + 0 
0e64 : 85 53 __ STA T0 + 0 
0e66 : 18 __ __ CLC
0e67 : a5 62 __ LDA T9 + 1 
0e69 : 65 58 __ ADC T2 + 1 
0e6b : 85 54 __ STA T0 + 1 
0e6d : a9 51 __ LDA #$51
0e6f : a4 61 __ LDY T9 + 0 
0e71 : 91 53 __ STA (T0 + 0),y 
0e73 : a5 5b __ LDA T3 + 0 
0e75 : a0 01 __ LDY #$01
0e77 : 91 61 __ STA (T9 + 0),y 
0e79 : d0 11 __ BNE $0e8c ; (main.s42 + 0)
.s119:
0e7b : a5 57 __ LDA T2 + 0 
0e7d : 85 53 __ STA T0 + 0 
0e7f : 18 __ __ CLC
0e80 : a5 62 __ LDA T9 + 1 
0e82 : 65 58 __ ADC T2 + 1 
0e84 : 85 54 __ STA T0 + 1 
0e86 : a9 51 __ LDA #$51
0e88 : a4 61 __ LDY T9 + 0 
0e8a : 91 53 __ STA (T0 + 0),y 
.s42:
0e8c : 8a __ __ TXA
0e8d : 10 03 __ BPL $0e92 ; (main.s117 + 0)
0e8f : 4c 86 0c JMP $0c86 ; (main.l28 + 0)
.s117:
0e92 : d0 06 __ BNE $0e9a ; (main.s43 + 0)
.s116:
0e94 : a9 13 __ LDA #$13
0e96 : c5 45 __ CMP T6 + 0 
0e98 : b0 f5 __ BCS $0e8f ; (main.s42 + 3)
.s43:
0e9a : 18 __ __ CLC
0e9b : a5 43 __ LDA T5 + 0 
0e9d : 69 01 __ ADC #$01
0e9f : 8d 04 23 STA $2304 ; (b_v_xi + 0)
0ea2 : a5 44 __ LDA T5 + 1 
0ea4 : 69 00 __ ADC #$00
0ea6 : 8d 05 23 STA $2305 ; (b_v_xi + 1)
0ea9 : a5 44 __ LDA T5 + 1 
0eab : 10 03 __ BPL $0eb0 ; (main.s115 + 0)
0ead : 4c 1c 0c JMP $0c1c ; (main.l27 + 0)
.s115:
0eb0 : d0 06 __ BNE $0eb8 ; (main.s44 + 0)
.s114:
0eb2 : a9 13 __ LDA #$13
0eb4 : c5 43 __ CMP T5 + 0 
0eb6 : b0 f5 __ BCS $0ead ; (main.s43 + 19)
.s44:
0eb8 : a9 01 __ LDA #$01
0eba : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
0ebd : a9 00 __ LDA #$00
0ebf : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
.l45:
0ec2 : ad f2 22 LDA $22f2 ; (b_v_ri + 0)
0ec5 : 85 51 __ STA T1 + 0 
0ec7 : 0a __ __ ASL
0ec8 : 85 1b __ STA ACCU + 0 
0eca : a9 01 __ LDA #$01
0ecc : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
0ecf : a9 00 __ LDA #$00
0ed1 : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
0ed4 : ad f3 22 LDA $22f3 ; (b_v_ri + 1)
0ed7 : 85 52 __ STA T1 + 1 
0ed9 : 2a __ __ ROL
0eda : 06 1b __ ASL ACCU + 0 
0edc : 2a __ __ ROL
0edd : aa __ __ TAX
0ede : 18 __ __ CLC
0edf : a5 1b __ LDA ACCU + 0 
0ee1 : 65 51 __ ADC T1 + 0 
0ee3 : 85 53 __ STA T0 + 0 
0ee5 : 8a __ __ TXA
0ee6 : 65 52 __ ADC T1 + 1 
0ee8 : 06 53 __ ASL T0 + 0 
0eea : 2a __ __ ROL
0eeb : 06 53 __ ASL T0 + 0 
0eed : 2a __ __ ROL
0eee : 06 53 __ ASL T0 + 0 
0ef0 : 2a __ __ ROL
0ef1 : aa __ __ TAX
0ef2 : a5 53 __ LDA T0 + 0 
0ef4 : 85 5b __ STA T3 + 0 
0ef6 : 18 __ __ CLC
0ef7 : 69 59 __ ADC #$59
0ef9 : 85 57 __ STA T2 + 0 
0efb : 8a __ __ TXA
0efc : 69 04 __ ADC #$04
0efe : 85 58 __ STA T2 + 1 
0f00 : 8a __ __ TXA
0f01 : 18 __ __ CLC
0f02 : 69 60 __ ADC #$60
0f04 : 85 5c __ STA T3 + 1 
.l46:
0f06 : ad f4 22 LDA $22f4 ; (b_v_ci + 0)
0f09 : 85 43 __ STA T5 + 0 
0f0b : 18 __ __ CLC
0f0c : 69 01 __ ADC #$01
0f0e : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
0f11 : ad f5 22 LDA $22f5 ; (b_v_ci + 1)
0f14 : 85 44 __ STA T5 + 1 
0f16 : 69 00 __ ADC #$00
0f18 : 8d f5 22 STA $22f5 ; (b_v_ci + 1)
0f1b : 18 __ __ CLC
0f1c : a5 43 __ LDA T5 + 0 
0f1e : 65 5b __ ADC T3 + 0 
0f20 : 85 53 __ STA T0 + 0 
0f22 : a5 44 __ LDA T5 + 1 
0f24 : 65 5c __ ADC T3 + 1 
0f26 : 18 __ __ CLC
0f27 : 65 62 __ ADC T9 + 1 
0f29 : 85 54 __ STA T0 + 1 
0f2b : a4 61 __ LDY T9 + 0 
0f2d : b1 53 __ LDA (T0 + 0),y 
0f2f : 85 53 __ STA T0 + 0 
0f31 : 18 __ __ CLC
0f32 : a5 57 __ LDA T2 + 0 
0f34 : 65 43 __ ADC T5 + 0 
0f36 : 85 45 __ STA T6 + 0 
0f38 : a5 58 __ LDA T2 + 1 
0f3a : 65 44 __ ADC T5 + 1 
0f3c : 85 46 __ STA T6 + 1 
0f3e : c9 e0 __ CMP #$e0
0f40 : 90 2d __ BCC $0f6f ; (main.s47 + 0)
.s109:
0f42 : c9 ff __ CMP #$ff
0f44 : d0 04 __ BNE $0f4a ; (main.s113 + 0)
.s112:
0f46 : a5 45 __ LDA T6 + 0 
0f48 : c9 40 __ CMP #$40
.s113:
0f4a : b0 23 __ BCS $0f6f ; (main.s47 + 0)
.s110:
0f4c : a0 01 __ LDY #$01
0f4e : b1 61 __ LDA (T9 + 0),y 
0f50 : aa __ __ TAX
0f51 : 4a __ __ LSR
0f52 : 90 19 __ BCC $0f6d ; (main.s187 + 0)
.s111:
0f54 : 8a __ __ TXA
0f55 : 29 fe __ AND #$fe
0f57 : 91 61 __ STA (T9 + 0),y 
0f59 : 18 __ __ CLC
0f5a : a5 62 __ LDA T9 + 1 
0f5c : 65 46 __ ADC T6 + 1 
0f5e : 85 46 __ STA T6 + 1 
0f60 : a5 53 __ LDA T0 + 0 
0f62 : a4 61 __ LDY T9 + 0 
0f64 : 91 45 __ STA (T6 + 0),y 
0f66 : 8a __ __ TXA
0f67 : a0 01 __ LDY #$01
0f69 : 91 61 __ STA (T9 + 0),y 
0f6b : d0 0d __ BNE $0f7a ; (main.s48 + 0)
.s187:
0f6d : a4 61 __ LDY T9 + 0 
.s47:
0f6f : 18 __ __ CLC
0f70 : a5 62 __ LDA T9 + 1 
0f72 : 65 46 __ ADC T6 + 1 
0f74 : 85 46 __ STA T6 + 1 
0f76 : a5 53 __ LDA T0 + 0 
0f78 : 91 45 __ STA (T6 + 0),y 
.s48:
0f7a : a5 44 __ LDA T5 + 1 
0f7c : 30 88 __ BMI $0f06 ; (main.l46 + 0)
.s108:
0f7e : d0 06 __ BNE $0f86 ; (main.s49 + 0)
.s107:
0f80 : a9 13 __ LDA #$13
0f82 : c5 43 __ CMP T5 + 0 
0f84 : b0 80 __ BCS $0f06 ; (main.l46 + 0)
.s49:
0f86 : 18 __ __ CLC
0f87 : a5 51 __ LDA T1 + 0 
0f89 : 69 01 __ ADC #$01
0f8b : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
0f8e : a5 52 __ LDA T1 + 1 
0f90 : 69 00 __ ADC #$00
0f92 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
0f95 : a5 52 __ LDA T1 + 1 
0f97 : 10 03 __ BPL $0f9c ; (main.s106 + 0)
0f99 : 4c c2 0e JMP $0ec2 ; (main.l45 + 0)
.s106:
0f9c : d0 06 __ BNE $0fa4 ; (main.s50 + 0)
.s105:
0f9e : a9 13 __ LDA #$13
0fa0 : c5 51 __ CMP T1 + 0 
0fa2 : b0 f5 __ BCS $0f99 ; (main.s49 + 19)
.s50:
0fa4 : ad 02 23 LDA $2302 ; (b_v_ki + 0)
0fa7 : 85 53 __ STA T0 + 0 
0fa9 : a5 61 __ LDA T9 + 0 
0fab : 85 1f __ STA ADDR + 0 
0fad : 18 __ __ CLC
0fae : a5 62 __ LDA T9 + 1 
0fb0 : 69 04 __ ADC #$04
0fb2 : 85 20 __ STA ADDR + 1 
0fb4 : a9 20 __ LDA #$20
0fb6 : ae 03 23 LDX $2303 ; (b_v_ki + 1)
0fb9 : a0 00 __ LDY #$00
0fbb : 91 1f __ STA (ADDR + 0),y 
0fbd : 18 __ __ CLC
0fbe : a5 53 __ LDA T0 + 0 
0fc0 : 69 01 __ ADC #$01
0fc2 : 8d 02 23 STA $2302 ; (b_v_ki + 0)
0fc5 : 8a __ __ TXA
0fc6 : 69 00 __ ADC #$00
0fc8 : 8d 03 23 STA $2303 ; (b_v_ki + 1)
0fcb : 8a __ __ TXA
0fcc : 10 03 __ BPL $0fd1 ; (main.s104 + 0)
0fce : 4c 12 0c JMP $0c12 ; (main.l26 + 0)
.s104:
0fd1 : d0 06 __ BNE $0fd9 ; (main.s51 + 0)
.s103:
0fd3 : a9 63 __ LDA #$63
0fd5 : c5 53 __ CMP T0 + 0 
0fd7 : b0 f5 __ BCS $0fce ; (main.s50 + 42)
.s51:
0fd9 : a9 13 __ LDA #$13
0fdb : 85 13 __ STA P6 
0fdd : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
0fe0 : a9 05 __ LDA #$05
0fe2 : 85 16 __ STA P9 
0fe4 : a9 16 __ LDA #$16
0fe6 : 85 15 __ STA P8 
0fe8 : a9 00 __ LDA #$00
0fea : 85 17 __ STA P10 
0fec : a9 d5 __ LDA #$d5
0fee : 85 14 __ STA P7 
0ff0 : 20 db 16 JSR $16db ; (b_str.s4 + 0)
0ff3 : 20 b4 16 JSR $16b4 ; (b_jiffy.s4 + 0)
0ff6 : a5 1b __ LDA ACCU + 0 
0ff8 : 85 53 __ STA T0 + 0 
0ffa : a5 1c __ LDA ACCU + 1 
0ffc : 85 54 __ STA T0 + 1 
0ffe : a5 1d __ LDA ACCU + 2 
1000 : 85 55 __ STA T0 + 2 
1002 : a5 1e __ LDA ACCU + 3 
1004 : 85 56 __ STA T0 + 3 
1006 : a5 5d __ LDA T4 + 0 
1008 : 85 1b __ STA ACCU + 0 
100a : a5 5e __ LDA T4 + 1 
100c : 85 1c __ STA ACCU + 1 
100e : a5 5f __ LDA T4 + 2 
1010 : 85 1d __ STA ACCU + 2 
1012 : a5 60 __ LDA T4 + 3 
1014 : 85 1e __ STA ACCU + 3 
1016 : 20 df 1f JSR $1fdf ; (sint32_to_float + 0)
1019 : a2 53 __ LDX #$53
101b : 20 f0 1b JSR $1bf0 ; (freg + 4)
101e : a5 1e __ LDA ACCU + 3 
1020 : 49 80 __ EOR #$80
1022 : 85 1e __ STA ACCU + 3 
1024 : 20 37 1c JSR $1c37 ; (faddsub + 6)
1027 : a5 1b __ LDA ACCU + 0 
1029 : 85 53 __ STA T0 + 0 
102b : a5 1c __ LDA ACCU + 1 
102d : 85 54 __ STA T0 + 1 
102f : a5 1d __ LDA ACCU + 2 
1031 : 85 55 __ STA T0 + 2 
1033 : a5 1e __ LDA ACCU + 3 
1035 : 85 56 __ STA T0 + 3 
1037 : 29 7f __ AND #$7f
1039 : 05 1d __ ORA ACCU + 2 
103b : 05 1c __ ORA ACCU + 1 
103d : 05 1b __ ORA ACCU + 0 
103f : f0 04 __ BEQ $1045 ; (main.s101 + 0)
.s102:
1041 : 24 1e __ BIT ACCU + 3 
1043 : 30 04 __ BMI $1049 ; (main.s52 + 0)
.s101:
1045 : a9 20 __ LDA #$20
1047 : d0 08 __ BNE $1051 ; (main.s53 + 0)
.s52:
1049 : a5 1e __ LDA ACCU + 3 
104b : 49 80 __ EOR #$80
104d : 85 56 __ STA T0 + 3 
104f : a9 2d __ LDA #$2d
.s53:
1051 : 85 13 __ STA P6 
1053 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1056 : a5 56 __ LDA T0 + 3 
1058 : 29 7f __ AND #$7f
105a : 05 55 __ ORA T0 + 2 
105c : 05 54 __ ORA T0 + 1 
105e : 05 53 __ ORA T0 + 0 
1060 : d0 0a __ BNE $106c ; (main.s54 + 0)
.s100:
1062 : a9 30 __ LDA #$30
1064 : 85 13 __ STA P6 
1066 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1069 : 4c dc 10 JMP $10dc ; (main.s56 + 0)
.s54:
106c : a5 53 __ LDA T0 + 0 
106e : 85 0f __ STA P2 
1070 : a5 54 __ LDA T0 + 1 
1072 : 85 10 __ STA P3 
1074 : a5 55 __ LDA T0 + 2 
1076 : 85 11 __ STA P4 
1078 : a5 56 __ LDA T0 + 3 
107a : 85 12 __ STA P5 
107c : a9 a8 __ LDA #$a8
107e : 85 0d __ STA P0 
1080 : a9 9f __ LDA #$9f
1082 : 85 0e __ STA P1 
1084 : 20 01 17 JSR $1701 ; (b_ftoa.s4 + 0)
1087 : a9 2e __ LDA #$2e
1089 : 85 0f __ STA P2 
108b : a9 00 __ LDA #$00
108d : 85 10 __ STA P3 
108f : 20 6b 1b JSR $1b6b ; (strchr.l4 + 0)
1092 : a5 1b __ LDA ACCU + 0 
1094 : 05 1c __ ORA ACCU + 1 
1096 : f0 2d __ BEQ $10c5 ; (main.s55 + 0)
.s93:
1098 : a9 a8 __ LDA #$a8
109a : 85 0d __ STA P0 
109c : a9 9f __ LDA #$9f
109e : 85 0e __ STA P1 
10a0 : 20 8d 1b JSR $1b8d ; (strlen.s4 + 0)
10a3 : a5 1c __ LDA ACCU + 1 
10a5 : 30 1e __ BMI $10c5 ; (main.s55 + 0)
.s99:
10a7 : d0 06 __ BNE $10af ; (main.s157 + 0)
.s98:
10a9 : a5 1b __ LDA ACCU + 0 
10ab : c9 02 __ CMP #$02
10ad : 90 16 __ BCC $10c5 ; (main.s55 + 0)
.s157:
10af : a6 1b __ LDX ACCU + 0 
.l94:
10b1 : bd a7 9f LDA $9fa7,x ; (tmp[0] + 23)
10b4 : c9 30 __ CMP #$30
10b6 : f0 03 __ BEQ $10bb ; (main.s97 + 0)
10b8 : 4c 38 13 JMP $1338 ; (main.s95 + 0)
.s97:
10bb : a9 00 __ LDA #$00
10bd : 9d a7 9f STA $9fa7,x ; (tmp[0] + 23)
10c0 : ca __ __ DEX
10c1 : e0 02 __ CPX #$02
10c3 : b0 ec __ BCS $10b1 ; (main.l94 + 0)
.s55:
10c5 : ad a8 9f LDA $9fa8 ; (buf[0] + 0)
10c8 : f0 12 __ BEQ $10dc ; (main.s56 + 0)
.s92:
10ca : a2 00 __ LDX #$00
10cc : 86 51 __ STX T1 + 0 
.l155:
10ce : 85 13 __ STA P6 
10d0 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
10d3 : e6 51 __ INC T1 + 0 
10d5 : a6 51 __ LDX T1 + 0 
10d7 : bd a8 9f LDA $9fa8,x ; (buf[0] + 0)
10da : d0 f2 __ BNE $10ce ; (main.l155 + 0)
.s56:
10dc : a9 20 __ LDA #$20
10de : 85 13 __ STA P6 
10e0 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
10e3 : a9 0d __ LDA #$0d
10e5 : 85 13 __ STA P6 
10e7 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
10ea : a9 00 __ LDA #$00
10ec : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
10ef : 8d 10 23 STA $2310 ; (b_v_si + 0)
10f2 : 8d 11 23 STA $2311 ; (b_v_si + 1)
10f5 : 8d 12 23 STA $2312 ; (b_v_si + 2)
10f8 : 8d 13 23 STA $2313 ; (b_v_si + 3)
10fb : a9 01 __ LDA #$01
10fd : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
.l57:
1100 : ad f2 22 LDA $22f2 ; (b_v_ri + 0)
1103 : 85 5b __ STA T3 + 0 
1105 : 0a __ __ ASL
1106 : 85 1b __ STA ACCU + 0 
1108 : ad f3 22 LDA $22f3 ; (b_v_ri + 1)
110b : 85 5c __ STA T3 + 1 
110d : 2a __ __ ROL
110e : 06 1b __ ASL ACCU + 0 
1110 : 2a __ __ ROL
1111 : aa __ __ TAX
1112 : 18 __ __ CLC
1113 : a5 1b __ LDA ACCU + 0 
1115 : 65 5b __ ADC T3 + 0 
1117 : 85 53 __ STA T0 + 0 
1119 : 8a __ __ TXA
111a : 65 5c __ ADC T3 + 1 
111c : 06 53 __ ASL T0 + 0 
111e : 2a __ __ ROL
111f : 06 53 __ ASL T0 + 0 
1121 : 2a __ __ ROL
1122 : 06 53 __ ASL T0 + 0 
1124 : 2a __ __ ROL
1125 : aa __ __ TAX
1126 : 18 __ __ CLC
1127 : a5 53 __ LDA T0 + 0 
1129 : 69 59 __ ADC #$59
112b : a8 __ __ TAY
112c : 8a __ __ TXA
112d : 69 04 __ ADC #$04
112f : aa __ __ TAX
1130 : 98 __ __ TYA
1131 : 18 __ __ CLC
1132 : 69 01 __ ADC #$01
1134 : 90 02 __ BCC $1138 ; (main.s177 + 0)
.s176:
1136 : e8 __ __ INX
1137 : 18 __ __ CLC
.s177:
1138 : 65 61 __ ADC T9 + 0 
113a : 85 5d __ STA T4 + 0 
113c : 8a __ __ TXA
113d : 65 62 __ ADC T9 + 1 
113f : 85 5e __ STA T4 + 1 
1141 : ad 10 23 LDA $2310 ; (b_v_si + 0)
1144 : 85 57 __ STA T2 + 0 
1146 : ad 11 23 LDA $2311 ; (b_v_si + 1)
1149 : 85 58 __ STA T2 + 1 
114b : ad 12 23 LDA $2312 ; (b_v_si + 2)
114e : 85 59 __ STA T2 + 2 
1150 : ad 13 23 LDA $2313 ; (b_v_si + 3)
1153 : 85 5a __ STA T2 + 3 
1155 : a2 01 __ LDX #$01
.l58:
1157 : a0 00 __ LDY #$00
1159 : b1 5d __ LDA (T4 + 0),y 
115b : c9 51 __ CMP #$51
115d : f0 05 __ BEQ $1164 ; (main.s59 + 0)
.s60:
115f : a5 57 __ LDA T2 + 0 
1161 : 18 __ __ CLC
1162 : 90 04 __ BCC $1168 ; (main.s61 + 0)
.s59:
1164 : a5 57 __ LDA T2 + 0 
1166 : 69 00 __ ADC #$00
.s61:
1168 : 85 57 __ STA T2 + 0 
116a : 90 0a __ BCC $1176 ; (main.s179 + 0)
.s184:
116c : e6 58 __ INC T2 + 1 
116e : d0 06 __ BNE $1176 ; (main.s179 + 0)
.s180:
1170 : e6 59 __ INC T2 + 2 
1172 : d0 02 __ BNE $1176 ; (main.s179 + 0)
.s178:
1174 : e6 5a __ INC T2 + 3 
.s179:
1176 : e6 5d __ INC T4 + 0 
1178 : d0 02 __ BNE $117c ; (main.s182 + 0)
.s181:
117a : e6 5e __ INC T4 + 1 
.s182:
117c : e8 __ __ INX
117d : e0 15 __ CPX #$15
117f : 90 d6 __ BCC $1157 ; (main.l58 + 0)
.s62:
1181 : 8c f5 22 STY $22f5 ; (b_v_ci + 1)
1184 : 8d 10 23 STA $2310 ; (b_v_si + 0)
1187 : a5 58 __ LDA T2 + 1 
1189 : 8d 11 23 STA $2311 ; (b_v_si + 1)
118c : a9 15 __ LDA #$15
118e : 8d f4 22 STA $22f4 ; (b_v_ci + 0)
1191 : a5 59 __ LDA T2 + 2 
1193 : 8d 12 23 STA $2312 ; (b_v_si + 2)
1196 : a5 5a __ LDA T2 + 3 
1198 : 8d 13 23 STA $2313 ; (b_v_si + 3)
119b : a5 5b __ LDA T3 + 0 
119d : 69 00 __ ADC #$00
119f : 8d f2 22 STA $22f2 ; (b_v_ri + 0)
11a2 : a5 5c __ LDA T3 + 1 
11a4 : 69 00 __ ADC #$00
11a6 : 8d f3 22 STA $22f3 ; (b_v_ri + 1)
11a9 : a5 5c __ LDA T3 + 1 
11ab : 10 03 __ BPL $11b0 ; (main.s91 + 0)
11ad : 4c 00 11 JMP $1100 ; (main.l57 + 0)
.s91:
11b0 : d0 06 __ BNE $11b8 ; (main.s63 + 0)
.s90:
11b2 : a9 13 __ LDA #$13
11b4 : c5 5b __ CMP T3 + 0 
11b6 : b0 f5 __ BCS $11ad ; (main.s62 + 44)
.s63:
11b8 : 84 17 __ STY P10 
11ba : a9 05 __ LDA #$05
11bc : 85 16 __ STA P9 
11be : a9 1b __ LDA #$1b
11c0 : 85 15 __ STA P8 
11c2 : a9 a9 __ LDA #$a9
11c4 : 85 14 __ STA P7 
11c6 : 20 db 16 JSR $16db ; (b_str.s4 + 0)
11c9 : a9 20 __ LDA #$20
11cb : 85 13 __ STA P6 
11cd : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
11d0 : a9 00 __ LDA #$00
11d2 : 85 5d __ STA T4 + 0 
11d4 : 85 55 __ STA T0 + 2 
11d6 : 85 56 __ STA T0 + 3 
11d8 : a8 __ __ TAY
11d9 : a9 64 __ LDA #$64
11db : 85 53 __ STA T0 + 0 
.l64:
11dd : a5 5d __ LDA T4 + 0 
11df : c9 17 __ CMP #$17
11e1 : b0 4a __ BCS $122d ; (main.l65 + 0)
.s86:
11e3 : 84 1c __ STY ACCU + 1 
11e5 : a5 53 __ LDA T0 + 0 
11e7 : 85 1b __ STA ACCU + 0 
11e9 : a5 55 __ LDA T0 + 2 
11eb : 85 1d __ STA ACCU + 2 
11ed : a5 56 __ LDA T0 + 3 
11ef : 85 1e __ STA ACCU + 3 
11f1 : a9 00 __ LDA #$00
11f3 : 85 04 __ STA WORK + 1 
11f5 : 85 05 __ STA WORK + 2 
11f7 : 85 06 __ STA WORK + 3 
11f9 : a9 0a __ LDA #$0a
11fb : 85 03 __ STA WORK + 0 
11fd : 20 07 21 JSR $2107 ; (divmod32 + 0)
1200 : a5 1b __ LDA ACCU + 0 
1202 : 85 53 __ STA T0 + 0 
1204 : a5 1d __ LDA ACCU + 2 
1206 : 85 55 __ STA T0 + 2 
1208 : a5 1e __ LDA ACCU + 3 
120a : 85 56 __ STA T0 + 3 
120c : 18 __ __ CLC
120d : a5 07 __ LDA WORK + 4 
120f : 69 30 __ ADC #$30
1211 : a6 5d __ LDX T4 + 0 
1213 : 9d 90 9f STA $9f90,x ; (tmp[0] + 0)
1216 : a9 00 __ LDA #$00
1218 : e6 5d __ INC T4 + 0 
121a : a4 1c __ LDY ACCU + 1 
121c : c5 1e __ CMP ACCU + 3 
121e : 90 bd __ BCC $11dd ; (main.l64 + 0)
.s185:
1220 : d0 0b __ BNE $122d ; (main.l65 + 0)
.s87:
1222 : a5 1d __ LDA ACCU + 2 
1224 : d0 b7 __ BNE $11dd ; (main.l64 + 0)
.s88:
1226 : 98 __ __ TYA
1227 : d0 b4 __ BNE $11dd ; (main.l64 + 0)
.s89:
1229 : c4 1b __ CPY ACCU + 0 
122b : 90 b0 __ BCC $11dd ; (main.l64 + 0)
.l65:
122d : a6 5d __ LDX T4 + 0 
122f : bd 8f 9f LDA $9f8f,x ; (tmp[0] + 23)
1232 : 85 13 __ STA P6 
1234 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1237 : c6 5d __ DEC T4 + 0 
1239 : d0 f2 __ BNE $122d ; (main.l65 + 0)
.s66:
123b : a9 20 __ LDA #$20
123d : 85 13 __ STA P6 
123f : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1242 : a9 0d __ LDA #$0d
1244 : 85 13 __ STA P6 
1246 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1249 : a9 00 __ LDA #$00
124b : 85 5b __ STA T3 + 0 
124d : 85 17 __ STA P10 
124f : a9 06 __ LDA #$06
1251 : 85 16 __ STA P9 
1253 : a9 af __ LDA #$af
1255 : 85 14 __ STA P7 
1257 : a9 1b __ LDA #$1b
1259 : 85 15 __ STA P8 
125b : 20 db 16 JSR $16db ; (b_str.s4 + 0)
125e : 24 5a __ BIT T2 + 3 
1260 : 10 21 __ BPL $1283 ; (main.s81 + 0)
.s67:
1262 : a9 2d __ LDA #$2d
1264 : 85 13 __ STA P6 
1266 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1269 : 38 __ __ SEC
126a : a9 00 __ LDA #$00
126c : e5 57 __ SBC T2 + 0 
126e : aa __ __ TAX
126f : a9 00 __ LDA #$00
1271 : e5 58 __ SBC T2 + 1 
1273 : a8 __ __ TAY
1274 : a9 00 __ LDA #$00
1276 : e5 59 __ SBC T2 + 2 
1278 : 85 55 __ STA T0 + 2 
127a : a9 00 __ LDA #$00
127c : e5 5a __ SBC T2 + 3 
127e : 85 56 __ STA T0 + 3 
1280 : 4c ab 12 JMP $12ab ; (main.s68 + 0)
.s81:
1283 : a9 20 __ LDA #$20
1285 : 85 13 __ STA P6 
1287 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
128a : a5 59 __ LDA T2 + 2 
128c : 85 55 __ STA T0 + 2 
128e : a4 58 __ LDY T2 + 1 
1290 : a6 57 __ LDX T2 + 0 
1292 : a5 5a __ LDA T2 + 3 
1294 : 85 56 __ STA T0 + 3 
1296 : d0 13 __ BNE $12ab ; (main.s68 + 0)
.s83:
1298 : a5 59 __ LDA T2 + 2 
129a : d0 0f __ BNE $12ab ; (main.s68 + 0)
.s84:
129c : 98 __ __ TYA
129d : d0 0c __ BNE $12ab ; (main.s68 + 0)
.s85:
129f : 8a __ __ TXA
12a0 : d0 09 __ BNE $12ab ; (main.s68 + 0)
.s82:
12a2 : e6 5b __ INC T3 + 0 
12a4 : a9 30 __ LDA #$30
12a6 : 8d 78 9f STA $9f78 ; (tmp[0] + 0)
12a9 : d0 60 __ BNE $130b ; (main.l71 + 0)
.s68:
12ab : a5 56 __ LDA T0 + 3 
12ad : 30 58 __ BMI $1307 ; (main.s69 + 0)
.s77:
12af : d0 0a __ BNE $12bb ; (main.l72 + 0)
.s78:
12b1 : a5 55 __ LDA T0 + 2 
12b3 : d0 06 __ BNE $12bb ; (main.l72 + 0)
.s79:
12b5 : 98 __ __ TYA
12b6 : d0 03 __ BNE $12bb ; (main.l72 + 0)
.s80:
12b8 : 8a __ __ TXA
12b9 : f0 4c __ BEQ $1307 ; (main.s69 + 0)
.l72:
12bb : a5 5b __ LDA T3 + 0 
12bd : c9 17 __ CMP #$17
12bf : b0 46 __ BCS $1307 ; (main.s69 + 0)
.s73:
12c1 : 86 1b __ STX ACCU + 0 
12c3 : 84 1c __ STY ACCU + 1 
12c5 : a5 55 __ LDA T0 + 2 
12c7 : 85 1d __ STA ACCU + 2 
12c9 : a5 56 __ LDA T0 + 3 
12cb : 85 1e __ STA ACCU + 3 
12cd : a9 00 __ LDA #$00
12cf : 85 04 __ STA WORK + 1 
12d1 : 85 05 __ STA WORK + 2 
12d3 : 85 06 __ STA WORK + 3 
12d5 : a9 0a __ LDA #$0a
12d7 : 85 03 __ STA WORK + 0 
12d9 : 20 07 21 JSR $2107 ; (divmod32 + 0)
12dc : a5 1d __ LDA ACCU + 2 
12de : 85 55 __ STA T0 + 2 
12e0 : a5 1e __ LDA ACCU + 3 
12e2 : 85 56 __ STA T0 + 3 
12e4 : 18 __ __ CLC
12e5 : a5 07 __ LDA WORK + 4 
12e7 : 69 30 __ ADC #$30
12e9 : a6 5b __ LDX T3 + 0 
12eb : 9d 78 9f STA $9f78,x ; (tmp[0] + 0)
12ee : a9 00 __ LDA #$00
12f0 : e6 5b __ INC T3 + 0 
12f2 : a4 1c __ LDY ACCU + 1 
12f4 : a6 1b __ LDX ACCU + 0 
12f6 : c5 1e __ CMP ACCU + 3 
12f8 : 90 c1 __ BCC $12bb ; (main.l72 + 0)
.s186:
12fa : d0 0b __ BNE $1307 ; (main.s69 + 0)
.s74:
12fc : a5 1d __ LDA ACCU + 2 
12fe : d0 bb __ BNE $12bb ; (main.l72 + 0)
.s75:
1300 : 98 __ __ TYA
1301 : d0 b8 __ BNE $12bb ; (main.l72 + 0)
.s76:
1303 : c4 1b __ CPY ACCU + 0 
1305 : 90 b4 __ BCC $12bb ; (main.l72 + 0)
.s69:
1307 : a5 5b __ LDA T3 + 0 
1309 : f0 0e __ BEQ $1319 ; (main.s70 + 0)
.l71:
130b : a6 5b __ LDX T3 + 0 
130d : bd 77 9f LDA $9f77,x ; (main@stack + 19)
1310 : 85 13 __ STA P6 
1312 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1315 : c6 5b __ DEC T3 + 0 
1317 : d0 f2 __ BNE $130b ; (main.l71 + 0)
.s70:
1319 : a9 20 __ LDA #$20
131b : 85 13 __ STA P6 
131d : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1320 : a9 0d __ LDA #$0d
1322 : 85 13 __ STA P6 
1324 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
1327 : a9 00 __ LDA #$00
1329 : 85 1b __ STA ACCU + 0 
132b : 85 1c __ STA ACCU + 1 
.s3:
132d : a2 0f __ LDX #$0f
132f : bd 64 9f LDA $9f64,x ; (main@stack + 0)
1332 : 95 53 __ STA T0 + 0,x 
1334 : ca __ __ DEX
1335 : 10 f8 __ BPL $132f ; (main.s3 + 2)
1337 : 60 __ __ RTS
.s95:
1338 : c9 2e __ CMP #$2e
133a : f0 03 __ BEQ $133f ; (main.s96 + 0)
133c : 4c c5 10 JMP $10c5 ; (main.s55 + 0)
.s96:
133f : a9 00 __ LDA #$00
1341 : 9d a7 9f STA $9fa7,x ; (tmp[0] + 23)
1344 : 4c c5 10 JMP $10c5 ; (main.s55 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1347 : ad 1e 22 LDA $221e ; (b_mem + 0)
134a : 85 43 __ STA T1 + 0 
134c : 85 45 __ STA T2 + 0 
134e : 85 1f __ STA ADDR + 0 
1350 : ad 1f 22 LDA $221f ; (b_mem + 1)
1353 : 85 44 __ STA T1 + 1 
1355 : 18 __ __ CLC
1356 : 69 dd __ ADC #$dd
1358 : 85 20 __ STA ADDR + 1 
135a : a9 03 __ LDA #$03
135c : a0 00 __ LDY #$00
135e : 91 1f __ STA (ADDR + 0),y 
1360 : 18 __ __ CLC
1361 : a5 44 __ LDA T1 + 1 
1363 : 69 d0 __ ADC #$d0
1365 : 85 20 __ STA ADDR + 1 
1367 : a9 15 __ LDA #$15
1369 : a0 18 __ LDY #$18
136b : 91 1f __ STA (ADDR + 0),y 
136d : 18 __ __ CLC
136e : a5 44 __ LDA T1 + 1 
1370 : 69 02 __ ADC #$02
1372 : 85 20 __ STA ADDR + 1 
1374 : a9 0e __ LDA #$0e
1376 : a0 86 __ LDY #$86
1378 : 91 1f __ STA (ADDR + 0),y 
137a : 18 __ __ CLC
137b : a5 44 __ LDA T1 + 1 
137d : 69 d8 __ ADC #$d8
137f : 85 46 __ STA T2 + 1 
1381 : a9 00 __ LDA #$00
1383 : 85 47 __ STA T3 + 0 
1385 : 85 48 __ STA T3 + 1 
.l5:
1387 : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
138a : 18 __ __ CLC
138b : a5 43 __ LDA T1 + 0 
138d : 65 1b __ ADC ACCU + 0 
138f : 85 1b __ STA ACCU + 0 
1391 : a5 44 __ LDA T1 + 1 
1393 : 65 1c __ ADC ACCU + 1 
1395 : 18 __ __ CLC
1396 : 65 48 __ ADC T3 + 1 
1398 : 85 1c __ STA ACCU + 1 
139a : a9 20 __ LDA #$20
139c : a4 47 __ LDY T3 + 0 
139e : 91 1b __ STA (ACCU + 0),y 
13a0 : a9 0e __ LDA #$0e
13a2 : a0 00 __ LDY #$00
13a4 : 91 45 __ STA (T2 + 0),y 
13a6 : e6 45 __ INC T2 + 0 
13a8 : d0 02 __ BNE $13ac ; (b_init.s9 + 0)
.s8:
13aa : e6 46 __ INC T2 + 1 
.s9:
13ac : e6 47 __ INC T3 + 0 
13ae : d0 02 __ BNE $13b2 ; (b_init.s11 + 0)
.s10:
13b0 : e6 48 __ INC T3 + 1 
.s11:
13b2 : a5 48 __ LDA T3 + 1 
13b4 : c9 03 __ CMP #$03
13b6 : d0 cf __ BNE $1387 ; (b_init.l5 + 0)
.s7:
13b8 : a5 47 __ LDA T3 + 0 
13ba : c9 e8 __ CMP #$e8
13bc : d0 c9 __ BNE $1387 ; (b_init.l5 + 0)
.s6:
13be : a5 43 __ LDA T1 + 0 
13c0 : 85 1f __ STA ADDR + 0 
13c2 : a5 44 __ LDA T1 + 1 
13c4 : 69 cf __ ADC #$cf
13c6 : 85 20 __ STA ADDR + 1 
13c8 : a9 0e __ LDA #$0e
13ca : a0 20 __ LDY #$20
13cc : 91 1f __ STA (ADDR + 0),y 
13ce : a9 06 __ LDA #$06
13d0 : c8 __ __ INY
13d1 : 91 1f __ STA (ADDR + 0),y 
13d3 : a9 00 __ LDA #$00
13d5 : a0 c6 __ LDY #$c6
13d7 : 91 43 __ STA (T1 + 0),y 
13d9 : 8d 22 22 STA $2222 ; (b_row + 0)
13dc : 8d 23 22 STA $2223 ; (b_row + 1)
13df : 8d 20 22 STA $2220 ; (b_col + 0)
13e2 : 8d 21 22 STA $2221 ; (b_col + 1)
.s3:
13e5 : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
13e6 : ad 1e 22 LDA $221e ; (b_mem + 0)
13e9 : 85 1f __ STA ADDR + 0 
13eb : ad 1f 22 LDA $221f ; (b_mem + 1)
13ee : 18 __ __ CLC
13ef : 69 dd __ ADC #$dd
13f1 : 85 20 __ STA ADDR + 1 
13f3 : a0 00 __ LDY #$00
13f5 : 84 1b __ STY ACCU + 0 
13f7 : b1 1f __ LDA (ADDR + 0),y 
13f9 : 29 03 __ AND #$03
13fb : 49 03 __ EOR #$03
13fd : aa __ __ TAX
13fe : 18 __ __ CLC
13ff : a5 1f __ LDA ADDR + 0 
1401 : 69 18 __ ADC #$18
1403 : 85 1f __ STA ADDR + 0 
1405 : ad 1f 22 LDA $221f ; (b_mem + 1)
1408 : 69 d0 __ ADC #$d0
140a : 85 20 __ STA ADDR + 1 
140c : b1 1f __ LDA (ADDR + 0),y 
140e : 29 f0 __ AND #$f0
1410 : 4a __ __ LSR
1411 : 4a __ __ LSR
1412 : 1d 19 22 ORA $2219,x ; (__multab16384H + 0)
1415 : 85 1c __ STA ACCU + 1 
.s3:
1417 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1273, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1418 : ad 24 22 LDA $2224 ; (tsb_inited + 0)
141b : 0d 25 22 ORA $2225 ; (tsb_inited + 1)
141e : d0 18 __ BNE $1438 ; (tsb_init.s3 + 0)
.s5:
1420 : 85 0d __ STA P0 
1422 : 85 0e __ STA P1 
1424 : 85 10 __ STA P3 
1426 : a9 01 __ LDA #$01
1428 : 85 0f __ STA P2 
142a : 8d 24 22 STA $2224 ; (tsb_inited + 0)
142d : a9 00 __ LDA #$00
142f : 8d 25 22 STA $2225 ; (tsb_inited + 1)
1432 : 20 39 14 JSR $1439 ; (tsb_init_tables.s4 + 0)
1435 : 4c 47 14 JMP $1447 ; (tsb_rot.s4 + 0)
.s3:
1438 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1261, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1439 : a2 00 __ LDX #$00
.l5:
143b : bd 26 22 LDA $2226,x ; (tab[0] + 0)
143e : 9d aa 22 STA $22aa,x ; (tsb_sintab[0] + 0)
1441 : e8 __ __ INX
1442 : e0 40 __ CPX #$40
1444 : d0 f5 __ BNE $143b ; (tsb_init_tables.l5 + 0)
.s3:
1446 : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
1447 : a5 0d __ LDA P0 ; (angle + 0)
1449 : 29 07 __ AND #$07
144b : 0a __ __ ASL
144c : 0a __ __ ASL
144d : 0a __ __ ASL
144e : aa __ __ TAX
144f : a9 00 __ LDA #$00
1451 : 85 1b __ STA ACCU + 0 
.l5:
1453 : 8a __ __ TXA
1454 : 65 1b __ ADC ACCU + 0 
1456 : a8 __ __ TAY
1457 : b9 66 22 LDA $2266,y ; (tsb_rottab[0] + 0)
145a : a4 1b __ LDY ACCU + 0 
145c : c8 __ __ INY
145d : 84 1b __ STY ACCU + 0 
145f : 99 e9 22 STA $22e9,y ; (tsb_sintab[0] + 63)
1462 : c0 08 __ CPY #$08
1464 : 90 ed __ BCC $1453 ; (tsb_rot.l5 + 0)
.s3:
1466 : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1467 : a5 13 __ LDA P6 ; (c + 0)
1469 : c9 93 __ CMP #$93
146b : d0 03 __ BNE $1470 ; (b_putc.s5 + 0)
146d : 4c fe 14 JMP $14fe ; (b_putc.s14 + 0)
.s5:
1470 : c9 13 __ CMP #$13
1472 : d0 0d __ BNE $1481 ; (b_putc.s6 + 0)
.s13:
1474 : a9 00 __ LDA #$00
1476 : 8d 22 22 STA $2222 ; (b_row + 0)
1479 : 8d 23 22 STA $2223 ; (b_row + 1)
147c : 8d 20 22 STA $2220 ; (b_col + 0)
147f : f0 76 __ BEQ $14f7 ; (b_putc.s17 + 0)
.s6:
1481 : c9 0d __ CMP #$0d
1483 : f0 76 __ BEQ $14fb ; (b_putc.s12 + 0)
.s7:
1485 : ad 21 22 LDA $2221 ; (b_col + 1)
1488 : 30 0c __ BMI $1496 ; (b_putc.s8 + 0)
.s11:
148a : d0 07 __ BNE $1493 ; (b_putc.s9 + 0)
.s10:
148c : ad 20 22 LDA $2220 ; (b_col + 0)
148f : c9 28 __ CMP #$28
1491 : 90 03 __ BCC $1496 ; (b_putc.s8 + 0)
.s9:
1493 : 20 42 15 JSR $1542 ; (b_newline.s4 + 0)
.s8:
1496 : a5 13 __ LDA P6 ; (c + 0)
1498 : 20 9e 16 JSR $169e ; (b_pet2scr.s4 + 0)
149b : 85 4e __ STA T3 + 0 
149d : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
14a0 : ad 1e 22 LDA $221e ; (b_mem + 0)
14a3 : 18 __ __ CLC
14a4 : 65 1b __ ADC ACCU + 0 
14a6 : 85 4a __ STA T1 + 0 
14a8 : ad 1f 22 LDA $221f ; (b_mem + 1)
14ab : 65 1c __ ADC ACCU + 1 
14ad : 85 4b __ STA T1 + 1 
14af : ad 22 22 LDA $2222 ; (b_row + 0)
14b2 : 0a __ __ ASL
14b3 : 85 07 __ STA WORK + 4 
14b5 : ad 23 22 LDA $2223 ; (b_row + 1)
14b8 : 2a __ __ ROL
14b9 : 06 07 __ ASL WORK + 4 
14bb : 2a __ __ ROL
14bc : aa __ __ TAX
14bd : 18 __ __ CLC
14be : a5 07 __ LDA WORK + 4 
14c0 : 6d 22 22 ADC $2222 ; (b_row + 0)
14c3 : 85 1b __ STA ACCU + 0 
14c5 : 8a __ __ TXA
14c6 : 6d 23 22 ADC $2223 ; (b_row + 1)
14c9 : 06 1b __ ASL ACCU + 0 
14cb : 2a __ __ ROL
14cc : 06 1b __ ASL ACCU + 0 
14ce : 2a __ __ ROL
14cf : 06 1b __ ASL ACCU + 0 
14d1 : 2a __ __ ROL
14d2 : 85 1c __ STA ACCU + 1 
14d4 : ad 20 22 LDA $2220 ; (b_col + 0)
14d7 : aa __ __ TAX
14d8 : 18 __ __ CLC
14d9 : 65 1b __ ADC ACCU + 0 
14db : a8 __ __ TAY
14dc : ad 21 22 LDA $2221 ; (b_col + 1)
14df : 85 4d __ STA T2 + 1 
14e1 : 65 1c __ ADC ACCU + 1 
14e3 : 18 __ __ CLC
14e4 : 65 4b __ ADC T1 + 1 
14e6 : 85 4b __ STA T1 + 1 
14e8 : a5 4e __ LDA T3 + 0 
14ea : 91 4a __ STA (T1 + 0),y 
14ec : 8a __ __ TXA
14ed : 18 __ __ CLC
14ee : 69 01 __ ADC #$01
14f0 : 8d 20 22 STA $2220 ; (b_col + 0)
14f3 : a5 4d __ LDA T2 + 1 
14f5 : 69 00 __ ADC #$00
.s17:
14f7 : 8d 21 22 STA $2221 ; (b_col + 1)
.s3:
14fa : 60 __ __ RTS
.s12:
14fb : 4c 42 15 JMP $1542 ; (b_newline.s4 + 0)
.s14:
14fe : a9 00 __ LDA #$00
1500 : 8d 22 22 STA $2222 ; (b_row + 0)
1503 : 8d 23 22 STA $2223 ; (b_row + 1)
1506 : 8d 20 22 STA $2220 ; (b_col + 0)
1509 : 8d 21 22 STA $2221 ; (b_col + 1)
150c : 85 4c __ STA T2 + 0 
150e : 85 4d __ STA T2 + 1 
.l15:
1510 : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
1513 : ad 1e 22 LDA $221e ; (b_mem + 0)
1516 : 18 __ __ CLC
1517 : 65 1b __ ADC ACCU + 0 
1519 : 85 4a __ STA T1 + 0 
151b : ad 1f 22 LDA $221f ; (b_mem + 1)
151e : 65 1c __ ADC ACCU + 1 
1520 : 18 __ __ CLC
1521 : 65 4d __ ADC T2 + 1 
1523 : 85 4b __ STA T1 + 1 
1525 : a9 20 __ LDA #$20
1527 : a4 4c __ LDY T2 + 0 
1529 : 91 4a __ STA (T1 + 0),y 
152b : 98 __ __ TYA
152c : 18 __ __ CLC
152d : 69 01 __ ADC #$01
152f : 85 4c __ STA T2 + 0 
1531 : a5 4d __ LDA T2 + 1 
1533 : 69 00 __ ADC #$00
1535 : 85 4d __ STA T2 + 1 
1537 : c9 03 __ CMP #$03
1539 : d0 d5 __ BNE $1510 ; (b_putc.l15 + 0)
.s16:
153b : a5 4c __ LDA T2 + 0 
153d : c9 e8 __ CMP #$e8
153f : d0 cf __ BNE $1510 ; (b_putc.l15 + 0)
1541 : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1542 : a9 00 __ LDA #$00
1544 : 8d 20 22 STA $2220 ; (b_col + 0)
1547 : 8d 21 22 STA $2221 ; (b_col + 1)
154a : ad 22 22 LDA $2222 ; (b_row + 0)
154d : aa __ __ TAX
154e : 18 __ __ CLC
154f : 69 01 __ ADC #$01
1551 : 8d 22 22 STA $2222 ; (b_row + 0)
1554 : ad 23 22 LDA $2223 ; (b_row + 1)
1557 : a8 __ __ TAY
1558 : 69 00 __ ADC #$00
155a : 8d 23 22 STA $2223 ; (b_row + 1)
155d : 98 __ __ TYA
155e : 30 13 __ BMI $1573 ; (b_newline.s3 + 0)
.s7:
1560 : d0 04 __ BNE $1566 ; (b_newline.s5 + 0)
.s6:
1562 : e0 18 __ CPX #$18
1564 : 90 0d __ BCC $1573 ; (b_newline.s3 + 0)
.s5:
1566 : 20 74 15 JSR $1574 ; (b_scroll.s4 + 0)
1569 : a9 18 __ LDA #$18
156b : 8d 22 22 STA $2222 ; (b_row + 0)
156e : a9 00 __ LDA #$00
1570 : 8d 23 22 STA $2223 ; (b_row + 1)
.s3:
1573 : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1574 : a9 c0 __ LDA #$c0
1576 : 85 11 __ STA P4 
1578 : a9 03 __ LDA #$03
157a : 85 12 __ STA P5 
157c : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
157f : ad 1e 22 LDA $221e ; (b_mem + 0)
1582 : 85 45 __ STA T1 + 0 
1584 : 18 __ __ CLC
1585 : 65 1b __ ADC ACCU + 0 
1587 : 85 0d __ STA P0 
1589 : ad 1f 22 LDA $221f ; (b_mem + 1)
158c : 85 46 __ STA T1 + 1 
158e : 65 1c __ ADC ACCU + 1 
1590 : 85 0e __ STA P1 
1592 : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
1595 : 18 __ __ CLC
1596 : a5 45 __ LDA T1 + 0 
1598 : 65 1b __ ADC ACCU + 0 
159a : aa __ __ TAX
159b : a5 46 __ LDA T1 + 1 
159d : 65 1c __ ADC ACCU + 1 
159f : a8 __ __ TAY
15a0 : 8a __ __ TXA
15a1 : 18 __ __ CLC
15a2 : 69 28 __ ADC #$28
15a4 : 85 0f __ STA P2 
15a6 : 90 01 __ BCC $15a9 ; (b_scroll.s7 + 0)
.s6:
15a8 : c8 __ __ INY
.s7:
15a9 : 84 10 __ STY P3 
15ab : 20 09 16 JSR $1609 ; (memmove.s4 + 0)
15ae : a9 03 __ LDA #$03
15b0 : 85 12 __ STA P5 
15b2 : 18 __ __ CLC
15b3 : a5 46 __ LDA T1 + 1 
15b5 : 69 d8 __ ADC #$d8
15b7 : 85 0e __ STA P1 
15b9 : a5 45 __ LDA T1 + 0 
15bb : 85 0d __ STA P0 
15bd : 18 __ __ CLC
15be : 69 28 __ ADC #$28
15c0 : 85 0f __ STA P2 
15c2 : a5 46 __ LDA T1 + 1 
15c4 : 69 d8 __ ADC #$d8
15c6 : 85 10 __ STA P3 
15c8 : 20 09 16 JSR $1609 ; (memmove.s4 + 0)
15cb : 18 __ __ CLC
15cc : a5 45 __ LDA T1 + 0 
15ce : 69 c0 __ ADC #$c0
15d0 : 85 47 __ STA T2 + 0 
15d2 : a5 46 __ LDA T1 + 1 
15d4 : 69 db __ ADC #$db
15d6 : 85 48 __ STA T2 + 1 
15d8 : a9 00 __ LDA #$00
15da : 85 49 __ STA T3 + 0 
.l5:
15dc : 20 e6 13 JSR $13e6 ; (b_scr_base.s4 + 0)
15df : 18 __ __ CLC
15e0 : a5 45 __ LDA T1 + 0 
15e2 : 65 1b __ ADC ACCU + 0 
15e4 : a8 __ __ TAY
15e5 : a5 46 __ LDA T1 + 1 
15e7 : 65 1c __ ADC ACCU + 1 
15e9 : aa __ __ TAX
15ea : 98 __ __ TYA
15eb : 18 __ __ CLC
15ec : 65 49 __ ADC T3 + 0 
15ee : 85 1f __ STA ADDR + 0 
15f0 : 8a __ __ TXA
15f1 : 69 03 __ ADC #$03
15f3 : 85 20 __ STA ADDR + 1 
15f5 : a9 20 __ LDA #$20
15f7 : a0 c0 __ LDY #$c0
15f9 : 91 1f __ STA (ADDR + 0),y 
15fb : a9 0e __ LDA #$0e
15fd : a4 49 __ LDY T3 + 0 
15ff : 91 47 __ STA (T2 + 0),y 
1601 : c8 __ __ INY
1602 : 84 49 __ STY T3 + 0 
1604 : c0 28 __ CPY #$28
1606 : 90 d4 __ BCC $15dc ; (b_scroll.l5 + 0)
.s3:
1608 : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1609 : a5 12 __ LDA P5 ; (size + 1)
160b : 30 65 __ BMI $1672 ; (memmove.s5 + 0)
.s14:
160d : 05 11 __ ORA P4 ; (size + 0)
160f : f0 61 __ BEQ $1672 ; (memmove.s5 + 0)
.s6:
1611 : a5 0d __ LDA P0 ; (dst + 0)
1613 : 85 1b __ STA ACCU + 0 
1615 : a5 0f __ LDA P2 ; (src + 0)
1617 : 85 43 __ STA T3 + 0 
1619 : a5 0e __ LDA P1 ; (dst + 1)
161b : 85 1c __ STA ACCU + 1 
161d : a6 10 __ LDX P3 ; (src + 1)
161f : 86 44 __ STX T3 + 1 
1621 : c5 10 __ CMP P3 ; (src + 1)
1623 : d0 04 __ BNE $1629 ; (memmove.s13 + 0)
.s12:
1625 : a5 0d __ LDA P0 ; (dst + 0)
1627 : c5 0f __ CMP P2 ; (src + 0)
.s13:
1629 : 90 50 __ BCC $167b ; (memmove.s11 + 0)
.s7:
162b : e4 0e __ CPX P1 ; (dst + 1)
162d : d0 04 __ BNE $1633 ; (memmove.s10 + 0)
.s9:
162f : a5 0f __ LDA P2 ; (src + 0)
1631 : c5 0d __ CMP P0 ; (dst + 0)
.s10:
1633 : b0 3d __ BCS $1672 ; (memmove.s5 + 0)
.s8:
1635 : a5 0f __ LDA P2 ; (src + 0)
1637 : 65 11 __ ADC P4 ; (size + 0)
1639 : 85 43 __ STA T3 + 0 
163b : 8a __ __ TXA
163c : 65 12 __ ADC P5 ; (size + 1)
163e : 85 44 __ STA T3 + 1 
1640 : 18 __ __ CLC
1641 : a5 0d __ LDA P0 ; (dst + 0)
1643 : 65 11 __ ADC P4 ; (size + 0)
1645 : 85 1b __ STA ACCU + 0 
1647 : a5 0e __ LDA P1 ; (dst + 1)
1649 : 65 12 __ ADC P5 ; (size + 1)
164b : 85 1c __ STA ACCU + 1 
164d : a0 00 __ LDY #$00
164f : a5 11 __ LDA P4 ; (size + 0)
1651 : f0 02 __ BEQ $1655 ; (memmove.s30 + 0)
.s16:
1653 : e6 12 __ INC P5 ; (size + 1)
.s30:
1655 : a6 11 __ LDX P4 ; (size + 0)
.l19:
1657 : a5 43 __ LDA T3 + 0 
1659 : d0 02 __ BNE $165d ; (memmove.s26 + 0)
.s25:
165b : c6 44 __ DEC T3 + 1 
.s26:
165d : c6 43 __ DEC T3 + 0 
165f : a5 1b __ LDA ACCU + 0 
1661 : d0 02 __ BNE $1665 ; (memmove.s28 + 0)
.s27:
1663 : c6 1c __ DEC ACCU + 1 
.s28:
1665 : c6 1b __ DEC ACCU + 0 
1667 : b1 43 __ LDA (T3 + 0),y 
1669 : 91 1b __ STA (ACCU + 0),y 
166b : ca __ __ DEX
166c : d0 e9 __ BNE $1657 ; (memmove.l19 + 0)
.s20:
166e : c6 12 __ DEC P5 ; (size + 1)
1670 : d0 e5 __ BNE $1657 ; (memmove.l19 + 0)
.s5:
1672 : a5 0d __ LDA P0 ; (dst + 0)
1674 : 85 1b __ STA ACCU + 0 
1676 : a5 0e __ LDA P1 ; (dst + 1)
1678 : 85 1c __ STA ACCU + 1 
.s3:
167a : 60 __ __ RTS
.s11:
167b : a0 00 __ LDY #$00
167d : a5 11 __ LDA P4 ; (size + 0)
167f : f0 02 __ BEQ $1683 ; (memmove.s29 + 0)
.s15:
1681 : e6 12 __ INC P5 ; (size + 1)
.s29:
1683 : a6 11 __ LDX P4 ; (size + 0)
.l17:
1685 : b1 43 __ LDA (T3 + 0),y 
1687 : 91 1b __ STA (ACCU + 0),y 
1689 : e6 43 __ INC T3 + 0 
168b : d0 02 __ BNE $168f ; (memmove.s22 + 0)
.s21:
168d : e6 44 __ INC T3 + 1 
.s22:
168f : e6 1b __ INC ACCU + 0 
1691 : d0 02 __ BNE $1695 ; (memmove.s24 + 0)
.s23:
1693 : e6 1c __ INC ACCU + 1 
.s24:
1695 : ca __ __ DEX
1696 : d0 ed __ BNE $1685 ; (memmove.l17 + 0)
.s18:
1698 : c6 12 __ DEC P5 ; (size + 1)
169a : d0 e9 __ BNE $1685 ; (memmove.l17 + 0)
169c : f0 d4 __ BEQ $1672 ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
169e : c9 41 __ CMP #$41
16a0 : 90 06 __ BCC $16a8 ; (b_pet2scr.s3 + 0)
.s8:
16a2 : c9 5b __ CMP #$5b
16a4 : b0 03 __ BCS $16a9 ; (b_pet2scr.s5 + 0)
.s9:
16a6 : e9 3f __ SBC #$3f
.s3:
16a8 : 60 __ __ RTS
.s5:
16a9 : c9 c1 __ CMP #$c1
16ab : 90 fb __ BCC $16a8 ; (b_pet2scr.s3 + 0)
.s6:
16ad : c9 db __ CMP #$db
16af : b0 f7 __ BCS $16a8 ; (b_pet2scr.s3 + 0)
.s7:
16b1 : e9 bf __ SBC #$bf
16b3 : 60 __ __ RTS
--------------------------------------------------------------------
b_jiffy: ; b_jiffy()->float
; 133, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16b4 : ad 1e 22 LDA $221e ; (b_mem + 0)
16b7 : 85 43 __ STA T2 + 0 
16b9 : ad 1f 22 LDA $221f ; (b_mem + 1)
16bc : 85 44 __ STA T2 + 1 
16be : a0 a2 __ LDY #$a2
16c0 : b1 43 __ LDA (T2 + 0),y 
16c2 : 85 1b __ STA ACCU + 0 
16c4 : 88 __ __ DEY
16c5 : b1 43 __ LDA (T2 + 0),y 
16c7 : 85 1c __ STA ACCU + 1 
16c9 : 88 __ __ DEY
16ca : b1 43 __ LDA (T2 + 0),y 
16cc : 85 1d __ STA ACCU + 2 
16ce : a9 00 __ LDA #$00
16d0 : 85 1e __ STA ACCU + 3 
16d2 : 4c 09 20 JMP $2009 ; (uint32_to_float + 0)
--------------------------------------------------------------------
16d5 : __ __ __ BYT 54 49 4d 45 3d 00                               : TIME=.
--------------------------------------------------------------------
b_str: ; b_str(const u8*,i16)->void
; 539, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
16db : a5 17 __ LDA P10 ; (len + 1)
16dd : 30 21 __ BMI $1700 ; (b_str.s3 + 0)
.s6:
16df : 05 16 __ ORA P9 ; (len + 0)
16e1 : f0 1d __ BEQ $1700 ; (b_str.s3 + 0)
.l5:
16e3 : a0 00 __ LDY #$00
16e5 : b1 14 __ LDA (P7),y ; (s + 0)
16e7 : 85 13 __ STA P6 
16e9 : 20 67 14 JSR $1467 ; (b_putc.s4 + 0)
16ec : e6 14 __ INC P7 ; (s + 0)
16ee : d0 02 __ BNE $16f2 ; (b_str.s11 + 0)
.s10:
16f0 : e6 15 __ INC P8 ; (s + 1)
.s11:
16f2 : a5 16 __ LDA P9 ; (len + 0)
16f4 : d0 02 __ BNE $16f8 ; (b_str.s8 + 0)
.s7:
16f6 : c6 17 __ DEC P10 ; (len + 1)
.s8:
16f8 : c6 16 __ DEC P9 ; (len + 0)
16fa : d0 e7 __ BNE $16e3 ; (b_str.l5 + 0)
.s9:
16fc : a5 17 __ LDA P10 ; (len + 1)
16fe : d0 e3 __ BNE $16e3 ; (b_str.l5 + 0)
.s3:
1700 : 60 __ __ RTS
--------------------------------------------------------------------
b_ftoa: ; b_ftoa(u8*,float)->void
; 559, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1701 : a9 00 __ LDA #$00
1703 : 85 49 __ STA T2 + 0 
1705 : 85 4a __ STA T2 + 1 
1707 : a5 0f __ LDA P2 ; (v + 0)
1709 : 85 43 __ STA T0 + 0 
170b : a5 10 __ LDA P3 ; (v + 1)
170d : 85 44 __ STA T0 + 1 
170f : a5 12 __ LDA P5 ; (v + 3)
1711 : 29 7f __ AND #$7f
1713 : 05 11 __ ORA P4 ; (v + 2)
1715 : 05 10 __ ORA P3 ; (v + 1)
1717 : a6 11 __ LDX P4 ; (v + 2)
1719 : 86 45 __ STX T0 + 2 
171b : 05 0f __ ORA P2 ; (v + 0)
171d : d0 05 __ BNE $1724 ; (b_ftoa.s78 + 0)
.s127:
171f : a5 12 __ LDA P5 ; (v + 3)
1721 : 4c 2b 17 JMP $172b ; (b_ftoa.s5 + 0)
.s78:
1724 : a5 12 __ LDA P5 ; (v + 3)
1726 : 10 03 __ BPL $172b ; (b_ftoa.s5 + 0)
1728 : 4c 58 1b JMP $1b58 ; (b_ftoa.s76 + 0)
.s5:
172b : 29 7f __ AND #$7f
172d : 05 11 __ ORA P4 ; (v + 2)
172f : 05 10 __ ORA P3 ; (v + 1)
1731 : 05 0f __ ORA P2 ; (v + 0)
1733 : d0 03 __ BNE $1738 ; (b_ftoa.s6 + 0)
1735 : 4c 4d 1b JMP $1b4d ; (b_ftoa.s75 + 0)
.s6:
1738 : a9 00 __ LDA #$00
.s7:
173a : 85 4b __ STA T3 + 0 
173c : a5 12 __ LDA P5 ; (v + 3)
173e : 85 46 __ STA T0 + 3 
1740 : 30 1c __ BMI $175e ; (b_ftoa.s8 + 0)
.s70:
1742 : c9 41 __ CMP #$41
1744 : d0 0d __ BNE $1753 ; (b_ftoa.s74 + 0)
.s71:
1746 : e0 20 __ CPX #$20
1748 : d0 09 __ BNE $1753 ; (b_ftoa.s74 + 0)
.s72:
174a : a5 10 __ LDA P3 ; (v + 1)
174c : 38 __ __ SEC
174d : d0 04 __ BNE $1753 ; (b_ftoa.s74 + 0)
.s73:
174f : a5 0f __ LDA P2 ; (v + 0)
1751 : f0 02 __ BEQ $1755 ; (b_ftoa.s61 + 0)
.s74:
1753 : 90 09 __ BCC $175e ; (b_ftoa.s8 + 0)
.s61:
1755 : a9 00 __ LDA #$00
1757 : 85 47 __ STA T1 + 0 
1759 : 85 48 __ STA T1 + 1 
175b : 4c e7 1a JMP $1ae7 ; (b_ftoa.l62 + 0)
.s8:
175e : a5 12 __ LDA P5 ; (v + 3)
1760 : 30 13 __ BMI $1775 ; (b_ftoa.s47 + 0)
.s56:
1762 : c9 3f __ CMP #$3f
1764 : d0 0d __ BNE $1773 ; (b_ftoa.s60 + 0)
.s57:
1766 : e0 80 __ CPX #$80
1768 : d0 09 __ BNE $1773 ; (b_ftoa.s60 + 0)
.s58:
176a : a5 10 __ LDA P3 ; (v + 1)
176c : 38 __ __ SEC
176d : d0 04 __ BNE $1773 ; (b_ftoa.s60 + 0)
.s59:
176f : a5 0f __ LDA P2 ; (v + 0)
1771 : f0 5c __ BEQ $17cf ; (b_ftoa.s9 + 0)
.s60:
1773 : b0 5a __ BCS $17cf ; (b_ftoa.s9 + 0)
.s47:
1775 : a9 00 __ LDA #$00
1777 : 85 47 __ STA T1 + 0 
1779 : 85 48 __ STA T1 + 1 
.l48:
177b : a5 49 __ LDA T2 + 0 
177d : d0 02 __ BNE $1781 ; (b_ftoa.s92 + 0)
.s91:
177f : c6 4a __ DEC T2 + 1 
.s92:
1781 : c6 49 __ DEC T2 + 0 
1783 : a9 00 __ LDA #$00
1785 : 85 1b __ STA ACCU + 0 
1787 : 85 1c __ STA ACCU + 1 
1789 : a9 20 __ LDA #$20
178b : 85 1d __ STA ACCU + 2 
178d : a9 41 __ LDA #$41
178f : 85 1e __ STA ACCU + 3 
1791 : a2 43 __ LDX #$43
1793 : 20 f0 1b JSR $1bf0 ; (freg + 4)
1796 : 20 1e 1d JSR $1d1e ; (crt_fmul + 0)
1799 : a5 1b __ LDA ACCU + 0 
179b : 85 43 __ STA T0 + 0 
179d : a5 1c __ LDA ACCU + 1 
179f : 85 44 __ STA T0 + 1 
17a1 : a6 1d __ LDX ACCU + 2 
17a3 : 86 45 __ STX T0 + 2 
17a5 : a5 1e __ LDA ACCU + 3 
17a7 : 85 46 __ STA T0 + 3 
17a9 : 30 13 __ BMI $17be ; (b_ftoa.s49 + 0)
.s51:
17ab : c9 3f __ CMP #$3f
17ad : d0 0d __ BNE $17bc ; (b_ftoa.s55 + 0)
.s52:
17af : e0 80 __ CPX #$80
17b1 : d0 09 __ BNE $17bc ; (b_ftoa.s55 + 0)
.s53:
17b3 : a5 1c __ LDA ACCU + 1 
17b5 : 38 __ __ SEC
17b6 : d0 04 __ BNE $17bc ; (b_ftoa.s55 + 0)
.s54:
17b8 : a5 1b __ LDA ACCU + 0 
17ba : f0 13 __ BEQ $17cf ; (b_ftoa.s9 + 0)
.s55:
17bc : b0 11 __ BCS $17cf ; (b_ftoa.s9 + 0)
.s49:
17be : e6 47 __ INC T1 + 0 
17c0 : d0 02 __ BNE $17c4 ; (b_ftoa.s94 + 0)
.s93:
17c2 : e6 48 __ INC T1 + 1 
.s94:
17c4 : a6 48 __ LDX T1 + 1 
17c6 : ca __ __ DEX
17c7 : d0 b2 __ BNE $177b ; (b_ftoa.l48 + 0)
.s50:
17c9 : a5 47 __ LDA T1 + 0 
17cb : c9 90 __ CMP #$90
17cd : d0 ac __ BNE $177b ; (b_ftoa.l48 + 0)
.s9:
17cf : a9 08 __ LDA #$08
17d1 : 85 4d __ STA T4 + 0 
17d3 : a9 4c __ LDA #$4c
17d5 : 85 1e __ STA ACCU + 3 
17d7 : a9 20 __ LDA #$20
17d9 : 85 1b __ STA ACCU + 0 
17db : a9 bc __ LDA #$bc
17dd : 85 1c __ STA ACCU + 1 
17df : a9 be __ LDA #$be
17e1 : 85 1d __ STA ACCU + 2 
17e3 : a2 43 __ LDX #$43
17e5 : 20 f0 1b JSR $1bf0 ; (freg + 4)
17e8 : 20 1e 1d JSR $1d1e ; (crt_fmul + 0)
17eb : a9 00 __ LDA #$00
17ed : 85 03 __ STA WORK + 0 
17ef : 85 04 __ STA WORK + 1 
17f1 : 85 05 __ STA WORK + 2 
17f3 : a9 3f __ LDA #$3f
17f5 : 85 06 __ STA WORK + 3 
17f7 : 20 00 1c JSR $1c00 ; (freg + 20)
17fa : 20 37 1c JSR $1c37 ; (faddsub + 6)
17fd : 20 80 1f JSR $1f80 ; (f32_to_i32 + 0)
1800 : a5 1b __ LDA ACCU + 0 
1802 : 85 43 __ STA T0 + 0 
1804 : a5 1c __ LDA ACCU + 1 
1806 : 85 44 __ STA T0 + 1 
1808 : a5 1e __ LDA ACCU + 3 
180a : 85 46 __ STA T0 + 3 
180c : 49 80 __ EOR #$80
180e : a6 1d __ LDX ACCU + 2 
1810 : 86 45 __ STX T0 + 2 
1812 : c9 bb __ CMP #$bb
1814 : d0 0a __ BNE $1820 ; (b_ftoa.s46 + 0)
.s44:
1816 : e0 9a __ CPX #$9a
1818 : d0 06 __ BNE $1820 ; (b_ftoa.s46 + 0)
.s45:
181a : a5 1c __ LDA ACCU + 1 
181c : c9 ca __ CMP #$ca
181e : f0 02 __ BEQ $1822 ; (b_ftoa.s43 + 0)
.s46:
1820 : 90 16 __ BCC $1838 ; (b_ftoa.s10 + 0)
.s43:
1822 : e6 49 __ INC T2 + 0 
1824 : d0 02 __ BNE $1828 ; (b_ftoa.s96 + 0)
.s95:
1826 : e6 4a __ INC T2 + 1 
.s96:
1828 : a9 00 __ LDA #$00
182a : 85 43 __ STA T0 + 0 
182c : a9 e1 __ LDA #$e1
182e : 85 44 __ STA T0 + 1 
1830 : a9 f5 __ LDA #$f5
1832 : 85 45 __ STA T0 + 2 
1834 : a9 05 __ LDA #$05
1836 : 85 46 __ STA T0 + 3 
.s10:
1838 : a5 43 __ LDA T0 + 0 
183a : 85 1b __ STA ACCU + 0 
183c : a5 44 __ LDA T0 + 1 
183e : 85 1c __ STA ACCU + 1 
1840 : a5 45 __ LDA T0 + 2 
1842 : 85 1d __ STA ACCU + 2 
1844 : a5 46 __ LDA T0 + 3 
1846 : 85 1e __ STA ACCU + 3 
.l79:
1848 : a9 00 __ LDA #$00
184a : 85 04 __ STA WORK + 1 
184c : 85 05 __ STA WORK + 2 
184e : 85 06 __ STA WORK + 3 
1850 : a9 0a __ LDA #$0a
1852 : 85 03 __ STA WORK + 0 
1854 : 20 de 21 JSR $21de ; (mods32 + 0)
1857 : 18 __ __ CLC
1858 : a5 07 __ LDA WORK + 4 
185a : 69 30 __ ADC #$30
185c : a6 4d __ LDX T4 + 0 
185e : 9d f0 9f STA $9ff0,x ; (d[0] + 0)
1861 : a5 43 __ LDA T0 + 0 
1863 : 85 1b __ STA ACCU + 0 
1865 : a5 44 __ LDA T0 + 1 
1867 : 85 1c __ STA ACCU + 1 
1869 : a5 45 __ LDA T0 + 2 
186b : 85 1d __ STA ACCU + 2 
186d : a5 46 __ LDA T0 + 3 
186f : 85 1e __ STA ACCU + 3 
1871 : a9 00 __ LDA #$00
1873 : 85 04 __ STA WORK + 1 
1875 : 85 05 __ STA WORK + 2 
1877 : 85 06 __ STA WORK + 3 
1879 : a9 0a __ LDA #$0a
187b : 85 03 __ STA WORK + 0 
187d : 20 b5 20 JSR $20b5 ; (divs32 + 0)
1880 : a5 1b __ LDA ACCU + 0 
1882 : 85 43 __ STA T0 + 0 
1884 : a5 1c __ LDA ACCU + 1 
1886 : 85 44 __ STA T0 + 1 
1888 : a5 1d __ LDA ACCU + 2 
188a : 85 45 __ STA T0 + 2 
188c : a5 1e __ LDA ACCU + 3 
188e : 85 46 __ STA T0 + 3 
1890 : c6 4d __ DEC T4 + 0 
1892 : 10 b4 __ BPL $1848 ; (b_ftoa.l79 + 0)
.s11:
1894 : a9 00 __ LDA #$00
1896 : 8d f9 9f STA $9ff9 ; (d[0] + 9)
1899 : a2 09 __ LDX #$09
.l12:
189b : bd ef 9f LDA $9fef,x ; (eb[0] + 7)
189e : c9 30 __ CMP #$30
18a0 : d0 05 __ BNE $18a7 ; (b_ftoa.s87 + 0)
.s42:
18a2 : ca __ __ DEX
18a3 : e0 02 __ CPX #$02
18a5 : b0 f4 __ BCS $189b ; (b_ftoa.l12 + 0)
.s87:
18a7 : 86 43 __ STX T0 + 0 
18a9 : a5 4b __ LDA T3 + 0 
18ab : f0 0d __ BEQ $18ba ; (b_ftoa.s13 + 0)
.s41:
18ad : a9 2d __ LDA #$2d
18af : a0 00 __ LDY #$00
18b1 : 91 0d __ STA (P0),y ; (buf + 0)
18b3 : a9 01 __ LDA #$01
18b5 : 85 47 __ STA T1 + 0 
18b7 : 98 __ __ TYA
18b8 : f0 02 __ BEQ $18bc ; (b_ftoa.s14 + 0)
.s13:
18ba : 85 47 __ STA T1 + 0 
.s14:
18bc : 85 48 __ STA T1 + 1 
18be : a5 4a __ LDA T2 + 1 
18c0 : 49 80 __ EOR #$80
18c2 : c9 7f __ CMP #$7f
18c4 : d0 04 __ BNE $18ca ; (b_ftoa.s40 + 0)
.s39:
18c6 : a5 49 __ LDA T2 + 0 
18c8 : c9 fc __ CMP #$fc
.s40:
18ca : b0 03 __ BCS $18cf ; (b_ftoa.s26 + 0)
18cc : 4c e9 19 JMP $19e9 ; (b_ftoa.s15 + 0)
.s26:
18cf : a5 4a __ LDA T2 + 1 
18d1 : 30 08 __ BMI $18db ; (b_ftoa.s27 + 0)
.s38:
18d3 : d0 f7 __ BNE $18cc ; (b_ftoa.s40 + 2)
.s37:
18d5 : a5 49 __ LDA T2 + 0 
18d7 : c9 09 __ CMP #$09
18d9 : b0 f1 __ BCS $18cc ; (b_ftoa.s40 + 2)
.s27:
18db : 18 __ __ CLC
18dc : a5 0d __ LDA P0 ; (buf + 0)
18de : 65 47 __ ADC T1 + 0 
18e0 : 85 4d __ STA T4 + 0 
18e2 : a5 0e __ LDA P1 ; (buf + 1)
18e4 : 69 00 __ ADC #$00
18e6 : 85 4e __ STA T4 + 1 
18e8 : a5 49 __ LDA T2 + 0 
18ea : 10 6f __ BPL $195b ; (b_ftoa.s31 + 0)
.s28:
18ec : a9 30 __ LDA #$30
18ee : a4 47 __ LDY T1 + 0 
18f0 : 91 0d __ STA (P0),y ; (buf + 0)
18f2 : a9 2e __ LDA #$2e
18f4 : a0 01 __ LDY #$01
18f6 : 91 4d __ STA (T4 + 0),y 
18f8 : a5 47 __ LDA T1 + 0 
18fa : 09 02 __ ORA #$02
18fc : 85 47 __ STA T1 + 0 
18fe : a9 00 __ LDA #$00
1900 : 38 __ __ SEC
1901 : e5 49 __ SBC T2 + 0 
1903 : aa __ __ TAX
1904 : ca __ __ DEX
1905 : f0 22 __ BEQ $1929 ; (b_ftoa.s29 + 0)
.s30:
1907 : 18 __ __ CLC
1908 : a5 0d __ LDA P0 ; (buf + 0)
190a : 65 47 __ ADC T1 + 0 
190c : a8 __ __ TAY
190d : a9 00 __ LDA #$00
190f : 85 4d __ STA T4 + 0 
1911 : a5 0e __ LDA P1 ; (buf + 1)
1913 : 69 00 __ ADC #$00
1915 : 85 4e __ STA T4 + 1 
.l84:
1917 : a9 30 __ LDA #$30
1919 : 91 4d __ STA (T4 + 0),y 
191b : e6 47 __ INC T1 + 0 
191d : d0 02 __ BNE $1921 ; (b_ftoa.s120 + 0)
.s119:
191f : e6 48 __ INC T1 + 1 
.s120:
1921 : c8 __ __ INY
1922 : d0 02 __ BNE $1926 ; (b_ftoa.s122 + 0)
.s121:
1924 : e6 4e __ INC T4 + 1 
.s122:
1926 : ca __ __ DEX
1927 : d0 ee __ BNE $1917 ; (b_ftoa.l84 + 0)
.s29:
1929 : a5 0d __ LDA P0 ; (buf + 0)
.s85:
192b : 18 __ __ CLC
192c : 65 47 __ ADC T1 + 0 
192e : 85 4b __ STA T3 + 0 
1930 : a5 0e __ LDA P1 ; (buf + 1)
1932 : 65 48 __ ADC T1 + 1 
1934 : 85 4c __ STA T3 + 1 
1936 : a0 00 __ LDY #$00
.l89:
1938 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
193b : 91 4b __ STA (T3 + 0),y 
193d : e6 47 __ INC T1 + 0 
193f : d0 02 __ BNE $1943 ; (b_ftoa.s112 + 0)
.s111:
1941 : e6 48 __ INC T1 + 1 
.s112:
1943 : c8 __ __ INY
1944 : e8 __ __ INX
1945 : e4 43 __ CPX T0 + 0 
1947 : 90 ef __ BCC $1938 ; (b_ftoa.l89 + 0)
.s129:
1949 : a4 0d __ LDY P0 ; (buf + 0)
.s21:
194b : a5 47 __ LDA T1 + 0 
194d : 85 43 __ STA T0 + 0 
194f : 18 __ __ CLC
1950 : a5 0e __ LDA P1 ; (buf + 1)
1952 : 65 48 __ ADC T1 + 1 
1954 : 85 44 __ STA T0 + 1 
1956 : a9 00 __ LDA #$00
1958 : 91 43 __ STA (T0 + 0),y 
.s3:
195a : 60 __ __ RTS
.s31:
195b : 18 __ __ CLC
195c : 69 01 __ ADC #$01
195e : 85 1b __ STA ACCU + 0 
1960 : c5 43 __ CMP T0 + 0 
1962 : a0 00 __ LDY #$00
1964 : 84 4f __ STY T5 + 0 
1966 : 90 44 __ BCC $19ac ; (b_ftoa.l82 + 0)
.s34:
1968 : a2 00 __ LDX #$00
.l90:
196a : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
196d : 91 4d __ STA (T4 + 0),y 
196f : e6 47 __ INC T1 + 0 
1971 : d0 02 __ BNE $1975 ; (b_ftoa.s114 + 0)
.s113:
1973 : e6 48 __ INC T1 + 1 
.s114:
1975 : c8 __ __ INY
1976 : e8 __ __ INX
1977 : e4 43 __ CPX T0 + 0 
1979 : 90 ef __ BCC $196a ; (b_ftoa.l90 + 0)
.s35:
197b : a5 49 __ LDA T2 + 0 
197d : c5 43 __ CMP T0 + 0 
197f : 90 c8 __ BCC $1949 ; (b_ftoa.s129 + 0)
.s36:
1981 : 18 __ __ CLC
1982 : a5 0d __ LDA P0 ; (buf + 0)
1984 : 65 47 __ ADC T1 + 0 
1986 : 85 4b __ STA T3 + 0 
1988 : a5 0e __ LDA P1 ; (buf + 1)
198a : 65 48 __ ADC T1 + 1 
198c : 85 4c __ STA T3 + 1 
198e : a0 00 __ LDY #$00
1990 : a6 47 __ LDX T1 + 0 
.l83:
1992 : a9 30 __ LDA #$30
1994 : 91 4b __ STA (T3 + 0),y 
1996 : e8 __ __ INX
1997 : d0 02 __ BNE $199b ; (b_ftoa.s116 + 0)
.s115:
1999 : e6 48 __ INC T1 + 1 
.s116:
199b : c8 __ __ INY
199c : d0 02 __ BNE $19a0 ; (b_ftoa.s118 + 0)
.s117:
199e : e6 4c __ INC T3 + 1 
.s118:
19a0 : e6 43 __ INC T0 + 0 
19a2 : a5 49 __ LDA T2 + 0 
19a4 : c5 43 __ CMP T0 + 0 
19a6 : b0 ea __ BCS $1992 ; (b_ftoa.l83 + 0)
.s86:
19a8 : 86 47 __ STX T1 + 0 
19aa : 90 9d __ BCC $1949 ; (b_ftoa.s129 + 0)
.l82:
19ac : a6 4f __ LDX T5 + 0 
19ae : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
19b1 : 91 4d __ STA (T4 + 0),y 
19b3 : e6 47 __ INC T1 + 0 
19b5 : d0 02 __ BNE $19b9 ; (b_ftoa.s106 + 0)
.s105:
19b7 : e6 48 __ INC T1 + 1 
.s106:
19b9 : c8 __ __ INY
19ba : d0 02 __ BNE $19be ; (b_ftoa.s108 + 0)
.s107:
19bc : e6 4e __ INC T4 + 1 
.s108:
19be : a5 49 __ LDA T2 + 0 
19c0 : e6 4f __ INC T5 + 0 
19c2 : c5 4f __ CMP T5 + 0 
19c4 : b0 e6 __ BCS $19ac ; (b_ftoa.l82 + 0)
.s32:
19c6 : a5 47 __ LDA T1 + 0 
19c8 : 85 49 __ STA T2 + 0 
19ca : a5 0e __ LDA P1 ; (buf + 1)
19cc : 65 48 __ ADC T1 + 1 
19ce : 85 4a __ STA T2 + 1 
19d0 : a9 2e __ LDA #$2e
19d2 : a4 0d __ LDY P0 ; (buf + 0)
19d4 : 91 49 __ STA (T2 + 0),y 
19d6 : e6 47 __ INC T1 + 0 
19d8 : d0 02 __ BNE $19dc ; (b_ftoa.s110 + 0)
.s109:
19da : e6 48 __ INC T1 + 1 
.s110:
19dc : a6 1b __ LDX ACCU + 0 
19de : e4 43 __ CPX T0 + 0 
19e0 : 90 03 __ BCC $19e5 ; (b_ftoa.s33 + 0)
19e2 : 4c 4b 19 JMP $194b ; (b_ftoa.s21 + 0)
.s33:
19e5 : 98 __ __ TYA
19e6 : 4c 2b 19 JMP $192b ; (b_ftoa.s85 + 0)
.s15:
19e9 : ad f0 9f LDA $9ff0 ; (d[0] + 0)
19ec : a4 47 __ LDY T1 + 0 
19ee : 91 0d __ STA (P0),y ; (buf + 0)
19f0 : e6 47 __ INC T1 + 0 
19f2 : a5 49 __ LDA T2 + 0 
19f4 : 85 4f __ STA T5 + 0 
19f6 : a5 4a __ LDA T2 + 1 
19f8 : 85 50 __ STA T5 + 1 
19fa : e0 02 __ CPX #$02
19fc : 90 29 __ BCC $1a27 ; (b_ftoa.s16 + 0)
.s25:
19fe : a9 2e __ LDA #$2e
1a00 : c8 __ __ INY
1a01 : 91 0d __ STA (P0),y ; (buf + 0)
1a03 : e6 47 __ INC T1 + 0 
1a05 : 18 __ __ CLC
1a06 : a5 47 __ LDA T1 + 0 
1a08 : 65 0d __ ADC P0 ; (buf + 0)
1a0a : 85 4d __ STA T4 + 0 
1a0c : a5 0e __ LDA P1 ; (buf + 1)
1a0e : 69 00 __ ADC #$00
1a10 : 85 4e __ STA T4 + 1 
1a12 : a0 00 __ LDY #$00
1a14 : a2 01 __ LDX #$01
.l88:
1a16 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1a19 : 91 4d __ STA (T4 + 0),y 
1a1b : e6 47 __ INC T1 + 0 
1a1d : d0 02 __ BNE $1a21 ; (b_ftoa.s98 + 0)
.s97:
1a1f : e6 48 __ INC T1 + 1 
.s98:
1a21 : c8 __ __ INY
1a22 : e8 __ __ INX
1a23 : e4 43 __ CPX T0 + 0 
1a25 : 90 ef __ BCC $1a16 ; (b_ftoa.l88 + 0)
.s16:
1a27 : 18 __ __ CLC
1a28 : a5 0d __ LDA P0 ; (buf + 0)
1a2a : 65 47 __ ADC T1 + 0 
1a2c : 85 43 __ STA T0 + 0 
1a2e : a5 0e __ LDA P1 ; (buf + 1)
1a30 : 65 48 __ ADC T1 + 1 
1a32 : 85 44 __ STA T0 + 1 
1a34 : a9 45 __ LDA #$45
1a36 : a0 00 __ LDY #$00
1a38 : 84 4d __ STY T4 + 0 
1a3a : 91 43 __ STA (T0 + 0),y 
1a3c : 18 __ __ CLC
1a3d : a5 47 __ LDA T1 + 0 
1a3f : 69 02 __ ADC #$02
1a41 : 85 47 __ STA T1 + 0 
1a43 : 90 02 __ BCC $1a47 ; (b_ftoa.s100 + 0)
.s99:
1a45 : e6 48 __ INC T1 + 1 
.s100:
1a47 : a0 01 __ LDY #$01
1a49 : 24 4a __ BIT T2 + 1 
1a4b : 10 1c __ BPL $1a69 ; (b_ftoa.s17 + 0)
.s24:
1a4d : a9 2d __ LDA #$2d
1a4f : 91 43 __ STA (T0 + 0),y 
1a51 : 38 __ __ SEC
1a52 : a9 00 __ LDA #$00
1a54 : e5 49 __ SBC T2 + 0 
1a56 : 85 4f __ STA T5 + 0 
1a58 : a9 00 __ LDA #$00
1a5a : e5 4a __ SBC T2 + 1 
1a5c : 85 50 __ STA T5 + 1 
.s18:
1a5e : a5 4f __ LDA T5 + 0 
1a60 : 85 1b __ STA ACCU + 0 
1a62 : a5 50 __ LDA T5 + 1 
1a64 : 85 1c __ STA ACCU + 1 
1a66 : 4c a7 1a JMP $1aa7 ; (b_ftoa.l80 + 0)
.s17:
1a69 : a9 2b __ LDA #$2b
1a6b : 91 43 __ STA (T0 + 0),y 
1a6d : a5 49 __ LDA T2 + 0 
1a6f : 05 4a __ ORA T2 + 1 
1a71 : d0 eb __ BNE $1a5e ; (b_ftoa.s18 + 0)
.s23:
1a73 : a9 30 __ LDA #$30
1a75 : 8d e8 9f STA $9fe8 ; (eb[0] + 0)
.s22:
1a78 : 8d e9 9f STA $9fe9 ; (eb[0] + 1)
1a7b : a9 02 __ LDA #$02
1a7d : 85 4d __ STA T4 + 0 
.s20:
1a7f : 18 __ __ CLC
1a80 : a5 0d __ LDA P0 ; (buf + 0)
1a82 : 65 47 __ ADC T1 + 0 
1a84 : a8 __ __ TAY
1a85 : a5 0e __ LDA P1 ; (buf + 1)
1a87 : 65 48 __ ADC T1 + 1 
1a89 : 85 4c __ STA T3 + 1 
1a8b : a9 00 __ LDA #$00
1a8d : 85 4b __ STA T3 + 0 
1a8f : a6 4d __ LDX T4 + 0 
.l81:
1a91 : bd e7 9f LDA $9fe7,x ; (buf[0] + 63)
1a94 : 91 4b __ STA (T3 + 0),y 
1a96 : e6 47 __ INC T1 + 0 
1a98 : d0 02 __ BNE $1a9c ; (b_ftoa.s102 + 0)
.s101:
1a9a : e6 48 __ INC T1 + 1 
.s102:
1a9c : c8 __ __ INY
1a9d : d0 02 __ BNE $1aa1 ; (b_ftoa.s104 + 0)
.s103:
1a9f : e6 4c __ INC T3 + 1 
.s104:
1aa1 : ca __ __ DEX
1aa2 : d0 ed __ BNE $1a91 ; (b_ftoa.l81 + 0)
1aa4 : 4c 49 19 JMP $1949 ; (b_ftoa.s129 + 0)
.l80:
1aa7 : a9 0a __ LDA #$0a
1aa9 : 85 03 __ STA WORK + 0 
1aab : a9 00 __ LDA #$00
1aad : 85 04 __ STA WORK + 1 
1aaf : 20 53 1f JSR $1f53 ; (mods16 + 0)
1ab2 : 18 __ __ CLC
1ab3 : a5 05 __ LDA WORK + 2 
1ab5 : 69 30 __ ADC #$30
1ab7 : a6 4d __ LDX T4 + 0 
1ab9 : 9d e8 9f STA $9fe8,x ; (eb[0] + 0)
1abc : a5 4f __ LDA T5 + 0 
1abe : e6 4d __ INC T4 + 0 
1ac0 : 85 1b __ STA ACCU + 0 
1ac2 : a5 50 __ LDA T5 + 1 
1ac4 : 85 1c __ STA ACCU + 1 
1ac6 : a9 0a __ LDA #$0a
1ac8 : 85 03 __ STA WORK + 0 
1aca : a9 00 __ LDA #$00
1acc : 85 04 __ STA WORK + 1 
1ace : 20 94 1e JSR $1e94 ; (divs16 + 0)
1ad1 : a5 1b __ LDA ACCU + 0 
1ad3 : 85 4f __ STA T5 + 0 
1ad5 : a5 1c __ LDA ACCU + 1 
1ad7 : 85 50 __ STA T5 + 1 
1ad9 : 05 1b __ ORA ACCU + 0 
1adb : d0 ca __ BNE $1aa7 ; (b_ftoa.l80 + 0)
.s19:
1add : a5 4d __ LDA T4 + 0 
1adf : c9 02 __ CMP #$02
1ae1 : b0 9c __ BCS $1a7f ; (b_ftoa.s20 + 0)
.s128:
1ae3 : a9 30 __ LDA #$30
1ae5 : 90 91 __ BCC $1a78 ; (b_ftoa.s22 + 0)
.l62:
1ae7 : e6 49 __ INC T2 + 0 
1ae9 : d0 02 __ BNE $1aed ; (b_ftoa.s124 + 0)
.s123:
1aeb : e6 4a __ INC T2 + 1 
.s124:
1aed : a5 43 __ LDA T0 + 0 
1aef : 85 1b __ STA ACCU + 0 
1af1 : a5 44 __ LDA T0 + 1 
1af3 : 85 1c __ STA ACCU + 1 
1af5 : a5 45 __ LDA T0 + 2 
1af7 : 85 1d __ STA ACCU + 2 
1af9 : a5 46 __ LDA T0 + 3 
1afb : 85 1e __ STA ACCU + 3 
1afd : a9 00 __ LDA #$00
1aff : 85 03 __ STA WORK + 0 
1b01 : 85 04 __ STA WORK + 1 
1b03 : a9 20 __ LDA #$20
1b05 : 85 05 __ STA WORK + 2 
1b07 : a9 41 __ LDA #$41
1b09 : 85 06 __ STA WORK + 3 
1b0b : 20 00 1c JSR $1c00 ; (freg + 20)
1b0e : 20 e6 1d JSR $1de6 ; (crt_fdiv + 0)
1b11 : a5 1b __ LDA ACCU + 0 
1b13 : 85 43 __ STA T0 + 0 
1b15 : a5 1c __ LDA ACCU + 1 
1b17 : 85 44 __ STA T0 + 1 
1b19 : a6 1d __ LDX ACCU + 2 
1b1b : 86 45 __ STX T0 + 2 
1b1d : a5 1e __ LDA ACCU + 3 
1b1f : 85 46 __ STA T0 + 3 
1b21 : 10 03 __ BPL $1b26 ; (b_ftoa.s65 + 0)
1b23 : 4c cf 17 JMP $17cf ; (b_ftoa.s9 + 0)
.s65:
1b26 : c9 41 __ CMP #$41
1b28 : d0 0d __ BNE $1b37 ; (b_ftoa.s69 + 0)
.s66:
1b2a : e0 20 __ CPX #$20
1b2c : d0 09 __ BNE $1b37 ; (b_ftoa.s69 + 0)
.s67:
1b2e : a5 1c __ LDA ACCU + 1 
1b30 : 38 __ __ SEC
1b31 : d0 04 __ BNE $1b37 ; (b_ftoa.s69 + 0)
.s68:
1b33 : a5 1b __ LDA ACCU + 0 
1b35 : f0 02 __ BEQ $1b39 ; (b_ftoa.s63 + 0)
.s69:
1b37 : 90 ea __ BCC $1b23 ; (b_ftoa.s124 + 54)
.s63:
1b39 : e6 47 __ INC T1 + 0 
1b3b : d0 02 __ BNE $1b3f ; (b_ftoa.s126 + 0)
.s125:
1b3d : e6 48 __ INC T1 + 1 
.s126:
1b3f : a6 48 __ LDX T1 + 1 
1b41 : ca __ __ DEX
1b42 : d0 a3 __ BNE $1ae7 ; (b_ftoa.l62 + 0)
.s64:
1b44 : a5 47 __ LDA T1 + 0 
1b46 : c9 90 __ CMP #$90
1b48 : d0 9d __ BNE $1ae7 ; (b_ftoa.l62 + 0)
1b4a : 4c cf 17 JMP $17cf ; (b_ftoa.s9 + 0)
.s75:
1b4d : a9 30 __ LDA #$30
1b4f : a0 00 __ LDY #$00
1b51 : 91 0d __ STA (P0),y ; (buf + 0)
1b53 : 98 __ __ TYA
1b54 : c8 __ __ INY
1b55 : 91 0d __ STA (P0),y ; (buf + 0)
1b57 : 60 __ __ RTS
.s76:
1b58 : 49 80 __ EOR #$80
1b5a : 85 12 __ STA P5 ; (v + 3)
1b5c : 29 7f __ AND #$7f
1b5e : 05 11 __ ORA P4 ; (v + 2)
1b60 : 05 10 __ ORA P3 ; (v + 1)
1b62 : 05 0f __ ORA P2 ; (v + 0)
1b64 : f0 e7 __ BEQ $1b4d ; (b_ftoa.s75 + 0)
.s77:
1b66 : a9 01 __ LDA #$01
1b68 : 4c 3a 17 JMP $173a ; (b_ftoa.s7 + 0)
--------------------------------------------------------------------
strchr: ; strchr(const u8*,i16)->u8*
;  18, "C:/Users/g/claude/c64/oscar64/include/string.h"
.l4:
1b6b : a0 00 __ LDY #$00
1b6d : b1 0d __ LDA (P0),y ; (str + 0)
1b6f : c5 0f __ CMP P2 ; (ch + 0)
1b71 : d0 09 __ BNE $1b7c ; (strchr.s6 + 0)
.s5:
1b73 : a5 0d __ LDA P0 ; (str + 0)
1b75 : 85 1b __ STA ACCU + 0 
1b77 : a5 0e __ LDA P1 ; (str + 1)
.s3:
1b79 : 85 1c __ STA ACCU + 1 
1b7b : 60 __ __ RTS
.s6:
1b7c : aa __ __ TAX
1b7d : f0 09 __ BEQ $1b88 ; (strchr.s7 + 0)
.s8:
1b7f : e6 0d __ INC P0 ; (str + 0)
1b81 : d0 e8 __ BNE $1b6b ; (strchr.l4 + 0)
.s9:
1b83 : e6 0e __ INC P1 ; (str + 1)
1b85 : 4c 6b 1b JMP $1b6b ; (strchr.l4 + 0)
.s7:
1b88 : 85 1b __ STA ACCU + 0 
1b8a : 4c 79 1b JMP $1b79 ; (strchr.s3 + 0)
--------------------------------------------------------------------
strlen: ; strlen(const u8*)->i16
;  12, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1b8d : a9 00 __ LDA #$00
1b8f : 85 1b __ STA ACCU + 0 
1b91 : 85 1c __ STA ACCU + 1 
1b93 : a8 __ __ TAY
1b94 : b1 0d __ LDA (P0),y ; (str + 0)
1b96 : f0 10 __ BEQ $1ba8 ; (strlen.s3 + 0)
.s6:
1b98 : a2 00 __ LDX #$00
.l7:
1b9a : c8 __ __ INY
1b9b : d0 03 __ BNE $1ba0 ; (strlen.s9 + 0)
.s8:
1b9d : e6 0e __ INC P1 ; (str + 1)
1b9f : e8 __ __ INX
.s9:
1ba0 : b1 0d __ LDA (P0),y ; (str + 0)
1ba2 : d0 f6 __ BNE $1b9a ; (strlen.l7 + 0)
.s5:
1ba4 : 86 1c __ STX ACCU + 1 
1ba6 : 84 1b __ STY ACCU + 0 
.s3:
1ba8 : 60 __ __ RTS
--------------------------------------------------------------------
1ba9 : __ __ __ BYT 47 45 4e 53 3d 00                               : GENS=.
--------------------------------------------------------------------
1baf : __ __ __ BYT 41 4c 49 56 45 3d 00                            : ALIVE=.
--------------------------------------------------------------------
mul32by8: ; mul32by8
1bb6 : a0 00 __ LDY #$00
1bb8 : 84 07 __ STY WORK + 4 
1bba : 84 08 __ STY WORK + 5 
1bbc : 84 09 __ STY WORK + 6 
1bbe : 4a __ __ LSR
1bbf : b0 0d __ BCS $1bce ; (mul32by8 + 24)
1bc1 : f0 26 __ BEQ $1be9 ; (mul32by8 + 51)
1bc3 : 06 1b __ ASL ACCU + 0 
1bc5 : 26 1c __ ROL ACCU + 1 
1bc7 : 26 1d __ ROL ACCU + 2 
1bc9 : 26 1e __ ROL ACCU + 3 
1bcb : 4a __ __ LSR
1bcc : 90 f5 __ BCC $1bc3 ; (mul32by8 + 13)
1bce : aa __ __ TAX
1bcf : 18 __ __ CLC
1bd0 : a5 07 __ LDA WORK + 4 
1bd2 : 65 1b __ ADC ACCU + 0 
1bd4 : 85 07 __ STA WORK + 4 
1bd6 : a5 08 __ LDA WORK + 5 
1bd8 : 65 1c __ ADC ACCU + 1 
1bda : 85 08 __ STA WORK + 5 
1bdc : a5 09 __ LDA WORK + 6 
1bde : 65 1d __ ADC ACCU + 2 
1be0 : 85 09 __ STA WORK + 6 
1be2 : 98 __ __ TYA
1be3 : 65 1e __ ADC ACCU + 3 
1be5 : a8 __ __ TAY
1be6 : 8a __ __ TXA
1be7 : d0 da __ BNE $1bc3 ; (mul32by8 + 13)
1be9 : 84 0a __ STY WORK + 7 
1beb : 60 __ __ RTS
--------------------------------------------------------------------
freg: ; freg
1bec : b1 19 __ LDA (IP + 0),y 
1bee : c8 __ __ INY
1bef : aa __ __ TAX
1bf0 : b5 00 __ LDA $00,x 
1bf2 : 85 03 __ STA WORK + 0 
1bf4 : b5 01 __ LDA $01,x 
1bf6 : 85 04 __ STA WORK + 1 
1bf8 : b5 02 __ LDA $02,x 
1bfa : 85 05 __ STA WORK + 2 
1bfc : b5 03 __ LDA WORK + 0,x 
1bfe : 85 06 __ STA WORK + 3 
1c00 : a5 05 __ LDA WORK + 2 
1c02 : 0a __ __ ASL
1c03 : a5 06 __ LDA WORK + 3 
1c05 : 2a __ __ ROL
1c06 : 85 08 __ STA WORK + 5 
1c08 : f0 06 __ BEQ $1c10 ; (freg + 36)
1c0a : a5 05 __ LDA WORK + 2 
1c0c : 09 80 __ ORA #$80
1c0e : 85 05 __ STA WORK + 2 
1c10 : a5 1d __ LDA ACCU + 2 
1c12 : 0a __ __ ASL
1c13 : a5 1e __ LDA ACCU + 3 
1c15 : 2a __ __ ROL
1c16 : 85 07 __ STA WORK + 4 
1c18 : f0 06 __ BEQ $1c20 ; (freg + 52)
1c1a : a5 1d __ LDA ACCU + 2 
1c1c : 09 80 __ ORA #$80
1c1e : 85 1d __ STA ACCU + 2 
1c20 : 60 __ __ RTS
1c21 : 06 1e __ ASL ACCU + 3 
1c23 : a5 07 __ LDA WORK + 4 
1c25 : 6a __ __ ROR
1c26 : 85 1e __ STA ACCU + 3 
1c28 : b0 06 __ BCS $1c30 ; (freg + 68)
1c2a : a5 1d __ LDA ACCU + 2 
1c2c : 29 7f __ AND #$7f
1c2e : 85 1d __ STA ACCU + 2 
1c30 : 60 __ __ RTS
--------------------------------------------------------------------
faddsub: ; faddsub
1c31 : a5 06 __ LDA WORK + 3 
1c33 : 49 80 __ EOR #$80
1c35 : 85 06 __ STA WORK + 3 
1c37 : a9 ff __ LDA #$ff
1c39 : c5 07 __ CMP WORK + 4 
1c3b : f0 04 __ BEQ $1c41 ; (faddsub + 16)
1c3d : c5 08 __ CMP WORK + 5 
1c3f : d0 11 __ BNE $1c52 ; (faddsub + 33)
1c41 : a5 1e __ LDA ACCU + 3 
1c43 : 09 7f __ ORA #$7f
1c45 : 85 1e __ STA ACCU + 3 
1c47 : a9 80 __ LDA #$80
1c49 : 85 1d __ STA ACCU + 2 
1c4b : a9 00 __ LDA #$00
1c4d : 85 1b __ STA ACCU + 0 
1c4f : 85 1c __ STA ACCU + 1 
1c51 : 60 __ __ RTS
1c52 : 38 __ __ SEC
1c53 : a5 07 __ LDA WORK + 4 
1c55 : e5 08 __ SBC WORK + 5 
1c57 : f0 38 __ BEQ $1c91 ; (faddsub + 96)
1c59 : aa __ __ TAX
1c5a : b0 25 __ BCS $1c81 ; (faddsub + 80)
1c5c : e0 e9 __ CPX #$e9
1c5e : b0 0e __ BCS $1c6e ; (faddsub + 61)
1c60 : a5 08 __ LDA WORK + 5 
1c62 : 85 07 __ STA WORK + 4 
1c64 : a9 00 __ LDA #$00
1c66 : 85 1b __ STA ACCU + 0 
1c68 : 85 1c __ STA ACCU + 1 
1c6a : 85 1d __ STA ACCU + 2 
1c6c : f0 23 __ BEQ $1c91 ; (faddsub + 96)
1c6e : a5 1d __ LDA ACCU + 2 
1c70 : 4a __ __ LSR
1c71 : 66 1c __ ROR ACCU + 1 
1c73 : 66 1b __ ROR ACCU + 0 
1c75 : e8 __ __ INX
1c76 : d0 f8 __ BNE $1c70 ; (faddsub + 63)
1c78 : 85 1d __ STA ACCU + 2 
1c7a : a5 08 __ LDA WORK + 5 
1c7c : 85 07 __ STA WORK + 4 
1c7e : 4c 91 1c JMP $1c91 ; (faddsub + 96)
1c81 : e0 18 __ CPX #$18
1c83 : b0 33 __ BCS $1cb8 ; (faddsub + 135)
1c85 : a5 05 __ LDA WORK + 2 
1c87 : 4a __ __ LSR
1c88 : 66 04 __ ROR WORK + 1 
1c8a : 66 03 __ ROR WORK + 0 
1c8c : ca __ __ DEX
1c8d : d0 f8 __ BNE $1c87 ; (faddsub + 86)
1c8f : 85 05 __ STA WORK + 2 
1c91 : a5 1e __ LDA ACCU + 3 
1c93 : 29 80 __ AND #$80
1c95 : 85 1e __ STA ACCU + 3 
1c97 : 45 06 __ EOR WORK + 3 
1c99 : 30 31 __ BMI $1ccc ; (faddsub + 155)
1c9b : 18 __ __ CLC
1c9c : a5 1b __ LDA ACCU + 0 
1c9e : 65 03 __ ADC WORK + 0 
1ca0 : 85 1b __ STA ACCU + 0 
1ca2 : a5 1c __ LDA ACCU + 1 
1ca4 : 65 04 __ ADC WORK + 1 
1ca6 : 85 1c __ STA ACCU + 1 
1ca8 : a5 1d __ LDA ACCU + 2 
1caa : 65 05 __ ADC WORK + 2 
1cac : 85 1d __ STA ACCU + 2 
1cae : 90 08 __ BCC $1cb8 ; (faddsub + 135)
1cb0 : 66 1d __ ROR ACCU + 2 
1cb2 : 66 1c __ ROR ACCU + 1 
1cb4 : 66 1b __ ROR ACCU + 0 
1cb6 : e6 07 __ INC WORK + 4 
1cb8 : a5 07 __ LDA WORK + 4 
1cba : c9 ff __ CMP #$ff
1cbc : f0 83 __ BEQ $1c41 ; (faddsub + 16)
1cbe : 4a __ __ LSR
1cbf : 05 1e __ ORA ACCU + 3 
1cc1 : 85 1e __ STA ACCU + 3 
1cc3 : b0 06 __ BCS $1ccb ; (faddsub + 154)
1cc5 : a5 1d __ LDA ACCU + 2 
1cc7 : 29 7f __ AND #$7f
1cc9 : 85 1d __ STA ACCU + 2 
1ccb : 60 __ __ RTS
1ccc : 38 __ __ SEC
1ccd : a5 1b __ LDA ACCU + 0 
1ccf : e5 03 __ SBC WORK + 0 
1cd1 : 85 1b __ STA ACCU + 0 
1cd3 : a5 1c __ LDA ACCU + 1 
1cd5 : e5 04 __ SBC WORK + 1 
1cd7 : 85 1c __ STA ACCU + 1 
1cd9 : a5 1d __ LDA ACCU + 2 
1cdb : e5 05 __ SBC WORK + 2 
1cdd : 85 1d __ STA ACCU + 2 
1cdf : b0 19 __ BCS $1cfa ; (faddsub + 201)
1ce1 : 38 __ __ SEC
1ce2 : a9 00 __ LDA #$00
1ce4 : e5 1b __ SBC ACCU + 0 
1ce6 : 85 1b __ STA ACCU + 0 
1ce8 : a9 00 __ LDA #$00
1cea : e5 1c __ SBC ACCU + 1 
1cec : 85 1c __ STA ACCU + 1 
1cee : a9 00 __ LDA #$00
1cf0 : e5 1d __ SBC ACCU + 2 
1cf2 : 85 1d __ STA ACCU + 2 
1cf4 : a5 1e __ LDA ACCU + 3 
1cf6 : 49 80 __ EOR #$80
1cf8 : 85 1e __ STA ACCU + 3 
1cfa : a5 1d __ LDA ACCU + 2 
1cfc : 30 ba __ BMI $1cb8 ; (faddsub + 135)
1cfe : 05 1c __ ORA ACCU + 1 
1d00 : 05 1b __ ORA ACCU + 0 
1d02 : f0 0f __ BEQ $1d13 ; (faddsub + 226)
1d04 : c6 07 __ DEC WORK + 4 
1d06 : f0 0b __ BEQ $1d13 ; (faddsub + 226)
1d08 : 06 1b __ ASL ACCU + 0 
1d0a : 26 1c __ ROL ACCU + 1 
1d0c : 26 1d __ ROL ACCU + 2 
1d0e : 10 f4 __ BPL $1d04 ; (faddsub + 211)
1d10 : 4c b8 1c JMP $1cb8 ; (faddsub + 135)
1d13 : a9 00 __ LDA #$00
1d15 : 85 1b __ STA ACCU + 0 
1d17 : 85 1c __ STA ACCU + 1 
1d19 : 85 1d __ STA ACCU + 2 
1d1b : 85 1e __ STA ACCU + 3 
1d1d : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
1d1e : a5 1b __ LDA ACCU + 0 
1d20 : 05 1c __ ORA ACCU + 1 
1d22 : 05 1d __ ORA ACCU + 2 
1d24 : f0 0e __ BEQ $1d34 ; (crt_fmul + 22)
1d26 : a5 03 __ LDA WORK + 0 
1d28 : 05 04 __ ORA WORK + 1 
1d2a : 05 05 __ ORA WORK + 2 
1d2c : d0 09 __ BNE $1d37 ; (crt_fmul + 25)
1d2e : 85 1b __ STA ACCU + 0 
1d30 : 85 1c __ STA ACCU + 1 
1d32 : 85 1d __ STA ACCU + 2 
1d34 : 85 1e __ STA ACCU + 3 
1d36 : 60 __ __ RTS
1d37 : a5 1e __ LDA ACCU + 3 
1d39 : 45 06 __ EOR WORK + 3 
1d3b : 29 80 __ AND #$80
1d3d : 85 1e __ STA ACCU + 3 
1d3f : a9 ff __ LDA #$ff
1d41 : c5 07 __ CMP WORK + 4 
1d43 : f0 42 __ BEQ $1d87 ; (crt_fmul + 105)
1d45 : c5 08 __ CMP WORK + 5 
1d47 : f0 3e __ BEQ $1d87 ; (crt_fmul + 105)
1d49 : a9 00 __ LDA #$00
1d4b : 85 09 __ STA WORK + 6 
1d4d : 85 0a __ STA WORK + 7 
1d4f : 85 0b __ STA WORK + 8 
1d51 : a4 1b __ LDY ACCU + 0 
1d53 : a5 03 __ LDA WORK + 0 
1d55 : d0 06 __ BNE $1d5d ; (crt_fmul + 63)
1d57 : a5 04 __ LDA WORK + 1 
1d59 : f0 0a __ BEQ $1d65 ; (crt_fmul + 71)
1d5b : d0 05 __ BNE $1d62 ; (crt_fmul + 68)
1d5d : 20 b8 1d JSR $1db8 ; (crt_fmul8 + 0)
1d60 : a5 04 __ LDA WORK + 1 
1d62 : 20 b8 1d JSR $1db8 ; (crt_fmul8 + 0)
1d65 : a5 05 __ LDA WORK + 2 
1d67 : 20 b8 1d JSR $1db8 ; (crt_fmul8 + 0)
1d6a : 38 __ __ SEC
1d6b : a5 0b __ LDA WORK + 8 
1d6d : 30 06 __ BMI $1d75 ; (crt_fmul + 87)
1d6f : 06 09 __ ASL WORK + 6 
1d71 : 26 0a __ ROL WORK + 7 
1d73 : 2a __ __ ROL
1d74 : 18 __ __ CLC
1d75 : 29 7f __ AND #$7f
1d77 : 85 0b __ STA WORK + 8 
1d79 : a5 07 __ LDA WORK + 4 
1d7b : 65 08 __ ADC WORK + 5 
1d7d : 90 19 __ BCC $1d98 ; (crt_fmul + 122)
1d7f : e9 7f __ SBC #$7f
1d81 : b0 04 __ BCS $1d87 ; (crt_fmul + 105)
1d83 : c9 ff __ CMP #$ff
1d85 : d0 15 __ BNE $1d9c ; (crt_fmul + 126)
1d87 : a5 1e __ LDA ACCU + 3 
1d89 : 09 7f __ ORA #$7f
1d8b : 85 1e __ STA ACCU + 3 
1d8d : a9 80 __ LDA #$80
1d8f : 85 1d __ STA ACCU + 2 
1d91 : a9 00 __ LDA #$00
1d93 : 85 1b __ STA ACCU + 0 
1d95 : 85 1c __ STA ACCU + 1 
1d97 : 60 __ __ RTS
1d98 : e9 7e __ SBC #$7e
1d9a : 90 15 __ BCC $1db1 ; (crt_fmul + 147)
1d9c : 4a __ __ LSR
1d9d : 05 1e __ ORA ACCU + 3 
1d9f : 85 1e __ STA ACCU + 3 
1da1 : a9 00 __ LDA #$00
1da3 : 6a __ __ ROR
1da4 : 05 0b __ ORA WORK + 8 
1da6 : 85 1d __ STA ACCU + 2 
1da8 : a5 0a __ LDA WORK + 7 
1daa : 85 1c __ STA ACCU + 1 
1dac : a5 09 __ LDA WORK + 6 
1dae : 85 1b __ STA ACCU + 0 
1db0 : 60 __ __ RTS
1db1 : a9 00 __ LDA #$00
1db3 : 85 1e __ STA ACCU + 3 
1db5 : f0 d8 __ BEQ $1d8f ; (crt_fmul + 113)
1db7 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
1db8 : 38 __ __ SEC
1db9 : 6a __ __ ROR
1dba : 90 1e __ BCC $1dda ; (crt_fmul8 + 34)
1dbc : aa __ __ TAX
1dbd : 18 __ __ CLC
1dbe : 98 __ __ TYA
1dbf : 65 09 __ ADC WORK + 6 
1dc1 : 85 09 __ STA WORK + 6 
1dc3 : a5 0a __ LDA WORK + 7 
1dc5 : 65 1c __ ADC ACCU + 1 
1dc7 : 85 0a __ STA WORK + 7 
1dc9 : a5 0b __ LDA WORK + 8 
1dcb : 65 1d __ ADC ACCU + 2 
1dcd : 6a __ __ ROR
1dce : 85 0b __ STA WORK + 8 
1dd0 : 8a __ __ TXA
1dd1 : 66 0a __ ROR WORK + 7 
1dd3 : 66 09 __ ROR WORK + 6 
1dd5 : 4a __ __ LSR
1dd6 : f0 0d __ BEQ $1de5 ; (crt_fmul8 + 45)
1dd8 : b0 e2 __ BCS $1dbc ; (crt_fmul8 + 4)
1dda : 66 0b __ ROR WORK + 8 
1ddc : 66 0a __ ROR WORK + 7 
1dde : 66 09 __ ROR WORK + 6 
1de0 : 4a __ __ LSR
1de1 : 90 f7 __ BCC $1dda ; (crt_fmul8 + 34)
1de3 : d0 d7 __ BNE $1dbc ; (crt_fmul8 + 4)
1de5 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
1de6 : a5 1b __ LDA ACCU + 0 
1de8 : 05 1c __ ORA ACCU + 1 
1dea : 05 1d __ ORA ACCU + 2 
1dec : d0 03 __ BNE $1df1 ; (crt_fdiv + 11)
1dee : 85 1e __ STA ACCU + 3 
1df0 : 60 __ __ RTS
1df1 : a5 1e __ LDA ACCU + 3 
1df3 : 45 06 __ EOR WORK + 3 
1df5 : 29 80 __ AND #$80
1df7 : 85 1e __ STA ACCU + 3 
1df9 : a5 08 __ LDA WORK + 5 
1dfb : f0 62 __ BEQ $1e5f ; (crt_fdiv + 121)
1dfd : a5 07 __ LDA WORK + 4 
1dff : c9 ff __ CMP #$ff
1e01 : f0 5c __ BEQ $1e5f ; (crt_fdiv + 121)
1e03 : a9 00 __ LDA #$00
1e05 : 85 09 __ STA WORK + 6 
1e07 : 85 0a __ STA WORK + 7 
1e09 : 85 0b __ STA WORK + 8 
1e0b : a2 18 __ LDX #$18
1e0d : a5 1b __ LDA ACCU + 0 
1e0f : c5 03 __ CMP WORK + 0 
1e11 : a5 1c __ LDA ACCU + 1 
1e13 : e5 04 __ SBC WORK + 1 
1e15 : a5 1d __ LDA ACCU + 2 
1e17 : e5 05 __ SBC WORK + 2 
1e19 : 90 13 __ BCC $1e2e ; (crt_fdiv + 72)
1e1b : a5 1b __ LDA ACCU + 0 
1e1d : e5 03 __ SBC WORK + 0 
1e1f : 85 1b __ STA ACCU + 0 
1e21 : a5 1c __ LDA ACCU + 1 
1e23 : e5 04 __ SBC WORK + 1 
1e25 : 85 1c __ STA ACCU + 1 
1e27 : a5 1d __ LDA ACCU + 2 
1e29 : e5 05 __ SBC WORK + 2 
1e2b : 85 1d __ STA ACCU + 2 
1e2d : 38 __ __ SEC
1e2e : 26 09 __ ROL WORK + 6 
1e30 : 26 0a __ ROL WORK + 7 
1e32 : 26 0b __ ROL WORK + 8 
1e34 : ca __ __ DEX
1e35 : f0 0a __ BEQ $1e41 ; (crt_fdiv + 91)
1e37 : 06 1b __ ASL ACCU + 0 
1e39 : 26 1c __ ROL ACCU + 1 
1e3b : 26 1d __ ROL ACCU + 2 
1e3d : b0 dc __ BCS $1e1b ; (crt_fdiv + 53)
1e3f : 90 cc __ BCC $1e0d ; (crt_fdiv + 39)
1e41 : 38 __ __ SEC
1e42 : a5 0b __ LDA WORK + 8 
1e44 : 30 06 __ BMI $1e4c ; (crt_fdiv + 102)
1e46 : 06 09 __ ASL WORK + 6 
1e48 : 26 0a __ ROL WORK + 7 
1e4a : 2a __ __ ROL
1e4b : 18 __ __ CLC
1e4c : 29 7f __ AND #$7f
1e4e : 85 0b __ STA WORK + 8 
1e50 : a5 07 __ LDA WORK + 4 
1e52 : e5 08 __ SBC WORK + 5 
1e54 : 90 1a __ BCC $1e70 ; (crt_fdiv + 138)
1e56 : 18 __ __ CLC
1e57 : 69 7f __ ADC #$7f
1e59 : b0 04 __ BCS $1e5f ; (crt_fdiv + 121)
1e5b : c9 ff __ CMP #$ff
1e5d : d0 15 __ BNE $1e74 ; (crt_fdiv + 142)
1e5f : a5 1e __ LDA ACCU + 3 
1e61 : 09 7f __ ORA #$7f
1e63 : 85 1e __ STA ACCU + 3 
1e65 : a9 80 __ LDA #$80
1e67 : 85 1d __ STA ACCU + 2 
1e69 : a9 00 __ LDA #$00
1e6b : 85 1c __ STA ACCU + 1 
1e6d : 85 1b __ STA ACCU + 0 
1e6f : 60 __ __ RTS
1e70 : 69 7f __ ADC #$7f
1e72 : 90 15 __ BCC $1e89 ; (crt_fdiv + 163)
1e74 : 4a __ __ LSR
1e75 : 05 1e __ ORA ACCU + 3 
1e77 : 85 1e __ STA ACCU + 3 
1e79 : a9 00 __ LDA #$00
1e7b : 6a __ __ ROR
1e7c : 05 0b __ ORA WORK + 8 
1e7e : 85 1d __ STA ACCU + 2 
1e80 : a5 0a __ LDA WORK + 7 
1e82 : 85 1c __ STA ACCU + 1 
1e84 : a5 09 __ LDA WORK + 6 
1e86 : 85 1b __ STA ACCU + 0 
1e88 : 60 __ __ RTS
1e89 : a9 00 __ LDA #$00
1e8b : 85 1e __ STA ACCU + 3 
1e8d : 85 1d __ STA ACCU + 2 
1e8f : 85 1c __ STA ACCU + 1 
1e91 : 85 1b __ STA ACCU + 0 
1e93 : 60 __ __ RTS
--------------------------------------------------------------------
divs16: ; divs16
1e94 : 24 1c __ BIT ACCU + 1 
1e96 : 10 0d __ BPL $1ea5 ; (divs16 + 17)
1e98 : 20 b2 1e JSR $1eb2 ; (negaccu + 0)
1e9b : 24 04 __ BIT WORK + 1 
1e9d : 10 0d __ BPL $1eac ; (divs16 + 24)
1e9f : 20 c0 1e JSR $1ec0 ; (negtmp + 0)
1ea2 : 4c ce 1e JMP $1ece ; (divmod + 0)
1ea5 : 24 04 __ BIT WORK + 1 
1ea7 : 10 f9 __ BPL $1ea2 ; (divs16 + 14)
1ea9 : 20 c0 1e JSR $1ec0 ; (negtmp + 0)
1eac : 20 ce 1e JSR $1ece ; (divmod + 0)
1eaf : 4c b2 1e JMP $1eb2 ; (negaccu + 0)
--------------------------------------------------------------------
negaccu: ; negaccu
1eb2 : 38 __ __ SEC
1eb3 : a9 00 __ LDA #$00
1eb5 : e5 1b __ SBC ACCU + 0 
1eb7 : 85 1b __ STA ACCU + 0 
1eb9 : a9 00 __ LDA #$00
1ebb : e5 1c __ SBC ACCU + 1 
1ebd : 85 1c __ STA ACCU + 1 
1ebf : 60 __ __ RTS
--------------------------------------------------------------------
negtmp: ; negtmp
1ec0 : 38 __ __ SEC
1ec1 : a9 00 __ LDA #$00
1ec3 : e5 03 __ SBC WORK + 0 
1ec5 : 85 03 __ STA WORK + 0 
1ec7 : a9 00 __ LDA #$00
1ec9 : e5 04 __ SBC WORK + 1 
1ecb : 85 04 __ STA WORK + 1 
1ecd : 60 __ __ RTS
--------------------------------------------------------------------
divmod: ; divmod
1ece : a5 1c __ LDA ACCU + 1 
1ed0 : d0 31 __ BNE $1f03 ; (divmod + 53)
1ed2 : a5 04 __ LDA WORK + 1 
1ed4 : d0 1e __ BNE $1ef4 ; (divmod + 38)
1ed6 : 85 06 __ STA WORK + 3 
1ed8 : a2 04 __ LDX #$04
1eda : 06 1b __ ASL ACCU + 0 
1edc : 2a __ __ ROL
1edd : c5 03 __ CMP WORK + 0 
1edf : 90 02 __ BCC $1ee3 ; (divmod + 21)
1ee1 : e5 03 __ SBC WORK + 0 
1ee3 : 26 1b __ ROL ACCU + 0 
1ee5 : 2a __ __ ROL
1ee6 : c5 03 __ CMP WORK + 0 
1ee8 : 90 02 __ BCC $1eec ; (divmod + 30)
1eea : e5 03 __ SBC WORK + 0 
1eec : 26 1b __ ROL ACCU + 0 
1eee : ca __ __ DEX
1eef : d0 eb __ BNE $1edc ; (divmod + 14)
1ef1 : 85 05 __ STA WORK + 2 
1ef3 : 60 __ __ RTS
1ef4 : a5 1b __ LDA ACCU + 0 
1ef6 : 85 05 __ STA WORK + 2 
1ef8 : a5 1c __ LDA ACCU + 1 
1efa : 85 06 __ STA WORK + 3 
1efc : a9 00 __ LDA #$00
1efe : 85 1b __ STA ACCU + 0 
1f00 : 85 1c __ STA ACCU + 1 
1f02 : 60 __ __ RTS
1f03 : a5 04 __ LDA WORK + 1 
1f05 : d0 1f __ BNE $1f26 ; (divmod + 88)
1f07 : a5 03 __ LDA WORK + 0 
1f09 : 30 1b __ BMI $1f26 ; (divmod + 88)
1f0b : a9 00 __ LDA #$00
1f0d : 85 06 __ STA WORK + 3 
1f0f : a2 10 __ LDX #$10
1f11 : 06 1b __ ASL ACCU + 0 
1f13 : 26 1c __ ROL ACCU + 1 
1f15 : 2a __ __ ROL
1f16 : c5 03 __ CMP WORK + 0 
1f18 : 90 02 __ BCC $1f1c ; (divmod + 78)
1f1a : e5 03 __ SBC WORK + 0 
1f1c : 26 1b __ ROL ACCU + 0 
1f1e : 26 1c __ ROL ACCU + 1 
1f20 : ca __ __ DEX
1f21 : d0 f2 __ BNE $1f15 ; (divmod + 71)
1f23 : 85 05 __ STA WORK + 2 
1f25 : 60 __ __ RTS
1f26 : a9 00 __ LDA #$00
1f28 : 85 05 __ STA WORK + 2 
1f2a : 85 06 __ STA WORK + 3 
1f2c : 84 02 __ STY $02 
1f2e : a0 10 __ LDY #$10
1f30 : 18 __ __ CLC
1f31 : 26 1b __ ROL ACCU + 0 
1f33 : 26 1c __ ROL ACCU + 1 
1f35 : 26 05 __ ROL WORK + 2 
1f37 : 26 06 __ ROL WORK + 3 
1f39 : 38 __ __ SEC
1f3a : a5 05 __ LDA WORK + 2 
1f3c : e5 03 __ SBC WORK + 0 
1f3e : aa __ __ TAX
1f3f : a5 06 __ LDA WORK + 3 
1f41 : e5 04 __ SBC WORK + 1 
1f43 : 90 04 __ BCC $1f49 ; (divmod + 123)
1f45 : 86 05 __ STX WORK + 2 
1f47 : 85 06 __ STA WORK + 3 
1f49 : 88 __ __ DEY
1f4a : d0 e5 __ BNE $1f31 ; (divmod + 99)
1f4c : 26 1b __ ROL ACCU + 0 
1f4e : 26 1c __ ROL ACCU + 1 
1f50 : a4 02 __ LDY $02 
1f52 : 60 __ __ RTS
--------------------------------------------------------------------
mods16: ; mods16
1f53 : 24 1c __ BIT ACCU + 1 
1f55 : 10 10 __ BPL $1f67 ; (mods16 + 20)
1f57 : 20 b2 1e JSR $1eb2 ; (negaccu + 0)
1f5a : 24 04 __ BIT WORK + 1 
1f5c : 10 03 __ BPL $1f61 ; (mods16 + 14)
1f5e : 20 c0 1e JSR $1ec0 ; (negtmp + 0)
1f61 : 20 ce 1e JSR $1ece ; (divmod + 0)
1f64 : 4c 72 1f JMP $1f72 ; (negtmpb + 0)
1f67 : 24 04 __ BIT WORK + 1 
1f69 : 10 03 __ BPL $1f6e ; (mods16 + 27)
1f6b : 20 c0 1e JSR $1ec0 ; (negtmp + 0)
1f6e : 4c ce 1e JMP $1ece ; (divmod + 0)
1f71 : 60 __ __ RTS
--------------------------------------------------------------------
negtmpb: ; negtmpb
1f72 : 38 __ __ SEC
1f73 : a9 00 __ LDA #$00
1f75 : e5 05 __ SBC WORK + 2 
1f77 : 85 05 __ STA WORK + 2 
1f79 : a9 00 __ LDA #$00
1f7b : e5 06 __ SBC WORK + 3 
1f7d : 85 06 __ STA WORK + 3 
1f7f : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
1f80 : a5 1e __ LDA ACCU + 3 
1f82 : 30 03 __ BMI $1f87 ; (f32_to_i32 + 7)
1f84 : 4c a4 1f JMP $1fa4 ; (f32_to_u32 + 0)
1f87 : 20 a4 1f JSR $1fa4 ; (f32_to_u32 + 0)
1f8a : 38 __ __ SEC
1f8b : a9 00 __ LDA #$00
1f8d : e5 1b __ SBC ACCU + 0 
1f8f : 85 1b __ STA ACCU + 0 
1f91 : a9 00 __ LDA #$00
1f93 : e5 1c __ SBC ACCU + 1 
1f95 : 85 1c __ STA ACCU + 1 
1f97 : a9 00 __ LDA #$00
1f99 : e5 1d __ SBC ACCU + 2 
1f9b : 85 1d __ STA ACCU + 2 
1f9d : a9 00 __ LDA #$00
1f9f : e5 1e __ SBC ACCU + 3 
1fa1 : 85 1e __ STA ACCU + 3 
1fa3 : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
1fa4 : 20 10 1c JSR $1c10 ; (freg + 36)
1fa7 : a5 07 __ LDA WORK + 4 
1fa9 : c9 7f __ CMP #$7f
1fab : b0 0b __ BCS $1fb8 ; (f32_to_u32 + 20)
1fad : a9 00 __ LDA #$00
1faf : 85 1b __ STA ACCU + 0 
1fb1 : 85 1c __ STA ACCU + 1 
1fb3 : 85 1d __ STA ACCU + 2 
1fb5 : 85 1e __ STA ACCU + 3 
1fb7 : 60 __ __ RTS
1fb8 : 38 __ __ SEC
1fb9 : e9 9e __ SBC #$9e
1fbb : f0 13 __ BEQ $1fd0 ; (f32_to_u32 + 44)
1fbd : 90 04 __ BCC $1fc3 ; (f32_to_u32 + 31)
1fbf : a9 ff __ LDA #$ff
1fc1 : d0 ec __ BNE $1faf ; (f32_to_u32 + 11)
1fc3 : aa __ __ TAX
1fc4 : a9 00 __ LDA #$00
1fc6 : 46 1d __ LSR ACCU + 2 
1fc8 : 66 1c __ ROR ACCU + 1 
1fca : 66 1b __ ROR ACCU + 0 
1fcc : 6a __ __ ROR
1fcd : e8 __ __ INX
1fce : d0 f6 __ BNE $1fc6 ; (f32_to_u32 + 34)
1fd0 : a6 1d __ LDX ACCU + 2 
1fd2 : 86 1e __ STX ACCU + 3 
1fd4 : a6 1c __ LDX ACCU + 1 
1fd6 : 86 1d __ STX ACCU + 2 
1fd8 : a6 1b __ LDX ACCU + 0 
1fda : 86 1c __ STX ACCU + 1 
1fdc : 85 1b __ STA ACCU + 0 
1fde : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
1fdf : 24 1e __ BIT ACCU + 3 
1fe1 : 30 03 __ BMI $1fe6 ; (sint32_to_float + 7)
1fe3 : 4c 09 20 JMP $2009 ; (uint32_to_float + 0)
1fe6 : 38 __ __ SEC
1fe7 : a9 00 __ LDA #$00
1fe9 : e5 1b __ SBC ACCU + 0 
1feb : 85 1b __ STA ACCU + 0 
1fed : a9 00 __ LDA #$00
1fef : e5 1c __ SBC ACCU + 1 
1ff1 : 85 1c __ STA ACCU + 1 
1ff3 : a9 00 __ LDA #$00
1ff5 : e5 1d __ SBC ACCU + 2 
1ff7 : 85 1d __ STA ACCU + 2 
1ff9 : a9 00 __ LDA #$00
1ffb : e5 1e __ SBC ACCU + 3 
1ffd : 85 1e __ STA ACCU + 3 
1fff : 20 09 20 JSR $2009 ; (uint32_to_float + 0)
2002 : a5 1e __ LDA ACCU + 3 
2004 : 09 80 __ ORA #$80
2006 : 85 1e __ STA ACCU + 3 
2008 : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
2009 : a5 1b __ LDA ACCU + 0 
200b : 05 1c __ ORA ACCU + 1 
200d : 05 1d __ ORA ACCU + 2 
200f : 05 1e __ ORA ACCU + 3 
2011 : d0 01 __ BNE $2014 ; (uint32_to_float + 11)
2013 : 60 __ __ RTS
2014 : a2 9e __ LDX #$9e
2016 : a5 1e __ LDA ACCU + 3 
2018 : 30 0a __ BMI $2024 ; (uint32_to_float + 27)
201a : ca __ __ DEX
201b : 06 1b __ ASL ACCU + 0 
201d : 26 1c __ ROL ACCU + 1 
201f : 26 1d __ ROL ACCU + 2 
2021 : 2a __ __ ROL
2022 : 10 f6 __ BPL $201a ; (uint32_to_float + 17)
2024 : 24 1b __ BIT ACCU + 0 
2026 : 10 13 __ BPL $203b ; (uint32_to_float + 50)
2028 : e6 1c __ INC ACCU + 1 
202a : d0 0f __ BNE $203b ; (uint32_to_float + 50)
202c : e6 1d __ INC ACCU + 2 
202e : d0 0b __ BNE $203b ; (uint32_to_float + 50)
2030 : 18 __ __ CLC
2031 : 69 01 __ ADC #$01
2033 : 90 06 __ BCC $203b ; (uint32_to_float + 50)
2035 : 4a __ __ LSR
2036 : 66 1d __ ROR ACCU + 2 
2038 : 66 1c __ ROR ACCU + 1 
203a : e8 __ __ INX
203b : 0a __ __ ASL
203c : a4 1c __ LDY ACCU + 1 
203e : 84 1b __ STY ACCU + 0 
2040 : a4 1d __ LDY ACCU + 2 
2042 : 84 1c __ STY ACCU + 1 
2044 : 85 1d __ STA ACCU + 2 
2046 : 8a __ __ TXA
2047 : 4a __ __ LSR
2048 : 85 1e __ STA ACCU + 3 
204a : 66 1d __ ROR ACCU + 2 
204c : 60 __ __ RTS
--------------------------------------------------------------------
mul32: ; mul32
204d : a5 04 __ LDA WORK + 1 
204f : 05 05 __ ORA WORK + 2 
2051 : 05 06 __ ORA WORK + 3 
2053 : d0 05 __ BNE $205a ; (mul32 + 13)
2055 : a5 03 __ LDA WORK + 0 
2057 : 4c b6 1b JMP $1bb6 ; (mul32by8 + 0)
205a : a0 00 __ LDY #$00
205c : 84 07 __ STY WORK + 4 
205e : 84 08 __ STY WORK + 5 
2060 : 98 __ __ TYA
2061 : 38 __ __ SEC
2062 : 66 03 __ ROR WORK + 0 
2064 : 90 15 __ BCC $207b ; (mul32 + 46)
2066 : aa __ __ TAX
2067 : 18 __ __ CLC
2068 : a5 07 __ LDA WORK + 4 
206a : 65 1b __ ADC ACCU + 0 
206c : 85 07 __ STA WORK + 4 
206e : a5 08 __ LDA WORK + 5 
2070 : 65 1c __ ADC ACCU + 1 
2072 : 85 08 __ STA WORK + 5 
2074 : 98 __ __ TYA
2075 : 65 1d __ ADC ACCU + 2 
2077 : a8 __ __ TAY
2078 : 8a __ __ TXA
2079 : 65 1e __ ADC ACCU + 3 
207b : 46 04 __ LSR WORK + 1 
207d : 90 0f __ BCC $208e ; (mul32 + 65)
207f : aa __ __ TAX
2080 : 18 __ __ CLC
2081 : a5 08 __ LDA WORK + 5 
2083 : 65 1b __ ADC ACCU + 0 
2085 : 85 08 __ STA WORK + 5 
2087 : 98 __ __ TYA
2088 : 65 1c __ ADC ACCU + 1 
208a : a8 __ __ TAY
208b : 8a __ __ TXA
208c : 65 1d __ ADC ACCU + 2 
208e : 46 05 __ LSR WORK + 2 
2090 : 90 09 __ BCC $209b ; (mul32 + 78)
2092 : aa __ __ TAX
2093 : 18 __ __ CLC
2094 : 98 __ __ TYA
2095 : 65 1b __ ADC ACCU + 0 
2097 : a8 __ __ TAY
2098 : 8a __ __ TXA
2099 : 65 1c __ ADC ACCU + 1 
209b : 46 06 __ LSR WORK + 3 
209d : 90 03 __ BCC $20a2 ; (mul32 + 85)
209f : 18 __ __ CLC
20a0 : 65 1b __ ADC ACCU + 0 
20a2 : 06 1b __ ASL ACCU + 0 
20a4 : 26 1c __ ROL ACCU + 1 
20a6 : 26 1d __ ROL ACCU + 2 
20a8 : 26 1e __ ROL ACCU + 3 
20aa : 46 03 __ LSR WORK + 0 
20ac : 90 cd __ BCC $207b ; (mul32 + 46)
20ae : d0 b6 __ BNE $2066 ; (mul32 + 25)
20b0 : 84 09 __ STY WORK + 6 
20b2 : 85 0a __ STA WORK + 7 
20b4 : 60 __ __ RTS
--------------------------------------------------------------------
divs32: ; divs32
20b5 : 24 1e __ BIT ACCU + 3 
20b7 : 10 0d __ BPL $20c6 ; (divs32 + 17)
20b9 : 20 d3 20 JSR $20d3 ; (negaccu32 + 0)
20bc : 24 06 __ BIT WORK + 3 
20be : 10 0d __ BPL $20cd ; (divs32 + 24)
20c0 : 20 ed 20 JSR $20ed ; (negtmp32 + 0)
20c3 : 4c 07 21 JMP $2107 ; (divmod32 + 0)
20c6 : 24 06 __ BIT WORK + 3 
20c8 : 10 f9 __ BPL $20c3 ; (divs32 + 14)
20ca : 20 ed 20 JSR $20ed ; (negtmp32 + 0)
20cd : 20 07 21 JSR $2107 ; (divmod32 + 0)
20d0 : 4c d3 20 JMP $20d3 ; (negaccu32 + 0)
--------------------------------------------------------------------
negaccu32: ; negaccu32
20d3 : 38 __ __ SEC
20d4 : a9 00 __ LDA #$00
20d6 : e5 1b __ SBC ACCU + 0 
20d8 : 85 1b __ STA ACCU + 0 
20da : a9 00 __ LDA #$00
20dc : e5 1c __ SBC ACCU + 1 
20de : 85 1c __ STA ACCU + 1 
20e0 : a9 00 __ LDA #$00
20e2 : e5 1d __ SBC ACCU + 2 
20e4 : 85 1d __ STA ACCU + 2 
20e6 : a9 00 __ LDA #$00
20e8 : e5 1e __ SBC ACCU + 3 
20ea : 85 1e __ STA ACCU + 3 
20ec : 60 __ __ RTS
--------------------------------------------------------------------
negtmp32: ; negtmp32
20ed : 38 __ __ SEC
20ee : a9 00 __ LDA #$00
20f0 : e5 03 __ SBC WORK + 0 
20f2 : 85 03 __ STA WORK + 0 
20f4 : a9 00 __ LDA #$00
20f6 : e5 04 __ SBC WORK + 1 
20f8 : 85 04 __ STA WORK + 1 
20fa : a9 00 __ LDA #$00
20fc : e5 05 __ SBC WORK + 2 
20fe : 85 05 __ STA WORK + 2 
2100 : a9 00 __ LDA #$00
2102 : e5 06 __ SBC WORK + 3 
2104 : 85 06 __ STA WORK + 3 
2106 : 60 __ __ RTS
--------------------------------------------------------------------
divmod32: ; divmod32
2107 : 84 02 __ STY $02 
2109 : a0 20 __ LDY #$20
210b : a9 00 __ LDA #$00
210d : 85 07 __ STA WORK + 4 
210f : 85 08 __ STA WORK + 5 
2111 : 85 09 __ STA WORK + 6 
2113 : 85 0a __ STA WORK + 7 
2115 : a5 05 __ LDA WORK + 2 
2117 : 05 06 __ ORA WORK + 3 
2119 : d0 78 __ BNE $2193 ; (divmod32 + 140)
211b : a5 04 __ LDA WORK + 1 
211d : d0 27 __ BNE $2146 ; (divmod32 + 63)
211f : 18 __ __ CLC
2120 : 26 1b __ ROL ACCU + 0 
2122 : 26 1c __ ROL ACCU + 1 
2124 : 26 1d __ ROL ACCU + 2 
2126 : 26 1e __ ROL ACCU + 3 
2128 : 2a __ __ ROL
2129 : 90 05 __ BCC $2130 ; (divmod32 + 41)
212b : e5 03 __ SBC WORK + 0 
212d : 38 __ __ SEC
212e : b0 06 __ BCS $2136 ; (divmod32 + 47)
2130 : c5 03 __ CMP WORK + 0 
2132 : 90 02 __ BCC $2136 ; (divmod32 + 47)
2134 : e5 03 __ SBC WORK + 0 
2136 : 88 __ __ DEY
2137 : d0 e7 __ BNE $2120 ; (divmod32 + 25)
2139 : 85 07 __ STA WORK + 4 
213b : 26 1b __ ROL ACCU + 0 
213d : 26 1c __ ROL ACCU + 1 
213f : 26 1d __ ROL ACCU + 2 
2141 : 26 1e __ ROL ACCU + 3 
2143 : a4 02 __ LDY $02 
2145 : 60 __ __ RTS
2146 : a5 1e __ LDA ACCU + 3 
2148 : d0 10 __ BNE $215a ; (divmod32 + 83)
214a : a6 1d __ LDX ACCU + 2 
214c : 86 1e __ STX ACCU + 3 
214e : a6 1c __ LDX ACCU + 1 
2150 : 86 1d __ STX ACCU + 2 
2152 : a6 1b __ LDX ACCU + 0 
2154 : 86 1c __ STX ACCU + 1 
2156 : 85 1b __ STA ACCU + 0 
2158 : a0 18 __ LDY #$18
215a : 18 __ __ CLC
215b : 26 1b __ ROL ACCU + 0 
215d : 26 1c __ ROL ACCU + 1 
215f : 26 1d __ ROL ACCU + 2 
2161 : 26 1e __ ROL ACCU + 3 
2163 : 26 07 __ ROL WORK + 4 
2165 : 26 08 __ ROL WORK + 5 
2167 : 90 0c __ BCC $2175 ; (divmod32 + 110)
2169 : a5 07 __ LDA WORK + 4 
216b : e5 03 __ SBC WORK + 0 
216d : aa __ __ TAX
216e : a5 08 __ LDA WORK + 5 
2170 : e5 04 __ SBC WORK + 1 
2172 : 38 __ __ SEC
2173 : b0 0c __ BCS $2181 ; (divmod32 + 122)
2175 : 38 __ __ SEC
2176 : a5 07 __ LDA WORK + 4 
2178 : e5 03 __ SBC WORK + 0 
217a : aa __ __ TAX
217b : a5 08 __ LDA WORK + 5 
217d : e5 04 __ SBC WORK + 1 
217f : 90 04 __ BCC $2185 ; (divmod32 + 126)
2181 : 86 07 __ STX WORK + 4 
2183 : 85 08 __ STA WORK + 5 
2185 : 88 __ __ DEY
2186 : d0 d3 __ BNE $215b ; (divmod32 + 84)
2188 : 26 1b __ ROL ACCU + 0 
218a : 26 1c __ ROL ACCU + 1 
218c : 26 1d __ ROL ACCU + 2 
218e : 26 1e __ ROL ACCU + 3 
2190 : a4 02 __ LDY $02 
2192 : 60 __ __ RTS
2193 : a0 10 __ LDY #$10
2195 : a5 1e __ LDA ACCU + 3 
2197 : 85 08 __ STA WORK + 5 
2199 : a5 1d __ LDA ACCU + 2 
219b : 85 07 __ STA WORK + 4 
219d : a9 00 __ LDA #$00
219f : 85 1d __ STA ACCU + 2 
21a1 : 85 1e __ STA ACCU + 3 
21a3 : 18 __ __ CLC
21a4 : 26 1b __ ROL ACCU + 0 
21a6 : 26 1c __ ROL ACCU + 1 
21a8 : 26 07 __ ROL WORK + 4 
21aa : 26 08 __ ROL WORK + 5 
21ac : 26 09 __ ROL WORK + 6 
21ae : 26 0a __ ROL WORK + 7 
21b0 : a5 07 __ LDA WORK + 4 
21b2 : c5 03 __ CMP WORK + 0 
21b4 : a5 08 __ LDA WORK + 5 
21b6 : e5 04 __ SBC WORK + 1 
21b8 : a5 09 __ LDA WORK + 6 
21ba : e5 05 __ SBC WORK + 2 
21bc : aa __ __ TAX
21bd : a5 0a __ LDA WORK + 7 
21bf : e5 06 __ SBC WORK + 3 
21c1 : 90 11 __ BCC $21d4 ; (divmod32 + 205)
21c3 : 86 09 __ STX WORK + 6 
21c5 : 85 0a __ STA WORK + 7 
21c7 : a5 07 __ LDA WORK + 4 
21c9 : e5 03 __ SBC WORK + 0 
21cb : 85 07 __ STA WORK + 4 
21cd : a5 08 __ LDA WORK + 5 
21cf : e5 04 __ SBC WORK + 1 
21d1 : 85 08 __ STA WORK + 5 
21d3 : 38 __ __ SEC
21d4 : 88 __ __ DEY
21d5 : d0 cd __ BNE $21a4 ; (divmod32 + 157)
21d7 : 26 1b __ ROL ACCU + 0 
21d9 : 26 1c __ ROL ACCU + 1 
21db : a4 02 __ LDY $02 
21dd : 60 __ __ RTS
--------------------------------------------------------------------
mods32: ; mods32
21de : 24 1e __ BIT ACCU + 3 
21e0 : 10 13 __ BPL $21f5 ; (mods32 + 23)
21e2 : 20 d3 20 JSR $20d3 ; (negaccu32 + 0)
21e5 : 24 06 __ BIT WORK + 3 
21e7 : 10 03 __ BPL $21ec ; (mods32 + 14)
21e9 : 20 ed 20 JSR $20ed ; (negtmp32 + 0)
21ec : 20 07 21 JSR $2107 ; (divmod32 + 0)
21ef : 4c ff 21 JMP $21ff ; (negtmp32b + 0)
21f2 : 4c 07 21 JMP $2107 ; (divmod32 + 0)
21f5 : 24 06 __ BIT WORK + 3 
21f7 : 10 f9 __ BPL $21f2 ; (mods32 + 20)
21f9 : 20 ed 20 JSR $20ed ; (negtmp32 + 0)
21fc : 4c 07 21 JMP $2107 ; (divmod32 + 0)
--------------------------------------------------------------------
negtmp32b: ; negtmp32b
21ff : 38 __ __ SEC
2200 : a9 00 __ LDA #$00
2202 : e5 07 __ SBC WORK + 4 
2204 : 85 07 __ STA WORK + 4 
2206 : a9 00 __ LDA #$00
2208 : e5 08 __ SBC WORK + 5 
220a : 85 08 __ STA WORK + 5 
220c : a9 00 __ LDA #$00
220e : e5 09 __ SBC WORK + 6 
2210 : 85 09 __ STA WORK + 6 
2212 : a9 00 __ LDA #$00
2214 : e5 0a __ SBC WORK + 7 
2216 : 85 0a __ STA WORK + 7 
2218 : 60 __ __ RTS
--------------------------------------------------------------------
__multab16384H:
2219 : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
spentry:
221d : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
b_mem:
221e : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
2220 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
2222 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
2224 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tab:
2226 : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
2236 : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
2246 : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
2256 : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
2266 : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
2276 : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
2286 : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
2296 : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
b_rndSeed:
22a6 : __ __ __ BYT 78 56 34 12                                     : xV4.
--------------------------------------------------------------------
tsb_sintab:
22aa : __ __ __ BSS	64
--------------------------------------------------------------------
tsb_drawtab:
22ea : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_ri:
22f2 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_ci:
22f4 : __ __ __ BSS	2
--------------------------------------------------------------------
b_t_0:
22f6 : __ __ __ BSS	4
--------------------------------------------------------------------
b_t_1:
22fa : __ __ __ BSS	4
--------------------------------------------------------------------
b_t_2:
22fe : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_ki:
2302 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_xi:
2304 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_bbi:
2306 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_yi:
230a : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_nbi:
230c : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_si:
2310 : __ __ __ BSS	4
