/* OPTIMIZE_C -- manzoo.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_pi;
static breal_t b_v_cxf;
static breal_t b_v_cyf;
static breal_t b_v_dxf;
static breal_t b_v_dyf;
static breal_t b_v_xrf;
static breal_t b_v_yif;
static bint_t b_v_sai;
static bint_t b_v_cai;
static breal_t b_v_cif;
static int b_v_ji;
static breal_t b_v_crf;
static int b_v_ii;
static breal_t b_v_zrf;
static breal_t b_v_zif;
static breal_t b_v_kf;
static breal_t b_v_rrf;
static breal_t b_v_iif;
static breal_t b_v_nzf;
static int b_v_ci;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{1,0,-190.797,0,0},{1,0,28.850999999999999,0,0},{1,0,67.840000000000003,0,0},{1,0,-0.89600000000000002,0,0},{1,0,-454.96300000000002,0,0},{1,0,-0.51200000000000001,0,0},{1,0,-320,0,0},{1,0,5.1200000000000001,0,0},{1,0,-22.733000000000001,0,0},{1,0,166.52799999999999,0,0}};
int b_data_len = 10;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 5 */
b_L5: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		b_putc(147);
		b_nl();
		/* line 6 */
b_L6: ;
		b_dataPtr = 0;
		b_v_pi=(0);
		b_v_cxf=b_read_real();
		b_v_cyf=b_read_real();
		b_v_dxf=(16);
		b_v_dyf=(26);
		/* line 10 */
b_L10: ;
		b_v_xrf=((b_v_cxf)-((((19.5))*(b_v_dxf))));
		b_v_yif=((b_v_cyf)-((((12))*(b_v_dyf))));
		/* line 20 */
b_L20: ;
		b_v_sai=(1024);
		b_v_cai=(55296.0);
		/* line 30 */
b_L30: ;
		b_v_cif=b_v_yif;
		b_v_ji=(0);
		if(b_v_ji > 24) goto b_f0_e;
b_f0_t: ;
		/* line 40 */
b_L40: ;
		b_v_crf=b_v_xrf;
		b_v_ii=(0);
		if(b_v_ii > 39) goto b_f1_e;
b_f1_t: ;
		/* line 50 */
b_L50: ;
		b_v_zrf=(0);
		b_v_zif=(0);
		b_v_kf=(0);
		/* line 60 */
b_L60: ;
		b_v_rrf=((((b_v_zrf)*(b_v_zrf)))*((0.00390625)));
		b_v_iif=((((b_v_zif)*(b_v_zif)))*((0.00390625)));
		if(-((((b_v_rrf)+(b_v_iif))) > ((1024)))){ goto b_L100; }
		/* line 70 */
b_L70: ;
		b_v_nzf=((((((b_v_zrf)*(b_v_zif)))*((2))))*((0.00390625)));
		/* line 80 */
b_L80: ;
		b_v_zif=((b_v_nzf)+(b_v_cif));
		b_v_zrf=((((b_v_rrf)-(b_v_iif)))+(b_v_crf));
		b_v_kf=((b_v_kf)+((1)));
		if(-((b_v_kf) < ((256)))){ goto b_L60; }
		/* line 90 */
b_L90: ;
		b_poke(b_v_sai,(160));
		b_poke(b_v_cai,(0));
		goto b_L120;
		/* line 100 */
b_L100: ;
		b_v_ci=((bint_t)(b_v_kf) & B_INT((15)));
		if(-((b_v_ci) == ((0)))){
			b_v_ci=(6);
		}
		/* line 110 */
b_L110: ;
		b_poke(b_v_sai,(160));
		b_poke(b_v_cai,b_v_ci);
		/* line 120 */
b_L120: ;
		b_v_crf=((b_v_crf)+(b_v_dxf));
		b_v_sai=((b_v_sai)+((1)));
		b_v_cai=((b_v_cai)+((1)));
		b_v_ii += 1;
		if(b_v_ii <= 39) goto b_f1_t;
b_f1_e: ;
		/* line 130 */
b_L130: ;
		b_v_cif=((b_v_cif)+(b_v_dyf));
		b_v_ji += 1;
		if(b_v_ji <= 24) goto b_f0_t;
b_f0_e: ;
		/* line 135 */
b_L135: ;
		b_v_dxf=((b_v_dxf)*((0.94999999995343387)));
		b_v_dyf=((b_v_dyf)*((0.94999999995343387)));
		if(-((b_v_dxf) > ((0.0069999999996070983)))){ goto b_L10; }
		/* line 136 */
b_L136: ;
		b_v_pi=((b_v_pi)+((1)));
		if(-((b_v_pi) > ((4)))){
			b_v_pi=(0);
			b_dataPtr = 0;
		}
		/* line 137 */
b_L137: ;
		b_v_cxf=b_read_real();
		b_v_cyf=b_read_real();
		b_v_dxf=(16);
		b_v_dyf=(26);
		goto b_L10;
		/* line 138 */
b_L138: ;
b_return: ;
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
