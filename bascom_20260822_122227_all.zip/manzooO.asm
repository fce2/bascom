; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e b9 19 STX $19b9 ; (spentry + 0)
0811 : a2 1b __ LDX #$1b
0813 : a0 8c __ LDY #$8c
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 1b __ CPX #$1b
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 8c __ CPY #$8c
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 8f __ LDA #$8f
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  35, "C:/Users/g/claude/cpus/6502/examples/compiler/release/manzoo.c"
.s1:
0880 : a2 1b __ LDX #$1b
0882 : b5 53 __ LDA T3 + 0,x 
0884 : 9d 91 9f STA $9f91,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 be 0e JSR $0ebe ; (b_init.s4 + 0)
088d : 20 8f 0f JSR $0f8f ; (tsb_init.s4 + 0)
0890 : ad ba 19 LDA $19ba ; (b_mem + 0)
0893 : 85 51 __ STA T11 + 0 
0895 : 85 1f __ STA ADDR + 0 
0897 : a9 93 __ LDA #$93
0899 : 85 13 __ STA P6 
089b : ad bb 19 LDA $19bb ; (b_mem + 1)
089e : 85 52 __ STA T11 + 1 
08a0 : 18 __ __ CLC
08a1 : 69 d0 __ ADC #$d0
08a3 : 85 20 __ STA ADDR + 1 
08a5 : a9 00 __ LDA #$00
08a7 : a0 20 __ LDY #$20
08a9 : 91 1f __ STA (ADDR + 0),y 
08ab : c8 __ __ INY
08ac : 91 1f __ STA (ADDR + 0),y 
08ae : 20 de 0f JSR $0fde ; (b_putc.s4 + 0)
08b1 : a9 0d __ LDA #$0d
08b3 : 85 13 __ STA P6 
08b5 : 20 de 0f JSR $0fde ; (b_putc.s4 + 0)
08b8 : a9 00 __ LDA #$00
08ba : 8d ce 19 STA $19ce ; (b_v_pi + 0)
08bd : 8d cf 19 STA $19cf ; (b_v_pi + 1)
08c0 : 8d c2 19 STA $19c2 ; (b_dataPtr + 0)
08c3 : 8d c3 19 STA $19c3 ; (b_dataPtr + 1)
.l5:
08c6 : 20 2b 12 JSR $122b ; (b_read_real.s4 + 0)
08c9 : a5 1b __ LDA ACCU + 0 
08cb : 85 6b __ STA T10 + 0 
08cd : a5 1c __ LDA ACCU + 1 
08cf : 85 6c __ STA T10 + 1 
08d1 : a5 1d __ LDA ACCU + 2 
08d3 : 85 6d __ STA T10 + 2 
08d5 : a5 1e __ LDA ACCU + 3 
08d7 : 85 6e __ STA T10 + 3 
08d9 : 20 2b 12 JSR $122b ; (b_read_real.s4 + 0)
08dc : a5 1b __ LDA ACCU + 0 
08de : 85 43 __ STA T0 + 0 
08e0 : a5 1c __ LDA ACCU + 1 
08e2 : 85 44 __ STA T0 + 1 
08e4 : a5 1d __ LDA ACCU + 2 
08e6 : 85 45 __ STA T0 + 2 
08e8 : a5 1e __ LDA ACCU + 3 
08ea : 85 46 __ STA T0 + 3 
08ec : a9 00 __ LDA #$00
08ee : 8d d4 19 STA $19d4 ; (b_v_dyf + 0)
08f1 : 8d d5 19 STA $19d5 ; (b_v_dyf + 1)
08f4 : 8d d0 19 STA $19d0 ; (b_v_dxf + 0)
08f7 : 8d d1 19 STA $19d1 ; (b_v_dxf + 1)
08fa : a9 41 __ LDA #$41
08fc : 8d d7 19 STA $19d7 ; (b_v_dyf + 3)
08ff : 8d d3 19 STA $19d3 ; (b_v_dxf + 3)
0902 : a9 d0 __ LDA #$d0
0904 : 8d d6 19 STA $19d6 ; (b_v_dyf + 2)
0907 : a9 80 __ LDA #$80
0909 : 8d d2 19 STA $19d2 ; (b_v_dxf + 2)
.l6:
090c : a9 00 __ LDA #$00
090e : 8d e4 19 STA $19e4 ; (b_v_ji + 0)
0911 : 8d e5 19 STA $19e5 ; (b_v_ji + 1)
0914 : 8d dc 19 STA $19dc ; (b_v_cai + 0)
0917 : 8d de 19 STA $19de ; (b_v_cai + 2)
091a : 8d df 19 STA $19df ; (b_v_cai + 3)
091d : 8d d8 19 STA $19d8 ; (b_v_sai + 0)
0920 : 8d da 19 STA $19da ; (b_v_sai + 2)
0923 : 8d db 19 STA $19db ; (b_v_sai + 3)
0926 : 85 1b __ STA ACCU + 0 
0928 : 85 1c __ STA ACCU + 1 
092a : a9 d8 __ LDA #$d8
092c : 8d dd 19 STA $19dd ; (b_v_cai + 1)
092f : a9 04 __ LDA #$04
0931 : 8d d9 19 STA $19d9 ; (b_v_sai + 1)
0934 : ad d0 19 LDA $19d0 ; (b_v_dxf + 0)
0937 : 85 47 __ STA T1 + 0 
0939 : ad d1 19 LDA $19d1 ; (b_v_dxf + 1)
093c : 85 48 __ STA T1 + 1 
093e : ad d2 19 LDA $19d2 ; (b_v_dxf + 2)
0941 : 85 49 __ STA T1 + 2 
0943 : ad d3 19 LDA $19d3 ; (b_v_dxf + 3)
0946 : 85 4a __ STA T1 + 3 
0948 : a9 9c __ LDA #$9c
094a : 85 1d __ STA ACCU + 2 
094c : a9 41 __ LDA #$41
094e : 85 1e __ STA ACCU + 3 
0950 : a2 47 __ LDX #$47
0952 : 20 11 16 JSR $1611 ; (freg + 4)
0955 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0958 : a2 6b __ LDX #$6b
095a : 20 11 16 JSR $1611 ; (freg + 4)
095d : a5 1e __ LDA ACCU + 3 
095f : 49 80 __ EOR #$80
0961 : 85 1e __ STA ACCU + 3 
0963 : 20 58 16 JSR $1658 ; (faddsub + 6)
0966 : a5 1b __ LDA ACCU + 0 
0968 : 85 4b __ STA T2 + 0 
096a : a5 1c __ LDA ACCU + 1 
096c : 85 4c __ STA T2 + 1 
096e : a5 1d __ LDA ACCU + 2 
0970 : 85 4d __ STA T2 + 2 
0972 : a5 1e __ LDA ACCU + 3 
0974 : 85 4e __ STA T2 + 3 
0976 : ad d4 19 LDA $19d4 ; (b_v_dyf + 0)
0979 : 85 53 __ STA T3 + 0 
097b : ad d5 19 LDA $19d5 ; (b_v_dyf + 1)
097e : 85 54 __ STA T3 + 1 
0980 : ad d6 19 LDA $19d6 ; (b_v_dyf + 2)
0983 : 85 55 __ STA T3 + 2 
0985 : ad d7 19 LDA $19d7 ; (b_v_dyf + 3)
0988 : 85 56 __ STA T3 + 3 
098a : a9 00 __ LDA #$00
098c : 85 1b __ STA ACCU + 0 
098e : 85 1c __ STA ACCU + 1 
0990 : a9 40 __ LDA #$40
0992 : 85 1d __ STA ACCU + 2 
0994 : a9 41 __ LDA #$41
0996 : 85 1e __ STA ACCU + 3 
0998 : a2 53 __ LDX #$53
099a : 20 11 16 JSR $1611 ; (freg + 4)
099d : 20 3f 17 JSR $173f ; (crt_fmul + 0)
09a0 : a2 43 __ LDX #$43
09a2 : 20 11 16 JSR $1611 ; (freg + 4)
09a5 : a5 1e __ LDA ACCU + 3 
09a7 : 49 80 __ EOR #$80
09a9 : 85 1e __ STA ACCU + 3 
09ab : 20 58 16 JSR $1658 ; (faddsub + 6)
09ae : a5 1b __ LDA ACCU + 0 
09b0 : 8d e0 19 STA $19e0 ; (b_v_cif + 0)
09b3 : a5 1c __ LDA ACCU + 1 
09b5 : 8d e1 19 STA $19e1 ; (b_v_cif + 1)
09b8 : a5 1d __ LDA ACCU + 2 
09ba : 8d e2 19 STA $19e2 ; (b_v_cif + 2)
09bd : a5 1e __ LDA ACCU + 3 
09bf : 8d e3 19 STA $19e3 ; (b_v_cif + 3)
.l7:
09c2 : a9 00 __ LDA #$00
09c4 : 8d ea 19 STA $19ea ; (b_v_ii + 0)
09c7 : 8d eb 19 STA $19eb ; (b_v_ii + 1)
09ca : a5 4b __ LDA T2 + 0 
09cc : 8d e6 19 STA $19e6 ; (b_v_crf + 0)
09cf : a5 4c __ LDA T2 + 1 
09d1 : 8d e7 19 STA $19e7 ; (b_v_crf + 1)
09d4 : a5 4d __ LDA T2 + 2 
09d6 : 8d e8 19 STA $19e8 ; (b_v_crf + 2)
09d9 : a5 4e __ LDA T2 + 3 
09db : 8d e9 19 STA $19e9 ; (b_v_crf + 3)
.l8:
09de : a9 00 __ LDA #$00
09e0 : 8d f4 19 STA $19f4 ; (b_v_kf + 0)
09e3 : 8d f5 19 STA $19f5 ; (b_v_kf + 1)
09e6 : 8d f6 19 STA $19f6 ; (b_v_kf + 2)
09e9 : 8d f7 19 STA $19f7 ; (b_v_kf + 3)
09ec : 8d f0 19 STA $19f0 ; (b_v_zif + 0)
09ef : 8d f1 19 STA $19f1 ; (b_v_zif + 1)
09f2 : 8d f2 19 STA $19f2 ; (b_v_zif + 2)
09f5 : 8d f3 19 STA $19f3 ; (b_v_zif + 3)
09f8 : 8d ec 19 STA $19ec ; (b_v_zrf + 0)
09fb : 8d ed 19 STA $19ed ; (b_v_zrf + 1)
09fe : 8d ee 19 STA $19ee ; (b_v_zrf + 2)
0a01 : 8d ef 19 STA $19ef ; (b_v_zrf + 3)
.l9:
0a04 : ad ec 19 LDA $19ec ; (b_v_zrf + 0)
0a07 : 85 57 __ STA T4 + 0 
0a09 : 85 1b __ STA ACCU + 0 
0a0b : ad ed 19 LDA $19ed ; (b_v_zrf + 1)
0a0e : 85 58 __ STA T4 + 1 
0a10 : 85 1c __ STA ACCU + 1 
0a12 : ad ee 19 LDA $19ee ; (b_v_zrf + 2)
0a15 : 85 59 __ STA T4 + 2 
0a17 : 85 1d __ STA ACCU + 2 
0a19 : ad ef 19 LDA $19ef ; (b_v_zrf + 3)
0a1c : 85 5a __ STA T4 + 3 
0a1e : 85 1e __ STA ACCU + 3 
0a20 : a2 57 __ LDX #$57
0a22 : 20 11 16 JSR $1611 ; (freg + 4)
0a25 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0a28 : a9 00 __ LDA #$00
0a2a : 85 03 __ STA WORK + 0 
0a2c : 85 04 __ STA WORK + 1 
0a2e : a9 80 __ LDA #$80
0a30 : 85 05 __ STA WORK + 2 
0a32 : a9 3b __ LDA #$3b
0a34 : 85 06 __ STA WORK + 3 
0a36 : 20 21 16 JSR $1621 ; (freg + 20)
0a39 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0a3c : a5 1b __ LDA ACCU + 0 
0a3e : 85 5b __ STA T5 + 0 
0a40 : a5 1c __ LDA ACCU + 1 
0a42 : 85 5c __ STA T5 + 1 
0a44 : a5 1d __ LDA ACCU + 2 
0a46 : 85 5d __ STA T5 + 2 
0a48 : a5 1e __ LDA ACCU + 3 
0a4a : 85 5e __ STA T5 + 3 
0a4c : ad f0 19 LDA $19f0 ; (b_v_zif + 0)
0a4f : 85 5f __ STA T6 + 0 
0a51 : 85 1b __ STA ACCU + 0 
0a53 : ad f1 19 LDA $19f1 ; (b_v_zif + 1)
0a56 : 85 60 __ STA T6 + 1 
0a58 : 85 1c __ STA ACCU + 1 
0a5a : ad f2 19 LDA $19f2 ; (b_v_zif + 2)
0a5d : 85 61 __ STA T6 + 2 
0a5f : 85 1d __ STA ACCU + 2 
0a61 : ad f3 19 LDA $19f3 ; (b_v_zif + 3)
0a64 : 85 62 __ STA T6 + 3 
0a66 : 85 1e __ STA ACCU + 3 
0a68 : a2 5f __ LDX #$5f
0a6a : 20 11 16 JSR $1611 ; (freg + 4)
0a6d : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0a70 : a9 00 __ LDA #$00
0a72 : 85 03 __ STA WORK + 0 
0a74 : 85 04 __ STA WORK + 1 
0a76 : a9 80 __ LDA #$80
0a78 : 85 05 __ STA WORK + 2 
0a7a : a9 3b __ LDA #$3b
0a7c : 85 06 __ STA WORK + 3 
0a7e : 20 21 16 JSR $1621 ; (freg + 20)
0a81 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0a84 : a5 1b __ LDA ACCU + 0 
0a86 : 85 63 __ STA T7 + 0 
0a88 : a5 1c __ LDA ACCU + 1 
0a8a : 85 64 __ STA T7 + 1 
0a8c : a5 1d __ LDA ACCU + 2 
0a8e : 85 65 __ STA T7 + 2 
0a90 : a5 1e __ LDA ACCU + 3 
0a92 : 85 66 __ STA T7 + 3 
0a94 : ad f4 19 LDA $19f4 ; (b_v_kf + 0)
0a97 : 85 67 __ STA T8 + 0 
0a99 : ad f5 19 LDA $19f5 ; (b_v_kf + 1)
0a9c : 85 68 __ STA T8 + 1 
0a9e : ad f6 19 LDA $19f6 ; (b_v_kf + 2)
0aa1 : 85 69 __ STA T8 + 2 
0aa3 : ad f7 19 LDA $19f7 ; (b_v_kf + 3)
0aa6 : 85 6a __ STA T8 + 3 
0aa8 : a5 5b __ LDA T5 + 0 
0aaa : 85 1b __ STA ACCU + 0 
0aac : a5 5c __ LDA T5 + 1 
0aae : 85 1c __ STA ACCU + 1 
0ab0 : a5 5d __ LDA T5 + 2 
0ab2 : 85 1d __ STA ACCU + 2 
0ab4 : a5 5e __ LDA T5 + 3 
0ab6 : 85 1e __ STA ACCU + 3 
0ab8 : a2 63 __ LDX #$63
0aba : 20 11 16 JSR $1611 ; (freg + 4)
0abd : 20 58 16 JSR $1658 ; (faddsub + 6)
0ac0 : a5 1e __ LDA ACCU + 3 
0ac2 : 30 17 __ BMI $0adb ; (main.s10 + 0)
.s12:
0ac4 : c9 44 __ CMP #$44
0ac6 : d0 0e __ BNE $0ad6 ; (main.s16 + 0)
.s13:
0ac8 : a5 1d __ LDA ACCU + 2 
0aca : c9 80 __ CMP #$80
0acc : d0 08 __ BNE $0ad6 ; (main.s16 + 0)
.s14:
0ace : a5 1c __ LDA ACCU + 1 
0ad0 : d0 04 __ BNE $0ad6 ; (main.s16 + 0)
.s15:
0ad2 : a5 1b __ LDA ACCU + 0 
0ad4 : f0 05 __ BEQ $0adb ; (main.s10 + 0)
.s16:
0ad6 : a9 00 __ LDA #$00
0ad8 : 2a __ __ ROL
0ad9 : 90 02 __ BCC $0add ; (main.s11 + 0)
.s10:
0adb : a9 00 __ LDA #$00
.s11:
0add : 49 ff __ EOR #$ff
0adf : c9 ff __ CMP #$ff
0ae1 : f0 03 __ BEQ $0ae6 ; (main.s17 + 0)
0ae3 : 4c 03 0e JMP $0e03 ; (main.s62 + 0)
.s17:
0ae6 : a5 57 __ LDA T4 + 0 
0ae8 : 85 1b __ STA ACCU + 0 
0aea : a5 58 __ LDA T4 + 1 
0aec : 85 1c __ STA ACCU + 1 
0aee : a5 59 __ LDA T4 + 2 
0af0 : 85 1d __ STA ACCU + 2 
0af2 : a5 5a __ LDA T4 + 3 
0af4 : 85 1e __ STA ACCU + 3 
0af6 : a2 5f __ LDX #$5f
0af8 : 20 11 16 JSR $1611 ; (freg + 4)
0afb : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0afe : a2 1b __ LDX #$1b
0b00 : 20 11 16 JSR $1611 ; (freg + 4)
0b03 : 20 58 16 JSR $1658 ; (faddsub + 6)
0b06 : a9 00 __ LDA #$00
0b08 : 85 03 __ STA WORK + 0 
0b0a : 85 04 __ STA WORK + 1 
0b0c : a9 80 __ LDA #$80
0b0e : 85 05 __ STA WORK + 2 
0b10 : a9 3b __ LDA #$3b
0b12 : 85 06 __ STA WORK + 3 
0b14 : 20 21 16 JSR $1621 ; (freg + 20)
0b17 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0b1a : ad e0 19 LDA $19e0 ; (b_v_cif + 0)
0b1d : 85 03 __ STA WORK + 0 
0b1f : ad e1 19 LDA $19e1 ; (b_v_cif + 1)
0b22 : 85 04 __ STA WORK + 1 
0b24 : ad e2 19 LDA $19e2 ; (b_v_cif + 2)
0b27 : 85 05 __ STA WORK + 2 
0b29 : ad e3 19 LDA $19e3 ; (b_v_cif + 3)
0b2c : 85 06 __ STA WORK + 3 
0b2e : 20 21 16 JSR $1621 ; (freg + 20)
0b31 : 20 58 16 JSR $1658 ; (faddsub + 6)
0b34 : a5 1b __ LDA ACCU + 0 
0b36 : 8d f0 19 STA $19f0 ; (b_v_zif + 0)
0b39 : a5 1c __ LDA ACCU + 1 
0b3b : 8d f1 19 STA $19f1 ; (b_v_zif + 1)
0b3e : a5 1d __ LDA ACCU + 2 
0b40 : 8d f2 19 STA $19f2 ; (b_v_zif + 2)
0b43 : a5 1e __ LDA ACCU + 3 
0b45 : 8d f3 19 STA $19f3 ; (b_v_zif + 3)
0b48 : a5 5b __ LDA T5 + 0 
0b4a : 85 1b __ STA ACCU + 0 
0b4c : a5 5c __ LDA T5 + 1 
0b4e : 85 1c __ STA ACCU + 1 
0b50 : a5 5d __ LDA T5 + 2 
0b52 : 85 1d __ STA ACCU + 2 
0b54 : a5 5e __ LDA T5 + 3 
0b56 : 85 1e __ STA ACCU + 3 
0b58 : a2 63 __ LDX #$63
0b5a : 20 11 16 JSR $1611 ; (freg + 4)
0b5d : 20 52 16 JSR $1652 ; (faddsub + 0)
0b60 : ad e6 19 LDA $19e6 ; (b_v_crf + 0)
0b63 : 85 03 __ STA WORK + 0 
0b65 : ad e7 19 LDA $19e7 ; (b_v_crf + 1)
0b68 : 85 04 __ STA WORK + 1 
0b6a : ad e8 19 LDA $19e8 ; (b_v_crf + 2)
0b6d : 85 05 __ STA WORK + 2 
0b6f : ad e9 19 LDA $19e9 ; (b_v_crf + 3)
0b72 : 85 06 __ STA WORK + 3 
0b74 : 20 21 16 JSR $1621 ; (freg + 20)
0b77 : 20 58 16 JSR $1658 ; (faddsub + 6)
0b7a : a5 1b __ LDA ACCU + 0 
0b7c : 8d ec 19 STA $19ec ; (b_v_zrf + 0)
0b7f : a5 1c __ LDA ACCU + 1 
0b81 : 8d ed 19 STA $19ed ; (b_v_zrf + 1)
0b84 : a5 1d __ LDA ACCU + 2 
0b86 : 8d ee 19 STA $19ee ; (b_v_zrf + 2)
0b89 : a5 1e __ LDA ACCU + 3 
0b8b : 8d ef 19 STA $19ef ; (b_v_zrf + 3)
0b8e : a9 00 __ LDA #$00
0b90 : 85 1b __ STA ACCU + 0 
0b92 : 85 1c __ STA ACCU + 1 
0b94 : a9 80 __ LDA #$80
0b96 : 85 1d __ STA ACCU + 2 
0b98 : a9 3f __ LDA #$3f
0b9a : 85 1e __ STA ACCU + 3 
0b9c : a2 67 __ LDX #$67
0b9e : 20 11 16 JSR $1611 ; (freg + 4)
0ba1 : 20 58 16 JSR $1658 ; (faddsub + 6)
0ba4 : a5 1b __ LDA ACCU + 0 
0ba6 : 8d f4 19 STA $19f4 ; (b_v_kf + 0)
0ba9 : a5 1c __ LDA ACCU + 1 
0bab : 8d f5 19 STA $19f5 ; (b_v_kf + 1)
0bae : a6 1d __ LDX ACCU + 2 
0bb0 : 8e f6 19 STX $19f6 ; (b_v_kf + 2)
0bb3 : a5 1e __ LDA ACCU + 3 
0bb5 : 8d f7 19 STA $19f7 ; (b_v_kf + 3)
0bb8 : 10 04 __ BPL $0bbe ; (main.s21 + 0)
.s18:
0bba : a9 01 __ LDA #$01
0bbc : d0 1a __ BNE $0bd8 ; (main.s20 + 0)
.s21:
0bbe : c9 43 __ CMP #$43
0bc0 : d0 0d __ BNE $0bcf ; (main.s25 + 0)
.s22:
0bc2 : e0 80 __ CPX #$80
0bc4 : d0 09 __ BNE $0bcf ; (main.s25 + 0)
.s23:
0bc6 : a5 1c __ LDA ACCU + 1 
0bc8 : 38 __ __ SEC
0bc9 : d0 04 __ BNE $0bcf ; (main.s25 + 0)
.s24:
0bcb : a5 1b __ LDA ACCU + 0 
0bcd : f0 07 __ BEQ $0bd6 ; (main.s19 + 0)
.s25:
0bcf : a9 00 __ LDA #$00
0bd1 : 2a __ __ ROL
0bd2 : 49 01 __ EOR #$01
0bd4 : 90 02 __ BCC $0bd8 ; (main.s20 + 0)
.s19:
0bd6 : a9 00 __ LDA #$00
.s20:
0bd8 : 49 ff __ EOR #$ff
0bda : c9 ff __ CMP #$ff
0bdc : f0 03 __ BEQ $0be1 ; (main.s26 + 0)
0bde : 4c 04 0a JMP $0a04 ; (main.l9 + 0)
.s26:
0be1 : ad d8 19 LDA $19d8 ; (b_v_sai + 0)
0be4 : 85 57 __ STA T4 + 0 
0be6 : ad d9 19 LDA $19d9 ; (b_v_sai + 1)
0be9 : c9 e0 __ CMP #$e0
0beb : 90 2d __ BCC $0c1a ; (main.s27 + 0)
.s57:
0bed : 85 58 __ STA T4 + 1 
0bef : c9 ff __ CMP #$ff
0bf1 : d0 04 __ BNE $0bf7 ; (main.s61 + 0)
.s60:
0bf3 : a5 57 __ LDA T4 + 0 
0bf5 : c9 40 __ CMP #$40
.s61:
0bf7 : b0 21 __ BCS $0c1a ; (main.s27 + 0)
.s58:
0bf9 : a0 01 __ LDY #$01
0bfb : b1 51 __ LDA (T11 + 0),y 
0bfd : aa __ __ TAX
0bfe : 4a __ __ LSR
0bff : 90 19 __ BCC $0c1a ; (main.s27 + 0)
.s59:
0c01 : 8a __ __ TXA
0c02 : 29 fe __ AND #$fe
0c04 : 91 51 __ STA (T11 + 0),y 
0c06 : 18 __ __ CLC
0c07 : a5 52 __ LDA T11 + 1 
0c09 : 65 58 __ ADC T4 + 1 
0c0b : 85 58 __ STA T4 + 1 
0c0d : a9 a0 __ LDA #$a0
0c0f : a4 51 __ LDY T11 + 0 
0c11 : 91 57 __ STA (T4 + 0),y 
0c13 : 8a __ __ TXA
0c14 : a0 01 __ LDY #$01
0c16 : 91 51 __ STA (T11 + 0),y 
0c18 : d0 0e __ BNE $0c28 ; (main.s28 + 0)
.s27:
0c1a : 18 __ __ CLC
0c1b : a5 52 __ LDA T11 + 1 
0c1d : 6d d9 19 ADC $19d9 ; (b_v_sai + 1)
0c20 : 85 58 __ STA T4 + 1 
0c22 : a9 a0 __ LDA #$a0
0c24 : a4 51 __ LDY T11 + 0 
0c26 : 91 57 __ STA (T4 + 0),y 
.s28:
0c28 : ad dc 19 LDA $19dc ; (b_v_cai + 0)
0c2b : 85 57 __ STA T4 + 0 
0c2d : ad dd 19 LDA $19dd ; (b_v_cai + 1)
0c30 : c9 e0 __ CMP #$e0
0c32 : 90 18 __ BCC $0c4c ; (main.s29 + 0)
.s51:
0c34 : 85 58 __ STA T4 + 1 
0c36 : c9 ff __ CMP #$ff
0c38 : d0 04 __ BNE $0c3e ; (main.s56 + 0)
.s55:
0c3a : a5 57 __ LDA T4 + 0 
0c3c : c9 40 __ CMP #$40
.s56:
0c3e : b0 0c __ BCS $0c4c ; (main.s29 + 0)
.s52:
0c40 : a0 01 __ LDY #$01
0c42 : b1 51 __ LDA (T11 + 0),y 
0c44 : 85 67 __ STA T8 + 0 
0c46 : 4a __ __ LSR
0c47 : 90 03 __ BCC $0c4c ; (main.s29 + 0)
0c49 : 4c e7 0d JMP $0de7 ; (main.s53 + 0)
.s29:
0c4c : 18 __ __ CLC
0c4d : a5 52 __ LDA T11 + 1 
0c4f : 6d dd 19 ADC $19dd ; (b_v_cai + 1)
0c52 : 85 58 __ STA T4 + 1 
0c54 : a9 00 __ LDA #$00
.s78:
0c56 : a4 51 __ LDY T11 + 0 
0c58 : 91 57 __ STA (T4 + 0),y 
.s30:
0c5a : ad e6 19 LDA $19e6 ; (b_v_crf + 0)
0c5d : 85 1b __ STA ACCU + 0 
0c5f : ad e7 19 LDA $19e7 ; (b_v_crf + 1)
0c62 : 85 1c __ STA ACCU + 1 
0c64 : ad e8 19 LDA $19e8 ; (b_v_crf + 2)
0c67 : 85 1d __ STA ACCU + 2 
0c69 : ad e9 19 LDA $19e9 ; (b_v_crf + 3)
0c6c : 85 1e __ STA ACCU + 3 
0c6e : a2 47 __ LDX #$47
0c70 : 20 11 16 JSR $1611 ; (freg + 4)
0c73 : 20 58 16 JSR $1658 ; (faddsub + 6)
0c76 : a5 1b __ LDA ACCU + 0 
0c78 : 8d e6 19 STA $19e6 ; (b_v_crf + 0)
0c7b : a5 1c __ LDA ACCU + 1 
0c7d : 8d e7 19 STA $19e7 ; (b_v_crf + 1)
0c80 : a5 1d __ LDA ACCU + 2 
0c82 : 8d e8 19 STA $19e8 ; (b_v_crf + 2)
0c85 : a5 1e __ LDA ACCU + 3 
0c87 : 8d e9 19 STA $19e9 ; (b_v_crf + 3)
0c8a : ee d8 19 INC $19d8 ; (b_v_sai + 0)
0c8d : d0 0d __ BNE $0c9c ; (main.s80 + 0)
.s84:
0c8f : ee d9 19 INC $19d9 ; (b_v_sai + 1)
0c92 : d0 08 __ BNE $0c9c ; (main.s80 + 0)
.s81:
0c94 : ee da 19 INC $19da ; (b_v_sai + 2)
0c97 : d0 03 __ BNE $0c9c ; (main.s80 + 0)
.s79:
0c99 : ee db 19 INC $19db ; (b_v_sai + 3)
.s80:
0c9c : ee dc 19 INC $19dc ; (b_v_cai + 0)
0c9f : d0 0d __ BNE $0cae ; (main.s83 + 0)
.s86:
0ca1 : ee dd 19 INC $19dd ; (b_v_cai + 1)
0ca4 : d0 08 __ BNE $0cae ; (main.s83 + 0)
.s85:
0ca6 : ee de 19 INC $19de ; (b_v_cai + 2)
0ca9 : d0 03 __ BNE $0cae ; (main.s83 + 0)
.s82:
0cab : ee df 19 INC $19df ; (b_v_cai + 3)
.s83:
0cae : ad ea 19 LDA $19ea ; (b_v_ii + 0)
0cb1 : 85 57 __ STA T4 + 0 
0cb3 : 18 __ __ CLC
0cb4 : 69 01 __ ADC #$01
0cb6 : 8d ea 19 STA $19ea ; (b_v_ii + 0)
0cb9 : ad eb 19 LDA $19eb ; (b_v_ii + 1)
0cbc : aa __ __ TAX
0cbd : 69 00 __ ADC #$00
0cbf : 8d eb 19 STA $19eb ; (b_v_ii + 1)
0cc2 : 8a __ __ TXA
0cc3 : 10 03 __ BPL $0cc8 ; (main.s50 + 0)
0cc5 : 4c de 09 JMP $09de ; (main.l8 + 0)
.s50:
0cc8 : d0 06 __ BNE $0cd0 ; (main.s31 + 0)
.s49:
0cca : a9 26 __ LDA #$26
0ccc : c5 57 __ CMP T4 + 0 
0cce : b0 f5 __ BCS $0cc5 ; (main.s83 + 23)
.s31:
0cd0 : ad e0 19 LDA $19e0 ; (b_v_cif + 0)
0cd3 : 85 1b __ STA ACCU + 0 
0cd5 : ad e1 19 LDA $19e1 ; (b_v_cif + 1)
0cd8 : 85 1c __ STA ACCU + 1 
0cda : ad e2 19 LDA $19e2 ; (b_v_cif + 2)
0cdd : 85 1d __ STA ACCU + 2 
0cdf : ad e3 19 LDA $19e3 ; (b_v_cif + 3)
0ce2 : 85 1e __ STA ACCU + 3 
0ce4 : a2 53 __ LDX #$53
0ce6 : 20 11 16 JSR $1611 ; (freg + 4)
0ce9 : 20 58 16 JSR $1658 ; (faddsub + 6)
0cec : a5 1b __ LDA ACCU + 0 
0cee : 8d e0 19 STA $19e0 ; (b_v_cif + 0)
0cf1 : a5 1c __ LDA ACCU + 1 
0cf3 : 8d e1 19 STA $19e1 ; (b_v_cif + 1)
0cf6 : a5 1d __ LDA ACCU + 2 
0cf8 : 8d e2 19 STA $19e2 ; (b_v_cif + 2)
0cfb : a5 1e __ LDA ACCU + 3 
0cfd : 8d e3 19 STA $19e3 ; (b_v_cif + 3)
0d00 : ad e4 19 LDA $19e4 ; (b_v_ji + 0)
0d03 : 85 57 __ STA T4 + 0 
0d05 : 18 __ __ CLC
0d06 : 69 01 __ ADC #$01
0d08 : 8d e4 19 STA $19e4 ; (b_v_ji + 0)
0d0b : ad e5 19 LDA $19e5 ; (b_v_ji + 1)
0d0e : aa __ __ TAX
0d0f : 69 00 __ ADC #$00
0d11 : 8d e5 19 STA $19e5 ; (b_v_ji + 1)
0d14 : 8a __ __ TXA
0d15 : 10 03 __ BPL $0d1a ; (main.s48 + 0)
0d17 : 4c c2 09 JMP $09c2 ; (main.l7 + 0)
.s48:
0d1a : d0 06 __ BNE $0d22 ; (main.s32 + 0)
.s47:
0d1c : a9 17 __ LDA #$17
0d1e : c5 57 __ CMP T4 + 0 
0d20 : b0 f5 __ BCS $0d17 ; (main.s31 + 71)
.s32:
0d22 : a9 33 __ LDA #$33
0d24 : 85 1b __ STA ACCU + 0 
0d26 : 85 1c __ STA ACCU + 1 
0d28 : a9 73 __ LDA #$73
0d2a : 85 1d __ STA ACCU + 2 
0d2c : a9 3f __ LDA #$3f
0d2e : 85 1e __ STA ACCU + 3 
0d30 : a2 47 __ LDX #$47
0d32 : 20 11 16 JSR $1611 ; (freg + 4)
0d35 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0d38 : a5 1b __ LDA ACCU + 0 
0d3a : 8d d0 19 STA $19d0 ; (b_v_dxf + 0)
0d3d : a5 1c __ LDA ACCU + 1 
0d3f : 8d d1 19 STA $19d1 ; (b_v_dxf + 1)
0d42 : a5 1d __ LDA ACCU + 2 
0d44 : 8d d2 19 STA $19d2 ; (b_v_dxf + 2)
0d47 : a5 1e __ LDA ACCU + 3 
0d49 : 8d d3 19 STA $19d3 ; (b_v_dxf + 3)
0d4c : a9 33 __ LDA #$33
0d4e : 85 1b __ STA ACCU + 0 
0d50 : 85 1c __ STA ACCU + 1 
0d52 : a9 73 __ LDA #$73
0d54 : 85 1d __ STA ACCU + 2 
0d56 : a9 3f __ LDA #$3f
0d58 : 85 1e __ STA ACCU + 3 
0d5a : a2 53 __ LDX #$53
0d5c : 20 11 16 JSR $1611 ; (freg + 4)
0d5f : 20 3f 17 JSR $173f ; (crt_fmul + 0)
0d62 : a5 1b __ LDA ACCU + 0 
0d64 : 8d d4 19 STA $19d4 ; (b_v_dyf + 0)
0d67 : a5 1c __ LDA ACCU + 1 
0d69 : 8d d5 19 STA $19d5 ; (b_v_dyf + 1)
0d6c : a5 1d __ LDA ACCU + 2 
0d6e : 8d d6 19 STA $19d6 ; (b_v_dyf + 2)
0d71 : a5 1e __ LDA ACCU + 3 
0d73 : 8d d7 19 STA $19d7 ; (b_v_dyf + 3)
0d76 : ad d3 19 LDA $19d3 ; (b_v_dxf + 3)
0d79 : 30 1e __ BMI $0d99 ; (main.s33 + 0)
.s35:
0d7b : c9 3b __ CMP #$3b
0d7d : d0 15 __ BNE $0d94 ; (main.s39 + 0)
.s36:
0d7f : ad d2 19 LDA $19d2 ; (b_v_dxf + 2)
0d82 : c9 e5 __ CMP #$e5
0d84 : d0 0e __ BNE $0d94 ; (main.s39 + 0)
.s37:
0d86 : ad d1 19 LDA $19d1 ; (b_v_dxf + 1)
0d89 : c9 60 __ CMP #$60
0d8b : d0 07 __ BNE $0d94 ; (main.s39 + 0)
.s38:
0d8d : ad d0 19 LDA $19d0 ; (b_v_dxf + 0)
0d90 : c9 42 __ CMP #$42
0d92 : f0 05 __ BEQ $0d99 ; (main.s33 + 0)
.s39:
0d94 : a9 00 __ LDA #$00
0d96 : 2a __ __ ROL
0d97 : 90 02 __ BCC $0d9b ; (main.s34 + 0)
.s33:
0d99 : a9 00 __ LDA #$00
.s34:
0d9b : 49 ff __ EOR #$ff
0d9d : c9 ff __ CMP #$ff
0d9f : f0 03 __ BEQ $0da4 ; (main.s40 + 0)
0da1 : 4c 0c 09 JMP $090c ; (main.l6 + 0)
.s40:
0da4 : ad ce 19 LDA $19ce ; (b_v_pi + 0)
0da7 : 85 43 __ STA T0 + 0 
0da9 : 69 00 __ ADC #$00
0dab : 8d ce 19 STA $19ce ; (b_v_pi + 0)
0dae : ad cf 19 LDA $19cf ; (b_v_pi + 1)
0db1 : aa __ __ TAX
0db2 : 69 00 __ ADC #$00
0db4 : 8d cf 19 STA $19cf ; (b_v_pi + 1)
0db7 : 8a __ __ TXA
0db8 : 10 04 __ BPL $0dbe ; (main.s45 + 0)
.s42:
0dba : a9 00 __ LDA #$00
0dbc : f0 0f __ BEQ $0dcd ; (main.s43 + 0)
.s45:
0dbe : d0 0b __ BNE $0dcb ; (main.s41 + 0)
.s44:
0dc0 : a9 03 __ LDA #$03
0dc2 : c5 43 __ CMP T0 + 0 
0dc4 : a9 00 __ LDA #$00
0dc6 : 2a __ __ ROL
0dc7 : 49 01 __ EOR #$01
0dc9 : 90 02 __ BCC $0dcd ; (main.s43 + 0)
.s41:
0dcb : a9 01 __ LDA #$01
.s43:
0dcd : 49 ff __ EOR #$ff
0dcf : c9 ff __ CMP #$ff
0dd1 : d0 03 __ BNE $0dd6 ; (main.s46 + 0)
0dd3 : 4c c6 08 JMP $08c6 ; (main.l5 + 0)
.s46:
0dd6 : a9 00 __ LDA #$00
0dd8 : 8d c2 19 STA $19c2 ; (b_dataPtr + 0)
0ddb : 8d c3 19 STA $19c3 ; (b_dataPtr + 1)
0dde : 8d ce 19 STA $19ce ; (b_v_pi + 0)
0de1 : 8d cf 19 STA $19cf ; (b_v_pi + 1)
0de4 : 4c c6 08 JMP $08c6 ; (main.l5 + 0)
.s53:
0de7 : a5 67 __ LDA T8 + 0 
0de9 : 29 fe __ AND #$fe
0deb : 91 51 __ STA (T11 + 0),y 
0ded : 18 __ __ CLC
0dee : a5 52 __ LDA T11 + 1 
0df0 : 65 58 __ ADC T4 + 1 
0df2 : 85 58 __ STA T4 + 1 
0df4 : a9 00 __ LDA #$00
.s54:
0df6 : a4 51 __ LDY T11 + 0 
0df8 : 91 57 __ STA (T4 + 0),y 
0dfa : a5 67 __ LDA T8 + 0 
0dfc : a0 01 __ LDY #$01
0dfe : 91 51 __ STA (T11 + 0),y 
0e00 : 4c 5a 0c JMP $0c5a ; (main.s30 + 0)
.s62:
0e03 : a5 67 __ LDA T8 + 0 
0e05 : 85 1b __ STA ACCU + 0 
0e07 : a5 68 __ LDA T8 + 1 
0e09 : 85 1c __ STA ACCU + 1 
0e0b : a5 69 __ LDA T8 + 2 
0e0d : 85 1d __ STA ACCU + 2 
0e0f : a5 6a __ LDA T8 + 3 
0e11 : 85 1e __ STA ACCU + 3 
0e13 : 20 b5 18 JSR $18b5 ; (f32_to_i32 + 0)
0e16 : a5 1b __ LDA ACCU + 0 
0e18 : 29 0f __ AND #$0f
0e1a : 8d f8 19 STA $19f8 ; (b_v_ci + 0)
0e1d : a9 00 __ LDA #$00
0e1f : 8d f9 19 STA $19f9 ; (b_v_ci + 1)
0e22 : cd f8 19 CMP $19f8 ; (b_v_ci + 0)
0e25 : 2a __ __ ROL
0e26 : 49 ff __ EOR #$ff
0e28 : c9 ff __ CMP #$ff
0e2a : f0 0a __ BEQ $0e36 ; (main.s63 + 0)
.s77:
0e2c : a9 06 __ LDA #$06
0e2e : 8d f8 19 STA $19f8 ; (b_v_ci + 0)
0e31 : a9 00 __ LDA #$00
0e33 : 8d f9 19 STA $19f9 ; (b_v_ci + 1)
.s63:
0e36 : ad d8 19 LDA $19d8 ; (b_v_sai + 0)
0e39 : 85 57 __ STA T4 + 0 
0e3b : ad d9 19 LDA $19d9 ; (b_v_sai + 1)
0e3e : c9 e0 __ CMP #$e0
0e40 : 90 2d __ BCC $0e6f ; (main.s64 + 0)
.s72:
0e42 : 85 58 __ STA T4 + 1 
0e44 : c9 ff __ CMP #$ff
0e46 : d0 04 __ BNE $0e4c ; (main.s76 + 0)
.s75:
0e48 : a5 57 __ LDA T4 + 0 
0e4a : c9 40 __ CMP #$40
.s76:
0e4c : b0 21 __ BCS $0e6f ; (main.s64 + 0)
.s73:
0e4e : a0 01 __ LDY #$01
0e50 : b1 51 __ LDA (T11 + 0),y 
0e52 : aa __ __ TAX
0e53 : 4a __ __ LSR
0e54 : 90 19 __ BCC $0e6f ; (main.s64 + 0)
.s74:
0e56 : 8a __ __ TXA
0e57 : 29 fe __ AND #$fe
0e59 : 91 51 __ STA (T11 + 0),y 
0e5b : 18 __ __ CLC
0e5c : a5 52 __ LDA T11 + 1 
0e5e : 65 58 __ ADC T4 + 1 
0e60 : 85 58 __ STA T4 + 1 
0e62 : a9 a0 __ LDA #$a0
0e64 : a4 51 __ LDY T11 + 0 
0e66 : 91 57 __ STA (T4 + 0),y 
0e68 : 8a __ __ TXA
0e69 : a0 01 __ LDY #$01
0e6b : 91 51 __ STA (T11 + 0),y 
0e6d : d0 0e __ BNE $0e7d ; (main.s65 + 0)
.s64:
0e6f : 18 __ __ CLC
0e70 : a5 52 __ LDA T11 + 1 
0e72 : 6d d9 19 ADC $19d9 ; (b_v_sai + 1)
0e75 : 85 58 __ STA T4 + 1 
0e77 : a9 a0 __ LDA #$a0
0e79 : a4 51 __ LDY T11 + 0 
0e7b : 91 57 __ STA (T4 + 0),y 
.s65:
0e7d : ad dc 19 LDA $19dc ; (b_v_cai + 0)
0e80 : 85 57 __ STA T4 + 0 
0e82 : ad dd 19 LDA $19dd ; (b_v_cai + 1)
0e85 : c9 e0 __ CMP #$e0
0e87 : ae f8 19 LDX $19f8 ; (b_v_ci + 0)
0e8a : 90 26 __ BCC $0eb2 ; (main.s66 + 0)
.s67:
0e8c : 85 58 __ STA T4 + 1 
0e8e : c9 ff __ CMP #$ff
0e90 : d0 04 __ BNE $0e96 ; (main.s71 + 0)
.s70:
0e92 : a5 57 __ LDA T4 + 0 
0e94 : c9 40 __ CMP #$40
.s71:
0e96 : b0 1a __ BCS $0eb2 ; (main.s66 + 0)
.s68:
0e98 : a0 01 __ LDY #$01
0e9a : b1 51 __ LDA (T11 + 0),y 
0e9c : 85 67 __ STA T8 + 0 
0e9e : 4a __ __ LSR
0e9f : 90 11 __ BCC $0eb2 ; (main.s66 + 0)
.s69:
0ea1 : a5 67 __ LDA T8 + 0 
0ea3 : 29 fe __ AND #$fe
0ea5 : 91 51 __ STA (T11 + 0),y 
0ea7 : 18 __ __ CLC
0ea8 : a5 52 __ LDA T11 + 1 
0eaa : 65 58 __ ADC T4 + 1 
0eac : 85 58 __ STA T4 + 1 
0eae : 8a __ __ TXA
0eaf : 4c f6 0d JMP $0df6 ; (main.s54 + 0)
.s66:
0eb2 : 18 __ __ CLC
0eb3 : a5 52 __ LDA T11 + 1 
0eb5 : 6d dd 19 ADC $19dd ; (b_v_cai + 1)
0eb8 : 85 58 __ STA T4 + 1 
0eba : 8a __ __ TXA
0ebb : 4c 56 0c JMP $0c56 ; (main.s78 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
0ebe : ad ba 19 LDA $19ba ; (b_mem + 0)
0ec1 : 85 43 __ STA T1 + 0 
0ec3 : 85 45 __ STA T2 + 0 
0ec5 : 85 1f __ STA ADDR + 0 
0ec7 : ad bb 19 LDA $19bb ; (b_mem + 1)
0eca : 85 44 __ STA T1 + 1 
0ecc : 18 __ __ CLC
0ecd : 69 dd __ ADC #$dd
0ecf : 85 20 __ STA ADDR + 1 
0ed1 : a9 03 __ LDA #$03
0ed3 : a0 00 __ LDY #$00
0ed5 : 91 1f __ STA (ADDR + 0),y 
0ed7 : 18 __ __ CLC
0ed8 : a5 44 __ LDA T1 + 1 
0eda : 69 d0 __ ADC #$d0
0edc : 85 20 __ STA ADDR + 1 
0ede : a9 15 __ LDA #$15
0ee0 : a0 18 __ LDY #$18
0ee2 : 91 1f __ STA (ADDR + 0),y 
0ee4 : 18 __ __ CLC
0ee5 : a5 44 __ LDA T1 + 1 
0ee7 : 69 02 __ ADC #$02
0ee9 : 85 20 __ STA ADDR + 1 
0eeb : a9 0e __ LDA #$0e
0eed : a0 86 __ LDY #$86
0eef : 91 1f __ STA (ADDR + 0),y 
0ef1 : 18 __ __ CLC
0ef2 : a5 44 __ LDA T1 + 1 
0ef4 : 69 d8 __ ADC #$d8
0ef6 : 85 46 __ STA T2 + 1 
0ef8 : a9 00 __ LDA #$00
0efa : 85 47 __ STA T3 + 0 
0efc : 85 48 __ STA T3 + 1 
.l5:
0efe : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
0f01 : 18 __ __ CLC
0f02 : a5 43 __ LDA T1 + 0 
0f04 : 65 1b __ ADC ACCU + 0 
0f06 : 85 1b __ STA ACCU + 0 
0f08 : a5 44 __ LDA T1 + 1 
0f0a : 65 1c __ ADC ACCU + 1 
0f0c : 18 __ __ CLC
0f0d : 65 48 __ ADC T3 + 1 
0f0f : 85 1c __ STA ACCU + 1 
0f11 : a9 20 __ LDA #$20
0f13 : a4 47 __ LDY T3 + 0 
0f15 : 91 1b __ STA (ACCU + 0),y 
0f17 : a9 0e __ LDA #$0e
0f19 : a0 00 __ LDY #$00
0f1b : 91 45 __ STA (T2 + 0),y 
0f1d : e6 45 __ INC T2 + 0 
0f1f : d0 02 __ BNE $0f23 ; (b_init.s9 + 0)
.s8:
0f21 : e6 46 __ INC T2 + 1 
.s9:
0f23 : e6 47 __ INC T3 + 0 
0f25 : d0 02 __ BNE $0f29 ; (b_init.s11 + 0)
.s10:
0f27 : e6 48 __ INC T3 + 1 
.s11:
0f29 : a5 48 __ LDA T3 + 1 
0f2b : c9 03 __ CMP #$03
0f2d : d0 cf __ BNE $0efe ; (b_init.l5 + 0)
.s7:
0f2f : a5 47 __ LDA T3 + 0 
0f31 : c9 e8 __ CMP #$e8
0f33 : d0 c9 __ BNE $0efe ; (b_init.l5 + 0)
.s6:
0f35 : a5 43 __ LDA T1 + 0 
0f37 : 85 1f __ STA ADDR + 0 
0f39 : a5 44 __ LDA T1 + 1 
0f3b : 69 cf __ ADC #$cf
0f3d : 85 20 __ STA ADDR + 1 
0f3f : a9 0e __ LDA #$0e
0f41 : a0 20 __ LDY #$20
0f43 : 91 1f __ STA (ADDR + 0),y 
0f45 : a9 06 __ LDA #$06
0f47 : c8 __ __ INY
0f48 : 91 1f __ STA (ADDR + 0),y 
0f4a : a9 00 __ LDA #$00
0f4c : a0 c6 __ LDY #$c6
0f4e : 91 43 __ STA (T1 + 0),y 
0f50 : 8d be 19 STA $19be ; (b_row + 0)
0f53 : 8d bf 19 STA $19bf ; (b_row + 1)
0f56 : 8d bc 19 STA $19bc ; (b_col + 0)
0f59 : 8d bd 19 STA $19bd ; (b_col + 1)
.s3:
0f5c : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
0f5d : ad ba 19 LDA $19ba ; (b_mem + 0)
0f60 : 85 1f __ STA ADDR + 0 
0f62 : ad bb 19 LDA $19bb ; (b_mem + 1)
0f65 : 18 __ __ CLC
0f66 : 69 dd __ ADC #$dd
0f68 : 85 20 __ STA ADDR + 1 
0f6a : a0 00 __ LDY #$00
0f6c : 84 1b __ STY ACCU + 0 
0f6e : b1 1f __ LDA (ADDR + 0),y 
0f70 : 29 03 __ AND #$03
0f72 : 49 03 __ EOR #$03
0f74 : aa __ __ TAX
0f75 : 18 __ __ CLC
0f76 : a5 1f __ LDA ADDR + 0 
0f78 : 69 18 __ ADC #$18
0f7a : 85 1f __ STA ADDR + 0 
0f7c : ad bb 19 LDA $19bb ; (b_mem + 1)
0f7f : 69 d0 __ ADC #$d0
0f81 : 85 20 __ STA ADDR + 1 
0f83 : b1 1f __ LDA (ADDR + 0),y 
0f85 : 29 f0 __ AND #$f0
0f87 : 4a __ __ LSR
0f88 : 4a __ __ LSR
0f89 : 1d ab 19 ORA $19ab,x ; (__multab16384H + 0)
0f8c : 85 1c __ STA ACCU + 1 
.s3:
0f8e : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1273, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
0f8f : ad c0 19 LDA $19c0 ; (tsb_inited + 0)
0f92 : 0d c1 19 ORA $19c1 ; (tsb_inited + 1)
0f95 : d0 18 __ BNE $0faf ; (tsb_init.s3 + 0)
.s5:
0f97 : 85 0d __ STA P0 
0f99 : 85 0e __ STA P1 
0f9b : 85 10 __ STA P3 
0f9d : a9 01 __ LDA #$01
0f9f : 85 0f __ STA P2 
0fa1 : 8d c0 19 STA $19c0 ; (tsb_inited + 0)
0fa4 : a9 00 __ LDA #$00
0fa6 : 8d c1 19 STA $19c1 ; (tsb_inited + 1)
0fa9 : 20 b0 0f JSR $0fb0 ; (tsb_init_tables.s4 + 0)
0fac : 4c be 0f JMP $0fbe ; (tsb_rot.s4 + 0)
.s3:
0faf : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1261, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
0fb0 : a2 00 __ LDX #$00
.l5:
0fb2 : bd 00 1a LDA $1a00,x ; (tab[0] + 0)
0fb5 : 9d 80 1a STA $1a80,x ; (tsb_sintab[0] + 0)
0fb8 : e8 __ __ INX
0fb9 : e0 40 __ CPX #$40
0fbb : d0 f5 __ BNE $0fb2 ; (tsb_init_tables.l5 + 0)
.s3:
0fbd : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
0fbe : a5 0d __ LDA P0 ; (angle + 0)
0fc0 : 29 07 __ AND #$07
0fc2 : 0a __ __ ASL
0fc3 : 0a __ __ ASL
0fc4 : 0a __ __ ASL
0fc5 : aa __ __ TAX
0fc6 : a9 00 __ LDA #$00
0fc8 : 85 1b __ STA ACCU + 0 
.l5:
0fca : 8a __ __ TXA
0fcb : 65 1b __ ADC ACCU + 0 
0fcd : a8 __ __ TAY
0fce : b9 40 1a LDA $1a40,y ; (tsb_rottab[0] + 0)
0fd1 : a4 1b __ LDY ACCU + 0 
0fd3 : c8 __ __ INY
0fd4 : 84 1b __ STY ACCU + 0 
0fd6 : 99 c5 19 STA $19c5,y ; (b_data_len + 1)
0fd9 : c0 08 __ CPY #$08
0fdb : 90 ed __ BCC $0fca ; (tsb_rot.l5 + 0)
.s3:
0fdd : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
0fde : a5 13 __ LDA P6 ; (c + 0)
0fe0 : c9 93 __ CMP #$93
0fe2 : d0 03 __ BNE $0fe7 ; (b_putc.s5 + 0)
0fe4 : 4c 75 10 JMP $1075 ; (b_putc.s14 + 0)
.s5:
0fe7 : c9 13 __ CMP #$13
0fe9 : d0 0d __ BNE $0ff8 ; (b_putc.s6 + 0)
.s13:
0feb : a9 00 __ LDA #$00
0fed : 8d be 19 STA $19be ; (b_row + 0)
0ff0 : 8d bf 19 STA $19bf ; (b_row + 1)
0ff3 : 8d bc 19 STA $19bc ; (b_col + 0)
0ff6 : f0 76 __ BEQ $106e ; (b_putc.s17 + 0)
.s6:
0ff8 : c9 0d __ CMP #$0d
0ffa : f0 76 __ BEQ $1072 ; (b_putc.s12 + 0)
.s7:
0ffc : ad bd 19 LDA $19bd ; (b_col + 1)
0fff : 30 0c __ BMI $100d ; (b_putc.s8 + 0)
.s11:
1001 : d0 07 __ BNE $100a ; (b_putc.s9 + 0)
.s10:
1003 : ad bc 19 LDA $19bc ; (b_col + 0)
1006 : c9 28 __ CMP #$28
1008 : 90 03 __ BCC $100d ; (b_putc.s8 + 0)
.s9:
100a : 20 b9 10 JSR $10b9 ; (b_newline.s4 + 0)
.s8:
100d : a5 13 __ LDA P6 ; (c + 0)
100f : 20 15 12 JSR $1215 ; (b_pet2scr.s4 + 0)
1012 : 85 4e __ STA T3 + 0 
1014 : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
1017 : ad ba 19 LDA $19ba ; (b_mem + 0)
101a : 18 __ __ CLC
101b : 65 1b __ ADC ACCU + 0 
101d : 85 4a __ STA T1 + 0 
101f : ad bb 19 LDA $19bb ; (b_mem + 1)
1022 : 65 1c __ ADC ACCU + 1 
1024 : 85 4b __ STA T1 + 1 
1026 : ad be 19 LDA $19be ; (b_row + 0)
1029 : 0a __ __ ASL
102a : 85 07 __ STA WORK + 4 
102c : ad bf 19 LDA $19bf ; (b_row + 1)
102f : 2a __ __ ROL
1030 : 06 07 __ ASL WORK + 4 
1032 : 2a __ __ ROL
1033 : aa __ __ TAX
1034 : 18 __ __ CLC
1035 : a5 07 __ LDA WORK + 4 
1037 : 6d be 19 ADC $19be ; (b_row + 0)
103a : 85 1b __ STA ACCU + 0 
103c : 8a __ __ TXA
103d : 6d bf 19 ADC $19bf ; (b_row + 1)
1040 : 06 1b __ ASL ACCU + 0 
1042 : 2a __ __ ROL
1043 : 06 1b __ ASL ACCU + 0 
1045 : 2a __ __ ROL
1046 : 06 1b __ ASL ACCU + 0 
1048 : 2a __ __ ROL
1049 : 85 1c __ STA ACCU + 1 
104b : ad bc 19 LDA $19bc ; (b_col + 0)
104e : aa __ __ TAX
104f : 18 __ __ CLC
1050 : 65 1b __ ADC ACCU + 0 
1052 : a8 __ __ TAY
1053 : ad bd 19 LDA $19bd ; (b_col + 1)
1056 : 85 4d __ STA T2 + 1 
1058 : 65 1c __ ADC ACCU + 1 
105a : 18 __ __ CLC
105b : 65 4b __ ADC T1 + 1 
105d : 85 4b __ STA T1 + 1 
105f : a5 4e __ LDA T3 + 0 
1061 : 91 4a __ STA (T1 + 0),y 
1063 : 8a __ __ TXA
1064 : 18 __ __ CLC
1065 : 69 01 __ ADC #$01
1067 : 8d bc 19 STA $19bc ; (b_col + 0)
106a : a5 4d __ LDA T2 + 1 
106c : 69 00 __ ADC #$00
.s17:
106e : 8d bd 19 STA $19bd ; (b_col + 1)
.s3:
1071 : 60 __ __ RTS
.s12:
1072 : 4c b9 10 JMP $10b9 ; (b_newline.s4 + 0)
.s14:
1075 : a9 00 __ LDA #$00
1077 : 8d be 19 STA $19be ; (b_row + 0)
107a : 8d bf 19 STA $19bf ; (b_row + 1)
107d : 8d bc 19 STA $19bc ; (b_col + 0)
1080 : 8d bd 19 STA $19bd ; (b_col + 1)
1083 : 85 4c __ STA T2 + 0 
1085 : 85 4d __ STA T2 + 1 
.l15:
1087 : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
108a : ad ba 19 LDA $19ba ; (b_mem + 0)
108d : 18 __ __ CLC
108e : 65 1b __ ADC ACCU + 0 
1090 : 85 4a __ STA T1 + 0 
1092 : ad bb 19 LDA $19bb ; (b_mem + 1)
1095 : 65 1c __ ADC ACCU + 1 
1097 : 18 __ __ CLC
1098 : 65 4d __ ADC T2 + 1 
109a : 85 4b __ STA T1 + 1 
109c : a9 20 __ LDA #$20
109e : a4 4c __ LDY T2 + 0 
10a0 : 91 4a __ STA (T1 + 0),y 
10a2 : 98 __ __ TYA
10a3 : 18 __ __ CLC
10a4 : 69 01 __ ADC #$01
10a6 : 85 4c __ STA T2 + 0 
10a8 : a5 4d __ LDA T2 + 1 
10aa : 69 00 __ ADC #$00
10ac : 85 4d __ STA T2 + 1 
10ae : c9 03 __ CMP #$03
10b0 : d0 d5 __ BNE $1087 ; (b_putc.l15 + 0)
.s16:
10b2 : a5 4c __ LDA T2 + 0 
10b4 : c9 e8 __ CMP #$e8
10b6 : d0 cf __ BNE $1087 ; (b_putc.l15 + 0)
10b8 : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
10b9 : a9 00 __ LDA #$00
10bb : 8d bc 19 STA $19bc ; (b_col + 0)
10be : 8d bd 19 STA $19bd ; (b_col + 1)
10c1 : ad be 19 LDA $19be ; (b_row + 0)
10c4 : aa __ __ TAX
10c5 : 18 __ __ CLC
10c6 : 69 01 __ ADC #$01
10c8 : 8d be 19 STA $19be ; (b_row + 0)
10cb : ad bf 19 LDA $19bf ; (b_row + 1)
10ce : a8 __ __ TAY
10cf : 69 00 __ ADC #$00
10d1 : 8d bf 19 STA $19bf ; (b_row + 1)
10d4 : 98 __ __ TYA
10d5 : 30 13 __ BMI $10ea ; (b_newline.s3 + 0)
.s7:
10d7 : d0 04 __ BNE $10dd ; (b_newline.s5 + 0)
.s6:
10d9 : e0 18 __ CPX #$18
10db : 90 0d __ BCC $10ea ; (b_newline.s3 + 0)
.s5:
10dd : 20 eb 10 JSR $10eb ; (b_scroll.s4 + 0)
10e0 : a9 18 __ LDA #$18
10e2 : 8d be 19 STA $19be ; (b_row + 0)
10e5 : a9 00 __ LDA #$00
10e7 : 8d bf 19 STA $19bf ; (b_row + 1)
.s3:
10ea : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
10eb : a9 c0 __ LDA #$c0
10ed : 85 11 __ STA P4 
10ef : a9 03 __ LDA #$03
10f1 : 85 12 __ STA P5 
10f3 : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
10f6 : ad ba 19 LDA $19ba ; (b_mem + 0)
10f9 : 85 45 __ STA T1 + 0 
10fb : 18 __ __ CLC
10fc : 65 1b __ ADC ACCU + 0 
10fe : 85 0d __ STA P0 
1100 : ad bb 19 LDA $19bb ; (b_mem + 1)
1103 : 85 46 __ STA T1 + 1 
1105 : 65 1c __ ADC ACCU + 1 
1107 : 85 0e __ STA P1 
1109 : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
110c : 18 __ __ CLC
110d : a5 45 __ LDA T1 + 0 
110f : 65 1b __ ADC ACCU + 0 
1111 : aa __ __ TAX
1112 : a5 46 __ LDA T1 + 1 
1114 : 65 1c __ ADC ACCU + 1 
1116 : a8 __ __ TAY
1117 : 8a __ __ TXA
1118 : 18 __ __ CLC
1119 : 69 28 __ ADC #$28
111b : 85 0f __ STA P2 
111d : 90 01 __ BCC $1120 ; (b_scroll.s7 + 0)
.s6:
111f : c8 __ __ INY
.s7:
1120 : 84 10 __ STY P3 
1122 : 20 80 11 JSR $1180 ; (memmove.s4 + 0)
1125 : a9 03 __ LDA #$03
1127 : 85 12 __ STA P5 
1129 : 18 __ __ CLC
112a : a5 46 __ LDA T1 + 1 
112c : 69 d8 __ ADC #$d8
112e : 85 0e __ STA P1 
1130 : a5 45 __ LDA T1 + 0 
1132 : 85 0d __ STA P0 
1134 : 18 __ __ CLC
1135 : 69 28 __ ADC #$28
1137 : 85 0f __ STA P2 
1139 : a5 46 __ LDA T1 + 1 
113b : 69 d8 __ ADC #$d8
113d : 85 10 __ STA P3 
113f : 20 80 11 JSR $1180 ; (memmove.s4 + 0)
1142 : 18 __ __ CLC
1143 : a5 45 __ LDA T1 + 0 
1145 : 69 c0 __ ADC #$c0
1147 : 85 47 __ STA T2 + 0 
1149 : a5 46 __ LDA T1 + 1 
114b : 69 db __ ADC #$db
114d : 85 48 __ STA T2 + 1 
114f : a9 00 __ LDA #$00
1151 : 85 49 __ STA T3 + 0 
.l5:
1153 : 20 5d 0f JSR $0f5d ; (b_scr_base.s4 + 0)
1156 : 18 __ __ CLC
1157 : a5 45 __ LDA T1 + 0 
1159 : 65 1b __ ADC ACCU + 0 
115b : a8 __ __ TAY
115c : a5 46 __ LDA T1 + 1 
115e : 65 1c __ ADC ACCU + 1 
1160 : aa __ __ TAX
1161 : 98 __ __ TYA
1162 : 18 __ __ CLC
1163 : 65 49 __ ADC T3 + 0 
1165 : 85 1f __ STA ADDR + 0 
1167 : 8a __ __ TXA
1168 : 69 03 __ ADC #$03
116a : 85 20 __ STA ADDR + 1 
116c : a9 20 __ LDA #$20
116e : a0 c0 __ LDY #$c0
1170 : 91 1f __ STA (ADDR + 0),y 
1172 : a9 0e __ LDA #$0e
1174 : a4 49 __ LDY T3 + 0 
1176 : 91 47 __ STA (T2 + 0),y 
1178 : c8 __ __ INY
1179 : 84 49 __ STY T3 + 0 
117b : c0 28 __ CPY #$28
117d : 90 d4 __ BCC $1153 ; (b_scroll.l5 + 0)
.s3:
117f : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1180 : a5 12 __ LDA P5 ; (size + 1)
1182 : 30 65 __ BMI $11e9 ; (memmove.s5 + 0)
.s14:
1184 : 05 11 __ ORA P4 ; (size + 0)
1186 : f0 61 __ BEQ $11e9 ; (memmove.s5 + 0)
.s6:
1188 : a5 0d __ LDA P0 ; (dst + 0)
118a : 85 1b __ STA ACCU + 0 
118c : a5 0f __ LDA P2 ; (src + 0)
118e : 85 43 __ STA T3 + 0 
1190 : a5 0e __ LDA P1 ; (dst + 1)
1192 : 85 1c __ STA ACCU + 1 
1194 : a6 10 __ LDX P3 ; (src + 1)
1196 : 86 44 __ STX T3 + 1 
1198 : c5 10 __ CMP P3 ; (src + 1)
119a : d0 04 __ BNE $11a0 ; (memmove.s13 + 0)
.s12:
119c : a5 0d __ LDA P0 ; (dst + 0)
119e : c5 0f __ CMP P2 ; (src + 0)
.s13:
11a0 : 90 50 __ BCC $11f2 ; (memmove.s11 + 0)
.s7:
11a2 : e4 0e __ CPX P1 ; (dst + 1)
11a4 : d0 04 __ BNE $11aa ; (memmove.s10 + 0)
.s9:
11a6 : a5 0f __ LDA P2 ; (src + 0)
11a8 : c5 0d __ CMP P0 ; (dst + 0)
.s10:
11aa : b0 3d __ BCS $11e9 ; (memmove.s5 + 0)
.s8:
11ac : a5 0f __ LDA P2 ; (src + 0)
11ae : 65 11 __ ADC P4 ; (size + 0)
11b0 : 85 43 __ STA T3 + 0 
11b2 : 8a __ __ TXA
11b3 : 65 12 __ ADC P5 ; (size + 1)
11b5 : 85 44 __ STA T3 + 1 
11b7 : 18 __ __ CLC
11b8 : a5 0d __ LDA P0 ; (dst + 0)
11ba : 65 11 __ ADC P4 ; (size + 0)
11bc : 85 1b __ STA ACCU + 0 
11be : a5 0e __ LDA P1 ; (dst + 1)
11c0 : 65 12 __ ADC P5 ; (size + 1)
11c2 : 85 1c __ STA ACCU + 1 
11c4 : a0 00 __ LDY #$00
11c6 : a5 11 __ LDA P4 ; (size + 0)
11c8 : f0 02 __ BEQ $11cc ; (memmove.s30 + 0)
.s16:
11ca : e6 12 __ INC P5 ; (size + 1)
.s30:
11cc : a6 11 __ LDX P4 ; (size + 0)
.l19:
11ce : a5 43 __ LDA T3 + 0 
11d0 : d0 02 __ BNE $11d4 ; (memmove.s26 + 0)
.s25:
11d2 : c6 44 __ DEC T3 + 1 
.s26:
11d4 : c6 43 __ DEC T3 + 0 
11d6 : a5 1b __ LDA ACCU + 0 
11d8 : d0 02 __ BNE $11dc ; (memmove.s28 + 0)
.s27:
11da : c6 1c __ DEC ACCU + 1 
.s28:
11dc : c6 1b __ DEC ACCU + 0 
11de : b1 43 __ LDA (T3 + 0),y 
11e0 : 91 1b __ STA (ACCU + 0),y 
11e2 : ca __ __ DEX
11e3 : d0 e9 __ BNE $11ce ; (memmove.l19 + 0)
.s20:
11e5 : c6 12 __ DEC P5 ; (size + 1)
11e7 : d0 e5 __ BNE $11ce ; (memmove.l19 + 0)
.s5:
11e9 : a5 0d __ LDA P0 ; (dst + 0)
11eb : 85 1b __ STA ACCU + 0 
11ed : a5 0e __ LDA P1 ; (dst + 1)
11ef : 85 1c __ STA ACCU + 1 
.s3:
11f1 : 60 __ __ RTS
.s11:
11f2 : a0 00 __ LDY #$00
11f4 : a5 11 __ LDA P4 ; (size + 0)
11f6 : f0 02 __ BEQ $11fa ; (memmove.s29 + 0)
.s15:
11f8 : e6 12 __ INC P5 ; (size + 1)
.s29:
11fa : a6 11 __ LDX P4 ; (size + 0)
.l17:
11fc : b1 43 __ LDA (T3 + 0),y 
11fe : 91 1b __ STA (ACCU + 0),y 
1200 : e6 43 __ INC T3 + 0 
1202 : d0 02 __ BNE $1206 ; (memmove.s22 + 0)
.s21:
1204 : e6 44 __ INC T3 + 1 
.s22:
1206 : e6 1b __ INC ACCU + 0 
1208 : d0 02 __ BNE $120c ; (memmove.s24 + 0)
.s23:
120a : e6 1c __ INC ACCU + 1 
.s24:
120c : ca __ __ DEX
120d : d0 ed __ BNE $11fc ; (memmove.l17 + 0)
.s18:
120f : c6 12 __ DEC P5 ; (size + 1)
1211 : d0 e9 __ BNE $11fc ; (memmove.l17 + 0)
1213 : f0 d4 __ BEQ $11e9 ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1215 : c9 41 __ CMP #$41
1217 : 90 06 __ BCC $121f ; (b_pet2scr.s3 + 0)
.s8:
1219 : c9 5b __ CMP #$5b
121b : b0 03 __ BCS $1220 ; (b_pet2scr.s5 + 0)
.s9:
121d : e9 3f __ SBC #$3f
.s3:
121f : 60 __ __ RTS
.s5:
1220 : c9 c1 __ CMP #$c1
1222 : 90 fb __ BCC $121f ; (b_pet2scr.s3 + 0)
.s6:
1224 : c9 db __ CMP #$db
1226 : b0 f7 __ BCS $121f ; (b_pet2scr.s3 + 0)
.s7:
1228 : e9 bf __ SBC #$bf
122a : 60 __ __ RTS
--------------------------------------------------------------------
b_read_real: ; b_read_real()->float
;1146, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
122b : ad c2 19 LDA $19c2 ; (b_dataPtr + 0)
122e : 85 43 __ STA T0 + 0 
1230 : 18 __ __ CLC
1231 : 69 01 __ ADC #$01
1233 : 8d c2 19 STA $19c2 ; (b_dataPtr + 0)
1236 : ad c3 19 LDA $19c3 ; (b_dataPtr + 1)
1239 : aa __ __ TAX
123a : 69 00 __ ADC #$00
123c : 8d c3 19 STA $19c3 ; (b_dataPtr + 1)
123f : 8a __ __ TXA
1240 : ec c5 19 CPX $19c5 ; (b_data_len + 1)
1243 : d0 09 __ BNE $124e ; (b_read_real.s15 + 0)
.s12:
1245 : a5 43 __ LDA T0 + 0 
1247 : cd c4 19 CMP $19c4 ; (b_data_len + 0)
.s13:
124a : b0 09 __ BCS $1255 ; (b_read_real.s11 + 0)
124c : 90 12 __ BCC $1260 ; (b_read_real.s5 + 0)
.s15:
124e : 4d c5 19 EOR $19c5 ; (b_data_len + 1)
1251 : 10 f7 __ BPL $124a ; (b_read_real.s13 + 0)
.s14:
1253 : b0 0b __ BCS $1260 ; (b_read_real.s5 + 0)
.s11:
1255 : a9 00 __ LDA #$00
1257 : 85 1b __ STA ACCU + 0 
1259 : 85 1c __ STA ACCU + 1 
125b : 85 1d __ STA ACCU + 2 
.s16:
125d : 85 1e __ STA ACCU + 3 
.s3:
125f : 60 __ __ RTS
.s5:
1260 : a4 43 __ LDY T0 + 0 
1262 : be af 19 LDX $19af,y ; (__multab14L + 0)
1265 : bd 01 1b LDA $1b01,x ; (b_data[0].kind + 1)
1268 : d0 20 __ BNE $128a ; (b_read_real.s7 + 0)
.s10:
126a : bc 00 1b LDY $1b00,x ; (b_data[0].kind + 0)
126d : 88 __ __ DEY
126e : d0 15 __ BNE $1285 ; (b_read_real.s6 + 0)
.s9:
1270 : bd 06 1b LDA $1b06,x ; (b_data[0].f + 0)
1273 : 85 1b __ STA ACCU + 0 
1275 : bd 07 1b LDA $1b07,x ; (b_data[0].f + 1)
1278 : 85 1c __ STA ACCU + 1 
127a : bd 08 1b LDA $1b08,x ; (b_data[0].f + 2)
127d : 85 1d __ STA ACCU + 2 
127f : bd 09 1b LDA $1b09,x ; (b_data[0].f + 3)
1282 : 85 1e __ STA ACCU + 3 
1284 : 60 __ __ RTS
.s6:
1285 : bd 00 1b LDA $1b00,x ; (b_data[0].kind + 0)
1288 : f0 1b __ BEQ $12a5 ; (b_read_real.s8 + 0)
.s7:
128a : bd 0a 1b LDA $1b0a,x ; (b_data[0].s + 0)
128d : 8d fc 9f STA $9ffc ; (sstack + 0)
1290 : bd 0b 1b LDA $1b0b,x ; (b_data[0].s + 1)
1293 : 8d fd 9f STA $9ffd ; (sstack + 1)
1296 : bd 0c 1b LDA $1b0c,x ; (b_data[0].slen + 0)
1299 : 8d fe 9f STA $9ffe ; (sstack + 2)
129c : bd 0d 1b LDA $1b0d,x ; (b_data[0].slen + 1)
129f : 8d ff 9f STA $9fff ; (sstack + 3)
12a2 : 4c bc 12 JMP $12bc ; (b_val.s4 + 0)
.s8:
12a5 : bd 02 1b LDA $1b02,x ; (b_data[0].i + 0)
12a8 : 85 1b __ STA ACCU + 0 
12aa : bd 03 1b LDA $1b03,x ; (b_data[0].i + 1)
12ad : 85 1c __ STA ACCU + 1 
12af : bd 04 1b LDA $1b04,x ; (b_data[0].i + 2)
12b2 : 85 1d __ STA ACCU + 2 
12b4 : bd 05 1b LDA $1b05,x ; (b_data[0].i + 3)
12b7 : 85 1e __ STA ACCU + 3 
12b9 : 4c 3d 19 JMP $193d ; (sint32_to_float + 0)
--------------------------------------------------------------------
b_val: ; b_val(struct bstr_tag)->float
;1099, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
12bc : ad fe 9f LDA $9ffe ; (sstack + 2)
12bf : 85 43 __ STA T0 + 0 
12c1 : ad ff 9f LDA $9fff ; (sstack + 3)
12c4 : 30 23 __ BMI $12e9 ; (b_val.s7 + 0)
.s11:
12c6 : d0 06 __ BNE $12ce ; (b_val.s5 + 0)
.s10:
12c8 : a5 43 __ LDA T0 + 0 
12ca : c9 3c __ CMP #$3c
12cc : 90 12 __ BCC $12e0 ; (b_val.s8 + 0)
.s5:
12ce : a9 3c __ LDA #$3c
12d0 : 85 43 __ STA T0 + 0 
.s6:
12d2 : ad fc 9f LDA $9ffc ; (sstack + 0)
12d5 : 85 49 __ STA T2 + 0 
12d7 : ad fd 9f LDA $9ffd ; (sstack + 1)
12da : 85 4a __ STA T2 + 1 
12dc : a0 00 __ LDY #$00
12de : f0 1b __ BEQ $12fb ; (b_val.l12 + 0)
.s8:
12e0 : ad ff 9f LDA $9fff ; (sstack + 3)
12e3 : 30 04 __ BMI $12e9 ; (b_val.s7 + 0)
.s9:
12e5 : 05 43 __ ORA T0 + 0 
12e7 : d0 e9 __ BNE $12d2 ; (b_val.s6 + 0)
.s7:
12e9 : a9 00 __ LDA #$00
12eb : a6 43 __ LDX T0 + 0 
12ed : 9d b1 9f STA $9fb1,x ; (buf[0] + 0)
12f0 : a9 b1 __ LDA #$b1
12f2 : 85 0d __ STA P0 
12f4 : a9 9f __ LDA #$9f
12f6 : 85 0e __ STA P1 
12f8 : 4c 07 13 JMP $1307 ; (b_atof.s1 + 0)
.l12:
12fb : b1 49 __ LDA (T2 + 0),y 
12fd : 99 b1 9f STA $9fb1,y ; (buf[0] + 0)
1300 : c8 __ __ INY
1301 : c4 43 __ CPY T0 + 0 
1303 : 90 f6 __ BCC $12fb ; (b_val.l12 + 0)
1305 : b0 e2 __ BCS $12e9 ; (b_val.s7 + 0)
--------------------------------------------------------------------
b_atof: ; b_atof(const u8*)->float
;1084, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s1:
1307 : a2 05 __ LDX #$05
1309 : b5 53 __ LDA T6 + 0,x 
130b : 9d f1 9f STA $9ff1,x ; (b_atof@stack + 0)
130e : ca __ __ DEX
130f : 10 f8 __ BPL $1309 ; (b_atof.s1 + 2)
.s4:
1311 : a9 00 __ LDA #$00
1313 : 85 43 __ STA T0 + 0 
1315 : 85 44 __ STA T0 + 1 
1317 : 85 45 __ STA T0 + 2 
1319 : 85 46 __ STA T0 + 3 
131b : 85 47 __ STA T1 + 0 
131d : 85 48 __ STA T1 + 1 
131f : 85 49 __ STA T1 + 2 
1321 : 85 4a __ STA T1 + 3 
1323 : 85 4b __ STA T2 + 0 
1325 : 85 4c __ STA T2 + 1 
1327 : 85 4f __ STA T4 + 0 
1329 : 85 50 __ STA T5 + 0 
132b : 85 53 __ STA T6 + 0 
132d : 85 54 __ STA T6 + 1 
132f : 85 1c __ STA ACCU + 1 
1331 : a9 80 __ LDA #$80
1333 : 85 4d __ STA T2 + 2 
1335 : a9 3f __ LDA #$3f
1337 : 85 4e __ STA T2 + 3 
.l5:
1339 : a0 00 __ LDY #$00
133b : b1 0d __ LDA (P0),y ; (s + 0)
133d : c9 20 __ CMP #$20
133f : f0 04 __ BEQ $1345 ; (b_atof.s41 + 0)
.s6:
1341 : c9 09 __ CMP #$09
1343 : d0 09 __ BNE $134e ; (b_atof.s7 + 0)
.s41:
1345 : e6 0d __ INC P0 ; (s + 0)
1347 : d0 f0 __ BNE $1339 ; (b_atof.l5 + 0)
.s43:
1349 : e6 0e __ INC P1 ; (s + 1)
134b : 4c 39 13 JMP $1339 ; (b_atof.l5 + 0)
.s7:
134e : c9 2d __ CMP #$2d
1350 : d0 03 __ BNE $1355 ; (b_atof.s8 + 0)
1352 : 4c 02 16 JMP $1602 ; (b_atof.s40 + 0)
.s8:
1355 : c9 2b __ CMP #$2b
1357 : d0 06 __ BNE $135f ; (b_atof.s9 + 0)
.s39:
1359 : e6 0d __ INC P0 ; (s + 0)
135b : d0 02 __ BNE $135f ; (b_atof.s9 + 0)
.s58:
135d : e6 0e __ INC P1 ; (s + 1)
.s9:
135f : b1 0d __ LDA (P0),y ; (s + 0)
1361 : c9 30 __ CMP #$30
1363 : 90 6f __ BCC $13d4 ; (b_atof.s10 + 0)
.l37:
1365 : a5 0d __ LDA P0 ; (s + 0)
1367 : 85 55 __ STA T7 + 0 
1369 : a5 0e __ LDA P1 ; (s + 1)
136b : 85 56 __ STA T7 + 1 
136d : a0 00 __ LDY #$00
136f : b1 0d __ LDA (P0),y ; (s + 0)
1371 : c9 3a __ CMP #$3a
1373 : b0 5f __ BCS $13d4 ; (b_atof.s10 + 0)
.s38:
1375 : 84 1b __ STY ACCU + 0 
1377 : 84 1c __ STY ACCU + 1 
1379 : 85 57 __ STA T8 + 0 
137b : e6 0d __ INC P0 ; (s + 0)
137d : d0 02 __ BNE $1381 ; (b_atof.s57 + 0)
.s56:
137f : e6 0e __ INC P1 ; (s + 1)
.s57:
1381 : a9 20 __ LDA #$20
1383 : 85 1d __ STA ACCU + 2 
1385 : a9 41 __ LDA #$41
1387 : 85 1e __ STA ACCU + 3 
1389 : a2 43 __ LDX #$43
138b : 20 11 16 JSR $1611 ; (freg + 4)
138e : 20 3f 17 JSR $173f ; (crt_fmul + 0)
1391 : a5 1b __ LDA ACCU + 0 
1393 : 85 43 __ STA T0 + 0 
1395 : a5 1c __ LDA ACCU + 1 
1397 : 85 44 __ STA T0 + 1 
1399 : a5 1d __ LDA ACCU + 2 
139b : 85 45 __ STA T0 + 2 
139d : a5 1e __ LDA ACCU + 3 
139f : 85 46 __ STA T0 + 3 
13a1 : 38 __ __ SEC
13a2 : a5 57 __ LDA T8 + 0 
13a4 : e9 30 __ SBC #$30
13a6 : 85 1b __ STA ACCU + 0 
13a8 : a9 00 __ LDA #$00
13aa : e9 00 __ SBC #$00
13ac : 85 1c __ STA ACCU + 1 
13ae : 20 14 19 JSR $1914 ; (uint16_to_float + 0)
13b1 : a2 43 __ LDX #$43
13b3 : 20 11 16 JSR $1611 ; (freg + 4)
13b6 : 20 58 16 JSR $1658 ; (faddsub + 6)
13b9 : a5 1b __ LDA ACCU + 0 
13bb : 85 43 __ STA T0 + 0 
13bd : a5 1c __ LDA ACCU + 1 
13bf : 85 44 __ STA T0 + 1 
13c1 : a5 1d __ LDA ACCU + 2 
13c3 : 85 45 __ STA T0 + 2 
13c5 : a5 1e __ LDA ACCU + 3 
13c7 : 85 46 __ STA T0 + 3 
13c9 : a0 01 __ LDY #$01
13cb : 84 1c __ STY ACCU + 1 
13cd : b1 55 __ LDA (T7 + 0),y 
13cf : c9 30 __ CMP #$30
13d1 : b0 92 __ BCS $1365 ; (b_atof.l37 + 0)
.s59:
13d3 : 88 __ __ DEY
.s10:
13d4 : b1 0d __ LDA (P0),y ; (s + 0)
13d6 : c9 2e __ CMP #$2e
13d8 : f0 03 __ BEQ $13dd ; (b_atof.s33 + 0)
13da : 4c 7d 14 JMP $147d ; (b_atof.s11 + 0)
.s33:
13dd : a5 0e __ LDA P1 ; (s + 1)
13df : 85 56 __ STA T7 + 1 
13e1 : a5 0d __ LDA P0 ; (s + 0)
13e3 : 85 55 __ STA T7 + 0 
.l34:
13e5 : e6 0d __ INC P0 ; (s + 0)
13e7 : d0 02 __ BNE $13eb ; (b_atof.s47 + 0)
.s46:
13e9 : e6 0e __ INC P1 ; (s + 1)
.s47:
13eb : a0 01 __ LDY #$01
13ed : b1 55 __ LDA (T7 + 0),y 
13ef : c9 30 __ CMP #$30
13f1 : 88 __ __ DEY
13f2 : 90 e6 __ BCC $13da ; (b_atof.s10 + 6)
.s35:
13f4 : a5 0d __ LDA P0 ; (s + 0)
13f6 : 85 55 __ STA T7 + 0 
13f8 : a5 0e __ LDA P1 ; (s + 1)
13fa : 85 56 __ STA T7 + 1 
13fc : b1 0d __ LDA (P0),y ; (s + 0)
13fe : c9 3a __ CMP #$3a
1400 : b0 7b __ BCS $147d ; (b_atof.s11 + 0)
.s36:
1402 : 84 1b __ STY ACCU + 0 
1404 : 84 1c __ STY ACCU + 1 
1406 : 85 57 __ STA T8 + 0 
1408 : a9 20 __ LDA #$20
140a : 85 1d __ STA ACCU + 2 
140c : a9 41 __ LDA #$41
140e : 85 1e __ STA ACCU + 3 
1410 : a2 4b __ LDX #$4b
1412 : 20 11 16 JSR $1611 ; (freg + 4)
1415 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
1418 : a5 1b __ LDA ACCU + 0 
141a : 85 4b __ STA T2 + 0 
141c : a5 1c __ LDA ACCU + 1 
141e : 85 4c __ STA T2 + 1 
1420 : a5 1d __ LDA ACCU + 2 
1422 : 85 4d __ STA T2 + 2 
1424 : a5 1e __ LDA ACCU + 3 
1426 : 85 4e __ STA T2 + 3 
1428 : a9 00 __ LDA #$00
142a : 85 1b __ STA ACCU + 0 
142c : 85 1c __ STA ACCU + 1 
142e : a9 20 __ LDA #$20
1430 : 85 1d __ STA ACCU + 2 
1432 : a9 41 __ LDA #$41
1434 : 85 1e __ STA ACCU + 3 
1436 : a2 47 __ LDX #$47
1438 : 20 11 16 JSR $1611 ; (freg + 4)
143b : 20 3f 17 JSR $173f ; (crt_fmul + 0)
143e : a5 1b __ LDA ACCU + 0 
1440 : 85 47 __ STA T1 + 0 
1442 : a5 1c __ LDA ACCU + 1 
1444 : 85 48 __ STA T1 + 1 
1446 : a5 1d __ LDA ACCU + 2 
1448 : 85 49 __ STA T1 + 2 
144a : a5 1e __ LDA ACCU + 3 
144c : 85 4a __ STA T1 + 3 
144e : 38 __ __ SEC
144f : a5 57 __ LDA T8 + 0 
1451 : e9 30 __ SBC #$30
1453 : 85 1b __ STA ACCU + 0 
1455 : a9 00 __ LDA #$00
1457 : e9 00 __ SBC #$00
1459 : 85 1c __ STA ACCU + 1 
145b : 20 14 19 JSR $1914 ; (uint16_to_float + 0)
145e : a2 47 __ LDX #$47
1460 : 20 11 16 JSR $1611 ; (freg + 4)
1463 : 20 58 16 JSR $1658 ; (faddsub + 6)
1466 : a5 1b __ LDA ACCU + 0 
1468 : 85 47 __ STA T1 + 0 
146a : a5 1c __ LDA ACCU + 1 
146c : 85 48 __ STA T1 + 1 
146e : a5 1d __ LDA ACCU + 2 
1470 : 85 49 __ STA T1 + 2 
1472 : a5 1e __ LDA ACCU + 3 
1474 : 85 4a __ STA T1 + 3 
1476 : a9 01 __ LDA #$01
1478 : 85 1c __ STA ACCU + 1 
147a : 4c e5 13 JMP $13e5 ; (b_atof.l34 + 0)
.s11:
147d : a5 0d __ LDA P0 ; (s + 0)
147f : 85 55 __ STA T7 + 0 
1481 : a5 0e __ LDA P1 ; (s + 1)
1483 : 85 56 __ STA T7 + 1 
1485 : b1 0d __ LDA (P0),y ; (s + 0)
1487 : c9 45 __ CMP #$45
1489 : f0 07 __ BEQ $1492 ; (b_atof.s26 + 0)
.s12:
148b : c9 65 __ CMP #$65
148d : f0 03 __ BEQ $1492 ; (b_atof.s26 + 0)
148f : 4c 13 15 JMP $1513 ; (b_atof.s13 + 0)
.s26:
1492 : e6 0d __ INC P0 ; (s + 0)
1494 : d0 02 __ BNE $1498 ; (b_atof.s49 + 0)
.s48:
1496 : e6 0e __ INC P1 ; (s + 1)
.s49:
1498 : a0 01 __ LDY #$01
149a : b1 55 __ LDA (T7 + 0),y 
149c : c9 2d __ CMP #$2d
149e : d0 10 __ BNE $14b0 ; (b_atof.s27 + 0)
.s32:
14a0 : a5 55 __ LDA T7 + 0 
14a2 : 69 01 __ ADC #$01
14a4 : 85 0d __ STA P0 ; (s + 0)
14a6 : a5 56 __ LDA T7 + 1 
14a8 : 69 00 __ ADC #$00
14aa : 85 0e __ STA P1 ; (s + 1)
14ac : e6 50 __ INC T5 + 0 
14ae : d0 10 __ BNE $14c0 ; (b_atof.s28 + 0)
.s27:
14b0 : c9 2b __ CMP #$2b
14b2 : d0 0c __ BNE $14c0 ; (b_atof.s28 + 0)
.s31:
14b4 : a5 55 __ LDA T7 + 0 
14b6 : 69 01 __ ADC #$01
14b8 : 85 0d __ STA P0 ; (s + 0)
14ba : a5 56 __ LDA T7 + 1 
14bc : 69 00 __ ADC #$00
14be : 85 0e __ STA P1 ; (s + 1)
.s28:
14c0 : a0 00 __ LDY #$00
14c2 : b1 0d __ LDA (P0),y ; (s + 0)
14c4 : c9 30 __ CMP #$30
14c6 : 90 4b __ BCC $1513 ; (b_atof.s13 + 0)
.l29:
14c8 : a5 0d __ LDA P0 ; (s + 0)
14ca : 85 55 __ STA T7 + 0 
14cc : a5 0e __ LDA P1 ; (s + 1)
14ce : 85 56 __ STA T7 + 1 
14d0 : a0 00 __ LDY #$00
14d2 : b1 0d __ LDA (P0),y ; (s + 0)
14d4 : c9 3a __ CMP #$3a
14d6 : b0 3b __ BCS $1513 ; (b_atof.s13 + 0)
.s30:
14d8 : e9 2f __ SBC #$2f
14da : aa __ __ TAX
14db : 98 __ __ TYA
14dc : e9 00 __ SBC #$00
14de : 85 58 __ STA T8 + 1 
14e0 : e6 0d __ INC P0 ; (s + 0)
14e2 : d0 02 __ BNE $14e6 ; (b_atof.s55 + 0)
.s54:
14e4 : e6 0e __ INC P1 ; (s + 1)
.s55:
14e6 : a5 53 __ LDA T6 + 0 
14e8 : 0a __ __ ASL
14e9 : 85 1b __ STA ACCU + 0 
14eb : a5 54 __ LDA T6 + 1 
14ed : 2a __ __ ROL
14ee : 06 1b __ ASL ACCU + 0 
14f0 : 2a __ __ ROL
14f1 : a8 __ __ TAY
14f2 : 18 __ __ CLC
14f3 : a5 1b __ LDA ACCU + 0 
14f5 : 65 53 __ ADC T6 + 0 
14f7 : 85 53 __ STA T6 + 0 
14f9 : 98 __ __ TYA
14fa : 65 54 __ ADC T6 + 1 
14fc : 06 53 __ ASL T6 + 0 
14fe : 2a __ __ ROL
14ff : a8 __ __ TAY
1500 : 8a __ __ TXA
1501 : 18 __ __ CLC
1502 : 65 53 __ ADC T6 + 0 
1504 : 85 53 __ STA T6 + 0 
1506 : 98 __ __ TYA
1507 : 65 58 __ ADC T8 + 1 
1509 : 85 54 __ STA T6 + 1 
150b : a0 01 __ LDY #$01
150d : b1 55 __ LDA (T7 + 0),y 
150f : c9 30 __ CMP #$30
1511 : b0 b5 __ BCS $14c8 ; (b_atof.l29 + 0)
.s13:
1513 : a5 1c __ LDA ACCU + 1 
1515 : d0 11 __ BNE $1528 ; (b_atof.s15 + 0)
.s14:
1517 : 85 1b __ STA ACCU + 0 
1519 : 85 1d __ STA ACCU + 2 
.s42:
151b : 85 1e __ STA ACCU + 3 
.s3:
151d : a2 05 __ LDX #$05
151f : bd f1 9f LDA $9ff1,x ; (b_atof@stack + 0)
1522 : 95 53 __ STA T6 + 0,x 
1524 : ca __ __ DEX
1525 : 10 f8 __ BPL $151f ; (b_atof.s3 + 2)
1527 : 60 __ __ RTS
.s15:
1528 : a5 47 __ LDA T1 + 0 
152a : 85 1b __ STA ACCU + 0 
152c : a5 48 __ LDA T1 + 1 
152e : 85 1c __ STA ACCU + 1 
1530 : a5 49 __ LDA T1 + 2 
1532 : 85 1d __ STA ACCU + 2 
1534 : a5 4a __ LDA T1 + 3 
1536 : 85 1e __ STA ACCU + 3 
1538 : a2 4b __ LDX #$4b
153a : 20 11 16 JSR $1611 ; (freg + 4)
153d : 20 07 18 JSR $1807 ; (crt_fdiv + 0)
1540 : a2 43 __ LDX #$43
1542 : 20 11 16 JSR $1611 ; (freg + 4)
1545 : 20 58 16 JSR $1658 ; (faddsub + 6)
1548 : a5 53 __ LDA T6 + 0 
154a : 05 54 __ ORA T6 + 1 
154c : d0 03 __ BNE $1551 ; (b_atof.s18 + 0)
154e : 4c f4 15 JMP $15f4 ; (b_atof.s16 + 0)
.s18:
1551 : a5 1e __ LDA ACCU + 3 
1553 : 85 46 __ STA T0 + 3 
1555 : a5 1d __ LDA ACCU + 2 
1557 : 85 45 __ STA T0 + 2 
1559 : a5 1c __ LDA ACCU + 1 
155b : 85 44 __ STA T0 + 1 
155d : a5 1b __ LDA ACCU + 0 
155f : 85 43 __ STA T0 + 0 
1561 : a9 00 __ LDA #$00
1563 : 85 47 __ STA T1 + 0 
1565 : 85 48 __ STA T1 + 1 
1567 : a9 20 __ LDA #$20
1569 : 85 49 __ STA T1 + 2 
156b : a9 41 __ LDA #$41
156d : 85 4a __ STA T1 + 3 
156f : a5 54 __ LDA T6 + 1 
1571 : 30 4a __ BMI $15bd ; (b_atof.s19 + 0)
.s25:
1573 : f0 05 __ BEQ $157a ; (b_atof.s24 + 0)
.s60:
1575 : a5 53 __ LDA T6 + 0 
1577 : 4c 80 15 JMP $1580 ; (b_atof.s22 + 0)
.s24:
157a : a5 53 __ LDA T6 + 0 
157c : c9 02 __ CMP #$02
157e : 90 3d __ BCC $15bd ; (b_atof.s19 + 0)
.s22:
1580 : 38 __ __ SEC
1581 : e9 01 __ SBC #$01
1583 : 85 53 __ STA T6 + 0 
1585 : b0 02 __ BCS $1589 ; (b_atof.l23 + 0)
.s50:
1587 : c6 54 __ DEC T6 + 1 
.l23:
1589 : a9 00 __ LDA #$00
158b : 85 1b __ STA ACCU + 0 
158d : 85 1c __ STA ACCU + 1 
158f : a9 20 __ LDA #$20
1591 : 85 1d __ STA ACCU + 2 
1593 : a9 41 __ LDA #$41
1595 : 85 1e __ STA ACCU + 3 
1597 : a2 47 __ LDX #$47
1599 : 20 11 16 JSR $1611 ; (freg + 4)
159c : 20 3f 17 JSR $173f ; (crt_fmul + 0)
159f : a5 1b __ LDA ACCU + 0 
15a1 : 85 47 __ STA T1 + 0 
15a3 : a5 1c __ LDA ACCU + 1 
15a5 : 85 48 __ STA T1 + 1 
15a7 : a5 1d __ LDA ACCU + 2 
15a9 : 85 49 __ STA T1 + 2 
15ab : a5 1e __ LDA ACCU + 3 
15ad : 85 4a __ STA T1 + 3 
15af : a5 53 __ LDA T6 + 0 
15b1 : d0 02 __ BNE $15b5 ; (b_atof.s52 + 0)
.s51:
15b3 : c6 54 __ DEC T6 + 1 
.s52:
15b5 : c6 53 __ DEC T6 + 0 
15b7 : d0 d0 __ BNE $1589 ; (b_atof.l23 + 0)
.s53:
15b9 : a5 54 __ LDA T6 + 1 
15bb : d0 cc __ BNE $1589 ; (b_atof.l23 + 0)
.s19:
15bd : a5 50 __ LDA T5 + 0 
15bf : d0 1b __ BNE $15dc ; (b_atof.s21 + 0)
.s20:
15c1 : a5 47 __ LDA T1 + 0 
15c3 : 85 1b __ STA ACCU + 0 
15c5 : a5 48 __ LDA T1 + 1 
15c7 : 85 1c __ STA ACCU + 1 
15c9 : a5 49 __ LDA T1 + 2 
15cb : 85 1d __ STA ACCU + 2 
15cd : a5 4a __ LDA T1 + 3 
15cf : 85 1e __ STA ACCU + 3 
15d1 : a2 43 __ LDX #$43
15d3 : 20 11 16 JSR $1611 ; (freg + 4)
15d6 : 20 3f 17 JSR $173f ; (crt_fmul + 0)
15d9 : 4c f4 15 JMP $15f4 ; (b_atof.s16 + 0)
.s21:
15dc : a5 43 __ LDA T0 + 0 
15de : 85 1b __ STA ACCU + 0 
15e0 : a5 44 __ LDA T0 + 1 
15e2 : 85 1c __ STA ACCU + 1 
15e4 : a5 45 __ LDA T0 + 2 
15e6 : 85 1d __ STA ACCU + 2 
15e8 : a5 46 __ LDA T0 + 3 
15ea : 85 1e __ STA ACCU + 3 
15ec : a2 47 __ LDX #$47
15ee : 20 11 16 JSR $1611 ; (freg + 4)
15f1 : 20 07 18 JSR $1807 ; (crt_fdiv + 0)
.s16:
15f4 : a5 4f __ LDA T4 + 0 
15f6 : d0 03 __ BNE $15fb ; (b_atof.s17 + 0)
15f8 : 4c 1d 15 JMP $151d ; (b_atof.s3 + 0)
.s17:
15fb : a5 1e __ LDA ACCU + 3 
15fd : 49 80 __ EOR #$80
15ff : 4c 1b 15 JMP $151b ; (b_atof.s42 + 0)
.s40:
1602 : e6 0d __ INC P0 ; (s + 0)
1604 : d0 02 __ BNE $1608 ; (b_atof.s45 + 0)
.s44:
1606 : e6 0e __ INC P1 ; (s + 1)
.s45:
1608 : e6 4f __ INC T4 + 0 
160a : 4c 5f 13 JMP $135f ; (b_atof.s9 + 0)
--------------------------------------------------------------------
freg: ; freg
160d : b1 19 __ LDA (IP + 0),y 
160f : c8 __ __ INY
1610 : aa __ __ TAX
1611 : b5 00 __ LDA $00,x 
1613 : 85 03 __ STA WORK + 0 
1615 : b5 01 __ LDA $01,x 
1617 : 85 04 __ STA WORK + 1 
1619 : b5 02 __ LDA $02,x 
161b : 85 05 __ STA WORK + 2 
161d : b5 03 __ LDA WORK + 0,x 
161f : 85 06 __ STA WORK + 3 
1621 : a5 05 __ LDA WORK + 2 
1623 : 0a __ __ ASL
1624 : a5 06 __ LDA WORK + 3 
1626 : 2a __ __ ROL
1627 : 85 08 __ STA WORK + 5 
1629 : f0 06 __ BEQ $1631 ; (freg + 36)
162b : a5 05 __ LDA WORK + 2 
162d : 09 80 __ ORA #$80
162f : 85 05 __ STA WORK + 2 
1631 : a5 1d __ LDA ACCU + 2 
1633 : 0a __ __ ASL
1634 : a5 1e __ LDA ACCU + 3 
1636 : 2a __ __ ROL
1637 : 85 07 __ STA WORK + 4 
1639 : f0 06 __ BEQ $1641 ; (freg + 52)
163b : a5 1d __ LDA ACCU + 2 
163d : 09 80 __ ORA #$80
163f : 85 1d __ STA ACCU + 2 
1641 : 60 __ __ RTS
1642 : 06 1e __ ASL ACCU + 3 
1644 : a5 07 __ LDA WORK + 4 
1646 : 6a __ __ ROR
1647 : 85 1e __ STA ACCU + 3 
1649 : b0 06 __ BCS $1651 ; (freg + 68)
164b : a5 1d __ LDA ACCU + 2 
164d : 29 7f __ AND #$7f
164f : 85 1d __ STA ACCU + 2 
1651 : 60 __ __ RTS
--------------------------------------------------------------------
faddsub: ; faddsub
1652 : a5 06 __ LDA WORK + 3 
1654 : 49 80 __ EOR #$80
1656 : 85 06 __ STA WORK + 3 
1658 : a9 ff __ LDA #$ff
165a : c5 07 __ CMP WORK + 4 
165c : f0 04 __ BEQ $1662 ; (faddsub + 16)
165e : c5 08 __ CMP WORK + 5 
1660 : d0 11 __ BNE $1673 ; (faddsub + 33)
1662 : a5 1e __ LDA ACCU + 3 
1664 : 09 7f __ ORA #$7f
1666 : 85 1e __ STA ACCU + 3 
1668 : a9 80 __ LDA #$80
166a : 85 1d __ STA ACCU + 2 
166c : a9 00 __ LDA #$00
166e : 85 1b __ STA ACCU + 0 
1670 : 85 1c __ STA ACCU + 1 
1672 : 60 __ __ RTS
1673 : 38 __ __ SEC
1674 : a5 07 __ LDA WORK + 4 
1676 : e5 08 __ SBC WORK + 5 
1678 : f0 38 __ BEQ $16b2 ; (faddsub + 96)
167a : aa __ __ TAX
167b : b0 25 __ BCS $16a2 ; (faddsub + 80)
167d : e0 e9 __ CPX #$e9
167f : b0 0e __ BCS $168f ; (faddsub + 61)
1681 : a5 08 __ LDA WORK + 5 
1683 : 85 07 __ STA WORK + 4 
1685 : a9 00 __ LDA #$00
1687 : 85 1b __ STA ACCU + 0 
1689 : 85 1c __ STA ACCU + 1 
168b : 85 1d __ STA ACCU + 2 
168d : f0 23 __ BEQ $16b2 ; (faddsub + 96)
168f : a5 1d __ LDA ACCU + 2 
1691 : 4a __ __ LSR
1692 : 66 1c __ ROR ACCU + 1 
1694 : 66 1b __ ROR ACCU + 0 
1696 : e8 __ __ INX
1697 : d0 f8 __ BNE $1691 ; (faddsub + 63)
1699 : 85 1d __ STA ACCU + 2 
169b : a5 08 __ LDA WORK + 5 
169d : 85 07 __ STA WORK + 4 
169f : 4c b2 16 JMP $16b2 ; (faddsub + 96)
16a2 : e0 18 __ CPX #$18
16a4 : b0 33 __ BCS $16d9 ; (faddsub + 135)
16a6 : a5 05 __ LDA WORK + 2 
16a8 : 4a __ __ LSR
16a9 : 66 04 __ ROR WORK + 1 
16ab : 66 03 __ ROR WORK + 0 
16ad : ca __ __ DEX
16ae : d0 f8 __ BNE $16a8 ; (faddsub + 86)
16b0 : 85 05 __ STA WORK + 2 
16b2 : a5 1e __ LDA ACCU + 3 
16b4 : 29 80 __ AND #$80
16b6 : 85 1e __ STA ACCU + 3 
16b8 : 45 06 __ EOR WORK + 3 
16ba : 30 31 __ BMI $16ed ; (faddsub + 155)
16bc : 18 __ __ CLC
16bd : a5 1b __ LDA ACCU + 0 
16bf : 65 03 __ ADC WORK + 0 
16c1 : 85 1b __ STA ACCU + 0 
16c3 : a5 1c __ LDA ACCU + 1 
16c5 : 65 04 __ ADC WORK + 1 
16c7 : 85 1c __ STA ACCU + 1 
16c9 : a5 1d __ LDA ACCU + 2 
16cb : 65 05 __ ADC WORK + 2 
16cd : 85 1d __ STA ACCU + 2 
16cf : 90 08 __ BCC $16d9 ; (faddsub + 135)
16d1 : 66 1d __ ROR ACCU + 2 
16d3 : 66 1c __ ROR ACCU + 1 
16d5 : 66 1b __ ROR ACCU + 0 
16d7 : e6 07 __ INC WORK + 4 
16d9 : a5 07 __ LDA WORK + 4 
16db : c9 ff __ CMP #$ff
16dd : f0 83 __ BEQ $1662 ; (faddsub + 16)
16df : 4a __ __ LSR
16e0 : 05 1e __ ORA ACCU + 3 
16e2 : 85 1e __ STA ACCU + 3 
16e4 : b0 06 __ BCS $16ec ; (faddsub + 154)
16e6 : a5 1d __ LDA ACCU + 2 
16e8 : 29 7f __ AND #$7f
16ea : 85 1d __ STA ACCU + 2 
16ec : 60 __ __ RTS
16ed : 38 __ __ SEC
16ee : a5 1b __ LDA ACCU + 0 
16f0 : e5 03 __ SBC WORK + 0 
16f2 : 85 1b __ STA ACCU + 0 
16f4 : a5 1c __ LDA ACCU + 1 
16f6 : e5 04 __ SBC WORK + 1 
16f8 : 85 1c __ STA ACCU + 1 
16fa : a5 1d __ LDA ACCU + 2 
16fc : e5 05 __ SBC WORK + 2 
16fe : 85 1d __ STA ACCU + 2 
1700 : b0 19 __ BCS $171b ; (faddsub + 201)
1702 : 38 __ __ SEC
1703 : a9 00 __ LDA #$00
1705 : e5 1b __ SBC ACCU + 0 
1707 : 85 1b __ STA ACCU + 0 
1709 : a9 00 __ LDA #$00
170b : e5 1c __ SBC ACCU + 1 
170d : 85 1c __ STA ACCU + 1 
170f : a9 00 __ LDA #$00
1711 : e5 1d __ SBC ACCU + 2 
1713 : 85 1d __ STA ACCU + 2 
1715 : a5 1e __ LDA ACCU + 3 
1717 : 49 80 __ EOR #$80
1719 : 85 1e __ STA ACCU + 3 
171b : a5 1d __ LDA ACCU + 2 
171d : 30 ba __ BMI $16d9 ; (faddsub + 135)
171f : 05 1c __ ORA ACCU + 1 
1721 : 05 1b __ ORA ACCU + 0 
1723 : f0 0f __ BEQ $1734 ; (faddsub + 226)
1725 : c6 07 __ DEC WORK + 4 
1727 : f0 0b __ BEQ $1734 ; (faddsub + 226)
1729 : 06 1b __ ASL ACCU + 0 
172b : 26 1c __ ROL ACCU + 1 
172d : 26 1d __ ROL ACCU + 2 
172f : 10 f4 __ BPL $1725 ; (faddsub + 211)
1731 : 4c d9 16 JMP $16d9 ; (faddsub + 135)
1734 : a9 00 __ LDA #$00
1736 : 85 1b __ STA ACCU + 0 
1738 : 85 1c __ STA ACCU + 1 
173a : 85 1d __ STA ACCU + 2 
173c : 85 1e __ STA ACCU + 3 
173e : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
173f : a5 1b __ LDA ACCU + 0 
1741 : 05 1c __ ORA ACCU + 1 
1743 : 05 1d __ ORA ACCU + 2 
1745 : f0 0e __ BEQ $1755 ; (crt_fmul + 22)
1747 : a5 03 __ LDA WORK + 0 
1749 : 05 04 __ ORA WORK + 1 
174b : 05 05 __ ORA WORK + 2 
174d : d0 09 __ BNE $1758 ; (crt_fmul + 25)
174f : 85 1b __ STA ACCU + 0 
1751 : 85 1c __ STA ACCU + 1 
1753 : 85 1d __ STA ACCU + 2 
1755 : 85 1e __ STA ACCU + 3 
1757 : 60 __ __ RTS
1758 : a5 1e __ LDA ACCU + 3 
175a : 45 06 __ EOR WORK + 3 
175c : 29 80 __ AND #$80
175e : 85 1e __ STA ACCU + 3 
1760 : a9 ff __ LDA #$ff
1762 : c5 07 __ CMP WORK + 4 
1764 : f0 42 __ BEQ $17a8 ; (crt_fmul + 105)
1766 : c5 08 __ CMP WORK + 5 
1768 : f0 3e __ BEQ $17a8 ; (crt_fmul + 105)
176a : a9 00 __ LDA #$00
176c : 85 09 __ STA WORK + 6 
176e : 85 0a __ STA WORK + 7 
1770 : 85 0b __ STA WORK + 8 
1772 : a4 1b __ LDY ACCU + 0 
1774 : a5 03 __ LDA WORK + 0 
1776 : d0 06 __ BNE $177e ; (crt_fmul + 63)
1778 : a5 04 __ LDA WORK + 1 
177a : f0 0a __ BEQ $1786 ; (crt_fmul + 71)
177c : d0 05 __ BNE $1783 ; (crt_fmul + 68)
177e : 20 d9 17 JSR $17d9 ; (crt_fmul8 + 0)
1781 : a5 04 __ LDA WORK + 1 
1783 : 20 d9 17 JSR $17d9 ; (crt_fmul8 + 0)
1786 : a5 05 __ LDA WORK + 2 
1788 : 20 d9 17 JSR $17d9 ; (crt_fmul8 + 0)
178b : 38 __ __ SEC
178c : a5 0b __ LDA WORK + 8 
178e : 30 06 __ BMI $1796 ; (crt_fmul + 87)
1790 : 06 09 __ ASL WORK + 6 
1792 : 26 0a __ ROL WORK + 7 
1794 : 2a __ __ ROL
1795 : 18 __ __ CLC
1796 : 29 7f __ AND #$7f
1798 : 85 0b __ STA WORK + 8 
179a : a5 07 __ LDA WORK + 4 
179c : 65 08 __ ADC WORK + 5 
179e : 90 19 __ BCC $17b9 ; (crt_fmul + 122)
17a0 : e9 7f __ SBC #$7f
17a2 : b0 04 __ BCS $17a8 ; (crt_fmul + 105)
17a4 : c9 ff __ CMP #$ff
17a6 : d0 15 __ BNE $17bd ; (crt_fmul + 126)
17a8 : a5 1e __ LDA ACCU + 3 
17aa : 09 7f __ ORA #$7f
17ac : 85 1e __ STA ACCU + 3 
17ae : a9 80 __ LDA #$80
17b0 : 85 1d __ STA ACCU + 2 
17b2 : a9 00 __ LDA #$00
17b4 : 85 1b __ STA ACCU + 0 
17b6 : 85 1c __ STA ACCU + 1 
17b8 : 60 __ __ RTS
17b9 : e9 7e __ SBC #$7e
17bb : 90 15 __ BCC $17d2 ; (crt_fmul + 147)
17bd : 4a __ __ LSR
17be : 05 1e __ ORA ACCU + 3 
17c0 : 85 1e __ STA ACCU + 3 
17c2 : a9 00 __ LDA #$00
17c4 : 6a __ __ ROR
17c5 : 05 0b __ ORA WORK + 8 
17c7 : 85 1d __ STA ACCU + 2 
17c9 : a5 0a __ LDA WORK + 7 
17cb : 85 1c __ STA ACCU + 1 
17cd : a5 09 __ LDA WORK + 6 
17cf : 85 1b __ STA ACCU + 0 
17d1 : 60 __ __ RTS
17d2 : a9 00 __ LDA #$00
17d4 : 85 1e __ STA ACCU + 3 
17d6 : f0 d8 __ BEQ $17b0 ; (crt_fmul + 113)
17d8 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
17d9 : 38 __ __ SEC
17da : 6a __ __ ROR
17db : 90 1e __ BCC $17fb ; (crt_fmul8 + 34)
17dd : aa __ __ TAX
17de : 18 __ __ CLC
17df : 98 __ __ TYA
17e0 : 65 09 __ ADC WORK + 6 
17e2 : 85 09 __ STA WORK + 6 
17e4 : a5 0a __ LDA WORK + 7 
17e6 : 65 1c __ ADC ACCU + 1 
17e8 : 85 0a __ STA WORK + 7 
17ea : a5 0b __ LDA WORK + 8 
17ec : 65 1d __ ADC ACCU + 2 
17ee : 6a __ __ ROR
17ef : 85 0b __ STA WORK + 8 
17f1 : 8a __ __ TXA
17f2 : 66 0a __ ROR WORK + 7 
17f4 : 66 09 __ ROR WORK + 6 
17f6 : 4a __ __ LSR
17f7 : f0 0d __ BEQ $1806 ; (crt_fmul8 + 45)
17f9 : b0 e2 __ BCS $17dd ; (crt_fmul8 + 4)
17fb : 66 0b __ ROR WORK + 8 
17fd : 66 0a __ ROR WORK + 7 
17ff : 66 09 __ ROR WORK + 6 
1801 : 4a __ __ LSR
1802 : 90 f7 __ BCC $17fb ; (crt_fmul8 + 34)
1804 : d0 d7 __ BNE $17dd ; (crt_fmul8 + 4)
1806 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
1807 : a5 1b __ LDA ACCU + 0 
1809 : 05 1c __ ORA ACCU + 1 
180b : 05 1d __ ORA ACCU + 2 
180d : d0 03 __ BNE $1812 ; (crt_fdiv + 11)
180f : 85 1e __ STA ACCU + 3 
1811 : 60 __ __ RTS
1812 : a5 1e __ LDA ACCU + 3 
1814 : 45 06 __ EOR WORK + 3 
1816 : 29 80 __ AND #$80
1818 : 85 1e __ STA ACCU + 3 
181a : a5 08 __ LDA WORK + 5 
181c : f0 62 __ BEQ $1880 ; (crt_fdiv + 121)
181e : a5 07 __ LDA WORK + 4 
1820 : c9 ff __ CMP #$ff
1822 : f0 5c __ BEQ $1880 ; (crt_fdiv + 121)
1824 : a9 00 __ LDA #$00
1826 : 85 09 __ STA WORK + 6 
1828 : 85 0a __ STA WORK + 7 
182a : 85 0b __ STA WORK + 8 
182c : a2 18 __ LDX #$18
182e : a5 1b __ LDA ACCU + 0 
1830 : c5 03 __ CMP WORK + 0 
1832 : a5 1c __ LDA ACCU + 1 
1834 : e5 04 __ SBC WORK + 1 
1836 : a5 1d __ LDA ACCU + 2 
1838 : e5 05 __ SBC WORK + 2 
183a : 90 13 __ BCC $184f ; (crt_fdiv + 72)
183c : a5 1b __ LDA ACCU + 0 
183e : e5 03 __ SBC WORK + 0 
1840 : 85 1b __ STA ACCU + 0 
1842 : a5 1c __ LDA ACCU + 1 
1844 : e5 04 __ SBC WORK + 1 
1846 : 85 1c __ STA ACCU + 1 
1848 : a5 1d __ LDA ACCU + 2 
184a : e5 05 __ SBC WORK + 2 
184c : 85 1d __ STA ACCU + 2 
184e : 38 __ __ SEC
184f : 26 09 __ ROL WORK + 6 
1851 : 26 0a __ ROL WORK + 7 
1853 : 26 0b __ ROL WORK + 8 
1855 : ca __ __ DEX
1856 : f0 0a __ BEQ $1862 ; (crt_fdiv + 91)
1858 : 06 1b __ ASL ACCU + 0 
185a : 26 1c __ ROL ACCU + 1 
185c : 26 1d __ ROL ACCU + 2 
185e : b0 dc __ BCS $183c ; (crt_fdiv + 53)
1860 : 90 cc __ BCC $182e ; (crt_fdiv + 39)
1862 : 38 __ __ SEC
1863 : a5 0b __ LDA WORK + 8 
1865 : 30 06 __ BMI $186d ; (crt_fdiv + 102)
1867 : 06 09 __ ASL WORK + 6 
1869 : 26 0a __ ROL WORK + 7 
186b : 2a __ __ ROL
186c : 18 __ __ CLC
186d : 29 7f __ AND #$7f
186f : 85 0b __ STA WORK + 8 
1871 : a5 07 __ LDA WORK + 4 
1873 : e5 08 __ SBC WORK + 5 
1875 : 90 1a __ BCC $1891 ; (crt_fdiv + 138)
1877 : 18 __ __ CLC
1878 : 69 7f __ ADC #$7f
187a : b0 04 __ BCS $1880 ; (crt_fdiv + 121)
187c : c9 ff __ CMP #$ff
187e : d0 15 __ BNE $1895 ; (crt_fdiv + 142)
1880 : a5 1e __ LDA ACCU + 3 
1882 : 09 7f __ ORA #$7f
1884 : 85 1e __ STA ACCU + 3 
1886 : a9 80 __ LDA #$80
1888 : 85 1d __ STA ACCU + 2 
188a : a9 00 __ LDA #$00
188c : 85 1c __ STA ACCU + 1 
188e : 85 1b __ STA ACCU + 0 
1890 : 60 __ __ RTS
1891 : 69 7f __ ADC #$7f
1893 : 90 15 __ BCC $18aa ; (crt_fdiv + 163)
1895 : 4a __ __ LSR
1896 : 05 1e __ ORA ACCU + 3 
1898 : 85 1e __ STA ACCU + 3 
189a : a9 00 __ LDA #$00
189c : 6a __ __ ROR
189d : 05 0b __ ORA WORK + 8 
189f : 85 1d __ STA ACCU + 2 
18a1 : a5 0a __ LDA WORK + 7 
18a3 : 85 1c __ STA ACCU + 1 
18a5 : a5 09 __ LDA WORK + 6 
18a7 : 85 1b __ STA ACCU + 0 
18a9 : 60 __ __ RTS
18aa : a9 00 __ LDA #$00
18ac : 85 1e __ STA ACCU + 3 
18ae : 85 1d __ STA ACCU + 2 
18b0 : 85 1c __ STA ACCU + 1 
18b2 : 85 1b __ STA ACCU + 0 
18b4 : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
18b5 : a5 1e __ LDA ACCU + 3 
18b7 : 30 03 __ BMI $18bc ; (f32_to_i32 + 7)
18b9 : 4c d9 18 JMP $18d9 ; (f32_to_u32 + 0)
18bc : 20 d9 18 JSR $18d9 ; (f32_to_u32 + 0)
18bf : 38 __ __ SEC
18c0 : a9 00 __ LDA #$00
18c2 : e5 1b __ SBC ACCU + 0 
18c4 : 85 1b __ STA ACCU + 0 
18c6 : a9 00 __ LDA #$00
18c8 : e5 1c __ SBC ACCU + 1 
18ca : 85 1c __ STA ACCU + 1 
18cc : a9 00 __ LDA #$00
18ce : e5 1d __ SBC ACCU + 2 
18d0 : 85 1d __ STA ACCU + 2 
18d2 : a9 00 __ LDA #$00
18d4 : e5 1e __ SBC ACCU + 3 
18d6 : 85 1e __ STA ACCU + 3 
18d8 : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
18d9 : 20 31 16 JSR $1631 ; (freg + 36)
18dc : a5 07 __ LDA WORK + 4 
18de : c9 7f __ CMP #$7f
18e0 : b0 0b __ BCS $18ed ; (f32_to_u32 + 20)
18e2 : a9 00 __ LDA #$00
18e4 : 85 1b __ STA ACCU + 0 
18e6 : 85 1c __ STA ACCU + 1 
18e8 : 85 1d __ STA ACCU + 2 
18ea : 85 1e __ STA ACCU + 3 
18ec : 60 __ __ RTS
18ed : 38 __ __ SEC
18ee : e9 9e __ SBC #$9e
18f0 : f0 13 __ BEQ $1905 ; (f32_to_u32 + 44)
18f2 : 90 04 __ BCC $18f8 ; (f32_to_u32 + 31)
18f4 : a9 ff __ LDA #$ff
18f6 : d0 ec __ BNE $18e4 ; (f32_to_u32 + 11)
18f8 : aa __ __ TAX
18f9 : a9 00 __ LDA #$00
18fb : 46 1d __ LSR ACCU + 2 
18fd : 66 1c __ ROR ACCU + 1 
18ff : 66 1b __ ROR ACCU + 0 
1901 : 6a __ __ ROR
1902 : e8 __ __ INX
1903 : d0 f6 __ BNE $18fb ; (f32_to_u32 + 34)
1905 : a6 1d __ LDX ACCU + 2 
1907 : 86 1e __ STX ACCU + 3 
1909 : a6 1c __ LDX ACCU + 1 
190b : 86 1d __ STX ACCU + 2 
190d : a6 1b __ LDX ACCU + 0 
190f : 86 1c __ STX ACCU + 1 
1911 : 85 1b __ STA ACCU + 0 
1913 : 60 __ __ RTS
--------------------------------------------------------------------
uint16_to_float: ; uint16_to_float
1914 : a5 1b __ LDA ACCU + 0 
1916 : 05 1c __ ORA ACCU + 1 
1918 : d0 05 __ BNE $191f ; (uint16_to_float + 11)
191a : 85 1d __ STA ACCU + 2 
191c : 85 1e __ STA ACCU + 3 
191e : 60 __ __ RTS
191f : a2 8e __ LDX #$8e
1921 : a5 1c __ LDA ACCU + 1 
1923 : 30 06 __ BMI $192b ; (uint16_to_float + 23)
1925 : ca __ __ DEX
1926 : 06 1b __ ASL ACCU + 0 
1928 : 2a __ __ ROL
1929 : 10 fa __ BPL $1925 ; (uint16_to_float + 17)
192b : 0a __ __ ASL
192c : 85 1d __ STA ACCU + 2 
192e : a5 1b __ LDA ACCU + 0 
1930 : 85 1c __ STA ACCU + 1 
1932 : 8a __ __ TXA
1933 : 4a __ __ LSR
1934 : 85 1e __ STA ACCU + 3 
1936 : a9 00 __ LDA #$00
1938 : 85 1b __ STA ACCU + 0 
193a : 66 1d __ ROR ACCU + 2 
193c : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
193d : 24 1e __ BIT ACCU + 3 
193f : 30 03 __ BMI $1944 ; (sint32_to_float + 7)
1941 : 4c 67 19 JMP $1967 ; (uint32_to_float + 0)
1944 : 38 __ __ SEC
1945 : a9 00 __ LDA #$00
1947 : e5 1b __ SBC ACCU + 0 
1949 : 85 1b __ STA ACCU + 0 
194b : a9 00 __ LDA #$00
194d : e5 1c __ SBC ACCU + 1 
194f : 85 1c __ STA ACCU + 1 
1951 : a9 00 __ LDA #$00
1953 : e5 1d __ SBC ACCU + 2 
1955 : 85 1d __ STA ACCU + 2 
1957 : a9 00 __ LDA #$00
1959 : e5 1e __ SBC ACCU + 3 
195b : 85 1e __ STA ACCU + 3 
195d : 20 67 19 JSR $1967 ; (uint32_to_float + 0)
1960 : a5 1e __ LDA ACCU + 3 
1962 : 09 80 __ ORA #$80
1964 : 85 1e __ STA ACCU + 3 
1966 : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
1967 : a5 1b __ LDA ACCU + 0 
1969 : 05 1c __ ORA ACCU + 1 
196b : 05 1d __ ORA ACCU + 2 
196d : 05 1e __ ORA ACCU + 3 
196f : d0 01 __ BNE $1972 ; (uint32_to_float + 11)
1971 : 60 __ __ RTS
1972 : a2 9e __ LDX #$9e
1974 : a5 1e __ LDA ACCU + 3 
1976 : 30 0a __ BMI $1982 ; (uint32_to_float + 27)
1978 : ca __ __ DEX
1979 : 06 1b __ ASL ACCU + 0 
197b : 26 1c __ ROL ACCU + 1 
197d : 26 1d __ ROL ACCU + 2 
197f : 2a __ __ ROL
1980 : 10 f6 __ BPL $1978 ; (uint32_to_float + 17)
1982 : 24 1b __ BIT ACCU + 0 
1984 : 10 13 __ BPL $1999 ; (uint32_to_float + 50)
1986 : e6 1c __ INC ACCU + 1 
1988 : d0 0f __ BNE $1999 ; (uint32_to_float + 50)
198a : e6 1d __ INC ACCU + 2 
198c : d0 0b __ BNE $1999 ; (uint32_to_float + 50)
198e : 18 __ __ CLC
198f : 69 01 __ ADC #$01
1991 : 90 06 __ BCC $1999 ; (uint32_to_float + 50)
1993 : 4a __ __ LSR
1994 : 66 1d __ ROR ACCU + 2 
1996 : 66 1c __ ROR ACCU + 1 
1998 : e8 __ __ INX
1999 : 0a __ __ ASL
199a : a4 1c __ LDY ACCU + 1 
199c : 84 1b __ STY ACCU + 0 
199e : a4 1d __ LDY ACCU + 2 
19a0 : 84 1c __ STY ACCU + 1 
19a2 : 85 1d __ STA ACCU + 2 
19a4 : 8a __ __ TXA
19a5 : 4a __ __ LSR
19a6 : 85 1e __ STA ACCU + 3 
19a8 : 66 1d __ ROR ACCU + 2 
19aa : 60 __ __ RTS
--------------------------------------------------------------------
__multab16384H:
19ab : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
__multab14L:
19af : __ __ __ BYT 00 0e 1c 2a 38 46 54 62 70 7e                   : ...*8FTbp~
--------------------------------------------------------------------
spentry:
19b9 : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
b_mem:
19ba : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
19bc : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
19be : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
19c0 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_dataPtr:
19c2 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_data_len:
19c4 : __ __ __ BYT 0a 00                                           : ..
--------------------------------------------------------------------
tsb_drawtab:
19c6 : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_pi:
19ce : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_dxf:
19d0 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_dyf:
19d4 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_sai:
19d8 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_cai:
19dc : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_cif:
19e0 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_ji:
19e4 : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_crf:
19e6 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_ii:
19ea : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_zrf:
19ec : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_zif:
19f0 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_kf:
19f4 : __ __ __ BSS	4
--------------------------------------------------------------------
b_v_ci:
19f8 : __ __ __ BSS	2
--------------------------------------------------------------------
tab:
1a00 : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
1a10 : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
1a20 : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
1a30 : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
1a40 : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
1a50 : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
1a60 : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
1a70 : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
tsb_sintab:
1a80 : __ __ __ BSS	64
--------------------------------------------------------------------
b_data:
1b00 : __ __ __ BYT 01 00 00 00 00 00 08 cc 3e c3 00 00 00 00 01 00 : ........>.......
1b10 : __ __ __ BYT 00 00 00 00 d9 ce e6 41 00 00 00 00 01 00 00 00 : .......A........
1b20 : __ __ __ BYT 00 00 14 ae 87 42 00 00 00 00 01 00 00 00 00 00 : .....B..........
1b30 : __ __ __ BYT 42 60 65 bf 00 00 00 00 01 00 00 00 00 00 44 7b : B`e...........D{
1b40 : __ __ __ BYT e3 c3 00 00 00 00 01 00 00 00 00 00 6f 12 03 bf : ............o...
1b50 : __ __ __ BYT 00 00 00 00 01 00 00 00 00 00 00 00 a0 c3 00 00 : ................
1b60 : __ __ __ BYT 00 00 01 00 00 00 00 00 0a d7 a3 40 00 00 00 00 : ...........@....
1b70 : __ __ __ BYT 01 00 00 00 00 00 2f dd b5 c1 00 00 00 00 01 00 : ....../.........
1b80 : __ __ __ BYT 00 00 00 00 2b 87 26 43 00 00 00 00             : ....+.&C....
