; -- manzoo.bas
; C64 BASIC V2 -> 6502  |  2389 bytes PRG, 19 source lines
	* = $0801
	; entry  $0B86   (10 SYS -> code)
	; vars   $1100 .. $1156   (22 vars, 86 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$32,$39,$35,$30,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- float const pool ----

fconst0:
0813 :  .byte $90,$50,$20,$00,$00

fconst1:
0818 :  .byte $90,$50,$21,$00,$00

fconst2:
081D :  .byte $85,$1C,$00,$00,$00

fconst3:
0822 :  .byte $90,$58,$00,$00,$00

fconst4:
0827 :  .byte $80,$73,$33,$33,$33

fconst5:
082C :  .byte $79,$65,$60,$41,$89

fconst6:
0831 :  .byte $79,$00,$00,$00,$00

fconst7:
0836 :  .byte $85,$00,$00,$00,$00

fconst8:
083B :  .byte $85,$50,$00,$00,$00

fconst9:
0840 :  .byte $84,$40,$00,$00,$00

fconst10:
0845 :  .byte $00,$00,$00,$00,$00

fconst11:
084A :  .byte $8B,$00,$00,$00,$00

fconst12:
084F :  .byte $82,$00,$00,$00,$00

fconst13:
0854 :  .byte $81,$00,$00,$00,$00

fconst14:
0859 :  .byte $89,$00,$00,$00,$00

ftemp:
085E :  .res 10	; float temp slots
; ---- DATA pool ----

data_pool_addr:
0868 :  .byte $01,$88,$BE,$CC,$08,$31,$01,$85,$66,$CE,$D9,$17,$01,$87,$07,$AE	; DATA image
	.byte $14,$7B,$01,$80,$E5,$60,$41,$89,$01,$89,$E3,$7B,$43,$96,$01,$80
	.byte $83,$12,$6E,$98,$01,$89,$A0,$00,$00,$00,$01,$83,$23,$D7,$0A,$3D
	.byte $01,$85,$B5,$DD,$2F,$1B,$01,$88,$26,$87,$2B,$02
; ---- runtime helpers ----

RT_zero:
08A4 :  LDY #0 ; $00
08A6 :  LDX ZP_SCR16 + 1 ; $FE
08A8 :  BEQ .z_tail

.z_page:
08AA :  LDA #0 ; $00

.z_pl:
08AC :  STA (ZP_PTR),Y ; $FB
08AE :  INY
08AF :  BNE .z_pl
08B1 :  INC ZP_PTR + 1 ; $FC
08B3 :  DEX
08B4 :  BNE .z_page

.z_tail:

.z_tail:
08B6 :  LDX ZP_SCR16 ; $FD
08B8 :  BEQ .z_done_l

.z_tl:
08BA :  LDA #0 ; $00
08BC :  STA (ZP_PTR),Y ; $FB
08BE :  INY
08BF :  DEX
08C0 :  BNE .z_tl

.z_done_l:

.z_done_l:
08C2 :  RTS

RT_fmul_align:

RT_fmul:

RT_fadd:
0B6C :  JSR $BA8C
0B6F :  LDA $61
0B71 :  JMP RT_fmul_align ; $08C3

RT_fsub:
0B74 :  JSR $BA8C
0B77 :  LDA $66
0B79 :  EOR #$FF
0B7B :  STA $66
0B7D :  EOR $6E
0B7F :  STA $6F
0B81 :  LDA $61
0B83 :  JMP RT_fmul_align ; $08C3

; ---- zero variable area (bss excluded from PRG; runtime-init via RT_zero) ----
0B86 :  LDA #0 ; $00
0B88 :  STA ZP_PTR ; $FB
0B8A :  LDA #0 ; $00
0B8C :  STA ZP_PTR + 1 ; $FC
0B8E :  LDA #0 ; $00
0B90 :  STA ZP_SCR16 ; $FD
0B92 :  LDA #0 ; $00
0B94 :  STA ZP_SCR16 + 1 ; $FE
0B96 :  JSR RT_zero ; $08A4
; ---- DATPTR init ----
0B99 :  LDA #<addr ; $68
0B9B :  STA ZP_DATPTR ; $41
0B9D :  LDA #>addr ; $08
0B9F :  STA ZP_DATPTR + 1 ; $42
; ---- BASIC source ----
; 5     $0BA1  POKE 53280,0:POKE 53281,0:PRINT CHR$(147)
; 1,"manzoo.bas"

L5:
0BA1 :  LDA #(u8)s->e2->ival ; $00
0BA3 :  STA ; $D020
0BA6 :  LDA #(u8)s->e2->ival ; $00
0BA8 :  STA ; $D021
0BAB :  LDA #LO(e->ival) ; $93
0BAD :  LDX #LO((e->ival >> 8)) ; $00
0BAF :  JSR ROM_CHROUT ; $FFD2
0BB2 :  LDA #13 ; $0D
0BB4 :  JSR ROM_CHROUT ; $FFD2
; 6     $0BB7  RESTORE:P=0:READ CX:READ CY:DX=16:DY=26
; 2,"manzoo.bas"

L6:
0BB7 :  LDA #<addr ; $68
0BB9 :  STA ZP_DATPTR ; $41
0BBB :  LDA #>addr ; $08
0BBD :  STA ZP_DATPTR + 1 ; $42
0BBF :  LDA #clo ; $00
0BC1 :  STA P
0BC4 :  CLC
0BC5 :  LDA ZP_DATPTR ; $41
0BC7 :  ADC #1 ; $01
0BC9 :  STA ZP_DATPTR ; $41
0BCB :  LDA ZP_DATPTR + 1 ; $42
0BCD :  ADC #0 ; $00
0BCF :  STA ZP_DATPTR + 1 ; $42
0BD1 :  LDY #0 ; $00
0BD3 :  LDA (ZP_DATPTR),Y ; $41
0BD5 :  STA CX_F
0BD8 :  INY
0BD9 :  LDA (ZP_DATPTR),Y ; $41
0BDB :  STA CX_F+1
0BDE :  INY
0BDF :  LDA (ZP_DATPTR),Y ; $41
0BE1 :  STA CX_F+2
0BE4 :  INY
0BE5 :  LDA (ZP_DATPTR),Y ; $41
0BE7 :  STA CX_F+3
0BEA :  INY
0BEB :  LDA (ZP_DATPTR),Y ; $41
0BED :  STA CX_F+4
0BF0 :  INY
0BF1 :  CLC
0BF2 :  LDA ZP_DATPTR ; $41
0BF4 :  ADC #5 ; $05
0BF6 :  STA ZP_DATPTR ; $41
0BF8 :  LDA ZP_DATPTR + 1 ; $42
0BFA :  ADC #0 ; $00
0BFC :  STA ZP_DATPTR + 1 ; $42
0BFE :  CLC
0BFF :  LDA ZP_DATPTR ; $41
0C01 :  ADC #1 ; $01
0C03 :  STA ZP_DATPTR ; $41
0C05 :  LDA ZP_DATPTR + 1 ; $42
0C07 :  ADC #0 ; $00
0C09 :  STA ZP_DATPTR + 1 ; $42
0C0B :  LDY #0 ; $00
0C0D :  LDA (ZP_DATPTR),Y ; $41
0C0F :  STA CY_F
0C12 :  INY
0C13 :  LDA (ZP_DATPTR),Y ; $41
0C15 :  STA CY_F+1
0C18 :  INY
0C19 :  LDA (ZP_DATPTR),Y ; $41
0C1B :  STA CY_F+2
0C1E :  INY
0C1F :  LDA (ZP_DATPTR),Y ; $41
0C21 :  STA CY_F+3
0C24 :  INY
0C25 :  LDA (ZP_DATPTR),Y ; $41
0C27 :  STA CY_F+4
0C2A :  INY
0C2B :  CLC
0C2C :  LDA ZP_DATPTR ; $41
0C2E :  ADC #5 ; $05
0C30 :  STA ZP_DATPTR ; $41
0C32 :  LDA ZP_DATPTR + 1 ; $42
0C34 :  ADC #0 ; $00
0C36 :  STA ZP_DATPTR + 1 ; $42
0C38 :  LDA #<addr ; $36
0C3A :  LDY #>addr ; $08
0C3C :  JSR ROM_MEM_FAC ; $BBA2
0C3F :  LDX #<DX_F
0C41 :  LDY #>DX_F+1
0C43 :  JSR ROM_FAC_MEM ; $BBD4
0C46 :  LDA #<addr ; $3B
0C48 :  LDY #>addr ; $08
0C4A :  JSR ROM_MEM_FAC ; $BBA2
0C4D :  LDX #<DY_F
0C4F :  LDY #>DY_F+1
0C51 :  JSR ROM_FAC_MEM ; $BBD4
; 10    $0C54  XR=CX-19.5*DX:YI=CY-12*DY
; 3,"manzoo.bas"

L10:
0C54 :  LDA #<CX_F
0C56 :  LDY #>CX_F+1
0C58 :  JSR ROM_MEM_FAC ; $BBA2
0C5B :  LDX #<addr ; $5E
0C5D :  LDY #>addr ; $08
0C5F :  JSR ROM_FAC_MEM ; $BBD4
0C62 :  LDA #<addr ; $1D
0C64 :  LDY #>addr ; $08
0C66 :  JSR ROM_MEM_FAC ; $BBA2
0C69 :  LDX #<addr ; $63
0C6B :  LDY #>addr ; $08
0C6D :  JSR ROM_FAC_MEM ; $BBD4
0C70 :  LDA #<DX_F
0C72 :  LDY #>DX_F+1
0C74 :  JSR ROM_MEM_FAC ; $BBA2
0C77 :  LDA #<addr ; $63
0C79 :  LDY #>addr ; $08
0C7B :  JSR ROM_MEM_ARG ; $BA8C
0C7E :  LDA FACEXP ; $61
0C80 :  LDA #<addr ; $63
0C82 :  LDY #>addr ; $08
0C84 :  JSR RT_fmul ; $0A40
0C87 :  LDA #<addr ; $5E
0C89 :  LDY #>addr ; $08
0C8B :  JSR ROM_MEM_ARG ; $BA8C
0C8E :  LDA FACEXP ; $61
0C90 :  LDA #<addr ; $5E
0C92 :  LDY #>addr ; $08
0C94 :  JSR ROM_MINUS ; $B850
0C97 :  LDX #<XR_F
0C99 :  LDY #>XR_F+1
0C9B :  JSR ROM_FAC_MEM ; $BBD4
0C9E :  LDA #<CY_F
0CA0 :  LDY #>CY_F+1
0CA2 :  JSR ROM_MEM_FAC ; $BBA2
0CA5 :  LDX #<addr ; $5E
0CA7 :  LDY #>addr ; $08
0CA9 :  JSR ROM_FAC_MEM ; $BBD4
0CAC :  LDA #<addr ; $40
0CAE :  LDY #>addr ; $08
0CB0 :  JSR ROM_MEM_FAC ; $BBA2
0CB3 :  LDX #<addr ; $63
0CB5 :  LDY #>addr ; $08
0CB7 :  JSR ROM_FAC_MEM ; $BBD4
0CBA :  LDA #<DY_F
0CBC :  LDY #>DY_F+1
0CBE :  JSR ROM_MEM_FAC ; $BBA2
0CC1 :  LDA #<addr ; $63
0CC3 :  LDY #>addr ; $08
0CC5 :  JSR ROM_MEM_ARG ; $BA8C
0CC8 :  LDA FACEXP ; $61
0CCA :  LDA #<addr ; $63
0CCC :  LDY #>addr ; $08
0CCE :  JSR RT_fmul ; $0A40
0CD1 :  LDA #<addr ; $5E
0CD3 :  LDY #>addr ; $08
0CD5 :  JSR ROM_MEM_ARG ; $BA8C
0CD8 :  LDA FACEXP ; $61
0CDA :  LDA #<addr ; $5E
0CDC :  LDY #>addr ; $08
0CDE :  JSR ROM_MINUS ; $B850
0CE1 :  LDX #<YI_F
0CE3 :  LDY #>YI_F+1
0CE5 :  JSR ROM_FAC_MEM ; $BBD4
; 20    $0CE8  SA=1024:CA=55296
; 4,"manzoo.bas"

L20:
0CE8 :  LDA #LO(e->ival) ; $00
0CEA :  LDX #LO((e->ival >> 8)) ; $04
0CEC :  STA SA
0CEF :  STX SA+1
0CF2 :  LDA #LO(K) ; $00
0CF4 :  LDX #HI(K) ; $D8
0CF6 :  STA CA
0CF9 :  STX CA+1
; 30    $0CFC  CI=YI:FOR J=0 TO 24
; 5,"manzoo.bas"

L30:
0CFC :  LDA #<YI_F
0CFE :  LDY #>YI_F+1
0D00 :  JSR ROM_MEM_FAC ; $BBA2
0D03 :  LDX #<CI_F
0D05 :  LDY #>CI_F+1
0D07 :  JSR ROM_FAC_MEM ; $BBD4
0D0A :  LDA #LO(e->ival) ; $00
0D0C :  LDX #LO((e->ival >> 8)) ; $00
0D0E :  STA J
0D11 :  STX J+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 40    $0D14  CR=XR:FOR I=0 TO 39
; 6,"manzoo.bas"

L40:
0D14 :  LDA #<XR_F
0D16 :  LDY #>XR_F+1
0D18 :  JSR ROM_MEM_FAC ; $BBA2
0D1B :  LDX #<CR_F
0D1D :  LDY #>CR_F+1
0D1F :  JSR ROM_FAC_MEM ; $BBD4
0D22 :  LDA #LO(e->ival) ; $00
0D24 :  LDX #LO((e->ival >> 8)) ; $00
0D26 :  STA I
0D29 :  STX I+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 50    $0D2C  ZR=0:ZI=0:K=0
; 7,"manzoo.bas"

L50:
0D2C :  LDA #<addr ; $45
0D2E :  LDY #>addr ; $08
0D30 :  JSR ROM_MEM_FAC ; $BBA2
0D33 :  LDX #<ZR_F
0D35 :  LDY #>ZR_F+1
0D37 :  JSR ROM_FAC_MEM ; $BBD4
0D3A :  LDA #<addr ; $45
0D3C :  LDY #>addr ; $08
0D3E :  JSR ROM_MEM_FAC ; $BBA2
0D41 :  LDX #<ZI_F
0D43 :  LDY #>ZI_F+1
0D45 :  JSR ROM_FAC_MEM ; $BBD4
0D48 :  LDA #<addr ; $45
0D4A :  LDY #>addr ; $08
0D4C :  JSR ROM_MEM_FAC ; $BBA2
0D4F :  LDX #<K_F
0D51 :  LDY #>K_F+1
0D53 :  JSR ROM_FAC_MEM ; $BBD4
; 60    $0D56  RR=ZR*ZR/256:II=ZI*ZI/256:IF RR+II>1024 THEN 100
; 8,"manzoo.bas"

L60:
0D56 :  LDA #<ZR_F
0D58 :  LDY #>ZR_F+1
0D5A :  JSR ROM_MEM_FAC ; $BBA2
0D5D :  LDA #<ZR_F
0D5F :  LDY #>ZR_F+1
0D61 :  JSR RT_fmul ; $0A40
; opt: pow2scale (float *2^k -> FAC exp += k)
0D64 :  SEC
0D65 :  LDA FACEXP ; $61
0D67 :  SBC #n ; $08
0D69 :  BCS .pow2s_ok
0D6B :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0D6D :  STA FACEXP ; $61
0D6F :  LDX #<RR_F
0D71 :  LDY #>RR_F+1
0D73 :  JSR ROM_FAC_MEM ; $BBD4
0D76 :  LDA #<ZI_F
0D78 :  LDY #>ZI_F+1
0D7A :  JSR ROM_MEM_FAC ; $BBA2
0D7D :  LDA #<ZI_F
0D7F :  LDY #>ZI_F+1
0D81 :  JSR RT_fmul ; $0A40
; opt: pow2scale (float *2^k -> FAC exp += k)
0D84 :  SEC
0D85 :  LDA FACEXP ; $61
0D87 :  SBC #n ; $08
0D89 :  BCS .pow2s_ok
0D8B :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0D8D :  STA FACEXP ; $61
0D8F :  LDX #<II_F
0D91 :  LDY #>II_F+1
0D93 :  JSR ROM_FAC_MEM ; $BBD4
0D96 :  LDA #<II_F
0D98 :  LDY #>II_F+1
0D9A :  JSR ROM_MEM_FAC ; $BBA2
0D9D :  LDA #<RR_F
0D9F :  LDY #>RR_F+1
0DA1 :  JSR RT_fadd ; $0B6C
0DA4 :  LDA #<addr ; $4A
0DA6 :  LDY #>addr ; $08
0DA8 :  JSR ROM_FCOMP ; $BC5B
0DAB :  BMI .false
0DAD :  BEQ .false
0DAF :  LDA #0xFF ; $FF
0DB1 :  BNE .cmp_tail
0DB3 :  LDA #0x00 ; $00

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0DB5 :  BEQ .if_skip
0DB7 :  JMP L100

.if_skip:
; 70    $0DBA  NZ=ZR*ZI*2/256
; 9,"manzoo.bas"

L70:
0DBA :  LDA #<ZI_F
0DBC :  LDY #>ZI_F+1
0DBE :  JSR ROM_MEM_FAC ; $BBA2
0DC1 :  LDA #<ZR_F
0DC3 :  LDY #>ZR_F+1
0DC5 :  JSR RT_fmul ; $0A40
; opt: pow2scale (float *2^k -> FAC exp += k)
0DC8 :  LDA FACEXP ; $61
0DCA :  BEQ .pow2s_done
0DCC :  CLC
0DCD :  ADC #k ; $01
0DCF :  STA FACEXP ; $61

.pow2s_done:

.pow2s_done:
; opt: pow2scale (float *2^k -> FAC exp += k)
0DD1 :  SEC
0DD2 :  LDA FACEXP ; $61
0DD4 :  SBC #n ; $08
0DD6 :  BCS .pow2s_ok
0DD8 :  LDA #0 ; $00

.pow2s_ok:

.pow2s_ok:
0DDA :  STA FACEXP ; $61
0DDC :  LDX #<NZ_F
0DDE :  LDY #>NZ_F+1
0DE0 :  JSR ROM_FAC_MEM ; $BBD4
; 80    $0DE3  ZI=NZ+CI:ZR=RR-II+CR:K=K+1:IF K<256 THEN 60
; 10,"manzoo.bas"

L80:
0DE3 :  LDA #<CI_F
0DE5 :  LDY #>CI_F+1
0DE7 :  JSR ROM_MEM_FAC ; $BBA2
0DEA :  LDA #<NZ_F
0DEC :  LDY #>NZ_F+1
0DEE :  JSR RT_fadd ; $0B6C
0DF1 :  LDX #<ZI_F
0DF3 :  LDY #>ZI_F+1
0DF5 :  JSR ROM_FAC_MEM ; $BBD4
0DF8 :  LDA #<II_F
0DFA :  LDY #>II_F+1
0DFC :  JSR ROM_MEM_FAC ; $BBA2
0DFF :  LDA #<RR_F
0E01 :  LDY #>RR_F+1
0E03 :  JSR RT_fsub ; $0B74
0E06 :  LDX #<addr ; $5E
0E08 :  LDY #>addr ; $08
0E0A :  JSR ROM_FAC_MEM ; $BBD4
0E0D :  LDA #<CR_F
0E0F :  LDY #>CR_F+1
0E11 :  JSR ROM_MEM_FAC ; $BBA2
0E14 :  LDA #<addr ; $5E
0E16 :  LDY #>addr ; $08
0E18 :  JSR ROM_MEM_ARG ; $BA8C
0E1B :  LDA FACEXP ; $61
0E1D :  JSR ROM_PLUS ; $B86A
0E20 :  LDX #<ZR_F
0E22 :  LDY #>ZR_F+1
0E24 :  JSR ROM_FAC_MEM ; $BBD4
0E27 :  LDA #<addr ; $54
0E29 :  LDY #>addr ; $08
0E2B :  JSR ROM_MEM_FAC ; $BBA2
0E2E :  LDA #<K_F
0E30 :  LDY #>K_F+1
0E32 :  JSR RT_fadd ; $0B6C
0E35 :  LDX #<K_F
0E37 :  LDY #>K_F+1
0E39 :  JSR ROM_FAC_MEM ; $BBD4
0E3C :  LDA #<K_F
0E3E :  LDY #>K_F+1
0E40 :  JSR ROM_MEM_FAC ; $BBA2
0E43 :  LDA #<addr ; $59
0E45 :  LDY #>addr ; $08
0E47 :  JSR ROM_FCOMP ; $BC5B
0E4A :  BMI .true
0E4C :  LDA #0x00 ; $00
0E4E :  BEQ .cmp_tail
0E50 :  LDA #0xFF ; $FF

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0E52 :  BEQ .if_skip
0E54 :  JMP L60

.if_skip:
; 90    $0E57  POKE SA,160:POKE CA,0:GOTO 120
; 11,"manzoo.bas"

L90:
0E57 :  LDA SA
0E5A :  LDX SA+1
0E5D :  STA ZP_PTR ; $FB
0E5F :  STX ZP_PTR + 1 ; $FC
0E61 :  LDA #(u8)s->e2->ival ; $A0
0E63 :  LDY #0 ; $00
0E65 :  STA (ZP_PTR),Y ; $FB
0E67 :  LDA CA
0E6A :  LDX CA+1
0E6D :  STA ZP_PTR ; $FB
0E6F :  STX ZP_PTR + 1 ; $FC
0E71 :  LDA #(u8)s->e2->ival ; $00
0E73 :  LDY #0 ; $00
0E75 :  STA (ZP_PTR),Y ; $FB
0E77 :  JMP L120

; 100   $0E7A  C=K AND 15:IF C=0 THEN C=6
; 12,"manzoo.bas"

L100:
0E7A :  LDA #<K_F
0E7C :  LDY #>K_F+1
0E7E :  JSR ROM_MEM_FAC ; $BBA2
0E81 :  JSR ROM_FAC_INT ; $BC9B
0E84 :  LDA FACMO3 ; $65
0E86 :  LDX FACMO2 ; $64
0E88 :  AND #imm ; $0F
0E8A :  STA C
0E8D :  BEQ +3 ; long IF-skip (body >127B)
0E8F :  JMP .if_skip

0E92 :  LDA #clo ; $06
0E94 :  STA C

.if_skip:
; 110   $0E97  POKE SA,160:POKE CA,C
; 13,"manzoo.bas"

L110:
0E97 :  LDA SA
0E9A :  LDX SA+1
0E9D :  STA ZP_PTR ; $FB
0E9F :  STX ZP_PTR + 1 ; $FC
0EA1 :  LDA #(u8)s->e2->ival ; $A0
0EA3 :  LDY #0 ; $00
0EA5 :  STA (ZP_PTR),Y ; $FB
0EA7 :  LDA CA
0EAA :  LDX CA+1
0EAD :  STA ZP_PTR ; $FB
0EAF :  STX ZP_PTR + 1 ; $FC
0EB1 :  LDA C
0EB4 :  LDY #0 ; $00
0EB6 :  STA (ZP_PTR),Y ; $FB
; 120   $0EB8  CR=CR+DX:SA=SA+1:CA=CA+1:NEXT
; 14,"manzoo.bas"

L120:
0EB8 :  LDA #<DX_F
0EBA :  LDY #>DX_F+1
0EBC :  JSR ROM_MEM_FAC ; $BBA2
0EBF :  LDA #<CR_F
0EC1 :  LDY #>CR_F+1
0EC3 :  JSR RT_fadd ; $0B6C
0EC6 :  LDX #<CR_F
0EC8 :  LDY #>CR_F+1
0ECA :  JSR ROM_FAC_MEM ; $BBD4
0ECD :  INC SA
0ED0 :  BNE .pm1_skip
0ED2 :  INC SA+1

.pm1_skip:
0ED5 :  INC CA
0ED8 :  BNE .pm1_skip
0EDA :  INC CA+1

.pm1_skip:
0EDD :  INC I
0EE0 :  LDA I
0EE3 :  CMP #L->lim_lo ; $27
0EE5 :  BEQ .nxt_back
0EE7 :  BCS .nxt_done

.nxt_back:
0EE9 :  JMP .for_body ; $0D2C

.nxt_done:
; 130   $0EEC  CI=CI+DY:NEXT
; 15,"manzoo.bas"

L130:
0EEC :  LDA #<DY_F
0EEE :  LDY #>DY_F+1
0EF0 :  JSR ROM_MEM_FAC ; $BBA2
0EF3 :  LDA #<CI_F
0EF5 :  LDY #>CI_F+1
0EF7 :  JSR RT_fadd ; $0B6C
0EFA :  LDX #<CI_F
0EFC :  LDY #>CI_F+1
0EFE :  JSR ROM_FAC_MEM ; $BBD4
0F01 :  INC J
0F04 :  LDA J
0F07 :  CMP #L->lim_lo ; $18
0F09 :  BEQ .nxt_back
0F0B :  BCS .nxt_done

.nxt_back:
0F0D :  JMP .for_body ; $0D14

.nxt_done:
; 135   $0F10  DX=DX*0.95:DY=DY*0.95:IF DX>0.007 THEN 10
; 16,"manzoo.bas"

L135:
0F10 :  LDA #<addr ; $27
0F12 :  LDY #>addr ; $08
0F14 :  JSR ROM_MEM_FAC ; $BBA2
0F17 :  LDA #<DX_F
0F19 :  LDY #>DX_F+1
0F1B :  JSR RT_fmul ; $0A40
0F1E :  LDX #<DX_F
0F20 :  LDY #>DX_F+1
0F22 :  JSR ROM_FAC_MEM ; $BBD4
0F25 :  LDA #<addr ; $27
0F27 :  LDY #>addr ; $08
0F29 :  JSR ROM_MEM_FAC ; $BBA2
0F2C :  LDA #<DY_F
0F2E :  LDY #>DY_F+1
0F30 :  JSR RT_fmul ; $0A40
0F33 :  LDX #<DY_F
0F35 :  LDY #>DY_F+1
0F37 :  JSR ROM_FAC_MEM ; $BBD4
0F3A :  LDA #<DX_F
0F3C :  LDY #>DX_F+1
0F3E :  JSR ROM_MEM_FAC ; $BBA2
0F41 :  LDA #<addr ; $2C
0F43 :  LDY #>addr ; $08
0F45 :  JSR ROM_FCOMP ; $BC5B
0F48 :  BMI .false
0F4A :  BEQ .false
0F4C :  LDA #0xFF ; $FF
0F4E :  BNE .cmp_tail
0F50 :  LDA #0x00 ; $00

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0F52 :  BEQ .if_skip
0F54 :  JMP L10

.if_skip:
; 136   $0F57  P=P+1:IF P>4 THEN P=0:RESTORE
; 17,"manzoo.bas"

L136:
0F57 :  INC P
; opt: compare-narrow
0F5A :  LDA P
0F5D :  CMP #klo ; $04
0F5F :  BNE +3 ; long IF-skip (body >127B)
0F61 :  JMP .if_skip

0F64 :  BCS +3 ; long IF-skip (body >127B)
0F66 :  JMP .if_skip

0F69 :  LDA #clo ; $00
0F6B :  STA P
0F6E :  LDA #<addr ; $68
0F70 :  STA ZP_DATPTR ; $41
0F72 :  LDA #>addr ; $08
0F74 :  STA ZP_DATPTR + 1 ; $42

.if_skip:
; 137   $0F76  READ CX:READ CY:DX=16:DY=26:GOTO 10
; 18,"manzoo.bas"

L137:
0F76 :  CLC
0F77 :  LDA ZP_DATPTR ; $41
0F79 :  ADC #1 ; $01
0F7B :  STA ZP_DATPTR ; $41
0F7D :  LDA ZP_DATPTR + 1 ; $42
0F7F :  ADC #0 ; $00
0F81 :  STA ZP_DATPTR + 1 ; $42
0F83 :  LDY #0 ; $00
0F85 :  LDA (ZP_DATPTR),Y ; $41
0F87 :  STA CX_F
0F8A :  INY
0F8B :  LDA (ZP_DATPTR),Y ; $41
0F8D :  STA CX_F+1
0F90 :  INY
0F91 :  LDA (ZP_DATPTR),Y ; $41
0F93 :  STA CX_F+2
0F96 :  INY
0F97 :  LDA (ZP_DATPTR),Y ; $41
0F99 :  STA CX_F+3
0F9C :  INY
0F9D :  LDA (ZP_DATPTR),Y ; $41
0F9F :  STA CX_F+4
0FA2 :  INY
0FA3 :  CLC
0FA4 :  LDA ZP_DATPTR ; $41
0FA6 :  ADC #5 ; $05
0FA8 :  STA ZP_DATPTR ; $41
0FAA :  LDA ZP_DATPTR + 1 ; $42
0FAC :  ADC #0 ; $00
0FAE :  STA ZP_DATPTR + 1 ; $42
0FB0 :  CLC
0FB1 :  LDA ZP_DATPTR ; $41
0FB3 :  ADC #1 ; $01
0FB5 :  STA ZP_DATPTR ; $41
0FB7 :  LDA ZP_DATPTR + 1 ; $42
0FB9 :  ADC #0 ; $00
0FBB :  STA ZP_DATPTR + 1 ; $42
0FBD :  LDY #0 ; $00
0FBF :  LDA (ZP_DATPTR),Y ; $41
0FC1 :  STA CY_F
0FC4 :  INY
0FC5 :  LDA (ZP_DATPTR),Y ; $41
0FC7 :  STA CY_F+1
0FCA :  INY
0FCB :  LDA (ZP_DATPTR),Y ; $41
0FCD :  STA CY_F+2
0FD0 :  INY
0FD1 :  LDA (ZP_DATPTR),Y ; $41
0FD3 :  STA CY_F+3
0FD6 :  INY
0FD7 :  LDA (ZP_DATPTR),Y ; $41
0FD9 :  STA CY_F+4
0FDC :  INY
0FDD :  CLC
0FDE :  LDA ZP_DATPTR ; $41
0FE0 :  ADC #5 ; $05
0FE2 :  STA ZP_DATPTR ; $41
0FE4 :  LDA ZP_DATPTR + 1 ; $42
0FE6 :  ADC #0 ; $00
0FE8 :  STA ZP_DATPTR + 1 ; $42
0FEA :  LDA #<addr ; $36
0FEC :  LDY #>addr ; $08
0FEE :  JSR ROM_MEM_FAC ; $BBA2
0FF1 :  LDX #<DX_F
0FF3 :  LDY #>DX_F+1
0FF5 :  JSR ROM_FAC_MEM ; $BBD4
0FF8 :  LDA #<addr ; $3B
0FFA :  LDY #>addr ; $08
0FFC :  JSR ROM_MEM_FAC ; $BBA2
0FFF :  LDX #<DY_F
1001 :  LDY #>DY_F+1
1003 :  JSR ROM_FAC_MEM ; $BBD4
1006 :  JMP L10

; 138   $1009  DATA -190.797,28.851,67.84,-0.896,-454.963,-0.512,-320,5.12,-22.733,166.528
; 19,"manzoo.bas"

L138:
; halt
; ---- variables (zero-filled) ----
P = $1100
; P      $1100 (2 bytes)
CX_F = $1102
; CX     $1102 (5 bytes)
CY_F = $1107
; CY     $1107 (5 bytes)
DX_F = $110C
; DX     $110C (5 bytes)
DY_F = $1111
; DY     $1111 (5 bytes)
XR_F = $1116
; XR     $1116 (5 bytes)
YI_F = $111B
; YI     $111B (5 bytes)
SA = $1120
; SA     $1120 (2 bytes)
CA = $1122
; CA     $1122 (2 bytes)
CI_F = $1124
; CI     $1124 (5 bytes)
J = $1129
; J      $1129 (2 bytes)
CR_F = $112B
; CR     $112B (5 bytes)
I = $1130
; I      $1130 (2 bytes)
ZR_F = $1132
; ZR     $1132 (5 bytes)
ZI_F = $1137
; ZI     $1137 (5 bytes)
K_F = $113C
; K      $113C (5 bytes)
RR_F = $1141
; RR     $1141 (5 bytes)
II_F = $1146
; II     $1146 (5 bytes)
NZ_F = $114B
; NZ     $114B (5 bytes)
C = $1150
; C      $1150 (2 bytes)
LIMIT1 = $1152
; LIMIT1 $1152 (2 bytes)
LIMIT2 = $1154
; LIMIT2 $1154 (2 bytes)
1009 :  .res 333	; variable area
