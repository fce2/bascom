; Compiled with 1.32.271.0
--------------------------------------------------------------------
startup: ; startup
0801 : 0b __ __ INV
0802 : 08 __ __ PHP
0803 : 0a __ __ ASL
0804 : 00 __ __ BRK
0805 : 9e __ __ INV
0806 : 32 __ __ INV
0807 : 30 36 __ BMI $083f ; (startup + 62)
0809 : 31 00 __ AND ($00),y 
080b : 00 __ __ BRK
080c : 00 __ __ BRK
080d : ba __ __ TSX
080e : 8e 2f 23 STX $232f ; (spentry + 0)
0811 : a2 23 __ LDX #$23
0813 : a0 be __ LDY #$be
0815 : a9 00 __ LDA #$00
0817 : 85 19 __ STA IP + 0 
0819 : 86 1a __ STX IP + 1 
081b : e0 30 __ CPX #$30
081d : f0 0b __ BEQ $082a ; (startup + 41)
081f : 91 19 __ STA (IP + 0),y 
0821 : c8 __ __ INY
0822 : d0 fb __ BNE $081f ; (startup + 30)
0824 : e8 __ __ INX
0825 : d0 f2 __ BNE $0819 ; (startup + 24)
0827 : 91 19 __ STA (IP + 0),y 
0829 : c8 __ __ INY
082a : c0 12 __ CPY #$12
082c : d0 f9 __ BNE $0827 ; (startup + 38)
082e : a9 00 __ LDA #$00
0830 : a2 f7 __ LDX #$f7
0832 : d0 03 __ BNE $0837 ; (startup + 54)
0834 : 95 00 __ STA $00,x 
0836 : e8 __ __ INX
0837 : e0 f7 __ CPX #$f7
0839 : d0 f9 __ BNE $0834 ; (startup + 51)
083b : a9 9d __ LDA #$9d
083d : 85 23 __ STA SP + 0 
083f : a9 9f __ LDA #$9f
0841 : 85 24 __ STA SP + 1 
0843 : 20 80 08 JSR $0880 ; (main.s1 + 0)
0846 : a9 4c __ LDA #$4c
0848 : 85 54 __ STA $54 
084a : a9 00 __ LDA #$00
084c : 85 13 __ STA P6 
084e : a9 19 __ LDA #$19
0850 : 85 16 __ STA P9 
0852 : 60 __ __ RTS
--------------------------------------------------------------------
main: ; main()->i16
;  24, "C:/Users/g/claude/cpus/6502/examples/compiler/release/balls.c"
.s1:
0880 : a2 08 __ LDX #$08
0882 : b5 53 __ LDA T0 + 0,x 
0884 : 9d 9f 9f STA $9f9f,x ; (main@stack + 0)
0887 : ca __ __ DEX
0888 : 10 f8 __ BPL $0882 ; (main.s1 + 2)
.s4:
088a : 20 c7 13 JSR $13c7 ; (b_init.s4 + 0)
088d : 20 9e 14 JSR $149e ; (tsb_init.s4 + 0)
0890 : ad 30 23 LDA $2330 ; (b_mem + 0)
0893 : 85 51 __ STA T6 + 0 
0895 : 85 1f __ STA ADDR + 0 
0897 : a9 93 __ LDA #$93
0899 : 85 13 __ STA P6 
089b : a9 64 __ LDA #$64
089d : 8d fe 23 STA $23fe ; (b_v_ni + 0)
08a0 : ad 31 23 LDA $2331 ; (b_mem + 1)
08a3 : 85 52 __ STA T6 + 1 
08a5 : 18 __ __ CLC
08a6 : 69 d0 __ ADC #$d0
08a8 : 85 20 __ STA ADDR + 1 
08aa : a9 00 __ LDA #$00
08ac : 8d ff 23 STA $23ff ; (b_v_ni + 1)
08af : a0 20 __ LDY #$20
08b1 : 91 1f __ STA (ADDR + 0),y 
08b3 : c8 __ __ INY
08b4 : 91 1f __ STA (ADDR + 0),y 
08b6 : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
08b9 : a9 00 __ LDA #$00
08bb : 8d 09 24 STA $2409 ; (b_v_bi + 1)
08be : 8d 0a 24 STA $240a ; (b_v_bi + 2)
08c1 : 8d 0b 24 STA $240b ; (b_v_bi + 3)
08c4 : a9 01 __ LDA #$01
08c6 : 8d 08 24 STA $2408 ; (b_v_bi + 0)
.l5:
08c9 : ad ba 23 LDA $23ba ; (b_rndSeed + 0)
08cc : 85 1b __ STA ACCU + 0 
08ce : ad bb 23 LDA $23bb ; (b_rndSeed + 1)
08d1 : 85 1c __ STA ACCU + 1 
08d3 : ad bc 23 LDA $23bc ; (b_rndSeed + 2)
08d6 : 85 1d __ STA ACCU + 2 
08d8 : ad bd 23 LDA $23bd ; (b_rndSeed + 3)
08db : 85 1e __ STA ACCU + 3 
08dd : a9 cd __ LDA #$cd
08df : 85 03 __ STA WORK + 0 
08e1 : a9 00 __ LDA #$00
08e3 : 85 06 __ STA WORK + 3 
08e5 : a9 0d __ LDA #$0d
08e7 : 85 04 __ STA WORK + 1 
08e9 : a9 01 __ LDA #$01
08eb : 85 05 __ STA WORK + 2 
08ed : 20 5f 21 JSR $215f ; (mul32 + 0)
08f0 : 18 __ __ CLC
08f1 : a5 07 __ LDA WORK + 4 
08f3 : 69 39 __ ADC #$39
08f5 : 85 53 __ STA T0 + 0 
08f7 : a5 08 __ LDA WORK + 5 
08f9 : 69 30 __ ADC #$30
08fb : 85 54 __ STA T0 + 1 
08fd : 85 1b __ STA ACCU + 0 
08ff : a5 09 __ LDA WORK + 6 
0901 : 69 00 __ ADC #$00
0903 : 85 55 __ STA T0 + 2 
0905 : 85 1c __ STA ACCU + 1 
0907 : a5 0a __ LDA WORK + 7 
0909 : 69 00 __ ADC #$00
090b : 85 56 __ STA T0 + 3 
090d : 85 1d __ STA ACCU + 2 
090f : a9 00 __ LDA #$00
0911 : 85 1e __ STA ACCU + 3 
0913 : 20 cc 20 JSR $20cc ; (uint32_to_float + 0)
0916 : a9 00 __ LDA #$00
0918 : 85 03 __ STA WORK + 0 
091a : 85 04 __ STA WORK + 1 
091c : a9 80 __ LDA #$80
091e : 85 05 __ STA WORK + 2 
0920 : a9 4b __ LDA #$4b
0922 : 85 06 __ STA WORK + 3 
0924 : 20 4d 1c JSR $1c4d ; (freg + 20)
0927 : 20 33 1e JSR $1e33 ; (crt_fdiv + 0)
092a : a9 00 __ LDA #$00
092c : 85 03 __ STA WORK + 0 
092e : 85 04 __ STA WORK + 1 
0930 : a9 20 __ LDA #$20
0932 : 85 05 __ STA WORK + 2 
0934 : a9 42 __ LDA #$42
0936 : 85 06 __ STA WORK + 3 
0938 : 20 4d 1c JSR $1c4d ; (freg + 20)
093b : 20 6b 1d JSR $1d6b ; (crt_fmul + 0)
093e : a5 1b __ LDA ACCU + 0 
0940 : 85 57 __ STA T1 + 0 
0942 : a5 1c __ LDA ACCU + 1 
0944 : 85 58 __ STA T1 + 1 
0946 : a5 1d __ LDA ACCU + 2 
0948 : 85 59 __ STA T1 + 2 
094a : a5 1e __ LDA ACCU + 3 
094c : 85 5a __ STA T1 + 3 
094e : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
0951 : a5 1b __ LDA ACCU + 0 
0953 : 85 43 __ STA T2 + 0 
0955 : a5 1c __ LDA ACCU + 1 
0957 : 85 44 __ STA T2 + 1 
0959 : a5 5a __ LDA T1 + 3 
095b : 29 7f __ AND #$7f
095d : 05 59 __ ORA T1 + 2 
095f : 05 58 __ ORA T1 + 1 
0961 : 05 57 __ ORA T1 + 0 
0963 : f0 39 __ BEQ $099e ; (main.s6 + 0)
.s136:
0965 : 24 5a __ BIT T1 + 3 
0967 : 10 35 __ BPL $099e ; (main.s6 + 0)
.s134:
0969 : 20 a2 20 JSR $20a2 ; (sint32_to_float + 0)
096c : a5 1b __ LDA ACCU + 0 
096e : 85 03 __ STA WORK + 0 
0970 : a5 1c __ LDA ACCU + 1 
0972 : 85 04 __ STA WORK + 1 
0974 : a5 1d __ LDA ACCU + 2 
0976 : 85 05 __ STA WORK + 2 
0978 : a5 1e __ LDA ACCU + 3 
097a : 85 06 __ STA WORK + 3 
097c : a5 57 __ LDA T1 + 0 
097e : 85 1b __ STA ACCU + 0 
0980 : a5 58 __ LDA T1 + 1 
0982 : 85 1c __ STA ACCU + 1 
0984 : a5 59 __ LDA T1 + 2 
0986 : 85 1d __ STA ACCU + 2 
0988 : a5 5a __ LDA T1 + 3 
098a : 85 1e __ STA ACCU + 3 
098c : 20 10 21 JSR $2110 ; (crt_fcmp + 0)
098f : f0 0d __ BEQ $099e ; (main.s6 + 0)
.s135:
0991 : 18 __ __ CLC
0992 : a5 43 __ LDA T2 + 0 
0994 : 69 ff __ ADC #$ff
0996 : a8 __ __ TAY
0997 : a5 44 __ LDA T2 + 1 
0999 : 69 ff __ ADC #$ff
099b : 4c a2 09 JMP $09a2 ; (main.s7 + 0)
.s6:
099e : a5 44 __ LDA T2 + 1 
09a0 : a4 43 __ LDY T2 + 0 
.s7:
09a2 : aa __ __ TAX
09a3 : ad 08 24 LDA $2408 ; (b_v_bi + 0)
09a6 : 85 43 __ STA T2 + 0 
09a8 : 0a __ __ ASL
09a9 : 85 4f __ STA T5 + 0 
09ab : ad 09 24 LDA $2409 ; (b_v_bi + 1)
09ae : 85 44 __ STA T2 + 1 
09b0 : ad 0a 24 LDA $240a ; (b_v_bi + 2)
09b3 : 85 45 __ STA T2 + 2 
09b5 : ad 0b 24 LDA $240b ; (b_v_bi + 3)
09b8 : 85 46 __ STA T2 + 3 
09ba : a9 00 __ LDA #$00
09bc : 85 06 __ STA WORK + 3 
09be : 2a __ __ ROL
09bf : 85 50 __ STA T5 + 1 
09c1 : a9 0c __ LDA #$0c
09c3 : 85 47 __ STA T3 + 0 
09c5 : a9 24 __ LDA #$24
09c7 : 65 50 __ ADC T5 + 1 
09c9 : 85 48 __ STA T3 + 1 
09cb : 98 __ __ TYA
09cc : a4 4f __ LDY T5 + 0 
09ce : 91 47 __ STA (T3 + 0),y 
09d0 : 8a __ __ TXA
09d1 : c8 __ __ INY
09d2 : 91 47 __ STA (T3 + 0),y 
09d4 : a5 53 __ LDA T0 + 0 
09d6 : 85 1b __ STA ACCU + 0 
09d8 : a5 54 __ LDA T0 + 1 
09da : 85 1c __ STA ACCU + 1 
09dc : a5 55 __ LDA T0 + 2 
09de : 85 1d __ STA ACCU + 2 
09e0 : a5 56 __ LDA T0 + 3 
09e2 : 85 1e __ STA ACCU + 3 
09e4 : a9 cd __ LDA #$cd
09e6 : 85 03 __ STA WORK + 0 
09e8 : a9 01 __ LDA #$01
09ea : 85 05 __ STA WORK + 2 
09ec : a9 0d __ LDA #$0d
09ee : 85 04 __ STA WORK + 1 
09f0 : 20 5f 21 JSR $215f ; (mul32 + 0)
09f3 : 18 __ __ CLC
09f4 : a5 07 __ LDA WORK + 4 
09f6 : 69 39 __ ADC #$39
09f8 : 85 53 __ STA T0 + 0 
09fa : a5 08 __ LDA WORK + 5 
09fc : 69 30 __ ADC #$30
09fe : 85 54 __ STA T0 + 1 
0a00 : 85 1b __ STA ACCU + 0 
0a02 : a5 09 __ LDA WORK + 6 
0a04 : 69 00 __ ADC #$00
0a06 : 85 55 __ STA T0 + 2 
0a08 : 85 1c __ STA ACCU + 1 
0a0a : a5 0a __ LDA WORK + 7 
0a0c : 69 00 __ ADC #$00
0a0e : 85 56 __ STA T0 + 3 
0a10 : 85 1d __ STA ACCU + 2 
0a12 : a9 00 __ LDA #$00
0a14 : 85 1e __ STA ACCU + 3 
0a16 : 20 cc 20 JSR $20cc ; (uint32_to_float + 0)
0a19 : a9 00 __ LDA #$00
0a1b : 85 03 __ STA WORK + 0 
0a1d : 85 04 __ STA WORK + 1 
0a1f : a9 80 __ LDA #$80
0a21 : 85 05 __ STA WORK + 2 
0a23 : a9 4b __ LDA #$4b
0a25 : 85 06 __ STA WORK + 3 
0a27 : 20 4d 1c JSR $1c4d ; (freg + 20)
0a2a : 20 33 1e JSR $1e33 ; (crt_fdiv + 0)
0a2d : a9 00 __ LDA #$00
0a2f : 85 03 __ STA WORK + 0 
0a31 : 85 04 __ STA WORK + 1 
0a33 : a9 c8 __ LDA #$c8
0a35 : 85 05 __ STA WORK + 2 
0a37 : a9 41 __ LDA #$41
0a39 : 85 06 __ STA WORK + 3 
0a3b : 20 4d 1c JSR $1c4d ; (freg + 20)
0a3e : 20 6b 1d JSR $1d6b ; (crt_fmul + 0)
0a41 : a5 1b __ LDA ACCU + 0 
0a43 : 85 57 __ STA T1 + 0 
0a45 : a5 1c __ LDA ACCU + 1 
0a47 : 85 58 __ STA T1 + 1 
0a49 : a5 1d __ LDA ACCU + 2 
0a4b : 85 59 __ STA T1 + 2 
0a4d : a5 1e __ LDA ACCU + 3 
0a4f : 85 5a __ STA T1 + 3 
0a51 : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
0a54 : a5 1b __ LDA ACCU + 0 
0a56 : 85 47 __ STA T3 + 0 
0a58 : a5 1c __ LDA ACCU + 1 
0a5a : 85 48 __ STA T3 + 1 
0a5c : a5 5a __ LDA T1 + 3 
0a5e : 29 7f __ AND #$7f
0a60 : 05 59 __ ORA T1 + 2 
0a62 : 05 58 __ ORA T1 + 1 
0a64 : 05 57 __ ORA T1 + 0 
0a66 : f0 39 __ BEQ $0aa1 ; (main.s8 + 0)
.s133:
0a68 : 24 5a __ BIT T1 + 3 
0a6a : 10 35 __ BPL $0aa1 ; (main.s8 + 0)
.s131:
0a6c : 20 a2 20 JSR $20a2 ; (sint32_to_float + 0)
0a6f : a5 1b __ LDA ACCU + 0 
0a71 : 85 03 __ STA WORK + 0 
0a73 : a5 1c __ LDA ACCU + 1 
0a75 : 85 04 __ STA WORK + 1 
0a77 : a5 1d __ LDA ACCU + 2 
0a79 : 85 05 __ STA WORK + 2 
0a7b : a5 1e __ LDA ACCU + 3 
0a7d : 85 06 __ STA WORK + 3 
0a7f : a5 57 __ LDA T1 + 0 
0a81 : 85 1b __ STA ACCU + 0 
0a83 : a5 58 __ LDA T1 + 1 
0a85 : 85 1c __ STA ACCU + 1 
0a87 : a5 59 __ LDA T1 + 2 
0a89 : 85 1d __ STA ACCU + 2 
0a8b : a5 5a __ LDA T1 + 3 
0a8d : 85 1e __ STA ACCU + 3 
0a8f : 20 10 21 JSR $2110 ; (crt_fcmp + 0)
0a92 : f0 0d __ BEQ $0aa1 ; (main.s8 + 0)
.s132:
0a94 : 18 __ __ CLC
0a95 : a5 47 __ LDA T3 + 0 
0a97 : 69 ff __ ADC #$ff
0a99 : a8 __ __ TAY
0a9a : a5 48 __ LDA T3 + 1 
0a9c : 69 ff __ ADC #$ff
0a9e : 4c a5 0a JMP $0aa5 ; (main.s9 + 0)
.s8:
0aa1 : a5 48 __ LDA T3 + 1 
0aa3 : a4 47 __ LDY T3 + 0 
.s9:
0aa5 : aa __ __ TAX
0aa6 : a9 0c __ LDA #$0c
0aa8 : 85 47 __ STA T3 + 0 
0aaa : 18 __ __ CLC
0aab : a9 26 __ LDA #$26
0aad : 65 50 __ ADC T5 + 1 
0aaf : 85 48 __ STA T3 + 1 
0ab1 : 98 __ __ TYA
0ab2 : a4 4f __ LDY T5 + 0 
0ab4 : 91 47 __ STA (T3 + 0),y 
0ab6 : 8a __ __ TXA
0ab7 : c8 __ __ INY
0ab8 : 91 47 __ STA (T3 + 0),y 
0aba : a5 53 __ LDA T0 + 0 
0abc : 85 1b __ STA ACCU + 0 
0abe : a5 54 __ LDA T0 + 1 
0ac0 : 85 1c __ STA ACCU + 1 
0ac2 : a5 55 __ LDA T0 + 2 
0ac4 : 85 1d __ STA ACCU + 2 
0ac6 : a5 56 __ LDA T0 + 3 
0ac8 : 85 1e __ STA ACCU + 3 
0aca : a9 cd __ LDA #$cd
0acc : 85 03 __ STA WORK + 0 
0ace : a9 00 __ LDA #$00
0ad0 : 85 06 __ STA WORK + 3 
0ad2 : a9 0d __ LDA #$0d
0ad4 : 85 04 __ STA WORK + 1 
0ad6 : a9 01 __ LDA #$01
0ad8 : 85 05 __ STA WORK + 2 
0ada : 20 5f 21 JSR $215f ; (mul32 + 0)
0add : 18 __ __ CLC
0ade : a5 07 __ LDA WORK + 4 
0ae0 : 69 39 __ ADC #$39
0ae2 : 85 53 __ STA T0 + 0 
0ae4 : a5 08 __ LDA WORK + 5 
0ae6 : 69 30 __ ADC #$30
0ae8 : 85 54 __ STA T0 + 1 
0aea : 85 1b __ STA ACCU + 0 
0aec : a5 09 __ LDA WORK + 6 
0aee : 69 00 __ ADC #$00
0af0 : 85 55 __ STA T0 + 2 
0af2 : 85 1c __ STA ACCU + 1 
0af4 : a5 0a __ LDA WORK + 7 
0af6 : 69 00 __ ADC #$00
0af8 : 85 56 __ STA T0 + 3 
0afa : 85 1d __ STA ACCU + 2 
0afc : a9 00 __ LDA #$00
0afe : 85 1e __ STA ACCU + 3 
0b00 : 20 cc 20 JSR $20cc ; (uint32_to_float + 0)
0b03 : a9 00 __ LDA #$00
0b05 : 85 03 __ STA WORK + 0 
0b07 : 85 04 __ STA WORK + 1 
0b09 : a9 80 __ LDA #$80
0b0b : 85 05 __ STA WORK + 2 
0b0d : a9 4b __ LDA #$4b
0b0f : 85 06 __ STA WORK + 3 
0b11 : 20 4d 1c JSR $1c4d ; (freg + 20)
0b14 : 20 33 1e JSR $1e33 ; (crt_fdiv + 0)
0b17 : a9 00 __ LDA #$00
0b19 : 85 03 __ STA WORK + 0 
0b1b : 85 04 __ STA WORK + 1 
0b1d : a9 60 __ LDA #$60
0b1f : 85 05 __ STA WORK + 2 
0b21 : a9 41 __ LDA #$41
0b23 : 85 06 __ STA WORK + 3 
0b25 : 20 4d 1c JSR $1c4d ; (freg + 20)
0b28 : 20 6b 1d JSR $1d6b ; (crt_fmul + 0)
0b2b : a5 1b __ LDA ACCU + 0 
0b2d : 85 57 __ STA T1 + 0 
0b2f : a5 1c __ LDA ACCU + 1 
0b31 : 85 58 __ STA T1 + 1 
0b33 : a5 1d __ LDA ACCU + 2 
0b35 : 85 59 __ STA T1 + 2 
0b37 : a5 1e __ LDA ACCU + 3 
0b39 : 85 5a __ STA T1 + 3 
0b3b : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
0b3e : a5 1b __ LDA ACCU + 0 
0b40 : 85 47 __ STA T3 + 0 
0b42 : a5 1c __ LDA ACCU + 1 
0b44 : 85 48 __ STA T3 + 1 
0b46 : a5 5a __ LDA T1 + 3 
0b48 : 29 7f __ AND #$7f
0b4a : 05 59 __ ORA T1 + 2 
0b4c : 05 58 __ ORA T1 + 1 
0b4e : 05 57 __ ORA T1 + 0 
0b50 : f0 39 __ BEQ $0b8b ; (main.s10 + 0)
.s130:
0b52 : 24 5a __ BIT T1 + 3 
0b54 : 10 35 __ BPL $0b8b ; (main.s10 + 0)
.s128:
0b56 : 20 a2 20 JSR $20a2 ; (sint32_to_float + 0)
0b59 : a5 1b __ LDA ACCU + 0 
0b5b : 85 03 __ STA WORK + 0 
0b5d : a5 1c __ LDA ACCU + 1 
0b5f : 85 04 __ STA WORK + 1 
0b61 : a5 1d __ LDA ACCU + 2 
0b63 : 85 05 __ STA WORK + 2 
0b65 : a5 1e __ LDA ACCU + 3 
0b67 : 85 06 __ STA WORK + 3 
0b69 : a5 57 __ LDA T1 + 0 
0b6b : 85 1b __ STA ACCU + 0 
0b6d : a5 58 __ LDA T1 + 1 
0b6f : 85 1c __ STA ACCU + 1 
0b71 : a5 59 __ LDA T1 + 2 
0b73 : 85 1d __ STA ACCU + 2 
0b75 : a5 5a __ LDA T1 + 3 
0b77 : 85 1e __ STA ACCU + 3 
0b79 : 20 10 21 JSR $2110 ; (crt_fcmp + 0)
0b7c : f0 0d __ BEQ $0b8b ; (main.s10 + 0)
.s129:
0b7e : 18 __ __ CLC
0b7f : a5 47 __ LDA T3 + 0 
0b81 : 69 ff __ ADC #$ff
0b83 : a8 __ __ TAY
0b84 : a5 48 __ LDA T3 + 1 
0b86 : 69 ff __ ADC #$ff
0b88 : 4c 8f 0b JMP $0b8f ; (main.s11 + 0)
.s10:
0b8b : a5 48 __ LDA T3 + 1 
0b8d : a4 47 __ LDY T3 + 0 
.s11:
0b8f : aa __ __ TAX
0b90 : c8 __ __ INY
0b91 : d0 01 __ BNE $0b94 ; (main.s142 + 0)
.s141:
0b93 : e8 __ __ INX
.s142:
0b94 : a9 0c __ LDA #$0c
0b96 : 85 47 __ STA T3 + 0 
0b98 : 18 __ __ CLC
0b99 : a9 28 __ LDA #$28
0b9b : 65 50 __ ADC T5 + 1 
0b9d : 85 48 __ STA T3 + 1 
0b9f : 98 __ __ TYA
0ba0 : a4 4f __ LDY T5 + 0 
0ba2 : 91 47 __ STA (T3 + 0),y 
0ba4 : 8a __ __ TXA
0ba5 : c8 __ __ INY
0ba6 : 91 47 __ STA (T3 + 0),y 
0ba8 : a5 53 __ LDA T0 + 0 
0baa : 85 1b __ STA ACCU + 0 
0bac : a5 54 __ LDA T0 + 1 
0bae : 85 1c __ STA ACCU + 1 
0bb0 : a5 55 __ LDA T0 + 2 
0bb2 : 85 1d __ STA ACCU + 2 
0bb4 : a5 56 __ LDA T0 + 3 
0bb6 : 85 1e __ STA ACCU + 3 
0bb8 : a9 cd __ LDA #$cd
0bba : 85 03 __ STA WORK + 0 
0bbc : a9 00 __ LDA #$00
0bbe : 85 06 __ STA WORK + 3 
0bc0 : a9 0d __ LDA #$0d
0bc2 : 85 04 __ STA WORK + 1 
0bc4 : a9 01 __ LDA #$01
0bc6 : 85 05 __ STA WORK + 2 
0bc8 : 20 5f 21 JSR $215f ; (mul32 + 0)
0bcb : 18 __ __ CLC
0bcc : a5 07 __ LDA WORK + 4 
0bce : 69 39 __ ADC #$39
0bd0 : 8d ba 23 STA $23ba ; (b_rndSeed + 0)
0bd3 : a5 08 __ LDA WORK + 5 
0bd5 : 69 30 __ ADC #$30
0bd7 : 8d bb 23 STA $23bb ; (b_rndSeed + 1)
0bda : 85 1b __ STA ACCU + 0 
0bdc : a5 09 __ LDA WORK + 6 
0bde : 69 00 __ ADC #$00
0be0 : 8d bc 23 STA $23bc ; (b_rndSeed + 2)
0be3 : 85 1c __ STA ACCU + 1 
0be5 : a5 0a __ LDA WORK + 7 
0be7 : 69 00 __ ADC #$00
0be9 : 8d bd 23 STA $23bd ; (b_rndSeed + 3)
0bec : 85 1d __ STA ACCU + 2 
0bee : a9 0c __ LDA #$0c
0bf0 : 85 57 __ STA T1 + 0 
0bf2 : 18 __ __ CLC
0bf3 : a9 2c __ LDA #$2c
0bf5 : 65 50 __ ADC T5 + 1 
0bf7 : 85 58 __ STA T1 + 1 
0bf9 : a9 01 __ LDA #$01
0bfb : a4 4f __ LDY T5 + 0 
0bfd : 91 57 __ STA (T1 + 0),y 
0bff : a9 00 __ LDA #$00
0c01 : 85 1e __ STA ACCU + 3 
0c03 : c8 __ __ INY
0c04 : 91 57 __ STA (T1 + 0),y 
0c06 : 18 __ __ CLC
0c07 : a5 43 __ LDA T2 + 0 
0c09 : 69 01 __ ADC #$01
0c0b : 8d 08 24 STA $2408 ; (b_v_bi + 0)
0c0e : a5 44 __ LDA T2 + 1 
0c10 : 69 00 __ ADC #$00
0c12 : 8d 09 24 STA $2409 ; (b_v_bi + 1)
0c15 : a5 45 __ LDA T2 + 2 
0c17 : 69 00 __ ADC #$00
0c19 : 8d 0a 24 STA $240a ; (b_v_bi + 2)
0c1c : a5 46 __ LDA T2 + 3 
0c1e : 69 00 __ ADC #$00
0c20 : 8d 0b 24 STA $240b ; (b_v_bi + 3)
0c23 : 20 cc 20 JSR $20cc ; (uint32_to_float + 0)
0c26 : a9 00 __ LDA #$00
0c28 : 85 03 __ STA WORK + 0 
0c2a : 85 04 __ STA WORK + 1 
0c2c : a9 80 __ LDA #$80
0c2e : 85 05 __ STA WORK + 2 
0c30 : a9 4b __ LDA #$4b
0c32 : 85 06 __ STA WORK + 3 
0c34 : 20 4d 1c JSR $1c4d ; (freg + 20)
0c37 : 20 33 1e JSR $1e33 ; (crt_fdiv + 0)
0c3a : a2 1b __ LDX #$1b
0c3c : 20 3d 1c JSR $1c3d ; (freg + 4)
0c3f : 20 84 1c JSR $1c84 ; (faddsub + 6)
0c42 : a5 1b __ LDA ACCU + 0 
0c44 : 85 53 __ STA T0 + 0 
0c46 : a5 1c __ LDA ACCU + 1 
0c48 : 85 54 __ STA T0 + 1 
0c4a : a5 1d __ LDA ACCU + 2 
0c4c : 85 55 __ STA T0 + 2 
0c4e : a5 1e __ LDA ACCU + 3 
0c50 : 85 56 __ STA T0 + 3 
0c52 : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
0c55 : a5 1b __ LDA ACCU + 0 
0c57 : 85 57 __ STA T1 + 0 
0c59 : a5 1c __ LDA ACCU + 1 
0c5b : 85 58 __ STA T1 + 1 
0c5d : a5 56 __ LDA T0 + 3 
0c5f : 29 7f __ AND #$7f
0c61 : 05 55 __ ORA T0 + 2 
0c63 : 05 54 __ ORA T0 + 1 
0c65 : 05 53 __ ORA T0 + 0 
0c67 : f0 39 __ BEQ $0ca2 ; (main.s12 + 0)
.s127:
0c69 : 24 56 __ BIT T0 + 3 
0c6b : 10 35 __ BPL $0ca2 ; (main.s12 + 0)
.s125:
0c6d : 20 a2 20 JSR $20a2 ; (sint32_to_float + 0)
0c70 : a5 1b __ LDA ACCU + 0 
0c72 : 85 03 __ STA WORK + 0 
0c74 : a5 1c __ LDA ACCU + 1 
0c76 : 85 04 __ STA WORK + 1 
0c78 : a5 1d __ LDA ACCU + 2 
0c7a : 85 05 __ STA WORK + 2 
0c7c : a5 1e __ LDA ACCU + 3 
0c7e : 85 06 __ STA WORK + 3 
0c80 : a5 53 __ LDA T0 + 0 
0c82 : 85 1b __ STA ACCU + 0 
0c84 : a5 54 __ LDA T0 + 1 
0c86 : 85 1c __ STA ACCU + 1 
0c88 : a5 55 __ LDA T0 + 2 
0c8a : 85 1d __ STA ACCU + 2 
0c8c : a5 56 __ LDA T0 + 3 
0c8e : 85 1e __ STA ACCU + 3 
0c90 : 20 10 21 JSR $2110 ; (crt_fcmp + 0)
0c93 : f0 0d __ BEQ $0ca2 ; (main.s12 + 0)
.s126:
0c95 : 18 __ __ CLC
0c96 : a5 57 __ LDA T1 + 0 
0c98 : 69 ff __ ADC #$ff
0c9a : a8 __ __ TAY
0c9b : a5 58 __ LDA T1 + 1 
0c9d : 69 ff __ ADC #$ff
0c9f : 4c a6 0c JMP $0ca6 ; (main.s13 + 0)
.s12:
0ca2 : a5 58 __ LDA T1 + 1 
0ca4 : a4 57 __ LDY T1 + 0 
.s13:
0ca6 : aa __ __ TAX
0ca7 : a9 0c __ LDA #$0c
0ca9 : 85 57 __ STA T1 + 0 
0cab : 18 __ __ CLC
0cac : a9 2a __ LDA #$2a
0cae : 65 50 __ ADC T5 + 1 
0cb0 : 85 58 __ STA T1 + 1 
0cb2 : 98 __ __ TYA
0cb3 : a4 4f __ LDY T5 + 0 
0cb5 : 91 57 __ STA (T1 + 0),y 
0cb7 : 8a __ __ TXA
0cb8 : c8 __ __ INY
0cb9 : 91 57 __ STA (T1 + 0),y 
0cbb : a5 46 __ LDA T2 + 3 
0cbd : 10 04 __ BPL $0cc3 ; (main.s17 + 0)
.s14:
0cbf : a9 01 __ LDA #$01
0cc1 : d0 17 __ BNE $0cda ; (main.s16 + 0)
.s17:
0cc3 : d0 08 __ BNE $0ccd ; (main.s15 + 0)
.s18:
0cc5 : a5 45 __ LDA T2 + 2 
0cc7 : d0 04 __ BNE $0ccd ; (main.s15 + 0)
.s19:
0cc9 : a5 44 __ LDA T2 + 1 
0ccb : f0 04 __ BEQ $0cd1 ; (main.s20 + 0)
.s15:
0ccd : a9 00 __ LDA #$00
0ccf : f0 09 __ BEQ $0cda ; (main.s16 + 0)
.s20:
0cd1 : a5 43 __ LDA T2 + 0 
0cd3 : c9 64 __ CMP #$64
0cd5 : a9 00 __ LDA #$00
0cd7 : 2a __ __ ROL
0cd8 : 49 01 __ EOR #$01
.s16:
0cda : 49 ff __ EOR #$ff
0cdc : c9 ff __ CMP #$ff
0cde : f0 03 __ BEQ $0ce3 ; (main.s21 + 0)
0ce0 : 4c c9 08 JMP $08c9 ; (main.l5 + 0)
.s21:
0ce3 : a9 00 __ LDA #$00
0ce5 : 8d 0c 2e STA $2e0c ; (b_v_ii + 0)
0ce8 : a9 04 __ LDA #$04
0cea : 8d 0d 2e STA $2e0d ; (b_v_ii + 1)
.l22:
0ced : ad 0d 2e LDA $2e0d ; (b_v_ii + 1)
0cf0 : 85 54 __ STA T0 + 1 
0cf2 : c9 e0 __ CMP #$e0
0cf4 : ae 0c 2e LDX $2e0c ; (b_v_ii + 0)
0cf7 : 90 2e __ BCC $0d27 ; (main.s23 + 0)
.s120:
0cf9 : c9 ff __ CMP #$ff
0cfb : d0 02 __ BNE $0cff ; (main.s124 + 0)
.s123:
0cfd : e0 40 __ CPX #$40
.s124:
0cff : b0 26 __ BCS $0d27 ; (main.s23 + 0)
.s121:
0d01 : a0 01 __ LDY #$01
0d03 : b1 51 __ LDA (T6 + 0),y 
0d05 : 85 47 __ STA T3 + 0 
0d07 : 4a __ __ LSR
0d08 : 90 1d __ BCC $0d27 ; (main.s23 + 0)
.s122:
0d0a : 86 57 __ STX T1 + 0 
0d0c : a5 47 __ LDA T3 + 0 
0d0e : 29 fe __ AND #$fe
0d10 : 91 51 __ STA (T6 + 0),y 
0d12 : 18 __ __ CLC
0d13 : a5 52 __ LDA T6 + 1 
0d15 : 65 54 __ ADC T0 + 1 
0d17 : 85 58 __ STA T1 + 1 
0d19 : a9 51 __ LDA #$51
0d1b : a4 51 __ LDY T6 + 0 
0d1d : 91 57 __ STA (T1 + 0),y 
0d1f : a5 47 __ LDA T3 + 0 
0d21 : a0 01 __ LDY #$01
0d23 : 91 51 __ STA (T6 + 0),y 
0d25 : d0 0f __ BNE $0d36 ; (main.s24 + 0)
.s23:
0d27 : 86 57 __ STX T1 + 0 
0d29 : 18 __ __ CLC
0d2a : a5 52 __ LDA T6 + 1 
0d2c : 65 54 __ ADC T0 + 1 
0d2e : 85 58 __ STA T1 + 1 
0d30 : a9 51 __ LDA #$51
0d32 : a4 51 __ LDY T6 + 0 
0d34 : 91 57 __ STA (T1 + 0),y 
.s24:
0d36 : 8a __ __ TXA
0d37 : 18 __ __ CLC
0d38 : 69 01 __ ADC #$01
0d3a : 8d 0c 2e STA $2e0c ; (b_v_ii + 0)
0d3d : a5 54 __ LDA T0 + 1 
0d3f : 69 00 __ ADC #$00
0d41 : 8d 0d 2e STA $2e0d ; (b_v_ii + 1)
0d44 : a9 07 __ LDA #$07
0d46 : cd 0d 2e CMP $2e0d ; (b_v_ii + 1)
0d49 : d0 05 __ BNE $0d50 ; (main.s119 + 0)
.s118:
0d4b : a9 e7 __ LDA #$e7
0d4d : cd 0c 2e CMP $2e0c ; (b_v_ii + 0)
.s119:
0d50 : b0 9b __ BCS $0ced ; (main.l22 + 0)
.s25:
0d52 : a9 00 __ LDA #$00
0d54 : 8d 0c 2e STA $2e0c ; (b_v_ii + 0)
0d57 : a9 d8 __ LDA #$d8
0d59 : 8d 0d 2e STA $2e0d ; (b_v_ii + 1)
.l26:
0d5c : ad 0d 2e LDA $2e0d ; (b_v_ii + 1)
0d5f : 85 54 __ STA T0 + 1 
0d61 : c9 e0 __ CMP #$e0
0d63 : ae 0c 2e LDX $2e0c ; (b_v_ii + 0)
0d66 : 90 2e __ BCC $0d96 ; (main.s27 + 0)
.s113:
0d68 : c9 ff __ CMP #$ff
0d6a : d0 02 __ BNE $0d6e ; (main.s117 + 0)
.s116:
0d6c : e0 40 __ CPX #$40
.s117:
0d6e : b0 26 __ BCS $0d96 ; (main.s27 + 0)
.s114:
0d70 : a0 01 __ LDY #$01
0d72 : b1 51 __ LDA (T6 + 0),y 
0d74 : 85 47 __ STA T3 + 0 
0d76 : 4a __ __ LSR
0d77 : 90 1d __ BCC $0d96 ; (main.s27 + 0)
.s115:
0d79 : 86 57 __ STX T1 + 0 
0d7b : a5 47 __ LDA T3 + 0 
0d7d : 29 fe __ AND #$fe
0d7f : 91 51 __ STA (T6 + 0),y 
0d81 : 18 __ __ CLC
0d82 : a5 52 __ LDA T6 + 1 
0d84 : 65 54 __ ADC T0 + 1 
0d86 : 85 58 __ STA T1 + 1 
0d88 : a9 00 __ LDA #$00
0d8a : a4 51 __ LDY T6 + 0 
0d8c : 91 57 __ STA (T1 + 0),y 
0d8e : a5 47 __ LDA T3 + 0 
0d90 : a0 01 __ LDY #$01
0d92 : 91 51 __ STA (T6 + 0),y 
0d94 : d0 0f __ BNE $0da5 ; (main.s28 + 0)
.s27:
0d96 : 86 57 __ STX T1 + 0 
0d98 : 18 __ __ CLC
0d99 : a5 52 __ LDA T6 + 1 
0d9b : 65 54 __ ADC T0 + 1 
0d9d : 85 58 __ STA T1 + 1 
0d9f : a9 00 __ LDA #$00
0da1 : a4 51 __ LDY T6 + 0 
0da3 : 91 57 __ STA (T1 + 0),y 
.s28:
0da5 : 8a __ __ TXA
0da6 : 18 __ __ CLC
0da7 : 69 01 __ ADC #$01
0da9 : 8d 0c 2e STA $2e0c ; (b_v_ii + 0)
0dac : a5 54 __ LDA T0 + 1 
0dae : 69 00 __ ADC #$00
0db0 : 8d 0d 2e STA $2e0d ; (b_v_ii + 1)
0db3 : a9 db __ LDA #$db
0db5 : cd 0d 2e CMP $2e0d ; (b_v_ii + 1)
0db8 : d0 05 __ BNE $0dbf ; (main.s112 + 0)
.s111:
0dba : a9 e7 __ LDA #$e7
0dbc : cd 0c 2e CMP $2e0c ; (b_v_ii + 0)
.s112:
0dbf : b0 9b __ BCS $0d5c ; (main.l26 + 0)
.l29:
0dc1 : a9 00 __ LDA #$00
0dc3 : 8d 09 24 STA $2409 ; (b_v_bi + 1)
0dc6 : 8d 0a 24 STA $240a ; (b_v_bi + 2)
0dc9 : 8d 0b 24 STA $240b ; (b_v_bi + 3)
0dcc : a9 01 __ LDA #$01
0dce : 8d 08 24 STA $2408 ; (b_v_bi + 0)
0dd1 : 20 3a 17 JSR $173a ; (b_jiffy.s4 + 0)
0dd4 : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
0dd7 : a5 1b __ LDA ACCU + 0 
0dd9 : 8d 0e 2e STA $2e0e ; (b_v_ti + 0)
0ddc : a5 1c __ LDA ACCU + 1 
0dde : 8d 0f 2e STA $2e0f ; (b_v_ti + 1)
0de1 : a5 1d __ LDA ACCU + 2 
0de3 : 8d 10 2e STA $2e10 ; (b_v_ti + 2)
0de6 : a5 1e __ LDA ACCU + 3 
0de8 : 8d 11 2e STA $2e11 ; (b_v_ti + 3)
.l30:
0deb : ad 08 24 LDA $2408 ; (b_v_bi + 0)
0dee : 0a __ __ ASL
0def : 85 43 __ STA T2 + 0 
0df1 : a8 __ __ TAY
0df2 : a9 00 __ LDA #$00
0df4 : 2a __ __ ROL
0df5 : 85 44 __ STA T2 + 1 
0df7 : 69 26 __ ADC #$26
0df9 : 85 54 __ STA T0 + 1 
0dfb : a9 0c __ LDA #$0c
0dfd : 85 53 __ STA T0 + 0 
0dff : b1 53 __ LDA (T0 + 0),y 
0e01 : aa __ __ TAX
0e02 : 0a __ __ ASL
0e03 : 85 07 __ STA WORK + 4 
0e05 : c8 __ __ INY
0e06 : b1 53 __ LDA (T0 + 0),y 
0e08 : 2a __ __ ROL
0e09 : 06 07 __ ASL WORK + 4 
0e0b : 2a __ __ ROL
0e0c : 85 08 __ STA WORK + 5 
0e0e : 8a __ __ TXA
0e0f : 18 __ __ CLC
0e10 : 65 07 __ ADC WORK + 4 
0e12 : 85 1b __ STA ACCU + 0 
0e14 : a5 08 __ LDA WORK + 5 
0e16 : 71 53 __ ADC (T0 + 0),y 
0e18 : 06 1b __ ASL ACCU + 0 
0e1a : 2a __ __ ROL
0e1b : 06 1b __ ASL ACCU + 0 
0e1d : 2a __ __ ROL
0e1e : 06 1b __ ASL ACCU + 0 
0e20 : 2a __ __ ROL
0e21 : 85 1c __ STA ACCU + 1 
0e23 : 20 5b 20 JSR $205b ; (sint16_to_float + 0)
0e26 : a9 00 __ LDA #$00
0e28 : 85 03 __ STA WORK + 0 
0e2a : 85 04 __ STA WORK + 1 
0e2c : a9 58 __ LDA #$58
0e2e : 85 05 __ STA WORK + 2 
0e30 : a9 47 __ LDA #$47
0e32 : 85 06 __ STA WORK + 3 
0e34 : 20 4d 1c JSR $1c4d ; (freg + 20)
0e37 : 20 84 1c JSR $1c84 ; (faddsub + 6)
0e3a : a5 1b __ LDA ACCU + 0 
0e3c : 85 53 __ STA T0 + 0 
0e3e : a5 1c __ LDA ACCU + 1 
0e40 : 85 54 __ STA T0 + 1 
0e42 : a5 1d __ LDA ACCU + 2 
0e44 : 85 55 __ STA T0 + 2 
0e46 : a5 1e __ LDA ACCU + 3 
0e48 : 85 56 __ STA T0 + 3 
0e4a : a9 0c __ LDA #$0c
0e4c : 85 47 __ STA T3 + 0 
0e4e : 18 __ __ CLC
0e4f : a9 24 __ LDA #$24
0e51 : 65 44 __ ADC T2 + 1 
0e53 : 85 48 __ STA T3 + 1 
0e55 : a4 43 __ LDY T2 + 0 
0e57 : b1 47 __ LDA (T3 + 0),y 
0e59 : 85 4b __ STA T4 + 0 
0e5b : 85 1b __ STA ACCU + 0 
0e5d : c8 __ __ INY
0e5e : b1 47 __ LDA (T3 + 0),y 
0e60 : 85 4c __ STA T4 + 1 
0e62 : 85 1c __ STA ACCU + 1 
0e64 : 20 5b 20 JSR $205b ; (sint16_to_float + 0)
0e67 : a2 53 __ LDX #$53
0e69 : 20 3d 1c JSR $1c3d ; (freg + 4)
0e6c : 20 84 1c JSR $1c84 ; (faddsub + 6)
0e6f : 20 cd 1f JSR $1fcd ; (f32_to_u16 + 0)
0e72 : a5 1c __ LDA ACCU + 1 
0e74 : c9 e0 __ CMP #$e0
0e76 : a6 1b __ LDX ACCU + 0 
0e78 : 86 53 __ STX T0 + 0 
0e7a : 90 29 __ BCC $0ea5 ; (main.s31 + 0)
.s106:
0e7c : c9 ff __ CMP #$ff
0e7e : d0 02 __ BNE $0e82 ; (main.s110 + 0)
.s109:
0e80 : e0 40 __ CPX #$40
.s110:
0e82 : b0 21 __ BCS $0ea5 ; (main.s31 + 0)
.s107:
0e84 : a0 01 __ LDY #$01
0e86 : b1 51 __ LDA (T6 + 0),y 
0e88 : aa __ __ TAX
0e89 : 4a __ __ LSR
0e8a : 90 19 __ BCC $0ea5 ; (main.s31 + 0)
.s108:
0e8c : 8a __ __ TXA
0e8d : 29 fe __ AND #$fe
0e8f : 91 51 __ STA (T6 + 0),y 
0e91 : 18 __ __ CLC
0e92 : a5 52 __ LDA T6 + 1 
0e94 : 65 1c __ ADC ACCU + 1 
0e96 : 85 54 __ STA T0 + 1 
0e98 : a9 00 __ LDA #$00
0e9a : a4 51 __ LDY T6 + 0 
0e9c : 91 53 __ STA (T0 + 0),y 
0e9e : 8a __ __ TXA
0e9f : a0 01 __ LDY #$01
0ea1 : 91 51 __ STA (T6 + 0),y 
0ea3 : d0 0d __ BNE $0eb2 ; (main.s32 + 0)
.s31:
0ea5 : 18 __ __ CLC
0ea6 : a5 52 __ LDA T6 + 1 
0ea8 : 65 1c __ ADC ACCU + 1 
0eaa : 85 54 __ STA T0 + 1 
0eac : a9 00 __ LDA #$00
0eae : a4 51 __ LDY T6 + 0 
0eb0 : 91 53 __ STA (T0 + 0),y 
.s32:
0eb2 : a9 0c __ LDA #$0c
0eb4 : 85 53 __ STA T0 + 0 
0eb6 : 18 __ __ CLC
0eb7 : a9 2a __ LDA #$2a
0eb9 : 65 44 __ ADC T2 + 1 
0ebb : 85 54 __ STA T0 + 1 
0ebd : a4 43 __ LDY T2 + 0 
0ebf : b1 53 __ LDA (T0 + 0),y 
0ec1 : c8 __ __ INY
0ec2 : 11 53 __ ORA (T0 + 0),y 
0ec4 : f0 03 __ BEQ $0ec9 ; (main.s103 + 0)
0ec6 : 4c 1e 13 JMP $131e ; (main.l33 + 0)
.s103:
0ec9 : ad 36 23 LDA $2336 ; (b_gosubSP + 0)
0ecc : 85 57 __ STA T1 + 0 
0ece : 18 __ __ CLC
0ecf : 69 01 __ ADC #$01
0ed1 : 8d 36 23 STA $2336 ; (b_gosubSP + 0)
0ed4 : ad 37 23 LDA $2337 ; (b_gosubSP + 1)
0ed7 : 85 58 __ STA T1 + 1 
0ed9 : 69 00 __ ADC #$00
0edb : 8d 37 23 STA $2337 ; (b_gosubSP + 1)
0ede : 06 57 __ ASL T1 + 0 
0ee0 : 26 58 __ ROL T1 + 1 
0ee2 : 18 __ __ CLC
0ee3 : a9 12 __ LDA #$12
0ee5 : 65 57 __ ADC T1 + 0 
0ee7 : 85 57 __ STA T1 + 0 
0ee9 : a9 2e __ LDA #$2e
0eeb : 65 58 __ ADC T1 + 1 
0eed : 85 58 __ STA T1 + 1 
0eef : a9 00 __ LDA #$00
0ef1 : a8 __ __ TAY
0ef2 : 91 57 __ STA (T1 + 0),y 
0ef4 : c8 __ __ INY
0ef5 : 91 57 __ STA (T1 + 0),y 
0ef7 : a5 4b __ LDA T4 + 0 
0ef9 : a4 43 __ LDY T2 + 0 
0efb : 05 4c __ ORA T4 + 1 
0efd : f0 11 __ BEQ $0f10 ; (main.s105 + 0)
.s104:
0eff : 38 __ __ SEC
0f00 : a5 4b __ LDA T4 + 0 
0f02 : e9 01 __ SBC #$01
0f04 : 91 47 __ STA (T3 + 0),y 
0f06 : a5 4c __ LDA T4 + 1 
0f08 : e9 00 __ SBC #$00
0f0a : c8 __ __ INY
0f0b : 91 47 __ STA (T3 + 0),y 
0f0d : 4c 19 0f JMP $0f19 ; (main.l81 + 0)
.s105:
0f10 : a9 01 __ LDA #$01
0f12 : 91 53 __ STA (T0 + 0),y 
0f14 : a9 00 __ LDA #$00
0f16 : c8 __ __ INY
.s138:
0f17 : 91 53 __ STA (T0 + 0),y 
.l81:
0f19 : ad 36 23 LDA $2336 ; (b_gosubSP + 0)
0f1c : 85 53 __ STA T0 + 0 
0f1e : ad 37 23 LDA $2337 ; (b_gosubSP + 1)
0f21 : 30 42 __ BMI $0f65 ; (main.s84 + 0)
.s91:
0f23 : 85 54 __ STA T0 + 1 
0f25 : 05 53 __ ORA T0 + 0 
0f27 : f0 3c __ BEQ $0f65 ; (main.s84 + 0)
.s82:
0f29 : a6 53 __ LDX T0 + 0 
0f2b : ca __ __ DEX
0f2c : 8e 36 23 STX $2336 ; (b_gosubSP + 0)
0f2f : 06 53 __ ASL T0 + 0 
0f31 : 26 54 __ ROL T0 + 1 
0f33 : 18 __ __ CLC
0f34 : a9 10 __ LDA #$10
0f36 : 65 53 __ ADC T0 + 0 
0f38 : 85 53 __ STA T0 + 0 
0f3a : a9 2e __ LDA #$2e
0f3c : 65 54 __ ADC T0 + 1 
0f3e : 85 54 __ STA T0 + 1 
0f40 : a0 00 __ LDY #$00
0f42 : 8c 37 23 STY $2337 ; (b_gosubSP + 1)
0f45 : b1 53 __ LDA (T0 + 0),y 
0f47 : aa __ __ TAX
0f48 : c8 __ __ INY
0f49 : b1 53 __ LDA (T0 + 0),y 
0f4b : d0 03 __ BNE $0f50 ; (main.s145 + 0)
0f4d : 4c bb 13 JMP $13bb ; (main.s90 + 0)
.s145:
0f50 : 30 03 __ BMI $0f55 ; (main.s86 + 0)
0f52 : 4c ae 13 JMP $13ae ; (main.s83 + 0)
.s86:
0f55 : 8a __ __ TXA
0f56 : 11 53 __ ORA (T0 + 0),y 
0f58 : d0 03 __ BNE $0f5d ; (main.s87 + 0)
0f5a : 4c 1e 13 JMP $131e ; (main.l33 + 0)
.s87:
0f5d : b1 53 __ LDA (T0 + 0),y 
0f5f : d0 04 __ BNE $0f65 ; (main.s84 + 0)
.s88:
0f61 : e0 01 __ CPX #$01
0f63 : f0 11 __ BEQ $0f76 ; (main.s37 + 0)
.s84:
0f65 : a9 00 __ LDA #$00
0f67 : 85 1b __ STA ACCU + 0 
0f69 : 85 1c __ STA ACCU + 1 
.s3:
0f6b : a2 08 __ LDX #$08
0f6d : bd 9f 9f LDA $9f9f,x ; (main@stack + 0)
0f70 : 95 53 __ STA T0 + 0,x 
0f72 : ca __ __ DEX
0f73 : 10 f8 __ BPL $0f6d ; (main.s3 + 2)
0f75 : 60 __ __ RTS
.s37:
0f76 : ad 08 24 LDA $2408 ; (b_v_bi + 0)
0f79 : 0a __ __ ASL
0f7a : 85 53 __ STA T0 + 0 
0f7c : ad 09 24 LDA $2409 ; (b_v_bi + 1)
0f7f : 2a __ __ ROL
0f80 : 85 54 __ STA T0 + 1 
0f82 : 18 __ __ CLC
0f83 : a9 0c __ LDA #$0c
0f85 : 65 53 __ ADC T0 + 0 
0f87 : 85 57 __ STA T1 + 0 
0f89 : a9 2c __ LDA #$2c
0f8b : 65 54 __ ADC T0 + 1 
0f8d : 85 58 __ STA T1 + 1 
0f8f : a0 00 __ LDY #$00
0f91 : b1 57 __ LDA (T1 + 0),y 
0f93 : c8 __ __ INY
0f94 : 11 57 __ ORA (T1 + 0),y 
0f96 : d0 67 __ BNE $0fff ; (main.s38 + 0)
.s94:
0f98 : ad 36 23 LDA $2336 ; (b_gosubSP + 0)
0f9b : 85 43 __ STA T2 + 0 
0f9d : 18 __ __ CLC
0f9e : 69 01 __ ADC #$01
0fa0 : 8d 36 23 STA $2336 ; (b_gosubSP + 0)
0fa3 : ad 37 23 LDA $2337 ; (b_gosubSP + 1)
0fa6 : 85 44 __ STA T2 + 1 
0fa8 : 69 00 __ ADC #$00
0faa : 8d 37 23 STA $2337 ; (b_gosubSP + 1)
0fad : 06 43 __ ASL T2 + 0 
0faf : 26 44 __ ROL T2 + 1 
0fb1 : 18 __ __ CLC
0fb2 : a9 12 __ LDA #$12
0fb4 : 65 43 __ ADC T2 + 0 
0fb6 : 85 43 __ STA T2 + 0 
0fb8 : a9 2e __ LDA #$2e
0fba : 65 44 __ ADC T2 + 1 
0fbc : 85 44 __ STA T2 + 1 
0fbe : a9 02 __ LDA #$02
0fc0 : 88 __ __ DEY
0fc1 : 91 43 __ STA (T2 + 0),y 
0fc3 : 98 __ __ TYA
0fc4 : c8 __ __ INY
0fc5 : 91 43 __ STA (T2 + 0),y 
0fc7 : 18 __ __ CLC
0fc8 : a9 0c __ LDA #$0c
0fca : 65 53 __ ADC T0 + 0 
0fcc : 85 53 __ STA T0 + 0 
0fce : a9 26 __ LDA #$26
0fd0 : 65 54 __ ADC T0 + 1 
0fd2 : 85 54 __ STA T0 + 1 
0fd4 : 88 __ __ DEY
0fd5 : b1 53 __ LDA (T0 + 0),y 
0fd7 : aa __ __ TAX
0fd8 : c8 __ __ INY
0fd9 : 11 53 __ ORA (T0 + 0),y 
0fdb : d0 0c __ BNE $0fe9 ; (main.s95 + 0)
.s96:
0fdd : 98 __ __ TYA
0fde : 88 __ __ DEY
0fdf : 91 57 __ STA (T1 + 0),y 
0fe1 : 98 __ __ TYA
.l139:
0fe2 : a0 01 __ LDY #$01
0fe4 : 91 57 __ STA (T1 + 0),y 
0fe6 : 4c 19 0f JMP $0f19 ; (main.l81 + 0)
.s95:
0fe9 : 8a __ __ TXA
0fea : 38 __ __ SEC
0feb : e9 01 __ SBC #$01
0fed : 85 57 __ STA T1 + 0 
0fef : b1 53 __ LDA (T0 + 0),y 
0ff1 : e9 00 __ SBC #$00
.s80:
0ff3 : aa __ __ TAX
0ff4 : a5 57 __ LDA T1 + 0 
0ff6 : a0 00 __ LDY #$00
0ff8 : 91 53 __ STA (T0 + 0),y 
0ffa : 8a __ __ TXA
0ffb : c8 __ __ INY
0ffc : 4c 17 0f JMP $0f17 ; (main.s138 + 0)
.s38:
0fff : ad 08 24 LDA $2408 ; (b_v_bi + 0)
1002 : 0a __ __ ASL
1003 : 85 53 __ STA T0 + 0 
1005 : ad 09 24 LDA $2409 ; (b_v_bi + 1)
1008 : 2a __ __ ROL
1009 : 85 54 __ STA T0 + 1 
100b : 18 __ __ CLC
100c : a9 0c __ LDA #$0c
100e : 65 53 __ ADC T0 + 0 
1010 : 85 57 __ STA T1 + 0 
1012 : a9 2c __ LDA #$2c
1014 : 65 54 __ ADC T0 + 1 
1016 : 85 58 __ STA T1 + 1 
1018 : b1 57 __ LDA (T1 + 0),y 
101a : d0 07 __ BNE $1023 ; (main.s39 + 0)
.s41:
101c : a8 __ __ TAY
101d : b1 57 __ LDA (T1 + 0),y 
101f : c9 01 __ CMP #$01
1021 : f0 02 __ BEQ $1025 ; (main.s40 + 0)
.s39:
1023 : a9 00 __ LDA #$00
.s40:
1025 : 49 ff __ EOR #$ff
1027 : c9 ff __ CMP #$ff
1029 : f0 03 __ BEQ $102e ; (main.s42 + 0)
102b : 4c ab 12 JMP $12ab ; (main.s74 + 0)
.s42:
102e : ad 09 24 LDA $2409 ; (b_v_bi + 1)
1031 : 85 54 __ STA T0 + 1 
1033 : ad 0a 24 LDA $240a ; (b_v_bi + 2)
1036 : 85 55 __ STA T0 + 2 
1038 : ad 0b 24 LDA $240b ; (b_v_bi + 3)
103b : 85 56 __ STA T0 + 3 
103d : ad 08 24 LDA $2408 ; (b_v_bi + 0)
1040 : 85 53 __ STA T0 + 0 
1042 : 0a __ __ ASL
1043 : 85 43 __ STA T2 + 0 
1045 : a8 __ __ TAY
1046 : a9 00 __ LDA #$00
1048 : 2a __ __ ROL
1049 : 85 44 __ STA T2 + 1 
104b : 69 28 __ ADC #$28
104d : 85 58 __ STA T1 + 1 
104f : a9 0c __ LDA #$0c
1051 : 85 57 __ STA T1 + 0 
1053 : b1 57 __ LDA (T1 + 0),y 
1055 : 85 47 __ STA T3 + 0 
1057 : a9 0c __ LDA #$0c
1059 : 85 57 __ STA T1 + 0 
105b : a9 26 __ LDA #$26
105d : 65 44 __ ADC T2 + 1 
105f : 85 58 __ STA T1 + 1 
1061 : b1 57 __ LDA (T1 + 0),y 
1063 : aa __ __ TAX
1064 : 0a __ __ ASL
1065 : 85 07 __ STA WORK + 4 
1067 : c8 __ __ INY
1068 : b1 57 __ LDA (T1 + 0),y 
106a : 2a __ __ ROL
106b : 06 07 __ ASL WORK + 4 
106d : 2a __ __ ROL
106e : 85 08 __ STA WORK + 5 
1070 : 8a __ __ TXA
1071 : 18 __ __ CLC
1072 : 65 07 __ ADC WORK + 4 
1074 : 85 1b __ STA ACCU + 0 
1076 : a5 08 __ LDA WORK + 5 
1078 : 71 57 __ ADC (T1 + 0),y 
107a : 06 1b __ ASL ACCU + 0 
107c : 2a __ __ ROL
107d : 06 1b __ ASL ACCU + 0 
107f : 2a __ __ ROL
1080 : 06 1b __ ASL ACCU + 0 
1082 : 2a __ __ ROL
1083 : 85 1c __ STA ACCU + 1 
1085 : 20 5b 20 JSR $205b ; (sint16_to_float + 0)
1088 : a9 00 __ LDA #$00
108a : 85 03 __ STA WORK + 0 
108c : 85 04 __ STA WORK + 1 
108e : a9 58 __ LDA #$58
1090 : 85 05 __ STA WORK + 2 
1092 : a9 47 __ LDA #$47
1094 : 85 06 __ STA WORK + 3 
1096 : 20 4d 1c JSR $1c4d ; (freg + 20)
1099 : 20 84 1c JSR $1c84 ; (faddsub + 6)
109c : a5 1b __ LDA ACCU + 0 
109e : 85 57 __ STA T1 + 0 
10a0 : a5 1c __ LDA ACCU + 1 
10a2 : 85 58 __ STA T1 + 1 
10a4 : a5 1d __ LDA ACCU + 2 
10a6 : 85 59 __ STA T1 + 2 
10a8 : a5 1e __ LDA ACCU + 3 
10aa : 85 5a __ STA T1 + 3 
10ac : 18 __ __ CLC
10ad : a9 0c __ LDA #$0c
10af : 65 43 __ ADC T2 + 0 
10b1 : 85 43 __ STA T2 + 0 
10b3 : a9 24 __ LDA #$24
10b5 : 65 44 __ ADC T2 + 1 
10b7 : 85 44 __ STA T2 + 1 
10b9 : a0 00 __ LDY #$00
10bb : b1 43 __ LDA (T2 + 0),y 
10bd : 85 1b __ STA ACCU + 0 
10bf : c8 __ __ INY
10c0 : b1 43 __ LDA (T2 + 0),y 
10c2 : 85 1c __ STA ACCU + 1 
10c4 : 20 5b 20 JSR $205b ; (sint16_to_float + 0)
10c7 : a2 57 __ LDX #$57
10c9 : 20 3d 1c JSR $1c3d ; (freg + 4)
10cc : 20 84 1c JSR $1c84 ; (faddsub + 6)
10cf : 20 cd 1f JSR $1fcd ; (f32_to_u16 + 0)
10d2 : a5 1c __ LDA ACCU + 1 
10d4 : c9 e0 __ CMP #$e0
10d6 : 90 1f __ BCC $10f7 ; (main.s43 + 0)
.s69:
10d8 : a6 1b __ LDX ACCU + 0 
10da : 86 57 __ STX T1 + 0 
10dc : c9 ff __ CMP #$ff
10de : d0 02 __ BNE $10e2 ; (main.s73 + 0)
.s72:
10e0 : e0 40 __ CPX #$40
.s73:
10e2 : b0 13 __ BCS $10f7 ; (main.s43 + 0)
.s70:
10e4 : ad 30 23 LDA $2330 ; (b_mem + 0)
10e7 : 85 43 __ STA T2 + 0 
10e9 : ad 31 23 LDA $2331 ; (b_mem + 1)
10ec : 85 44 __ STA T2 + 1 
10ee : a0 01 __ LDY #$01
10f0 : b1 43 __ LDA (T2 + 0),y 
10f2 : 85 5b __ STA T7 + 0 
10f4 : 4a __ __ LSR
10f5 : b0 26 __ BCS $111d ; (main.s71 + 0)
.s43:
10f7 : ad fe 23 LDA $23fe ; (b_v_ni + 0)
10fa : 85 57 __ STA T1 + 0 
10fc : ad ff 23 LDA $23ff ; (b_v_ni + 1)
10ff : 85 44 __ STA T2 + 1 
1101 : 85 58 __ STA T1 + 1 
1103 : ad 30 23 LDA $2330 ; (b_mem + 0)
1106 : 18 __ __ CLC
1107 : 65 1b __ ADC ACCU + 0 
1109 : 85 4b __ STA T4 + 0 
110b : ad 31 23 LDA $2331 ; (b_mem + 1)
110e : 65 1c __ ADC ACCU + 1 
1110 : 85 4c __ STA T4 + 1 
1112 : a5 47 __ LDA T3 + 0 
1114 : a0 00 __ LDY #$00
1116 : 91 4b __ STA (T4 + 0),y 
1118 : 06 44 __ ASL T2 + 1 
111a : 4c 45 11 JMP $1145 ; (main.s44 + 0)
.s71:
111d : ad ff 23 LDA $23ff ; (b_v_ni + 1)
1120 : 85 50 __ STA T5 + 1 
1122 : a5 5b __ LDA T7 + 0 
1124 : 29 fe __ AND #$fe
1126 : ae fe 23 LDX $23fe ; (b_v_ni + 0)
1129 : 91 43 __ STA (T2 + 0),y 
112b : 18 __ __ CLC
112c : a5 44 __ LDA T2 + 1 
112e : 65 1c __ ADC ACCU + 1 
1130 : 85 58 __ STA T1 + 1 
1132 : a5 47 __ LDA T3 + 0 
1134 : a4 43 __ LDY T2 + 0 
1136 : 91 57 __ STA (T1 + 0),y 
1138 : 86 57 __ STX T1 + 0 
113a : a5 5b __ LDA T7 + 0 
113c : a0 01 __ LDY #$01
113e : 91 43 __ STA (T2 + 0),y 
1140 : a5 50 __ LDA T5 + 1 
1142 : 85 58 __ STA T1 + 1 
1144 : 0a __ __ ASL
.s44:
1145 : a2 00 __ LDX #$00
1147 : 90 01 __ BCC $114a ; (main.s144 + 0)
.s143:
1149 : ca __ __ DEX
.s144:
114a : 18 __ __ CLC
114b : a5 53 __ LDA T0 + 0 
114d : 69 01 __ ADC #$01
114f : 8d 08 24 STA $2408 ; (b_v_bi + 0)
1152 : a5 54 __ LDA T0 + 1 
1154 : 69 00 __ ADC #$00
1156 : 8d 09 24 STA $2409 ; (b_v_bi + 1)
1159 : a5 55 __ LDA T0 + 2 
115b : 69 00 __ ADC #$00
115d : 8d 0a 24 STA $240a ; (b_v_bi + 2)
1160 : a5 56 __ LDA T0 + 3 
1162 : 69 00 __ ADC #$00
1164 : 8d 0b 24 STA $240b ; (b_v_bi + 3)
1167 : 8a __ __ TXA
1168 : ec 0b 24 CPX $240b ; (b_v_bi + 3)
116b : d0 03 __ BNE $1170 ; (main.s51 + 0)
116d : 4c 94 12 JMP $1294 ; (main.s46 + 0)
.s51:
1170 : 4d 0b 24 EOR $240b ; (b_v_bi + 3)
1173 : 30 05 __ BMI $117a ; (main.s50 + 0)
.s49:
1175 : a9 00 __ LDA #$00
1177 : 2a __ __ ROL
1178 : 90 05 __ BCC $117f ; (main.s45 + 0)
.s50:
117a : a9 00 __ LDA #$00
117c : 2a __ __ ROL
117d : 49 01 __ EOR #$01
.s45:
117f : 49 ff __ EOR #$ff
1181 : c9 ff __ CMP #$ff
1183 : f0 03 __ BEQ $1188 ; (main.s52 + 0)
1185 : 4c eb 0d JMP $0deb ; (main.l30 + 0)
.s52:
1188 : a9 13 __ LDA #$13
118a : 85 13 __ STA P6 
118c : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
118f : 20 3a 17 JSR $173a ; (b_jiffy.s4 + 0)
1192 : a5 1b __ LDA ACCU + 0 
1194 : 85 53 __ STA T0 + 0 
1196 : a5 1c __ LDA ACCU + 1 
1198 : 85 54 __ STA T0 + 1 
119a : a5 1d __ LDA ACCU + 2 
119c : 85 55 __ STA T0 + 2 
119e : a5 1e __ LDA ACCU + 3 
11a0 : 85 56 __ STA T0 + 3 
11a2 : ad 0e 2e LDA $2e0e ; (b_v_ti + 0)
11a5 : 85 1b __ STA ACCU + 0 
11a7 : ad 0f 2e LDA $2e0f ; (b_v_ti + 1)
11aa : 85 1c __ STA ACCU + 1 
11ac : ad 10 2e LDA $2e10 ; (b_v_ti + 2)
11af : 85 1d __ STA ACCU + 2 
11b1 : ad 11 2e LDA $2e11 ; (b_v_ti + 3)
11b4 : 85 1e __ STA ACCU + 3 
11b6 : 20 a2 20 JSR $20a2 ; (sint32_to_float + 0)
11b9 : a2 53 __ LDX #$53
11bb : 20 3d 1c JSR $1c3d ; (freg + 4)
11be : a5 1e __ LDA ACCU + 3 
11c0 : 49 80 __ EOR #$80
11c2 : 85 1e __ STA ACCU + 3 
11c4 : 20 84 1c JSR $1c84 ; (faddsub + 6)
11c7 : a5 1b __ LDA ACCU + 0 
11c9 : 85 53 __ STA T0 + 0 
11cb : a5 1c __ LDA ACCU + 1 
11cd : 85 54 __ STA T0 + 1 
11cf : a5 1d __ LDA ACCU + 2 
11d1 : 85 55 __ STA T0 + 2 
11d3 : a5 1e __ LDA ACCU + 3 
11d5 : 85 56 __ STA T0 + 3 
11d7 : 29 7f __ AND #$7f
11d9 : 05 1d __ ORA ACCU + 2 
11db : 05 1c __ ORA ACCU + 1 
11dd : 05 1b __ ORA ACCU + 0 
11df : f0 04 __ BEQ $11e5 ; (main.s67 + 0)
.s68:
11e1 : 24 1e __ BIT ACCU + 3 
11e3 : 30 04 __ BMI $11e9 ; (main.s53 + 0)
.s67:
11e5 : a9 20 __ LDA #$20
11e7 : d0 08 __ BNE $11f1 ; (main.s54 + 0)
.s53:
11e9 : a5 1e __ LDA ACCU + 3 
11eb : 49 80 __ EOR #$80
11ed : 85 56 __ STA T0 + 3 
11ef : a9 2d __ LDA #$2d
.s54:
11f1 : 85 13 __ STA P6 
11f3 : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
11f6 : a5 56 __ LDA T0 + 3 
11f8 : 29 7f __ AND #$7f
11fa : 05 55 __ ORA T0 + 2 
11fc : 05 54 __ ORA T0 + 1 
11fe : 05 53 __ ORA T0 + 0 
1200 : d0 18 __ BNE $121a ; (main.s55 + 0)
.s66:
1202 : a9 30 __ LDA #$30
1204 : 85 13 __ STA P6 
1206 : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
.s57:
1209 : a9 20 __ LDA #$20
120b : 85 13 __ STA P6 
120d : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
1210 : a9 0d __ LDA #$0d
1212 : 85 13 __ STA P6 
1214 : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
1217 : 4c c1 0d JMP $0dc1 ; (main.l29 + 0)
.s55:
121a : a5 53 __ LDA T0 + 0 
121c : 85 0f __ STA P2 
121e : a5 54 __ LDA T0 + 1 
1220 : 85 10 __ STA P3 
1222 : a5 55 __ LDA T0 + 2 
1224 : 85 11 __ STA P4 
1226 : a5 56 __ LDA T0 + 3 
1228 : 85 12 __ STA P5 
122a : a9 a8 __ LDA #$a8
122c : 85 0d __ STA P0 
122e : a9 9f __ LDA #$9f
1230 : 85 0e __ STA P1 
1232 : 20 5b 17 JSR $175b ; (b_ftoa.s4 + 0)
1235 : a9 2e __ LDA #$2e
1237 : 85 0f __ STA P2 
1239 : a9 00 __ LDA #$00
123b : 85 10 __ STA P3 
123d : 20 c5 1b JSR $1bc5 ; (strchr.l4 + 0)
1240 : a5 1b __ LDA ACCU + 0 
1242 : 05 1c __ ORA ACCU + 1 
1244 : f0 2a __ BEQ $1270 ; (main.s56 + 0)
.s59:
1246 : a9 a8 __ LDA #$a8
1248 : 85 0d __ STA P0 
124a : a9 9f __ LDA #$9f
124c : 85 0e __ STA P1 
124e : 20 e7 1b JSR $1be7 ; (strlen.s4 + 0)
1251 : a5 1c __ LDA ACCU + 1 
1253 : 30 1b __ BMI $1270 ; (main.s56 + 0)
.s65:
1255 : d0 06 __ BNE $125d ; (main.s140 + 0)
.s64:
1257 : a5 1b __ LDA ACCU + 0 
1259 : c9 02 __ CMP #$02
125b : 90 13 __ BCC $1270 ; (main.s56 + 0)
.s140:
125d : a6 1b __ LDX ACCU + 0 
.l60:
125f : bd a7 9f LDA $9fa7,x ; (main@stack + 8)
1262 : c9 30 __ CMP #$30
1264 : d0 23 __ BNE $1289 ; (main.s61 + 0)
.s63:
1266 : a9 00 __ LDA #$00
1268 : 9d a7 9f STA $9fa7,x ; (main@stack + 8)
126b : ca __ __ DEX
126c : e0 02 __ CPX #$02
126e : b0 ef __ BCS $125f ; (main.l60 + 0)
.s56:
1270 : ad a8 9f LDA $9fa8 ; (buf[0] + 0)
1273 : f0 94 __ BEQ $1209 ; (main.s57 + 0)
.s58:
1275 : a2 00 __ LDX #$00
1277 : 86 57 __ STX T1 + 0 
.l137:
1279 : 85 13 __ STA P6 
127b : 20 ed 14 JSR $14ed ; (b_putc.s4 + 0)
127e : e6 57 __ INC T1 + 0 
1280 : a6 57 __ LDX T1 + 0 
1282 : bd a8 9f LDA $9fa8,x ; (buf[0] + 0)
1285 : d0 f2 __ BNE $1279 ; (main.l137 + 0)
1287 : f0 80 __ BEQ $1209 ; (main.s57 + 0)
.s61:
1289 : c9 2e __ CMP #$2e
128b : d0 e3 __ BNE $1270 ; (main.s56 + 0)
.s62:
128d : a9 00 __ LDA #$00
128f : 9d a7 9f STA $9fa7,x ; (main@stack + 8)
1292 : f0 dc __ BEQ $1270 ; (main.s56 + 0)
.s46:
1294 : cd 0a 24 CMP $240a ; (b_v_bi + 2)
1297 : f0 03 __ BEQ $129c ; (main.s47 + 0)
1299 : 4c 75 11 JMP $1175 ; (main.s49 + 0)
.s47:
129c : a5 58 __ LDA T1 + 1 
129e : cd 09 24 CMP $2409 ; (b_v_bi + 1)
12a1 : d0 f6 __ BNE $1299 ; (main.s46 + 5)
.s48:
12a3 : a5 57 __ LDA T1 + 0 
12a5 : cd 08 24 CMP $2408 ; (b_v_bi + 0)
12a8 : 4c 75 11 JMP $1175 ; (main.s49 + 0)
.s74:
12ab : ad 36 23 LDA $2336 ; (b_gosubSP + 0)
12ae : 85 43 __ STA T2 + 0 
12b0 : 18 __ __ CLC
12b1 : 69 01 __ ADC #$01
12b3 : 8d 36 23 STA $2336 ; (b_gosubSP + 0)
12b6 : ad 37 23 LDA $2337 ; (b_gosubSP + 1)
12b9 : 85 44 __ STA T2 + 1 
12bb : 69 00 __ ADC #$00
12bd : 8d 37 23 STA $2337 ; (b_gosubSP + 1)
12c0 : 06 43 __ ASL T2 + 0 
12c2 : 26 44 __ ROL T2 + 1 
12c4 : 18 __ __ CLC
12c5 : a9 12 __ LDA #$12
12c7 : 65 43 __ ADC T2 + 0 
12c9 : 85 43 __ STA T2 + 0 
12cb : a9 2e __ LDA #$2e
12cd : 65 44 __ ADC T2 + 1 
12cf : 85 44 __ STA T2 + 1 
12d1 : a9 03 __ LDA #$03
12d3 : a0 00 __ LDY #$00
12d5 : 91 43 __ STA (T2 + 0),y 
12d7 : 98 __ __ TYA
12d8 : c8 __ __ INY
12d9 : 91 43 __ STA (T2 + 0),y 
12db : 18 __ __ CLC
12dc : a9 0c __ LDA #$0c
12de : 65 53 __ ADC T0 + 0 
12e0 : 85 53 __ STA T0 + 0 
12e2 : a9 26 __ LDA #$26
12e4 : 65 54 __ ADC T0 + 1 
12e6 : 85 54 __ STA T0 + 1 
12e8 : 88 __ __ DEY
12e9 : b1 53 __ LDA (T0 + 0),y 
12eb : aa __ __ TAX
12ec : c8 __ __ INY
12ed : b1 53 __ LDA (T0 + 0),y 
12ef : 85 44 __ STA T2 + 1 
12f1 : d0 07 __ BNE $12fa ; (main.s76 + 0)
.s78:
12f3 : e0 18 __ CPX #$18
12f5 : d0 03 __ BNE $12fa ; (main.s76 + 0)
.s75:
12f7 : 98 __ __ TYA
12f8 : d0 02 __ BNE $12fc ; (main.s77 + 0)
.s76:
12fa : a9 00 __ LDA #$00
.s77:
12fc : 49 ff __ EOR #$ff
12fe : c9 ff __ CMP #$ff
1300 : d0 0c __ BNE $130e ; (main.s92 + 0)
.s79:
1302 : 8a __ __ TXA
1303 : 69 00 __ ADC #$00
1305 : 85 57 __ STA T1 + 0 
1307 : a5 44 __ LDA T2 + 1 
1309 : 69 00 __ ADC #$00
130b : 4c f3 0f JMP $0ff3 ; (main.s80 + 0)
.s92:
130e : a9 17 __ LDA #$17
.l93:
1310 : a0 00 __ LDY #$00
1312 : 91 53 __ STA (T0 + 0),y 
1314 : 98 __ __ TYA
1315 : c8 __ __ INY
1316 : 91 53 __ STA (T0 + 0),y 
1318 : a8 __ __ TAY
1319 : 91 57 __ STA (T1 + 0),y 
131b : 4c e2 0f JMP $0fe2 ; (main.l139 + 0)
.l33:
131e : ad 08 24 LDA $2408 ; (b_v_bi + 0)
1321 : 0a __ __ ASL
1322 : 85 53 __ STA T0 + 0 
1324 : ad 09 24 LDA $2409 ; (b_v_bi + 1)
1327 : 2a __ __ ROL
1328 : 85 54 __ STA T0 + 1 
132a : 18 __ __ CLC
132b : a9 0c __ LDA #$0c
132d : 65 53 __ ADC T0 + 0 
132f : 85 57 __ STA T1 + 0 
1331 : a9 2a __ LDA #$2a
1333 : 65 54 __ ADC T0 + 1 
1335 : 85 58 __ STA T1 + 1 
1337 : a0 01 __ LDY #$01
1339 : b1 57 __ LDA (T1 + 0),y 
133b : d0 07 __ BNE $1344 ; (main.s34 + 0)
.s36:
133d : a8 __ __ TAY
133e : b1 57 __ LDA (T1 + 0),y 
1340 : c9 01 __ CMP #$01
1342 : f0 02 __ BEQ $1346 ; (main.s35 + 0)
.s34:
1344 : a9 00 __ LDA #$00
.s35:
1346 : 49 ff __ EOR #$ff
1348 : c9 ff __ CMP #$ff
134a : d0 03 __ BNE $134f ; (main.s97 + 0)
134c : 4c 76 0f JMP $0f76 ; (main.s37 + 0)
.s97:
134f : ad 36 23 LDA $2336 ; (b_gosubSP + 0)
1352 : 85 43 __ STA T2 + 0 
1354 : 18 __ __ CLC
1355 : 69 01 __ ADC #$01
1357 : 8d 36 23 STA $2336 ; (b_gosubSP + 0)
135a : ad 37 23 LDA $2337 ; (b_gosubSP + 1)
135d : 85 44 __ STA T2 + 1 
135f : 69 00 __ ADC #$00
1361 : 8d 37 23 STA $2337 ; (b_gosubSP + 1)
1364 : 06 43 __ ASL T2 + 0 
1366 : 26 44 __ ROL T2 + 1 
1368 : 18 __ __ CLC
1369 : a9 12 __ LDA #$12
136b : 65 43 __ ADC T2 + 0 
136d : 85 43 __ STA T2 + 0 
136f : a9 2e __ LDA #$2e
1371 : 65 44 __ ADC T2 + 1 
1373 : 85 44 __ STA T2 + 1 
1375 : a9 01 __ LDA #$01
1377 : a0 00 __ LDY #$00
1379 : 91 43 __ STA (T2 + 0),y 
137b : 98 __ __ TYA
137c : c8 __ __ INY
137d : 91 43 __ STA (T2 + 0),y 
137f : 18 __ __ CLC
1380 : a9 0c __ LDA #$0c
1382 : 65 53 __ ADC T0 + 0 
1384 : 85 53 __ STA T0 + 0 
1386 : a9 24 __ LDA #$24
1388 : 65 54 __ ADC T0 + 1 
138a : 85 54 __ STA T0 + 1 
138c : 88 __ __ DEY
138d : b1 53 __ LDA (T0 + 0),y 
138f : aa __ __ TAX
1390 : c8 __ __ INY
1391 : b1 53 __ LDA (T0 + 0),y 
1393 : 85 44 __ STA T2 + 1 
1395 : d0 07 __ BNE $139e ; (main.s99 + 0)
.s101:
1397 : e0 27 __ CPX #$27
1399 : d0 03 __ BNE $139e ; (main.s99 + 0)
.s98:
139b : 98 __ __ TYA
139c : d0 02 __ BNE $13a0 ; (main.s100 + 0)
.s99:
139e : a9 00 __ LDA #$00
.s100:
13a0 : 49 ff __ EOR #$ff
13a2 : c9 ff __ CMP #$ff
13a4 : d0 03 __ BNE $13a9 ; (main.s102 + 0)
13a6 : 4c 02 13 JMP $1302 ; (main.s79 + 0)
.s102:
13a9 : a9 26 __ LDA #$26
13ab : 4c 10 13 JMP $1310 ; (main.l93 + 0)
.s83:
13ae : a8 __ __ TAY
13af : f0 03 __ BEQ $13b4 ; (main.s85 + 0)
13b1 : 4c 65 0f JMP $0f65 ; (main.s84 + 0)
.s85:
13b4 : e0 03 __ CPX #$03
13b6 : d0 f9 __ BNE $13b1 ; (main.s83 + 3)
13b8 : 4c 2e 10 JMP $102e ; (main.s42 + 0)
.s90:
13bb : e0 02 __ CPX #$02
13bd : d0 03 __ BNE $13c2 ; (main.s89 + 0)
13bf : 4c ff 0f JMP $0fff ; (main.s38 + 0)
.s89:
13c2 : b0 ea __ BCS $13ae ; (main.s83 + 0)
13c4 : 4c 55 0f JMP $0f55 ; (main.s86 + 0)
--------------------------------------------------------------------
b_init: ; b_init()->void
; 245, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
13c7 : ad 30 23 LDA $2330 ; (b_mem + 0)
13ca : 85 43 __ STA T1 + 0 
13cc : 85 45 __ STA T2 + 0 
13ce : 85 1f __ STA ADDR + 0 
13d0 : ad 31 23 LDA $2331 ; (b_mem + 1)
13d3 : 85 44 __ STA T1 + 1 
13d5 : 18 __ __ CLC
13d6 : 69 dd __ ADC #$dd
13d8 : 85 20 __ STA ADDR + 1 
13da : a9 03 __ LDA #$03
13dc : a0 00 __ LDY #$00
13de : 91 1f __ STA (ADDR + 0),y 
13e0 : 18 __ __ CLC
13e1 : a5 44 __ LDA T1 + 1 
13e3 : 69 d0 __ ADC #$d0
13e5 : 85 20 __ STA ADDR + 1 
13e7 : a9 15 __ LDA #$15
13e9 : a0 18 __ LDY #$18
13eb : 91 1f __ STA (ADDR + 0),y 
13ed : 18 __ __ CLC
13ee : a5 44 __ LDA T1 + 1 
13f0 : 69 02 __ ADC #$02
13f2 : 85 20 __ STA ADDR + 1 
13f4 : a9 0e __ LDA #$0e
13f6 : a0 86 __ LDY #$86
13f8 : 91 1f __ STA (ADDR + 0),y 
13fa : 18 __ __ CLC
13fb : a5 44 __ LDA T1 + 1 
13fd : 69 d8 __ ADC #$d8
13ff : 85 46 __ STA T2 + 1 
1401 : a9 00 __ LDA #$00
1403 : 85 47 __ STA T3 + 0 
1405 : 85 48 __ STA T3 + 1 
.l5:
1407 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
140a : 18 __ __ CLC
140b : a5 43 __ LDA T1 + 0 
140d : 65 1b __ ADC ACCU + 0 
140f : 85 1b __ STA ACCU + 0 
1411 : a5 44 __ LDA T1 + 1 
1413 : 65 1c __ ADC ACCU + 1 
1415 : 18 __ __ CLC
1416 : 65 48 __ ADC T3 + 1 
1418 : 85 1c __ STA ACCU + 1 
141a : a9 20 __ LDA #$20
141c : a4 47 __ LDY T3 + 0 
141e : 91 1b __ STA (ACCU + 0),y 
1420 : a9 0e __ LDA #$0e
1422 : a0 00 __ LDY #$00
1424 : 91 45 __ STA (T2 + 0),y 
1426 : e6 45 __ INC T2 + 0 
1428 : d0 02 __ BNE $142c ; (b_init.s9 + 0)
.s8:
142a : e6 46 __ INC T2 + 1 
.s9:
142c : e6 47 __ INC T3 + 0 
142e : d0 02 __ BNE $1432 ; (b_init.s11 + 0)
.s10:
1430 : e6 48 __ INC T3 + 1 
.s11:
1432 : a5 48 __ LDA T3 + 1 
1434 : c9 03 __ CMP #$03
1436 : d0 cf __ BNE $1407 ; (b_init.l5 + 0)
.s7:
1438 : a5 47 __ LDA T3 + 0 
143a : c9 e8 __ CMP #$e8
143c : d0 c9 __ BNE $1407 ; (b_init.l5 + 0)
.s6:
143e : a5 43 __ LDA T1 + 0 
1440 : 85 1f __ STA ADDR + 0 
1442 : a5 44 __ LDA T1 + 1 
1444 : 69 cf __ ADC #$cf
1446 : 85 20 __ STA ADDR + 1 
1448 : a9 0e __ LDA #$0e
144a : a0 20 __ LDY #$20
144c : 91 1f __ STA (ADDR + 0),y 
144e : a9 06 __ LDA #$06
1450 : c8 __ __ INY
1451 : 91 1f __ STA (ADDR + 0),y 
1453 : a9 00 __ LDA #$00
1455 : a0 c6 __ LDY #$c6
1457 : 91 43 __ STA (T1 + 0),y 
1459 : 8d 36 23 STA $2336 ; (b_gosubSP + 0)
145c : 8d 37 23 STA $2337 ; (b_gosubSP + 1)
145f : 8d 34 23 STA $2334 ; (b_row + 0)
1462 : 8d 35 23 STA $2335 ; (b_row + 1)
1465 : 8d 32 23 STA $2332 ; (b_col + 0)
1468 : 8d 33 23 STA $2333 ; (b_col + 1)
.s3:
146b : 60 __ __ RTS
--------------------------------------------------------------------
b_scr_base: ; b_scr_base()->u16
; 126, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
146c : ad 30 23 LDA $2330 ; (b_mem + 0)
146f : 85 1f __ STA ADDR + 0 
1471 : ad 31 23 LDA $2331 ; (b_mem + 1)
1474 : 18 __ __ CLC
1475 : 69 dd __ ADC #$dd
1477 : 85 20 __ STA ADDR + 1 
1479 : a0 00 __ LDY #$00
147b : 84 1b __ STY ACCU + 0 
147d : b1 1f __ LDA (ADDR + 0),y 
147f : 29 03 __ AND #$03
1481 : 49 03 __ EOR #$03
1483 : aa __ __ TAX
1484 : 18 __ __ CLC
1485 : a5 1f __ LDA ADDR + 0 
1487 : 69 18 __ ADC #$18
1489 : 85 1f __ STA ADDR + 0 
148b : ad 31 23 LDA $2331 ; (b_mem + 1)
148e : 69 d0 __ ADC #$d0
1490 : 85 20 __ STA ADDR + 1 
1492 : b1 1f __ LDA (ADDR + 0),y 
1494 : 29 f0 __ AND #$f0
1496 : 4a __ __ LSR
1497 : 4a __ __ LSR
1498 : 1d 2b 23 ORA $232b,x ; (__multab16384H + 0)
149b : 85 1c __ STA ACCU + 1 
.s3:
149d : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init: ; tsb_init()->void
;1273, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
149e : ad 38 23 LDA $2338 ; (tsb_inited + 0)
14a1 : 0d 39 23 ORA $2339 ; (tsb_inited + 1)
14a4 : d0 18 __ BNE $14be ; (tsb_init.s3 + 0)
.s5:
14a6 : 85 0d __ STA P0 
14a8 : 85 0e __ STA P1 
14aa : 85 10 __ STA P3 
14ac : a9 01 __ LDA #$01
14ae : 85 0f __ STA P2 
14b0 : 8d 38 23 STA $2338 ; (tsb_inited + 0)
14b3 : a9 00 __ LDA #$00
14b5 : 8d 39 23 STA $2339 ; (tsb_inited + 1)
14b8 : 20 bf 14 JSR $14bf ; (tsb_init_tables.s4 + 0)
14bb : 4c cd 14 JMP $14cd ; (tsb_rot.s4 + 0)
.s3:
14be : 60 __ __ RTS
--------------------------------------------------------------------
tsb_init_tables: ; tsb_init_tables()->void
;1261, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
14bf : a2 00 __ LDX #$00
.l5:
14c1 : bd 3a 23 LDA $233a,x ; (tab[0] + 0)
14c4 : 9d be 23 STA $23be,x ; (tsb_sintab[0] + 0)
14c7 : e8 __ __ INX
14c8 : e0 40 __ CPX #$40
14ca : d0 f5 __ BNE $14c1 ; (tsb_init_tables.l5 + 0)
.s3:
14cc : 60 __ __ RTS
--------------------------------------------------------------------
tsb_rot: ; tsb_rot(i16,i16)->void
; 278, "C:/Users/g/claude/cpus/6502/examples/compiler/tsb.h"
.s4:
14cd : a5 0d __ LDA P0 ; (angle + 0)
14cf : 29 07 __ AND #$07
14d1 : 0a __ __ ASL
14d2 : 0a __ __ ASL
14d3 : 0a __ __ ASL
14d4 : aa __ __ TAX
14d5 : a9 00 __ LDA #$00
14d7 : 85 1b __ STA ACCU + 0 
.l5:
14d9 : 8a __ __ TXA
14da : 65 1b __ ADC ACCU + 0 
14dc : a8 __ __ TAY
14dd : b9 7a 23 LDA $237a,y ; (tsb_rottab[0] + 0)
14e0 : a4 1b __ LDY ACCU + 0 
14e2 : c8 __ __ INY
14e3 : 84 1b __ STY ACCU + 0 
14e5 : 99 ff 23 STA $23ff,y ; (b_v_ni + 1)
14e8 : c0 08 __ CPY #$08
14ea : 90 ed __ BCC $14d9 ; (tsb_rot.l5 + 0)
.s3:
14ec : 60 __ __ RTS
--------------------------------------------------------------------
b_putc: ; b_putc(u8)->void
; 309, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
14ed : a5 13 __ LDA P6 ; (c + 0)
14ef : c9 93 __ CMP #$93
14f1 : d0 03 __ BNE $14f6 ; (b_putc.s5 + 0)
14f3 : 4c 84 15 JMP $1584 ; (b_putc.s14 + 0)
.s5:
14f6 : c9 13 __ CMP #$13
14f8 : d0 0d __ BNE $1507 ; (b_putc.s6 + 0)
.s13:
14fa : a9 00 __ LDA #$00
14fc : 8d 34 23 STA $2334 ; (b_row + 0)
14ff : 8d 35 23 STA $2335 ; (b_row + 1)
1502 : 8d 32 23 STA $2332 ; (b_col + 0)
1505 : f0 76 __ BEQ $157d ; (b_putc.s17 + 0)
.s6:
1507 : c9 0d __ CMP #$0d
1509 : f0 76 __ BEQ $1581 ; (b_putc.s12 + 0)
.s7:
150b : ad 33 23 LDA $2333 ; (b_col + 1)
150e : 30 0c __ BMI $151c ; (b_putc.s8 + 0)
.s11:
1510 : d0 07 __ BNE $1519 ; (b_putc.s9 + 0)
.s10:
1512 : ad 32 23 LDA $2332 ; (b_col + 0)
1515 : c9 28 __ CMP #$28
1517 : 90 03 __ BCC $151c ; (b_putc.s8 + 0)
.s9:
1519 : 20 c8 15 JSR $15c8 ; (b_newline.s4 + 0)
.s8:
151c : a5 13 __ LDA P6 ; (c + 0)
151e : 20 24 17 JSR $1724 ; (b_pet2scr.s4 + 0)
1521 : 85 4e __ STA T3 + 0 
1523 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
1526 : ad 30 23 LDA $2330 ; (b_mem + 0)
1529 : 18 __ __ CLC
152a : 65 1b __ ADC ACCU + 0 
152c : 85 4a __ STA T1 + 0 
152e : ad 31 23 LDA $2331 ; (b_mem + 1)
1531 : 65 1c __ ADC ACCU + 1 
1533 : 85 4b __ STA T1 + 1 
1535 : ad 34 23 LDA $2334 ; (b_row + 0)
1538 : 0a __ __ ASL
1539 : 85 07 __ STA WORK + 4 
153b : ad 35 23 LDA $2335 ; (b_row + 1)
153e : 2a __ __ ROL
153f : 06 07 __ ASL WORK + 4 
1541 : 2a __ __ ROL
1542 : aa __ __ TAX
1543 : 18 __ __ CLC
1544 : a5 07 __ LDA WORK + 4 
1546 : 6d 34 23 ADC $2334 ; (b_row + 0)
1549 : 85 1b __ STA ACCU + 0 
154b : 8a __ __ TXA
154c : 6d 35 23 ADC $2335 ; (b_row + 1)
154f : 06 1b __ ASL ACCU + 0 
1551 : 2a __ __ ROL
1552 : 06 1b __ ASL ACCU + 0 
1554 : 2a __ __ ROL
1555 : 06 1b __ ASL ACCU + 0 
1557 : 2a __ __ ROL
1558 : 85 1c __ STA ACCU + 1 
155a : ad 32 23 LDA $2332 ; (b_col + 0)
155d : aa __ __ TAX
155e : 18 __ __ CLC
155f : 65 1b __ ADC ACCU + 0 
1561 : a8 __ __ TAY
1562 : ad 33 23 LDA $2333 ; (b_col + 1)
1565 : 85 4d __ STA T2 + 1 
1567 : 65 1c __ ADC ACCU + 1 
1569 : 18 __ __ CLC
156a : 65 4b __ ADC T1 + 1 
156c : 85 4b __ STA T1 + 1 
156e : a5 4e __ LDA T3 + 0 
1570 : 91 4a __ STA (T1 + 0),y 
1572 : 8a __ __ TXA
1573 : 18 __ __ CLC
1574 : 69 01 __ ADC #$01
1576 : 8d 32 23 STA $2332 ; (b_col + 0)
1579 : a5 4d __ LDA T2 + 1 
157b : 69 00 __ ADC #$00
.s17:
157d : 8d 33 23 STA $2333 ; (b_col + 1)
.s3:
1580 : 60 __ __ RTS
.s12:
1581 : 4c c8 15 JMP $15c8 ; (b_newline.s4 + 0)
.s14:
1584 : a9 00 __ LDA #$00
1586 : 8d 34 23 STA $2334 ; (b_row + 0)
1589 : 8d 35 23 STA $2335 ; (b_row + 1)
158c : 8d 32 23 STA $2332 ; (b_col + 0)
158f : 8d 33 23 STA $2333 ; (b_col + 1)
1592 : 85 4c __ STA T2 + 0 
1594 : 85 4d __ STA T2 + 1 
.l15:
1596 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
1599 : ad 30 23 LDA $2330 ; (b_mem + 0)
159c : 18 __ __ CLC
159d : 65 1b __ ADC ACCU + 0 
159f : 85 4a __ STA T1 + 0 
15a1 : ad 31 23 LDA $2331 ; (b_mem + 1)
15a4 : 65 1c __ ADC ACCU + 1 
15a6 : 18 __ __ CLC
15a7 : 65 4d __ ADC T2 + 1 
15a9 : 85 4b __ STA T1 + 1 
15ab : a9 20 __ LDA #$20
15ad : a4 4c __ LDY T2 + 0 
15af : 91 4a __ STA (T1 + 0),y 
15b1 : 98 __ __ TYA
15b2 : 18 __ __ CLC
15b3 : 69 01 __ ADC #$01
15b5 : 85 4c __ STA T2 + 0 
15b7 : a5 4d __ LDA T2 + 1 
15b9 : 69 00 __ ADC #$00
15bb : 85 4d __ STA T2 + 1 
15bd : c9 03 __ CMP #$03
15bf : d0 d5 __ BNE $1596 ; (b_putc.l15 + 0)
.s16:
15c1 : a5 4c __ LDA T2 + 0 
15c3 : c9 e8 __ CMP #$e8
15c5 : d0 cf __ BNE $1596 ; (b_putc.l15 + 0)
15c7 : 60 __ __ RTS
--------------------------------------------------------------------
b_newline: ; b_newline()->void
; 300, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
15c8 : a9 00 __ LDA #$00
15ca : 8d 32 23 STA $2332 ; (b_col + 0)
15cd : 8d 33 23 STA $2333 ; (b_col + 1)
15d0 : ad 34 23 LDA $2334 ; (b_row + 0)
15d3 : aa __ __ TAX
15d4 : 18 __ __ CLC
15d5 : 69 01 __ ADC #$01
15d7 : 8d 34 23 STA $2334 ; (b_row + 0)
15da : ad 35 23 LDA $2335 ; (b_row + 1)
15dd : a8 __ __ TAY
15de : 69 00 __ ADC #$00
15e0 : 8d 35 23 STA $2335 ; (b_row + 1)
15e3 : 98 __ __ TYA
15e4 : 30 13 __ BMI $15f9 ; (b_newline.s3 + 0)
.s7:
15e6 : d0 04 __ BNE $15ec ; (b_newline.s5 + 0)
.s6:
15e8 : e0 18 __ CPX #$18
15ea : 90 0d __ BCC $15f9 ; (b_newline.s3 + 0)
.s5:
15ec : 20 fa 15 JSR $15fa ; (b_scroll.s4 + 0)
15ef : a9 18 __ LDA #$18
15f1 : 8d 34 23 STA $2334 ; (b_row + 0)
15f4 : a9 00 __ LDA #$00
15f6 : 8d 35 23 STA $2335 ; (b_row + 1)
.s3:
15f9 : 60 __ __ RTS
--------------------------------------------------------------------
b_scroll: ; b_scroll()->void
; 114, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
15fa : a9 c0 __ LDA #$c0
15fc : 85 11 __ STA P4 
15fe : a9 03 __ LDA #$03
1600 : 85 12 __ STA P5 
1602 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
1605 : ad 30 23 LDA $2330 ; (b_mem + 0)
1608 : 85 45 __ STA T1 + 0 
160a : 18 __ __ CLC
160b : 65 1b __ ADC ACCU + 0 
160d : 85 0d __ STA P0 
160f : ad 31 23 LDA $2331 ; (b_mem + 1)
1612 : 85 46 __ STA T1 + 1 
1614 : 65 1c __ ADC ACCU + 1 
1616 : 85 0e __ STA P1 
1618 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
161b : 18 __ __ CLC
161c : a5 45 __ LDA T1 + 0 
161e : 65 1b __ ADC ACCU + 0 
1620 : aa __ __ TAX
1621 : a5 46 __ LDA T1 + 1 
1623 : 65 1c __ ADC ACCU + 1 
1625 : a8 __ __ TAY
1626 : 8a __ __ TXA
1627 : 18 __ __ CLC
1628 : 69 28 __ ADC #$28
162a : 85 0f __ STA P2 
162c : 90 01 __ BCC $162f ; (b_scroll.s7 + 0)
.s6:
162e : c8 __ __ INY
.s7:
162f : 84 10 __ STY P3 
1631 : 20 8f 16 JSR $168f ; (memmove.s4 + 0)
1634 : a9 03 __ LDA #$03
1636 : 85 12 __ STA P5 
1638 : 18 __ __ CLC
1639 : a5 46 __ LDA T1 + 1 
163b : 69 d8 __ ADC #$d8
163d : 85 0e __ STA P1 
163f : a5 45 __ LDA T1 + 0 
1641 : 85 0d __ STA P0 
1643 : 18 __ __ CLC
1644 : 69 28 __ ADC #$28
1646 : 85 0f __ STA P2 
1648 : a5 46 __ LDA T1 + 1 
164a : 69 d8 __ ADC #$d8
164c : 85 10 __ STA P3 
164e : 20 8f 16 JSR $168f ; (memmove.s4 + 0)
1651 : 18 __ __ CLC
1652 : a5 45 __ LDA T1 + 0 
1654 : 69 c0 __ ADC #$c0
1656 : 85 47 __ STA T2 + 0 
1658 : a5 46 __ LDA T1 + 1 
165a : 69 db __ ADC #$db
165c : 85 48 __ STA T2 + 1 
165e : a9 00 __ LDA #$00
1660 : 85 49 __ STA T3 + 0 
.l5:
1662 : 20 6c 14 JSR $146c ; (b_scr_base.s4 + 0)
1665 : 18 __ __ CLC
1666 : a5 45 __ LDA T1 + 0 
1668 : 65 1b __ ADC ACCU + 0 
166a : a8 __ __ TAY
166b : a5 46 __ LDA T1 + 1 
166d : 65 1c __ ADC ACCU + 1 
166f : aa __ __ TAX
1670 : 98 __ __ TYA
1671 : 18 __ __ CLC
1672 : 65 49 __ ADC T3 + 0 
1674 : 85 1f __ STA ADDR + 0 
1676 : 8a __ __ TXA
1677 : 69 03 __ ADC #$03
1679 : 85 20 __ STA ADDR + 1 
167b : a9 20 __ LDA #$20
167d : a0 c0 __ LDY #$c0
167f : 91 1f __ STA (ADDR + 0),y 
1681 : a9 0e __ LDA #$0e
1683 : a4 49 __ LDY T3 + 0 
1685 : 91 47 __ STA (T2 + 0),y 
1687 : c8 __ __ INY
1688 : 84 49 __ STY T3 + 0 
168a : c0 28 __ CPY #$28
168c : 90 d4 __ BCC $1662 ; (b_scroll.l5 + 0)
.s3:
168e : 60 __ __ RTS
--------------------------------------------------------------------
memmove: ; memmove(void*,const void*,i16)->void*
;  34, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
168f : a5 12 __ LDA P5 ; (size + 1)
1691 : 30 65 __ BMI $16f8 ; (memmove.s5 + 0)
.s14:
1693 : 05 11 __ ORA P4 ; (size + 0)
1695 : f0 61 __ BEQ $16f8 ; (memmove.s5 + 0)
.s6:
1697 : a5 0d __ LDA P0 ; (dst + 0)
1699 : 85 1b __ STA ACCU + 0 
169b : a5 0f __ LDA P2 ; (src + 0)
169d : 85 43 __ STA T3 + 0 
169f : a5 0e __ LDA P1 ; (dst + 1)
16a1 : 85 1c __ STA ACCU + 1 
16a3 : a6 10 __ LDX P3 ; (src + 1)
16a5 : 86 44 __ STX T3 + 1 
16a7 : c5 10 __ CMP P3 ; (src + 1)
16a9 : d0 04 __ BNE $16af ; (memmove.s13 + 0)
.s12:
16ab : a5 0d __ LDA P0 ; (dst + 0)
16ad : c5 0f __ CMP P2 ; (src + 0)
.s13:
16af : 90 50 __ BCC $1701 ; (memmove.s11 + 0)
.s7:
16b1 : e4 0e __ CPX P1 ; (dst + 1)
16b3 : d0 04 __ BNE $16b9 ; (memmove.s10 + 0)
.s9:
16b5 : a5 0f __ LDA P2 ; (src + 0)
16b7 : c5 0d __ CMP P0 ; (dst + 0)
.s10:
16b9 : b0 3d __ BCS $16f8 ; (memmove.s5 + 0)
.s8:
16bb : a5 0f __ LDA P2 ; (src + 0)
16bd : 65 11 __ ADC P4 ; (size + 0)
16bf : 85 43 __ STA T3 + 0 
16c1 : 8a __ __ TXA
16c2 : 65 12 __ ADC P5 ; (size + 1)
16c4 : 85 44 __ STA T3 + 1 
16c6 : 18 __ __ CLC
16c7 : a5 0d __ LDA P0 ; (dst + 0)
16c9 : 65 11 __ ADC P4 ; (size + 0)
16cb : 85 1b __ STA ACCU + 0 
16cd : a5 0e __ LDA P1 ; (dst + 1)
16cf : 65 12 __ ADC P5 ; (size + 1)
16d1 : 85 1c __ STA ACCU + 1 
16d3 : a0 00 __ LDY #$00
16d5 : a5 11 __ LDA P4 ; (size + 0)
16d7 : f0 02 __ BEQ $16db ; (memmove.s30 + 0)
.s16:
16d9 : e6 12 __ INC P5 ; (size + 1)
.s30:
16db : a6 11 __ LDX P4 ; (size + 0)
.l19:
16dd : a5 43 __ LDA T3 + 0 
16df : d0 02 __ BNE $16e3 ; (memmove.s26 + 0)
.s25:
16e1 : c6 44 __ DEC T3 + 1 
.s26:
16e3 : c6 43 __ DEC T3 + 0 
16e5 : a5 1b __ LDA ACCU + 0 
16e7 : d0 02 __ BNE $16eb ; (memmove.s28 + 0)
.s27:
16e9 : c6 1c __ DEC ACCU + 1 
.s28:
16eb : c6 1b __ DEC ACCU + 0 
16ed : b1 43 __ LDA (T3 + 0),y 
16ef : 91 1b __ STA (ACCU + 0),y 
16f1 : ca __ __ DEX
16f2 : d0 e9 __ BNE $16dd ; (memmove.l19 + 0)
.s20:
16f4 : c6 12 __ DEC P5 ; (size + 1)
16f6 : d0 e5 __ BNE $16dd ; (memmove.l19 + 0)
.s5:
16f8 : a5 0d __ LDA P0 ; (dst + 0)
16fa : 85 1b __ STA ACCU + 0 
16fc : a5 0e __ LDA P1 ; (dst + 1)
16fe : 85 1c __ STA ACCU + 1 
.s3:
1700 : 60 __ __ RTS
.s11:
1701 : a0 00 __ LDY #$00
1703 : a5 11 __ LDA P4 ; (size + 0)
1705 : f0 02 __ BEQ $1709 ; (memmove.s29 + 0)
.s15:
1707 : e6 12 __ INC P5 ; (size + 1)
.s29:
1709 : a6 11 __ LDX P4 ; (size + 0)
.l17:
170b : b1 43 __ LDA (T3 + 0),y 
170d : 91 1b __ STA (ACCU + 0),y 
170f : e6 43 __ INC T3 + 0 
1711 : d0 02 __ BNE $1715 ; (memmove.s22 + 0)
.s21:
1713 : e6 44 __ INC T3 + 1 
.s22:
1715 : e6 1b __ INC ACCU + 0 
1717 : d0 02 __ BNE $171b ; (memmove.s24 + 0)
.s23:
1719 : e6 1c __ INC ACCU + 1 
.s24:
171b : ca __ __ DEX
171c : d0 ed __ BNE $170b ; (memmove.l17 + 0)
.s18:
171e : c6 12 __ DEC P5 ; (size + 1)
1720 : d0 e9 __ BNE $170b ; (memmove.l17 + 0)
1722 : f0 d4 __ BEQ $16f8 ; (memmove.s5 + 0)
--------------------------------------------------------------------
b_pet2scr: ; b_pet2scr(u8)->u8
; 119, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
1724 : c9 41 __ CMP #$41
1726 : 90 06 __ BCC $172e ; (b_pet2scr.s3 + 0)
.s8:
1728 : c9 5b __ CMP #$5b
172a : b0 03 __ BCS $172f ; (b_pet2scr.s5 + 0)
.s9:
172c : e9 3f __ SBC #$3f
.s3:
172e : 60 __ __ RTS
.s5:
172f : c9 c1 __ CMP #$c1
1731 : 90 fb __ BCC $172e ; (b_pet2scr.s3 + 0)
.s6:
1733 : c9 db __ CMP #$db
1735 : b0 f7 __ BCS $172e ; (b_pet2scr.s3 + 0)
.s7:
1737 : e9 bf __ SBC #$bf
1739 : 60 __ __ RTS
--------------------------------------------------------------------
b_jiffy: ; b_jiffy()->float
; 133, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
173a : ad 30 23 LDA $2330 ; (b_mem + 0)
173d : 85 43 __ STA T2 + 0 
173f : ad 31 23 LDA $2331 ; (b_mem + 1)
1742 : 85 44 __ STA T2 + 1 
1744 : a0 a2 __ LDY #$a2
1746 : b1 43 __ LDA (T2 + 0),y 
1748 : 85 1b __ STA ACCU + 0 
174a : 88 __ __ DEY
174b : b1 43 __ LDA (T2 + 0),y 
174d : 85 1c __ STA ACCU + 1 
174f : 88 __ __ DEY
1750 : b1 43 __ LDA (T2 + 0),y 
1752 : 85 1d __ STA ACCU + 2 
1754 : a9 00 __ LDA #$00
1756 : 85 1e __ STA ACCU + 3 
1758 : 4c cc 20 JMP $20cc ; (uint32_to_float + 0)
--------------------------------------------------------------------
b_ftoa: ; b_ftoa(u8*,float)->void
; 559, "C:/Users/g/claude/cpus/6502/examples/compiler/runtime.h"
.s4:
175b : a9 00 __ LDA #$00
175d : 85 49 __ STA T2 + 0 
175f : 85 4a __ STA T2 + 1 
1761 : a5 0f __ LDA P2 ; (v + 0)
1763 : 85 43 __ STA T0 + 0 
1765 : a5 10 __ LDA P3 ; (v + 1)
1767 : 85 44 __ STA T0 + 1 
1769 : a5 12 __ LDA P5 ; (v + 3)
176b : 29 7f __ AND #$7f
176d : 05 11 __ ORA P4 ; (v + 2)
176f : 05 10 __ ORA P3 ; (v + 1)
1771 : a6 11 __ LDX P4 ; (v + 2)
1773 : 86 45 __ STX T0 + 2 
1775 : 05 0f __ ORA P2 ; (v + 0)
1777 : d0 05 __ BNE $177e ; (b_ftoa.s78 + 0)
.s127:
1779 : a5 12 __ LDA P5 ; (v + 3)
177b : 4c 85 17 JMP $1785 ; (b_ftoa.s5 + 0)
.s78:
177e : a5 12 __ LDA P5 ; (v + 3)
1780 : 10 03 __ BPL $1785 ; (b_ftoa.s5 + 0)
1782 : 4c b2 1b JMP $1bb2 ; (b_ftoa.s76 + 0)
.s5:
1785 : 29 7f __ AND #$7f
1787 : 05 11 __ ORA P4 ; (v + 2)
1789 : 05 10 __ ORA P3 ; (v + 1)
178b : 05 0f __ ORA P2 ; (v + 0)
178d : d0 03 __ BNE $1792 ; (b_ftoa.s6 + 0)
178f : 4c a7 1b JMP $1ba7 ; (b_ftoa.s75 + 0)
.s6:
1792 : a9 00 __ LDA #$00
.s7:
1794 : 85 4b __ STA T3 + 0 
1796 : a5 12 __ LDA P5 ; (v + 3)
1798 : 85 46 __ STA T0 + 3 
179a : 30 1c __ BMI $17b8 ; (b_ftoa.s8 + 0)
.s70:
179c : c9 41 __ CMP #$41
179e : d0 0d __ BNE $17ad ; (b_ftoa.s74 + 0)
.s71:
17a0 : e0 20 __ CPX #$20
17a2 : d0 09 __ BNE $17ad ; (b_ftoa.s74 + 0)
.s72:
17a4 : a5 10 __ LDA P3 ; (v + 1)
17a6 : 38 __ __ SEC
17a7 : d0 04 __ BNE $17ad ; (b_ftoa.s74 + 0)
.s73:
17a9 : a5 0f __ LDA P2 ; (v + 0)
17ab : f0 02 __ BEQ $17af ; (b_ftoa.s61 + 0)
.s74:
17ad : 90 09 __ BCC $17b8 ; (b_ftoa.s8 + 0)
.s61:
17af : a9 00 __ LDA #$00
17b1 : 85 47 __ STA T1 + 0 
17b3 : 85 48 __ STA T1 + 1 
17b5 : 4c 41 1b JMP $1b41 ; (b_ftoa.l62 + 0)
.s8:
17b8 : a5 12 __ LDA P5 ; (v + 3)
17ba : 30 13 __ BMI $17cf ; (b_ftoa.s47 + 0)
.s56:
17bc : c9 3f __ CMP #$3f
17be : d0 0d __ BNE $17cd ; (b_ftoa.s60 + 0)
.s57:
17c0 : e0 80 __ CPX #$80
17c2 : d0 09 __ BNE $17cd ; (b_ftoa.s60 + 0)
.s58:
17c4 : a5 10 __ LDA P3 ; (v + 1)
17c6 : 38 __ __ SEC
17c7 : d0 04 __ BNE $17cd ; (b_ftoa.s60 + 0)
.s59:
17c9 : a5 0f __ LDA P2 ; (v + 0)
17cb : f0 5c __ BEQ $1829 ; (b_ftoa.s9 + 0)
.s60:
17cd : b0 5a __ BCS $1829 ; (b_ftoa.s9 + 0)
.s47:
17cf : a9 00 __ LDA #$00
17d1 : 85 47 __ STA T1 + 0 
17d3 : 85 48 __ STA T1 + 1 
.l48:
17d5 : a5 49 __ LDA T2 + 0 
17d7 : d0 02 __ BNE $17db ; (b_ftoa.s92 + 0)
.s91:
17d9 : c6 4a __ DEC T2 + 1 
.s92:
17db : c6 49 __ DEC T2 + 0 
17dd : a9 00 __ LDA #$00
17df : 85 1b __ STA ACCU + 0 
17e1 : 85 1c __ STA ACCU + 1 
17e3 : a9 20 __ LDA #$20
17e5 : 85 1d __ STA ACCU + 2 
17e7 : a9 41 __ LDA #$41
17e9 : 85 1e __ STA ACCU + 3 
17eb : a2 43 __ LDX #$43
17ed : 20 3d 1c JSR $1c3d ; (freg + 4)
17f0 : 20 6b 1d JSR $1d6b ; (crt_fmul + 0)
17f3 : a5 1b __ LDA ACCU + 0 
17f5 : 85 43 __ STA T0 + 0 
17f7 : a5 1c __ LDA ACCU + 1 
17f9 : 85 44 __ STA T0 + 1 
17fb : a6 1d __ LDX ACCU + 2 
17fd : 86 45 __ STX T0 + 2 
17ff : a5 1e __ LDA ACCU + 3 
1801 : 85 46 __ STA T0 + 3 
1803 : 30 13 __ BMI $1818 ; (b_ftoa.s49 + 0)
.s51:
1805 : c9 3f __ CMP #$3f
1807 : d0 0d __ BNE $1816 ; (b_ftoa.s55 + 0)
.s52:
1809 : e0 80 __ CPX #$80
180b : d0 09 __ BNE $1816 ; (b_ftoa.s55 + 0)
.s53:
180d : a5 1c __ LDA ACCU + 1 
180f : 38 __ __ SEC
1810 : d0 04 __ BNE $1816 ; (b_ftoa.s55 + 0)
.s54:
1812 : a5 1b __ LDA ACCU + 0 
1814 : f0 13 __ BEQ $1829 ; (b_ftoa.s9 + 0)
.s55:
1816 : b0 11 __ BCS $1829 ; (b_ftoa.s9 + 0)
.s49:
1818 : e6 47 __ INC T1 + 0 
181a : d0 02 __ BNE $181e ; (b_ftoa.s94 + 0)
.s93:
181c : e6 48 __ INC T1 + 1 
.s94:
181e : a6 48 __ LDX T1 + 1 
1820 : ca __ __ DEX
1821 : d0 b2 __ BNE $17d5 ; (b_ftoa.l48 + 0)
.s50:
1823 : a5 47 __ LDA T1 + 0 
1825 : c9 90 __ CMP #$90
1827 : d0 ac __ BNE $17d5 ; (b_ftoa.l48 + 0)
.s9:
1829 : a9 08 __ LDA #$08
182b : 85 4d __ STA T4 + 0 
182d : a9 4c __ LDA #$4c
182f : 85 1e __ STA ACCU + 3 
1831 : a9 20 __ LDA #$20
1833 : 85 1b __ STA ACCU + 0 
1835 : a9 bc __ LDA #$bc
1837 : 85 1c __ STA ACCU + 1 
1839 : a9 be __ LDA #$be
183b : 85 1d __ STA ACCU + 2 
183d : a2 43 __ LDX #$43
183f : 20 3d 1c JSR $1c3d ; (freg + 4)
1842 : 20 6b 1d JSR $1d6b ; (crt_fmul + 0)
1845 : a9 00 __ LDA #$00
1847 : 85 03 __ STA WORK + 0 
1849 : 85 04 __ STA WORK + 1 
184b : 85 05 __ STA WORK + 2 
184d : a9 3f __ LDA #$3f
184f : 85 06 __ STA WORK + 3 
1851 : 20 4d 1c JSR $1c4d ; (freg + 20)
1854 : 20 84 1c JSR $1c84 ; (faddsub + 6)
1857 : 20 fc 1f JSR $1ffc ; (f32_to_i32 + 0)
185a : a5 1b __ LDA ACCU + 0 
185c : 85 43 __ STA T0 + 0 
185e : a5 1c __ LDA ACCU + 1 
1860 : 85 44 __ STA T0 + 1 
1862 : a5 1e __ LDA ACCU + 3 
1864 : 85 46 __ STA T0 + 3 
1866 : 49 80 __ EOR #$80
1868 : a6 1d __ LDX ACCU + 2 
186a : 86 45 __ STX T0 + 2 
186c : c9 bb __ CMP #$bb
186e : d0 0a __ BNE $187a ; (b_ftoa.s46 + 0)
.s44:
1870 : e0 9a __ CPX #$9a
1872 : d0 06 __ BNE $187a ; (b_ftoa.s46 + 0)
.s45:
1874 : a5 1c __ LDA ACCU + 1 
1876 : c9 ca __ CMP #$ca
1878 : f0 02 __ BEQ $187c ; (b_ftoa.s43 + 0)
.s46:
187a : 90 16 __ BCC $1892 ; (b_ftoa.s10 + 0)
.s43:
187c : e6 49 __ INC T2 + 0 
187e : d0 02 __ BNE $1882 ; (b_ftoa.s96 + 0)
.s95:
1880 : e6 4a __ INC T2 + 1 
.s96:
1882 : a9 00 __ LDA #$00
1884 : 85 43 __ STA T0 + 0 
1886 : a9 e1 __ LDA #$e1
1888 : 85 44 __ STA T0 + 1 
188a : a9 f5 __ LDA #$f5
188c : 85 45 __ STA T0 + 2 
188e : a9 05 __ LDA #$05
1890 : 85 46 __ STA T0 + 3 
.s10:
1892 : a5 43 __ LDA T0 + 0 
1894 : 85 1b __ STA ACCU + 0 
1896 : a5 44 __ LDA T0 + 1 
1898 : 85 1c __ STA ACCU + 1 
189a : a5 45 __ LDA T0 + 2 
189c : 85 1d __ STA ACCU + 2 
189e : a5 46 __ LDA T0 + 3 
18a0 : 85 1e __ STA ACCU + 3 
.l79:
18a2 : a9 00 __ LDA #$00
18a4 : 85 04 __ STA WORK + 1 
18a6 : 85 05 __ STA WORK + 2 
18a8 : 85 06 __ STA WORK + 3 
18aa : a9 0a __ LDA #$0a
18ac : 85 03 __ STA WORK + 0 
18ae : 20 f0 22 JSR $22f0 ; (mods32 + 0)
18b1 : 18 __ __ CLC
18b2 : a5 07 __ LDA WORK + 4 
18b4 : 69 30 __ ADC #$30
18b6 : a6 4d __ LDX T4 + 0 
18b8 : 9d f0 9f STA $9ff0,x ; (d[0] + 0)
18bb : a5 43 __ LDA T0 + 0 
18bd : 85 1b __ STA ACCU + 0 
18bf : a5 44 __ LDA T0 + 1 
18c1 : 85 1c __ STA ACCU + 1 
18c3 : a5 45 __ LDA T0 + 2 
18c5 : 85 1d __ STA ACCU + 2 
18c7 : a5 46 __ LDA T0 + 3 
18c9 : 85 1e __ STA ACCU + 3 
18cb : a9 00 __ LDA #$00
18cd : 85 04 __ STA WORK + 1 
18cf : 85 05 __ STA WORK + 2 
18d1 : 85 06 __ STA WORK + 3 
18d3 : a9 0a __ LDA #$0a
18d5 : 85 03 __ STA WORK + 0 
18d7 : 20 c7 21 JSR $21c7 ; (divs32 + 0)
18da : a5 1b __ LDA ACCU + 0 
18dc : 85 43 __ STA T0 + 0 
18de : a5 1c __ LDA ACCU + 1 
18e0 : 85 44 __ STA T0 + 1 
18e2 : a5 1d __ LDA ACCU + 2 
18e4 : 85 45 __ STA T0 + 2 
18e6 : a5 1e __ LDA ACCU + 3 
18e8 : 85 46 __ STA T0 + 3 
18ea : c6 4d __ DEC T4 + 0 
18ec : 10 b4 __ BPL $18a2 ; (b_ftoa.l79 + 0)
.s11:
18ee : a9 00 __ LDA #$00
18f0 : 8d f9 9f STA $9ff9 ; (d[0] + 9)
18f3 : a2 09 __ LDX #$09
.l12:
18f5 : bd ef 9f LDA $9fef,x ; (eb[0] + 7)
18f8 : c9 30 __ CMP #$30
18fa : d0 05 __ BNE $1901 ; (b_ftoa.s87 + 0)
.s42:
18fc : ca __ __ DEX
18fd : e0 02 __ CPX #$02
18ff : b0 f4 __ BCS $18f5 ; (b_ftoa.l12 + 0)
.s87:
1901 : 86 43 __ STX T0 + 0 
1903 : a5 4b __ LDA T3 + 0 
1905 : f0 0d __ BEQ $1914 ; (b_ftoa.s13 + 0)
.s41:
1907 : a9 2d __ LDA #$2d
1909 : a0 00 __ LDY #$00
190b : 91 0d __ STA (P0),y ; (buf + 0)
190d : a9 01 __ LDA #$01
190f : 85 47 __ STA T1 + 0 
1911 : 98 __ __ TYA
1912 : f0 02 __ BEQ $1916 ; (b_ftoa.s14 + 0)
.s13:
1914 : 85 47 __ STA T1 + 0 
.s14:
1916 : 85 48 __ STA T1 + 1 
1918 : a5 4a __ LDA T2 + 1 
191a : 49 80 __ EOR #$80
191c : c9 7f __ CMP #$7f
191e : d0 04 __ BNE $1924 ; (b_ftoa.s40 + 0)
.s39:
1920 : a5 49 __ LDA T2 + 0 
1922 : c9 fc __ CMP #$fc
.s40:
1924 : b0 03 __ BCS $1929 ; (b_ftoa.s26 + 0)
1926 : 4c 43 1a JMP $1a43 ; (b_ftoa.s15 + 0)
.s26:
1929 : a5 4a __ LDA T2 + 1 
192b : 30 08 __ BMI $1935 ; (b_ftoa.s27 + 0)
.s38:
192d : d0 f7 __ BNE $1926 ; (b_ftoa.s40 + 2)
.s37:
192f : a5 49 __ LDA T2 + 0 
1931 : c9 09 __ CMP #$09
1933 : b0 f1 __ BCS $1926 ; (b_ftoa.s40 + 2)
.s27:
1935 : 18 __ __ CLC
1936 : a5 0d __ LDA P0 ; (buf + 0)
1938 : 65 47 __ ADC T1 + 0 
193a : 85 4d __ STA T4 + 0 
193c : a5 0e __ LDA P1 ; (buf + 1)
193e : 69 00 __ ADC #$00
1940 : 85 4e __ STA T4 + 1 
1942 : a5 49 __ LDA T2 + 0 
1944 : 10 6f __ BPL $19b5 ; (b_ftoa.s31 + 0)
.s28:
1946 : a9 30 __ LDA #$30
1948 : a4 47 __ LDY T1 + 0 
194a : 91 0d __ STA (P0),y ; (buf + 0)
194c : a9 2e __ LDA #$2e
194e : a0 01 __ LDY #$01
1950 : 91 4d __ STA (T4 + 0),y 
1952 : a5 47 __ LDA T1 + 0 
1954 : 09 02 __ ORA #$02
1956 : 85 47 __ STA T1 + 0 
1958 : a9 00 __ LDA #$00
195a : 38 __ __ SEC
195b : e5 49 __ SBC T2 + 0 
195d : aa __ __ TAX
195e : ca __ __ DEX
195f : f0 22 __ BEQ $1983 ; (b_ftoa.s29 + 0)
.s30:
1961 : 18 __ __ CLC
1962 : a5 0d __ LDA P0 ; (buf + 0)
1964 : 65 47 __ ADC T1 + 0 
1966 : a8 __ __ TAY
1967 : a9 00 __ LDA #$00
1969 : 85 4d __ STA T4 + 0 
196b : a5 0e __ LDA P1 ; (buf + 1)
196d : 69 00 __ ADC #$00
196f : 85 4e __ STA T4 + 1 
.l84:
1971 : a9 30 __ LDA #$30
1973 : 91 4d __ STA (T4 + 0),y 
1975 : e6 47 __ INC T1 + 0 
1977 : d0 02 __ BNE $197b ; (b_ftoa.s120 + 0)
.s119:
1979 : e6 48 __ INC T1 + 1 
.s120:
197b : c8 __ __ INY
197c : d0 02 __ BNE $1980 ; (b_ftoa.s122 + 0)
.s121:
197e : e6 4e __ INC T4 + 1 
.s122:
1980 : ca __ __ DEX
1981 : d0 ee __ BNE $1971 ; (b_ftoa.l84 + 0)
.s29:
1983 : a5 0d __ LDA P0 ; (buf + 0)
.s85:
1985 : 18 __ __ CLC
1986 : 65 47 __ ADC T1 + 0 
1988 : 85 4b __ STA T3 + 0 
198a : a5 0e __ LDA P1 ; (buf + 1)
198c : 65 48 __ ADC T1 + 1 
198e : 85 4c __ STA T3 + 1 
1990 : a0 00 __ LDY #$00
.l89:
1992 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1995 : 91 4b __ STA (T3 + 0),y 
1997 : e6 47 __ INC T1 + 0 
1999 : d0 02 __ BNE $199d ; (b_ftoa.s112 + 0)
.s111:
199b : e6 48 __ INC T1 + 1 
.s112:
199d : c8 __ __ INY
199e : e8 __ __ INX
199f : e4 43 __ CPX T0 + 0 
19a1 : 90 ef __ BCC $1992 ; (b_ftoa.l89 + 0)
.s129:
19a3 : a4 0d __ LDY P0 ; (buf + 0)
.s21:
19a5 : a5 47 __ LDA T1 + 0 
19a7 : 85 43 __ STA T0 + 0 
19a9 : 18 __ __ CLC
19aa : a5 0e __ LDA P1 ; (buf + 1)
19ac : 65 48 __ ADC T1 + 1 
19ae : 85 44 __ STA T0 + 1 
19b0 : a9 00 __ LDA #$00
19b2 : 91 43 __ STA (T0 + 0),y 
.s3:
19b4 : 60 __ __ RTS
.s31:
19b5 : 18 __ __ CLC
19b6 : 69 01 __ ADC #$01
19b8 : 85 1b __ STA ACCU + 0 
19ba : c5 43 __ CMP T0 + 0 
19bc : a0 00 __ LDY #$00
19be : 84 4f __ STY T5 + 0 
19c0 : 90 44 __ BCC $1a06 ; (b_ftoa.l82 + 0)
.s34:
19c2 : a2 00 __ LDX #$00
.l90:
19c4 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
19c7 : 91 4d __ STA (T4 + 0),y 
19c9 : e6 47 __ INC T1 + 0 
19cb : d0 02 __ BNE $19cf ; (b_ftoa.s114 + 0)
.s113:
19cd : e6 48 __ INC T1 + 1 
.s114:
19cf : c8 __ __ INY
19d0 : e8 __ __ INX
19d1 : e4 43 __ CPX T0 + 0 
19d3 : 90 ef __ BCC $19c4 ; (b_ftoa.l90 + 0)
.s35:
19d5 : a5 49 __ LDA T2 + 0 
19d7 : c5 43 __ CMP T0 + 0 
19d9 : 90 c8 __ BCC $19a3 ; (b_ftoa.s129 + 0)
.s36:
19db : 18 __ __ CLC
19dc : a5 0d __ LDA P0 ; (buf + 0)
19de : 65 47 __ ADC T1 + 0 
19e0 : 85 4b __ STA T3 + 0 
19e2 : a5 0e __ LDA P1 ; (buf + 1)
19e4 : 65 48 __ ADC T1 + 1 
19e6 : 85 4c __ STA T3 + 1 
19e8 : a0 00 __ LDY #$00
19ea : a6 47 __ LDX T1 + 0 
.l83:
19ec : a9 30 __ LDA #$30
19ee : 91 4b __ STA (T3 + 0),y 
19f0 : e8 __ __ INX
19f1 : d0 02 __ BNE $19f5 ; (b_ftoa.s116 + 0)
.s115:
19f3 : e6 48 __ INC T1 + 1 
.s116:
19f5 : c8 __ __ INY
19f6 : d0 02 __ BNE $19fa ; (b_ftoa.s118 + 0)
.s117:
19f8 : e6 4c __ INC T3 + 1 
.s118:
19fa : e6 43 __ INC T0 + 0 
19fc : a5 49 __ LDA T2 + 0 
19fe : c5 43 __ CMP T0 + 0 
1a00 : b0 ea __ BCS $19ec ; (b_ftoa.l83 + 0)
.s86:
1a02 : 86 47 __ STX T1 + 0 
1a04 : 90 9d __ BCC $19a3 ; (b_ftoa.s129 + 0)
.l82:
1a06 : a6 4f __ LDX T5 + 0 
1a08 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1a0b : 91 4d __ STA (T4 + 0),y 
1a0d : e6 47 __ INC T1 + 0 
1a0f : d0 02 __ BNE $1a13 ; (b_ftoa.s106 + 0)
.s105:
1a11 : e6 48 __ INC T1 + 1 
.s106:
1a13 : c8 __ __ INY
1a14 : d0 02 __ BNE $1a18 ; (b_ftoa.s108 + 0)
.s107:
1a16 : e6 4e __ INC T4 + 1 
.s108:
1a18 : a5 49 __ LDA T2 + 0 
1a1a : e6 4f __ INC T5 + 0 
1a1c : c5 4f __ CMP T5 + 0 
1a1e : b0 e6 __ BCS $1a06 ; (b_ftoa.l82 + 0)
.s32:
1a20 : a5 47 __ LDA T1 + 0 
1a22 : 85 49 __ STA T2 + 0 
1a24 : a5 0e __ LDA P1 ; (buf + 1)
1a26 : 65 48 __ ADC T1 + 1 
1a28 : 85 4a __ STA T2 + 1 
1a2a : a9 2e __ LDA #$2e
1a2c : a4 0d __ LDY P0 ; (buf + 0)
1a2e : 91 49 __ STA (T2 + 0),y 
1a30 : e6 47 __ INC T1 + 0 
1a32 : d0 02 __ BNE $1a36 ; (b_ftoa.s110 + 0)
.s109:
1a34 : e6 48 __ INC T1 + 1 
.s110:
1a36 : a6 1b __ LDX ACCU + 0 
1a38 : e4 43 __ CPX T0 + 0 
1a3a : 90 03 __ BCC $1a3f ; (b_ftoa.s33 + 0)
1a3c : 4c a5 19 JMP $19a5 ; (b_ftoa.s21 + 0)
.s33:
1a3f : 98 __ __ TYA
1a40 : 4c 85 19 JMP $1985 ; (b_ftoa.s85 + 0)
.s15:
1a43 : ad f0 9f LDA $9ff0 ; (d[0] + 0)
1a46 : a4 47 __ LDY T1 + 0 
1a48 : 91 0d __ STA (P0),y ; (buf + 0)
1a4a : e6 47 __ INC T1 + 0 
1a4c : a5 49 __ LDA T2 + 0 
1a4e : 85 4f __ STA T5 + 0 
1a50 : a5 4a __ LDA T2 + 1 
1a52 : 85 50 __ STA T5 + 1 
1a54 : e0 02 __ CPX #$02
1a56 : 90 29 __ BCC $1a81 ; (b_ftoa.s16 + 0)
.s25:
1a58 : a9 2e __ LDA #$2e
1a5a : c8 __ __ INY
1a5b : 91 0d __ STA (P0),y ; (buf + 0)
1a5d : e6 47 __ INC T1 + 0 
1a5f : 18 __ __ CLC
1a60 : a5 47 __ LDA T1 + 0 
1a62 : 65 0d __ ADC P0 ; (buf + 0)
1a64 : 85 4d __ STA T4 + 0 
1a66 : a5 0e __ LDA P1 ; (buf + 1)
1a68 : 69 00 __ ADC #$00
1a6a : 85 4e __ STA T4 + 1 
1a6c : a0 00 __ LDY #$00
1a6e : a2 01 __ LDX #$01
.l88:
1a70 : bd f0 9f LDA $9ff0,x ; (d[0] + 0)
1a73 : 91 4d __ STA (T4 + 0),y 
1a75 : e6 47 __ INC T1 + 0 
1a77 : d0 02 __ BNE $1a7b ; (b_ftoa.s98 + 0)
.s97:
1a79 : e6 48 __ INC T1 + 1 
.s98:
1a7b : c8 __ __ INY
1a7c : e8 __ __ INX
1a7d : e4 43 __ CPX T0 + 0 
1a7f : 90 ef __ BCC $1a70 ; (b_ftoa.l88 + 0)
.s16:
1a81 : 18 __ __ CLC
1a82 : a5 0d __ LDA P0 ; (buf + 0)
1a84 : 65 47 __ ADC T1 + 0 
1a86 : 85 43 __ STA T0 + 0 
1a88 : a5 0e __ LDA P1 ; (buf + 1)
1a8a : 65 48 __ ADC T1 + 1 
1a8c : 85 44 __ STA T0 + 1 
1a8e : a9 45 __ LDA #$45
1a90 : a0 00 __ LDY #$00
1a92 : 84 4d __ STY T4 + 0 
1a94 : 91 43 __ STA (T0 + 0),y 
1a96 : 18 __ __ CLC
1a97 : a5 47 __ LDA T1 + 0 
1a99 : 69 02 __ ADC #$02
1a9b : 85 47 __ STA T1 + 0 
1a9d : 90 02 __ BCC $1aa1 ; (b_ftoa.s100 + 0)
.s99:
1a9f : e6 48 __ INC T1 + 1 
.s100:
1aa1 : a0 01 __ LDY #$01
1aa3 : 24 4a __ BIT T2 + 1 
1aa5 : 10 1c __ BPL $1ac3 ; (b_ftoa.s17 + 0)
.s24:
1aa7 : a9 2d __ LDA #$2d
1aa9 : 91 43 __ STA (T0 + 0),y 
1aab : 38 __ __ SEC
1aac : a9 00 __ LDA #$00
1aae : e5 49 __ SBC T2 + 0 
1ab0 : 85 4f __ STA T5 + 0 
1ab2 : a9 00 __ LDA #$00
1ab4 : e5 4a __ SBC T2 + 1 
1ab6 : 85 50 __ STA T5 + 1 
.s18:
1ab8 : a5 4f __ LDA T5 + 0 
1aba : 85 1b __ STA ACCU + 0 
1abc : a5 50 __ LDA T5 + 1 
1abe : 85 1c __ STA ACCU + 1 
1ac0 : 4c 01 1b JMP $1b01 ; (b_ftoa.l80 + 0)
.s17:
1ac3 : a9 2b __ LDA #$2b
1ac5 : 91 43 __ STA (T0 + 0),y 
1ac7 : a5 49 __ LDA T2 + 0 
1ac9 : 05 4a __ ORA T2 + 1 
1acb : d0 eb __ BNE $1ab8 ; (b_ftoa.s18 + 0)
.s23:
1acd : a9 30 __ LDA #$30
1acf : 8d e8 9f STA $9fe8 ; (eb[0] + 0)
.s22:
1ad2 : 8d e9 9f STA $9fe9 ; (eb[0] + 1)
1ad5 : a9 02 __ LDA #$02
1ad7 : 85 4d __ STA T4 + 0 
.s20:
1ad9 : 18 __ __ CLC
1ada : a5 0d __ LDA P0 ; (buf + 0)
1adc : 65 47 __ ADC T1 + 0 
1ade : a8 __ __ TAY
1adf : a5 0e __ LDA P1 ; (buf + 1)
1ae1 : 65 48 __ ADC T1 + 1 
1ae3 : 85 4c __ STA T3 + 1 
1ae5 : a9 00 __ LDA #$00
1ae7 : 85 4b __ STA T3 + 0 
1ae9 : a6 4d __ LDX T4 + 0 
.l81:
1aeb : bd e7 9f LDA $9fe7,x ; (buf[0] + 63)
1aee : 91 4b __ STA (T3 + 0),y 
1af0 : e6 47 __ INC T1 + 0 
1af2 : d0 02 __ BNE $1af6 ; (b_ftoa.s102 + 0)
.s101:
1af4 : e6 48 __ INC T1 + 1 
.s102:
1af6 : c8 __ __ INY
1af7 : d0 02 __ BNE $1afb ; (b_ftoa.s104 + 0)
.s103:
1af9 : e6 4c __ INC T3 + 1 
.s104:
1afb : ca __ __ DEX
1afc : d0 ed __ BNE $1aeb ; (b_ftoa.l81 + 0)
1afe : 4c a3 19 JMP $19a3 ; (b_ftoa.s129 + 0)
.l80:
1b01 : a9 0a __ LDA #$0a
1b03 : 85 03 __ STA WORK + 0 
1b05 : a9 00 __ LDA #$00
1b07 : 85 04 __ STA WORK + 1 
1b09 : 20 a0 1f JSR $1fa0 ; (mods16 + 0)
1b0c : 18 __ __ CLC
1b0d : a5 05 __ LDA WORK + 2 
1b0f : 69 30 __ ADC #$30
1b11 : a6 4d __ LDX T4 + 0 
1b13 : 9d e8 9f STA $9fe8,x ; (eb[0] + 0)
1b16 : a5 4f __ LDA T5 + 0 
1b18 : e6 4d __ INC T4 + 0 
1b1a : 85 1b __ STA ACCU + 0 
1b1c : a5 50 __ LDA T5 + 1 
1b1e : 85 1c __ STA ACCU + 1 
1b20 : a9 0a __ LDA #$0a
1b22 : 85 03 __ STA WORK + 0 
1b24 : a9 00 __ LDA #$00
1b26 : 85 04 __ STA WORK + 1 
1b28 : 20 e1 1e JSR $1ee1 ; (divs16 + 0)
1b2b : a5 1b __ LDA ACCU + 0 
1b2d : 85 4f __ STA T5 + 0 
1b2f : a5 1c __ LDA ACCU + 1 
1b31 : 85 50 __ STA T5 + 1 
1b33 : 05 1b __ ORA ACCU + 0 
1b35 : d0 ca __ BNE $1b01 ; (b_ftoa.l80 + 0)
.s19:
1b37 : a5 4d __ LDA T4 + 0 
1b39 : c9 02 __ CMP #$02
1b3b : b0 9c __ BCS $1ad9 ; (b_ftoa.s20 + 0)
.s128:
1b3d : a9 30 __ LDA #$30
1b3f : 90 91 __ BCC $1ad2 ; (b_ftoa.s22 + 0)
.l62:
1b41 : e6 49 __ INC T2 + 0 
1b43 : d0 02 __ BNE $1b47 ; (b_ftoa.s124 + 0)
.s123:
1b45 : e6 4a __ INC T2 + 1 
.s124:
1b47 : a5 43 __ LDA T0 + 0 
1b49 : 85 1b __ STA ACCU + 0 
1b4b : a5 44 __ LDA T0 + 1 
1b4d : 85 1c __ STA ACCU + 1 
1b4f : a5 45 __ LDA T0 + 2 
1b51 : 85 1d __ STA ACCU + 2 
1b53 : a5 46 __ LDA T0 + 3 
1b55 : 85 1e __ STA ACCU + 3 
1b57 : a9 00 __ LDA #$00
1b59 : 85 03 __ STA WORK + 0 
1b5b : 85 04 __ STA WORK + 1 
1b5d : a9 20 __ LDA #$20
1b5f : 85 05 __ STA WORK + 2 
1b61 : a9 41 __ LDA #$41
1b63 : 85 06 __ STA WORK + 3 
1b65 : 20 4d 1c JSR $1c4d ; (freg + 20)
1b68 : 20 33 1e JSR $1e33 ; (crt_fdiv + 0)
1b6b : a5 1b __ LDA ACCU + 0 
1b6d : 85 43 __ STA T0 + 0 
1b6f : a5 1c __ LDA ACCU + 1 
1b71 : 85 44 __ STA T0 + 1 
1b73 : a6 1d __ LDX ACCU + 2 
1b75 : 86 45 __ STX T0 + 2 
1b77 : a5 1e __ LDA ACCU + 3 
1b79 : 85 46 __ STA T0 + 3 
1b7b : 10 03 __ BPL $1b80 ; (b_ftoa.s65 + 0)
1b7d : 4c 29 18 JMP $1829 ; (b_ftoa.s9 + 0)
.s65:
1b80 : c9 41 __ CMP #$41
1b82 : d0 0d __ BNE $1b91 ; (b_ftoa.s69 + 0)
.s66:
1b84 : e0 20 __ CPX #$20
1b86 : d0 09 __ BNE $1b91 ; (b_ftoa.s69 + 0)
.s67:
1b88 : a5 1c __ LDA ACCU + 1 
1b8a : 38 __ __ SEC
1b8b : d0 04 __ BNE $1b91 ; (b_ftoa.s69 + 0)
.s68:
1b8d : a5 1b __ LDA ACCU + 0 
1b8f : f0 02 __ BEQ $1b93 ; (b_ftoa.s63 + 0)
.s69:
1b91 : 90 ea __ BCC $1b7d ; (b_ftoa.s124 + 54)
.s63:
1b93 : e6 47 __ INC T1 + 0 
1b95 : d0 02 __ BNE $1b99 ; (b_ftoa.s126 + 0)
.s125:
1b97 : e6 48 __ INC T1 + 1 
.s126:
1b99 : a6 48 __ LDX T1 + 1 
1b9b : ca __ __ DEX
1b9c : d0 a3 __ BNE $1b41 ; (b_ftoa.l62 + 0)
.s64:
1b9e : a5 47 __ LDA T1 + 0 
1ba0 : c9 90 __ CMP #$90
1ba2 : d0 9d __ BNE $1b41 ; (b_ftoa.l62 + 0)
1ba4 : 4c 29 18 JMP $1829 ; (b_ftoa.s9 + 0)
.s75:
1ba7 : a9 30 __ LDA #$30
1ba9 : a0 00 __ LDY #$00
1bab : 91 0d __ STA (P0),y ; (buf + 0)
1bad : 98 __ __ TYA
1bae : c8 __ __ INY
1baf : 91 0d __ STA (P0),y ; (buf + 0)
1bb1 : 60 __ __ RTS
.s76:
1bb2 : 49 80 __ EOR #$80
1bb4 : 85 12 __ STA P5 ; (v + 3)
1bb6 : 29 7f __ AND #$7f
1bb8 : 05 11 __ ORA P4 ; (v + 2)
1bba : 05 10 __ ORA P3 ; (v + 1)
1bbc : 05 0f __ ORA P2 ; (v + 0)
1bbe : f0 e7 __ BEQ $1ba7 ; (b_ftoa.s75 + 0)
.s77:
1bc0 : a9 01 __ LDA #$01
1bc2 : 4c 94 17 JMP $1794 ; (b_ftoa.s7 + 0)
--------------------------------------------------------------------
strchr: ; strchr(const u8*,i16)->u8*
;  18, "C:/Users/g/claude/c64/oscar64/include/string.h"
.l4:
1bc5 : a0 00 __ LDY #$00
1bc7 : b1 0d __ LDA (P0),y ; (str + 0)
1bc9 : c5 0f __ CMP P2 ; (ch + 0)
1bcb : d0 09 __ BNE $1bd6 ; (strchr.s6 + 0)
.s5:
1bcd : a5 0d __ LDA P0 ; (str + 0)
1bcf : 85 1b __ STA ACCU + 0 
1bd1 : a5 0e __ LDA P1 ; (str + 1)
.s3:
1bd3 : 85 1c __ STA ACCU + 1 
1bd5 : 60 __ __ RTS
.s6:
1bd6 : aa __ __ TAX
1bd7 : f0 09 __ BEQ $1be2 ; (strchr.s7 + 0)
.s8:
1bd9 : e6 0d __ INC P0 ; (str + 0)
1bdb : d0 e8 __ BNE $1bc5 ; (strchr.l4 + 0)
.s9:
1bdd : e6 0e __ INC P1 ; (str + 1)
1bdf : 4c c5 1b JMP $1bc5 ; (strchr.l4 + 0)
.s7:
1be2 : 85 1b __ STA ACCU + 0 
1be4 : 4c d3 1b JMP $1bd3 ; (strchr.s3 + 0)
--------------------------------------------------------------------
strlen: ; strlen(const u8*)->i16
;  12, "C:/Users/g/claude/c64/oscar64/include/string.h"
.s4:
1be7 : a9 00 __ LDA #$00
1be9 : 85 1b __ STA ACCU + 0 
1beb : 85 1c __ STA ACCU + 1 
1bed : a8 __ __ TAY
1bee : b1 0d __ LDA (P0),y ; (str + 0)
1bf0 : f0 10 __ BEQ $1c02 ; (strlen.s3 + 0)
.s6:
1bf2 : a2 00 __ LDX #$00
.l7:
1bf4 : c8 __ __ INY
1bf5 : d0 03 __ BNE $1bfa ; (strlen.s9 + 0)
.s8:
1bf7 : e6 0e __ INC P1 ; (str + 1)
1bf9 : e8 __ __ INX
.s9:
1bfa : b1 0d __ LDA (P0),y ; (str + 0)
1bfc : d0 f6 __ BNE $1bf4 ; (strlen.l7 + 0)
.s5:
1bfe : 86 1c __ STX ACCU + 1 
1c00 : 84 1b __ STY ACCU + 0 
.s3:
1c02 : 60 __ __ RTS
--------------------------------------------------------------------
mul32by8: ; mul32by8
1c03 : a0 00 __ LDY #$00
1c05 : 84 07 __ STY WORK + 4 
1c07 : 84 08 __ STY WORK + 5 
1c09 : 84 09 __ STY WORK + 6 
1c0b : 4a __ __ LSR
1c0c : b0 0d __ BCS $1c1b ; (mul32by8 + 24)
1c0e : f0 26 __ BEQ $1c36 ; (mul32by8 + 51)
1c10 : 06 1b __ ASL ACCU + 0 
1c12 : 26 1c __ ROL ACCU + 1 
1c14 : 26 1d __ ROL ACCU + 2 
1c16 : 26 1e __ ROL ACCU + 3 
1c18 : 4a __ __ LSR
1c19 : 90 f5 __ BCC $1c10 ; (mul32by8 + 13)
1c1b : aa __ __ TAX
1c1c : 18 __ __ CLC
1c1d : a5 07 __ LDA WORK + 4 
1c1f : 65 1b __ ADC ACCU + 0 
1c21 : 85 07 __ STA WORK + 4 
1c23 : a5 08 __ LDA WORK + 5 
1c25 : 65 1c __ ADC ACCU + 1 
1c27 : 85 08 __ STA WORK + 5 
1c29 : a5 09 __ LDA WORK + 6 
1c2b : 65 1d __ ADC ACCU + 2 
1c2d : 85 09 __ STA WORK + 6 
1c2f : 98 __ __ TYA
1c30 : 65 1e __ ADC ACCU + 3 
1c32 : a8 __ __ TAY
1c33 : 8a __ __ TXA
1c34 : d0 da __ BNE $1c10 ; (mul32by8 + 13)
1c36 : 84 0a __ STY WORK + 7 
1c38 : 60 __ __ RTS
--------------------------------------------------------------------
freg: ; freg
1c39 : b1 19 __ LDA (IP + 0),y 
1c3b : c8 __ __ INY
1c3c : aa __ __ TAX
1c3d : b5 00 __ LDA $00,x 
1c3f : 85 03 __ STA WORK + 0 
1c41 : b5 01 __ LDA $01,x 
1c43 : 85 04 __ STA WORK + 1 
1c45 : b5 02 __ LDA $02,x 
1c47 : 85 05 __ STA WORK + 2 
1c49 : b5 03 __ LDA WORK + 0,x 
1c4b : 85 06 __ STA WORK + 3 
1c4d : a5 05 __ LDA WORK + 2 
1c4f : 0a __ __ ASL
1c50 : a5 06 __ LDA WORK + 3 
1c52 : 2a __ __ ROL
1c53 : 85 08 __ STA WORK + 5 
1c55 : f0 06 __ BEQ $1c5d ; (freg + 36)
1c57 : a5 05 __ LDA WORK + 2 
1c59 : 09 80 __ ORA #$80
1c5b : 85 05 __ STA WORK + 2 
1c5d : a5 1d __ LDA ACCU + 2 
1c5f : 0a __ __ ASL
1c60 : a5 1e __ LDA ACCU + 3 
1c62 : 2a __ __ ROL
1c63 : 85 07 __ STA WORK + 4 
1c65 : f0 06 __ BEQ $1c6d ; (freg + 52)
1c67 : a5 1d __ LDA ACCU + 2 
1c69 : 09 80 __ ORA #$80
1c6b : 85 1d __ STA ACCU + 2 
1c6d : 60 __ __ RTS
1c6e : 06 1e __ ASL ACCU + 3 
1c70 : a5 07 __ LDA WORK + 4 
1c72 : 6a __ __ ROR
1c73 : 85 1e __ STA ACCU + 3 
1c75 : b0 06 __ BCS $1c7d ; (freg + 68)
1c77 : a5 1d __ LDA ACCU + 2 
1c79 : 29 7f __ AND #$7f
1c7b : 85 1d __ STA ACCU + 2 
1c7d : 60 __ __ RTS
--------------------------------------------------------------------
faddsub: ; faddsub
1c7e : a5 06 __ LDA WORK + 3 
1c80 : 49 80 __ EOR #$80
1c82 : 85 06 __ STA WORK + 3 
1c84 : a9 ff __ LDA #$ff
1c86 : c5 07 __ CMP WORK + 4 
1c88 : f0 04 __ BEQ $1c8e ; (faddsub + 16)
1c8a : c5 08 __ CMP WORK + 5 
1c8c : d0 11 __ BNE $1c9f ; (faddsub + 33)
1c8e : a5 1e __ LDA ACCU + 3 
1c90 : 09 7f __ ORA #$7f
1c92 : 85 1e __ STA ACCU + 3 
1c94 : a9 80 __ LDA #$80
1c96 : 85 1d __ STA ACCU + 2 
1c98 : a9 00 __ LDA #$00
1c9a : 85 1b __ STA ACCU + 0 
1c9c : 85 1c __ STA ACCU + 1 
1c9e : 60 __ __ RTS
1c9f : 38 __ __ SEC
1ca0 : a5 07 __ LDA WORK + 4 
1ca2 : e5 08 __ SBC WORK + 5 
1ca4 : f0 38 __ BEQ $1cde ; (faddsub + 96)
1ca6 : aa __ __ TAX
1ca7 : b0 25 __ BCS $1cce ; (faddsub + 80)
1ca9 : e0 e9 __ CPX #$e9
1cab : b0 0e __ BCS $1cbb ; (faddsub + 61)
1cad : a5 08 __ LDA WORK + 5 
1caf : 85 07 __ STA WORK + 4 
1cb1 : a9 00 __ LDA #$00
1cb3 : 85 1b __ STA ACCU + 0 
1cb5 : 85 1c __ STA ACCU + 1 
1cb7 : 85 1d __ STA ACCU + 2 
1cb9 : f0 23 __ BEQ $1cde ; (faddsub + 96)
1cbb : a5 1d __ LDA ACCU + 2 
1cbd : 4a __ __ LSR
1cbe : 66 1c __ ROR ACCU + 1 
1cc0 : 66 1b __ ROR ACCU + 0 
1cc2 : e8 __ __ INX
1cc3 : d0 f8 __ BNE $1cbd ; (faddsub + 63)
1cc5 : 85 1d __ STA ACCU + 2 
1cc7 : a5 08 __ LDA WORK + 5 
1cc9 : 85 07 __ STA WORK + 4 
1ccb : 4c de 1c JMP $1cde ; (faddsub + 96)
1cce : e0 18 __ CPX #$18
1cd0 : b0 33 __ BCS $1d05 ; (faddsub + 135)
1cd2 : a5 05 __ LDA WORK + 2 
1cd4 : 4a __ __ LSR
1cd5 : 66 04 __ ROR WORK + 1 
1cd7 : 66 03 __ ROR WORK + 0 
1cd9 : ca __ __ DEX
1cda : d0 f8 __ BNE $1cd4 ; (faddsub + 86)
1cdc : 85 05 __ STA WORK + 2 
1cde : a5 1e __ LDA ACCU + 3 
1ce0 : 29 80 __ AND #$80
1ce2 : 85 1e __ STA ACCU + 3 
1ce4 : 45 06 __ EOR WORK + 3 
1ce6 : 30 31 __ BMI $1d19 ; (faddsub + 155)
1ce8 : 18 __ __ CLC
1ce9 : a5 1b __ LDA ACCU + 0 
1ceb : 65 03 __ ADC WORK + 0 
1ced : 85 1b __ STA ACCU + 0 
1cef : a5 1c __ LDA ACCU + 1 
1cf1 : 65 04 __ ADC WORK + 1 
1cf3 : 85 1c __ STA ACCU + 1 
1cf5 : a5 1d __ LDA ACCU + 2 
1cf7 : 65 05 __ ADC WORK + 2 
1cf9 : 85 1d __ STA ACCU + 2 
1cfb : 90 08 __ BCC $1d05 ; (faddsub + 135)
1cfd : 66 1d __ ROR ACCU + 2 
1cff : 66 1c __ ROR ACCU + 1 
1d01 : 66 1b __ ROR ACCU + 0 
1d03 : e6 07 __ INC WORK + 4 
1d05 : a5 07 __ LDA WORK + 4 
1d07 : c9 ff __ CMP #$ff
1d09 : f0 83 __ BEQ $1c8e ; (faddsub + 16)
1d0b : 4a __ __ LSR
1d0c : 05 1e __ ORA ACCU + 3 
1d0e : 85 1e __ STA ACCU + 3 
1d10 : b0 06 __ BCS $1d18 ; (faddsub + 154)
1d12 : a5 1d __ LDA ACCU + 2 
1d14 : 29 7f __ AND #$7f
1d16 : 85 1d __ STA ACCU + 2 
1d18 : 60 __ __ RTS
1d19 : 38 __ __ SEC
1d1a : a5 1b __ LDA ACCU + 0 
1d1c : e5 03 __ SBC WORK + 0 
1d1e : 85 1b __ STA ACCU + 0 
1d20 : a5 1c __ LDA ACCU + 1 
1d22 : e5 04 __ SBC WORK + 1 
1d24 : 85 1c __ STA ACCU + 1 
1d26 : a5 1d __ LDA ACCU + 2 
1d28 : e5 05 __ SBC WORK + 2 
1d2a : 85 1d __ STA ACCU + 2 
1d2c : b0 19 __ BCS $1d47 ; (faddsub + 201)
1d2e : 38 __ __ SEC
1d2f : a9 00 __ LDA #$00
1d31 : e5 1b __ SBC ACCU + 0 
1d33 : 85 1b __ STA ACCU + 0 
1d35 : a9 00 __ LDA #$00
1d37 : e5 1c __ SBC ACCU + 1 
1d39 : 85 1c __ STA ACCU + 1 
1d3b : a9 00 __ LDA #$00
1d3d : e5 1d __ SBC ACCU + 2 
1d3f : 85 1d __ STA ACCU + 2 
1d41 : a5 1e __ LDA ACCU + 3 
1d43 : 49 80 __ EOR #$80
1d45 : 85 1e __ STA ACCU + 3 
1d47 : a5 1d __ LDA ACCU + 2 
1d49 : 30 ba __ BMI $1d05 ; (faddsub + 135)
1d4b : 05 1c __ ORA ACCU + 1 
1d4d : 05 1b __ ORA ACCU + 0 
1d4f : f0 0f __ BEQ $1d60 ; (faddsub + 226)
1d51 : c6 07 __ DEC WORK + 4 
1d53 : f0 0b __ BEQ $1d60 ; (faddsub + 226)
1d55 : 06 1b __ ASL ACCU + 0 
1d57 : 26 1c __ ROL ACCU + 1 
1d59 : 26 1d __ ROL ACCU + 2 
1d5b : 10 f4 __ BPL $1d51 ; (faddsub + 211)
1d5d : 4c 05 1d JMP $1d05 ; (faddsub + 135)
1d60 : a9 00 __ LDA #$00
1d62 : 85 1b __ STA ACCU + 0 
1d64 : 85 1c __ STA ACCU + 1 
1d66 : 85 1d __ STA ACCU + 2 
1d68 : 85 1e __ STA ACCU + 3 
1d6a : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul: ; crt_fmul
1d6b : a5 1b __ LDA ACCU + 0 
1d6d : 05 1c __ ORA ACCU + 1 
1d6f : 05 1d __ ORA ACCU + 2 
1d71 : f0 0e __ BEQ $1d81 ; (crt_fmul + 22)
1d73 : a5 03 __ LDA WORK + 0 
1d75 : 05 04 __ ORA WORK + 1 
1d77 : 05 05 __ ORA WORK + 2 
1d79 : d0 09 __ BNE $1d84 ; (crt_fmul + 25)
1d7b : 85 1b __ STA ACCU + 0 
1d7d : 85 1c __ STA ACCU + 1 
1d7f : 85 1d __ STA ACCU + 2 
1d81 : 85 1e __ STA ACCU + 3 
1d83 : 60 __ __ RTS
1d84 : a5 1e __ LDA ACCU + 3 
1d86 : 45 06 __ EOR WORK + 3 
1d88 : 29 80 __ AND #$80
1d8a : 85 1e __ STA ACCU + 3 
1d8c : a9 ff __ LDA #$ff
1d8e : c5 07 __ CMP WORK + 4 
1d90 : f0 42 __ BEQ $1dd4 ; (crt_fmul + 105)
1d92 : c5 08 __ CMP WORK + 5 
1d94 : f0 3e __ BEQ $1dd4 ; (crt_fmul + 105)
1d96 : a9 00 __ LDA #$00
1d98 : 85 09 __ STA WORK + 6 
1d9a : 85 0a __ STA WORK + 7 
1d9c : 85 0b __ STA WORK + 8 
1d9e : a4 1b __ LDY ACCU + 0 
1da0 : a5 03 __ LDA WORK + 0 
1da2 : d0 06 __ BNE $1daa ; (crt_fmul + 63)
1da4 : a5 04 __ LDA WORK + 1 
1da6 : f0 0a __ BEQ $1db2 ; (crt_fmul + 71)
1da8 : d0 05 __ BNE $1daf ; (crt_fmul + 68)
1daa : 20 05 1e JSR $1e05 ; (crt_fmul8 + 0)
1dad : a5 04 __ LDA WORK + 1 
1daf : 20 05 1e JSR $1e05 ; (crt_fmul8 + 0)
1db2 : a5 05 __ LDA WORK + 2 
1db4 : 20 05 1e JSR $1e05 ; (crt_fmul8 + 0)
1db7 : 38 __ __ SEC
1db8 : a5 0b __ LDA WORK + 8 
1dba : 30 06 __ BMI $1dc2 ; (crt_fmul + 87)
1dbc : 06 09 __ ASL WORK + 6 
1dbe : 26 0a __ ROL WORK + 7 
1dc0 : 2a __ __ ROL
1dc1 : 18 __ __ CLC
1dc2 : 29 7f __ AND #$7f
1dc4 : 85 0b __ STA WORK + 8 
1dc6 : a5 07 __ LDA WORK + 4 
1dc8 : 65 08 __ ADC WORK + 5 
1dca : 90 19 __ BCC $1de5 ; (crt_fmul + 122)
1dcc : e9 7f __ SBC #$7f
1dce : b0 04 __ BCS $1dd4 ; (crt_fmul + 105)
1dd0 : c9 ff __ CMP #$ff
1dd2 : d0 15 __ BNE $1de9 ; (crt_fmul + 126)
1dd4 : a5 1e __ LDA ACCU + 3 
1dd6 : 09 7f __ ORA #$7f
1dd8 : 85 1e __ STA ACCU + 3 
1dda : a9 80 __ LDA #$80
1ddc : 85 1d __ STA ACCU + 2 
1dde : a9 00 __ LDA #$00
1de0 : 85 1b __ STA ACCU + 0 
1de2 : 85 1c __ STA ACCU + 1 
1de4 : 60 __ __ RTS
1de5 : e9 7e __ SBC #$7e
1de7 : 90 15 __ BCC $1dfe ; (crt_fmul + 147)
1de9 : 4a __ __ LSR
1dea : 05 1e __ ORA ACCU + 3 
1dec : 85 1e __ STA ACCU + 3 
1dee : a9 00 __ LDA #$00
1df0 : 6a __ __ ROR
1df1 : 05 0b __ ORA WORK + 8 
1df3 : 85 1d __ STA ACCU + 2 
1df5 : a5 0a __ LDA WORK + 7 
1df7 : 85 1c __ STA ACCU + 1 
1df9 : a5 09 __ LDA WORK + 6 
1dfb : 85 1b __ STA ACCU + 0 
1dfd : 60 __ __ RTS
1dfe : a9 00 __ LDA #$00
1e00 : 85 1e __ STA ACCU + 3 
1e02 : f0 d8 __ BEQ $1ddc ; (crt_fmul + 113)
1e04 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fmul8: ; crt_fmul8
1e05 : 38 __ __ SEC
1e06 : 6a __ __ ROR
1e07 : 90 1e __ BCC $1e27 ; (crt_fmul8 + 34)
1e09 : aa __ __ TAX
1e0a : 18 __ __ CLC
1e0b : 98 __ __ TYA
1e0c : 65 09 __ ADC WORK + 6 
1e0e : 85 09 __ STA WORK + 6 
1e10 : a5 0a __ LDA WORK + 7 
1e12 : 65 1c __ ADC ACCU + 1 
1e14 : 85 0a __ STA WORK + 7 
1e16 : a5 0b __ LDA WORK + 8 
1e18 : 65 1d __ ADC ACCU + 2 
1e1a : 6a __ __ ROR
1e1b : 85 0b __ STA WORK + 8 
1e1d : 8a __ __ TXA
1e1e : 66 0a __ ROR WORK + 7 
1e20 : 66 09 __ ROR WORK + 6 
1e22 : 4a __ __ LSR
1e23 : f0 0d __ BEQ $1e32 ; (crt_fmul8 + 45)
1e25 : b0 e2 __ BCS $1e09 ; (crt_fmul8 + 4)
1e27 : 66 0b __ ROR WORK + 8 
1e29 : 66 0a __ ROR WORK + 7 
1e2b : 66 09 __ ROR WORK + 6 
1e2d : 4a __ __ LSR
1e2e : 90 f7 __ BCC $1e27 ; (crt_fmul8 + 34)
1e30 : d0 d7 __ BNE $1e09 ; (crt_fmul8 + 4)
1e32 : 60 __ __ RTS
--------------------------------------------------------------------
crt_fdiv: ; crt_fdiv
1e33 : a5 1b __ LDA ACCU + 0 
1e35 : 05 1c __ ORA ACCU + 1 
1e37 : 05 1d __ ORA ACCU + 2 
1e39 : d0 03 __ BNE $1e3e ; (crt_fdiv + 11)
1e3b : 85 1e __ STA ACCU + 3 
1e3d : 60 __ __ RTS
1e3e : a5 1e __ LDA ACCU + 3 
1e40 : 45 06 __ EOR WORK + 3 
1e42 : 29 80 __ AND #$80
1e44 : 85 1e __ STA ACCU + 3 
1e46 : a5 08 __ LDA WORK + 5 
1e48 : f0 62 __ BEQ $1eac ; (crt_fdiv + 121)
1e4a : a5 07 __ LDA WORK + 4 
1e4c : c9 ff __ CMP #$ff
1e4e : f0 5c __ BEQ $1eac ; (crt_fdiv + 121)
1e50 : a9 00 __ LDA #$00
1e52 : 85 09 __ STA WORK + 6 
1e54 : 85 0a __ STA WORK + 7 
1e56 : 85 0b __ STA WORK + 8 
1e58 : a2 18 __ LDX #$18
1e5a : a5 1b __ LDA ACCU + 0 
1e5c : c5 03 __ CMP WORK + 0 
1e5e : a5 1c __ LDA ACCU + 1 
1e60 : e5 04 __ SBC WORK + 1 
1e62 : a5 1d __ LDA ACCU + 2 
1e64 : e5 05 __ SBC WORK + 2 
1e66 : 90 13 __ BCC $1e7b ; (crt_fdiv + 72)
1e68 : a5 1b __ LDA ACCU + 0 
1e6a : e5 03 __ SBC WORK + 0 
1e6c : 85 1b __ STA ACCU + 0 
1e6e : a5 1c __ LDA ACCU + 1 
1e70 : e5 04 __ SBC WORK + 1 
1e72 : 85 1c __ STA ACCU + 1 
1e74 : a5 1d __ LDA ACCU + 2 
1e76 : e5 05 __ SBC WORK + 2 
1e78 : 85 1d __ STA ACCU + 2 
1e7a : 38 __ __ SEC
1e7b : 26 09 __ ROL WORK + 6 
1e7d : 26 0a __ ROL WORK + 7 
1e7f : 26 0b __ ROL WORK + 8 
1e81 : ca __ __ DEX
1e82 : f0 0a __ BEQ $1e8e ; (crt_fdiv + 91)
1e84 : 06 1b __ ASL ACCU + 0 
1e86 : 26 1c __ ROL ACCU + 1 
1e88 : 26 1d __ ROL ACCU + 2 
1e8a : b0 dc __ BCS $1e68 ; (crt_fdiv + 53)
1e8c : 90 cc __ BCC $1e5a ; (crt_fdiv + 39)
1e8e : 38 __ __ SEC
1e8f : a5 0b __ LDA WORK + 8 
1e91 : 30 06 __ BMI $1e99 ; (crt_fdiv + 102)
1e93 : 06 09 __ ASL WORK + 6 
1e95 : 26 0a __ ROL WORK + 7 
1e97 : 2a __ __ ROL
1e98 : 18 __ __ CLC
1e99 : 29 7f __ AND #$7f
1e9b : 85 0b __ STA WORK + 8 
1e9d : a5 07 __ LDA WORK + 4 
1e9f : e5 08 __ SBC WORK + 5 
1ea1 : 90 1a __ BCC $1ebd ; (crt_fdiv + 138)
1ea3 : 18 __ __ CLC
1ea4 : 69 7f __ ADC #$7f
1ea6 : b0 04 __ BCS $1eac ; (crt_fdiv + 121)
1ea8 : c9 ff __ CMP #$ff
1eaa : d0 15 __ BNE $1ec1 ; (crt_fdiv + 142)
1eac : a5 1e __ LDA ACCU + 3 
1eae : 09 7f __ ORA #$7f
1eb0 : 85 1e __ STA ACCU + 3 
1eb2 : a9 80 __ LDA #$80
1eb4 : 85 1d __ STA ACCU + 2 
1eb6 : a9 00 __ LDA #$00
1eb8 : 85 1c __ STA ACCU + 1 
1eba : 85 1b __ STA ACCU + 0 
1ebc : 60 __ __ RTS
1ebd : 69 7f __ ADC #$7f
1ebf : 90 15 __ BCC $1ed6 ; (crt_fdiv + 163)
1ec1 : 4a __ __ LSR
1ec2 : 05 1e __ ORA ACCU + 3 
1ec4 : 85 1e __ STA ACCU + 3 
1ec6 : a9 00 __ LDA #$00
1ec8 : 6a __ __ ROR
1ec9 : 05 0b __ ORA WORK + 8 
1ecb : 85 1d __ STA ACCU + 2 
1ecd : a5 0a __ LDA WORK + 7 
1ecf : 85 1c __ STA ACCU + 1 
1ed1 : a5 09 __ LDA WORK + 6 
1ed3 : 85 1b __ STA ACCU + 0 
1ed5 : 60 __ __ RTS
1ed6 : a9 00 __ LDA #$00
1ed8 : 85 1e __ STA ACCU + 3 
1eda : 85 1d __ STA ACCU + 2 
1edc : 85 1c __ STA ACCU + 1 
1ede : 85 1b __ STA ACCU + 0 
1ee0 : 60 __ __ RTS
--------------------------------------------------------------------
divs16: ; divs16
1ee1 : 24 1c __ BIT ACCU + 1 
1ee3 : 10 0d __ BPL $1ef2 ; (divs16 + 17)
1ee5 : 20 ff 1e JSR $1eff ; (negaccu + 0)
1ee8 : 24 04 __ BIT WORK + 1 
1eea : 10 0d __ BPL $1ef9 ; (divs16 + 24)
1eec : 20 0d 1f JSR $1f0d ; (negtmp + 0)
1eef : 4c 1b 1f JMP $1f1b ; (divmod + 0)
1ef2 : 24 04 __ BIT WORK + 1 
1ef4 : 10 f9 __ BPL $1eef ; (divs16 + 14)
1ef6 : 20 0d 1f JSR $1f0d ; (negtmp + 0)
1ef9 : 20 1b 1f JSR $1f1b ; (divmod + 0)
1efc : 4c ff 1e JMP $1eff ; (negaccu + 0)
--------------------------------------------------------------------
negaccu: ; negaccu
1eff : 38 __ __ SEC
1f00 : a9 00 __ LDA #$00
1f02 : e5 1b __ SBC ACCU + 0 
1f04 : 85 1b __ STA ACCU + 0 
1f06 : a9 00 __ LDA #$00
1f08 : e5 1c __ SBC ACCU + 1 
1f0a : 85 1c __ STA ACCU + 1 
1f0c : 60 __ __ RTS
--------------------------------------------------------------------
negtmp: ; negtmp
1f0d : 38 __ __ SEC
1f0e : a9 00 __ LDA #$00
1f10 : e5 03 __ SBC WORK + 0 
1f12 : 85 03 __ STA WORK + 0 
1f14 : a9 00 __ LDA #$00
1f16 : e5 04 __ SBC WORK + 1 
1f18 : 85 04 __ STA WORK + 1 
1f1a : 60 __ __ RTS
--------------------------------------------------------------------
divmod: ; divmod
1f1b : a5 1c __ LDA ACCU + 1 
1f1d : d0 31 __ BNE $1f50 ; (divmod + 53)
1f1f : a5 04 __ LDA WORK + 1 
1f21 : d0 1e __ BNE $1f41 ; (divmod + 38)
1f23 : 85 06 __ STA WORK + 3 
1f25 : a2 04 __ LDX #$04
1f27 : 06 1b __ ASL ACCU + 0 
1f29 : 2a __ __ ROL
1f2a : c5 03 __ CMP WORK + 0 
1f2c : 90 02 __ BCC $1f30 ; (divmod + 21)
1f2e : e5 03 __ SBC WORK + 0 
1f30 : 26 1b __ ROL ACCU + 0 
1f32 : 2a __ __ ROL
1f33 : c5 03 __ CMP WORK + 0 
1f35 : 90 02 __ BCC $1f39 ; (divmod + 30)
1f37 : e5 03 __ SBC WORK + 0 
1f39 : 26 1b __ ROL ACCU + 0 
1f3b : ca __ __ DEX
1f3c : d0 eb __ BNE $1f29 ; (divmod + 14)
1f3e : 85 05 __ STA WORK + 2 
1f40 : 60 __ __ RTS
1f41 : a5 1b __ LDA ACCU + 0 
1f43 : 85 05 __ STA WORK + 2 
1f45 : a5 1c __ LDA ACCU + 1 
1f47 : 85 06 __ STA WORK + 3 
1f49 : a9 00 __ LDA #$00
1f4b : 85 1b __ STA ACCU + 0 
1f4d : 85 1c __ STA ACCU + 1 
1f4f : 60 __ __ RTS
1f50 : a5 04 __ LDA WORK + 1 
1f52 : d0 1f __ BNE $1f73 ; (divmod + 88)
1f54 : a5 03 __ LDA WORK + 0 
1f56 : 30 1b __ BMI $1f73 ; (divmod + 88)
1f58 : a9 00 __ LDA #$00
1f5a : 85 06 __ STA WORK + 3 
1f5c : a2 10 __ LDX #$10
1f5e : 06 1b __ ASL ACCU + 0 
1f60 : 26 1c __ ROL ACCU + 1 
1f62 : 2a __ __ ROL
1f63 : c5 03 __ CMP WORK + 0 
1f65 : 90 02 __ BCC $1f69 ; (divmod + 78)
1f67 : e5 03 __ SBC WORK + 0 
1f69 : 26 1b __ ROL ACCU + 0 
1f6b : 26 1c __ ROL ACCU + 1 
1f6d : ca __ __ DEX
1f6e : d0 f2 __ BNE $1f62 ; (divmod + 71)
1f70 : 85 05 __ STA WORK + 2 
1f72 : 60 __ __ RTS
1f73 : a9 00 __ LDA #$00
1f75 : 85 05 __ STA WORK + 2 
1f77 : 85 06 __ STA WORK + 3 
1f79 : 84 02 __ STY $02 
1f7b : a0 10 __ LDY #$10
1f7d : 18 __ __ CLC
1f7e : 26 1b __ ROL ACCU + 0 
1f80 : 26 1c __ ROL ACCU + 1 
1f82 : 26 05 __ ROL WORK + 2 
1f84 : 26 06 __ ROL WORK + 3 
1f86 : 38 __ __ SEC
1f87 : a5 05 __ LDA WORK + 2 
1f89 : e5 03 __ SBC WORK + 0 
1f8b : aa __ __ TAX
1f8c : a5 06 __ LDA WORK + 3 
1f8e : e5 04 __ SBC WORK + 1 
1f90 : 90 04 __ BCC $1f96 ; (divmod + 123)
1f92 : 86 05 __ STX WORK + 2 
1f94 : 85 06 __ STA WORK + 3 
1f96 : 88 __ __ DEY
1f97 : d0 e5 __ BNE $1f7e ; (divmod + 99)
1f99 : 26 1b __ ROL ACCU + 0 
1f9b : 26 1c __ ROL ACCU + 1 
1f9d : a4 02 __ LDY $02 
1f9f : 60 __ __ RTS
--------------------------------------------------------------------
mods16: ; mods16
1fa0 : 24 1c __ BIT ACCU + 1 
1fa2 : 10 10 __ BPL $1fb4 ; (mods16 + 20)
1fa4 : 20 ff 1e JSR $1eff ; (negaccu + 0)
1fa7 : 24 04 __ BIT WORK + 1 
1fa9 : 10 03 __ BPL $1fae ; (mods16 + 14)
1fab : 20 0d 1f JSR $1f0d ; (negtmp + 0)
1fae : 20 1b 1f JSR $1f1b ; (divmod + 0)
1fb1 : 4c bf 1f JMP $1fbf ; (negtmpb + 0)
1fb4 : 24 04 __ BIT WORK + 1 
1fb6 : 10 03 __ BPL $1fbb ; (mods16 + 27)
1fb8 : 20 0d 1f JSR $1f0d ; (negtmp + 0)
1fbb : 4c 1b 1f JMP $1f1b ; (divmod + 0)
1fbe : 60 __ __ RTS
--------------------------------------------------------------------
negtmpb: ; negtmpb
1fbf : 38 __ __ SEC
1fc0 : a9 00 __ LDA #$00
1fc2 : e5 05 __ SBC WORK + 2 
1fc4 : 85 05 __ STA WORK + 2 
1fc6 : a9 00 __ LDA #$00
1fc8 : e5 06 __ SBC WORK + 3 
1fca : 85 06 __ STA WORK + 3 
1fcc : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u16: ; f32_to_u16
1fcd : 20 5d 1c JSR $1c5d ; (freg + 36)
1fd0 : a5 07 __ LDA WORK + 4 
1fd2 : c9 7f __ CMP #$7f
1fd4 : b0 07 __ BCS $1fdd ; (f32_to_u16 + 16)
1fd6 : a9 00 __ LDA #$00
1fd8 : 85 1b __ STA ACCU + 0 
1fda : 85 1c __ STA ACCU + 1 
1fdc : 60 __ __ RTS
1fdd : e9 8e __ SBC #$8e
1fdf : 90 06 __ BCC $1fe7 ; (f32_to_u16 + 26)
1fe1 : f0 14 __ BEQ $1ff7 ; (f32_to_u16 + 42)
1fe3 : a9 ff __ LDA #$ff
1fe5 : d0 f1 __ BNE $1fd8 ; (f32_to_u16 + 11)
1fe7 : aa __ __ TAX
1fe8 : a5 1c __ LDA ACCU + 1 
1fea : 46 1d __ LSR ACCU + 2 
1fec : 6a __ __ ROR
1fed : e8 __ __ INX
1fee : d0 fa __ BNE $1fea ; (f32_to_u16 + 29)
1ff0 : 85 1b __ STA ACCU + 0 
1ff2 : a5 1d __ LDA ACCU + 2 
1ff4 : 85 1c __ STA ACCU + 1 
1ff6 : 60 __ __ RTS
1ff7 : a5 1c __ LDA ACCU + 1 
1ff9 : b0 f5 __ BCS $1ff0 ; (f32_to_u16 + 35)
1ffb : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_i32: ; f32_to_i32
1ffc : a5 1e __ LDA ACCU + 3 
1ffe : 30 03 __ BMI $2003 ; (f32_to_i32 + 7)
2000 : 4c 20 20 JMP $2020 ; (f32_to_u32 + 0)
2003 : 20 20 20 JSR $2020 ; (f32_to_u32 + 0)
2006 : 38 __ __ SEC
2007 : a9 00 __ LDA #$00
2009 : e5 1b __ SBC ACCU + 0 
200b : 85 1b __ STA ACCU + 0 
200d : a9 00 __ LDA #$00
200f : e5 1c __ SBC ACCU + 1 
2011 : 85 1c __ STA ACCU + 1 
2013 : a9 00 __ LDA #$00
2015 : e5 1d __ SBC ACCU + 2 
2017 : 85 1d __ STA ACCU + 2 
2019 : a9 00 __ LDA #$00
201b : e5 1e __ SBC ACCU + 3 
201d : 85 1e __ STA ACCU + 3 
201f : 60 __ __ RTS
--------------------------------------------------------------------
f32_to_u32: ; f32_to_u32
2020 : 20 5d 1c JSR $1c5d ; (freg + 36)
2023 : a5 07 __ LDA WORK + 4 
2025 : c9 7f __ CMP #$7f
2027 : b0 0b __ BCS $2034 ; (f32_to_u32 + 20)
2029 : a9 00 __ LDA #$00
202b : 85 1b __ STA ACCU + 0 
202d : 85 1c __ STA ACCU + 1 
202f : 85 1d __ STA ACCU + 2 
2031 : 85 1e __ STA ACCU + 3 
2033 : 60 __ __ RTS
2034 : 38 __ __ SEC
2035 : e9 9e __ SBC #$9e
2037 : f0 13 __ BEQ $204c ; (f32_to_u32 + 44)
2039 : 90 04 __ BCC $203f ; (f32_to_u32 + 31)
203b : a9 ff __ LDA #$ff
203d : d0 ec __ BNE $202b ; (f32_to_u32 + 11)
203f : aa __ __ TAX
2040 : a9 00 __ LDA #$00
2042 : 46 1d __ LSR ACCU + 2 
2044 : 66 1c __ ROR ACCU + 1 
2046 : 66 1b __ ROR ACCU + 0 
2048 : 6a __ __ ROR
2049 : e8 __ __ INX
204a : d0 f6 __ BNE $2042 ; (f32_to_u32 + 34)
204c : a6 1d __ LDX ACCU + 2 
204e : 86 1e __ STX ACCU + 3 
2050 : a6 1c __ LDX ACCU + 1 
2052 : 86 1d __ STX ACCU + 2 
2054 : a6 1b __ LDX ACCU + 0 
2056 : 86 1c __ STX ACCU + 1 
2058 : 85 1b __ STA ACCU + 0 
205a : 60 __ __ RTS
--------------------------------------------------------------------
sint16_to_float: ; sint16_to_float
205b : 24 1c __ BIT ACCU + 1 
205d : 30 03 __ BMI $2062 ; (sint16_to_float + 7)
205f : 4c 79 20 JMP $2079 ; (uint16_to_float + 0)
2062 : 38 __ __ SEC
2063 : a9 00 __ LDA #$00
2065 : e5 1b __ SBC ACCU + 0 
2067 : 85 1b __ STA ACCU + 0 
2069 : a9 00 __ LDA #$00
206b : e5 1c __ SBC ACCU + 1 
206d : 85 1c __ STA ACCU + 1 
206f : 20 79 20 JSR $2079 ; (uint16_to_float + 0)
2072 : a5 1e __ LDA ACCU + 3 
2074 : 09 80 __ ORA #$80
2076 : 85 1e __ STA ACCU + 3 
2078 : 60 __ __ RTS
--------------------------------------------------------------------
uint16_to_float: ; uint16_to_float
2079 : a5 1b __ LDA ACCU + 0 
207b : 05 1c __ ORA ACCU + 1 
207d : d0 05 __ BNE $2084 ; (uint16_to_float + 11)
207f : 85 1d __ STA ACCU + 2 
2081 : 85 1e __ STA ACCU + 3 
2083 : 60 __ __ RTS
2084 : a2 8e __ LDX #$8e
2086 : a5 1c __ LDA ACCU + 1 
2088 : 30 06 __ BMI $2090 ; (uint16_to_float + 23)
208a : ca __ __ DEX
208b : 06 1b __ ASL ACCU + 0 
208d : 2a __ __ ROL
208e : 10 fa __ BPL $208a ; (uint16_to_float + 17)
2090 : 0a __ __ ASL
2091 : 85 1d __ STA ACCU + 2 
2093 : a5 1b __ LDA ACCU + 0 
2095 : 85 1c __ STA ACCU + 1 
2097 : 8a __ __ TXA
2098 : 4a __ __ LSR
2099 : 85 1e __ STA ACCU + 3 
209b : a9 00 __ LDA #$00
209d : 85 1b __ STA ACCU + 0 
209f : 66 1d __ ROR ACCU + 2 
20a1 : 60 __ __ RTS
--------------------------------------------------------------------
sint32_to_float: ; sint32_to_float
20a2 : 24 1e __ BIT ACCU + 3 
20a4 : 30 03 __ BMI $20a9 ; (sint32_to_float + 7)
20a6 : 4c cc 20 JMP $20cc ; (uint32_to_float + 0)
20a9 : 38 __ __ SEC
20aa : a9 00 __ LDA #$00
20ac : e5 1b __ SBC ACCU + 0 
20ae : 85 1b __ STA ACCU + 0 
20b0 : a9 00 __ LDA #$00
20b2 : e5 1c __ SBC ACCU + 1 
20b4 : 85 1c __ STA ACCU + 1 
20b6 : a9 00 __ LDA #$00
20b8 : e5 1d __ SBC ACCU + 2 
20ba : 85 1d __ STA ACCU + 2 
20bc : a9 00 __ LDA #$00
20be : e5 1e __ SBC ACCU + 3 
20c0 : 85 1e __ STA ACCU + 3 
20c2 : 20 cc 20 JSR $20cc ; (uint32_to_float + 0)
20c5 : a5 1e __ LDA ACCU + 3 
20c7 : 09 80 __ ORA #$80
20c9 : 85 1e __ STA ACCU + 3 
20cb : 60 __ __ RTS
--------------------------------------------------------------------
uint32_to_float: ; uint32_to_float
20cc : a5 1b __ LDA ACCU + 0 
20ce : 05 1c __ ORA ACCU + 1 
20d0 : 05 1d __ ORA ACCU + 2 
20d2 : 05 1e __ ORA ACCU + 3 
20d4 : d0 01 __ BNE $20d7 ; (uint32_to_float + 11)
20d6 : 60 __ __ RTS
20d7 : a2 9e __ LDX #$9e
20d9 : a5 1e __ LDA ACCU + 3 
20db : 30 0a __ BMI $20e7 ; (uint32_to_float + 27)
20dd : ca __ __ DEX
20de : 06 1b __ ASL ACCU + 0 
20e0 : 26 1c __ ROL ACCU + 1 
20e2 : 26 1d __ ROL ACCU + 2 
20e4 : 2a __ __ ROL
20e5 : 10 f6 __ BPL $20dd ; (uint32_to_float + 17)
20e7 : 24 1b __ BIT ACCU + 0 
20e9 : 10 13 __ BPL $20fe ; (uint32_to_float + 50)
20eb : e6 1c __ INC ACCU + 1 
20ed : d0 0f __ BNE $20fe ; (uint32_to_float + 50)
20ef : e6 1d __ INC ACCU + 2 
20f1 : d0 0b __ BNE $20fe ; (uint32_to_float + 50)
20f3 : 18 __ __ CLC
20f4 : 69 01 __ ADC #$01
20f6 : 90 06 __ BCC $20fe ; (uint32_to_float + 50)
20f8 : 4a __ __ LSR
20f9 : 66 1d __ ROR ACCU + 2 
20fb : 66 1c __ ROR ACCU + 1 
20fd : e8 __ __ INX
20fe : 0a __ __ ASL
20ff : a4 1c __ LDY ACCU + 1 
2101 : 84 1b __ STY ACCU + 0 
2103 : a4 1d __ LDY ACCU + 2 
2105 : 84 1c __ STY ACCU + 1 
2107 : 85 1d __ STA ACCU + 2 
2109 : 8a __ __ TXA
210a : 4a __ __ LSR
210b : 85 1e __ STA ACCU + 3 
210d : 66 1d __ ROR ACCU + 2 
210f : 60 __ __ RTS
--------------------------------------------------------------------
crt_fcmp: ; crt_fcmp
2110 : a5 1e __ LDA ACCU + 3 
2112 : 45 06 __ EOR WORK + 3 
2114 : 10 1e __ BPL $2134 ; (crt_fcmp + 36)
2116 : a5 1e __ LDA ACCU + 3 
2118 : 29 7f __ AND #$7f
211a : 05 1d __ ORA ACCU + 2 
211c : 05 1c __ ORA ACCU + 1 
211e : 05 1b __ ORA ACCU + 0 
2120 : d0 0c __ BNE $212e ; (crt_fcmp + 30)
2122 : a5 06 __ LDA WORK + 3 
2124 : 29 7f __ AND #$7f
2126 : 05 05 __ ORA WORK + 2 
2128 : 05 04 __ ORA WORK + 1 
212a : 05 03 __ ORA WORK + 0 
212c : f0 1e __ BEQ $214c ; (crt_fcmp + 60)
212e : a5 1e __ LDA ACCU + 3 
2130 : 30 23 __ BMI $2155 ; (crt_fcmp + 69)
2132 : 10 28 __ BPL $215c ; (crt_fcmp + 76)
2134 : a5 1e __ LDA ACCU + 3 
2136 : c5 06 __ CMP WORK + 3 
2138 : d0 15 __ BNE $214f ; (crt_fcmp + 63)
213a : a5 1d __ LDA ACCU + 2 
213c : c5 05 __ CMP WORK + 2 
213e : d0 0f __ BNE $214f ; (crt_fcmp + 63)
2140 : a5 1c __ LDA ACCU + 1 
2142 : c5 04 __ CMP WORK + 1 
2144 : d0 09 __ BNE $214f ; (crt_fcmp + 63)
2146 : a5 1b __ LDA ACCU + 0 
2148 : c5 03 __ CMP WORK + 0 
214a : d0 03 __ BNE $214f ; (crt_fcmp + 63)
214c : a9 00 __ LDA #$00
214e : 60 __ __ RTS
214f : b0 07 __ BCS $2158 ; (crt_fcmp + 72)
2151 : 24 1e __ BIT ACCU + 3 
2153 : 30 07 __ BMI $215c ; (crt_fcmp + 76)
2155 : a9 01 __ LDA #$01
2157 : 60 __ __ RTS
2158 : 24 1e __ BIT ACCU + 3 
215a : 30 f9 __ BMI $2155 ; (crt_fcmp + 69)
215c : a9 ff __ LDA #$ff
215e : 60 __ __ RTS
--------------------------------------------------------------------
mul32: ; mul32
215f : a5 04 __ LDA WORK + 1 
2161 : 05 05 __ ORA WORK + 2 
2163 : 05 06 __ ORA WORK + 3 
2165 : d0 05 __ BNE $216c ; (mul32 + 13)
2167 : a5 03 __ LDA WORK + 0 
2169 : 4c 03 1c JMP $1c03 ; (mul32by8 + 0)
216c : a0 00 __ LDY #$00
216e : 84 07 __ STY WORK + 4 
2170 : 84 08 __ STY WORK + 5 
2172 : 98 __ __ TYA
2173 : 38 __ __ SEC
2174 : 66 03 __ ROR WORK + 0 
2176 : 90 15 __ BCC $218d ; (mul32 + 46)
2178 : aa __ __ TAX
2179 : 18 __ __ CLC
217a : a5 07 __ LDA WORK + 4 
217c : 65 1b __ ADC ACCU + 0 
217e : 85 07 __ STA WORK + 4 
2180 : a5 08 __ LDA WORK + 5 
2182 : 65 1c __ ADC ACCU + 1 
2184 : 85 08 __ STA WORK + 5 
2186 : 98 __ __ TYA
2187 : 65 1d __ ADC ACCU + 2 
2189 : a8 __ __ TAY
218a : 8a __ __ TXA
218b : 65 1e __ ADC ACCU + 3 
218d : 46 04 __ LSR WORK + 1 
218f : 90 0f __ BCC $21a0 ; (mul32 + 65)
2191 : aa __ __ TAX
2192 : 18 __ __ CLC
2193 : a5 08 __ LDA WORK + 5 
2195 : 65 1b __ ADC ACCU + 0 
2197 : 85 08 __ STA WORK + 5 
2199 : 98 __ __ TYA
219a : 65 1c __ ADC ACCU + 1 
219c : a8 __ __ TAY
219d : 8a __ __ TXA
219e : 65 1d __ ADC ACCU + 2 
21a0 : 46 05 __ LSR WORK + 2 
21a2 : 90 09 __ BCC $21ad ; (mul32 + 78)
21a4 : aa __ __ TAX
21a5 : 18 __ __ CLC
21a6 : 98 __ __ TYA
21a7 : 65 1b __ ADC ACCU + 0 
21a9 : a8 __ __ TAY
21aa : 8a __ __ TXA
21ab : 65 1c __ ADC ACCU + 1 
21ad : 46 06 __ LSR WORK + 3 
21af : 90 03 __ BCC $21b4 ; (mul32 + 85)
21b1 : 18 __ __ CLC
21b2 : 65 1b __ ADC ACCU + 0 
21b4 : 06 1b __ ASL ACCU + 0 
21b6 : 26 1c __ ROL ACCU + 1 
21b8 : 26 1d __ ROL ACCU + 2 
21ba : 26 1e __ ROL ACCU + 3 
21bc : 46 03 __ LSR WORK + 0 
21be : 90 cd __ BCC $218d ; (mul32 + 46)
21c0 : d0 b6 __ BNE $2178 ; (mul32 + 25)
21c2 : 84 09 __ STY WORK + 6 
21c4 : 85 0a __ STA WORK + 7 
21c6 : 60 __ __ RTS
--------------------------------------------------------------------
divs32: ; divs32
21c7 : 24 1e __ BIT ACCU + 3 
21c9 : 10 0d __ BPL $21d8 ; (divs32 + 17)
21cb : 20 e5 21 JSR $21e5 ; (negaccu32 + 0)
21ce : 24 06 __ BIT WORK + 3 
21d0 : 10 0d __ BPL $21df ; (divs32 + 24)
21d2 : 20 ff 21 JSR $21ff ; (negtmp32 + 0)
21d5 : 4c 19 22 JMP $2219 ; (divmod32 + 0)
21d8 : 24 06 __ BIT WORK + 3 
21da : 10 f9 __ BPL $21d5 ; (divs32 + 14)
21dc : 20 ff 21 JSR $21ff ; (negtmp32 + 0)
21df : 20 19 22 JSR $2219 ; (divmod32 + 0)
21e2 : 4c e5 21 JMP $21e5 ; (negaccu32 + 0)
--------------------------------------------------------------------
negaccu32: ; negaccu32
21e5 : 38 __ __ SEC
21e6 : a9 00 __ LDA #$00
21e8 : e5 1b __ SBC ACCU + 0 
21ea : 85 1b __ STA ACCU + 0 
21ec : a9 00 __ LDA #$00
21ee : e5 1c __ SBC ACCU + 1 
21f0 : 85 1c __ STA ACCU + 1 
21f2 : a9 00 __ LDA #$00
21f4 : e5 1d __ SBC ACCU + 2 
21f6 : 85 1d __ STA ACCU + 2 
21f8 : a9 00 __ LDA #$00
21fa : e5 1e __ SBC ACCU + 3 
21fc : 85 1e __ STA ACCU + 3 
21fe : 60 __ __ RTS
--------------------------------------------------------------------
negtmp32: ; negtmp32
21ff : 38 __ __ SEC
2200 : a9 00 __ LDA #$00
2202 : e5 03 __ SBC WORK + 0 
2204 : 85 03 __ STA WORK + 0 
2206 : a9 00 __ LDA #$00
2208 : e5 04 __ SBC WORK + 1 
220a : 85 04 __ STA WORK + 1 
220c : a9 00 __ LDA #$00
220e : e5 05 __ SBC WORK + 2 
2210 : 85 05 __ STA WORK + 2 
2212 : a9 00 __ LDA #$00
2214 : e5 06 __ SBC WORK + 3 
2216 : 85 06 __ STA WORK + 3 
2218 : 60 __ __ RTS
--------------------------------------------------------------------
divmod32: ; divmod32
2219 : 84 02 __ STY $02 
221b : a0 20 __ LDY #$20
221d : a9 00 __ LDA #$00
221f : 85 07 __ STA WORK + 4 
2221 : 85 08 __ STA WORK + 5 
2223 : 85 09 __ STA WORK + 6 
2225 : 85 0a __ STA WORK + 7 
2227 : a5 05 __ LDA WORK + 2 
2229 : 05 06 __ ORA WORK + 3 
222b : d0 78 __ BNE $22a5 ; (divmod32 + 140)
222d : a5 04 __ LDA WORK + 1 
222f : d0 27 __ BNE $2258 ; (divmod32 + 63)
2231 : 18 __ __ CLC
2232 : 26 1b __ ROL ACCU + 0 
2234 : 26 1c __ ROL ACCU + 1 
2236 : 26 1d __ ROL ACCU + 2 
2238 : 26 1e __ ROL ACCU + 3 
223a : 2a __ __ ROL
223b : 90 05 __ BCC $2242 ; (divmod32 + 41)
223d : e5 03 __ SBC WORK + 0 
223f : 38 __ __ SEC
2240 : b0 06 __ BCS $2248 ; (divmod32 + 47)
2242 : c5 03 __ CMP WORK + 0 
2244 : 90 02 __ BCC $2248 ; (divmod32 + 47)
2246 : e5 03 __ SBC WORK + 0 
2248 : 88 __ __ DEY
2249 : d0 e7 __ BNE $2232 ; (divmod32 + 25)
224b : 85 07 __ STA WORK + 4 
224d : 26 1b __ ROL ACCU + 0 
224f : 26 1c __ ROL ACCU + 1 
2251 : 26 1d __ ROL ACCU + 2 
2253 : 26 1e __ ROL ACCU + 3 
2255 : a4 02 __ LDY $02 
2257 : 60 __ __ RTS
2258 : a5 1e __ LDA ACCU + 3 
225a : d0 10 __ BNE $226c ; (divmod32 + 83)
225c : a6 1d __ LDX ACCU + 2 
225e : 86 1e __ STX ACCU + 3 
2260 : a6 1c __ LDX ACCU + 1 
2262 : 86 1d __ STX ACCU + 2 
2264 : a6 1b __ LDX ACCU + 0 
2266 : 86 1c __ STX ACCU + 1 
2268 : 85 1b __ STA ACCU + 0 
226a : a0 18 __ LDY #$18
226c : 18 __ __ CLC
226d : 26 1b __ ROL ACCU + 0 
226f : 26 1c __ ROL ACCU + 1 
2271 : 26 1d __ ROL ACCU + 2 
2273 : 26 1e __ ROL ACCU + 3 
2275 : 26 07 __ ROL WORK + 4 
2277 : 26 08 __ ROL WORK + 5 
2279 : 90 0c __ BCC $2287 ; (divmod32 + 110)
227b : a5 07 __ LDA WORK + 4 
227d : e5 03 __ SBC WORK + 0 
227f : aa __ __ TAX
2280 : a5 08 __ LDA WORK + 5 
2282 : e5 04 __ SBC WORK + 1 
2284 : 38 __ __ SEC
2285 : b0 0c __ BCS $2293 ; (divmod32 + 122)
2287 : 38 __ __ SEC
2288 : a5 07 __ LDA WORK + 4 
228a : e5 03 __ SBC WORK + 0 
228c : aa __ __ TAX
228d : a5 08 __ LDA WORK + 5 
228f : e5 04 __ SBC WORK + 1 
2291 : 90 04 __ BCC $2297 ; (divmod32 + 126)
2293 : 86 07 __ STX WORK + 4 
2295 : 85 08 __ STA WORK + 5 
2297 : 88 __ __ DEY
2298 : d0 d3 __ BNE $226d ; (divmod32 + 84)
229a : 26 1b __ ROL ACCU + 0 
229c : 26 1c __ ROL ACCU + 1 
229e : 26 1d __ ROL ACCU + 2 
22a0 : 26 1e __ ROL ACCU + 3 
22a2 : a4 02 __ LDY $02 
22a4 : 60 __ __ RTS
22a5 : a0 10 __ LDY #$10
22a7 : a5 1e __ LDA ACCU + 3 
22a9 : 85 08 __ STA WORK + 5 
22ab : a5 1d __ LDA ACCU + 2 
22ad : 85 07 __ STA WORK + 4 
22af : a9 00 __ LDA #$00
22b1 : 85 1d __ STA ACCU + 2 
22b3 : 85 1e __ STA ACCU + 3 
22b5 : 18 __ __ CLC
22b6 : 26 1b __ ROL ACCU + 0 
22b8 : 26 1c __ ROL ACCU + 1 
22ba : 26 07 __ ROL WORK + 4 
22bc : 26 08 __ ROL WORK + 5 
22be : 26 09 __ ROL WORK + 6 
22c0 : 26 0a __ ROL WORK + 7 
22c2 : a5 07 __ LDA WORK + 4 
22c4 : c5 03 __ CMP WORK + 0 
22c6 : a5 08 __ LDA WORK + 5 
22c8 : e5 04 __ SBC WORK + 1 
22ca : a5 09 __ LDA WORK + 6 
22cc : e5 05 __ SBC WORK + 2 
22ce : aa __ __ TAX
22cf : a5 0a __ LDA WORK + 7 
22d1 : e5 06 __ SBC WORK + 3 
22d3 : 90 11 __ BCC $22e6 ; (divmod32 + 205)
22d5 : 86 09 __ STX WORK + 6 
22d7 : 85 0a __ STA WORK + 7 
22d9 : a5 07 __ LDA WORK + 4 
22db : e5 03 __ SBC WORK + 0 
22dd : 85 07 __ STA WORK + 4 
22df : a5 08 __ LDA WORK + 5 
22e1 : e5 04 __ SBC WORK + 1 
22e3 : 85 08 __ STA WORK + 5 
22e5 : 38 __ __ SEC
22e6 : 88 __ __ DEY
22e7 : d0 cd __ BNE $22b6 ; (divmod32 + 157)
22e9 : 26 1b __ ROL ACCU + 0 
22eb : 26 1c __ ROL ACCU + 1 
22ed : a4 02 __ LDY $02 
22ef : 60 __ __ RTS
--------------------------------------------------------------------
mods32: ; mods32
22f0 : 24 1e __ BIT ACCU + 3 
22f2 : 10 13 __ BPL $2307 ; (mods32 + 23)
22f4 : 20 e5 21 JSR $21e5 ; (negaccu32 + 0)
22f7 : 24 06 __ BIT WORK + 3 
22f9 : 10 03 __ BPL $22fe ; (mods32 + 14)
22fb : 20 ff 21 JSR $21ff ; (negtmp32 + 0)
22fe : 20 19 22 JSR $2219 ; (divmod32 + 0)
2301 : 4c 11 23 JMP $2311 ; (negtmp32b + 0)
2304 : 4c 19 22 JMP $2219 ; (divmod32 + 0)
2307 : 24 06 __ BIT WORK + 3 
2309 : 10 f9 __ BPL $2304 ; (mods32 + 20)
230b : 20 ff 21 JSR $21ff ; (negtmp32 + 0)
230e : 4c 19 22 JMP $2219 ; (divmod32 + 0)
--------------------------------------------------------------------
negtmp32b: ; negtmp32b
2311 : 38 __ __ SEC
2312 : a9 00 __ LDA #$00
2314 : e5 07 __ SBC WORK + 4 
2316 : 85 07 __ STA WORK + 4 
2318 : a9 00 __ LDA #$00
231a : e5 08 __ SBC WORK + 5 
231c : 85 08 __ STA WORK + 5 
231e : a9 00 __ LDA #$00
2320 : e5 09 __ SBC WORK + 6 
2322 : 85 09 __ STA WORK + 6 
2324 : a9 00 __ LDA #$00
2326 : e5 0a __ SBC WORK + 7 
2328 : 85 0a __ STA WORK + 7 
232a : 60 __ __ RTS
--------------------------------------------------------------------
__multab16384H:
232b : __ __ __ BYT 00 40 80 c0                                     : .@..
--------------------------------------------------------------------
spentry:
232f : __ __ __ BYT 00                                              : .
--------------------------------------------------------------------
b_mem:
2330 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_col:
2332 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_row:
2334 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
b_gosubSP:
2336 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tsb_inited:
2338 : __ __ __ BYT 00 00                                           : ..
--------------------------------------------------------------------
tab:
233a : __ __ __ BYT 00 06 0d 13 19 1f 25 2c 32 38 3e 44 4a 50 56 5c : ......%,28>DJPV\
234a : __ __ __ BYT 62 67 6d 73 78 7e 83 88 8e 93 98 9d a2 a7 ab b0 : bgmsx~..........
235a : __ __ __ BYT b4 b9 bd c1 c5 c9 cd d0 d4 d7 db de e1 e4 e7 e9 : ................
236a : __ __ __ BYT ec ee f0 f2 f4 f6 f7 f9 fa fb fc fd fe fe ff ff : ................
--------------------------------------------------------------------
tsb_rottab:
237a : __ __ __ BYT 01 00 00 ff 00 ff 01 00 01 01 ff ff 01 ff 01 ff : ................
238a : __ __ __ BYT 00 01 ff 00 01 00 00 ff ff 01 ff 01 01 01 ff ff : ................
239a : __ __ __ BYT ff 00 00 01 00 01 ff 00 ff ff 01 01 ff 01 ff 01 : ................
23aa : __ __ __ BYT 00 ff 01 00 ff 00 00 01 01 ff 01 ff ff ff 01 01 : ................
--------------------------------------------------------------------
b_rndSeed:
23ba : __ __ __ BYT 78 56 34 12                                     : xV4.
--------------------------------------------------------------------
tsb_sintab:
23be : __ __ __ BSS	64
--------------------------------------------------------------------
b_v_ni:
23fe : __ __ __ BSS	2
--------------------------------------------------------------------
tsb_drawtab:
2400 : __ __ __ BSS	8
--------------------------------------------------------------------
b_v_bi:
2408 : __ __ __ BSS	4
--------------------------------------------------------------------
b_a_bxi:
240c : __ __ __ BSS	512
--------------------------------------------------------------------
b_a_byi:
260c : __ __ __ BSS	512
--------------------------------------------------------------------
b_a_bci:
280c : __ __ __ BSS	512
--------------------------------------------------------------------
b_a_xi:
2a0c : __ __ __ BSS	512
--------------------------------------------------------------------
b_a_yi:
2c0c : __ __ __ BSS	512
--------------------------------------------------------------------
b_v_ii:
2e0c : __ __ __ BSS	2
--------------------------------------------------------------------
b_v_ti:
2e0e : __ __ __ BSS	4
--------------------------------------------------------------------
b_gosubStack:
2e12 : __ __ __ BSS	512
