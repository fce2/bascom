/* OPTIMIZE_C -- matrix.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static int b_v_sci;
static unsigned int b_v_cri;
static int b_a_hi[40];
static int b_a_ei[40];
static int b_a_ti[40];
static int b_a_chi[40];
static int b_a_di[40];
static bint_t b_v_ci;
static bint_t b_v_pi;
static int b_v_bi;
static bint_t b_t_0;
static bint_t b_t_1;
static bint_t b_t_2;
static bint_t b_t_3;
static bint_t b_t_4;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 10 */
b_L10: ;
		/* line 20 */
b_L20: ;
		/* line 30 */
b_L30: ;
		b_poke((53280.0),(0));
		b_poke((53281.0),(0));
		/* line 40 */
b_L40: ;
		b_putc(147);
		b_nl();
		/* line 50 */
b_L50: ;
		b_v_sci=(1024);
		b_v_cri=(55296.0);
		/* line 60 */
b_L60: ;
		/* line 70 */
b_L70: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f0_e;
b_f0_t: ;
		/* line 80 */
b_L80: ;
		b_a_hi[B_INT(b_v_ci)]=b_int(((b_rnd(B_INT((1))))*((25))));
		/* line 90 */
b_L90: ;
		b_a_ti[B_INT(b_v_ci)]=(((5))+(b_int(((b_rnd(B_INT((1))))*((10))))));
		/* line 100 */
b_L100: ;
		b_a_ei[B_INT(b_v_ci)]=((b_a_hi[B_INT(b_v_ci)])-(b_a_ti[B_INT(b_v_ci)]));
		if(-((b_a_ei[B_INT(b_v_ci)]) < ((0)))){
			b_a_ei[B_INT(b_v_ci)]=((b_a_ei[B_INT(b_v_ci)])+((25)));
		}
		/* line 110 */
b_L110: ;
		b_a_chi[B_INT(b_v_ci)]=(((33))+(b_int(((b_rnd(B_INT((1))))*((58))))));
		/* line 120 */
b_L120: ;
		b_a_di[B_INT(b_v_ci)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((5))))));
		/* line 130 */
b_L130: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f0_t;
b_f0_e: ;
		/* line 140 */
b_L140: ;
		b_v_ci=(0);
		if(b_v_ci > 39) goto b_f1_e;
b_f1_t: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1000;
b_ret0: ;
		b_v_ci += 1;
		if(b_v_ci <= 39) goto b_f1_t;
b_f1_e: ;
		/* line 150 */
b_L150: ;
		goto b_L140;
		/* line 1000 */
b_L1000: ;
		/* line 1001 */
b_L1001: ;
		b_v_pi=((((b_a_hi[B_INT(b_v_ci)])*((40))))+(b_v_ci));
		/* line 1002 */
b_L1002: ;
		b_poke(((b_v_sci)+(b_v_pi)),b_a_chi[B_INT(b_v_ci)]);
		b_poke(((b_v_cri)+(b_v_pi)),(1));
		/* line 1003 */
b_L1003: ;
		b_a_chi[B_INT(b_v_ci)]=((b_a_chi[B_INT(b_v_ci)])+(b_a_di[B_INT(b_v_ci)]));
		if(-((b_a_chi[B_INT(b_v_ci)]) > ((90)))){
			b_a_chi[B_INT(b_v_ci)]=((b_a_chi[B_INT(b_v_ci)])-((58)));
		}
		/* line 1004 */
b_L1004: ;
		b_v_bi=((b_a_hi[B_INT(b_v_ci)])-((1)));
		if(-((b_v_bi) < ((0)))){
			b_v_bi=(24);
		}
		/* line 1005 */
b_L1005: ;
		b_poke(((((b_v_cri)+(((b_v_bi)*((40))))))+(b_v_ci)),(13));
		/* line 1006 */
b_L1006: ;
		b_v_bi=((b_v_bi)-((1)));
		if(-((b_v_bi) < ((0)))){
			b_v_bi=(24);
		}
		/* line 1007 */
b_L1007: ;
		b_poke(((((b_v_cri)+(((b_v_bi)*((40))))))+(b_v_ci)),(5));
		/* line 1008 */
b_L1008: ;
		b_poke(((((b_v_sci)+(((b_a_ei[B_INT(b_v_ci)])*((40))))))+(b_v_ci)),(32));
		/* line 1009 */
b_L1009: ;
		b_a_hi[B_INT(b_v_ci)]=((b_a_hi[B_INT(b_v_ci)])+((1)));
		if(-((b_a_hi[B_INT(b_v_ci)]) > ((24)))){
			b_a_hi[B_INT(b_v_ci)]=(0);
			b_a_chi[B_INT(b_v_ci)]=(((33))+(b_int(((b_rnd(B_INT((1))))*((58))))));
			b_a_di[B_INT(b_v_ci)]=(((1))+(b_int(((b_rnd(B_INT((1))))*((5))))));
		}
		/* line 1010 */
b_L1010: ;
		b_a_ei[B_INT(b_v_ci)]=((b_a_ei[B_INT(b_v_ci)])+((1)));
		if(-((b_a_ei[B_INT(b_v_ci)]) > ((24)))){
			b_a_ei[B_INT(b_v_ci)]=(0);
		}
		/* line 1011 */
b_L1011: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
