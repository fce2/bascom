; -- life.bas
; C64 BASIC V2 -> 6502  |  2983 bytes PRG, 47 source lines
	* = $0801
	; entry  $0C3A   (10 SYS -> code)
	; vars   $1354 .. $13A8   (39 vars, 84 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$33,$31,$33,$30,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- string pool ----

str0:
0813 :  .byte $54,$49,$4D,$45,$3D	; "TIME="

str1:
0818 :  .byte $47,$45,$4E,$53,$3D	; "GENS="

str2:
081D :  .byte $41,$4C,$49,$56,$45,$3D	; "ALIVE="
; ---- float const pool ----

fconst0:
0823 :  .byte $7F,$19,$99,$99,$9A

fconst1:
0828 :  .byte $91,$00,$00,$00,$00

ftemp:
082D :  .res 5	; float temp slots

ti_t1:
0832 :  .res 5	; TI read 5-byte float temp (24-bit jiffy->FAC hi-byte accum)

rnd_st:
0837 :  .res 2	; RT_rnd_fast 16-bit LFSR state (lo,hi)
; ---- mulK lookup tables (speed-mode V*K strength reduction) ----

mulK40_lo:
0839 :  .byte $00,$28,$50,$78,$A0,$C8,$F0,$18,$40,$68,$90,$B8,$E0,$08,$30,$58	; mulK lo bytes (i*K & 0xFF)
	.byte $80,$A8,$D0,$F8,$20,$48

mulK40_hi:
084F :  .byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02	; mulK hi bytes (i*K >> 8)
	.byte $02,$02,$02,$02,$03,$03
; ---- runtime helpers ----

RT_print_str:
0865 :  TAX
0866 :  LDY #0 ; $00

.ps_loop:
0868 :  TXA
0869 :  BEQ ps_skip
086B :  LDA (ZP_PTR),Y ; $FB
086D :  JSR ROM_CHROUT ; $FFD2
0870 :  INY
0871 :  DEX
0872 :  JMP .ps_loop ; $0868

0875 :  RTS

uword2dec_shiftedbcd:
0876 :  .byte $00,$01,$02,$03,$04,$08,$09,$0A,$0B,$0C,$10,$11,$12,$13,$14,$18	; ShiftedBcdTab (Omegamatrix HexToDec65535)
	.byte $19,$1A,$1B,$1C,$20,$21,$22,$23,$24,$28,$29,$2A,$2B,$2C,$30,$31
	.byte $32,$33,$34,$38,$39,$3A,$3B,$3C,$40,$41,$42,$43,$44,$48,$49,$4A
	.byte $4B,$4C

uword2dec_mod100:
08A8 :  .byte $00,$38,$0C,$44	; Mod100Tab

uword2dec_decbuf:
08AC :  .res 6	; decbuf: 5 ASCII digits + 0 terminator

RT_uword2dec:
08B2 :  STY ZP_SCR16 + 1 ; $FE
08B4 :  STA ZP_SCR16 ; $FD
08B6 :  TYA
08B7 :  TAX
08B8 :  LSR
08B9 :  LSR
08BA :  CPX #0xA7 ; $A7
08BC :  ADC #1 ; $01
08BE :  STA ZP_MULMP ; $FA
08C0 :  ASL
08C1 :  ADC ZP_MULMP ; $FA
08C3 :  TAY
08C4 :  LSR
08C5 :  LSR
08C6 :  LSR
08C7 :  LSR
08C8 :  LSR
08C9 :  TAX
08CA :  TYA
08CB :  ASL
08CC :  ASL
08CD :  ASL
08CE :  CLC
08CF :  ADC ZP_SCR16 ; $FD
08D1 :  STA ZP_SCR16 ; $FD
08D3 :  TXA
08D4 :  ADC ZP_SCR16 + 1 ; $FE
08D6 :  STA ZP_SCR16 + 1 ; $FE
08D8 :  ROR
08D9 :  LSR
08DA :  TAY
08DB :  LSR
08DC :  TAX
08DD :  LDA ShiftedBcdTab,X ; $0876
08E0 :  TAX
08E1 :  ROL
08E2 :  AND #0x0F ; $0F
08E4 :  ORA #0x30 ; $30
08E6 :  STA uword2dec_decbuf + 1 ; $08AD
08E9 :  TXA
08EA :  LSR
08EB :  LSR
08EC :  LSR
08ED :  ORA #0x30 ; $30
08EF :  STA uword2dec_decbuf + 0 ; $08AC
08F2 :  LDA ZP_SCR16 ; $FD
08F4 :  CPY ZP_MULMP ; $FA
08F6 :  BMI .uw_doSub
08F8 :  BEQ .uw_useZero
08FA :  ADC #23 + 24 ; $2F

.uw_doSub:
08FC :  SBC #23 ; $17
08FE :  STA ZP_SCR16 ; $FD

.uw_useZero:
0900 :  LDA ZP_SCR16 + 1 ; $FE
0902 :  SBC #0 ; $00
0904 :  AND #0x03 ; $03
0906 :  TAX
0907 :  CMP #2 ; $02
0909 :  ROL
090A :  ORA #0x30 ; $30
090C :  TAY
090D :  LDA ZP_SCR16 ; $FD
090F :  ADC uword2dec_mod100,X ; $08A8
0912 :  BCS .uw_doSub200
0914 :  CMP #200 ; $C8
0916 :  BCC .uw_try100

.uw_doSub200:
0918 :  INY
0919 :  INY
091A :  SBC #200 ; $C8

.uw_try100:
091C :  CMP #100 ; $64
091E :  BCC .uw_h2d99
0920 :  INY
0921 :  SBC #100 ; $64

.uw_h2d99:
0923 :  LSR
0924 :  TAX
0925 :  LDA ShiftedBcdTab,X ; $0876
0928 :  TAX
0929 :  ROL
092A :  AND #0x0F ; $0F
092C :  ORA #0x30 ; $30
092E :  STA uword2dec_decbuf + 4 ; $08B0
0931 :  TXA
0932 :  LSR
0933 :  LSR
0934 :  LSR
0935 :  ORA #0x30 ; $30
0937 :  STY uword2dec_decbuf + 2 ; $08AE
093A :  STA uword2dec_decbuf + 3 ; $08AF
093D :  LDX uword2dec_decbuf + 4 ; $08B0
0940 :  RTS

RT_print_int:
0941 :  STA ZP_SCR16 ; $FD
0943 :  STX ZP_SCR16 + 1 ; $FE
0945 :  LDA #0x20 ; $20
0947 :  BIT ZP_SCR16 + 1 ; $FE
0949 :  BPL .pos
094B :  SEC
094C :  LDA #0 ; $00
094E :  SBC ZP_SCR16 ; $FD
0950 :  STA ZP_SCR16 ; $FD
0952 :  LDA #0 ; $00
0954 :  SBC ZP_SCR16 + 1 ; $FE
0956 :  STA ZP_SCR16 + 1 ; $FE
0958 :  LDA #0x2D ; $2D

.pos:
095A :  JSR ROM_CHROUT ; $FFD2
095D :  LDY ZP_SCR16 + 1 ; $FE
095F :  LDA ZP_SCR16 ; $FD
0961 :  JSR RT_uword2dec ; $08B2
0964 :  LDY #0 ; $00

.uw_skip:
0966 :  LDA uword2dec_decbuf,Y ; $08AC
0969 :  BEQ .uw_allzero_l
096B :  CMP #0x30 ; $30
096D :  BNE .uw_got_l
096F :  INY
0970 :  BNE .uw_skip

.uw_got:
0972 :  JSR ROM_CHROUT ; $FFD2
0975 :  INY
0976 :  LDA uword2dec_decbuf,Y ; $08AC
0979 :  BNE .uw_got

.uw_trail:
097B :  LDA #0x1D ; $1D
097D :  JSR ROM_CHROUT ; $FFD2
0980 :  RTS

.uw_allzero_l:
0981 :  LDA #0x30 ; $30
0983 :  JSR ROM_CHROUT ; $FFD2
0986 :  JMP .uw_trail ; $097B

RT_fmul_align:

RT_fadd:
0B06 :  JSR $BA8C
0B09 :  LDA $61
0B0B :  JMP RT_fmul_align ; $0989

RT_fsub:
0B0E :  JSR $BA8C
0B11 :  LDA $66
0B13 :  EOR #$FF
0B15 :  STA $66
0B17 :  EOR $6E
0B19 :  STA $6F
0B1B :  LDA $61
0B1D :  JMP RT_fmul_align ; $0989

RT_rnd_fast:
0B20 :  LDA FACEXP ; $61
0B22 :  BNE +3 ; FACEXP!=0 -> skip (long BEQ .seed_ti)
0B24 :  JMP .seed_ti

0B27 :  LDA 0x66 ; $66
0B29 :  BPL +3 ; arg>0 -> skip (long BMI .seed_arg)
0B2B :  JMP .seed_arg

.do_advance:
0B2E :  LDA rnd_st + 1 ; $0838
0B31 :  BNE .adv_lfsr
0B33 :  LDA rnd_st ; $0837
0B36 :  BNE .adv_lfsr
0B38 :  LDA 0xA1 ; $A1
0B3A :  STA rnd_st ; $0837
0B3D :  LDA 0xA2 ; $A2
0B3F :  STA rnd_st + 1 ; $0838
0B42 :  BNE .adv_lfsr
0B44 :  LDA rnd_st ; $0837
0B47 :  BNE .adv_lfsr
0B49 :  LDA #0xE1 ; $E1
0B4B :  STA rnd_st ; $0837
0B4E :  LDA #0xAC ; $AC
0B50 :  STA rnd_st + 1 ; $0838

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:
0B53 :  LDA rnd_st + 1 ; $0838
0B56 :  AND #1 ; $01
0B58 :  ASL
0B59 :  ASL
0B5A :  ASL
0B5B :  ASL
0B5C :  ASL
0B5D :  ASL
0B5E :  ASL
0B5F :  EOR rnd_st + 1 ; $0838
0B62 :  STA rnd_st + 1 ; $0838
0B65 :  LDA rnd_st ; $0837
0B68 :  LSR
0B69 :  EOR rnd_st + 1 ; $0838
0B6C :  STA rnd_st + 1 ; $0838
0B6F :  LDA rnd_st ; $0837
0B72 :  AND #1 ; $01
0B74 :  ASL
0B75 :  ASL
0B76 :  ASL
0B77 :  ASL
0B78 :  ASL
0B79 :  ASL
0B7A :  ASL
0B7B :  EOR rnd_st ; $0837
0B7E :  STA rnd_st ; $0837
0B81 :  LDA rnd_st + 1 ; $0838
0B84 :  LSR
0B85 :  EOR rnd_st ; $0837
0B88 :  STA rnd_st ; $0837
0B8B :  LDA rnd_st + 1 ; $0838
0B8E :  EOR rnd_st ; $0837
0B91 :  STA rnd_st + 1 ; $0838
0B94 :  BNE .rf_build
0B96 :  LDA rnd_st ; $0837
0B99 :  BEQ .to_zero

.rf_build:

.rf_build:
0B9B :  LDA rnd_st + 1 ; $0838
0B9E :  STA 0x62 ; $62
0BA0 :  LDA rnd_st ; $0837
0BA3 :  STA 0x63 ; $63
0BA5 :  LDA #0 ; $00
0BA7 :  STA 0x64 ; $64
0BA9 :  STA 0x65 ; $65
0BAB :  STA 0x66 ; $66
0BAD :  LDA #128 ; $80
0BAF :  STA FACEXP ; $61

.cvt_loop:
0BB1 :  LDA 0x62 ; $62
0BB3 :  BMI .cvt_done
0BB5 :  ASL 0x65 ; $65
0BB7 :  ROL 0x64 ; $64
0BB9 :  ROL 0x63 ; $63
0BBB :  ROL 0x62 ; $62
0BBD :  DEC FACEXP ; $61
0BBF :  JMP .cvt_loop ; $0BB1

.cvt_done:

.cvt_done:
0BC2 :  RTS

.seed_ti:

.seed_ti:
0BC3 :  LDA 0xA1 ; $A1
0BC5 :  STA rnd_st ; $0837
0BC8 :  LDA 0xA2 ; $A2
0BCA :  STA rnd_st + 1 ; $0838
0BCD :  JMP .do_advance ; $0B2E

.seed_arg:

.seed_arg:
0BD0 :  LDA 0x63 ; $63
0BD2 :  STA rnd_st ; $0837
0BD5 :  LDA 0x64 ; $64
0BD7 :  STA rnd_st + 1 ; $0838
0BDA :  JMP .do_advance ; $0B2E

.to_zero:

.to_zero:
0BDD :  LDA #0 ; $00
0BDF :  STA FACEXP ; $61
0BE1 :  STA 0x62 ; $62
0BE3 :  STA 0x63 ; $63
0BE5 :  STA 0x64 ; $64
0BE7 :  STA 0x65 ; $65
0BE9 :  STA 0x66 ; $66
0BEB :  RTS

RT_ti_read:
0BEC :  LDA #0 ; $00
0BEE :  LDY 0xA0 ; $A0
0BF0 :  JSR ROM_INT_FAC ; $B391
0BF3 :  LDA FACEXP ; $61
0BF5 :  BEQ .ti_r_s1
0BF7 :  CLC
0BF8 :  ADC #16 ; $10
0BFA :  STA FACEXP ; $61

.ti_r_s1:

.ti_r_s1:
0BFC :  LDX #<addr ; $32
0BFE :  LDY #>addr ; $08
0C00 :  JSR ROM_FAC_MEM ; $BBD4
0C03 :  LDA #0 ; $00
0C05 :  LDY 0xA1 ; $A1
0C07 :  JSR ROM_INT_FAC ; $B391
0C0A :  LDA FACEXP ; $61
0C0C :  BEQ .ti_r_s2
0C0E :  CLC
0C0F :  ADC #8 ; $08
0C11 :  STA FACEXP ; $61

.ti_r_s2:

.ti_r_s2:
0C13 :  LDA #<addr ; $32
0C15 :  LDY #>addr ; $08
0C17 :  JSR ROM_MEM_ARG ; $BA8C
0C1A :  LDA FACEXP ; $61
0C1C :  JSR ROM_PLUS ; $B86A
0C1F :  LDX #<addr ; $32
0C21 :  LDY #>addr ; $08
0C23 :  JSR ROM_FAC_MEM ; $BBD4
0C26 :  LDA #0 ; $00
0C28 :  LDY 0xA2 ; $A2
0C2A :  JSR ROM_INT_FAC ; $B391
0C2D :  LDA #<addr ; $32
0C2F :  LDY #>addr ; $08
0C31 :  JSR ROM_MEM_ARG ; $BA8C
0C34 :  LDA FACEXP ; $61
0C36 :  JSR ROM_PLUS ; $B86A
0C39 :  RTS

; ---- BASIC source ----
; 10    $0C3A  PRINT CHR$(147)
; 1,"life.bas"

L10:
0C3A :  LDA #LO(e->ival) ; $93
0C3C :  LDX #LO((e->ival >> 8)) ; $00
0C3E :  JSR ROM_CHROUT ; $FFD2
0C41 :  LDA #13 ; $0D
0C43 :  JSR ROM_CHROUT ; $FFD2
; 20    $0C46  W=20
; 3,"life.bas"

L20:
0C46 :  LDA #clo ; $14
0C48 :  STA W
; 30    $0C4B  G=100
; 4,"life.bas"

L30:
0C4B :  LDA #clo ; $64
0C4D :  STA G
; 40    $0C50  L=1113
; 5,"life.bas"

L40:
0C50 :  LDA #LO(e->ival) ; $59
0C52 :  LDX #LO((e->ival >> 8)) ; $04
0C54 :  STA L
0C57 :  STX L+1
; 50    $0C5A  N=24576
; 6,"life.bas"

L50:
0C5A :  LDA #LO(e->ival) ; $00
0C5C :  LDX #LO((e->ival >> 8)) ; $60
0C5E :  STA N
0C61 :  STX N+1
; 60    $0C64  D=23463
; 7,"life.bas"

L60:
0C64 :  LDA #LO(e->ival) ; $A7
0C66 :  LDX #LO((e->ival >> 8)) ; $5B
0C68 :  STA D
0C6B :  STX D+1
; 70    $0C6E  FOR R=0 TO 21
; 9,"life.bas"

L70:
0C6E :  LDA #LO(e->ival) ; $00
0C70 :  LDX #LO((e->ival >> 8)) ; $00
0C72 :  STA R
0C75 :  STX R+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
; 80    $0C78  FOR C=0 TO 21
; 10,"life.bas"

L80:
0C78 :  LDA #LO(e->ival) ; $00
0C7A :  LDX #LO((e->ival >> 8)) ; $00
0C7C :  STA C
0C7F :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
0C82 :  LDA L
0C85 :  LDX L+1
0C88 :  STA slot+0
0C8A :  STX slot+1
0C8C :  LDA R
0C8F :  LDX #0 ; $00
0C91 :  TAY
0C92 :  LDA h_mulK_hi[K],Y ; $084F
0C95 :  TAX
0C96 :  LDA h_mulK_lo[K],Y ; $0839
0C99 :  CLC
0C9A :  ADC slot+0
0C9C :  PHA
0C9D :  TXA
0C9E :  ADC slot+1
0CA0 :  TAX
0CA1 :  PLA
0CA2 :  STA LICM0
0CA5 :  STX LICM0+1
0CA8 :  LDA N
0CAB :  LDX N+1
0CAE :  STA slot+0
0CB0 :  STX slot+1
0CB2 :  LDA R
0CB5 :  LDX #0 ; $00
0CB7 :  TAY
0CB8 :  LDA h_mulK_hi[K],Y ; $084F
0CBB :  TAX
0CBC :  LDA h_mulK_lo[K],Y ; $0839
0CBF :  CLC
0CC0 :  ADC slot+0
0CC2 :  PHA
0CC3 :  TXA
0CC4 :  ADC slot+1
0CC6 :  TAX
0CC7 :  PLA
0CC8 :  STA LICM1
0CCB :  STX LICM1+1
0CCE :  LDA LICM0
0CD1 :  LDX LICM0+1
0CD4 :  STA slot+0
0CD6 :  STX slot+1
0CD8 :  LDA C
0CDB :  LDX C+1
0CDE :  CLC
0CDF :  ADC slot+0
0CE1 :  PHA
0CE2 :  TXA
0CE3 :  ADC slot+1
0CE5 :  TAX
0CE6 :  PLA
0CE7 :  STA LOPT0
0CEA :  STX LOPT0+1
0CED :  LDA LICM1
0CF0 :  LDX LICM1+1
0CF3 :  STA slot+0
0CF5 :  STX slot+1
0CF7 :  LDA C
0CFA :  LDX C+1
0CFD :  CLC
0CFE :  ADC slot+0
0D00 :  PHA
0D01 :  TXA
0D02 :  ADC slot+1
0D04 :  TAX
0D05 :  PLA
0D06 :  STA LOPT1
0D09 :  STX LOPT1+1
; opt: licm-subexpr range-byte-loop

.for_body:
; 90    $0D0C  POKE L+R*40+C,32
; 11,"life.bas"

L90:
0D0C :  LDA LOPT0
0D0F :  LDX LOPT0+1
0D12 :  STA ZP_PTR ; $FB
0D14 :  STX ZP_PTR + 1 ; $FC
0D16 :  LDA #(u8)s->e2->ival ; $20
0D18 :  LDY #0 ; $00
0D1A :  STA (ZP_PTR),Y ; $FB
; 100   $0D1C  POKE N+R*40+C,32
; 12,"life.bas"

L100:
0D1C :  LDA LOPT1
0D1F :  LDX LOPT1+1
0D22 :  STA ZP_PTR ; $FB
0D24 :  STX ZP_PTR + 1 ; $FC
0D26 :  LDA #(u8)s->e2->ival ; $20
0D28 :  LDY #0 ; $00
0D2A :  STA (ZP_PTR),Y ; $FB
; 110   $0D2C  NEXT C
; 13,"life.bas"

L110:
0D2C :  LDA LOPT0
0D2F :  CLC
0D30 :  ADC #(u8)(st & 0xFF) ; $01
0D32 :  STA LOPT0
0D35 :  LDA LOPT0+1
0D38 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0D3A :  STA LOPT0+1
0D3D :  LDA LOPT1
0D40 :  CLC
0D41 :  ADC #(u8)(st & 0xFF) ; $01
0D43 :  STA LOPT1
0D46 :  LDA LOPT1+1
0D49 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0D4B :  STA LOPT1+1
0D4E :  INC C
0D51 :  LDA C
0D54 :  CMP #L->lim_lo ; $15
0D56 :  BEQ .nxt_back
0D58 :  BCS .nxt_done

.nxt_back:
0D5A :  JMP .for_body ; $0D0C

.nxt_done:
; 120   $0D5D  NEXT R
; 14,"life.bas"

L120:
0D5D :  INC R
0D60 :  LDA R
0D63 :  CMP #L->lim_lo ; $15
0D65 :  BEQ .nxt_back
0D67 :  BCS .nxt_done

.nxt_back:
0D69 :  JMP .for_body ; $0C78

.nxt_done:
; 130   $0D6C  Z=RND(-246)
; 15,"life.bas"

L130:
0D6C :  LDA #LO(e->ival) ; $0A
0D6E :  LDX #LO((e->ival >> 8)) ; $FF
0D70 :  TAY
0D71 :  TXA
0D72 :  JSR ROM_INT_FAC ; $B391
0D75 :  JSR RT_rnd_fast ; $0B20
0D78 :  LDX #<Z_F
0D7A :  LDY #>Z_F+1
0D7C :  JSR ROM_FAC_MEM ; $BBD4
; 140   $0D7F  FOR R=1 TO W
; 16,"life.bas"

L140:
0D7F :  LDA #LO(e->ival) ; $01
0D81 :  LDX #LO((e->ival >> 8)) ; $00
0D83 :  STA R
0D86 :  STX R+1
0D89 :  LDA W
0D8C :  STA LIMIT3
0D8F :  STX LIMIT3+1

.for_body:
; 150   $0D92  FOR C=1 TO W
; 17,"life.bas"

L150:
0D92 :  LDA #LO(e->ival) ; $01
0D94 :  LDX #LO((e->ival >> 8)) ; $00
0D96 :  STA C
0D99 :  STX C+1
0D9C :  LDA W
0D9F :  STA LIMIT4
0DA2 :  STX LIMIT4+1
0DA5 :  LDA L
0DA8 :  LDX L+1
0DAB :  STA slot+0
0DAD :  STX slot+1
0DAF :  LDA R
0DB2 :  LDX #0 ; $00
0DB4 :  TAY
0DB5 :  LDA h_mulK_hi[K],Y ; $084F
0DB8 :  TAX
0DB9 :  LDA h_mulK_lo[K],Y ; $0839
0DBC :  CLC
0DBD :  ADC slot+0
0DBF :  PHA
0DC0 :  TXA
0DC1 :  ADC slot+1
0DC3 :  TAX
0DC4 :  PLA
0DC5 :  STA LICM2
0DC8 :  STX LICM2+1
0DCB :  STA slot+0
0DCD :  STX slot+1
0DCF :  LDA C
0DD2 :  LDX C+1
0DD5 :  CLC
0DD6 :  ADC slot+0
0DD8 :  PHA
0DD9 :  TXA
0DDA :  ADC slot+1
0DDC :  TAX
0DDD :  PLA
0DDE :  STA LOPT2
0DE1 :  STX LOPT2+1
; opt: licm-subexpr

.for_body:
; 160   $0DE4  IF RND(1)<0.3 THEN POKE L+R*40+C,81
; 18,"life.bas"

L160:
0DE4 :  LDA #LO(e->ival) ; $01
0DE6 :  LDX #LO((e->ival >> 8)) ; $00
0DE8 :  TAY
0DE9 :  TXA
0DEA :  JSR ROM_INT_FAC ; $B391
0DED :  JSR RT_rnd_fast ; $0B20
0DF0 :  LDA #<addr ; $23
0DF2 :  LDY #>addr ; $08
0DF4 :  JSR ROM_FCOMP ; $BC5B
0DF7 :  BMI .true
0DF9 :  LDA #0x00 ; $00
0DFB :  BEQ .cmp_tail
0DFD :  LDA #0xFF ; $FF

.cmp_tail:
; opt: booltax (TAX elided, consumer tests Z)
; opt: cmp-bool truth-test (STX+ORA hi elided)
0DFF :  BNE +3 ; long IF-skip (body >127B)
0E01 :  JMP .if_skip

0E04 :  LDA LOPT2
0E07 :  LDX LOPT2+1
0E0A :  STA ZP_PTR ; $FB
0E0C :  STX ZP_PTR + 1 ; $FC
0E0E :  LDA #(u8)s->e2->ival ; $51
0E10 :  LDY #0 ; $00
0E12 :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 170   $0E14  NEXT C
; 19,"life.bas"

L170:
0E14 :  LDA LOPT2
0E17 :  CLC
0E18 :  ADC #(u8)(st & 0xFF) ; $01
0E1A :  STA LOPT2
0E1D :  LDA LOPT2+1
0E20 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0E22 :  STA LOPT2+1
0E25 :  INC C
0E28 :  BNE .inc_skip
0E2A :  INC C+1

.inc_skip:
0E2D :  LDA C+1
0E30 :  CMP LIMIT4+1
0E33 :  BCC .nxt_back
0E35 :  BNE .nxt_done
0E37 :  LDA C
0E3A :  CMP LIMIT4
0E3D :  BCC .nxt_back
0E3F :  BNE .nxt_done
0E41 :  BEQ .nxt_back

.nxt_back:
0E43 :  JMP .for_body ; $0DE4

.nxt_done:
; 180   $0E46  NEXT R
; 20,"life.bas"

L180:
0E46 :  INC R
0E49 :  BNE .inc_skip
0E4B :  INC R+1

.inc_skip:
0E4E :  LDA R+1
0E51 :  CMP LIMIT3+1
0E54 :  BCC .nxt_back
0E56 :  BNE .nxt_done
0E58 :  LDA R
0E5B :  CMP LIMIT3
0E5E :  BCC .nxt_back
0E60 :  BNE .nxt_done
0E62 :  BEQ .nxt_back

.nxt_back:
0E64 :  JMP .for_body ; $0D92

.nxt_done:
; 190   $0E67  T%=TI
; 22,"life.bas"

L190:
0E67 :  JSR RT_ti_read ; $0BEC
0E6A :  JSR ROM_FAC_INT ; $BC9B
0E6D :  LDA FACMO3 ; $65
0E6F :  LDX FACMO2 ; $64
0E71 :  STA T
0E74 :  STX T+1
; 200   $0E77  FOR K=1 TO G
; 24,"life.bas"

L200:
0E77 :  LDA #LO(e->ival) ; $01
0E79 :  LDX #LO((e->ival >> 8)) ; $00
0E7B :  STA K
0E7E :  STX K+1
0E81 :  LDA G
0E84 :  STA LIMIT5
0E87 :  STX LIMIT5+1

.for_body:
; 210   $0E8A  FOR X=1 TO W
; 25,"life.bas"

L210:
0E8A :  LDA #LO(e->ival) ; $01
0E8C :  LDX #LO((e->ival >> 8)) ; $00
0E8E :  STA X
0E91 :  STX X+1
0E94 :  LDA W
0E97 :  STA LIMIT6
0E9A :  STX LIMIT6+1

.for_body:
; 220   $0E9D  BB=L+X*40+1
; 26,"life.bas"

L220:
0E9D :  LDA L
0EA0 :  LDX L+1
0EA3 :  STA slot+0
0EA5 :  STX slot+1
0EA7 :  LDA X
0EAA :  LDX #0 ; $00
0EAC :  TAY
0EAD :  LDA h_mulK_hi[K],Y ; $084F
0EB0 :  TAX
0EB1 :  LDA h_mulK_lo[K],Y ; $0839
0EB4 :  CLC
0EB5 :  ADC slot+0
0EB7 :  PHA
0EB8 :  TXA
0EB9 :  ADC slot+1
0EBB :  TAX
0EBC :  PLA
0EBD :  STA slot+0
0EBF :  STX slot+1
0EC1 :  LDA #LO(e->ival) ; $01
0EC3 :  LDX #LO((e->ival >> 8)) ; $00
0EC5 :  CLC
0EC6 :  ADC slot+0
0EC8 :  PHA
0EC9 :  TXA
0ECA :  ADC slot+1
0ECC :  TAX
0ECD :  PLA
0ECE :  STA BB
0ED1 :  STX BB+1
; 230   $0ED4  FOR Y=1 TO W
; 27,"life.bas"

L230:
0ED4 :  LDA #LO(e->ival) ; $01
0ED6 :  LDX #LO((e->ival >> 8)) ; $00
0ED8 :  STA Y
0EDB :  STX Y+1
0EDE :  LDA W
0EE1 :  STA LIMIT7
0EE4 :  STX LIMIT7+1
0EE7 :  LDA BB
0EEA :  LDX BB+1
0EED :  STA slot+0
0EEF :  STX slot+1
0EF1 :  LDA D
0EF4 :  LDX D+1
0EF7 :  CLC
0EF8 :  ADC slot+0
0EFA :  PHA
0EFB :  TXA
0EFC :  ADC slot+1
0EFE :  TAX
0EFF :  PLA
0F00 :  STA NB
0F03 :  STX NB+1
; opt: user-iv-let peek-cluster-reuse

.for_body:
; 240   $0F06  C=PEEK(BB-41)+PEEK(BB-40)+PEEK(BB-39)+PEEK(BB-1)+PEEK(BB+1)+PEEK(BB+39)+PEEK(BB+40)+PEEK(BB+41)
; 28,"life.bas"

L240:
0F06 :  LDA BB
0F09 :  STA ZP_PTR ; $FB
0F0B :  LDA BB+1
0F0E :  STA ZP_PTR + 1 ; $FC
0F10 :  LDA ZP_PTR ; $FB
0F12 :  SEC
0F13 :  SBC #(u8)(-min & 0xFF) ; $29
0F15 :  STA ZP_PTR ; $FB
0F17 :  LDA ZP_PTR + 1 ; $FC
0F19 :  SBC #(u8)(((-min) >> 8) & 0xFF) ; $00
0F1B :  STA ZP_PTR + 1 ; $FC
; opt: peek-cluster
0F1D :  LDY #(u8)(off - g_peek_cluster_min) ; $00
0F1F :  LDA (ZP_PTR),Y ; $FB
0F21 :  STA slot+0
0F23 :  LDX #0 ; $00
0F25 :  LDY #(u8)(off - g_peek_cluster_min) ; $01
0F27 :  LDA (ZP_PTR),Y ; $FB
0F29 :  CLC
0F2A :  ADC slot+0
0F2C :  STA slot+0
0F2E :  TXA
0F2F :  ADC #0 ; $00
0F31 :  TAX
0F32 :  LDY #(u8)(off - g_peek_cluster_min) ; $02
0F34 :  LDA (ZP_PTR),Y ; $FB
0F36 :  CLC
0F37 :  ADC slot+0
0F39 :  STA slot+0
0F3B :  TXA
0F3C :  ADC #0 ; $00
0F3E :  TAX
0F3F :  LDY #(u8)(off - g_peek_cluster_min) ; $28
0F41 :  LDA (ZP_PTR),Y ; $FB
0F43 :  CLC
0F44 :  ADC slot+0
0F46 :  STA slot+0
0F48 :  TXA
0F49 :  ADC #0 ; $00
0F4B :  TAX
0F4C :  LDY #(u8)(off - g_peek_cluster_min) ; $2A
0F4E :  LDA (ZP_PTR),Y ; $FB
0F50 :  CLC
0F51 :  ADC slot+0
0F53 :  STA slot+0
0F55 :  TXA
0F56 :  ADC #0 ; $00
0F58 :  TAX
0F59 :  LDY #(u8)(off - g_peek_cluster_min) ; $50
0F5B :  LDA (ZP_PTR),Y ; $FB
0F5D :  CLC
0F5E :  ADC slot+0
0F60 :  STA slot+0
0F62 :  TXA
0F63 :  ADC #0 ; $00
0F65 :  TAX
0F66 :  LDY #(u8)(off - g_peek_cluster_min) ; $51
0F68 :  LDA (ZP_PTR),Y ; $FB
0F6A :  CLC
0F6B :  ADC slot+0
0F6D :  STA slot+0
0F6F :  TXA
0F70 :  ADC #0 ; $00
0F72 :  TAX
0F73 :  LDY #(u8)(off - g_peek_cluster_min) ; $52
0F75 :  LDA (ZP_PTR),Y ; $FB
0F77 :  CLC
0F78 :  ADC slot+0
0F7A :  STA slot+0
0F7C :  TXA
0F7D :  ADC #0 ; $00
0F7F :  TAX
0F80 :  LDA slot+0
0F82 :  STA C
0F85 :  STX C+1
; 250   $0F88  P=PEEK(BB)
; 29,"life.bas"

L250:
0F88 :  LDY #(u8)e->peek_reuse_y ; $29
0F8A :  LDA (ZP_PTR),Y ; $FB
0F8C :  STA P
; 260   $0F8F  NB=BB+D
; 30,"life.bas"

L260:
; 270   $0F8F  POKE NB,32
; 31,"life.bas"

L270:
0F8F :  LDA NB
0F92 :  LDX NB+1
0F95 :  STA ZP_PTR ; $FB
0F97 :  STX ZP_PTR + 1 ; $FC
0F99 :  LDA #(u8)s->e2->ival ; $20
0F9B :  LDY #0 ; $00
0F9D :  STA (ZP_PTR),Y ; $FB
; 280   $0F9F  IF C=403 OR (P=81 AND C=354) THEN POKE NB,81
; 32,"life.bas"

L280:
; opt: mixed AND/OR-of-cmp short-circuit
0F9F :  LDA C
0FA2 :  LDX C+1
0FA5 :  STA slot+0
0FA7 :  STX slot+1
0FA9 :  LDA #LO(e->ival) ; $93
0FAB :  LDX #LO((e->ival >> 8)) ; $01
0FAD :  STA ZP_SCR16 ; $FD
0FAF :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-nonneg (EOR #$80 elided)
0FB1 :  LDA slot+1
0FB3 :  CMP ZP_SCR16 + 1 ; $FE
0FB5 :  BNE .cmp_done
0FB7 :  LDA slot+0
0FB9 :  CMP ZP_SCR16 ; $FD

.cmp_done:
0FBB :  BEQ .true
0FBD :  LDA #0x00 ; $00
0FBF :  BEQ .cmp_tail
0FC1 :  LDA #0xFF ; $FF

.cmp_tail:
0FC3 :  TAX
0FC4 :  BEQ +3 ; long branch
0FC6 :  JMP .sc_t

0FC9 :  JMP .sc_f

.sc_mid:
0FCC :  LDA P
0FCF :  LDX #0 ; $00
0FD1 :  STA slot+0
0FD3 :  STX slot+1
0FD5 :  LDA #LO(e->ival) ; $51
0FD7 :  STA ZP_SCR16 ; $FD
0FD9 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-hielide (hi bytes known equal; lo-only compare, EOR elided)
0FDB :  LDA slot+0
0FDD :  CMP ZP_SCR16 ; $FD
0FDF :  BEQ .true
0FE1 :  LDA #0x00 ; $00
0FE3 :  BEQ .cmp_tail
0FE5 :  LDA #0xFF ; $FF

.cmp_tail:
0FE7 :  TAX
0FE8 :  BEQ +3 ; long branch
0FEA :  JMP .sc_t

0FED :  JMP .sc_f

.sc_mid:
0FF0 :  LDA C
0FF3 :  LDX C+1
0FF6 :  STA slot+0
0FF8 :  STX slot+1
0FFA :  LDA #LO(e->ival) ; $62
0FFC :  LDX #LO((e->ival >> 8)) ; $01
0FFE :  STA ZP_SCR16 ; $FD
1000 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-nonneg (EOR #$80 elided)
1002 :  LDA slot+1
1004 :  CMP ZP_SCR16 + 1 ; $FE
1006 :  BNE .cmp_done
1008 :  LDA slot+0
100A :  CMP ZP_SCR16 ; $FD

.cmp_done:
100C :  BEQ .true
100E :  LDA #0x00 ; $00
1010 :  BEQ .cmp_tail
1012 :  LDA #0xFF ; $FF

.cmp_tail:
1014 :  TAX
1015 :  BEQ +3 ; long branch
1017 :  JMP .sc_t

101A :  JMP .sc_f

.if_true:
101D :  LDA NB
1020 :  LDX NB+1
1023 :  STA ZP_PTR ; $FB
1025 :  STX ZP_PTR + 1 ; $FC
1027 :  LDA #(u8)s->e2->ival ; $51
1029 :  LDY #0 ; $00
102B :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 290   $102D  BB=BB+1
; 33,"life.bas"

L290:
102D :  INC BB
1030 :  BNE .pm1_skip
1032 :  INC BB+1

.pm1_skip:
; 300   $1035  NEXT Y
; 34,"life.bas"

L300:
1035 :  LDA NB
1038 :  CLC
1039 :  ADC #(u8)(st & 0xFF) ; $01
103B :  STA NB
103E :  LDA NB+1
1041 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
1043 :  STA NB+1
1046 :  INC Y
1049 :  BNE .inc_skip
104B :  INC Y+1

.inc_skip:
104E :  LDA Y+1
1051 :  CMP LIMIT7+1
1054 :  BCC .nxt_back
1056 :  BNE .nxt_done
1058 :  LDA Y
105B :  CMP LIMIT7
105E :  BCC .nxt_back
1060 :  BNE .nxt_done
1062 :  BEQ .nxt_back

.nxt_back:
1064 :  JMP .for_body ; $0F06

.nxt_done:
; 310   $1067  NEXT X
; 35,"life.bas"

L310:
1067 :  INC X
106A :  BNE .inc_skip
106C :  INC X+1

.inc_skip:
106F :  LDA X+1
1072 :  CMP LIMIT6+1
1075 :  BCC .nxt_back
1077 :  BNE .nxt_done
1079 :  LDA X
107C :  CMP LIMIT6
107F :  BCC .nxt_back
1081 :  BNE .nxt_done
1083 :  BEQ .nxt_back

.nxt_back:
1085 :  JMP .for_body ; $0E9D

.nxt_done:
; 320   $1088  FOR R=1 TO W
; 36,"life.bas"

L320:
1088 :  LDA #LO(e->ival) ; $01
108A :  LDX #LO((e->ival >> 8)) ; $00
108C :  STA R
108F :  STX R+1
1092 :  LDA W
1095 :  STA LIMIT8
1098 :  STX LIMIT8+1

.for_body:
; 330   $109B  FOR C=1 TO W
; 37,"life.bas"

L330:
; opt: licm-subexpr memmove-2base
109B :  LDA L
109E :  LDX L+1
10A1 :  STA slot+0
10A3 :  STX slot+1
10A5 :  LDA R
10A8 :  LDX #0 ; $00
10AA :  TAY
10AB :  LDA h_mulK_hi[K],Y ; $084F
10AE :  TAX
10AF :  LDA h_mulK_lo[K],Y ; $0839
10B2 :  CLC
10B3 :  ADC slot+0
10B5 :  PHA
10B6 :  TXA
10B7 :  ADC slot+1
10B9 :  TAX
10BA :  PLA
10BB :  STA LICM3
10BE :  STX LICM3+1
10C1 :  LDA N
10C4 :  LDX N+1
10C7 :  STA slot+0
10C9 :  STX slot+1
10CB :  LDA R
10CE :  LDX #0 ; $00
10D0 :  TAY
10D1 :  LDA h_mulK_hi[K],Y ; $084F
10D4 :  TAX
10D5 :  LDA h_mulK_lo[K],Y ; $0839
10D8 :  CLC
10D9 :  ADC slot+0
10DB :  PHA
10DC :  TXA
10DD :  ADC slot+1
10DF :  TAX
10E0 :  PLA
10E1 :  STA LICM4
10E4 :  STX LICM4+1
; #6 inc-3v: runtime count = limit - start + 1 (forward)
10E7 :  LDA W
10EA :  LDX #0 ; $00
10EC :  STA VLMT9
10EF :  STX VLMT9+1
10F2 :  SEC
10F3 :  SBC #(u8)(vc_start & 0xFF) ; $01
10F5 :  PHA
10F6 :  TXA
10F7 :  SBC #(u8)((vc_start >> 8) & 0xFF) ; $00
10F9 :  TAX
10FA :  PLA
10FB :  CLC
10FC :  ADC #1 ; $01
10FE :  PHA
10FF :  TXA
1100 :  ADC #0 ; $00
1102 :  TAX
1103 :  PLA
1104 :  STA VCNT9
1107 :  STX VCNT9+1
110A :  LDA VCNT9+1
110D :  BMI .vc_set1
110F :  BNE .vc_keep
1111 :  LDA VCNT9
1114 :  BNE .vc_keep

.vc_set1:
1116 :  LDA #1 ; $01
1118 :  STA VCNT9
111B :  LDA #0 ; $00
111D :  STA VCNT9+1

.vc_keep:
1120 :  LDA VLMT9
1123 :  CLC
1124 :  ADC #1 ; $01
1126 :  STA C
1129 :  LDA VLMT9+1
112C :  ADC #0 ; $00
112E :  STA C+1
1131 :  LDA LICM3
1134 :  STA zplo ; $FB
1136 :  LDA LICM3+1
1139 :  STA zplo + 1 ; $FC
113B :  CLC
113C :  LDA zplo ; $FB
113E :  ADC #(u8)(off & 0xFF) ; $01
1140 :  STA zplo ; $FB
1142 :  LDA zplo + 1 ; $FC
1144 :  ADC #(u8)((off >> 8) & 0xFF) ; $00
1146 :  STA zplo + 1 ; $FC
1148 :  LDA LICM4
114B :  STA zplo ; $FE
114D :  LDA LICM4+1
1150 :  STA zplo + 1 ; $FF
1152 :  CLC
1153 :  LDA zplo ; $FE
1155 :  ADC #(u8)(off & 0xFF) ; $01
1157 :  STA zplo ; $FE
1159 :  LDA zplo + 1 ; $FF
115B :  ADC #(u8)((off >> 8) & 0xFF) ; $00
115D :  STA zplo + 1 ; $FF
115F :  LDA VCNT9+1
1162 :  BEQ .vcrem
1164 :  TAX

.vcblk:
1165 :  LDY #0 ; $00

.vcinn:
1167 :  LDA (ZP_SRC),Y ; $FE
1169 :  STA (ZP_PTR),Y ; $FB
116B :  INY
116C :  BNE .vcinn
116E :  INC ZP_PTR + 1 ; $FC
1170 :  INC ZP_SRC + 1 ; $FF
1172 :  DEX
1173 :  BNE .vcblk

.vcrem:
1175 :  LDY #0 ; $00
1177 :  LDA VCNT9
117A :  BEQ .vcdone
117C :  TAX

.vcrlp:
117D :  LDA (ZP_SRC),Y ; $FE
117F :  STA (ZP_PTR),Y ; $FB
1181 :  INY
1182 :  DEX
1183 :  BNE .vcrlp

.vcdone:
; 340   $1185  POKE L+R*40+C,PEEK(N+R*40+C)
; 38,"life.bas"

L340:
; 350   $1185  NEXT C
; 39,"life.bas"

L350:
; 360   $1185  NEXT R
; 40,"life.bas"

L360:
1185 :  INC R
1188 :  BNE .inc_skip
118A :  INC R+1

.inc_skip:
118D :  LDA R+1
1190 :  CMP LIMIT8+1
1193 :  BCC .nxt_back
1195 :  BNE .nxt_done
1197 :  LDA R
119A :  CMP LIMIT8
119D :  BCC .nxt_back
119F :  BNE .nxt_done
11A1 :  BEQ .nxt_back

.nxt_back:
11A3 :  JMP .for_body ; $109B

.nxt_done:
; 370   $11A6  POKE 1024,32
; 41,"life.bas"

L370:
11A6 :  LDA #(u8)s->e2->ival ; $20
11A8 :  STA ; $0400
; 380   $11AB  NEXT K
; 42,"life.bas"

L380:
11AB :  INC K
11AE :  BNE .inc_skip
11B0 :  INC K+1

.inc_skip:
11B3 :  LDA K+1
11B6 :  CMP LIMIT5+1
11B9 :  BCC .nxt_back
11BB :  BNE .nxt_done
11BD :  LDA K
11C0 :  CMP LIMIT5
11C3 :  BCC .nxt_back
11C5 :  BNE .nxt_done
11C7 :  BEQ .nxt_back

.nxt_back:
11C9 :  JMP .for_body ; $0E8A

.nxt_done:
; 390   $11CC  PRINT CHR$(19);"TIME=";TI-T%
; 44,"life.bas"

L390:
11CC :  LDA #LO(e->ival) ; $13
11CE :  LDX #LO((e->ival >> 8)) ; $00
11D0 :  JSR ROM_CHROUT ; $FFD2
11D3 :  LDA #<addr ; $13
11D5 :  STA ZP_PTR ; $FB
11D7 :  LDA #>addr ; $08
11D9 :  STA ZP_PTR + 1 ; $FC
11DB :  LDA #(u8)str_lits[idx].bytes.size() ; $05
11DD :  JSR RT_print_str ; $0865
11E0 :  JSR RT_ti_read ; $0BEC
11E3 :  LDX #<addr ; $2D
11E5 :  LDY #>addr ; $08
11E7 :  JSR ROM_FAC_MEM ; $BBD4
11EA :  LDA T
11ED :  LDX T+1
11F0 :  TAY
11F1 :  TXA
11F2 :  JSR ROM_INT_FAC ; $B391
11F5 :  LDA #<addr ; $2D
11F7 :  LDY #>addr ; $08
11F9 :  JSR ROM_MEM_ARG ; $BA8C
11FC :  LDA FACEXP ; $61
11FE :  LDA #<addr ; $2D
1200 :  LDY #>addr ; $08
1202 :  JSR ROM_MINUS ; $B850
1205 :  JSR ROM_FOUT ; $BDDD
1208 :  LDY #0 ; $00

.fpl:
120A :  LDA ZP_GETBUF,Y ; $0100
120D :  BEQ .fpr_done
120F :  JSR ROM_CHROUT ; $FFD2
1212 :  INY
1213 :  BNE .fpr

.fpr_done:
1215 :  LDA #0x1D ; $1D
1217 :  JSR ROM_CHROUT ; $FFD2
121A :  LDA #13 ; $0D
121C :  JSR ROM_CHROUT ; $FFD2
; 400   $121F  S=0
; 46,"life.bas"

L400:
121F :  LDA #clo ; $00
1221 :  STA S
1224 :  STA S+1
; 410   $1227  FOR R=1 TO W
; 47,"life.bas"

L410:
1227 :  LDA #LO(e->ival) ; $01
1229 :  LDX #LO((e->ival >> 8)) ; $00
122B :  STA R
122E :  STX R+1
1231 :  LDA W
1234 :  STA LIMIT10
1237 :  STX LIMIT10+1

.for_body:
; 420   $123A  FOR C=1 TO W
; 48,"life.bas"

L420:
123A :  LDA #LO(e->ival) ; $01
123C :  LDX #LO((e->ival >> 8)) ; $00
123E :  STA C
1241 :  STX C+1
1244 :  LDA W
1247 :  STA LIMIT11
124A :  STX LIMIT11+1
124D :  LDA L
1250 :  LDX L+1
1253 :  STA slot+0
1255 :  STX slot+1
1257 :  LDA R
125A :  LDX #0 ; $00
125C :  TAY
125D :  LDA h_mulK_hi[K],Y ; $084F
1260 :  TAX
1261 :  LDA h_mulK_lo[K],Y ; $0839
1264 :  CLC
1265 :  ADC slot+0
1267 :  PHA
1268 :  TXA
1269 :  ADC slot+1
126B :  TAX
126C :  PLA
126D :  STA LICM5
1270 :  STX LICM5+1
1273 :  STA slot+0
1275 :  STX slot+1
1277 :  LDA C
127A :  LDX C+1
127D :  CLC
127E :  ADC slot+0
1280 :  PHA
1281 :  TXA
1282 :  ADC slot+1
1284 :  TAX
1285 :  PLA
1286 :  STA LOPT3
1289 :  STX LOPT3+1
; opt: licm-subexpr

.for_body:
; 430   $128C  S=S-(PEEK(L+R*40+C)=81)
; 49,"life.bas"

L430:
128C :  LDA LOPT3
128F :  LDX LOPT3+1
1292 :  STA ZP_PTR ; $FB
1294 :  STX ZP_PTR + 1 ; $FC
1296 :  LDY #0 ; $00
1298 :  LDA (ZP_PTR),Y ; $FB
129A :  LDX #0 ; $00
129C :  STA slot+0
129E :  STX slot+1
12A0 :  LDA #LO(e->ival) ; $51
12A2 :  STA ZP_SCR16 ; $FD
12A4 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-hielide (hi bytes known equal; lo-only compare, EOR elided)
12A6 :  LDA slot+0
12A8 :  CMP ZP_SCR16 ; $FD
12AA :  BEQ .true
12AC :  LDA #0x00 ; $00
12AE :  BEQ .cmp_tail
12B0 :  LDA #0xFF ; $FF

.cmp_tail:
12B2 :  TAX
12B3 :  STA slot+0
12B5 :  STX slot+1
12B7 :  LDA S
12BA :  LDX #0 ; $00
12BC :  SEC
12BD :  SBC slot+0
12BF :  PHA
12C0 :  TXA
12C1 :  SBC slot+1
12C3 :  TAX
12C4 :  PLA
12C5 :  STA S
12C8 :  STX S+1
; 440   $12CB  NEXT C
; 50,"life.bas"

L440:
12CB :  LDA LOPT3
12CE :  CLC
12CF :  ADC #(u8)(st & 0xFF) ; $01
12D1 :  STA LOPT3
12D4 :  LDA LOPT3+1
12D7 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
12D9 :  STA LOPT3+1
12DC :  INC C
12DF :  BNE .inc_skip
12E1 :  INC C+1

.inc_skip:
12E4 :  LDA C+1
12E7 :  CMP LIMIT11+1
12EA :  BCC .nxt_back
12EC :  BNE .nxt_done
12EE :  LDA C
12F1 :  CMP LIMIT11
12F4 :  BCC .nxt_back
12F6 :  BNE .nxt_done
12F8 :  BEQ .nxt_back

.nxt_back:
12FA :  JMP .for_body ; $128C

.nxt_done:
; 450   $12FD  NEXT R
; 51,"life.bas"

L450:
12FD :  INC R
1300 :  BNE .inc_skip
1302 :  INC R+1

.inc_skip:
1305 :  LDA R+1
1308 :  CMP LIMIT10+1
130B :  BCC .nxt_back
130D :  BNE .nxt_done
130F :  LDA R
1312 :  CMP LIMIT10
1315 :  BCC .nxt_back
1317 :  BNE .nxt_done
1319 :  BEQ .nxt_back

.nxt_back:
131B :  JMP .for_body ; $123A

.nxt_done:
; 460   $131E  PRINT "GENS=";G
; 53,"life.bas"

L460:
131E :  LDA #<addr ; $18
1320 :  STA ZP_PTR ; $FB
1322 :  LDA #>addr ; $08
1324 :  STA ZP_PTR + 1 ; $FC
1326 :  LDA #(u8)str_lits[idx].bytes.size() ; $05
1328 :  JSR RT_print_str ; $0865
132B :  LDA G
132E :  LDX #0 ; $00
1330 :  JSR RT_print_int ; $0941
1333 :  LDA #13 ; $0D
1335 :  JSR ROM_CHROUT ; $FFD2
; 470   $1338  PRINT "ALIVE=";S
; 54,"life.bas"

L470:
1338 :  LDA #<addr ; $1D
133A :  STA ZP_PTR ; $FB
133C :  LDA #>addr ; $08
133E :  STA ZP_PTR + 1 ; $FC
1340 :  LDA #(u8)str_lits[idx].bytes.size() ; $06
1342 :  JSR RT_print_str ; $0865
1345 :  LDA S
1348 :  LDX S+1
134B :  JSR RT_print_int ; $0941
134E :  LDA #13 ; $0D
1350 :  JSR ROM_CHROUT ; $FFD2
; halt
1353 :  RTS

; ---- variables (zero-filled) ----
W = $1354
; W      $1354 (2 bytes)
G = $1356
; G      $1356 (2 bytes)
L = $1358
; L      $1358 (2 bytes)
N = $135A
; N      $135A (2 bytes)
D = $135C
; D      $135C (2 bytes)
R = $135E
; R      $135E (2 bytes)
C = $1360
; C      $1360 (2 bytes)
Z_F = $1362
; Z      $1362 (5 bytes)
T = $1367
; T      $1367 (2 bytes)
TI_F = $1369
; TI     $1369 (5 bytes)
K = $136E
; K      $136E (2 bytes)
X = $1370
; X      $1370 (2 bytes)
BB = $1372
; BB     $1372 (2 bytes)
Y = $1374
; Y      $1374 (2 bytes)
P = $1376
; P      $1376 (2 bytes)
NB = $1378
; NB     $1378 (2 bytes)
S = $137A
; S      $137A (2 bytes)
LICM0 = $137C
; LICM0  $137C (2 bytes)
LICM1 = $137E
; LICM1  $137E (2 bytes)
LICM2 = $1380
; LICM2  $1380 (2 bytes)
LICM3 = $1382
; LICM3  $1382 (2 bytes)
LICM4 = $1384
; LICM4  $1384 (2 bytes)
LICM5 = $1386
; LICM5  $1386 (2 bytes)
LOPT0 = $1388
; LOPT0  $1388 (2 bytes)
LOPT1 = $138A
; LOPT1  $138A (2 bytes)
LOPT2 = $138C
; LOPT2  $138C (2 bytes)
LOPT3 = $138E
; LOPT3  $138E (2 bytes)
LIMIT1 = $1390
; LIMIT1 $1390 (2 bytes)
LIMIT2 = $1392
; LIMIT2 $1392 (2 bytes)
LIMIT3 = $1394
; LIMIT3 $1394 (2 bytes)
LIMIT4 = $1396
; LIMIT4 $1396 (2 bytes)
LIMIT5 = $1398
; LIMIT5 $1398 (2 bytes)
LIMIT6 = $139A
; LIMIT6 $139A (2 bytes)
LIMIT7 = $139C
; LIMIT7 $139C (2 bytes)
LIMIT8 = $139E
; LIMIT8 $139E (2 bytes)
VCNT9 = $13A0
; VCNT9  $13A0 (2 bytes)
VLMT9 = $13A2
; VLMT9  $13A2 (2 bytes)
LIMIT10 = $13A4
; LIMIT10 $13A4 (2 bytes)
LIMIT11 = $13A6
; LIMIT11 $13A6 (2 bytes)
1354 :  .res 84	; variable area
