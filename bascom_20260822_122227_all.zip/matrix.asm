; -- matrix.bas
; C64 BASIC V2 -> 6502  |  3239 bytes PRG, 27 source lines
	* = $0801
	; entry  $0CB6   (10 SYS -> code)
	; vars   $1300 .. $14A8   (17 vars, 424 bytes)
; ---- entry stub (10 SYS <tgt>, single BASIC line) ----
0801 :  .byte $0B,$08,$0A,$00,$9E,$33,$32,$35,$34,$00,$00,$00,$00,$00,$00,$00,$00,$00	; BASIC line 10
; ---- float const pool ----

fconst0:
0813 :  .byte $90,$50,$20,$00,$00

fconst1:
0818 :  .byte $90,$50,$21,$00,$00

fconst2:
081D :  .byte $90,$58,$00,$00,$00

fconst3:
0822 :  .byte $85,$48,$00,$00,$00

fconst4:
0827 :  .byte $84,$20,$00,$00,$00

fconst5:
082C :  .byte $86,$68,$00,$00,$00

fconst6:
0831 :  .byte $83,$20,$00,$00,$00

fconst7:
0836 :  .byte $91,$00,$00,$00,$00

ftemp:
083B :  .res 5	; float temp slots

sp_save:
0840 :  .res 1	; entry SP (END/STOP unwind GOSUB frames)

rnd_st:
0841 :  .res 2	; RT_rnd_fast 16-bit LFSR state (lo,hi)

rnd_k:
0843 :  .res 2	; RT_rnd_int K constant (lo,hi)
; ---- mulK lookup tables (speed-mode V*K strength reduction) ----

mulK40_lo:
0845 :  .byte $00,$28,$50,$78,$A0,$C8,$F0,$18,$40,$68,$90,$B8,$E0,$08,$30,$58	; mulK lo bytes (i*K & 0xFF)
	.byte $80,$A8,$D0,$F8,$20,$48,$70,$98,$C0

mulK40_hi:
085E :  .byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02	; mulK hi bytes (i*K >> 8)
	.byte $02,$02,$02,$02,$03,$03,$03,$03,$03
; ---- runtime helpers ----

RT_zero:
0877 :  LDY #0 ; $00
0879 :  LDX ZP_SCR16 + 1 ; $FE
087B :  BEQ .z_tail

.z_page:
087D :  LDA #0 ; $00

.z_pl:
087F :  STA (ZP_PTR),Y ; $FB
0881 :  INY
0882 :  BNE .z_pl
0884 :  INC ZP_PTR + 1 ; $FC
0886 :  DEX
0887 :  BNE .z_page

.z_tail:

.z_tail:
0889 :  LDX ZP_SCR16 ; $FD
088B :  BEQ .z_done_l

.z_tl:
088D :  LDA #0 ; $00
088F :  STA (ZP_PTR),Y ; $FB
0891 :  INY
0892 :  DEX
0893 :  BNE .z_tl

.z_done_l:

.z_done_l:
0895 :  RTS

RT_fmul_align:

RT_fmul:

RT_rnd_fast:
0B3F :  LDA FACEXP ; $61
0B41 :  BNE +3 ; FACEXP!=0 -> skip (long BEQ .seed_ti)
0B43 :  JMP .seed_ti

0B46 :  LDA 0x66 ; $66
0B48 :  BPL +3 ; arg>0 -> skip (long BMI .seed_arg)
0B4A :  JMP .seed_arg

.do_advance:
0B4D :  LDA rnd_st + 1 ; $0842
0B50 :  BNE .adv_lfsr
0B52 :  LDA rnd_st ; $0841
0B55 :  BNE .adv_lfsr
0B57 :  LDA 0xA1 ; $A1
0B59 :  STA rnd_st ; $0841
0B5C :  LDA 0xA2 ; $A2
0B5E :  STA rnd_st + 1 ; $0842
0B61 :  BNE .adv_lfsr
0B63 :  LDA rnd_st ; $0841
0B66 :  BNE .adv_lfsr
0B68 :  LDA #0xE1 ; $E1
0B6A :  STA rnd_st ; $0841
0B6D :  LDA #0xAC ; $AC
0B6F :  STA rnd_st + 1 ; $0842

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:

.adv_lfsr:
0B72 :  LDA rnd_st + 1 ; $0842
0B75 :  AND #1 ; $01
0B77 :  ASL
0B78 :  ASL
0B79 :  ASL
0B7A :  ASL
0B7B :  ASL
0B7C :  ASL
0B7D :  ASL
0B7E :  EOR rnd_st + 1 ; $0842
0B81 :  STA rnd_st + 1 ; $0842
0B84 :  LDA rnd_st ; $0841
0B87 :  LSR
0B88 :  EOR rnd_st + 1 ; $0842
0B8B :  STA rnd_st + 1 ; $0842
0B8E :  LDA rnd_st ; $0841
0B91 :  AND #1 ; $01
0B93 :  ASL
0B94 :  ASL
0B95 :  ASL
0B96 :  ASL
0B97 :  ASL
0B98 :  ASL
0B99 :  ASL
0B9A :  EOR rnd_st ; $0841
0B9D :  STA rnd_st ; $0841
0BA0 :  LDA rnd_st + 1 ; $0842
0BA3 :  LSR
0BA4 :  EOR rnd_st ; $0841
0BA7 :  STA rnd_st ; $0841
0BAA :  LDA rnd_st + 1 ; $0842
0BAD :  EOR rnd_st ; $0841
0BB0 :  STA rnd_st + 1 ; $0842
0BB3 :  BNE .rf_build
0BB5 :  LDA rnd_st ; $0841
0BB8 :  BEQ .to_zero

.rf_build:

.rf_build:
0BBA :  LDA rnd_st + 1 ; $0842
0BBD :  STA 0x62 ; $62
0BBF :  LDA rnd_st ; $0841
0BC2 :  STA 0x63 ; $63
0BC4 :  LDA #0 ; $00
0BC6 :  STA 0x64 ; $64
0BC8 :  STA 0x65 ; $65
0BCA :  STA 0x66 ; $66
0BCC :  LDA #128 ; $80
0BCE :  STA FACEXP ; $61

.cvt_loop:
0BD0 :  LDA 0x62 ; $62
0BD2 :  BMI .cvt_done
0BD4 :  ASL 0x65 ; $65
0BD6 :  ROL 0x64 ; $64
0BD8 :  ROL 0x63 ; $63
0BDA :  ROL 0x62 ; $62
0BDC :  DEC FACEXP ; $61
0BDE :  JMP .cvt_loop ; $0BD0

.cvt_done:

.cvt_done:
0BE1 :  RTS

.seed_ti:

.seed_ti:
0BE2 :  LDA 0xA1 ; $A1
0BE4 :  STA rnd_st ; $0841
0BE7 :  LDA 0xA2 ; $A2
0BE9 :  STA rnd_st + 1 ; $0842
0BEC :  JMP .do_advance ; $0B4D

.seed_arg:

.seed_arg:
0BEF :  LDA 0x63 ; $63
0BF1 :  STA rnd_st ; $0841
0BF4 :  LDA 0x64 ; $64
0BF6 :  STA rnd_st + 1 ; $0842
0BF9 :  JMP .do_advance ; $0B4D

.to_zero:

.to_zero:
0BFC :  LDA #0 ; $00
0BFE :  STA FACEXP ; $61
0C00 :  STA 0x62 ; $62
0C02 :  STA 0x63 ; $63
0C04 :  STA 0x64 ; $64
0C06 :  STA 0x65 ; $65
0C08 :  STA 0x66 ; $66
0C0A :  RTS

RT_rnd_int:
0C0B :  LDA rnd_st + 1 ; $0842
0C0E :  BNE .adv_int
0C10 :  LDA rnd_st ; $0841
0C13 :  BNE .adv_int
0C15 :  LDA 0xA1 ; $A1
0C17 :  STA rnd_st ; $0841
0C1A :  LDA 0xA2 ; $A2
0C1C :  STA rnd_st + 1 ; $0842
0C1F :  BNE .adv_int
0C21 :  LDA rnd_st ; $0841
0C24 :  BNE .adv_int
0C26 :  LDA #0xE1 ; $E1
0C28 :  STA rnd_st ; $0841
0C2B :  LDA #0xAC ; $AC
0C2D :  STA rnd_st + 1 ; $0842

.adv_int:

.adv_int:

.adv_int:

.adv_int:

.adv_int:
0C30 :  LDA rnd_st + 1 ; $0842
0C33 :  AND #1 ; $01
0C35 :  ASL
0C36 :  ASL
0C37 :  ASL
0C38 :  ASL
0C39 :  ASL
0C3A :  ASL
0C3B :  ASL
0C3C :  EOR rnd_st + 1 ; $0842
0C3F :  STA rnd_st + 1 ; $0842
0C42 :  LDA rnd_st ; $0841
0C45 :  LSR
0C46 :  EOR rnd_st + 1 ; $0842
0C49 :  STA rnd_st + 1 ; $0842
0C4C :  LDA rnd_st ; $0841
0C4F :  AND #1 ; $01
0C51 :  ASL
0C52 :  ASL
0C53 :  ASL
0C54 :  ASL
0C55 :  ASL
0C56 :  ASL
0C57 :  ASL
0C58 :  EOR rnd_st ; $0841
0C5B :  STA rnd_st ; $0841
0C5E :  LDA rnd_st + 1 ; $0842
0C61 :  LSR
0C62 :  EOR rnd_st ; $0841
0C65 :  STA rnd_st ; $0841
0C68 :  LDA rnd_st + 1 ; $0842
0C6B :  EOR rnd_st ; $0841
0C6E :  STA rnd_st + 1 ; $0842
0C71 :  LDA #0 ; $00
0C73 :  STA 0xFA ; $FA
0C75 :  STA 0xFB ; $FB
0C77 :  STA 0xFC ; $FC
0C79 :  STA 0xFD ; $FD
0C7B :  LDX #16 ; $10

.mul_loop:
0C7D :  LDA rnd_k + 1 ; $0844
0C80 :  AND #0x80 ; $80
0C82 :  ASL rnd_k ; $0843
0C85 :  ROL rnd_k+1 ; $0844
0C88 :  ASL 0xFA ; $FA
0C8A :  ROL 0xFB ; $FB
0C8C :  ROL 0xFC ; $FC
0C8E :  ROL 0xFD ; $FD
0C90 :  ASL
0C91 :  BCC .skip_add
0C93 :  CLC
0C94 :  LDA 0xFA ; $FA
0C96 :  ADC rnd_st ; $0841
0C99 :  STA 0xFA ; $FA
0C9B :  LDA 0xFB ; $FB
0C9D :  ADC rnd_st + 1 ; $0842
0CA0 :  STA 0xFB ; $FB
0CA2 :  LDA 0xFC ; $FC
0CA4 :  ADC #0 ; $00
0CA6 :  STA 0xFC ; $FC
0CA8 :  LDA 0xFD ; $FD
0CAA :  ADC #0 ; $00
0CAC :  STA 0xFD ; $FD

.skip_add:

.skip_add:
0CAE :  DEX
0CAF :  BNE .mul_loop
0CB1 :  LDA 0xFC ; $FC
0CB3 :  LDX 0xFD ; $FD
0CB5 :  RTS

; ---- save entry SP (END/STOP unwinds GOSUB frames to return to KERNAL, like CBM clearing the GOSUB stack) ----
0CB6 :  TSX
0CB7 :  STX sp_save_addr ; $0840
; ---- zero variable area (bss excluded from PRG; runtime-init via RT_zero) ----
0CBA :  LDA #0 ; $00
0CBC :  STA ZP_PTR ; $FB
0CBE :  LDA #0 ; $00
0CC0 :  STA ZP_PTR + 1 ; $FC
0CC2 :  LDA #0 ; $00
0CC4 :  STA ZP_SCR16 ; $FD
0CC6 :  LDA #0 ; $00
0CC8 :  STA ZP_SCR16 + 1 ; $FE
0CCA :  JSR RT_zero ; $0877
; ---- BASIC source ----
; 10    $0CCD  REM *** matrix digital rain - c64 ***
; 1,"matrix.bas"

L10:
; 20    $0CCD  REM white head, light-green body, green tail
; 2,"matrix.bas"

L20:
; 30    $0CCD  POKE 53280,0:POKE 53281,0
; 4,"matrix.bas"

L30:
0CCD :  LDA #(u8)s->e2->ival ; $00
0CCF :  STA ; $D020
0CD2 :  LDA #(u8)s->e2->ival ; $00
0CD4 :  STA ; $D021
; 40    $0CD7  PRINT CHR$(147)
; 5,"matrix.bas"

L40:
0CD7 :  LDA #LO(e->ival) ; $93
0CD9 :  LDX #LO((e->ival >> 8)) ; $00
0CDB :  JSR ROM_CHROUT ; $FFD2
0CDE :  LDA #13 ; $0D
0CE0 :  JSR ROM_CHROUT ; $FFD2
; 50    $0CE3  SC=1024:CR=55296
; 7,"matrix.bas"

L50:
0CE3 :  LDA #LO(e->ival) ; $00
0CE5 :  LDX #LO((e->ival >> 8)) ; $04
0CE7 :  STA SC
0CEA :  STX SC+1
0CED :  LDA #LO(K) ; $00
0CEF :  LDX #HI(K) ; $D8
0CF1 :  STA CR
0CF4 :  STX CR+1
; 60    $0CF7  DIM H(39):DIM E(39):DIM T(39):DIM CH(39):DIM D(39)
; 8,"matrix.bas"

L60:
; 70    $0CF7  FOR C=0 TO 39
; 10,"matrix.bas"

L70:
0CF7 :  LDA #LO(e->ival) ; $00
0CF9 :  LDX #LO((e->ival >> 8)) ; $00
0CFB :  STA C
0CFE :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
0D01 :  STA ZP_MULMP ; $FA
0D03 :  STX ZP_SCR_HI ; $FF
0D05 :  ASL ZP_MULMP ; $FA
0D07 :  ROL ZP_SCR_HI ; $FF
0D09 :  CLC
0D0A :  LDA #<H
0D0C :  ADC ZP_MULMP ; $FA
0D0E :  STA ZP_PTR ; $FB
0D10 :  LDA #>H+1
0D12 :  ADC ZP_SCR_HI ; $FF
0D14 :  STA ZP_PTR + 1 ; $FC
0D16 :  LDA ZP_PTR ; $FB
0D18 :  STA LOPT0
0D1B :  LDA ZP_PTR + 1 ; $FC
0D1D :  STA LOPT0+1
0D20 :  CLC
0D21 :  LDA #<T
0D23 :  ADC ZP_MULMP ; $FA
0D25 :  STA ZP_PTR ; $FB
0D27 :  LDA #>T+1
0D29 :  ADC ZP_SCR_HI ; $FF
0D2B :  STA ZP_PTR + 1 ; $FC
0D2D :  LDA ZP_PTR ; $FB
0D2F :  STA LOPT1
0D32 :  LDA ZP_PTR + 1 ; $FC
0D34 :  STA LOPT1+1
0D37 :  CLC
0D38 :  LDA #<E
0D3A :  ADC ZP_MULMP ; $FA
0D3C :  STA ZP_PTR ; $FB
0D3E :  LDA #>E+1
0D40 :  ADC ZP_SCR_HI ; $FF
0D42 :  STA ZP_PTR + 1 ; $FC
0D44 :  LDA ZP_PTR ; $FB
0D46 :  STA LOPT2
0D49 :  LDA ZP_PTR + 1 ; $FC
0D4B :  STA LOPT2+1
0D4E :  CLC
0D4F :  LDA #<CH
0D51 :  ADC ZP_MULMP ; $FA
0D53 :  STA ZP_PTR ; $FB
0D55 :  LDA #>CH+1
0D57 :  ADC ZP_SCR_HI ; $FF
0D59 :  STA ZP_PTR + 1 ; $FC
0D5B :  LDA ZP_PTR ; $FB
0D5D :  STA LOPT3
0D60 :  LDA ZP_PTR + 1 ; $FC
0D62 :  STA LOPT3+1
0D65 :  CLC
0D66 :  LDA #<D
0D68 :  ADC ZP_MULMP ; $FA
0D6A :  STA ZP_PTR ; $FB
0D6C :  LDA #>D+1
0D6E :  ADC ZP_SCR_HI ; $FF
0D70 :  STA ZP_PTR + 1 ; $FC
0D72 :  LDA ZP_PTR ; $FB
0D74 :  STA LOPT4
0D77 :  LDA ZP_PTR + 1 ; $FC
0D79 :  STA LOPT4+1
; opt: range-byte-loop

.for_body:
; 80    $0D7C  H(C)=INT(RND(1)*25)
; 11,"matrix.bas"

L80:
0D7C :  LDA #LO(K) ; $19
0D7E :  STA rnd_k ; $0843
0D81 :  LDA #HI(K) ; $00
0D83 :  STA rnd_k + 1 ; $0844
0D86 :  JSR RT_rnd_int ; $0C0B
0D89 :  PHA
0D8A :  LDA LOPT0
0D8D :  STA ZP_PTR ; $FB
0D8F :  LDA LOPT0+1
0D92 :  STA ZP_PTR + 1 ; $FC
0D94 :  PLA
0D95 :  LDY #0 ; $00
0D97 :  STA (ZP_PTR),Y ; $FB
0D99 :  INY
0D9A :  TXA
0D9B :  STA (ZP_PTR),Y ; $FB
; 90    $0D9D  T(C)=5+INT(RND(1)*10)
; 12,"matrix.bas"

L90:
0D9D :  LDA #LO(e->ival) ; $05
0D9F :  LDX #LO((e->ival >> 8)) ; $00
0DA1 :  STA slot+0
0DA3 :  LDA #LO(K) ; $0A
0DA5 :  STA rnd_k ; $0843
0DA8 :  LDA #HI(K) ; $00
0DAA :  STA rnd_k + 1 ; $0844
0DAD :  JSR RT_rnd_int ; $0C0B
0DB0 :  CLC
0DB1 :  ADC slot+0
0DB3 :  LDX #0 ; $00
0DB5 :  PHA
0DB6 :  LDA LOPT1
0DB9 :  STA ZP_PTR ; $FB
0DBB :  LDA LOPT1+1
0DBE :  STA ZP_PTR + 1 ; $FC
0DC0 :  PLA
0DC1 :  LDY #0 ; $00
0DC3 :  STA (ZP_PTR),Y ; $FB
0DC5 :  INY
0DC6 :  TXA
0DC7 :  STA (ZP_PTR),Y ; $FB
; 100   $0DC9  E(C)=H(C)-T(C):IF E(C)<0 THEN E(C)=E(C)+25
; 13,"matrix.bas"

L100:
0DC9 :  LDA LOPT1
0DCC :  STA ZP_PTR ; $FB
0DCE :  LDA LOPT1+1
0DD1 :  STA ZP_PTR + 1 ; $FC
0DD3 :  LDY #0 ; $00
0DD5 :  LDA (ZP_PTR),Y ; $FB
0DD7 :  STA ZP_SCR16 ; $FD
0DD9 :  INY
0DDA :  LAX (ZP_PTR),Y ; $FB
0DDC :  LDA ZP_SCR16 ; $FD
0DDE :  STA slot+0
0DE0 :  STX slot+1
0DE2 :  LDA LOPT0
0DE5 :  STA ZP_PTR ; $FB
0DE7 :  LDA LOPT0+1
0DEA :  STA ZP_PTR + 1 ; $FC
0DEC :  LDY #0 ; $00
0DEE :  LDA (ZP_PTR),Y ; $FB
0DF0 :  STA ZP_SCR16 ; $FD
0DF2 :  INY
0DF3 :  LAX (ZP_PTR),Y ; $FB
0DF5 :  LDA ZP_SCR16 ; $FD
0DF7 :  SEC
0DF8 :  SBC slot+0
0DFA :  PHA
0DFB :  TXA
0DFC :  SBC slot+1
0DFE :  TAX
0DFF :  PLA
0E00 :  PHA
0E01 :  LDA LOPT2
0E04 :  STA ZP_PTR ; $FB
0E06 :  LDA LOPT2+1
0E09 :  STA ZP_PTR + 1 ; $FC
0E0B :  PLA
0E0C :  LDY #0 ; $00
0E0E :  STA (ZP_PTR),Y ; $FB
0E10 :  INY
0E11 :  TXA
0E12 :  STA (ZP_PTR),Y ; $FB
0E14 :  LDA LOPT2
0E17 :  STA ZP_PTR ; $FB
0E19 :  LDA LOPT2+1
0E1C :  STA ZP_PTR + 1 ; $FC
0E1E :  LDY #0 ; $00
0E20 :  LDA (ZP_PTR),Y ; $FB
0E22 :  STA ZP_SCR16 ; $FD
0E24 :  INY
0E25 :  LAX (ZP_PTR),Y ; $FB
0E27 :  LDA ZP_SCR16 ; $FD
0E29 :  STX ZP_SCR16 + 1 ; $FE
0E2B :  LDA ZP_SCR16 + 1 ; $FE
0E2D :  BMI +3 ; long IF-skip (body >127B)
0E2F :  JMP .if_skip

0E32 :  LDA LOPT2
0E35 :  STA ZP_PTR ; $FB
0E37 :  LDA LOPT2+1
0E3A :  STA ZP_PTR + 1 ; $FC
0E3C :  LDY #0 ; $00
0E3E :  LDA (ZP_PTR),Y ; $FB
0E40 :  STA ZP_SCR16 ; $FD
0E42 :  INY
0E43 :  LAX (ZP_PTR),Y ; $FB
0E45 :  LDA ZP_SCR16 ; $FD
0E47 :  STA slot+0
0E49 :  LDA #LO(e->ival) ; $19
0E4B :  LDX #LO((e->ival >> 8)) ; $00
0E4D :  CLC
0E4E :  ADC slot+0
0E50 :  PHA
0E51 :  LDA LOPT2
0E54 :  STA ZP_PTR ; $FB
0E56 :  LDA LOPT2+1
0E59 :  STA ZP_PTR + 1 ; $FC
0E5B :  PLA
0E5C :  LDY #0 ; $00
0E5E :  STA (ZP_PTR),Y ; $FB
0E60 :  INY
0E61 :  TXA
0E62 :  STA (ZP_PTR),Y ; $FB

.if_skip:
; 110   $0E64  CH(C)=33+INT(RND(1)*58)
; 14,"matrix.bas"

L110:
0E64 :  LDA #LO(e->ival) ; $21
0E66 :  LDX #LO((e->ival >> 8)) ; $00
0E68 :  STA slot+0
0E6A :  LDA #LO(K) ; $3A
0E6C :  STA rnd_k ; $0843
0E6F :  LDA #HI(K) ; $00
0E71 :  STA rnd_k + 1 ; $0844
0E74 :  JSR RT_rnd_int ; $0C0B
0E77 :  CLC
0E78 :  ADC slot+0
0E7A :  LDX #0 ; $00
0E7C :  PHA
0E7D :  LDA LOPT3
0E80 :  STA ZP_PTR ; $FB
0E82 :  LDA LOPT3+1
0E85 :  STA ZP_PTR + 1 ; $FC
0E87 :  PLA
0E88 :  LDY #0 ; $00
0E8A :  STA (ZP_PTR),Y ; $FB
0E8C :  INY
0E8D :  TXA
0E8E :  STA (ZP_PTR),Y ; $FB
; 120   $0E90  D(C)=1+INT(RND(1)*5)
; 15,"matrix.bas"

L120:
0E90 :  LDA #LO(e->ival) ; $01
0E92 :  LDX #LO((e->ival >> 8)) ; $00
0E94 :  STA slot+0
0E96 :  LDA #LO(K) ; $05
0E98 :  STA rnd_k ; $0843
0E9B :  LDA #HI(K) ; $00
0E9D :  STA rnd_k + 1 ; $0844
0EA0 :  JSR RT_rnd_int ; $0C0B
0EA3 :  CLC
0EA4 :  ADC slot+0
0EA6 :  LDX #0 ; $00
0EA8 :  PHA
0EA9 :  LDA LOPT4
0EAC :  STA ZP_PTR ; $FB
0EAE :  LDA LOPT4+1
0EB1 :  STA ZP_PTR + 1 ; $FC
0EB3 :  PLA
0EB4 :  LDY #0 ; $00
0EB6 :  STA (ZP_PTR),Y ; $FB
0EB8 :  INY
0EB9 :  TXA
0EBA :  STA (ZP_PTR),Y ; $FB
; 130   $0EBC  NEXT C
; 16,"matrix.bas"

L130:
0EBC :  LDA LOPT0
0EBF :  CLC
0EC0 :  ADC #(u8)(st & 0xFF) ; $02
0EC2 :  STA LOPT0
0EC5 :  LDA LOPT0+1
0EC8 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0ECA :  STA LOPT0+1
0ECD :  LDA LOPT1
0ED0 :  CLC
0ED1 :  ADC #(u8)(st & 0xFF) ; $02
0ED3 :  STA LOPT1
0ED6 :  LDA LOPT1+1
0ED9 :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0EDB :  STA LOPT1+1
0EDE :  LDA LOPT2
0EE1 :  CLC
0EE2 :  ADC #(u8)(st & 0xFF) ; $02
0EE4 :  STA LOPT2
0EE7 :  LDA LOPT2+1
0EEA :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0EEC :  STA LOPT2+1
0EEF :  LDA LOPT3
0EF2 :  CLC
0EF3 :  ADC #(u8)(st & 0xFF) ; $02
0EF5 :  STA LOPT3
0EF8 :  LDA LOPT3+1
0EFB :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0EFD :  STA LOPT3+1
0F00 :  LDA LOPT4
0F03 :  CLC
0F04 :  ADC #(u8)(st & 0xFF) ; $02
0F06 :  STA LOPT4
0F09 :  LDA LOPT4+1
0F0C :  ADC #(u8)((st >> 8) & 0xFF) ; $00
0F0E :  STA LOPT4+1
0F11 :  INC C
0F14 :  LDA C
0F17 :  CMP #L->lim_lo ; $27
0F19 :  BEQ .nxt_back
0F1B :  BCS .nxt_done

.nxt_back:
0F1D :  JMP .for_body ; $0D7C

.nxt_done:
; 140   $0F20  FOR C=0 TO 39:GOSUB 1000:NEXT C
; 18,"matrix.bas"

L140:
0F20 :  LDA #LO(e->ival) ; $00
0F22 :  LDX #LO((e->ival >> 8)) ; $00
0F24 :  STA C
0F27 :  STX C+1
; opt: forlim (limit var store elided, immediate compare)
; opt: range-byte-loop

.for_body:
0F2A :  JSR L1000
0F2D :  INC C
0F30 :  LDA C
0F33 :  CMP #L->lim_lo ; $27
0F35 :  BEQ .nxt_back
0F37 :  BCS .nxt_done

.nxt_back:
0F39 :  JMP .for_body ; $0F2A

.nxt_done:
; 150   $0F3C  GOTO 140
; 19,"matrix.bas"

L150:
0F3C :  JMP L140

; 1000  $0F3F  REM --- advance column c by 1 row ---
; 21,"matrix.bas"

L1000:
; 1001  $0F3F  P=H(C)*40+C
; 22,"matrix.bas"

L1001:
0F3F :  LDA C
0F42 :  ASL
0F43 :  TAX
0F44 :  LDA H,X
0F47 :  STA ZP_SCR16 ; $FD
0F49 :  LDA H+1,X
0F4C :  TAX
0F4D :  LDA ZP_SCR16 ; $FD
0F4F :  TAY
0F50 :  LDA h_mulK_hi[K],Y ; $085E
0F53 :  TAX
0F54 :  LDA h_mulK_lo[K],Y ; $0845
0F57 :  STA slot+0
0F59 :  STX slot+1
0F5B :  LDA C
0F5E :  LDX #0 ; $00
0F60 :  CLC
0F61 :  ADC slot+0
0F63 :  PHA
0F64 :  TXA
0F65 :  ADC slot+1
0F67 :  TAX
0F68 :  PLA
0F69 :  STA P
0F6C :  STX P+1
; 1002  $0F6F  POKE SC+P,CH(C):POKE CR+P,1
; 23,"matrix.bas"

L1002:
0F6F :  LDA SC
0F72 :  LDX SC+1
0F75 :  STA slot+0
0F77 :  STX slot+1
0F79 :  LDA P
0F7C :  LDX P+1
0F7F :  CLC
0F80 :  ADC slot+0
0F82 :  PHA
0F83 :  TXA
0F84 :  ADC slot+1
0F86 :  TAX
0F87 :  PLA
0F88 :  STA ZP_PTR ; $FB
0F8A :  STX ZP_PTR + 1 ; $FC
0F8C :  PHA
0F8D :  LDA ZP_PTR + 1 ; $FC
0F8F :  PHA
0F90 :  LDA C
0F93 :  ASL
0F94 :  TAX
0F95 :  LDA CH,X
0F98 :  STA ZP_SCR16 ; $FD
0F9A :  LDA CH+1,X
0F9D :  TAX
0F9E :  LDA ZP_SCR16 ; $FD
0FA0 :  PLA
0FA1 :  STA ZP_PTR + 1 ; $FC
0FA3 :  PLA
0FA4 :  STA ZP_PTR ; $FB
0FA6 :  LDA ZP_SCR16 ; $FD
0FA8 :  LDY #0 ; $00
0FAA :  STA (ZP_PTR),Y ; $FB
0FAC :  LDA CR
0FAF :  LDX CR+1
0FB2 :  STA slot+0
0FB4 :  STX slot+1
0FB6 :  LDA P
0FB9 :  LDX P+1
0FBC :  CLC
0FBD :  ADC slot+0
0FBF :  PHA
0FC0 :  TXA
0FC1 :  ADC slot+1
0FC3 :  TAX
0FC4 :  PLA
0FC5 :  STA ZP_PTR ; $FB
0FC7 :  STX ZP_PTR + 1 ; $FC
0FC9 :  LDA #(u8)s->e2->ival ; $01
0FCB :  LDY #0 ; $00
0FCD :  STA (ZP_PTR),Y ; $FB
; 1003  $0FCF  CH(C)=CH(C)+D(C):IF CH(C)>90 THEN CH(C)=CH(C)-58
; 24,"matrix.bas"

L1003:
0FCF :  LDA C
0FD2 :  ASL
0FD3 :  TAX
0FD4 :  LDA CH,X
0FD7 :  STA ZP_SCR16 ; $FD
0FD9 :  LDA CH+1,X
0FDC :  TAX
0FDD :  LDA ZP_SCR16 ; $FD
0FDF :  STA slot+0
0FE1 :  LDA C
0FE4 :  ASL
0FE5 :  TAX
0FE6 :  LDA D,X
0FE9 :  STA ZP_SCR16 ; $FD
0FEB :  LDA D+1,X
0FEE :  TAX
0FEF :  LDA ZP_SCR16 ; $FD
0FF1 :  CLC
0FF2 :  ADC slot+0
0FF4 :  LDX #0 ; $00
0FF6 :  STA ZP_SCR16 ; $FD
0FF8 :  STX ZP_SCR16 + 1 ; $FE
0FFA :  LDA C
0FFD :  ASL
0FFE :  TAX
0FFF :  LDA ZP_SCR16 ; $FD
1001 :  STA CH,X
1004 :  LDA ZP_SCR16 + 1 ; $FE
1006 :  STA CH+1,X
1009 :  LDA C
100C :  ASL
100D :  TAX
100E :  LDA CH,X
1011 :  STA ZP_SCR16 ; $FD
1013 :  LDA CH+1,X
1016 :  TAX
1017 :  LDA ZP_SCR16 ; $FD
1019 :  STX ZP_SCR16 + 1 ; $FE
; opt: compare-narrow
101B :  CMP #klo ; $5A
101D :  BNE +3 ; long IF-skip (body >127B)
101F :  JMP .if_skip

1022 :  BCS +3 ; long IF-skip (body >127B)
1024 :  JMP .if_skip

1027 :  LDA #LO(e->ival) ; $3A
1029 :  LDX #LO((e->ival >> 8)) ; $00
102B :  STA slot+0
102D :  STX slot+1
102F :  LDA C
1032 :  ASL
1033 :  TAX
1034 :  LDA CH,X
1037 :  STA ZP_SCR16 ; $FD
1039 :  LDA CH+1,X
103C :  TAX
103D :  LDA ZP_SCR16 ; $FD
103F :  SEC
1040 :  SBC slot+0
1042 :  PHA
1043 :  TXA
1044 :  SBC slot+1
1046 :  TAX
1047 :  PLA
1048 :  STA ZP_SCR16 ; $FD
104A :  STX ZP_SCR16 + 1 ; $FE
104C :  LDA C
104F :  ASL
1050 :  TAX
1051 :  LDA ZP_SCR16 ; $FD
1053 :  STA CH,X
1056 :  LDA ZP_SCR16 + 1 ; $FE
1058 :  STA CH+1,X

.if_skip:
; 1004  $105B  B=H(C)-1:IF B<0 THEN B=24
; 25,"matrix.bas"

L1004:
105B :  LDA #LO(e->ival) ; $01
105D :  LDX #LO((e->ival >> 8)) ; $00
105F :  STA slot+0
1061 :  STX slot+1
1063 :  LDA C
1066 :  ASL
1067 :  TAX
1068 :  LDA H,X
106B :  STA ZP_SCR16 ; $FD
106D :  LDA H+1,X
1070 :  TAX
1071 :  LDA ZP_SCR16 ; $FD
1073 :  SEC
1074 :  SBC slot+0
1076 :  PHA
1077 :  TXA
1078 :  SBC slot+1
107A :  TAX
107B :  PLA
107C :  STA B
107F :  STX B+1
1082 :  LDA B+1
1085 :  BMI +3 ; long IF-skip (body >127B)
1087 :  JMP .if_skip

108A :  LDA #LO(e->ival) ; $18
108C :  LDX #LO((e->ival >> 8)) ; $00
108E :  STA B
1091 :  STX B+1

.if_skip:
; 1005  $1094  POKE CR+B*40+C,13
; 26,"matrix.bas"

L1005:
1094 :  LDA CR
1097 :  LDX CR+1
109A :  STA slot+0
109C :  STX slot+1
109E :  LDA B
10A1 :  LDX B+1
10A4 :  TAY
10A5 :  LDA h_mulK_hi[K],Y ; $085E
10A8 :  TAX
10A9 :  LDA h_mulK_lo[K],Y ; $0845
10AC :  CLC
10AD :  ADC slot+0
10AF :  PHA
10B0 :  TXA
10B1 :  ADC slot+1
10B3 :  TAX
10B4 :  PLA
10B5 :  STA slot+0
10B7 :  STX slot+1
10B9 :  LDA C
10BC :  LDX #0 ; $00
10BE :  CLC
10BF :  ADC slot+0
10C1 :  PHA
10C2 :  TXA
10C3 :  ADC slot+1
10C5 :  TAX
10C6 :  PLA
10C7 :  STA ZP_PTR ; $FB
10C9 :  STX ZP_PTR + 1 ; $FC
10CB :  LDA #(u8)s->e2->ival ; $0D
10CD :  LDY #0 ; $00
10CF :  STA (ZP_PTR),Y ; $FB
; 1006  $10D1  B=B-1:IF B<0 THEN B=24
; 27,"matrix.bas"

L1006:
10D1 :  LDA B
10D4 :  BNE .pm1_skip
10D6 :  DEC B+1

.pm1_skip:
10D9 :  DEC B
10DC :  LDA B+1
10DF :  BMI +3 ; long IF-skip (body >127B)
10E1 :  JMP .if_skip

10E4 :  LDA #LO(e->ival) ; $18
10E6 :  LDX #LO((e->ival >> 8)) ; $00
10E8 :  STA B
10EB :  STX B+1

.if_skip:
; 1007  $10EE  POKE CR+B*40+C,5
; 28,"matrix.bas"

L1007:
10EE :  LDA CR
10F1 :  LDX CR+1
10F4 :  STA slot+0
10F6 :  STX slot+1
10F8 :  LDA B
10FB :  LDX B+1
10FE :  TAY
10FF :  LDA h_mulK_hi[K],Y ; $085E
1102 :  TAX
1103 :  LDA h_mulK_lo[K],Y ; $0845
1106 :  CLC
1107 :  ADC slot+0
1109 :  PHA
110A :  TXA
110B :  ADC slot+1
110D :  TAX
110E :  PLA
110F :  STA slot+0
1111 :  STX slot+1
1113 :  LDA C
1116 :  LDX #0 ; $00
1118 :  CLC
1119 :  ADC slot+0
111B :  PHA
111C :  TXA
111D :  ADC slot+1
111F :  TAX
1120 :  PLA
1121 :  STA ZP_PTR ; $FB
1123 :  STX ZP_PTR + 1 ; $FC
1125 :  LDA #(u8)s->e2->ival ; $05
1127 :  LDY #0 ; $00
1129 :  STA (ZP_PTR),Y ; $FB
; 1008  $112B  POKE SC+E(C)*40+C,32
; 29,"matrix.bas"

L1008:
112B :  LDA SC
112E :  LDX SC+1
1131 :  STA slot+0
1133 :  STX slot+1
1135 :  LDA C
1138 :  ASL
1139 :  TAX
113A :  LDA E,X
113D :  STA ZP_SCR16 ; $FD
113F :  LDA E+1,X
1142 :  TAX
1143 :  LDA ZP_SCR16 ; $FD
1145 :  TAY
1146 :  LDA h_mulK_hi[K],Y ; $085E
1149 :  TAX
114A :  LDA h_mulK_lo[K],Y ; $0845
114D :  CLC
114E :  ADC slot+0
1150 :  PHA
1151 :  TXA
1152 :  ADC slot+1
1154 :  TAX
1155 :  PLA
1156 :  STA slot+0
1158 :  STX slot+1
115A :  LDA C
115D :  LDX #0 ; $00
115F :  CLC
1160 :  ADC slot+0
1162 :  PHA
1163 :  TXA
1164 :  ADC slot+1
1166 :  TAX
1167 :  PLA
1168 :  STA ZP_PTR ; $FB
116A :  STX ZP_PTR + 1 ; $FC
116C :  LDA #(u8)s->e2->ival ; $20
116E :  LDY #0 ; $00
1170 :  STA (ZP_PTR),Y ; $FB
; 1009  $1172  H(C)=H(C)+1:IF H(C)>24 THEN H(C)=0:CH(C)=33+INT(RND(1)*58):D(C)=1+INT(RND(1)*5)
; 30,"matrix.bas"

L1009:
1172 :  LDA C
1175 :  ASL
1176 :  TAX
1177 :  LDA H,X
117A :  STA ZP_SCR16 ; $FD
117C :  LDA H+1,X
117F :  TAX
1180 :  LDA ZP_SCR16 ; $FD
1182 :  STA slot+0
1184 :  LDA #LO(e->ival) ; $01
1186 :  LDX #LO((e->ival >> 8)) ; $00
1188 :  CLC
1189 :  ADC slot+0
118B :  STA ZP_SCR16 ; $FD
118D :  STX ZP_SCR16 + 1 ; $FE
118F :  LDA C
1192 :  ASL
1193 :  TAX
1194 :  LDA ZP_SCR16 ; $FD
1196 :  STA H,X
1199 :  LDA ZP_SCR16 + 1 ; $FE
119B :  STA H+1,X
119E :  LDA C
11A1 :  ASL
11A2 :  TAX
11A3 :  LDA H,X
11A6 :  STA ZP_SCR16 ; $FD
11A8 :  LDA H+1,X
11AB :  TAX
11AC :  LDA ZP_SCR16 ; $FD
11AE :  STX ZP_SCR16 + 1 ; $FE
11B0 :  LDA ZP_SCR16 + 1 ; $FE
11B2 :  EOR #0x80 ; $80
11B4 :  CMP #(u8)(cmp_uns_a ? khi : (khi ^ 0x80)) ; $80
11B6 :  BEQ .cmp_lo
11B8 :  BCS +3 ; long IF-skip (body >127B)
11BA :  JMP .if_skip

11BD :  BNE .cmp_body

.cmp_lo:
11BF :  LDA ZP_SCR16 ; $FD
11C1 :  CMP #klo ; $18
11C3 :  BNE +3 ; long IF-skip (body >127B)
11C5 :  JMP .if_skip

11C8 :  BCS +3 ; long IF-skip (body >127B)
11CA :  JMP .if_skip

.cmp_body:
11CD :  LDA #LO(e->ival) ; $00
11CF :  LDX #LO((e->ival >> 8)) ; $00
11D1 :  STA ZP_SCR16 ; $FD
11D3 :  STX ZP_SCR16 + 1 ; $FE
11D5 :  LDA C
11D8 :  ASL
11D9 :  TAX
11DA :  LDA ZP_SCR16 ; $FD
11DC :  STA H,X
11DF :  LDA ZP_SCR16 + 1 ; $FE
11E1 :  STA H+1,X
11E4 :  LDA #LO(e->ival) ; $21
11E6 :  LDX #LO((e->ival >> 8)) ; $00
11E8 :  STA slot+0
11EA :  LDA #LO(K) ; $3A
11EC :  STA rnd_k ; $0843
11EF :  LDA #HI(K) ; $00
11F1 :  STA rnd_k + 1 ; $0844
11F4 :  JSR RT_rnd_int ; $0C0B
11F7 :  CLC
11F8 :  ADC slot+0
11FA :  LDX #0 ; $00
11FC :  STA ZP_SCR16 ; $FD
11FE :  STX ZP_SCR16 + 1 ; $FE
1200 :  LDA C
1203 :  ASL
1204 :  TAX
1205 :  LDA ZP_SCR16 ; $FD
1207 :  STA CH,X
120A :  LDA ZP_SCR16 + 1 ; $FE
120C :  STA CH+1,X
120F :  LDA #LO(e->ival) ; $01
1211 :  LDX #LO((e->ival >> 8)) ; $00
1213 :  STA slot+0
1215 :  LDA #LO(K) ; $05
1217 :  STA rnd_k ; $0843
121A :  LDA #HI(K) ; $00
121C :  STA rnd_k + 1 ; $0844
121F :  JSR RT_rnd_int ; $0C0B
1222 :  CLC
1223 :  ADC slot+0
1225 :  LDX #0 ; $00
1227 :  STA ZP_SCR16 ; $FD
1229 :  STX ZP_SCR16 + 1 ; $FE
122B :  LDA C
122E :  ASL
122F :  TAX
1230 :  LDA ZP_SCR16 ; $FD
1232 :  STA D,X
1235 :  LDA ZP_SCR16 + 1 ; $FE
1237 :  STA D+1,X

.if_skip:
; 1010  $123A  E(C)=E(C)+1:IF E(C)>24 THEN E(C)=0
; 31,"matrix.bas"

L1010:
123A :  LDA C
123D :  ASL
123E :  TAX
123F :  LDA E,X
1242 :  STA ZP_SCR16 ; $FD
1244 :  LDA E+1,X
1247 :  TAX
1248 :  LDA ZP_SCR16 ; $FD
124A :  STA slot+0
124C :  LDA #LO(e->ival) ; $01
124E :  LDX #LO((e->ival >> 8)) ; $00
1250 :  CLC
1251 :  ADC slot+0
1253 :  STA ZP_SCR16 ; $FD
1255 :  STX ZP_SCR16 + 1 ; $FE
1257 :  LDA C
125A :  ASL
125B :  TAX
125C :  LDA ZP_SCR16 ; $FD
125E :  STA E,X
1261 :  LDA ZP_SCR16 + 1 ; $FE
1263 :  STA E+1,X
1266 :  LDA C
1269 :  ASL
126A :  TAX
126B :  LDA E,X
126E :  STA ZP_SCR16 ; $FD
1270 :  LDA E+1,X
1273 :  TAX
1274 :  LDA ZP_SCR16 ; $FD
1276 :  STX ZP_SCR16 + 1 ; $FE
1278 :  LDA ZP_SCR16 + 1 ; $FE
127A :  EOR #0x80 ; $80
127C :  CMP #(u8)(cmp_uns_a ? khi : (khi ^ 0x80)) ; $80
127E :  BEQ .cmp_lo
1280 :  BCS +3 ; long IF-skip (body >127B)
1282 :  JMP .if_skip

1285 :  BNE .cmp_body

.cmp_lo:
1287 :  LDA ZP_SCR16 ; $FD
1289 :  CMP #klo ; $18
128B :  BNE +3 ; long IF-skip (body >127B)
128D :  JMP .if_skip

1290 :  BCS +3 ; long IF-skip (body >127B)
1292 :  JMP .if_skip

.cmp_body:
1295 :  LDA #LO(e->ival) ; $00
1297 :  LDX #LO((e->ival >> 8)) ; $00
1299 :  STA ZP_SCR16 ; $FD
129B :  STX ZP_SCR16 + 1 ; $FE
129D :  LDA C
12A0 :  ASL
12A1 :  TAX
12A2 :  LDA ZP_SCR16 ; $FD
12A4 :  STA E,X
12A7 :  LDA ZP_SCR16 + 1 ; $FE
12A9 :  STA E+1,X

.if_skip:
; 1011  $12AC  RETURN
; 32,"matrix.bas"

L1011:
12AC :  RTS

; halt
; ---- variables (zero-filled) ----
SC = $1300
; SC     $1300 (2 bytes)
CR = $1302
; CR     $1302 (2 bytes)
H = $1304
; H      $1304 (80 bytes array)
E = $1354
; E      $1354 (80 bytes array)
T = $13A4
; T      $13A4 (80 bytes array)
CH = $13F4
; CH     $13F4 (80 bytes array)
D = $1444
; D      $1444 (80 bytes array)
C = $1494
; C      $1494 (2 bytes)
P = $1496
; P      $1496 (2 bytes)
B = $1498
; B      $1498 (2 bytes)
LOPT0 = $149A
; LOPT0  $149A (2 bytes)
LOPT1 = $149C
; LOPT1  $149C (2 bytes)
LOPT2 = $149E
; LOPT2  $149E (2 bytes)
LOPT3 = $14A0
; LOPT3  $14A0 (2 bytes)
LOPT4 = $14A2
; LOPT4  $14A2 (2 bytes)
LIMIT1 = $14A4
; LIMIT1 $14A4 (2 bytes)
LIMIT2 = $14A6
; LIMIT2 $14A6 (2 bytes)
12AD :  .res 507	; variable area
