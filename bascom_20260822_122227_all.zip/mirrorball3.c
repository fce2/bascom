/* OPTIMIZE_C -- mirrorball3.bas */
#include "runtime.h"
#include "tsb.h"

/* ---- variables ---- */
static breal_t b_a_kxf[61];
static breal_t b_a_kyf[61];
static breal_t b_a_kzf[61];
static breal_t b_a_oxf[61];
static breal_t b_a_oyf[61];
static breal_t b_a_ozf[61];
static int b_a_kri[61];
static breal_t b_a_vxf[61];
static breal_t b_a_vyf[61];
static breal_t b_a_vzf[61];
static int b_a_mi[61];
static breal_t b_v_akf;
static breal_t b_v_bxf;
static breal_t b_v_byf;
static breal_t b_v_bzf;
static int b_v_bei;
static bint_t b_v_lxi;
static bint_t b_v_lyi;
static bint_t b_v_lzi;
static int b_v_gbi;
static breal_t b_v_gf;
static breal_t b_v_ref;
static breal_t b_v_grf;
static int b_v_wli;
static int b_v_zli;
static int b_v_zri;
static int b_v_chi;
static bint_t b_v_fri;
static int b_v_cfi;
static breal_t b_v_ccf;
static breal_t b_v_caf;
static breal_t b_v_ssf;
static breal_t b_v_if;
static bint_t b_v_pbi;
static breal_t b_v_zwf;
static breal_t b_v_yf;
static breal_t b_v_zxf;
static breal_t b_v_pwf;
static int b_v_pxi;
static breal_t b_v_xf;
static breal_t b_v_rxf;
static breal_t b_v_ryf;
static breal_t b_v_rzf;
static breal_t b_v_oxf;
static breal_t b_v_oyf;
static breal_t b_v_ozf;
static int b_v_rdi;
static breal_t b_v_tf;
static breal_t b_v_laf;
static breal_t b_v_sxf;
static int b_v_syi;
static breal_t b_v_szf;
static breal_t b_v_faf;
static breal_t b_v_kf;
static breal_t b_v_x1f;
static breal_t b_v_x2f;
static breal_t b_v_x3f;
static breal_t b_v_f1f;
static breal_t b_v_f2f;
static breal_t b_v_f3f;
static breal_t b_v_df;
static breal_t b_v_nxf;
static breal_t b_v_nyf;
static breal_t b_v_nzf;
static bstr_t b_v_as;
static breal_t b_v_pf;
static breal_t b_v_qf;
static breal_t b_v_z1f;
static breal_t b_v_z2f;
static breal_t b_v_wuf;
static breal_t b_v_z0f;
static int b_v_ji;
static breal_t b_v_dxf;
static breal_t b_v_dyf;
static breal_t b_v_dzf;
static int b_v_rsi;
static breal_t b_v_ovf;
static int b_v_mti;
static breal_t b_v_fif;
static breal_t b_v_fjf;
static breal_t b_v_vnf;
static breal_t b_v_imf;
static int b_v_M0;
static int b_v_M1;
static bint_t b_t_0;
static bint_t b_t_1;
static breal_t b_fl_0;
static breal_t b_fl_4;
static breal_t b_fl_5;
static breal_t b_fl_6;
static breal_t b_fl_7;
static int b_fl_8;

/* ---- DATA pool ---- */
const b_datum b_data[] = {{0,0,0,0,0}};
int b_data_len = 1;
int b_dataPtr = 0;

/* ---- functions ---- */

/* ---- main ---- */
int main(void){
	b_init();
	tsb_init();
	for(;;){
		/* line 100 */
b_L100: ;
		/* line 101 */
b_L101: ;
		/* line 102 */
b_L102: ;
		/* line 103 */
b_L103: ;
		/* line 200 */
b_L200: ;
		/* line 201 */
b_L201: ;
		b_v_akf=(5);
		/* line 202 */
b_L202: ;
		b_v_bxf=(0);
		b_v_byf=(24);
		b_v_bzf=(-50);
		b_v_bei=(25);
		/* line 203 */
b_L203: ;
		b_v_lxi=(-50);
		b_v_lyi=(300);
		b_v_lzi=(50);
		/* line 204 */
b_L204: ;
		b_v_gbi=(26);
		/* line 205 */
b_L205: ;
		b_v_gf=(0.25);
		b_v_ref=(0.98999999999068677);
		b_v_grf=(0.050000000002910383);
		/* line 206 */
b_L206: ;
		b_v_wli=(18);
		b_v_zli=(38);
		b_v_zri=(82);
		b_v_chi=(50);
		/* line 207 */
b_L207: ;
		b_poke((53272.0),(11));
		b_poke((53265.0),(59));
		b_poke((56576.0),(148));
		/* line 250 */
b_L250: ;
		b_v_fri=(0);
		b_v_cfi=(0);
		/* line 255 */
b_L255: ;
		b_gosubStack[b_gosubSP++]=0; goto b_L1200;
b_ret0: ;
		/* line 260 */
b_L260: ;
		b_gosubStack[b_gosubSP++]=1; goto b_L2000;
b_ret1: ;
		/* line 262 */
b_L262: ;
		b_v_ccf=b_cos(b_v_caf);
		b_v_ssf=b_sin(b_v_caf);
		/* line 263 */
b_L263: ;
		b_v_if=(0);
		b_fl_0=b_v_akf;
		if(b_v_if > b_fl_0) goto b_f0_e;
b_f0_t: ;
		b_a_kxf[(bint_t)(b_v_if)]=((((b_a_oxf[(bint_t)(b_v_if)])*(b_v_ccf)))-(((((b_a_ozf[(bint_t)(b_v_if)])-((60))))*(b_v_ssf))));
		b_a_kzf[(bint_t)(b_v_if)]=(((((60))+(((b_a_oxf[(bint_t)(b_v_if)])*(b_v_ssf)))))+(((((b_a_ozf[(bint_t)(b_v_if)])-((60))))*(b_v_ccf))));
		b_a_kyf[(bint_t)(b_v_if)]=b_a_oyf[(bint_t)(b_v_if)];
		b_v_if += 1;
		if(b_v_if <= (b_fl_0)) goto b_f0_t;
b_f0_e: ;
		/* line 265 */
b_L265: ;
		if(-((b_v_cfi) == ((0)))){ goto b_L300; }
		/* line 266 */
b_L266: ;
		goto b_L304;
		/* line 300 */
b_L300: ;
		b_v_if=(1024);
		if(b_v_if > 2023) goto b_f1_e;
b_f1_t: ;
		/* line 301 */
b_L301: ;
		b_poke((((48128.0))+(b_v_if)),(15));
		/* line 302 */
b_L302: ;
		b_poke((((54272.0))+(b_v_if)),(0));
		/* line 303 */
b_L303: ;
		b_v_if += 1;
		if(b_v_if <= 2023) goto b_f1_t;
b_f1_e: ;
		b_v_cfi=(1);
		/* line 304 */
b_L304: ;
		b_v_pbi=(0);
		if(b_v_pbi > 8000) goto b_f2_e;
b_f2_t: ;
		/* line 306 */
b_L306: ;
		b_v_zwf=(B_INT(b_v_pbi) & B_INT((7)));
		/* line 307 */
b_L307: ;
		b_v_yf=((((b_int(((breal_t)(b_v_pbi)/(breal_t)((320)))))*((8))))+(b_v_zwf));
		/* line 308 */
b_L308: ;
		b_v_zwf=b_int(((breal_t)(b_v_pbi)/(breal_t)((8))));
		/* line 309 */
b_L309: ;
		b_v_zxf=((((b_v_zwf)-(((b_int((b_v_zwf/(breal_t)((40)))))*((40))))))*((8)));
		/* line 310 */
b_L310: ;
		b_v_pwf=(0);
		/* line 400 */
b_L400: ;
		b_v_pxi=(0);
		if(b_v_pxi > 7) goto b_f3_e;
b_f3_t: ;
		/* line 401 */
b_L401: ;
		b_v_xf=((b_v_zxf)+(b_v_pxi));
		/* line 402 */
b_L402: ;
		b_v_zwf=((breal_t)(b_v_gbi)/(breal_t)((320)));
		/* line 403 */
b_L403: ;
		b_v_rxf=((((b_v_xf)*(b_v_zwf)))-(((b_v_gbi)*((0.5)))));
		/* line 404 */
b_L404: ;
		b_v_ryf=(((((-(b_v_yf)))*(b_v_zwf)))+((((((200))*((0.5))))*(b_v_zwf))));
		/* line 405 */
b_L405: ;
		b_v_rzf=b_v_bei;
		/* line 406 */
b_L406: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 407 */
b_L407: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 408 */
b_L408: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 409 */
b_L409: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 410 */
b_L410: ;
		b_v_oxf=b_v_bxf;
		/* line 411 */
b_L411: ;
		b_v_oyf=b_v_byf;
		/* line 412 */
b_L412: ;
		b_v_ozf=b_v_bzf;
		/* line 413 */
b_L413: ;
		b_v_rdi=(0);
		/* line 500 */
b_L500: ;
		b_gosubStack[b_gosubSP++]=2; goto b_L1000;
b_ret2: ;
		/* line 501 */
b_L501: ;
		switch((-(-((((b_v_oyf)+(((b_v_tf)*(b_v_ryf))))) > ((0)))))){
			case 1: goto b_L600; break;
			default: break;}
		/* line 502 */
b_L502: ;
		b_v_laf=((-(b_v_oyf))/b_v_ryf);
		/* line 503 */
b_L503: ;
		b_v_sxf=((b_v_oxf)+(((b_v_laf)*(b_v_rxf))));
		/* line 504 */
b_L504: ;
		b_v_syi=(0);
		/* line 505 */
b_L505: ;
		b_v_szf=((b_v_ozf)+(((b_v_laf)*(b_v_rzf))));
		/* line 506 */
b_L506: ;
		b_v_zwf=(((B_INT(b_int((b_v_sxf/(breal_t)((5))))) & B_INT((1))))+((B_INT(b_int((b_v_szf/(breal_t)((5))))) & B_INT((1)))));
		/* line 507 */
b_L507: ;
		b_v_faf=((-((b_v_zwf) == ((1))))+((1)));
		/* line 508 */
b_L508: ;
		b_v_oxf=b_v_sxf;
		/* line 509 */
b_L509: ;
		b_v_oyf=b_v_syi;
		/* line 510 */
b_L510: ;
		b_v_ozf=b_v_szf;
		/* line 511 */
b_L511: ;
		b_v_rxf=((b_v_oxf)+(b_v_lxi));
		/* line 512 */
b_L512: ;
		b_v_ryf=((b_v_oyf)+(b_v_lyi));
		/* line 513 */
b_L513: ;
		b_v_rzf=((b_v_ozf)+(b_v_lzi));
		/* line 514 */
b_L514: ;
		b_gosubStack[b_gosubSP++]=3; goto b_L1000;
b_ret3: ;
		/* line 515 */
b_L515: ;
		switch((-(-((b_v_kf) == ((-1)))))){
			case 1: goto b_L900; break;
			default: break;}
		/* line 516 */
b_L516: ;
		b_v_faf=((-((((bint_t)(b_v_xf) & B_INT((1)))) != (((bint_t)(b_v_yf) & B_INT((1))))))+((1)));
		/* line 517 */
b_L517: ;
		goto b_L900;
		/* line 600 */
b_L600: ;
		if(-((b_v_kf) == ((-1)))){
			b_v_faf=(0);
			goto b_L900;
		}
		/* line 700 */
b_L700: ;
		b_v_x1f=((((((b_a_kxf[(bint_t)(b_v_kf)])*(b_v_rxf)))+(((b_a_kyf[(bint_t)(b_v_kf)])*(b_v_ryf)))))+(((b_a_kzf[(bint_t)(b_v_kf)])*(b_v_rzf))));
		/* line 701 */
b_L701: ;
		b_v_x2f=((((((b_v_oxf)*(b_v_rxf)))+(((b_v_oyf)*(b_v_ryf)))))+(((b_v_ozf)*(b_v_rzf))));
		/* line 702 */
b_L702: ;
		b_v_x3f=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 703 */
b_L703: ;
		b_v_laf=(((b_v_x1f)-(b_v_x2f))/b_v_x3f);
		/* line 704 */
b_L704: ;
		b_v_f1f=((((b_v_oxf)+(((b_v_laf)*(b_v_rxf)))))-(b_a_kxf[(bint_t)(b_v_kf)]));
		/* line 705 */
b_L705: ;
		b_v_f2f=((((b_v_oyf)+(((b_v_laf)*(b_v_ryf)))))-(b_a_kyf[(bint_t)(b_v_kf)]));
		/* line 706 */
b_L706: ;
		b_v_f3f=((((b_v_ozf)+(((b_v_laf)*(b_v_rzf)))))-(b_a_kzf[(bint_t)(b_v_kf)]));
		/* line 707 */
b_L707: ;
		b_v_df=b_sqr(((((((b_v_f1f)*(b_v_f1f)))+(((b_v_f2f)*(b_v_f2f)))))+(((b_v_f3f)*(b_v_f3f)))));
		/* line 708 */
b_L708: ;
		if(-((((b_a_kri[(bint_t)(b_v_kf)])*((0.94999999995343387)))) < (b_v_df))){
			b_v_faf=(1);
			goto b_L900;
		}
		/* line 710 */
b_L710: ;
		b_v_rdi=((b_v_rdi)+((1)));
		if(-((b_v_rdi) > ((3)))){
			b_v_faf=(1);
			goto b_L900;
		}
		/* line 800 */
b_L800: ;
		b_v_oxf=((b_v_oxf)+(((b_v_tf)*(b_v_rxf))));
		/* line 801 */
b_L801: ;
		b_v_oyf=((b_v_oyf)+(((b_v_tf)*(b_v_ryf))));
		/* line 802 */
b_L802: ;
		b_v_ozf=((b_v_ozf)+(((b_v_tf)*(b_v_rzf))));
		/* line 803 */
b_L803: ;
		b_v_nxf=((b_a_kxf[(bint_t)(b_v_kf)])-(b_v_oxf));
		/* line 804 */
b_L804: ;
		b_v_nyf=((b_a_kyf[(bint_t)(b_v_kf)])-(b_v_oyf));
		/* line 805 */
b_L805: ;
		b_v_nzf=((b_a_kzf[(bint_t)(b_v_kf)])-(b_v_ozf));
		/* line 806 */
b_L806: ;
		b_v_zwf=((((((b_v_nxf)*(b_v_rxf)))+(((b_v_nyf)*(b_v_ryf)))))+(((b_v_nzf)*(b_v_rzf))));
		/* line 807 */
b_L807: ;
		b_v_rxf=((b_v_rxf)-((((((2))*(b_v_zwf)))*(b_v_nxf))));
		/* line 808 */
b_L808: ;
		b_v_ryf=((b_v_ryf)-((((((2))*(b_v_zwf)))*(b_v_nyf))));
		/* line 809 */
b_L809: ;
		b_v_rzf=((b_v_rzf)-((((((2))*(b_v_zwf)))*(b_v_nzf))));
		/* line 810 */
b_L810: ;
		b_v_zwf=b_sqr(((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf)))));
		/* line 811 */
b_L811: ;
		b_v_rxf=(b_v_rxf/b_v_zwf);
		/* line 812 */
b_L812: ;
		b_v_ryf=(b_v_ryf/b_v_zwf);
		/* line 813 */
b_L813: ;
		b_v_rzf=(b_v_rzf/b_v_zwf);
		/* line 814 */
b_L814: ;
		goto b_L500;
		/* line 900 */
b_L900: ;
		b_v_pwf=((((b_v_pwf)*((2))))+(b_v_faf));
		/* line 901 */
b_L901: ;
		b_v_pxi += 1;
		if(b_v_pxi <= 7) goto b_f3_t;
b_f3_e: ;
		/* line 902 */
b_L902: ;
		b_poke((((57344.0))+(b_v_pbi)),b_v_pwf);
		/* line 903 */
b_L903: ;
		b_v_pbi += 1;
		if(b_v_pbi <= 8000) goto b_f2_t;
b_f2_e: ;
		/* line 904 */
b_L904: ;
		b_v_fri=((b_v_fri)+((1)));
		/* line 905 */
b_L905: ;
		{ int _g=b_getin(); if(_g<0) b_v_as=b_lit("",0); else b_v_as=b_keep(b_chr(_g)); }
		/* line 906 */
b_L906: ;
		if(-(b_strcmp(b_v_as,b_lit(" ",1)) == 0)){
			b_gosubStack[b_gosubSP++]=4; goto b_L1400;
b_ret4: ;
		}
		/* line 907 */
b_L907: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("R",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("R",1)) == 0)))){
			b_gosubStack[b_gosubSP++]=5; goto b_L1200;
b_ret5: ;
		}
		/* line 908 */
b_L908: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("Q",1)) == 0)))){ goto b_L920; }
		/* line 909 */
b_L909: ;
		if(-(b_strcmp(b_v_as,b_lit("\035",1)) == 0)){
			b_v_caf=((b_v_caf)+((0.10000000000582077)));
		}
		/* line 910 */
b_L910: ;
		if(-(b_strcmp(b_v_as,b_lit("\235",1)) == 0)){
			b_v_caf=((b_v_caf)-((0.10000000000582077)));
		}
		/* line 911 */
b_L911: ;
		if(-(b_strcmp(b_v_as,b_lit("\221",1)) == 0)){
			b_v_byf=((b_v_byf)+((1)));
		}
		/* line 912 */
b_L912: ;
		if(-(b_strcmp(b_v_as,b_lit("\021",1)) == 0)){
			b_v_byf=((b_v_byf)-((1)));
		}
		/* line 913 */
b_L913: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("W",1)) == 0)))){
			b_v_bzf=((b_v_bzf)+((1)));
		}
		/* line 914 */
b_L914: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("S",1)) == 0)))){
			b_v_bzf=((b_v_bzf)-((1)));
		}
		/* line 915 */
b_L915: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("A",1)) == 0)))){
			b_v_bxf=((b_v_bxf)-((1)));
		}
		/* line 916 */
b_L916: ;
		if((B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)) | B_INT(-(b_strcmp(b_v_as,b_lit("D",1)) == 0)))){
			b_v_bxf=((b_v_bxf)+((1)));
		}
		/* line 917 */
b_L917: ;
		goto b_L260;
		/* line 920 */
b_L920: ;
		goto b_end;
		/* line 1000 */
b_L1000: ;
		b_v_kf=(-1);
		/* line 1001 */
b_L1001: ;
		b_v_tf=(99999.0);
		/* line 1002 */
b_L1002: ;
		b_v_if=(0);
		b_fl_4=b_v_akf;
		if(b_v_if > b_fl_4) goto b_f4_e;
b_f4_t: ;
		/* line 1003 */
b_L1003: ;
		b_v_zwf=((((((b_v_rxf)*(b_v_rxf)))+(((b_v_ryf)*(b_v_ryf)))))+(((b_v_rzf)*(b_v_rzf))));
		/* line 1004 */
b_L1004: ;
		b_v_pf=((((2))*(((((((b_v_rxf)*(((b_v_oxf)-(b_a_kxf[(bint_t)(b_v_if)])))))+(((b_v_ryf)*(((b_v_oyf)-(b_a_kyf[(bint_t)(b_v_if)])))))))+(((b_v_rzf)*(((b_v_ozf)-(b_a_kzf[(bint_t)(b_v_if)]))))))))/b_v_zwf);
		/* line 1005 */
b_L1005: ;
		b_v_qf=(((((((((((b_v_oxf)-(b_a_kxf[(bint_t)(b_v_if)])))*(((b_v_oxf)-(b_a_kxf[(bint_t)(b_v_if)])))))+(((((b_v_oyf)-(b_a_kyf[(bint_t)(b_v_if)])))*(((b_v_oyf)-(b_a_kyf[(bint_t)(b_v_if)])))))))+(((((b_v_ozf)-(b_a_kzf[(bint_t)(b_v_if)])))*(((b_v_ozf)-(b_a_kzf[(bint_t)(b_v_if)])))))))-(((b_a_kri[(bint_t)(b_v_if)])*(b_a_kri[(bint_t)(b_v_if)]))))/b_v_zwf);
		/* line 1006 */
b_L1006: ;
		b_v_z1f=(((-(b_v_pf)))*((0.5)));
		/* line 1007 */
b_L1007: ;
		b_v_z2f=((((((b_v_pf)*(b_v_pf)))*((0.25))))-(b_v_qf));
		/* line 1008 */
b_L1008: ;
		if(-((b_v_z2f) < ((0)))){
			b_v_if += 1;
			if(b_v_if <= (b_fl_4)) goto b_f4_t;
			goto b_return;
		}
		/* line 1100 */
b_L1100: ;
		b_v_wuf=b_sqr(b_v_z2f);
		/* line 1101 */
b_L1101: ;
		b_v_x1f=((b_v_z1f)+(b_v_wuf));
		/* line 1102 */
b_L1102: ;
		b_v_x2f=((b_v_z1f)-(b_v_wuf));
		/* line 1103 */
b_L1103: ;
		b_v_z0f=(-((B_INT(-((b_v_x1f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x1f) < (b_v_tf))))));
		/* line 1104 */
b_L1104: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 1105 */
b_L1105: ;
		b_v_kf=((((b_v_z0f)*(b_v_if)))+(((b_v_z1f)*(b_v_kf))));
		/* line 1106 */
b_L1106: ;
		b_v_tf=((((b_v_z0f)*(b_v_x1f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 1107 */
b_L1107: ;
		b_v_z0f=(-((B_INT(-((b_v_x2f) > ((0.0010000000002037268)))) & B_INT(-((b_v_x2f) < (b_v_tf))))));
		/* line 1108 */
b_L1108: ;
		b_v_z1f=(((-(b_v_z0f)))+((1)));
		/* line 1109 */
b_L1109: ;
		b_v_kf=((((b_v_z0f)*(b_v_if)))+(((b_v_z1f)*(b_v_kf))));
		/* line 1110 */
b_L1110: ;
		b_v_tf=((((b_v_z0f)*(b_v_x2f)))+(((b_v_z1f)*(b_v_tf))));
		/* line 1111 */
b_L1111: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_4)) goto b_f4_t;
b_f4_e: ;
		/* line 1112 */
b_L1112: ;
		goto b_return;
		/* line 1200 */
b_L1200: ;
		/* line 1210 */
b_L1210: ;
		b_v_akf=(0);
		/* line 1220 */
b_L1220: ;
		b_v_if=(0);
		b_fl_5=b_v_akf;
		if(b_v_if > b_fl_5) goto b_f5_e;
b_f5_t: ;
		/* line 1230 */
b_L1230: ;
		b_a_kri[(bint_t)(b_v_if)]=(((3))+(b_int(((b_rnd(B_INT((1))))*((5))))));
		/* line 1240 */
b_L1240: ;
		b_a_oxf[(bint_t)(b_v_if)]=(((-16))+(((b_rnd(B_INT((1))))*((32)))));
		/* line 1250 */
b_L1250: ;
		b_a_ozf[(bint_t)(b_v_if)]=(((40))+(((b_rnd(B_INT((1))))*((40)))));
		/* line 1260 */
b_L1260: ;
		b_a_oyf[(bint_t)(b_v_if)]=(((35))+(((b_rnd(B_INT((1))))*((10)))));
		/* line 1270 */
b_L1270: ;
		b_a_vxf[(bint_t)(b_v_if)]=((((((b_rnd(B_INT((1))))*((2))))-((1))))*((2.5)));
		/* line 1280 */
b_L1280: ;
		b_a_vyf[(bint_t)(b_v_if)]=(0);
		/* line 1290 */
b_L1290: ;
		b_a_vzf[(bint_t)(b_v_if)]=((((((b_rnd(B_INT((1))))*((2))))-((1))))*((2.5)));
		/* line 1300 */
b_L1300: ;
		b_a_mi[(bint_t)(b_v_if)]=((b_a_kri[(bint_t)(b_v_if)])*(b_a_kri[(bint_t)(b_v_if)]));
		/* line 1310 */
b_L1310: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_5)) goto b_f5_t;
b_f5_e: ;
		/* line 1320 */
b_L1320: ;
		b_v_cfi=(0);
		/* line 1330 */
b_L1330: ;
		goto b_return;
		/* line 1400 */
b_L1400: ;
		/* line 1410 */
b_L1410: ;
		if(-((b_v_akf) >= ((59)))){
			goto b_return;
		}
		/* line 1420 */
b_L1420: ;
		b_v_akf=((b_v_akf)+((1)));
		b_v_if=b_v_akf;
		/* line 1430 */
b_L1430: ;
		b_a_kri[(bint_t)(b_v_if)]=(((3))+(b_int(((b_rnd(B_INT((1))))*((5))))));
		/* line 1440 */
b_L1440: ;
		b_a_oxf[(bint_t)(b_v_if)]=(((-16))+(((b_rnd(B_INT((1))))*((32)))));
		/* line 1450 */
b_L1450: ;
		b_a_ozf[(bint_t)(b_v_if)]=(((40))+(((b_rnd(B_INT((1))))*((40)))));
		/* line 1460 */
b_L1460: ;
		b_a_oyf[(bint_t)(b_v_if)]=(50);
		/* line 1470 */
b_L1470: ;
		b_a_vxf[(bint_t)(b_v_if)]=((((((b_rnd(B_INT((1))))*((2))))-((1))))*((2.5)));
		b_a_vyf[(bint_t)(b_v_if)]=(0);
		b_a_vzf[(bint_t)(b_v_if)]=((((((b_rnd(B_INT((1))))*((2))))-((1))))*((2.5)));
		/* line 1480 */
b_L1480: ;
		b_a_mi[(bint_t)(b_v_if)]=((b_a_kri[(bint_t)(b_v_if)])*(b_a_kri[(bint_t)(b_v_if)]));
		/* line 1490 */
b_L1490: ;
		goto b_return;
		/* line 2000 */
b_L2000: ;
		/* line 2010 */
b_L2010: ;
		b_v_if=(0);
		b_fl_6=b_v_akf;
		if(b_v_if > b_fl_6) goto b_f6_e;
b_f6_t: ;
		/* line 2020 */
b_L2020: ;
		b_a_vyf[(bint_t)(b_v_if)]=((b_a_vyf[(bint_t)(b_v_if)])-(b_v_gf));
		/* line 2030 */
b_L2030: ;
		b_a_oxf[(bint_t)(b_v_if)]=((b_a_oxf[(bint_t)(b_v_if)])+(b_a_vxf[(bint_t)(b_v_if)]));
		/* line 2040 */
b_L2040: ;
		b_a_oyf[(bint_t)(b_v_if)]=((b_a_oyf[(bint_t)(b_v_if)])+(b_a_vyf[(bint_t)(b_v_if)]));
		/* line 2050 */
b_L2050: ;
		b_a_ozf[(bint_t)(b_v_if)]=((b_a_ozf[(bint_t)(b_v_if)])+(b_a_vzf[(bint_t)(b_v_if)]));
		/* line 2060 */
b_L2060: ;
		if(-((b_a_oxf[(bint_t)(b_v_if)]) < ((-(b_v_wli))))){
			b_a_oxf[(bint_t)(b_v_if)]=(-(b_v_wli));
			b_a_vxf[(bint_t)(b_v_if)]=(((-(b_a_vxf[(bint_t)(b_v_if)])))*(b_v_ref));
		}
		/* line 2070 */
b_L2070: ;
		if(-((b_a_oxf[(bint_t)(b_v_if)]) > (b_v_wli))){
			b_a_oxf[(bint_t)(b_v_if)]=b_v_wli;
			b_a_vxf[(bint_t)(b_v_if)]=(((-(b_a_vxf[(bint_t)(b_v_if)])))*(b_v_ref));
		}
		/* line 2080 */
b_L2080: ;
		if(-((b_a_ozf[(bint_t)(b_v_if)]) < (b_v_zli))){
			b_a_ozf[(bint_t)(b_v_if)]=b_v_zli;
			b_a_vzf[(bint_t)(b_v_if)]=(((-(b_a_vzf[(bint_t)(b_v_if)])))*(b_v_ref));
		}
		/* line 2090 */
b_L2090: ;
		if(-((b_a_ozf[(bint_t)(b_v_if)]) > (b_v_zri))){
			b_a_ozf[(bint_t)(b_v_if)]=b_v_zri;
			b_a_vzf[(bint_t)(b_v_if)]=(((-(b_a_vzf[(bint_t)(b_v_if)])))*(b_v_ref));
		}
		/* line 2100 */
b_L2100: ;
		if(-((b_a_oyf[(bint_t)(b_v_if)]) < (b_a_kri[(bint_t)(b_v_if)]))){
			b_a_oyf[(bint_t)(b_v_if)]=b_a_kri[(bint_t)(b_v_if)];
			b_a_vyf[(bint_t)(b_v_if)]=(((-(b_a_vyf[(bint_t)(b_v_if)])))*(b_v_ref));
		}
		/* line 2110 */
b_L2110: ;
		if((B_INT(-((b_a_oyf[(bint_t)(b_v_if)]) >= (((b_a_kri[(bint_t)(b_v_if)])-((0.5)))))) & B_INT(-((b_abs(b_a_vyf[(bint_t)(b_v_if)])) < (b_v_grf))))){
			b_a_vyf[(bint_t)(b_v_if)]=(0);
			b_a_vxf[(bint_t)(b_v_if)]=((b_a_vxf[(bint_t)(b_v_if)])*((0.99699999997392297)));
			b_a_vzf[(bint_t)(b_v_if)]=((b_a_vzf[(bint_t)(b_v_if)])*((0.99699999997392297)));
		}
		/* line 2120 */
b_L2120: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_6)) goto b_f6_t;
b_f6_e: ;
		/* line 2200 */
b_L2200: ;
		/* line 2210 */
b_L2210: ;
		b_v_if=(0);
		b_fl_7=b_v_akf;
		if(b_v_if > b_fl_7) goto b_f7_e;
b_f7_t: ;
		/* line 2220 */
b_L2220: ;
		b_v_ji=((b_v_if)+((1)));
		b_fl_8=b_v_akf;
		if(b_v_ji > b_fl_8) goto b_f8_e;
		b_v_M0=b_a_kri[(bint_t)(b_v_if)];
		b_v_M1=b_a_mi[(bint_t)(b_v_if)];
b_f8_t: ;
		/* line 2230 */
b_L2230: ;
		b_v_dxf=((b_a_oxf[B_INT(b_v_ji)])-(b_a_oxf[(bint_t)(b_v_if)]));
		b_v_dyf=((b_a_oyf[B_INT(b_v_ji)])-(b_a_oyf[(bint_t)(b_v_if)]));
		b_v_dzf=((b_a_ozf[B_INT(b_v_ji)])-(b_a_ozf[(bint_t)(b_v_if)]));
		/* line 2240 */
b_L2240: ;
		b_v_df=b_sqr(((((((b_v_dxf)*(b_v_dxf)))+(((b_v_dyf)*(b_v_dyf)))))+(((b_v_dzf)*(b_v_dzf)))));
		/* line 2250 */
b_L2250: ;
		b_v_rsi=((b_v_M0)+(b_a_kri[B_INT(b_v_ji)]));
		/* line 2260 */
b_L2260: ;
		if(-((b_v_df) >= (b_v_rsi))){ goto b_L2360; }
		/* line 2270 */
b_L2270: ;
		if(-((b_v_df) < ((0.0099999999983992893)))){
			b_v_df=(0.0099999999983992893);
			b_v_dxf=(0.0099999999983992893);
			b_v_dyf=(0);
			b_v_dzf=(0);
		}
		/* line 2280 */
b_L2280: ;
		b_v_nxf=(b_v_dxf/b_v_df);
		b_v_nyf=(b_v_dyf/b_v_df);
		b_v_nzf=(b_v_dzf/b_v_df);
		/* line 2290 */
b_L2290: ;
		b_v_ovf=((b_v_rsi)-(b_v_df));
		/* line 2295 */
b_L2295: ;
		b_v_mti=((b_v_M1)+(b_a_mi[B_INT(b_v_ji)]));
		b_v_fif=((breal_t)(b_a_mi[B_INT(b_v_ji)])/(breal_t)(b_v_mti));
		b_v_fjf=((breal_t)(b_v_M1)/(breal_t)(b_v_mti));
		/* line 2300 */
b_L2300: ;
		b_a_oxf[(bint_t)(b_v_if)]=((b_a_oxf[(bint_t)(b_v_if)])-(((((b_v_nxf)*(b_v_ovf)))*(b_v_fif))));
		b_a_oyf[(bint_t)(b_v_if)]=((b_a_oyf[(bint_t)(b_v_if)])-(((((b_v_nyf)*(b_v_ovf)))*(b_v_fif))));
		b_a_ozf[(bint_t)(b_v_if)]=((b_a_ozf[(bint_t)(b_v_if)])-(((((b_v_nzf)*(b_v_ovf)))*(b_v_fif))));
		/* line 2310 */
b_L2310: ;
		b_a_oxf[B_INT(b_v_ji)]=((b_a_oxf[B_INT(b_v_ji)])+(((((b_v_nxf)*(b_v_ovf)))*(b_v_fjf))));
		b_a_oyf[B_INT(b_v_ji)]=((b_a_oyf[B_INT(b_v_ji)])+(((((b_v_nyf)*(b_v_ovf)))*(b_v_fjf))));
		b_a_ozf[B_INT(b_v_ji)]=((b_a_ozf[B_INT(b_v_ji)])+(((((b_v_nzf)*(b_v_ovf)))*(b_v_fjf))));
		/* line 2320 */
b_L2320: ;
		b_v_rxf=((b_a_vxf[B_INT(b_v_ji)])-(b_a_vxf[(bint_t)(b_v_if)]));
		b_v_ryf=((b_a_vyf[B_INT(b_v_ji)])-(b_a_vyf[(bint_t)(b_v_if)]));
		b_v_rzf=((b_a_vzf[B_INT(b_v_ji)])-(b_a_vzf[(bint_t)(b_v_if)]));
		/* line 2330 */
b_L2330: ;
		b_v_vnf=((((((b_v_rxf)*(b_v_nxf)))+(((b_v_ryf)*(b_v_nyf)))))+(((b_v_rzf)*(b_v_nzf))));
		/* line 2340 */
b_L2340: ;
		if(-((b_v_vnf) >= ((0)))){ goto b_L2360; }
		/* line 2350 */
b_L2350: ;
		b_v_imf=((((-((((1))+(b_v_ref)))))*(b_v_vnf))/((((breal_t)((1))/(breal_t)(b_v_M1)))+(((breal_t)((1))/(breal_t)(b_a_mi[B_INT(b_v_ji)])))));
		/* line 2352 */
b_L2352: ;
		b_a_vxf[(bint_t)(b_v_if)]=((b_a_vxf[(bint_t)(b_v_if)])-((((b_v_imf)*(b_v_nxf))/(breal_t)(b_v_M1))));
		b_a_vyf[(bint_t)(b_v_if)]=((b_a_vyf[(bint_t)(b_v_if)])-((((b_v_imf)*(b_v_nyf))/(breal_t)(b_v_M1))));
		b_a_vzf[(bint_t)(b_v_if)]=((b_a_vzf[(bint_t)(b_v_if)])-((((b_v_imf)*(b_v_nzf))/(breal_t)(b_v_M1))));
		/* line 2354 */
b_L2354: ;
		b_a_vxf[B_INT(b_v_ji)]=((b_a_vxf[B_INT(b_v_ji)])+((((b_v_imf)*(b_v_nxf))/(breal_t)(b_a_mi[B_INT(b_v_ji)]))));
		b_a_vyf[B_INT(b_v_ji)]=((b_a_vyf[B_INT(b_v_ji)])+((((b_v_imf)*(b_v_nyf))/(breal_t)(b_a_mi[B_INT(b_v_ji)]))));
		b_a_vzf[B_INT(b_v_ji)]=((b_a_vzf[B_INT(b_v_ji)])+((((b_v_imf)*(b_v_nzf))/(breal_t)(b_a_mi[B_INT(b_v_ji)]))));
		/* line 2360 */
b_L2360: ;
		b_v_ji += 1;
		if(b_v_ji <= (b_fl_8)) goto b_f8_t;
b_f8_e: ;
		/* line 2370 */
b_L2370: ;
		b_v_if += 1;
		if(b_v_if <= (b_fl_7)) goto b_f7_t;
b_f7_e: ;
		/* line 2380 */
b_L2380: ;
		goto b_return;
b_return: ;
		if (b_gosubSP<=0) goto b_end;
		switch (b_gosubStack[--b_gosubSP]) {
			case 0: goto b_ret0;
			case 1: goto b_ret1;
			case 2: goto b_ret2;
			case 3: goto b_ret3;
			case 4: goto b_ret4;
			case 5: goto b_ret5;
			default: goto b_end;}
b_end:
		b_flush();

		tsb_hold();
		if(tsb_done)break;
		b_init();
	}
	return 0;
}
